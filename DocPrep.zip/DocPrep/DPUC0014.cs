﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;


namespace DocPrep
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]
    public class DPUC0014 : MasterTestClass
    {
        public DPUC0014()
        {
        }

        #region BAT
        [TestMethod]
        public void DPUC0014_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Check Spell.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "1.Navigate to Buyer summary screen and edit the instance.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Check the Spelling.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetText().Contains("Spelling").ToString(), "Verifying spelling issue was corrected");
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }

        [TestMethod]
        public void DPUC0014_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Ignore Misspelled Words.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "1.Navigate to Buyer summary screen and edit the instance.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Ignore the Spelling.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.Ignore.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetText().Contains("Speling").ToString(), "Verifying spelling issue was corrected");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        public void DPUC0014_REG0001()
        {
            try
            {
                Reports.TestDescription = "DP4227_Buyer_Seller: The system will allow users to cancel the spell checker without save changes on Buyer, seller and Property Tax Info screen.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Click Vest button and entering vest details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Select the correct spelling on Buyer seller setup vesting.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("relation");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Cancel.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetText().Contains("rlation").ToString(), "Verifying spelling issue was corrected");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0014_REG0002()
        {
            try
            {
                Reports.TestDescription = "DP4227_Property_Tax_Info: The system will allow users to cancel the spell checker without save changes on Buyer, seller and Property Tax Info screen.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to property tax info screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Update Property Information";
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("1 Main St");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Lot 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Box 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Santa Ana");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Orange");

                Reports.TestStep = "Update Legal Description info";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("Lot1");
                FastDriver.PropertyTaxInfoLegalDesciption.Block.FASetText("Block1");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("Unit1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to property tax info and Check for spelling.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.AbbrLegalDesciptionComments.FASetText("atached");

                Reports.TestStep = "Click on check Spelling.";
                FastDriver.PropertyTaxInfoLegalDesciption.AbbreviatedLegalDescriptionCheckSpelling.FAClick();
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("attached");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Cancel.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify that cancellation of spell check is working fine.";
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PropertyTaxInfoLegalDesciption.AbbrLegalDesciptionComments.FAGetText().Contains("atached").ToString(), "Verifying misspelled word is still present.");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to property tax info and Check for spelling.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.CompleteLegalDescriptionComments.FASetText("atached");

                Reports.TestStep = "Click on check Spelling.";
                FastDriver.PropertyTaxInfoLegalDesciption.CompleteLegalDescriptioncheckSpelling.FAClick();
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("attached");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Cancel.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify that cancellation of spell check is working fine.";
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PropertyTaxInfoLegalDesciption.CompleteLegalDescriptionComments.FAGetText().Contains("atached").ToString(), "Verifying misspelled word is still present.");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0014_REG0003()
        {
            try
            {
                Reports.TestDescription = "DP4227_File_Notes: The system will allow users to cancel the spell checker without save changes on Buyer, seller and Property Tax Info screen.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create a file note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("EPIC");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Enter data incorrect spell in new note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.txtNote.FASendKeys("Speling");
                FastDriver.FileNotesEditor.CheckSpelling.FAClick();

                Reports.TestStep = "Click on check Spelling.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Cancel.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Vest button and entering vest details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Select the correct spelling on Buyer seller setup vesting.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("relation");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Cancel.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetText().Contains("rlation").ToString(), "Verifying spelling issue was not corrected");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0014_REG0004()
        {
            try
            {
                Reports.TestDescription = "DP4227_File_Notes: The system will allow users to cancel the spell checker on Finalized Dialog.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Add Document to Document Repository screen.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument(templateType: "Form");
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();

                Reports.TestStep = "Click on Edit button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad(element: FastDriver.DocumentRepository.Deliver);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Enter Text.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText("atached");
                FastDriver.DocPrepTextEditorDlg.CheckSpelling.FAClick();

                Reports.TestStep = "Click Check Spelling";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("attached");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Cancel.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Check Spelling";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.DocPrepTextEditorDlg.Note.FAGetText().Contains("attached").ToString(), "Verifying spelling has been corrected.");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0014_REG0005()
        {
            try
            {
                Reports.TestDescription = "DP4227_1: The system will allow users to cancel the spell checker without save changes on Template maintenance screen.";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Select the template and Click on Find.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(1, "RESHMA", 1, TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Phrase marker Edit button.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Click on Phrase editor.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                string WindoName = FastDriver.PhraseMaintenance.PhraseName.FAGetText() + " - " + FastDriver.PhraseMaintenance.Description.FAGetText();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Spell check.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: WindoName);
                FastDriver.PhraseEditorDlg.TextArea.FASendKeys(FAKeys.End);
                FastDriver.PhraseEditorDlg.TextArea.FASendKeys(FAKeys.Enter);
                FastDriver.PhraseEditorDlg.TextArea.FASendKeys("speling  .");
                FastDriver.PhraseEditorDlg.SpellCheck.FAClick();

                Reports.TestStep = "Verify the correct spelling and cancelling the spell check for new notes.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("spelling");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Cancel.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: WindoName);
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq
        //Iteration                               : r10
        //UserStory                               : User Story 748571:INC2374897 - Direct [Bug] - Spell Check missing from Email and Fax Modules
        //TestCase                                : 884495
        //Appended By/ Created By                 : (Added multiple screens)Nikhil
        [TestMethod]
        public void DPUC0014_REG0006()
        {
            try
            {
                Reports.TestDescription = "DP4227_2: The system will allow users to correct the spell using spell checker on Buyer, seller and Property Tax Info screen.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Click Vest button and entering vest details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Select the correct spelling on Buyer seller setup vesting.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("relation");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker get disabled";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetText().Contains("relation").ToString(), "Verifying spelling issue was corrected");

                Reports.TestStep = "Navigate to property tax info screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Update Property Information";
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("1 Main St");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Lot 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Box 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Santa Ana");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Orange");

                Reports.TestStep = "Update Legal Description info";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("Lot1");
                FastDriver.PropertyTaxInfoLegalDesciption.Block.FASetText("Block1");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("Unit1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to property tax info and Check for spelling.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.AbbrLegalDesciptionComments.FASetText("atached");

                Reports.TestStep = "Click on check Spelling.";
                FastDriver.PropertyTaxInfoLegalDesciption.AbbreviatedLegalDescriptionCheckSpelling.FAClick();
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("attached");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker get disabled";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.ChangeAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Change.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Ignore.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.IgnoreAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify that spelling has been corrected.";
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PropertyTaxInfoLegalDesciption.AbbrLegalDesciptionComments.FAGetText().Contains("attached").ToString(), "Verifying misspelled word is still present.");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Create a file note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("EPIC");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Enter data incorrect spell in new note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.txtNote.FASendKeys("Speling");
                FastDriver.FileNotesEditor.CheckSpelling.FAClick();

                Reports.TestStep = "Click on check Spelling.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker get disabled";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.ChangeAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Change.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Ignore.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.IgnoreAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Vest button and entering vest details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Select the correct spelling on Buyer seller setup vesting.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("relation");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker get disabled";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.ChangeAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Change.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Ignore.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.IgnoreAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetText().Contains("relation").ToString(), "Verifying spelling issue was corrected");

                //Bug#:748571
                Reports.TestStep = "Verify spell check in Invoice screen";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.Delivery("Email");
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.Delivery("Fax");
                FastDriver.SpellingErrorDlg.SpellCheck_Fax();

                Reports.TestStep = "Verify spell check in Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.PerformDelivery("Email");
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.PerformDelivery("Fax");
                FastDriver.SpellingErrorDlg.SpellCheck_Fax();

                Reports.TestStep = "Verify spell check in Deposit Receipt History screen";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>(@"Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.Method.FASelectItem("Email");
                FastDriver.DepositReceiptHistory.Deliver.FAClick();
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.Method.FASelectItem("Fax");
                FastDriver.DepositReceiptHistory.Deliver.FAClick();
                FastDriver.SpellingErrorDlg.SpellCheck_Fax();

                Reports.TestStep = "Verify spell check in Disbursement History screen";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Order Entry>Escrow Closing>Disbursements>Disbursement History");
                FastDriver.DisbursementHistory.SwitchToContentFrame();
                FastDriver.DisbursementHistory.PerformDelivery("Email");
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                FastDriver.DisbursementHistory.PerformDelivery("Fax");
                FastDriver.SpellingErrorDlg.SpellCheck_Fax();

                Reports.TestStep = "Verify spell check in File Balance Summary screen";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.Method("Email");
                FastDriver.EscrowFileBalanceSummary.Deliver();
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.Method("Fax");
                FastDriver.EscrowFileBalanceSummary.Deliver();
                FastDriver.SpellingErrorDlg.SpellCheck_Fax();

                Reports.TestStep = "Verify spell check in Settlement Statement screen";
                FastDriver.LeftNavigation.Navigate<PrintEscrowSetlleStmt>(@"Order Entry>Escrow Closing>Settlement Statement").WaitForScreenToLoad();
                FastDriver.PrintEscrowSetlleStmt.Delivery("Email");
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                FastDriver.PrintEscrowSetlleStmt.WaitForScreenToLoad();
                FastDriver.PrintEscrowSetlleStmt.Delivery("Fax");
                FastDriver.SpellingErrorDlg.SpellCheck_Fax();

                Reports.TestStep = "Verify spell check in Trust Accounting Interface screen";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>(@"Home");
                FastDriver.TrustAccounting.Open();
                FastDriver.TrustAccounting.SwitchToContentFrame();
                FastDriver.TrustAccounting.DeliveryMethod.FASelectItem("Email");
                FastDriver.TrustAccounting.Deliver.FAClick();
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                FastDriver.LeftNavigation.Navigate<TrustAccounting>(@"Home");
                FastDriver.TrustAccounting.Open();
                FastDriver.TrustAccounting.SwitchToContentFrame();
                FastDriver.TrustAccounting.DeliveryMethod.FASelectItem("Fax");
                FastDriver.TrustAccounting.Deliver.FAClick();
                FastDriver.SpellingErrorDlg.SpellCheck_Fax();


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0014_REG0007()
        {
            try
            {
                Reports.TestDescription = "DP4227_3: The system will allow users to correct the spell using spell checker on Template maintenance screen.";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Select the template and Click on Find.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(1, "RESHMA", 1, TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Phrase marker Edit button.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Click on Phrase editor.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                string WindoName = FastDriver.PhraseMaintenance.PhraseName.FAGetText() + " - " + FastDriver.PhraseMaintenance.Description.FAGetText();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Spell check.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: WindoName);
                FastDriver.PhraseEditorDlg.TextArea.FASendKeys(FAKeys.End);
                FastDriver.PhraseEditorDlg.TextArea.FASendKeys(FAKeys.Enter);
                FastDriver.PhraseEditorDlg.TextArea.FASendKeys("speling  .");
                FastDriver.PhraseEditorDlg.SpellCheck.FAClick();

                Reports.TestStep = "Verify the correct spelling and cancelling the spell check for new notes.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("spelling");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Done.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: WindoName);
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0014_REG0008()
        {
            try
            {
                Reports.TestDescription = "FIELD_DEFINATION: Verify the Field Definition For spell checker dialog.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Verifying the spell changed and click on Spell check button for Buyer.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Verify Spell Checker buttons are enabled";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.ChangeAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Change.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Ignore.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.IgnoreAll.IsEnabled().ToString(), "Verifying button is disabled after spelling is checked");

                Reports.TestStep = "Verify suggested words";
                Support.AreEqual("ration, relation, elation", FastDriver.SpellingErrorDialog.SuggestedWords.FAGetAllTextFromSelect(separator: ", "));

                Reports.TestStep = "Enter New text to the New Spelling.";
                FastDriver.SpellingErrorDialog.NewSpelling.FASetText("Testing");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Done.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.ChangeAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Change.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Ignore.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.IgnoreAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verifying that spell checker is work fine for New Spell.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetText().Contains("Testing").ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Vest button and entering vest details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Verify Spell Checker buttons are enabled";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.ChangeAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is enabled");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Change.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is enabled");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.Ignore.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is enabled");
                Support.AreEqual("False", FastDriver.SpellingErrorDialog.IgnoreAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is enabled");

                Reports.TestStep = "Verify suggested words";
                Support.AreEqual("ration, relation, elation", FastDriver.SpellingErrorDialog.SuggestedWords.FAGetAllTextFromSelect(separator: ", "));

                Reports.TestStep = "Enter New text to the New Spelling.";
                FastDriver.SpellingErrorDialog.NewSpelling.FASetText("Testing");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker gets disable and clicking on Done.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.ChangeAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Change.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.Ignore.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                Support.AreEqual("True", FastDriver.SpellingErrorDialog.IgnoreAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0014_REG0009()
        {
            try
            {
                Reports.TestDescription = "FIELD_DEFINATION: Verify the Field Definition For shortkeys for spell checker dialog.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Verifying the spell changed and click on Spell check button for Buyer.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Select the correct spelling on Buyer seller setup vesting.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("relation");
                Keyboard.SendKeys("%C");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Spell check for Relation word is done.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetText().Contains("relation").ToString(), "Verifying spelling issue was corrected");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Vest button and entering vest details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Select the correct spelling on Buyer seller setup vesting.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("relation");
                Keyboard.SendKeys("%L");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Spell check for Relation word is done.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Vest button and entering vest details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Select the correct spelling on Buyer seller setup vesting.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("relation");
                Keyboard.SendKeys("%I");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Spell check for Relation word is done.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Vest button and entering vest details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("rlation");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();

                Reports.TestStep = "Select the correct spelling on Buyer seller setup vesting.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("relation");
                Keyboard.SendKeys("%G");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Spell check for Relation word is done.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0014_REG0010()
        {
            try
            {
                Reports.TestDescription = "Error Warning Conditions.";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Verify controls on Dictionary screen.";
                FastDriver.LeftNavigation.Navigate<DictionaryManagement>("Home>System Maintenance>Document Preparation>Custom Dictionary").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.DictionaryManagement.NewValue.IsDisplayed().ToString(), "Verifying button exists.");
                Support.AreEqual("True", FastDriver.DictionaryManagement.Search.IsDisplayed().ToString(), "Verifying button exists.");
                Support.AreEqual("True", FastDriver.DictionaryManagement.Add.IsDisplayed().ToString(), "Verifying button exists.");
                Support.AreEqual("True", FastDriver.DictionaryManagement.Remove.IsDisplayed().ToString(), "Verifying button exists.");
                Support.AreEqual("True", FastDriver.DictionaryManagement.Edit.IsDisplayed().ToString(), "Verifying button exists.");

                Reports.TestStep = "Verify enable disable property.";
                Support.AreEqual("True", FastDriver.DictionaryManagement.NewValue.IsEnabled().ToString(), "Verifying button enabled.");
                Support.AreEqual("True", FastDriver.DictionaryManagement.Search.IsEnabled().ToString(), "Verifying button enabled.");
                Support.AreEqual("True", FastDriver.DictionaryManagement.Add.IsEnabled().ToString(), "Verifying button enabled.");
                Support.AreEqual("False", FastDriver.DictionaryManagement.Remove.IsEnabled().ToString(), "Verifying button enabled.");
                Support.AreEqual("False", FastDriver.DictionaryManagement.Edit.IsEnabled().ToString(), "Verifying button enabled.");

                Reports.TestStep = "Click on Add.";
                FastDriver.DictionaryManagement.Add.FAClick();

                Reports.TestStep = "Please enter a New Value";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.DictionaryManagement.WaitForScreenToLoad();

                Reports.TestStep = "Enter Text and click on Add.";
                FastDriver.DictionaryManagement.NewValue.FASetText("Alp" + Support.RandomString("AAAZZZ"));
                string newValue = FastDriver.DictionaryManagement.NewValue.FAGetValue();
                FastDriver.DictionaryManagement.Add.FAClick();

                Reports.TestStep = "Select added Value.";
                FastDriver.DictionaryManagement.CustomWordsTable.PerformTableAction(1, newValue, 1, TableAction.Click);
                FastDriver.DictionaryManagement.Edit.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.DictionaryManagement.WaitForScreenToLoad();

                Reports.TestStep = "Enter the same word we saved already.";
                FastDriver.DictionaryManagement.NewValue.FASetText(newValue);
                FastDriver.DictionaryManagement.Add.FAClick();
                Support.AreEqual("The word " + newValue + " already exists in your Regions's Dictionary.", FastDriver.DictionaryManagement.ErrorMsg.FAGetText(), "Verifying error message.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Useful Methods
        private void Login(string Key)
        {

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(Key, credentials, true);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
