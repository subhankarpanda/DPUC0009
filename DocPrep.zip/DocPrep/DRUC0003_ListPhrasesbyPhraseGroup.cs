﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;
using System.Linq;


namespace DocPrep
{
    /// <summary>
    /// Summary description for DRUC0003_ListPhrasesbyPhraseGroup
    /// </summary>
    [CodedUITest]
    public class DRUC0003 : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void DRUC0003_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_001: Navigate to DocPrep reports link & Select SelectAll checkbox and Click on Generate report button.";

                //
                Reports.TestStep = "Login To Fast";
                this.Login(true);
                //FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                //
                Reports.TestStep = "Navigate to DocPrep reports link & Select SelectAll checkbox.";
                FastDriver.LeftNavigation.Navigate<DocPrepReports>("Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Phrase Group").WaitForScreenToLoad();
                FastDriver.DocPrepReports.SelectAll.FASetCheckbox(true);

                //
                Reports.TestStep = "Click on Generate report button.";
                FastDriver.DocPrepReports.GenerateReport.FAClick();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }


        [TestMethod]
        public void DRUC0003_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_002: Verify for the eagle image.";

                //
                Reports.TestStep = "Login To Fast";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to DocPrep reports link & Select SelectAll checkbox.";
                FastDriver.LeftNavigation.Navigate<DocPrepReports>("Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Phrase Group").WaitForScreenToLoad();
                FastDriver.DocPrepReports.SelectAll.FASetCheckbox(true);

                //
                Reports.TestStep = "Click on Generate report button.";
                FastDriver.DocPrepReports.GenerateReport.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Phrases by Phrase Group");
                //
                Reports.TestStep = "Verify for the eagle image.";
                this.VerifyEagleImageExists();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DRUC0003_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF1_001: Navigate to DocPrep reports link & Select phrase groupname checkbox and Click on Generate report button.";

                //
                Reports.TestStep = "Login To Fast";
                this.Login(true);
                //
                Reports.TestStep = "Navigate to DocPrep reports link & Select SelectAll checkbox.";
                FastDriver.LeftNavigation.Navigate<DocPrepReports>("Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Phrase Group").WaitForScreenToLoad();
                FastDriver.DocPrepReports.SelectPhraseGroupName.FASetCheckbox(true);

                Reports.TestStep = "Click on Generate report button.";
                FastDriver.DocPrepReports.GenerateReport.FAClick();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DRUC0003_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF1_002: Verify for the eagle image.";

                //
                Reports.TestStep = "Login To Fast";
                this.Login(true);
                //
                Reports.TestStep = "Navigate to DocPrep reports link & Select SelectAll checkbox.";
                FastDriver.LeftNavigation.Navigate<DocPrepReports>("Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Phrase Group").WaitForScreenToLoad();
                FastDriver.DocPrepReports.SelectPhraseGroupName.FASetCheckbox(true);

                Reports.TestStep = "Click on Generate report button.";
                FastDriver.DocPrepReports.GenerateReport.FAClick();

                //
                Reports.TestStep = "Verify for the eagle image.";
                this.VerifyEagleImageExists();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DRUC0003_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF2_002: Select Phrasename checkbox in Select phrase screen & click on generate report button and Verify for Eagle image in Generated report.";

                //
                Reports.TestStep = "Login To Fast";
                this.Login(true);
                //
                Reports.TestStep = "Navigate to DocPrep reports link & Select SelectAll checkbox.";
                FastDriver.LeftNavigation.Navigate<DocPrepReports>("Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Phrase Group").WaitForScreenToLoad();

                //
                Reports.TestStep = "Select phrase group name checkbox.";
                FastDriver.DocPrepReports.SelectPhraseGroupName.FASetCheckbox(true);

                //
                Reports.TestStep = "Click on select phrases button.";
                FastDriver.DocPrepReports.SelectPhrases.FAClick();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DRUC0003_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF2_001: Navigate to DocPrep reports link & Select phrase groupname checkbox and Click on select phrases button.";

                //
                Reports.TestStep = "Login To Fast";
                this.Login(true);
                //
                Reports.TestStep = "Navigate to DocPrep reports link & Select SelectAll checkbox.";
                FastDriver.LeftNavigation.Navigate<DocPrepReports>("Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Phrase Group").WaitForScreenToLoad();

                //
                Reports.TestStep = "Select Phrase name checkbox in Select phrase screen.";
                FastDriver.DocPrepReports.SelectPhraseTypeName.FASetCheckbox(true);

                //
                Reports.TestStep = "Click on Generate report button.";
                FastDriver.DocPrepReports.GenerateReport.FAClick();

                //
                Reports.TestStep = "Verify for the eagle image.";
                Playback.Wait(10000);
                this.VerifyEagleImageExists();

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }


        #endregion BAT

        #region REG
        [TestMethod]
        public void DRUC0003_REG0001()
        {
            try
            {
                Reports.TestDescription = "DP3629_DP3725_DP3969_EWC_FD_HK: Navigate to DocPrep reports link & Select phrase groupname checkbox and Click on Generate report button.";
                this.Login(true);

                // 
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "Enter mandatory info to create a new phrase.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                string randomName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(randomName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("##");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Continue From Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("##");
                FastDriver.PhraseGroupMaintenance.Save.FAClick();
                Playback.Wait(4000);

                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Select template and click on Generate report button.";
                FastDriver.LeftNavigation.Navigate<DocPrepReports>("Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Phrase Group").WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectAll.FASetCheckbox(false);
                Support.AreEqual("True", FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectGroupDisplayPhraseText.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectTemplateGroupcheckBox1.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectTemplateGroupcheckBox2.IsSelected().ToString());
                Keyboard.SendKeys("%g");
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Click on generate report without select any phrase group.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                // 
                Reports.TestStep = "Select template and click on Generate report button.";
                FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SwitchToContentFrame();
                FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectAll.FASetCheckbox(true);
                FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectGroupDisplayPhraseText.FASetCheckbox(true);
                Support.AreEqual("True", FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectTemplateGroupcheckBox1.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectTemplateGroupcheckBox2.IsSelected().ToString());
                FastDriver.DocPrepReportsPhrasesbyPhraseGroup.GenerateReport.FAClick();
                Playback.Wait(92000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Phrases by Phrase Group");
                Keyboard.SendKeys("%+{F4}");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SwitchToContentFrame();

                // 
                Reports.TestStep = "Verify for recently added phrase.";
                Support.AreEqual("True", FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectGroupDisplayPhraseText.IsSelected().ToString());
                int counter = 0;
                bool doBreak = false;
                while (!doBreak)
                {
                    if (FastDriver.DocPrepReportsPhrasesbyPhraseGroup.DocPrepReportsPhrasesbyPhraseGroupTable.FAGetText().Contains(randomName))
                    {
                        FastDriver.DocPrepReportsPhrasesbyPhraseGroup.DocPrepReportsPhrasesbyPhraseGroupTable.PerformTableAction(2, randomName, 3, TableAction.Click);
                        doBreak = true;
                        //break;
                    }
                    else
                    {
                        counter = counter + 2;
                        IWebElement element = FastDriver.WebDriver.FindElement(By.Id("dgridSel_FAFDatagridItem_" + counter));
                        element.FAClick();
                        Playback.Wait(2500);
                        FastDriver.DocPrepReportsPhrasesbyPhraseGroup.WaitCreation(FastDriver.DocPrepReportsPhrasesbyPhraseGroup.DocPrepReportsPhrasesbyPhraseGroupTable);
                    }
                }

                // 
                Reports.TestStep = "Select template and click on Generate report button.";
                FastDriver.DocPrepReportsPhrasesbyPhraseGroup.SelectAll.FASetCheckbox(false);
              
                counter = 0;
                doBreak = false;
                while (!doBreak)
                {
                    if (FastDriver.DocPrepReportsPhrasesbyPhraseGroup.DocPrepReportsPhrasesbyPhraseGroupTable.FAGetText().Contains("0~ASLN*"))
                    {
                        FastDriver.DocPrepReportsPhrasesbyPhraseGroup.DocPrepReportsPhrasesbyPhraseGroupTable.PerformTableAction(2, "0~ASLN*", 1, TableAction.On);
                        doBreak = true;
                        //break;
                    }
                    else
                    {
                        counter = counter + 2;
                        IWebElement element = FastDriver.WebDriver.FindElement(By.Id("dgridSel_FAFDatagridItem_" + counter));
                        element.FAClick();
                        Playback.Wait(1000);
                        FastDriver.DocPrepReportsPhrasesbyPhraseGroup.WaitCreation(FastDriver.DocPrepReportsPhrasesbyPhraseGroup.DocPrepReportsPhrasesbyPhraseGroupTable);
                    }
                }


                // 
                Reports.TestStep = "Select template and click on Generate report button.2222";
                Playback.Wait(10000);
                counter = 0;
                doBreak = false; 
                while (!doBreak)
                {
                    if (FastDriver.DocPrepReportsPhrasesbyPhraseGroup.DocPrepReportsPhrasesbyPhraseGroupTable.FAGetText().Contains("0~BUYR*"))
                    {
                        FastDriver.DocPrepReportsPhrasesbyPhraseGroup.DocPrepReportsPhrasesbyPhraseGroupTable.PerformTableAction(2, "0~BUYR*", 1, TableAction.On);
                        doBreak = true;
                        //break;
                    }
                    else
                    {
                        counter = counter + 2;
                        IWebElement element = FastDriver.WebDriver.FindElement(By.Id("dgridSel_FAFDatagridItem_" + counter));
                        element.FAClick();
                        Playback.Wait(1000);
                        FastDriver.DocPrepReportsPhrasesbyPhraseGroup.WaitCreation(FastDriver.DocPrepReportsPhrasesbyPhraseGroup.DocPrepReportsPhrasesbyPhraseGroupTable);
                    }
                }
                FastDriver.DocPrepReportsPhrasesbyPhraseGroup.GenerateReport.FAClick();



            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion REG

        #region Custom Class Methods
        private void Login(bool admLogin = false)
        {
            if (!admLogin)
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,                // AutoConfig.UserName,
                    Password = AutoConfig.UserPassword            //AutoConfig.UserPassword
                };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            else
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            }
        }

        private void VerifyEagleImageExists()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("List Phrases by Phrase Group");
            IWebElement element = FastDriver.WebDriver.FindElements(By.TagName("img"))
              .FirstOrDefault(p => p.GetAttribute("src").Contains("eagle.jpg"));
            if (element == null)
            {
                Reports.StatusUpdate("Not As Expected: Eagle Image not available", false);
            }
            else
            {
                Reports.StatusUpdate("As Expected: Eagle Image available", true);
            }
        }

        #endregion Custom Class Methods

        #region Class CleanUp
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
        #endregion Class Cleanup
    }
}