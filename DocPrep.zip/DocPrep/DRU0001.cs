﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;


namespace DocPrep
{
    
    [CodedUITest]
    public class DRU0001 : MasterTestClass
    {
        public DRU0001()
        {
        }

        #region BAT
        [TestMethod]
        public void DRUC0001_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Login TO FAST Application ADM Side ,Generate report of all templates using all phrases in all phrase groups.";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Template using phrase screen and select all group and generate report.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsTemplatesUsingPhrases>("System Maintenance>Document Preparation>DocPrep Reports>Templates Using Phrases").WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesUsingPhrases.SelectGroupSelectAll.FASetCheckbox(true);
                FastDriver.DocPrepReportsTemplatesUsingPhrases.SelectGroupGenerateReport.FAClick();

                Reports.TestStep = "Verify for the image on list phrase by template screen.";
                FastDriver.ListTemplatesUsingSpecificPhrases.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ListTemplatesUsingSpecificPhrases.smsfastimageseaglejpg.IsDisplayed().ToString(), "Verying Eagle Image is Displayed");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DRUC0001_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Generate report of all templates using all phrases in select phrase groups.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Template using phrase screen and select all group and generate report.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsTemplatesUsingPhrases>("System Maintenance>Document Preparation>DocPrep Reports>Templates Using Phrases").WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesUsingPhrases.DocPrepReportsTemplatesUsingPhrasesTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DocPrepReportsTemplatesUsingPhrases.SelectGroupGenerateReport.FAClick();

                Reports.TestStep = "Verify for the image on list phrase by template screen.";
                FastDriver.ListTemplatesUsingSpecificPhrases.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ListTemplatesUsingSpecificPhrases.smsfastimageseaglejpg.IsDisplayed().ToString(), "Verying Eagle Image is Displayed");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DRUC0001_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF1: Generate report of all templates using all phrases in select phrase groups.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Template using phrase screen and select all group and generate report.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsTemplatesUsingPhrases>("System Maintenance>Document Preparation>DocPrep Reports>Templates Using Phrases").WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesUsingPhrases.DocPrepReportsTemplatesUsingPhrasesTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DocPrepReportsTemplatesUsingPhrases.SelectGroupSelectPhrases.FAClick();
                FastDriver.DocPrepReportsTemplatesUsingPhrases1.WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesUsingPhrases1.DocPrepReportsTemplatesUsingPhrasesTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DocPrepReportsTemplatesUsingPhrases1.SelectPhraseGenerateReport.FAClick();

                Reports.TestStep = "Verify for the image on list phrase by template screen.";
                FastDriver.ListTemplatesUsingSpecificPhrases.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ListTemplatesUsingSpecificPhrases.smsfastimageseaglejpg.IsDisplayed().ToString(), "Verying Eagle Image is Displayed");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        public void DRUC0001_REG0001()
        {
            try
            {

                Reports.TestDescription = "DP3627_DP3722_DP3967_EWC_FD_HK: Select Phrase and generate report, Verify table columns";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create a new phrase.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Name.FASetText(@"##" + Support.RandomString("AN"));
                string phraseName = FastDriver.PhraseGroupMaintenance.Name.FAGetValue();
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText(@"##");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Continue From Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("DRU0001 REG Test");
                FastDriver.BottomFrame.Done();
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Template using phrase screen and select all group and generate report.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsTemplatesUsingPhrases>("System Maintenance>Document Preparation>DocPrep Reports>Templates Using Phrases").WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesUsingPhrases.SelectGroupGenerateReport.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.DocPrepReportsTemplatesUsingPhrases.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Template using phrase screen and select all and generate report.";
                FastDriver.DocPrepReportsTemplatesUsingPhrases.DocPrepReportsTemplatesUsingPhrasesTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DocPrepReportsTemplatesUsingPhrases.SelectGroupGenerateReport.FAClick();

                Reports.TestStep = "Close the report.";
                FastDriver.ListTemplatesUsingSpecificPhrases.WaitForScreenToLoad();
                FastDriver.WebDriver.Close();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                
                Reports.TestStep = "Verify for recently added phrase.";
                FastDriver.DocPrepReportsTemplatesUsingPhrases.WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesUsingPhrases.DocPrepReportsTemplatesUsingPhrasesTable.PerformTableAction(1, 1, TableAction.Off);
                FastDriver.DocPrepReportsTemplatesUsingPhrases.WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesUsingPhrases.DocPrepReportsTemplatesUsingPhrasesTable.PerformTableAction(2, phraseName, 2, TableAction.Click);

                Reports.TestStep = "Navigate to Template using phrase screen and select two group and generate report.";
                FastDriver.DocPrepReportsTemplatesUsingPhrases.DocPrepReportsTemplatesUsingPhrasesTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DocPrepReportsTemplatesUsingPhrases.DocPrepReportsTemplatesUsingPhrasesTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DocPrepReportsTemplatesUsingPhrases.SelectGroupGenerateReport.FAClick();
                FastDriver.ListTemplatesUsingSpecificPhrases.WaitForScreenToLoad();

                

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DRUC0001_REG0002_PH()
        {
            try
            {
                Reports.TestDescription = "DP3622_DP3635_DP3638_DP3642_DP3722_DP3967_PlaceHolder: Report generated is in PDF, Verify manually";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Useful Methods
        private void Login(string Key)
        {

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(Key, credentials, true);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
