﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace DocPrep
{
    [CodedUITest]
    public class DRUC0005 : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void DRUC0005_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1_01: Navigate to Doc Prep and Select All Phrase type and click on Select Phrase Group. Validate That Phrase Group screenis loaded.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Doc Prep Reports Phrase Groups by Phrase type screen.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsPGPT>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Phrase Groups by Phrase Type").WaitForScreenToLoad();

                Reports.TestStep = "User selects all phrase and generates report.";
                FastDriver.DocPrepReportsPGPT.SelectAll.FASetCheckbox(true);
                FastDriver.DocPrepReportsPGPT.GenerateReportPhraseGroup.FAClick();

                Reports.TestStep = "Validate Eagle logo appears and close";
                FastDriver.ListPhraseGroupsbyPhraseType.WaitForScreenToLoad(FastDriver.ListPhraseGroupsbyPhraseType.EagleLogo);
                Support.AreEqual(true, FastDriver.ListPhraseGroupsbyPhraseType.EagleLogo.IsVisible(), "EagleLogo IsVisible");
                FastDriver.WebDriver.Close();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DRUC0005_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1_02: Click Generate Reports button to generate reports and validate that eagle logo appears.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Doc Prep Reports Phrase Groups by Phrase type screen. ";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsPGPT>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Phrase Groups by Phrase Type").WaitForScreenToLoad();

                Reports.TestStep = "User selects all phrase and generates report.";
                FastDriver.DocPrepReportsPGPT.SelectPhraseType1.FASetCheckbox(true);
                FastDriver.DocPrepReportsPGPT.SelectPhraseType2.FASetCheckbox(true);
                FastDriver.DocPrepReportsPGPT.SelectPhraseType3.FASetCheckbox(true);
                FastDriver.DocPrepReportsPGPT.GenerateReportPhraseGroup.FAClick();

                Reports.TestStep = "Validate Eagle logo appears and close";
                FastDriver.ListPhraseGroupsbyPhraseType.WaitForScreenToLoad(FastDriver.ListPhraseGroupsbyPhraseType.EagleLogo);
                Support.AreEqual(true, FastDriver.ListPhraseGroupsbyPhraseType.EagleLogo.IsVisible(), "EagleLogo IsVisible");
                FastDriver.WebDriver.Close();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DRUC0005_BAT0003_04()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1_03_04: Navigate to Doc Prep and Select one Phrase type and click on Select Phrase Group. Validate That Phrase Group screen is loaded.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Doc Prep Reports Phrase Groups by Phrase type screen. ";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsPGPT>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Phrase Groups by Phrase Type").WaitForScreenToLoad();

                Reports.TestStep = "User selects particular phrase and Select Phrase group.";
                FastDriver.DocPrepReportsPGPT.SelectPhraseType1.FASetCheckbox(true);
                FastDriver.DocPrepReportsPGPT.SelectPhraseGroups.FAClick();

                Reports.TestStep = "Select a Phrase in a Phrase Group.";
                FastDriver.DocPrepReportsPGPT1.WaitForScreenToLoad(FastDriver.DocPrepReportsPGPT.SelectPhraseGroup1);
                FastDriver.DocPrepReportsPGPT1.SelectPhraseGroup1.FASetCheckbox(true);
                FastDriver.DocPrepReportsPGPT1.SelectPhraseGroup2.FASetCheckbox(true);
                FastDriver.DocPrepReportsPGPT1.GenerateReportPhraseGroup.FAClick();

                Reports.TestStep = "MF1_04: Validate Eagle logo appears and close";
                FastDriver.ListPhraseGroupsbyPhraseType.WaitForScreenToLoad(FastDriver.ListPhraseGroupsbyPhraseType.EagleLogo);
                Support.AreEqual(true, FastDriver.ListPhraseGroupsbyPhraseType.EagleLogo.IsVisible(), "EagleLogo IsVisible");
                FastDriver.WebDriver.Close();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        public void DRUC0005_REG0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP3727_DP3971_EWC_FD_HK: Navigate to Doc Prep and Select one PhraseGroups type and click on generate button.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create anew phrase.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                string phraseGroupName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroupName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("test");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Continue From Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("test");
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on generate report.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsPhraseGroupsbyPhraseType>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Phrase Groups by Phrase Type").WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.SelectAll.IsSelected(), "SelectAll IsSelected");
                Support.AreEqual(false, FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.SelectGroupDisplayPhraseText.IsEnabled(), "SelectGroupDisplayPhraseText IsEnabled");
                Support.AreEqual(false, FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.SelectTemplateGroupcheckBox1.IsSelected(), "SelectTemplateGroupcheckBox1 IsSelected");
                Support.AreEqual(false, FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.SelectTemplateGroupcheckBox2.IsSelected(), "SelectTemplateGroupcheckBox2 IsSelected");
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.GenerateReport.FAClick();

                Reports.TestStep = "Click on generate report without select any phrase group.";
                Support.AreEqual("Please select at least one Phrase Type", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "click on generate report.";
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.SelectAll.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.SelectTemplateGroupcheckBox1.IsSelected(), "SelectTemplateGroupcheckBox1 IsSelected");
                Support.AreEqual(true, FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.SelectTemplateGroupcheckBox2.IsSelected(), "SelectTemplateGroupcheckBox2 IsSelected");
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.GenerateReport.FAClick();

                Reports.TestStep = "Wait for screen load.";
                FastDriver.ListPhraseGroupsbyPhraseType.WaitForScreenToLoad(FastDriver.ListPhraseGroupsbyPhraseType.EagleLogo);
                FastDriver.WebDriver.Close();

                Reports.TestStep = "Select Phrase and click on Generate report button.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.SelectAll.FASetCheckbox(false);
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.DocPrepReportsPhraseGroupsbyPhraseTypeTable.PerformTableAction(2, "CONTFROM", 1, TableAction.On);
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.DocPrepReportsPhraseGroupsbyPhraseTypeTable.PerformTableAction(2, "ESCROW", 1, TableAction.On);
                FastDriver.DocPrepReportsPhraseGroupsbyPhraseType.GenerateReport.FAClick();

                Reports.TestStep = "Wait for screen load.";
                FastDriver.ListPhraseGroupsbyPhraseType.WaitForScreenToLoad(FastDriver.ListPhraseGroupsbyPhraseType.EagleLogo);
                FastDriver.WebDriver.Close();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        } 
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}