﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;


namespace DocPrep
{
    
    [CodedUITest]
    public class DRUC0002 : MasterTestClass
    {

        #region REG

        #region DRUC0002_REG0001
        [TestMethod]
        public void DRUC0002_REG0001()
        {
            try
            {

                Reports.TestDescription = "MF1: Login TO FAST Application ADM Side.Phrases by Template screen and selecting all template task group and click on Generate Report Button to check whether LOGO is Displaying.";
                
                Reports.TestStep = "Log into FAST ADM site.";
                LoginFastADMSite(AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Select template as all and click on Generate report button.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsPhrasesbyTemplate>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Template").WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhrasesbyTemplate.SelectAll.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.DocPrepReportsPhrasesbyTemplate.DocPrepReportsPhrasesbyTemplateTable.PerformTableAction(1, 1, TableAction.GetAttribute, "selected").Message.Clean());
                Support.AreEqual("true", FastDriver.DocPrepReportsPhrasesbyTemplate.DocPrepReportsPhrasesbyTemplateTable.PerformTableAction(2, 1, TableAction.GetAttribute, "selected").Message.Clean());
                FastDriver.DocPrepReportsPhrasesbyTemplate.SelectGroupDisplayPhraseText.FASetCheckbox(true);
                FastDriver.DocPrepReportsPhrasesbyTemplate.GenerateReport.FAClick();

                Reports.TestStep = "Verify for the image on list phrase by template screen.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Phrases by Template", true, 200);
                Support.AreEqual("True", FastDriver.ListPhrasesbyTemplate.EagleImage.IsDisplayed().ToString());
                FastDriver.WebDriver.Quit();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region DRUC0002_REG0002
        [TestMethod]
        public void DRUC0002_REG0002()
        {
            try
            {

                Reports.TestDescription = "AF1: Phrases by Template screen selecting one template task group and click on Generate Report Button to check whether LOGO is Displaying.";

                Reports.TestStep = "Log into FAST ADM site.";
                LoginFastADMSite(AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Select one template and click on Generate report button.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsPhrasesbyTemplate>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Template").WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhrasesbyTemplate.DocPrepReportsPhrasesbyTemplateTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DocPrepReportsPhrasesbyTemplate.GenerateReport.FAClick();

                Reports.TestStep = "Verify for the image on list phrase by template screen.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Phrases by Template", true, 200);
                Support.AreEqual("True", FastDriver.ListPhrasesbyTemplate.EagleImage.IsDisplayed().ToString());
                FastDriver.WebDriver.Quit();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region DRUC0002_REG0003
        [TestMethod]
        public void DRUC0002_REG0003()
        {
            try
            {

                Reports.TestDescription = "AF2: Phrases by Template screen selecting one template and click on Select Template Button and verifieng for the Correct LOGO.";

                Reports.TestStep = "Log into FAST ADM site.";
                LoginFastADMSite(AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Select one template and click on Select Template Button.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsPhrasesbyTemplate>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Template").WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhrasesbyTemplate.DocPrepReportsPhrasesbyTemplateTable.PerformTableAction(2, "ENDORSE", 1, TableAction.On);
                FastDriver.DocPrepReportsPhrasesbyTemplate.SelectTemplates.FAClick();

                Reports.TestStep = "Check the Display Phrase Text checkbox, select the first template, click Generate Report button";
                FastDriver.DocPrepReportsPhrasesbyTemplate1.WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhrasesbyTemplate1.SelectTemplateDisplayPhraseText.FASetCheckbox(true);
                FastDriver.DocPrepReportsPhrasesbyTemplate1.SelectTemplateTable.PerformTableAction(3, 1, TableAction.On);
                FastDriver.DocPrepReportsPhrasesbyTemplate1.GenerateReport.FAClick();

                Reports.TestStep = "Verify for the image on list phrase by template screen.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Phrases by Template", true, 200);
                Support.AreEqual("True", FastDriver.ListPhrasesbyTemplate.EagleImage.IsDisplayed().ToString());
                FastDriver.WebDriver.Quit();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region DRUC0002_REG0004
        [TestMethod]
        public void DRUC0002_REG0004()
        {
            try
            {

                Reports.TestDescription = "DP3640_DP3724_EWC_FD_HK: List Phrases by Template";

                Reports.TestStep = "Log into FAST ADM site.";
                LoginFastADMSite(AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Select all template and click Generate Report Button.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsPhrasesbyTemplate>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Phrases by Template").WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhrasesbyTemplate.SelectAll.FASetCheckbox(true);
                FastDriver.DocPrepReportsPhrasesbyTemplate.GenerateReport.FAClick();

                Reports.TestStep = "Verify for the image on list phrase by template screen.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Phrases by Template", true, 200);
                Support.AreEqual("True", FastDriver.ListPhrasesbyTemplate.EagleImage.IsDisplayed().ToString());
                FastDriver.WebDriver.Close();

                Reports.TestStep = "Click on generate report without select any phrase group.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 60);
                FastDriver.DocPrepReportsPhrasesbyTemplate.WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhrasesbyTemplate.SelectAll.FASetCheckbox(false);
                FastDriver.DocPrepReportsPhrasesbyTemplate.GenerateReport.FAClick();
                Support.AreEqual("Please select at least one Template Type", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true));

                Reports.TestStep = "Select one template and click on Select Template Button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 60);
                FastDriver.DocPrepReportsPhrasesbyTemplate.WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhrasesbyTemplate.DocPrepReportsPhrasesbyTemplateTable.PerformTableAction(2, "ENDORSE", 1, TableAction.On);
                FastDriver.DocPrepReportsPhrasesbyTemplate.GenerateReport.FAClick();

                Reports.TestStep = "Verify for the image on list phrase by template screen.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Phrases by Template", true, 200);
                Support.AreEqual("True", FastDriver.ListPhrasesbyTemplate.EagleImage.IsDisplayed().ToString());
                FastDriver.WebDriver.Quit();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region Private Methods

        private void LoginFastADMSite(string UserName = null, string Password = null)
        {

            var ADMSiteURL = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(ADMSiteURL, Credentials, true);
        }

        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
