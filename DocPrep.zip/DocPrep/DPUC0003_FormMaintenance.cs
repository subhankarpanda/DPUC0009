﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.Common;


namespace DocPrep
{
    [CodedUITest]
    public class DPUC0003 : MasterTestClass
    {
        #region DPUC0003_REG0001
        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0003_REG0001()
        {
            // This test case combines BAT0001, BAT0002, BAT0003, and BAT0004
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1: Add a New Form; AF3: Edit the Form; AF4_AF5: Undo Check Out and Delete the Form.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FormMaintenanceSummary>("Home>System Maintenance>Document Preparation>Form Maintenance").WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.New);
                FastDriver.FormMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Create a Form.";
                string formName = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");
                FastDriver.FormMaintenance.EnterFormMaintenanceData(formName, true, "Creating New Form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Newly created form.";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                Support.AreEqual(formName, FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.GetText).Message, "Form Description");

                Reports.TestStep = "Select the form and click Download";
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.Download.FAClick();
                Playback.Wait(2000);
                FastDriver.FormMaintenanceSummary.HandleOpenOrSave("Save");

                Reports.TestStep = "Select the form and click Edit/Upload";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.EditUpload.FAClick();

                Reports.TestStep = "Change form description, then click Done";
                formName = formName + "EDIT";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FormDesc.FASetText(formName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Edited form name";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                Support.AreEqual(formName, FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.GetText).Message, "Form Description");

                Reports.TestStep = "Select the form and click Undo Check Out";
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.UndoCheckOut.FAClick();
                Support.AreEqual("Are you sure you wish to undo the check out of " + formName + " ? This action cannot be undone", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean());

                Reports.TestStep = "Select the form and click Delete";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.Delete.FAClick();
                Support.AreEqual("Are you sure you wish to delete " + formName + " ? This action cannot be undone.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region DPUC0003_REG0002
        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0003_REG0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
                #endregion

                Reports.TestDescription = "DP8286  Access to downloaded/checked Out; DP8287  Replace checked out form";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FormMaintenanceSummary>("Home>System Maintenance>Document Preparation>Form Maintenance").WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.New);
                FastDriver.FormMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Create a Form.";
                string formName = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");
                FastDriver.FormMaintenance.EnterFormMaintenanceData(formName, true, "Creating New Form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the form and click Download";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.Download.FAClick();
                Playback.Wait(2000);
                FastDriver.FormMaintenanceSummary.HandleOpenOrSave("Save");

                Reports.TestStep = "Close FAST application";
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Login as different user";
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FormMaintenanceSummary>("Home>System Maintenance>Document Preparation>Form Maintenance").WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.New);
                
                Reports.TestStep = "Validate form state is checked out";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                Support.AreEqual("Checked Out -" + AutoConfig.UserNameSecondary.ToUpper(), FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 3, TableAction.GetText).Message.Clean(), "Form State");

                Reports.TestStep = "Click on the form to validate the warning message";
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                Support.AreEqual("Document checked out by " + AutoConfig.UserNameSecondary.ToUpper(), FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "Message from webpage");

                Reports.TestStep = "Create a Form.";
                formName = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.New.FAClick();
                FastDriver.FormMaintenance.EnterFormMaintenanceData(formName, true, "Creating New Form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the form and click Download";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.Download.FAClick();
                Playback.Wait(2000);
                FastDriver.FormMaintenanceSummary.HandleOpenOrSave("Save");

                Reports.TestStep = "Replace the checked out form";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.EditUpload.FAClick();
                FastDriver.FormMaintenance.EnterFormMaintenanceData(formName, true, "Replace old form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the new form name and state of form";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                Support.AreEqual(formName, FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.GetText).Message, "Form Description");
                Support.AreEqual(string.Empty, FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 3, TableAction.GetText).Message.Clean(), "Form State");

                Reports.TestStep = "Delete the form (cleanup)";
                DeleteForm(formName);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region DPUC0003_REG0003
        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0003_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8290  Form Maintenance Summary Order Display";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FormMaintenanceSummary>("Home>System Maintenance>Document Preparation>Form Maintenance").WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.New);
                FastDriver.FormMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Create first form";
                string formName1 = "00001" + Support.RandomString("AAAAAAAAAA");
                FastDriver.FormMaintenance.EnterFormMaintenanceData(formName1, true, "Creating First Form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create second form";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.New.FAClick();
                string formName2 = "00002" + Support.RandomString("AAAAAAAAAA");
                FastDriver.FormMaintenance.EnterFormMaintenanceData(formName2, true, "Creating Second Form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate forms display order on form summary table.";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                int form1Row = FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName1, 1, TableAction.GetCell).CurrentRow;
                int form2Row = FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName2, 1, TableAction.GetCell).CurrentRow;
                Support.AreEqual((form1Row + 1).ToString(), form2Row.ToString());

                Reports.TestStep = "Delete the forms (cleanup)";
                DeleteForm(formName1);
                DeleteForm(formName2);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region DPUC0003_REG0004
        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0003_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8292  Capture Revision History";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FormMaintenanceSummary>("Home>System Maintenance>Document Preparation>Form Maintenance").WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.New);
                FastDriver.FormMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Create a Form.";
                string formName = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");
                FastDriver.FormMaintenance.EnterFormMaintenanceData(formName, true, formName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Newly created form.";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                Support.AreEqual(formName, FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.GetText).Message, "Form Description");

                Reports.TestStep = "Select the form and click Download";
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.Download.FAClick();
                Playback.Wait(2000);
                FastDriver.FormMaintenanceSummary.HandleOpenOrSave("Save");

                Reports.TestStep = "Select the form and click Edit/Upload";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.EditUpload.FAClick();

                Reports.TestStep = "Validate the revision history table";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                Support.AreEqual("True", FastDriver.FormMaintenance.RevisedHistoryTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean().Contains(DateTime.Now.ToString("MM/dd/yyyy")).ToString(), true);
                Support.AreEqual(credentials.UserName.ToUpper(), FastDriver.FormMaintenance.RevisedHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("Created: " + formName, FastDriver.FormMaintenance.RevisedHistoryTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete the form (cleanup)";
                DeleteForm(formName);
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region DPUC0003_REG0005
        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0003_REG0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8293  Form Description Required; DP8294  Form Description Unique; DP8300  Special Characters; DP8298  File Location Required When Uploading A Form; DP8296  MS Word Files Only; DP8301  Form Name Is Not Case Sensitive";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FormMaintenanceSummary>("Home>System Maintenance>Document Preparation>Form Maintenance").WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.New);

                Reports.TestStep = "Get an exsting form description and save it for later use";
                string existingFormDescription = FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Create a form without form description";
                FastDriver.FormMaintenanceSummary.New.FAClick();
                string formName = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                var fileLoc = Reports.DEPLOYDIR + @"\" + formName + ".doc";
                fileLoc = fileLoc.ToUpper();
                var invalidFileLoc = Reports.DEPLOYDIR + @"\" + formName + ".docx";
                System.IO.File.Copy(Reports.DEPLOYDIR + @"\GeneralForm.doc", fileLoc, true);
                System.IO.File.Copy(Reports.DEPLOYDIR + @"\GeneralForm.doc", invalidFileLoc, true);

                Reports.TestStep = "Validate warning message when form description is not entered.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Please enter a Form Description.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "Empty form description");
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);

                Reports.TestStep = "Enter special chracters in form description and validate warning message.";
                FastDriver.FormMaintenance.FormDesc.FASetText(@"~'!@^_{}|\[]");
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , characters", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "Special characters");

                Reports.TestStep = "Enter a valid form description.";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FormDesc.FASetText(formName);

                Reports.TestStep = "Validate warning message when file location is empty.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Please select a file to upload.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "File location empty");

                Reports.TestStep = "Enter an existing form description and validate warning message";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FileLocation.FASetText(fileLoc, false);
                FastDriver.FormMaintenance.FormDesc.FASetText(existingFormDescription);
                FastDriver.BottomFrame.Done();
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                Support.AreEqual("The Form Description " + existingFormDescription + " is already in use, please choose another.", FastDriver.FormMaintenance.eMessage.FAGetText(), "Form description not unique");

                Reports.TestStep = "Enter an invalid file type (.docx) and validate warning message";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FileLocation.FASetText(invalidFileLoc, false);
                FastDriver.FormMaintenance.FormDesc.FASetText(formName);
                FastDriver.BottomFrame.Done();
                Support.AreEqual("The File " + formName + ".docx is not an MS Word Document. Please Correct.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "Invalid document type");

                Reports.TestStep = "Enter valid form description and file location";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FileLocation.FASetText(fileLoc, false);
                FastDriver.FormMaintenance.FormDesc.FASetText(formName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete the form (cleanup)";
                DeleteForm(formName);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Private Methods
        private void DeleteForm(string formName)
        {
            FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
            FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
            FastDriver.FormMaintenanceSummary.Delete.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}