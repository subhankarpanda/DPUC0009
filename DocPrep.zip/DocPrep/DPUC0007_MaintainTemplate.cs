﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Globalization;
using OpenQA.Selenium;
using System.Linq;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;



namespace DocPrep
{
    [CodedUITest]
    public class DPUC0007 : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void DPUC0007_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1: Add New Template.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                string templateName = "DP07BAT01" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE", searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Save created template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.WebDriver.FAFindElement(ByLocator.TagName, "body").SendKeys(FAKeys.PageUp);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction);
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF2: Search Template.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region Template Creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07BAT02" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE", searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateStatus);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem("Active");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.State.FASelectItem("CA");

                Reports.TestStep = "Verify template is found.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_BAT0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF1: Edit Template. AF2: Verify the Edited Template and Copy Template";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region need to create a template again to remove dependency with BAT01
                //need to create a template again to remove dependency with BAT01
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07BAT03" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE", searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                //need to create a template again to remove dependency with BAT01 
                #endregion

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateStatus);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem("Active");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.State.FASelectItem("CA");

                Reports.TestStep = "Select template and click edit.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Edit the template information.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationDescription);
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText("Template for " + templateName + " - Edited");
                FastDriver.TemplateMaintenanceInformation.InformationNotificationAttachmentCandidate.FASetCheckbox(true);
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText("Comments for Template - " + templateName + " - Edited");

                Reports.TestStep = "Edit the template formatting information.";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.75", marginBtm: "0.75");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "BAT0004_AF2: Verify the Edited Template and Copy Template";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateStatus);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName + " - Edited");

                Reports.TestStep = "Click on Find Now and select.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName + " - Edited", "Status", TableAction.Click);

                Reports.TestStep = "Click on Copy on Template Summary Screen,.";
                FastDriver.TemplateMaintenanceSummary.Copy.FAClick();
                string copiedTemplateName = Support.RandomString("AAA");
                FastDriver.TemplateMaintenanceSummary.CopyName.FASetText(copiedTemplateName);

                Reports.TestStep = "Click on Save Button on Template Summary Screen.";
                FastDriver.TemplateMaintenanceSummary.Save.FAClick();

                Reports.TestStep = "Verify for Copied Template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateStatus);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem("Both");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName + " - Edited");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                var copiedTemplateType = FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", copiedTemplateName, "Type", TableAction.GetText).Message;
                Support.AreEqual("Endorsement/Guarantee", copiedTemplateType, "Copied template type");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_BAT0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF3_AF4: Deactivate and Activating Template Status.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region need to create a template again to remove dependency with BAT01
                //need to create a template again to remove dependency with BAT01
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07BAT05" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE", searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                //need to create a template again to remove dependency with BAT01 
                #endregion

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateStatus);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem("Active");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.State.FASelectItem("CA");

                Reports.TestStep = "Select template and click edit.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Edit the template information.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationDescription);
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FASetCheckbox(false);
                FastDriver.TemplateMaintenanceInformation.InformationInactive.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Verify for the Status Inactive.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationRevisionHistory);
                Support.AreEqual("Inactive", FastDriver.TemplateMaintenanceInformation.InformationRevisionHistory.PerformTableAction(1, 3, TableAction.GetText).Message.Clean(), "Latest status");

                Reports.TestStep = "Activating the Status of Template.";
                FastDriver.TemplateMaintenanceInformation.InformationActive.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Verify for the Active status.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationRevisionHistory);
                Support.AreEqual("Active", FastDriver.TemplateMaintenanceInformation.InformationRevisionHistory.PerformTableAction(1, 3, TableAction.GetText).Message.Clean(), "Latest status");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0007_BAT0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF5_6: Enter Adhoc Phrase settings and Add Phrase.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FormMaintenanceSummary>("Home>System Maintenance>Document Preparation>Form Maintenance").WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.New);
                FastDriver.FormMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Create a random doc with random document";
                string formName = "DPUC0007FORM" + Support.RandomString("AAAAA");
                FastDriver.FormMaintenance.EnterFormMaintenanceData(formName, true, "Creating New Form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify form creation";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 2, TableAction.Click);

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "#" + Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, description: "Template Brief Info.", comments: "Information",
                    fontNameType: "Times New Roman", fontSize: "12", marginTop: "0.25", marginLeft: "0.9", marginRight: "0.8");

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation(description: "FirstPhraseInQQZQ", type: "Escrow Phrase", group: "CreatedForAutomationTesting[DERF]", name: @"DERF/PHR4");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5",
                    headerPhrase: "Header Ph1", footerPhrase: "Footer Phrase one", continueFrom: "test", continueOn: "Test Phrase");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company",
                    propertyType: "Single Family Residence", productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE",
                    searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FASetCheckbox(false);
                Support.AreEqual("Active", FastDriver.TemplateMaintenanceInformation.InformationRevisionHistory.PerformTableAction(1, 3, TableAction.GetText).Message.Clean(), "Latest status");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "STEPS FOR BAT0007 START HERE: AF7_8_9_10: Edit Phrase, Add/Edit Phrase Marker, Re-sequence Phrases/Phrase Markers and Delete Phrase Marker.";
                Reports.StatusUpdate("Will add/edit second phrase and change phrase sequence, then delete second phrase.", true);

                Reports.TestStep = "Click on Phrase marker Edit button.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesEdit);
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesEdit);
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Second Phrase.";
                FastDriver.PhraseSelectDlg.EnterPhraseInformation(description: "SecondPhraseInQQZQ", type: "Escrow Phrase", name: "TDS/TDS");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Move Phrase Down.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();

                Reports.TestStep = "Move Phrase UP.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesUp);
                FastDriver.TemplateMaintenancePhrase.PhrasesUp.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Delete Phrase.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesRemove);
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Adding Phrase Marker.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker);
                FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker.FAClick();

                Reports.TestStep = "Move Phrase UP.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesUp);
                FastDriver.TemplateMaintenancePhrase.PhrasesUp.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase marker Edit button.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesEdit);
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Add the random form";
                FastDriver.EditPhraseMarkerPropertiesDlg.EnterInformation(formName: formName, regionForms: true, pageBreak: true, autoOutlineRestart: true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.EditPhraseMarkerPropertiesDlg.WindowTitle, false, 15);

                Reports.TestStep = "Verify added Doc.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.DocumentAdded);
                FastDriver.TemplateMaintenancePhrase.DocumentAdded.FAClick();

                Reports.TestStep = "Move Phrase Down.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesDown);
                FastDriver.TemplateMaintenancePhrase.PhrasesDown.FAClick();

                Reports.TestStep = "Move Phrase Up.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesDown);
                FastDriver.TemplateMaintenancePhrase.PhrasesDown.FAClick();

                Reports.TestStep = "Delete Phrase.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesRemove);
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_BAT0008()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF11: Phrase Conditioning.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region need to create a template again to remove dependency with BAT01
                //need to create a template again to remove dependency with BAT01
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07BAT08" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                //need to create a template again to remove dependency with BAT01 
                #endregion

                Reports.TestStep = "Phrase Conditioning.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesConditions);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Add Phrase Condition.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad(FastDriver.PhraseConditionsDlg.Add);
                FastDriver.PhraseConditionsDlg.Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "ALBADD1", index: "1", _operator: "EQ", value: "Field");

                Reports.TestStep = "Click Done in Phrase Conditions dialog.";
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_BAT0009()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF12: Add Template Validation.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region need to create a template again to remove dependency with BAT01
                //need to create a template again to remove dependency with BAT01
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07BAT09" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                //need to create a template again to remove dependency with BAT01 
                #endregion

                Reports.TestStep = "Template Validation.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkValidation);
                FastDriver.TemplateMaintenanceInformation.linkValidation.FAClick();
                FastDriver.TemplateMaintenanceValidation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceValidation.ValidationSelect);
                FastDriver.TemplateMaintenanceValidation.ValidationSelect.FAClick();

                Reports.TestStep = "Select the state filter for Template.";
                FastDriver.StateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateFilterSelectionDlg.AddRemoveState.FAClick();

                Reports.TestStep = "Choose State Filter.";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Clear);
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.StateSelect.FASetCheckbox(true);

                Reports.TestStep = "Click on Select.";
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.StateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.StateSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_BAT0010()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF13_14_15: Add Template Filtering Criteria, Add Role Type/Business Party combination filter criteria, Edit Template Filter.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "#" + Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for DPUC0007", comments: "InformationComment");

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation(description: "Business Source Contact Info.", type: "Escrow Phrase", name: "7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5",
                    headerPhrase: "Header Ph1", footerPhrase: "Footer Phrase one", continueFrom: "test", continueOn: "Test Phrase");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE", searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Save created template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.WebDriver.FAFindElement(ByLocator.TagName, "body").SendKeys(FAKeys.PageUp);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction);
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Select the Filter on Filtering TAB.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.TemplateFilter);
                FastDriver.TemplateMaintenanceFiltering.TemplateFilter.PerformTableAction("Transaction", "Sale w/Mortgage", "Transaction", TableAction.Click);

                Reports.TestStep = "Click on Edit on Filtering TAB.";
                FastDriver.TemplateMaintenanceFiltering.FilteringEdit.FAClick();

                Reports.TestStep = "Edit the Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad(FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll);
                FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(programType: "PT_DO_NOT_DELETE");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        public void DPUC0007_REG0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8148_49_50_54_EWC2_ECW3_ECW18: Template creation.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter Template comments.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(comments: "InformationComment");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Template Name is required.";
                Support.AreEqual("Name is required. Please enter a Name", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Create template name with existing name.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(name: "FCTDTF");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Template Description is required.";
                Support.AreEqual("Template Description is required.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter Template Description and Comments.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(comments: "Information", description: "Template Brief Info.");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Template First Page Format is required.";
                Support.AreEqual("Template First Page Formatting is required", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Select First Page formatting.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.4", marginBtm: "0.3");
                FastDriver.TemplateMaintenanceFormating.FormattingHeaderPhrase.FASelectItemByIndex(1);
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItemByIndex(2);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItemByIndex(4);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItemByIndex(1);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Template Name already exists.";
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                Support.AreEqual("Error[Template]: Template Name already exists", FastDriver.TemplateMaintenanceInformation.ErrorMessage.FAGetText().Clean());

                Reports.TestStep = "Click on Information Tab.";
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();

                Reports.TestStep = "Enter auto generated template Name and template comments.";
                string templateName = "#" + Support.RandomString("AAAAZZ");
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(name: templateName, comments: "InformationComment", description: "Template Brief Info.");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8151_55_56_57_58_59_60_ECW4_ECW5_ECW6_ECW7_ECW8_TSSFD01_TSSHK01_TMFD02: Template creation with required fields and validations(spl chars & Margins).";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Template name should not contain spl characters.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(name: "temp~`!@^_");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "System shall not allow the use of special characters in Template Names.";
                Support.AreEqual("Name may only contain 0-9 a-z A-Z < > * % $ # : ; ' / + - = ( ) . , characters", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter auto generated template Name and invalid template description.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                string templateName = "#" + Support.RandomString("AAAAZZ");
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(name: templateName, description: "temp~`!@^_");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "System shall not allow the use of special characters in Template Description.";
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , & _ characters", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter Template Description.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(description: "Template Brief Info.");

                Reports.TestStep = "Template comments should not contain spl characters.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(comments: @"temp~`!@^_{ }|\[ ]");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "System shall not allow the use of special characters in Template Comments.";
                Support.AreEqual("Comments may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , & _ characters", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter Template comments.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(comments: @"InformationComment");

                Reports.TestStep = "Default Phrase Settings.";
                Support.AreEqual("Tahoma", FastDriver.TemplateMaintenanceInformation.InformationFontNameType.FAGetSelectedItem(), "InformationFontNameType");
                Support.AreEqual("10", FastDriver.TemplateMaintenanceInformation.InformationFontSize.FAGetSelectedItem(), "InformationFontSize");
                Support.AreEqual("0.21", FastDriver.TemplateMaintenanceInformation.InformationMarginTop.FAGetValue(), "InformationMarginTop");
                Support.AreEqual("0.7", FastDriver.TemplateMaintenanceInformation.InformationMarginLeft.FAGetValue(), "InformationMarginLeft");
                Support.AreEqual("0.8", FastDriver.TemplateMaintenanceInformation.InformationMarginRight.FAGetValue(), "InformationMarginRight");

                Reports.TestStep = "Incorrect margin values.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(fontNameType: "Tahoma", fontSize: "14", marginTop: "7.5", marginLeft: "8.5", marginRight: "8.3");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Incorrect Top Margin value.";
                Support.AreEqual("Incorrect Top Margin value. Valid Values are decimals between 0.00 and 7.00", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Create template with misc. phrase settings.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(fontNameType: "Times New Roman", fontSize: "12", marginTop: "0.25");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Incorrect Left Margin value.";
                Support.AreEqual("Incorrect Left Margin value. Valid Values are decimals between 0.00 and 7.00", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Create template left margin.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(marginTop: "0.25", marginLeft: "0.9");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Incorrect Right Margin value.";
                Support.AreEqual("Incorrect Right Margin value. Valid Values are decimals between 0.00 and 7.00", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Create template Right margin.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(marginRight: "0.8");

                Reports.TestStep = "Select First Page formatting only.";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickFirstPage: true);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8152_53_54_10942_TSS_FD: Template requires template type& Read only editable.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateType);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "JVR Description", "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Edit template type in Template Information.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.TemplateType);
                Support.AreEqual("True", FastDriver.TemplateMaintenanceInformation.TemplateType.IsEnabled().ToString(), "TemplateType IsEnabled");
                Support.AreEqual("True", FastDriver.TemplateMaintenanceInformation.InformationComments.IsEnabled().ToString(), "InformationComments IsEnabled");

                Reports.TestStep = "Navigate to Template maintenance screen & Select Title Report type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateType);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Title Reports");

                Reports.TestStep = "Click on Find Now and Select to Edit for created Title Reports type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for Testing Phrase Conditions", "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Template name Title Reports.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.TemplateNamePane);
                Support.AreEqual("Title Reports", FastDriver.TemplateMaintenanceInformation.TemplateNamePane.FAGetText().Clean(), "TemplateNamePane");

                Reports.TestStep = "Navigate to Template maintenance screen & select Lender Policy type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateType);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Lender Policy");

                Reports.TestStep = "Click on Find Now and Select to Edit for created Lender Policy type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Regression purpose", "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Template name Lender Policy type.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.TemplateNamePane);
                Support.AreEqual("Lender Policy", FastDriver.TemplateMaintenanceInformation.TemplateNamePane.FAGetText().Clean(), "TemplateNamePane");

                Reports.TestStep = "Navigate to Template maintenance screen & Select Owner Policy type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateType);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Owner Policy");

                Reports.TestStep = "Click on Find Now and Select to Edit for created Owner Policy type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Regression purpose", "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Template name Owner Policy type.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.TemplateNamePane);
                Support.AreEqual("Owner Policy", FastDriver.TemplateMaintenanceInformation.TemplateNamePane.FAGetText().Clean(), "TemplateNamePane");

                Reports.TestStep = "Navigate to Template maintenance screen & Select Policy w/o Title Reports type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateType);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Policy w/o Title Reports");

                Reports.TestStep = "Click on Find Now and Select to Edit for created Policy w/o Title Reports type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "1377 Document Security Filters", "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Read Only Template name Policy w/o Title Reports type.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.TemplateNamePane);
                Support.AreEqual("Policy w/o Title Reports", FastDriver.TemplateMaintenanceInformation.TemplateNamePane.FAGetText().Clean(), "TemplateNamePane");

                Reports.TestStep = "Navigate to Template maintenance screen & Select ALL type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateType);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("All");

                Reports.TestStep = "Check New button disabled.";
                Support.AreEqual("False", FastDriver.TemplateMaintenanceSummary.New.IsEnabled().ToString(), "New IsEnabled");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_REG0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8161_62_63_64_EWC9_EWC10_TMHK02_TMFD02: Template ID, Under construction, storing dates and User Id.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on New button Hot key.";
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter auto generated template Name and Template Description.";
                string templateName = "#" + Support.RandomString("AAAAZZ");
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(name: templateName, description: "Template Brief Info.");

                Reports.TestStep = "Template Under construction while Create new template.";
                Support.AreEqual("True", FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.IsSelected().ToString(), "InformationUnderConstruction IsSelected");

                Reports.TestStep = "Select First Page formatting.";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickFirstPage: true, clickMiddlePages: true, marginTop: "0.4", marginBtm: "0.3");
                FastDriver.TemplateMaintenanceFormating.FormattingHeaderPhrase.FASelectItemByIndex(1);
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItemByIndex(2);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItemByIndex(4);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItemByIndex(1);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Deactivating the Template and Verify for the Inactive status.";
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(underConstruction: false, inactive: true);

                Reports.TestStep = "When Template is inactive, under construction will be deactivated.";
                Support.AreEqual("False", FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.IsEnabled().ToString(), "InformationUnderConstruction IsEnabled");

                Reports.TestStep = "Click on View button.";
                FastDriver.TemplateMaintenanceInformation.InformationView.FAClick();

                Reports.TestStep = "A template must be Under Construction to be previewed.";
                Support.AreEqual("A template must be Under Construction to be previewed.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Activating the Status of Template.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(active: true);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "When Template is active, under construction will be activated.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction);
                Support.AreEqual("True", FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.IsEnabled().ToString(), "InformationUnderConstruction IsEnabled");

                Reports.TestStep = "Select under construction and enter comments.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(underConstruction: true, comments: "comment");

                Reports.TestStep = "Click on View button.";
                FastDriver.TemplateMaintenanceInformation.InformationView.FAClick();

                Reports.TestStep = "Please save your changes to this Template prior to Preview.";
                Support.AreEqual("Please save your changes to this Template prior to Previewing.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Template ID will be assigned once the template has been saved.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.TemplateID);
                Support.AreNotEqual("0", FastDriver.TemplateMaintenanceInformation.TemplateID.FAGetText().Clean(), "TemplateID");
                Support.AreNotEqual("", FastDriver.TemplateMaintenanceInformation.TemplateID.FAGetText().Clean(), "TemplateID");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_REG0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("STARTLEN"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "DP8165_66: Preview of doc with and with out Template Highlight Signatures.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Create a file.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Regression purpose", "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Under Construction checkbox and select the Test File Region.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(underConstruction: true);
                FastDriver.TemplateMaintenanceInformation.InformationSelectTestFileRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Checking the box Signature Highlight Allowed.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(signatureHighlightAllowed: true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Enter Office file view.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationViewText);
                FastDriver.TemplateMaintenanceInformation.InformationTestFileName.FASetText(fileNumber);
                FastDriver.TemplateMaintenanceInformation.InformationView.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                FastDriver.WebDriver.ClosePreviewWindow();

                Reports.TestStep = "Uncheck the box Signature Highlight Allowed.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(signatureHighlightAllowed: false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_REG0007()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8168_186_EWC12: Phrase editor overrides template.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG07" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Description);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on the phrase and checking Required check box.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", "7HPG/7HP1", "Required", TableAction.Off);

                Reports.TestStep = "Click on the phrase and checking Required check box.";
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", "7HPG/7HP1", "Required", TableAction.On);

                Reports.TestStep = "Click on Phrases Tab & Click on Edit button to edit phrase.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesEdit);
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "You have made changes to this template.";
                Support.AreEqual("You have made changes to this template. You must save your changes before you can edit this Phrase", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrases Tab & Click on Edit button to edit phrase.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesEdit);
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Select text.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.Highlight, "7HP1 - Creation of phrase for UC 7 H");
                Keyboard.SendKeys("^a");

                Reports.TestStep = "Highlighting text.";
                FastDriver.PhraseEditorDlg.Highlight.FAClick();

                Reports.TestStep = "Click Done in dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Would you like to save your changes?.";
                Support.AreEqual("Would you like to save your changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Description);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on the phrase and checking Required check box.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", "7HPG/7HP1", "Required", TableAction.On);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_REG0008()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8170_71_72_73_74: Validating date as server date and activating and deactivating a template with status comments updated with Revision history.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG08" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Validate Unable to enter status change comments until status change.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.StatusChangeComments);
                Support.AreEqual("False", FastDriver.TemplateMaintenanceInformation.StatusChangeComments.IsEnabled().ToString(), "StatusChangeComments IsEnabled");

                Reports.TestStep = "Deactivate Temp and Inactive status with status change comments.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(underConstruction: false, inactive: true, notificationAttachmentCandidate: true, statusChangeComments: "#");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Reactivating the Status of Template with status change comments.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationNotificationAttachmentCandidate);
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(active: true, notificationAttachmentCandidate: false, statusChangeComments: "#");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "REG0009: DP8173_170: Validate current date appears.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.RevisionHistoryRevisedDate);
                Support.AreEqual(DateTime.Now.ToPST().ToDateString(slash: true, trim: true), FastDriver.TemplateMaintenanceInformation.RevisionHistoryRevisedDate.FAGetText().Clean(), "RevisionHistoryRevisedDate");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_REG0010()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8175_76_77_78_79_EWC1: Searching and copying template with unique name.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                string templateName = "DP07REG10" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Copy button to copy template.";
                FastDriver.TemplateMaintenanceSummary.Copy.FAClick();

                Reports.TestStep = "Click on Save Button on Template Summary Screen.";
                FastDriver.TemplateMaintenanceSummary.Save.FAClick();

                Reports.TestStep = "Template Name already exists in Template Maintenance.";
                Support.AreEqual("Template Name \"" + templateName + "\" already exists. Please enter a new Name.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Search for filter details like description & Both status.";
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateStatus);
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem("Both");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("temp*");

                Reports.TestStep = "Click on Find Now button and select the record with name starting with temp.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_REG0011()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8180_81_82_83_84_85_87_88_92_205_EWC11_TMFD03_HK03_FD04_HK04: Inserting & deleting Phrases in Templates.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", "DPUC00726L", "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Phrases Tab & Click on Add button.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesAdd);
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter Invalid Phrase name.";
                FastDriver.PhraseSelectDlg.EnterPhraseInformation(name: "ABC/abc");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "ABC/abc is not a valid phrase, please correct.";
                Support.AreEqual("ABC/abc is not a valid phrase, please correct.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Enter multiple phrases.";
                FastDriver.PhraseSelectDlg.EnterPhraseInformation(name: "JVE/JV01,JVE/JV01,GOAL/PHR1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Verify that selected phrase added to phrases table.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", "JVE/JV01", "Required", TableAction.Click);

                Reports.TestStep = "Verify that selected phrase added to phrases table.";
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", "GOAL/PHR1", "Required", TableAction.Click);

                Reports.TestStep = "Click on Phrases Tab & Click on Add button.";
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Select Phrase type & Phrase group.";
                FastDriver.PhraseSelectDlg.EnterPhraseInformation(name: "OGFG/PSXO", type: "Escrow Phrase", group: "Created for REB[OGFG]");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Verify that selected phrase added to phrases table.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", "OGFG/PSXO", "Required", TableAction.Click);

                Reports.TestStep = "Click on down button for the selected phrase.";
                FastDriver.TemplateMaintenancePhrase.PhrasesDown.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesRequired.FASetCheckbox(true);

                Reports.TestStep = "Click on Up button for the selected phrase.";
                FastDriver.TemplateMaintenancePhrase.PhrasesUp.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesRequired.FASetCheckbox(true);

                Reports.TestStep = "Click on delete button for the selected phrase.";
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_REG0012()
        {
            try
            {
                Reports.TestDescription = "US773331_TC827106 - Verify ATP - Tax Research Form exists in Document Attachment list from Task Templates/Notification Setup screen";

                #region data setup
                string taskName = Support.RandomString("AAZZ");
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                Reports.TestDescription = "Verify ATP - Tax Research Form  exists in Document Attachment list from Task Templates/Notification Setup screen";
                Reports.TestStep = "Log into ADM FAST application and navigate to DOCPREP Corporate Region";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("196"); //AutoConfig.SelectedRegionBUID

                Reports.TestStep = "Navigate to Template Maintenance";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Title Reports");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Select ATP - Tax Research Form template";
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "ATP - Tax Research Form", 1, TableAction.Click);
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Select Notification Attachment Candidate option";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.InformationNotificationAttachmentCandidate.FASetCheckbox(true);

                Reports.TestStep = "Click on Save and Done";
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("1486"); //AutoConfig.SelectedRegionBUID

                Reports.TestStep = "Create task TaskName1.";
                FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Home>System Maintenance>Process Setup>Task Templates").WaitForScreenToLoad();
                FastDriver.TaskTemplateSelection.SwitchToContentFrame();

                FastDriver.TaskTemplateSelection.Categories.PerformTableAction(2, "Title", 3, TableAction.Click);
                Playback.Wait(2000);

                FastDriver.TaskTemplateSelection.New.FAClick();
                int lastRow = FastDriver.TaskTemplateSelection.TasksForTable.FindElements(By.CssSelector("tr")).Count() - 1;
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(lastRow, 3, TableAction.SetText, taskName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Select the newly created Task.";
                FastDriver.TaskTemplateSelection.SwitchToContentFrame();
                Playback.Wait(2000);

                FastDriver.TaskTemplateSelection.Categories.PerformTableAction(2, "Title", 3, TableAction.Click);
                Playback.Wait(1000);

                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(3, taskName, 3, TableAction.Click);
                Playback.Wait(1000);
                FastDriver.TaskTemplateSelection.Notification.FAClick();
                FastDriver.NotificationSummary.SwitchToContentFrame();
                FastDriver.NotificationSetup.TaskStatus.FASelectItem("Activated");
                FastDriver.NotificationSetup.DeliveryMethod.FASelectItem("Email");

                Reports.TestStep = "Click on File Roles.";
                FastDriver.NotificationSetup.FileRoles.FAClick();

                FastDriver.SelectFBPRolesDlg.SwitchToDialogContentFrame();
                Playback.Wait(3000);
                FastDriver.SelectFBPRolesDlg.Table.PerformTableAction(2, "Invoice To Party", 1, TableAction.Click);
                Playback.Wait(1000);

                FastDriver.SelectFBPRolesDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NotificationSetup.SwitchToContentFrame();

                Reports.TestStep = "Enter data element";
                FastDriver.NotificationSetup.SubjectLine.FASetText("^BSNAM1^");

                Reports.TestStep = "Select Designed Sender.";
                FastDriver.NotificationSetup.AvailabeSender.FASelectItem("Designated Sender");

                Reports.TestStep = "Click on right direction.";
                FastDriver.NotificationSetup.RightDirectionArrow.FAClick();

                Reports.TestStep = "Enter Name for designated sender.";
                FastDriver.NotificationSetup.DesignatedSenderName.FASetText("Designated sender name");

                Reports.TestStep = "Enter Email address designated sender.";
                FastDriver.NotificationSetup.DesignatedSenderEmailAddress.FASetText("designated@firstam.com");

                Reports.TestStep = "Click on Add/Remove document.";
                FastDriver.NotificationSetup.DocumentsAddRemove.FAClick();

                Reports.TestStep = "Select a Document.";
                FastDriver.DocumentSelectionDlg.WaitForScreenLoad();

                FastDriver.DocumentSelectionDlg.Source.FASelectItem("DOCPREP Corporate Region");
                Playback.Wait(1000);

                FastDriver.DocumentSelectionDlg.TemplateType.FASelectItem("Title Reports");
                FastDriver.DocumentSelectionDlg.FindNow.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Verify ATP - Tax Search Form exists and can be selected";
                FastDriver.DocumentSelectionDlg.DocumnentSearchTable.PerformTableAction(2, "ATP - Tax Research Form", 1, TableAction.Click);
                FastDriver.DocumentSelectionDlg.Add.FAClick();
                Playback.Wait(1000);
                FastDriver.DocumentSelectionDlg.DocumentSelectionTable.PerformTableAction(2, "ATP - Tax Research Form", 1, TableAction.Click);
                FastDriver.DocumentSelectionDlg.Select.FAClick();

                Reports.TestStep = "Validate that the document is attached";
                FastDriver.NotificationSetup.SwitchToContentFrame();
                Playback.Wait(1000);
                string value = FastDriver.NotificationSetup.DocumentsTable.GetRowCount().ToString();
                Support.AreEqual("2", value);

                Reports.TestStep = "Click on Message Template Select.";
                FastDriver.NotificationSetup.Select.FAClick();

                Reports.TestStep = "Select the message template.";
                FastDriver.MessageTemplateSelectionDlg.SwitchToDialogContentFrame();
                FastDriver.MessageTemplateSelectionDlg.FindNow.FAClick();
                FastDriver.MessageTemplateSelectionDlg.SearchResults.PerformTableAction(1, "PROMSG1", 1, TableAction.Click);
                Playback.Wait(1000);
                FastDriver.MessageTemplateSelectionDlg.Select.FAClick();

                FastDriver.NotificationSetup.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.NotificationSetup.TaskStatus.FAGetSelectedItem().Contains("Activated").ToString());

                Support.AreEqual("True", FastDriver.NotificationSetup.DeliveryMethod.FAGetSelectedItem().Contains("Email").ToString());

                Support.AreEqual("True", FastDriver.NotificationSetup.MessageTemplate.FAGetValue().Contains("CreatedForProActiveEnhTest").ToString());

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();
                FastDriver.BottomFrame.btnDone.FAClick();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }


        [TestMethod]
        public void DPUC0007_REG0013()
        {
            try
            {
                Reports.TestDescription = "US795535_TC856084: Verify Manufactured Home value exists in Property Type dropdown on Document Preparation/Template Maintenance/Filter screen";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region ADM 
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Home Regions";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Select a region";
                FastDriver.SecuritySelectRegionOffice.RegionsTable.PerformTableAction("BUID", "1486", "BUID", TableAction.Click);
                FastDriver.BottomFrame.Done();
                FastDriver.HomePage.WaitForHomeScreen();

                #region Create Template
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "US795535-" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateFilterSelectionDlg.Title.FAClick();
                FastDriver.TemplateFilterSelectionDlg.Escrow.FAClick();
                FastDriver.TemplateFilterSelectionDlg.SubEscrow.FAClick();
                FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.TrassactionTypeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.ProgrammeTypeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.SearchTypeSelectAll.FAClick();

                Reports.TestStep = "verify Manufactured Home is in Property Type Dropdown, Select it";
                if (FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.Selected)
                    FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.PropertyType.FASelectItem("Manufactured Home");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateStatus);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem("Active");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.State.FASelectItem("CA");

                Reports.TestStep = "Verify template is found.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);
                #endregion Create Template
                #endregion ADM

                #region IIS
                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Create File
                Reports.TestStep = "Create a FAST file via Home | Order Entry | Quick File Entry";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Order Entry>Quick File Entry").ClickSkipSearchButton();
                FastDriver.QuickFileEntry.SwitchToContentFrame();

                Reports.TestStep = "Enter a GAB and Required info in the Service area";
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                Reports.TestStep = "verify Manufactured Home is in Property Type Dropdown, Select it";
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Manufactured Home");

                Reports.TestStep = "Set up property tax info and address";
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("1");
                FastDriver.QuickFileEntry.PropertyPropTaxYear1.FASetText("2011");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("123 Testing Ave");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92630");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");

                Reports.TestStep = "Click Done to create file";
                FastDriver.BottomFrame.Done();
                #endregion Create File

                Reports.TestStep = "Navigate to Document Repository > Filtered Templates";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();

                Reports.TestStep = "Verify Filtered Template w/ Manufactured Home Property Type is visible";
                FastDriver.DocumentRepository.SearchDocument("Both", "All Available Templates", "Template for " + templateName);
                Support.AreEqual("1", FastDriver.DocumentRepository.SearchResultsTable.GetRowCount().ToString());
                if (FastDriver.DocumentRepository.SearchResultsTable.GetRowCount() == 1)
                    Support.AreEqual(true, FastDriver.DocumentRepository.SearchResultsTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().Contains("Template for " + templateName), "Manufactured Home filtered Template in Search Results Table");

                Reports.TestStep = "Chnage property type of created file to something other than Manufactured Home";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertyName1.FAClick();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Single Family Residence");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Document Repository > Filtered Templates";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();

                Reports.TestStep = "Verify Filtered Template w/ Manufactured Home Property Type is not visible with new property type";
                FastDriver.DocumentRepository.SearchDocument("Both", "All Available Templates", "Template for " + templateName);
                Support.AreEqual("0", FastDriver.DocumentRepository.SearchResultsTable.GetRowCount().ToString());
                #endregion
            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }


        [TestMethod]
        public void DPUC0007_DREG0012()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P8194_95_96_97_98_99_200_1_2_3_4_ECW13_TMPC05_FD05_TMPCFD05: Adding phrase and manipulating phrase conditions.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                string templateName = "DP7REG12" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Phrases Tab & Click on Add button.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesAdd);
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Select Phrase type & Phrase group.";
                FastDriver.PhraseSelectDlg.EnterPhraseInformation(name: "OGFG/PSXO", type: "Escrow Phrase", group: "Created for REB[OGFG]");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Phrase conditions.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesConditions);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Add Invalid data element.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "1A2B3C4");
                FastDriver.PhraseConditionsDlg.Done.FAClick();

                Reports.TestStep = "Phrase conditions data element not found.";
                Support.AreEqual("Data Element not found, please reenter.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Add Phrase Condition Buyer and operator as EB.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(2, dataElement: "BUFNAM", index: "1", _operator: "EB");
                Support.AreEqual("False", FastDriver.PhraseConditionsDlg.DataElmts1Value.IsEnabled().ToString(), "DataElmts1Value IsEnabled");
                FastDriver.PhraseConditionsDlg.Done.FAClick();

                Reports.TestStep = "Field is required.";
                Support.AreEqual("Field is required.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Enter Operator as NB and Verify the value.";
                FastDriver.PhraseConditionsDlg.EnterCondition(1, value: "value");
                FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "PI1CTY", _operator: "NB");

                Reports.TestStep = "Verify a value is not required if the selected operator is NB (not equal to blank).";
                Support.AreEqual("False", FastDriver.PhraseConditionsDlg.Value.IsEnabled().ToString(), "Value IsEnabled");

                Reports.TestStep = "Verify the conditions and Operator values.";
                Support.AreEqual("True", FastDriver.PhraseConditionsDlg.Operator.FAGetDropdownOptions().ToListString().Contains("NB").ToString(), "NB listed in Operator options");

                Reports.TestStep = "Add value field more than 35 characters.";
                FastDriver.PhraseConditionsDlg.EnterCondition(1, _operator: "EQ", value: "dsadhkiasjdklasjdlksjdflkjfkldjfdfuxczxczxcxzcxzczczczczczcz");

                Reports.TestStep = "Verify City (PI1CTY) data element is selected the Value should allow up to 30 chars.";
                Support.AreEqual("dsadhkiasjdklasjdlksjdflkjfkldjfdfuxczxczxcxzcxzczczczczczcz", FastDriver.PhraseConditionsDlg.Value.FAGetValue().Clean(), "Value");

                Reports.TestStep = "Click on Done button.";
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Phrase conditions.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesConditions);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Add Phrase Condition.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(3, dataElement: "ALBADD1", index: "1", _operator: "EQ", value: "Field");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0013()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P8200_01_02_03: A value is required if a data element.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                string templateName = "DP7REG13" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Phrases Tab & Click on Add button.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesAdd);
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Select Phrase type & Phrase group.";
                FastDriver.PhraseSelectDlg.EnterPhraseInformation(name: "OGFG/PSXO", type: "Escrow Phrase", group: "Created for REB[OGFG]");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Phrase conditions.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesConditions);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Enter PI1TXYR data element Operator as EB and Verify the value.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "PI1TXYR", index: "1", _operator: "EQ", value: "abc");
                FastDriver.PhraseConditionsDlg.Done.FAClick();

                Reports.TestStep = "Field is required.";
                Support.AreEqual("Field is required.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "PI1TXYR data element accepts only numeric value.";
                FastDriver.PhraseConditionsDlg.EnterCondition(1, value: "123");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Select the added Phrase.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhraseTable);
                FastDriver.TemplateMaintenancePhrase.PhraseTable.PerformTableAction(1, "OGFG/PSXO", 1, TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Enter PI1CNT data element Verify the value should accept 35chrs.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(2, dataElement: "PI1CNT", index: "1", _operator: "EQ", value: "fieldvalidationacceptsonly35charactersbutisacceptingmore");

                Reports.TestStep = "Validate value field accepting 35chrs only.";
                Support.AreEqual("fieldvalidationacceptsonly35charactersbutisacceptingmore", FastDriver.PhraseConditionsDlg.DataElmts1Value.FAGetValue().Clean(), "DataElmts1Value");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Select the added Phrase.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhraseTable);
                FastDriver.TemplateMaintenancePhrase.PhraseTable.PerformTableAction(1, "OGFG/PSXO", 1, TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Add Phrase Condition.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(3, dataElement: "ALBADD1", index: "1", _operator: "EQ", value: "Field");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0014()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P8191: Phrase Marker Properties.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07REG14" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Adding Phrase Marker.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker);
                FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker.FAClick();

                Reports.TestStep = "Click on Phrases Tab & Click on Edit button to edit phrase.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction(2, "PhraseMarker", 2, TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                //this won't show up because the template is new
                //Reports.TestStep = "You have made changes to this template."; 
                //Support.AreEqual("You have made changes to this template. You must save your changes before you can edit this Phrase", FastDriver.WebDriver.HandleDialogMessage().Clean());

                //Reports.TestStep = "Save created template.";
                //FastDriver.BottomFrame.Save();

                //Reports.TestStep = "Click on Phrases Tab & Click on Edit button to edit phrase.";
                //FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                //FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction(2, "PhraseMarker", 2, TableAction.Click);
                //FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Load Doc prep region forms.";
                FastDriver.EditPhraseMarkerPropertiesDlg.WaitForScreenToLoad(FastDriver.EditPhraseMarkerPropertiesDlg.LoadDocPrepRegionForms);
                FastDriver.EditPhraseMarkerPropertiesDlg.LoadDocPrepRegionForms.FASetCheckbox(true);
                Playback.Wait(2000);

                Reports.TestStep = "Edit the Phrase Marker with all the properties.";
                FastDriver.EditPhraseMarkerPropertiesDlg.EnterInformation(formName: "(FA) ALTA Res LC JLP-Hdr SchA-KS (09)", pageBreak: true, autoOutlineRestart: true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.EditPhraseMarkerPropertiesDlg.WindowTitle, false, 15);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0015()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P8189_92_93_94_98_207_ECW14_ECW15_ECW16_TMHK02: Creating required phrases with conditions in ADM.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07REG14" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now button and Select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Phrases Tab & Click on Add button.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesAdd);
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Select Phrase type & Phrase group.";
                FastDriver.PhraseSelectDlg.EnterPhraseInformation(type: "Escrow Phrase", group: "Created for REB[OGFG]", name: "OGFG/PSXO");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Checking the required checkbox.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesRequired);
                FastDriver.TemplateMaintenancePhrase.PhrasesRequired.FASetCheckbox(true);

                Reports.TestStep = "Click on Phrase conditions.";
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Add Phrase Condition.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "ALBADD1", index: "1", _operator: "EQ", value: "Field");

                Reports.TestStep = "Click Done.";
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Phrase conditions.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesConditions);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Add Phrase Condition Buyer1.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(2, dataElement: "BUFNAM", index: "1", value: "Buyer1Firstname");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Phrase conditions.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesConditions);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Add Phrase Condition Buyer2 missing Index.";
                FastDriver.PhraseConditionsDlg.EnterCondition(2, dataElement: "BUFNAM", index: "", _operator: "EQ", value: "Buyer1Firstname");
                FastDriver.PhraseConditionsDlg.EnterCondition(1, value: "Field");
                FastDriver.PhraseConditionsDlg.Done.FAClick();

                Reports.TestStep = "Index is required for this Data Element.";
                Support.AreEqual("Index is required for this Data Element.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Add Index to Phrase Condition Buyer2.";
                FastDriver.PhraseConditionsDlg.EnterCondition(2, index: "1");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Adding Phrase Marker.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker);
                FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker.FAClick();

                Reports.TestStep = "Click the phrase marker & checking Required and Click on phrase cond.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Description", "PhraseMarker", "Required", TableAction.On);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions1.FAClick();

                Reports.TestStep = "Add Phrase Condition.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "BUFNAM", index: "1", _operator: "EQ");
                FastDriver.PhraseConditionsDlg.Done.FAClick();

                Reports.TestStep = "Field is required.";
                Support.AreEqual("Field is required.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Add Phrase Condition with value.";
                FastDriver.PhraseConditionsDlg.EnterCondition(1, value: "Buyer1Firstname");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Phrase conditions.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesConditions);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Add Phrase Condition Buyer2 missing element.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(3, value: "Buyer2Firstname", index: "1", _operator: "EQ");
                FastDriver.PhraseConditionsDlg.Done.FAClick();

                Reports.TestStep = "Data Element required for operator and value.";
                Support.AreEqual("Data Element required for operator and value.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Remove a phrase.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Remove.FAClick();
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Save button in Phrases Tab.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify Inserted Phrases(rowcount).";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                Support.AreEqual("3", FastDriver.TemplateMaintenancePhrase.PhrasesTable.GetRowCount().ToString());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Add on Filtering TAB.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();

                Reports.TestStep = "Select Geographic Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad(FastDriver.TemplateFilterSelectionDlg.Select);
                FastDriver.TemplateFilterSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on AddRemove button for State selection.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveState);
                FastDriver.GeograficFilterSelectionDlg.AddRemoveState.FAClick();

                Reports.TestStep = "Add a new state.";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Clear);
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.grdState8SelState.FASetCheckbox(true);
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on AddRemove button for County selection.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveCounty);
                FastDriver.GeograficFilterSelectionDlg.AddRemoveCounty.FAClick();

                Reports.TestStep = "Add a new county.";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Clear);
                FastDriver.CountySelectionDlg.Clear.FAClick();
                FastDriver.CountySelectionDlg.grdCounty0SelCounty.FASetCheckbox(true);
                FastDriver.CountySelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on AddRemove button for City selection.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveCounty);
                FastDriver.GeograficFilterSelectionDlg.AddRemoveCity.FAClick();

                Reports.TestStep = "Add a new city.";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Clear, citySelection: true);
                FastDriver.CountySelectionDlg.Clear.FAClick();
                FastDriver.CountySelectionDlg.grdCounty1SelCounty.FASetCheckbox(true);
                FastDriver.CountySelectionDlg.Select.FAClick();
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveCounty);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.GeograficFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Select the Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE", searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Save button in Filtering Tab.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done button in Filtering Tab.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0016()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P9331: Identify Template as a Notification Attachment Candidate.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Select the existing task.";
                FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Home>System Maintenance>Process Setup>Task Templates").WaitForScreenToLoad();
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(3, "AUTO_ProActiveTask_DONOTTOUCH_Task1", 3, TableAction.Click);
                FastDriver.TaskTemplateSelection.Notification.FAClick();

                Reports.TestStep = "Click on edit button.";
                FastDriver.NotificationSummary.WaitForScreenToLoad(FastDriver.NotificationSummary.Edit);
                FastDriver.NotificationSummary.Edit.FAClick();

                Reports.TestStep = "Verify the Notification Message Template Selected.";
                FastDriver.NotificationSetup.WaitForScreenToLoad(FastDriver.NotificationSetup.MessageTemplate);
                Support.AreEqual("Template for Proactive Notification", FastDriver.NotificationSetup.MessageTemplate.FAGetValue().Clean());
                FastDriver.NotificationSetup.Select.FAClick();

                Reports.TestStep = "Select the message template.";
                FastDriver.MessageTemplateSelectionDlg.WaitForScreenToLoad(FastDriver.MessageTemplateSelectionDlg.FindNow);
                FastDriver.MessageTemplateSelectionDlg.FindNow.FAClick();
                FastDriver.MessageTemplateSelectionDlg.SearchResults.PerformTableAction(1, "DMKGB", 1, TableAction.Click);
                FastDriver.MessageTemplateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.MessageTemplateSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Add/Remove document.";
                FastDriver.NotificationSetup.WaitForScreenToLoad(FastDriver.NotificationSetup.DocumentsAddRemove);
                FastDriver.NotificationSetup.DocumentsAddRemove.FAClick();

                Reports.TestStep = "Select the required document.";
                FastDriver.DocumentSelectionDlg.WaitForScreenToLoad(FastDriver.DocumentSelectionDlg.Results0Select, switchToFraPageWin: true);
                FastDriver.DocumentSelectionDlg.Results0Select.FASetCheckbox(true);
                FastDriver.DocumentSelectionDlg.Add.FAClick();
                FastDriver.DocumentSelectionDlg.SelectDocument.FASetCheckbox(true);
                FastDriver.DocumentSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.DocumentSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Save button.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0017()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("STARTLEN"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "P8189_93_94_207_224_239_242_243: Exclude Templates Without Filters and Incomplete from File Filtered Templates.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Document Repository and click on Add button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Select template.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument(source: "Both", templateType: "Endorsement/Guarantee", templateDescription: "Template donot use");
                //Support.AreEqual("1", FastDriver.AdHocDocuments.SearchResultsTable.GetRowCount().ToString(), "SearchResultsTable row count");
                Support.AreEqual("0", FastDriver.AdHocDocuments.SearchResultsTable.GetRowCount().ToString(), "SearchResultsTable row count");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0018()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P8219_20_21_22_38_EW19_EW20_EW21_EW26_10950_51_52_53_54_FD06: Select Filter criteria(IEmsgs/Error msgs).";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07REG18" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now button and Select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add on Filtering TAB.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();

                Reports.TestStep = "Select Geographic Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad(FastDriver.TemplateFilterSelectionDlg.Select);
                FastDriver.TemplateFilterSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on AddRemove button for State selection.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveState);
                FastDriver.GeograficFilterSelectionDlg.AddRemoveState.FAClick();

                Reports.TestStep = "Add a new state with checked All.";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.CheckAll);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Check County AddRemove button got disabled.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveState);
                Support.AreEqual("False", FastDriver.GeograficFilterSelectionDlg.AddRemoveCounty.IsEnabled().ToString(), "AddRemoveCounty IsEnabled");

                Reports.TestStep = "Click on AddRemove button for State selection.";
                FastDriver.GeograficFilterSelectionDlg.AddRemoveState.FAClick();

                Reports.TestStep = "Add a new state.";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Clear);
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.grdState8SelState.FASetCheckbox(true);
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Check City AddRemove button got disabled.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveCity);
                Support.AreEqual("False", FastDriver.GeograficFilterSelectionDlg.AddRemoveCity.IsEnabled().ToString(), "AddRemoveCity IsEnabled");

                Reports.TestStep = "Click on AddRemove button for County selection.";
                FastDriver.GeograficFilterSelectionDlg.AddRemoveCounty.FAClick();

                Reports.TestStep = "Add a new county.";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Clear);
                FastDriver.CountySelectionDlg.Clear.FAClick();
                FastDriver.CountySelectionDlg.grdCounty0SelCounty.FASetCheckbox(true);
                FastDriver.CountySelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on AddRemove button for City selection.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveCity);
                FastDriver.GeograficFilterSelectionDlg.AddRemoveCity.FAClick();

                Reports.TestStep = "Add a new city.";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Clear, citySelection: true);
                FastDriver.CountySelectionDlg.Clear.FAClick();
                FastDriver.CountySelectionDlg.grdCounty1SelCounty.FASetCheckbox(true);
                FastDriver.CountySelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveCity);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad(FastDriver.TemplateFilterSelectionDlg.Select);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "You must select at least one Service Type.";
                Support.AreEqual("You must select at least one Service Type.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Are you sure you want to navigate away from this page?";
                Support.AreEqual("Are you sure you want to navigate away from this page? If you press OK, Data change(s) will not be saved. See field(s) with red background or details in message pane. Press OK to continue, or Cancel to stay on the current page.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: false).Clean());

                Reports.TestStep = "Select Service Type and Underwriter Filter.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "You must select at least one Transaction Type.";
                Support.AreEqual("You must select at least one Transaction Type.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Are you sure you want to navigate away from this page?";
                Support.AreEqual("Are you sure you want to navigate away from this page? If you press OK, Data change(s) will not be saved. See field(s) with red background or details in message pane. Press OK to continue, or Cancel to stay on the current page.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: false).Clean());

                Reports.TestStep = "Select the Transaction Type.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(transType: "Sale w/Mortgage", roleType: "New Lender", nameIdCode: "247", findCode: true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "You must select at least one Property Type.";
                Support.AreEqual("You must select at least one Property Type.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Are you sure you want to navigate away from this page?";
                Support.AreEqual("Are you sure you want to navigate away from this page? If you press OK, Data change(s) will not be saved. See field(s) with red background or details in message pane. Press OK to continue, or Cancel to stay on the current page.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: false).Clean());

                Reports.TestStep = "Select a Property type and Change Role type.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(propertyType: "Single Family Residence");
                FastDriver.TemplateFilterSelectionDlg.RoleType.Click();
                FastDriver.TemplateFilterSelectionDlg.RoleType.SendKeys(FAKeys.ArrowUp + FAKeys.Tab);

                Reports.TestStep = "Replace the selected Role Type with a Blank will delete all Business Parties that are saved in the Business Party list box.";
                Support.AreEqual("Replacing the selected Role Type with a Blank will delete all Business Parties that are saved in the Business Party listbox.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Click on Done button.";
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad(FastDriver.TemplateFilterSelectionDlg.Select);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0019()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P8224_5_6_7_8_9_30_1_2_3_4_5_6_9644_47_TMP04_TMHK04: Selecting multiple filter criteria.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07REG19" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Adding Phrase Marker.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker);
                FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker.FAClick();

                Reports.TestStep = "Click the phrase marker and checking Required check box.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("#2", "PhraseMarker", "Required", TableAction.On);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase conditions.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesConditions);
                FastDriver.TemplateMaintenancePhrase.PhrasesConditions.FAClick();

                Reports.TestStep = "Add Phrase Condition.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "ALBADD1", index: "1", _operator: "EQ", value: "Field");

                Reports.TestStep = "Add Phrase Condition Buyer1.";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
                FastDriver.PhraseConditionsDlg.EnterCondition(2, dataElement: "BUFNAM", index: "1", value: "Buyer1Firstname");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Add on Filtering TAB.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesConditions);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();

                Reports.TestStep = "Select the Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE", searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Save button in Filtering Tab.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0020()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P8208_09_10_11_12_13_14_15_16_17_TMHK02: Selecting Formatting and defining page range controls-incomplete.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP07REG20" + Support.RandomString("AAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Name", templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Formatting Tab.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();

                Reports.TestStep = "Select First Page formatting.";
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickFirstPage: true, headerPhrase: "Header Ph1", marginTop: "0.4", marginBtm: "0.3");
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItemByIndex(2);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItemByIndex(4);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Select Middle Pages formatting.";
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, marginTop: "0.4", marginBtm: "0.3");
                FastDriver.TemplateMaintenanceFormating.FormattingHeaderPhrase.FASelectItemByIndex(1);
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItemByIndex(3);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItemByIndex(4);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Select Page Before Last formatting.";
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickPageBeforeLast: true, marginTop: "0.4", marginBtm: "0.3");
                FastDriver.TemplateMaintenanceFormating.FormattingHeaderPhrase.FASelectItemByIndex(1);
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItemByIndex(3);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItemByIndex(4);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Select Last Page formatting.";
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickLastPage: true, marginTop: "0.5", marginBtm: "0.5");
                FastDriver.TemplateMaintenanceFormating.FormattingHeaderPhrase.FASelectItemByIndex(0);
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItemByIndex(0);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItemByIndex(0);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Remove defined First Page formatting.";
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickFirstPage: true, marginTop: "0", marginBtm: "0");
                FastDriver.TemplateMaintenanceFormating.FormattingHeaderPhrase.FASelectItemByIndex(0);
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItemByIndex(0);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItemByIndex(0);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0021()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P8224_41_42_43_44_10943: Exclude Templates With Incomplete Filters and No filters.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG21" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Description);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE", searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);

                Reports.TestStep = "Click on Done button.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Select the Filter on Filtering TAB.";
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.TemplateFilter);
                FastDriver.TemplateMaintenanceFiltering.TemplateFilter.PerformTableAction("Transaction", "Sale w/Mortgage", "Transaction", TableAction.Click);

                Reports.TestStep = "Click on Edit on Filtering TAB.";
                FastDriver.TemplateMaintenanceFiltering.FilteringEdit.FAClick();

                Reports.TestStep = "Select the Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(roleType: "New Lender", nameIdCode: "306", findCode: true);
                FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Select the Filter on and Filtering TAB and Click on Copy.";
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.TemplateFilter);
                FastDriver.TemplateMaintenanceFiltering.TemplateFilter.PerformTableAction("Transaction", "Sale w/Mortgage", "Transaction", TableAction.Click);
                FastDriver.TemplateMaintenanceFiltering.FilteringCopy.FAClick();

                Reports.TestStep = "Click on Save button in Filtering Tab.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify Inserted Template Filters Count(rowcount).";
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.TemplateFilter);
                Support.AreEqual("3", FastDriver.TemplateMaintenanceFiltering.TemplateFilter.GetRowCount().ToString(), "TemplateFilter row count");

                Reports.TestStep = "Select the Filter on and Click on Remove in Filtering TAB.";
                FastDriver.TemplateMaintenanceFiltering.TemplateFilter.PerformTableAction("Transaction", "Sale w/Mortgage", "Transaction", TableAction.Click);
                FastDriver.TemplateMaintenanceFiltering.FilteringRemove.FAClick();

                Reports.TestStep = "Click on Save button in Filtering Tab.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify Removed Template Filters Count(rowcount).";
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.TemplateFilter);
                Support.AreEqual("2", FastDriver.TemplateMaintenanceFiltering.TemplateFilter.GetRowCount().ToString(), "TemplateFilter row count");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0022()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                Reports.TestDescription = "P8224_DP10944_45_46_47_48_12650_1: DOCPREP Corporate Region ADM side.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to DOCPREP Corporate Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("197");
                FastDriver.HomePage.WaitForHomeScreen();

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG22" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Description);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();

                Reports.TestStep = "Select Geographic Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateFilterSelectionDlg.Select.FAClick();

                Reports.TestStep = "Check the default values of State,County and City.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad();
                Support.AreEqual("ALL", FastDriver.GeograficFilterSelectionDlg.State.FAGetText().Clean(), "State");
                Support.AreEqual("ALL", FastDriver.GeograficFilterSelectionDlg.County.FAGetText().Clean(), "County");
                Support.AreEqual("ALL", FastDriver.GeograficFilterSelectionDlg.City.FAGetText().Clean(), "City");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select the owning region filter for Canada Template.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, owningRegionAll: false, owningRegion: "Canada Region", underwriterAll: true, propertyTypeAll: true, productTypeAll: true,
                    businessSegmentAll: true, transTypeAll: true, searchTypeAll: true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Save button in Filtering Tab.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done button in Filtering Tab.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_1REG0023()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                Reports.TestDescription = "2650_2: DOCPREP Corporate Region in File side.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to DOCPREP Corporate Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("197");
                FastDriver.HomePage.WaitForHomeScreen();

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG23" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("FRM/156A");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, owningRegionAll: false, owningRegion: "Canada Region", propertyType: "Single Family Residence",
                    transType: "Sale w/Mortgage", businessSegment: "Residential", productType: "ALTA Standard Owner Policy");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Steps for REG25.";
                Reports.StatusUpdate("P8224_218_10944_45_46_47_48_12650_1_FileSide0: DOCPREP Corporate Region in File side", true);
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to DOCPREP Corporate Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("2160");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry");
                try { FastDriver.DuplicateFileSearch.ClickSkipSearchButton(); }
                catch { Reports.StatusUpdate("Duplicate file search screen is disabled.", true); }
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("AHL");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, "*ALTA Standard Owner Policy", 1, TableAction.On);
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("AB");
                if (AutoConfig.UseCDFormType) FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                else FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Click on Document Repository and click on Add button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Select template created in ADM & click on save button.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument(source: "Both", templateType: "Endorsement/Guarantee", templateDescription: "*" + templateName);
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Name", templateName, "Type", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_1REG0024()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                Reports.TestDescription = "2650_3_HK01: DOCPREP Corporate Region in File side.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to DOCPREP Corporate Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("197");
                FastDriver.HomePage.WaitForHomeScreen();

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG24" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("FRM/156A");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, owningRegionAll: false, owningRegion: "Canada Region", propertyType: "Single Family Residence",
                    transType: "Sale w/Mortgage", searchType: "No Search Type");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Steps for REG27.";
                Reports.StatusUpdate("2650_3_FileSide0: DOCPREP Corporate Region in File side", true);
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to DOCPREP Corporate Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("2160");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry");
                try { FastDriver.DuplicateFileSearch.ClickSkipSearchButton(); }
                catch { Reports.StatusUpdate("Duplicate file search screen is disabled.", true); }
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("AHL");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, "*ALTA Standard Owner Policy", 1, TableAction.On);
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("AB");
                if (AutoConfig.UseCDFormType) FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                else FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Click on Document Repository and click on Add button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Select template created in ADM & click on save button.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument(source: "Both", templateType: "Endorsement/Guarantee", templateDescription: "*" + templateName);
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Name", templateName, "Type", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_EREG0028()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "WC22_23_24_25_27: Error warnings.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG28" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                Reports.TestStep = "Click on Save to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Description);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add on Filtering TAB.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();

                Reports.TestStep = "Select the Filter for Invalid Name.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(roleType: "New Lender", nameIdCode: "Buid", findName: true);

                Reports.TestStep = "Name not found.";
                Support.AreEqual("Name not found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Select the Filter for Invalid Name.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(roleType: "New Lender", nameIdCode: "3223WEE#", findCode: true);

                Reports.TestStep = "ID Code not found.";
                Support.AreEqual("ID Code not found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Click on Search button.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(roleType: "New Lender");
                FastDriver.TemplateFilterSelectionDlg.Search.FAClick();

                Reports.TestStep = "Click on Find button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(windowName: "Business Org Search", element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                Reports.TestStep = "User must provide at least one search criterion to complete the search.";
                Support.AreEqual("User must provide at least one search criterion to complete the search.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Set on Cancel.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(windowName: "Business Org Search", element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Click Find Code with out Enter ID Code.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(nameIdCode: "23192", findName: true, findCode: true);

                Reports.TestStep = "A Business Organization ID is required.";
                Support.AreEqual("A Business Organization ID is required.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Select & Delete Business party.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(businessParty: "23192 -23192 -Lender");
                FastDriver.TemplateFilterSelectionDlg.DeleteBusinessParty.FAClick();

                Reports.TestStep = "Are you sure that you want to delete the selected Business Parties?.";
                Support.AreEqual("Are you sure that you want to delete the selected Business Parties?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Select a Property type and Change Role type.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(propertyType: "Single Family Residence");
                FastDriver.TemplateFilterSelectionDlg.RoleType.FASelectItemByIndex(0);

                Reports.TestStep = "Select the owning region filter for Canada Template.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underwriterAll: true, propertyTypeAll: true, productTypeAll: true, businessSegmentAll: true, transTypeAll: true, searchTypeAll: true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Done button in Filtering Tab.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_TREG0029()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "SS01_FD01_ECW01: Field definition and ECW.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Description);
                Support.AreEqual("Endorsement/Guarantee", FastDriver.TemplateMaintenanceSummary.TemplateType.FAGetSelectedItem().Clean(), "TemplateType SelectedItem");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("description accepts upto 40 characters m");

                Reports.TestStep = "Validate Template information.";
                string templateTypes = "All CPL Endorsement/Guarantee Escrow Instruction Escrow Ltr/Transmittal Exchange Delayed Exchange Miscellaneous Exchange Reverse/Construction Fax Cover Sheet Form Gen'd Data Element Guarantee Legal Size Paper Legal/Recordable Doc Lender Policy Message Template Misc Escrow Document Misc Title Document Owner Policy Policy w/o Title Reports SDN Result Title Ltr/Transmittal Title Reports";
                Support.AreEqual(templateTypes, FastDriver.TemplateMaintenanceSummary.TemplateType.FAGetText().Clean(), "TemplateType options");
                Support.AreEqual("Active InActive Both", FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetText().Clean(), "TemplateStatus options");
                Support.AreEqual("description accepts upto 40 characters m", FastDriver.TemplateMaintenanceSummary.Description.FAGetValue().Clean(), "Description");
                Support.AreEqual("True", FastDriver.TemplateMaintenanceSummary.State.IsEnabled().ToString(), "State IsEnabled");
                Support.AreEqual("False", FastDriver.TemplateMaintenanceSummary.County.IsEnabled().ToString(), "County IsEnabled");
                Support.AreEqual("False", FastDriver.TemplateMaintenanceSummary.City.IsEnabled().ToString(), "City IsEnabled");

                Reports.TestStep = "Select CPL template type.";
                FastDriver.TemplateMaintenanceSummary.TemplateType.SendKeys("cpl");

                Reports.TestStep = "CPL document type can be used only from Docprep region.";
                Support.AreEqual("CPL document type can be used only from Docprep region.", FastDriver.WebDriver.HandleDialogMessage().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_TREG0030()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verification of Hotkeys in Template Maintenance Summary Screen.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Description);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("description");
                Support.AreEqual("description", FastDriver.TemplateMaintenanceSummary.Description.FAGetValue().Clean(), "Description");
                Keyboard.SendKeys("%W");
                Reports.StatusUpdate("Sent Alt+W hotkey", true);
                Support.AreEqual("", FastDriver.TemplateMaintenanceSummary.Description.FAGetValue().Clean(), "Description");

                Reports.TestStep = "Hot Key - Click on New button";
                Keyboard.SendKeys("%N");
                Reports.StatusUpdate("Sent Alt+N hotkey", true);
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationTemplateName);

                Reports.TestStep = "Hot Key - Click on Bottom Frame Cancel button";
                FastDriver.BottomFrame.Cancel();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Description);

                Reports.TestStep = "Hot Key - Click on Find Now button";
                Keyboard.SendKeys("%F");
                Reports.StatusUpdate("Sent Alt+F hotkey", true);
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                Support.AreNotEqual("0", FastDriver.TemplateMaintenanceSummary.Results.GetRowCount().ToString(), "Row count");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0007_REG0032()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8190: Using MS Word Files In Fast Templates.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region Form creation
                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FormMaintenanceSummary>("Home>System Maintenance>Document Preparation>Form Maintenance").WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.New);
                FastDriver.FormMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Create a random doc with random document";
                string formName = "DPUC0007FORM" + Support.RandomString("AAAAA");
                FastDriver.FormMaintenance.EnterFormMaintenanceData(formName, true, "Creating New Form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify form creation";
                FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 2, TableAction.Click);
                #endregion

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG28" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                Reports.TestStep = "Click on Save to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Click on Find Now and Select to Edit for created Endorsement/Guarantee type.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Description);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Adding Phrase Marker.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker);
                FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker.FAClick();

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Edit Phrase Tab.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesEdit);
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Edit the added Phrase Marker.";
                FastDriver.EditPhraseMarkerPropertiesDlg.EnterInformation(formName: formName, pageBreak: true, autoOutlineRestart: true);

                Reports.TestStep = "Click on Done button.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.EditPhraseMarkerPropertiesDlg.WindowTitle, false, 15);

                Reports.TestStep = "Verify the Phrase marker added.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhraseTable);
                var val = FastDriver.TemplateMaintenancePhrase.PhraseTable.PerformTableAction(2, 2, TableAction.GetText).Message;
                Support.AreEqual("PhraseMarker " + formName, val, "Phrase description");

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0033()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P8170_EWC29_30: Notification Attachment candidate.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG33" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                Reports.TestStep = "Click on Save to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Click on Find Now button and select the record with temp name.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(notificationAttachmentCandidate: true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Search a GAB 247 in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchAddressBook("247");
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", "247", "ID Code", TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Change the Notification type to Custom.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad(FastDriver.BusPartyOrgSetUp.Version);
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Playback.Wait(1000);
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad(FastDriver.BusPartyOrgSetUp.NotificationTable);
                FastDriver.BusPartyOrgSetUp.NotificationTable.PerformTableAction(3, 2,TableAction.SetText, "abc@fai.com");
                FastDriver.BottomFrame.Done();
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<BusPartyOrgSetUp>("Home>System Maintenance>Address Book>Lenders Advantage").WaitForScreenToLoad(FastDriver.BusPartyOrgSetUp.NotificationTable);
                FastDriver.BusPartyOrgSetUp.NotificationTable.PerformTableAction(3, 4,TableAction.SelectItem, "Custom");
                FastDriver.BusPartyOrgSetUp.NotificationTable.PerformTableAction(3, 3, TableAction.Click);

                Reports.TestStep = "Click on notification button.";
                FastDriver.BusPartyOrgSetUp.Notification.FAClick();

                Reports.TestStep = "Click on Add/Remove document.";
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.DocumentsAddRemove.FAClick();

                Reports.TestStep = "Select a Document.";
                FastDriver.DocumentSelectionDlg.WaitForScreenToLoad(FastDriver.DocumentSelectionDlg.TemplateType, switchToFraPageWin: true);
                FastDriver.DocumentSelectionDlg.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.DocumentSelectionDlg.FindNow.FAClick();
                FastDriver.DocumentSelectionDlg.WaitCreation(FastDriver.DocumentSelectionDlg.DocumnentSearchTable);
                FastDriver.DocumentSelectionDlg.DocumnentSearchTable.PerformTableAction(2, "Template for " + templateName, 1, TableAction.On);
                FastDriver.DocumentSelectionDlg.Add.FAClick();
                FastDriver.DocumentSelectionDlg.WaitCreation(FastDriver.DocumentSelectionDlg.DocumentSelectionTable);
                FastDriver.DocumentSelectionDlg.DocumentSelectionTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DocumentSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.DocumentSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Task Email addresses button.";
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.TaskEmailAddresses.FAClick();

                Reports.TestStep = "Enter name and email address.";
                FastDriver.NotificationEmailAddressesDlg.WaitForScreenToLoad();
                FastDriver.NotificationEmailAddressesDlg.Name1.FASetText("Name");
                FastDriver.NotificationEmailAddressesDlg.Email1.FASetText("abc@fai.com");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter the Notification Setup details.";
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.TaskName.FASelectItem("Clear To Close");
                FastDriver.NotificationSetup.TaskStatus.FASelectItem("Activated");
                FastDriver.NotificationSetup.Select.FAClick();

                Reports.TestStep = "Select the message template.";
                FastDriver.MessageTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.MessageTemplateSelectionDlg.FindNow.FAClick();
                FastDriver.MessageTemplateSelectionDlg.SearchResults.PerformTableAction(1, "DMKGB", 1, TableAction.Click);
                FastDriver.MessageTemplateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.DocumentSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Select Escrow Assistant.";
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.AvailabeSender.FASelectItem("Title Officer");

                Reports.TestStep = "Click on right direction.";
                FastDriver.NotificationSetup.RightDirectionArrow.FAClick();

                Reports.TestStep = "Click on Done button.";
                FastDriver.BottomFrame.Done();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.AddressBookSearch.WaitForScreenToLoad();

                Reports.TestStep = "Click on Find Now button and select the record with temp name.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(underConstruction: false);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Inactivate this document template which has Notification attachment.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(inactive: false);
                FastDriver.WebDriver.HandleDialogMessage(); //this one is not showing up: EVAL01, FAST 10.02.05 - Jan 28, 2016
                //Support.AreEqual("Inactivating this document template, This Document Template will not be available for Notification Attachment.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Uncheck Notification attachment Candidate.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(notificationAttachmentCandidate: false);
                Support.AreEqual("This Document Template has been associated to a Notification, Notification Attachment Candidate cannot be de-selected.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Search a GAB 247 in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchAddressBook("247");
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", "247", "ID Code", TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Change the Notification type to Custom.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.EmailNotificationType.FASelectItem("Custom");
                FastDriver.BusPartyOrgSetUp.EmailNotificationType.FAClick();

                Reports.TestStep = "click on notification button.";
                FastDriver.BusPartyOrgSetUp.Notification.FAClick();

                Reports.TestStep = "Click on Remove button.";
                FastDriver.NotificationSummary.WaitForScreenToLoad(FastDriver.NotificationSummary.NotificationSummaryTable);
                FastDriver.NotificationSummary.NotificationSummaryTable.PerformTableAction("Task Name", "Clear To Close", "#1", TableAction.Click);
                FastDriver.NotificationSummary.Remove.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0034()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P13129_EWC30_31_34_35: State And Product validations and Owning Region filter except for Docprep.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG34" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("7HPG/7HP1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                Reports.TestStep = "Click on Save to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Click on Find Now button and select the record with temp name.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add on Filtering TAB.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();

                Reports.TestStep = "Select the Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, escrow: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", programType: "PT_DO_NOT_DELETE", searchType: "No Search Type", roleType: "New Lender", nameIdCode: "247", findCode: true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate Template Validation default values.";
                Playback.Wait(500);
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkValidation);
                FastDriver.WebDriver.FAFindElement(ByLocator.TagName, "body").SendKeys(FAKeys.PageUp);
                FastDriver.TemplateMaintenanceInformation.linkValidation.FAClick();
                FastDriver.TemplateMaintenanceValidation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceValidation.State);
                Support.AreEqual("ALL", FastDriver.TemplateMaintenanceValidation.State.FAGetText().Clean(), "State");
                Support.AreEqual("True", FastDriver.TemplateMaintenanceValidation.ValidationSelectAll.IsSelected().ToString(), "ValidationSelectAll IsSelected");

                Reports.TestStep = "Click on Template Validation.";
                FastDriver.TemplateMaintenanceValidation.ValidationSelect.FAClick();

                Reports.TestStep = "Select the state filter for Template.";
                FastDriver.StateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateFilterSelectionDlg.AddRemoveState.FAClick();

                Reports.TestStep = "Add a new state.";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.grdState8SelState.FASetCheckbox(true);
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.StateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.StateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Save Template Validation.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "State Filters should always be a subset of state values set up under State validations.";
                Support.AreEqual("State Filters should always be a subset of state values set up under State validations. Please check and try again!", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Uncheck on Template Product Validation Select All.";
                FastDriver.TemplateMaintenanceValidation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceValidation.ValidationSelectAll);
                FastDriver.TemplateMaintenanceValidation.ValidationSelectAll.FASetCheckbox(false);
                FastDriver.TemplateMaintenanceValidation.ValidationProductType.FASelectItem("ALTA Standard Owner Policy");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Product Filters should always be a subset of product values set up under Product validations.";
                Support.AreEqual("State Filters should always be a subset of state values set up under State validations. Product Filters should always be a subset of product values set up under Product validations. Please check and try again!", FastDriver.WebDriver.HandleDialogMessage().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0035()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "P13128_EWC33: Set up State and Product validations for Policy / Endorsements.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Title Reports");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG35" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("JVR/JVR1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                Reports.TestStep = "Click on Save to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Click on Find Now button and select the record with temp name.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Title Reports");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Template Validation.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkValidation);
                FastDriver.TemplateMaintenanceInformation.linkValidation.FAClick();

                Reports.TestStep = "System shall allow FAST admins to set up State and Product validations for Policy/Endorsement template types only.";
                Support.AreEqual("State and Product Validation setup is available for Policy, Guarantee, and Endorsement template types only. Validation setup is unavailable for other template types.", FastDriver.WebDriver.HandleDialogMessage().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0036()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                Reports.TestDescription = "P10948_49_50_51_52_53_54: State/Province, County/LT Reg Office and City Filters.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to DOCPREP Corporate Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("2160");
                FastDriver.HomePage.WaitForHomeScreen();

                #region Template creation
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Title Reports");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP7REG36" + Support.RandomString("AAAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                //Reports.TestStep = "Adding Phrases to the template in Phrases tab.";
                //FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                //FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog().EnterPhraseInformation("FAX/FUN1");
                //FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                Reports.TestStep = "Click on Save to Create the template";
                FastDriver.BottomFrame.Save();
                #endregion

                Reports.TestStep = "Click on Find Now button and select the record with temp name.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Title Reports");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template for " + templateName);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Template for " + templateName, "Status", TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add on Filtering TAB.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();

                Reports.TestStep = "Select Geographic Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad(FastDriver.TemplateFilterSelectionDlg.Select);
                FastDriver.TemplateFilterSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on AddRemove button for State/Province selection.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.GeograficFilterSelectionDlg.AddRemoveState.FAClick();

                Reports.TestStep = "Add a new Province with checked All.";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(provinceSelection: true);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Check County/LT Reg Office AddRemove button got disabled.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.GeograficFilterSelectionDlg.AddRemoveCounty.IsEnabled().ToString(), "AddRemoveCounty IsEnabled");

                Reports.TestStep = "Click on AddRemove button for State/Province selection.";
                FastDriver.GeograficFilterSelectionDlg.AddRemoveState.FAClick();

                Reports.TestStep = "Add a new Province.";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(provinceSelection: true);
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.grdState8SelState.FASetCheckbox(true);
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Check City AddRemove button got disabled.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.GeograficFilterSelectionDlg.AddRemoveCity.IsEnabled().ToString(), "AddRemoveCity IsEnabled");

                Reports.TestStep = "Click on AddRemove button for County/LT Reg Office selection.";
                FastDriver.GeograficFilterSelectionDlg.AddRemoveCounty.FAClick();

                Reports.TestStep = "Add a new LT Reg Office.";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(ltRegOfficeSelection: true);
                FastDriver.CountySelectionDlg.Clear.FAClick();
                FastDriver.CountySelectionDlg.grdCounty0SelCounty.FASetCheckbox(true);
                FastDriver.CountySelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Done button for Geographic Filter selection.";
                FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select the Filter for Template.";
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformation(title: true, underWriter: "First American Title Insurance Company", propertyType: "Single Family Residence",
                    productType: "Abstract", businessSegment: "Residential", transType: "Sale w/Mortgage", searchType: "No Search Type");
                if (AutoConfig.UseCDFormType) FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FAClick();
                else FastDriver.TemplateFilterSelectionDlg.OwningOffice.FASelectItem("Purchase Mortgage - Oakville");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Save created template.";
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0007_DREG0037_1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP9409 : Message Template Type for Proactive Notifications.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                // Getting the existing number of message templates, creating the remaining message templates to reach 200 count.
                Reports.TestStep = "Navigating to Template Maintenance summary screen.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Message Template");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                int messageTemplatesCount = FastDriver.TemplateMaintenanceSummary.Results.GetRowCount();
                Reports.StatusUpdate("Initial template count = " + (messageTemplatesCount).ToString(), true);
                if (messageTemplatesCount < 200)
                {
                    while (messageTemplatesCount < 200)
                    {
                        #region Template creation
                        Reports.TestStep = "Click on New to create new template of Message Template Type";
                        FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Message Template");
                        FastDriver.TemplateMaintenanceSummary.New.FAClick();

                        Reports.TestStep = "Create template of Message Type - Information Tab";
                        string templateName = "DP7REG37" + Support.RandomString("AZAZAZ");
                        FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                        FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                        FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(name: templateName, description: "DP7REG37 - Message Template", comments: "DP7REG37 - Information Comments", underConstruction: false);

                        Reports.TestStep = "Click on Formatting tab and enter required data";
                        FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                        FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                        FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true);

                        Reports.TestStep = "Click on Save to Create the template";
                        FastDriver.BottomFrame.Done();
                        #endregion

                        Reports.TestStep = "Navigate to Template Maintenance screen";
                        FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateType);
                        FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Message Template");
                        FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                        FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                        messageTemplatesCount = FastDriver.TemplateMaintenanceSummary.Results.GetRowCount();
                        Reports.StatusUpdate("Created template #" + messageTemplatesCount.ToString(), true);
                    }

                    // Verify for the message saying "You have reached the maximum of 200 Message Templates"
                    Reports.TestStep = "DP9409: Verify the Number of template and the error after creating 200 templates.";
                    FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Message Template");

                    Reports.TestStep = "Click on Find Now and Verify the number of templates.";
                    FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                    FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                    Support.AreEqual("200", FastDriver.TemplateMaintenanceSummary.Results.GetRowCount().ToString(), "Results row count");

                    Reports.TestStep = "After creating 200 templates clicking, on clicking New, system should load error: Please verify the template count should not be more than 200.";
                    FastDriver.TemplateMaintenanceSummary.New.FAClick();

                    Reports.TestStep = "200 Message Templates.";
                    Support.AreEqual("You have reached the maximum of 200 Message Templates.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                }
                else
                {
                    // Verify for the message saying "You have reached the maximum of 200 Message Templates"
                    Reports.TestStep = "DP9409: Verify the Number of template and the error after creating 200 templates.";
                    FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                    FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Message Template");

                    Reports.TestStep = "Click on Find Now and Verify the number of templates.";
                    FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                    FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                    Support.AreEqual("200", FastDriver.TemplateMaintenanceSummary.Results.GetRowCount().ToString(), "Results row count");

                    Reports.TestStep = "After creating 200 templates clicking, on clicking New, system should load error: Please verify the template count should not be more than 200.";
                    FastDriver.TemplateMaintenanceSummary.New.FAClick();

                    Reports.TestStep = "200 Message Templates.";
                    Support.AreEqual("You have reached the maximum of 200 Message Templates.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}