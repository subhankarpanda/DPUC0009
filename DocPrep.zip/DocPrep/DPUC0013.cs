﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;


namespace DocPrep
{
    /// <summary>
    /// Summary description for DPUC0013
    /// </summary>
    [CodedUITest]
    public class DPUC0013 : MasterTestClass
    {
        public DPUC0013()
        {
        }

        #region BAT
        [TestMethod]
        public void DPUC0013_BAT0001()
        {
            try
            {
                Reports.TestDescription = "611_612: Create a New Phrase.";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for a phrase group";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "AN4", 1, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = " select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.Click);
                string phraseName = FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean() + " - " + FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Select the Phrase Name from Phrase editor, click on Cut Button then Save";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Cut.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                FastDriver.PhraseEditorDlg.TextArea.SendKeys("Innovation");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_BAT0002()
        {
            try
            {
                Reports.TestDescription = "621_622_6223: Insert Space Between Lines.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for a phrase group";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "AN4", 1, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = " select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.Click);
                string phraseName = FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean() + " - " + FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Select the Phrase Name from Phrase editor, click on Cut Button then Save";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Cut.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                FastDriver.PhraseEditorDlg.TextArea.SendKeys("Innovation");

                Reports.TestStep = "Create the Spacing.";
                Keyboard.SendKeys("{ENTER}");
                Keyboard.SendKeys("{ENTER}");

                Reports.TestStep = "Inserting the Table.";
                FastDriver.PhraseEditorDlg.InsertTableElement.FAClick();

                Reports.TestStep = "Select the Phrase Name from Phrase editor and Click on Cut. Button.";
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Cut.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.DialogBottomFrame.ClickCancel();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_BAT0003()
        {
            try
            {
                Reports.TestDescription = "623_6231: Insert Data Element.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for a phrase group";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "AN4", 1, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = " select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.Click);
                string phraseName = FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean() + " - " + FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Add a data element";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Buyer");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("BUEBY");
                FastDriver.DataElementSelectionDlg.Select.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "click on save & then done button.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_BAT0004()
        {
            try
            {

                Reports.TestDescription = "6232_624_6241_6242_625_626_6261: Start a New Auto Outline Number Group for This Phrase.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for a phrase group";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "AN4", 1, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.Click);
                string phraseName = FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean() + " - " + FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Inserting Outline.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Cut.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                FastDriver.PhraseEditorDlg.AutoOutline.FAClick();

                Reports.TestStep = "Inserting a Bullet Point Style.";
                FastDriver.PhraseEditorDlg.OutlineList.FASelectItem("A.");
                FastDriver.PhraseEditorDlg.TextArea.Click();

                Reports.TestStep = "Create the Spacing.";
                Keyboard.SendKeys("{ENTER}");
                Keyboard.SendKeys("{ENTER}");

                Reports.TestStep = "Inserting a Bullet Point Style.";
                FastDriver.PhraseEditorDlg.OutlineList.FASelectItem("A.");
                FastDriver.PhraseEditorDlg.TextArea.Click();

                Reports.TestStep = "Select the Phrase Name from Phrase editor and Click on Cut. Button.";
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Cut.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);

                Reports.TestStep = "Select all and do Bold, Italic, underlining, Indent.";
                FastDriver.PhraseEditorDlg.TextArea.SendKeys("Innovation");
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Bold.FAClick();
                FastDriver.PhraseEditorDlg.Italic.FAClick();
                FastDriver.PhraseEditorDlg.Underline.FAClick();
                FastDriver.PhraseEditorDlg.Highlight.FAClick();
                FastDriver.PhraseEditorDlg.RightIndent.FAClick();

                Reports.TestStep = "Page Breaker.";
                FastDriver.PhraseEditorDlg.PageBreak.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG

        [TestMethod]
        public void DPUC0013_REG0001()
        {
            try
            {
                Reports.TestDescription = "DP7694: Control Highlight Function in Phrase Editor.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for a phrase group";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "AN4", 1, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.Click);
                string phraseName = FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean() + " - " + FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Insert Buyer Type Element";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys("{ENTER}");
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Buyer");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("BUEBY");
                FastDriver.DataElementSelectionDlg.Select.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);

                Reports.TestStep = "Select the Phrase Name from Phrase editor and click on Cut button.";
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Cut.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);

                Reports.TestStep = "Click Done and save.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Insert Buyer Type Element";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys("{ENTER}");
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Buyer");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("BUEBY");
                FastDriver.DataElementSelectionDlg.Select.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);

                Reports.TestStep = "Click Done and save.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_REG0002()
        {
            try
            {
                Reports.TestDescription = "DP7693: Highlight Typed Text Within a Phrase.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for a phrase group";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "ENTY", 1, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.Click);
                string phraseName = FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean() + " - " + FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Select the Phrase Name from Phrase editor, click on Cut Button then Save";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Highlight.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_REG0003()
        {
            try
            {
                Reports.TestDescription = "DP7692: Highlight Text Elements and Data Elements Within a Phrase.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for a phrase group";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "GOAL", 1, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.Click);
                string phraseName = FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean() + " - " + FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Insert Buyer Type Element";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Cut.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Buyer");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("BUEBY");
                FastDriver.DataElementSelectionDlg.Select.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);

                Reports.TestStep = "Select the Phrase Name from Phrase editor and Click to Yellow out.";
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Highlight.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_REG0006()
        {
            try
            {
                Reports.TestDescription = "DP7694_01: Control Highlight Function in Phrase Editor.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Click on Add Button, select template and save it";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument("Both", "Endorsement/Guarantee", "ALTA Endorsement 10-06 (Assignment)-N", "CA");
                FastDriver.AdHocDocuments.WaitForResultsToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();

                Reports.TestStep = "Select Document and Click on Edit Name Button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click on Phrase link & enter Phrase Name";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Keyboard.SendKeys("%P");
                Playback.Wait(1000);
                Keyboard.SendKeys("%P");
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"AN4/BBBB");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify that new Phrase and Misc Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                FastDriver.DocumentPreparationwin.Phrase2Table.PerformTableAction(1, 2, TableAction.Click);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_REG0007()
        {
            try
            {
                Reports.TestDescription = "DP7693_02: Highlight Typed Text Within a Phrase.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Click on Add Button, select template and save it";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument("Both", "Endorsement/Guarantee", "ALTA Endorsement 10-06 (Assignment)-N", "CA");
                FastDriver.AdHocDocuments.WaitForResultsToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();

                Reports.TestStep = "Select Document and Click on Edit Name Button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click on Phrase link & enter Phrase Name";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Keyboard.SendKeys("%P");
                Playback.Wait(1000);
                Keyboard.SendKeys("%P");
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"ENTY/PHRS");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify that new Phrase and Misc Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                FastDriver.DocumentPreparationwin.Phrase2Table.PerformTableAction(1, 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_REG0008()
        {
            try
            {
                Reports.TestDescription = "DP7692_03: Highlight Text Elements and Data Elements Within a Phrase.";
                Reports.TestStep = "Log in to IIS and Create a File";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Click on Add Button, select template and save it";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument("Both", "Endorsement/Guarantee", "ALTA Endorsement 10-06 (Assignment)-N", "CA");
                FastDriver.AdHocDocuments.WaitForResultsToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();

                Reports.TestStep = "Select Document and Click on Edit Name Button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click on Phrase link & enter Phrase Name";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Keyboard.SendKeys("%P");
                Playback.Wait(1000);
                Keyboard.SendKeys("%P");
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"GOAL/PHR5");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Verify that new Phrase and Misc Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                FastDriver.DocumentPreparationwin.Phrase2Table.PerformTableAction(1, 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_REG0009_PH()
        {
            try
            {
                Reports.TestDescription = "DP7695_DP7694_DP7693_DP7692_DP225: I covered the basic functionality related to Phrase editor, please verify BRs Manually.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_REG0011()
        {
            try
            {
                Reports.TestDescription = "DP7694_DP7695: Verify the basic functionality for Phrase Editor.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create anew phrase.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                string phraseName = Support.RandomString("ANAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("DPUC0013 Reg Test");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("DPUC0013 Reg Test");
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                Reports.TestStep = "Click on Add to enter a new phrase name and description.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                phraseName = Support.RandomString("ANAN");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Phrase for Extension");
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_REG0012()
        {
            try
            {
                Reports.TestDescription = "DP7692_DP7693_DP225: Select the Data element then perform Highlight , Bold, Italic, underline, Right Indent then click on save and once again click on the Insert data element.";

                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create anew phrase.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                string phraseName = Support.RandomString("ANAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("DPUC0013 Reg Test");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("DPUC0013 Reg Test");
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                Reports.TestStep = "Click on Add to enter a new phrase name and description.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                phraseName = Support.RandomString("ANAN");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Phrase for Extension");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click the phrase editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Insert Buyer Type Element";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWBPHX");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);

                Reports.TestStep = "Select all and do Bold,Italic,underlining, Indent.";
                FastDriver.PhraseEditorDlg.TextArea.SendKeys("Innovation");
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.Bold.FAClick();
                FastDriver.PhraseEditorDlg.Italic.FAClick();
                FastDriver.PhraseEditorDlg.Underline.FAClick();
                FastDriver.PhraseEditorDlg.Highlight.FAClick();
                FastDriver.PhraseEditorDlg.RightIndent.FAClick();
                //FastDriver.PhraseEditorDlg.Test();

                //Reports.TestStep = "Click on Insert data element link.";
                //FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                //FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                //FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement, windowName: phraseName);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0013_REG0013_PH()
        {
            try
            {
                Reports.TestDescription = "DP7695_DP7694_DP7693_DP7692_DP225_REG: I covered the basic functionality related to Phrase editor, please verify BRs Manually.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

        #region Useful Methods
        private void Login(string Key)
        {

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(Key, credentials, true);
        }

        #endregion
    }
}
