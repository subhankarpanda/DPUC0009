﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using System.Linq;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;


namespace DocPrep
{
    /// <summary>
    /// Summary description for DPUC0002
    /// </summary>
    [CodedUITest]
    public class DPUC0002 : MasterTestClass
    {
        #region BAT

        [TestMethod]
        public void DPUC0002_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_1_AF_2: Maintain Documents, Add Miscellaneous Phrase.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    //UserName = AutoConfig.UserName,
                    //Password = AutoConfig.UserPassword
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Doc";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Verify that A Misc. phrase requires at least one text character(Here I haven't Given anything as name) or control character, i.e. page break.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                int requiredRowNumber = FastDriver.DocumentRepository.DocumentsTable.GetRowCount();
                Support.AreEqual(@"1", requiredRowNumber.ToString());
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "Bus Source", "Name", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.DocumentPreparationwin.BrokenImage.Exists().ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                Reports.TestStep = "Preview the Document-ALT+V Under Document TAB.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000);
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Un Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"UnFinalized");

                Reports.TestStep = "Verify Un Finalized Document Data.";
                Support.AreEqual(@"UnFinalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_BAT0001B()
        {
            try
            {
                Reports.TestDescription = "aa";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Doc";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Verify that A Misc. phrase requires at least one text character(Here I haven't Given anything as name) or control character, i.e. page break.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                int requiredRowNumber = FastDriver.DocumentRepository.DocumentsTable.GetRowCount();
                Support.AreEqual(@"1", requiredRowNumber.ToString());
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "Bus Source", "Name", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.DocumentPreparationwin.BrokenImage.Exists().ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Preview the Document-ALT+V Under Document TAB.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000);
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Un Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(windowName: "Unfinalize Document");
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"UnFinalized");

                Reports.TestStep = "Verify Un Finalized Document Data.";
                Support.AreEqual(@"UnFinalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify the Phrase name and Business Contacts for the Business source.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                try
                {
                    var value = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("NPBS/NPBS")); 
                    Support.AreEqual(@"2", value.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%e");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");

                Reports.TestStep = "Enter text in phrase.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                Keyboard.SendKeys("Text");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_BAT0001C()
        {
            try
            {
                Reports.TestDescription = "bb";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Doc";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Verify that A Misc. phrase requires at least one text character(Here I haven't Given anything as name) or control character, i.e. page break.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                int requiredRowNumber = FastDriver.DocumentRepository.DocumentsTable.GetRowCount();
                Support.AreEqual(@"1", requiredRowNumber.ToString());
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "Bus Source", "Name", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.DocumentPreparationwin.BrokenImage.Exists().ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Preview the Document-ALT+V Under Document TAB.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000);
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Un Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"UnFinalized");

                Reports.TestStep = "Verify Un Finalized Document Data.";
                Support.AreEqual(@"UnFinalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify the Phrase name and Business Contacts for the Business source.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                try
                {
                    var value = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("NPBS/NPBS"));
                    Support.AreEqual(@"2", value.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%e");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");

                Reports.TestStep = "Enter text in phrase.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                Keyboard.SendKeys("Text");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Link and Press ALT+S. from DP0009 - REG DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("s");
                Playback.Wait(1000);

                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                Support.AreEqual(@"Click OK to insert the phrase below the first phrase, Cancel to insert a phrase above the first phrase.", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());
                Playback.Wait(2000);

                Reports.TestStep = "Click on OK without enter any data in Misc Phrase Dialog.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor Title", true, 20);
                FastDriver.DialogBottomFrame.ClickCancel();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF_1: Insert Phrases.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Doc";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Verify that A Misc. phrase requires at least one text character(Here I haven't Given anything as name) or control character, i.e. page break.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                int requiredRowNumber = FastDriver.DocumentRepository.DocumentsTable.GetRowCount();
                Support.AreEqual(@"1", requiredRowNumber.ToString());
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "Bus Source", "Name", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.DocumentPreparationwin.BrokenImage.Exists().ToString());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Preview the Document-ALT+V Under Document TAB.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000);
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Un Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"UnFinalized");

                Reports.TestStep = "Verify Un Finalized Document Data.";
                Support.AreEqual(@"UnFinalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify the Phrase name and Business Contacts for the Business source.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                try
                {
                    var value = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("NPBS/NPBS"));
                    Support.AreEqual(@"2", value.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");

                Reports.TestStep = "Enter text in phrase.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("Text");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Link and Press ALT+S. from DP0009 - REG DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("s");
                Playback.Wait(1000);

                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                Support.AreEqual(@"Click OK to insert the phrase below the first phrase, Cancel to insert a phrase above the first phrase.", 
                    FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());
                Playback.Wait(2000);

                Reports.TestStep = "Click on OK without enter any data in Misc Phrase Dialog.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor Title", true, 20);
                FastDriver.DialogBottomFrame.ClickCancel();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click ALT+P.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");
                Playback.Wait(1000);
                
                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                Support.AreEqual(@"Click OK to insert a phrase below the first phrase, Cancel to insert a phrase above the first phrase.",
                    FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());
                Playback.Wait(2000);

                Reports.TestStep = "Enter the Description and add Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 5);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                Reports.TestStep = "Verify that new Phrase and Misc Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                var element = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("JV01"));
                Support.AreEqual(@"3", element.ToString());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF_3_AF_7: Edit Text of Phrase - Custom Phrase, Insert an Auto numbering Marker.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Doc";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Verify that A Misc. phrase requires at least one text character(Here I haven't Given anything as name) or control character, i.e. page break.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                int requiredRowNumber = FastDriver.DocumentRepository.DocumentsTable.GetRowCount();
                Support.AreEqual(@"1", requiredRowNumber.ToString());
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "Bus Source", "Name", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.DocumentPreparationwin.BrokenImage.Exists().ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(1000);

                Reports.TestStep = "Preview the Document-ALT+V Under Document TAB.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000);
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Un Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"UnFinalized");

                Reports.TestStep = "Verify Un Finalized Document Data.";
                Support.AreEqual(@"UnFinalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(1000);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify the Phrase name and Business Contacts for the Business source.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                try
                {
                    var value = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("NPBS/NPBS"));
                    Support.AreEqual(@"2", value.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%e");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");

                Reports.TestStep = "Enter text in phrase.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(windowName: "Editor");
                Keyboard.SendKeys("Text");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                Playback.Wait(1000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Link and Press ALT+S. from DP0009 - REG DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("s");
                Playback.Wait(1000);

                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                Support.AreEqual(@"Click OK to insert the phrase below the first phrase, Cancel to insert a phrase above the first phrase.",
                    FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());
                Playback.Wait(2000);

                Reports.TestStep = "Click on OK without enter any data in Misc Phrase Dialog.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor Title", true, 20);
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(1000);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click ALT+P.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");
                Playback.Wait(1000);

                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                Support.AreEqual(@"Click OK to insert a phrase below the first phrase, Cancel to insert a phrase above the first phrase.",
                    FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());
                Playback.Wait(2000);

                Reports.TestStep = "Enter the Description and add Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 5);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(1000);

                Reports.TestStep = "Verify that new Phrase and Misc Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                var element = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("JV01"));
                Support.AreEqual(@"3", element.ToString());

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");
                Playback.Wait(1000);
                
                Reports.TestStep = "Inserting Outline.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("NPBS/NPBS", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                try
                {
                    IWebElement img = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(p => p.GetAttribute("src").Contains("images/ico_numlist.gif"));
                    img.FAClick();
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Error searching for element: " + e.Message, false);
                }

                Reports.TestStep = "Sending send keys of Save and Done.";
                sendKeysToPhraseEditor("^", "{END}");// added
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF_4: Remove Phrase(s).";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add Title Report.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys(@"Title Reports");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTERNATE FLOW 1 - QTP - DO NOT TOUCH");
                FastDriver.AdHocDocuments.State.FASelectItem(@"CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(5000);

                Reports.TestStep = "Verify that title report added.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                int requiredRowNumber = FastDriver.DocumentRepository.DocumentsTable.GetRowCount();
                Support.AreEqual(@"1", requiredRowNumber.ToString());
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", "Name", TableAction.Click);
                                
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();

                Reports.TestStep = "Add Lender Policy Document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys(@"Lender Policy");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.AdHocDocuments.State.FASelectItem(@"CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(5000);

                Reports.TestStep = "Verify that Lender Policy added.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.LenderPolicy.FAClick();
                //FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(p => p.Text.Contains("Lender Policy")).FAClick();

                Reports.TestStep = "Click Info.";
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter effective date and click on Save.";
                FastDriver.DocumentInfo.SwitchToContentFrame();
                FastDriver.DocumentInfo.WaitCreation(FastDriver.DocumentInfo.LenderOwnerEffectiveDate);
                value = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("M/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(value);
                if (!FastDriver.DocumentInfo.LenderCheckBox.Selected)
                    FastDriver.DocumentInfo.LenderCheckBox.FAClick();
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Click on Done.";
                Keyboard.SendKeys("^D");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Doc rep select Lender Policy click on edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.WebDriver.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Contains("Lender Policy")).FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Click ALT+P.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");
                Playback.Wait(1000);

                //Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                //FastDriver.WebDriver.HandleDialogMessage(false, true);

                Reports.TestStep = "Enter the Description and add Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 5);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                Reports.TestStep = "Verify that new Phrase and Misc Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                var element = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("JV01"));
                Support.AreEqual(@"3", element.ToString());
                
                Reports.TestStep = "Navigate to Doc rep select Lender Policy click on edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.WebDriver.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Contains("Lender Policy")).FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                
                Reports.TestStep = "Click ALT+D Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("d");
                
                Reports.TestStep = "Delete the Phrase.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                FastDriver.EditorDeleteDlg.SwitchToDialogContentFrame();
                FastDriver.EditorDeleteDlg.SelectAll.FAClick();
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText(@"Removing/Waiving all the Phrases.");

                Reports.TestStep = "desect first.";
                if (FastDriver.EditorDeleteDlg.FirstCheckBox.Selected)
                    FastDriver.EditorDeleteDlg.FirstCheckBox.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "To verify the removal of phrase from policy document";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Commitment/Policy Phrase Removed]", "Event", TableAction.Click);
                Support.value = FastDriver.EventTrackingLog.Comments.Text.Clean();
                value = "The reason is: Removing/Waiving all the Phrases. " + AutoConfig.SelectedRegionName + " " + AutoConfig.SelectedRegionBUID;
                Support.AreEqual("True", Support.value.Contains(value).ToString());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF_5: Add Phrase to Pending Group.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add Title Report.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys(@"Title Reports");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTERNATE FLOW 1 - QTP - DO NOT TOUCH");
                FastDriver.AdHocDocuments.State.FASelectItem(@"CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Verify that title report added.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                int requiredRowNumber = FastDriver.DocumentRepository.DocumentsTable.GetRowCount();
                Support.AreEqual(@"1", requiredRowNumber.ToString());
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", "Name", TableAction.Click);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();

                Reports.TestStep = "Add Lender Policy Document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys(@"Lender Policy");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.AdHocDocuments.State.FASelectItem(@"CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Verify that Lender Policy added.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.LenderPolicy.FAClick();
                //FastDriver.WebDriver.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Contains("Lender Policy")).FAClick();

                Reports.TestStep = "Click Info.";
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter effective date and click on Save.";
                FastDriver.DocumentInfo.SwitchToContentFrame();
                FastDriver.DocumentInfo.WaitCreation(FastDriver.DocumentInfo.LenderOwnerEffectiveDate);
                value = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("M/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(value);
                if (!FastDriver.DocumentInfo.LenderCheckBox.Selected)
                    FastDriver.DocumentInfo.LenderCheckBox.FAClick();
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Click on Done.";
                Keyboard.SendKeys("^D");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Doc rep select Lender Policy click on edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.LenderPolicy.FAClick();
                //FastDriver.WebDriver.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Contains("Lender Policy")).FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Click ALT+P.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");
                Playback.Wait(1000);
                
                Reports.TestStep = "Enter the Description and add Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 5);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                Playback.Wait(1000);

                Reports.TestStep = "Verify that new Phrase and Misc Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                var element = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("JV01"));
                Support.AreEqual(@"3", element.ToString());

                Reports.TestStep = "Navigate to Doc rep select Lender Policy click on edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.LenderPolicy.FAClick();
                FastDriver.WebDriver.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Contains("Lender Policy")).FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click ALT+D Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("d");

                Reports.TestStep = "Delete the Phrase.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                FastDriver.EditorDeleteDlg.SwitchToDialogContentFrame();
                FastDriver.EditorDeleteDlg.SelectAll.FAClick();
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText(@"Removing/Waiving all the Phrases.");

                Reports.TestStep = "desect first.";
                if (FastDriver.EditorDeleteDlg.FirstCheckBox.Selected)
                    FastDriver.EditorDeleteDlg.FirstCheckBox.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "To verify the removal of phrase from policy document";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Commitment/Policy Phrase Removed]", "Event", TableAction.Click);
                Support.value = FastDriver.EventTrackingLog.Comments.Text.Clean();
                value = "The reason is: Removing/Waiving all the Phrases. " + AutoConfig.SelectedRegionName + " " + AutoConfig.SelectedRegionBUID;
                Support.AreEqual("True", Support.value.Contains(value).ToString());

                Reports.TestStep = "Create a Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                this.CreateDocument("Endorsement/Guarantee", "Bus Source ", "Bus Source", multipleDocs: true);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Endorsement/Guarantee", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");
                Playback.Wait(2000);

                Reports.TestStep = "Inserting Outline.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("NPBS/NPBS", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                try
                {
                    IWebElement img = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(p => p.GetAttribute("src").Contains("images/ico_numlist.gif"));
                    img.FAClick();
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Error searching for element: " + e.Message, false);
                }
                sendKeysToPhraseEditor("^", "{END}");// added
                
                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click ALT+A Under Phrase Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Endorsement/Guarantee", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("a");
                Playback.Wait(1000);

                Reports.TestStep = "Data Element Bus ID Dby Cont Name will be added to the Pend phrase group.";
                Support.AreEqual(@"Phrase NPBS/NPBS - Data Element Bus ID Dby Cont Name will be added to the Pending phrase group", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.BottomFrame.Done();
                
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF_5_ADM: Verify that phrase added to pending group.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for a phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem(@"Miscellaneous Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText(@"Pending Phrase Group");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

                Reports.TestStep = "To verify that Pending Phrase is Present.";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Description", "Pending Phrase Group", "Description", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "To verify that Pending Phrase is added to the Pending Phrase Group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(3, "Active", 3, TableAction.Click);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_BAT0007()
        {
            try
            {
                Reports.TestDescription = "MF_1_AF_2: Maintain Documents, Add Miscellaneous Phrase.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Doc";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+P and D to add template.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("t");
                //FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                //Support.AreEqual("False", FastDriver.DocumentPreparationwin.LockImage.Exists().ToString());

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Select the Template to insert.";
                FastDriver.titleDlg.WaitForScreenToLoad();
                FastDriver.titleDlg.selSource.FASelectItem(@"Region");
                FastDriver.titleDlg.templateList.FASelectItem(@"Escrow Instruction");
                FastDriver.titleDlg.templateTable.PerformTableAction(2, "Babu Template", 2, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                Playback.Wait(5000);
                
                Reports.TestStep = "Verify that new Title Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                try
                {
                    var value = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("EEHR/ESOE"));
                    Support.AreEqual(@"2", value.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region REG

        [TestMethod]
        public void DPUC0002_REG0001()
        {
            try
            {
                Reports.TestDescription = "DP3373_DP267_DP3384_DP3385_DP3389_DP3390_DP3450_DP3451_ADM: Create Template, Adding phrase and For each Phrase that is made a part of the File Document, an abbreviated version of the phrase is displayed.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PhraseGroupName1 = "";
                string NewPhrase1 = "";
                #endregion

                #region GUI interaction

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for a phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                PhraseGroupName1 = Support.RandomString("AAAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(PhraseGroupName1);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText(@"Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText(@"Created for Axe BAT script");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                
                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                NewPhrase1 = Support.RandomString("NZNA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(NewPhrase1);
                FastDriver.PhraseMaintenance.Description.FASetText(@"New created phrase1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.SwitchToContentFrame();
                string desc = FastDriver.PhraseMaintenance.Description.FAGetValue().Clean();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");//added
                sendKeysToPhraseEditor("^", "{SPACE}");//added
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                //FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Select a data element & enter the value.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElementGroup);
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Home Warranty Information");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"HWBPHX");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                
                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                
                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0001B()
        {
            try
            {
                Reports.TestDescription = "Creation of Template using Random String";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PhraseGroupName1 = "";
                string NewPhrase1 = "";
                string Tempname = "";
                string InformationDescription = "";
                #endregion

                #region GUI interaction

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for a phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                PhraseGroupName1 = Support.RandomString("AAAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(PhraseGroupName1);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText(@"Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText(@"Created for Axe BAT script");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                NewPhrase1 = Support.RandomString("NZNA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(NewPhrase1);
                FastDriver.PhraseMaintenance.Description.FASetText(@"New created phrase1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.SwitchToContentFrame();
                var desc = FastDriver.PhraseMaintenance.Description.FAGetValue().Clean();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");//added
                sendKeysToPhraseEditor("^", "{SPACE}");//added
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                //FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Select a data element & enter the value.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Home Warranty Information");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"HWBPHX");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);

                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper(), true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New button.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Provide template name, description & comments.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                Support.AreEqual(@"0", FastDriver.TemplateMaintenanceInformation.TemplateID.Text.Clean());
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                Tempname = Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(Tempname);
                InformationDescription = Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(InformationDescription);
                if (FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.Selected)
                    FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FAClick();
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText(@"InformationComment");

                Reports.TestStep = "Provide template name, description & comments.";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Template ID will be assigned once the template has been saved.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");

                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(InformationDescription);

                Reports.TestStep = "Click on Find Now and Select to Edit.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", InformationDescription, "Status", TableAction.Click);
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0001C()
        {
            try
            {
                Reports.TestDescription = "Searching of Template in Table using random string";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PhraseGroupName1 = "";
                string NewPhrase1 = "";
                string Tempname = "";
                string InformationDescription = "";
                #endregion

                #region GUI interaction

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for a phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                PhraseGroupName1 = Support.RandomString("AAAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(PhraseGroupName1);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText(@"Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText(@"Created for Axe BAT script");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                NewPhrase1 = Support.RandomString("NZNA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(NewPhrase1);
                FastDriver.PhraseMaintenance.Description.FASetText(@"New created phrase1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.SwitchToContentFrame();
                var desc = FastDriver.PhraseMaintenance.Description.FAGetValue().Clean();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");//added
                sendKeysToPhraseEditor("^", "{SPACE}");//added
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                //FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Select a data element & enter the value.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Home Warranty Information");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"HWBPHX");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);

                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                Playback.Wait(1000);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New button.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Provide template name, description & comments.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                Support.AreEqual(@"0", FastDriver.TemplateMaintenanceInformation.TemplateID.Text.Clean());
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                Tempname = Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(Tempname);
                InformationDescription = Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(InformationDescription);
                if (FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.Selected)
                    FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FAClick();
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText(@"InformationComment");

                Reports.TestStep = "Provide template name, description & comments.";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Template ID will be assigned once the template has been saved.";
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");

                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(InformationDescription);

                Reports.TestStep = "Click on Find Now and Select to Edit.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", InformationDescription, "Status", TableAction.Click);
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 5);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(PhraseGroupName1 + "/" + NewPhrase1);
                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0002()
        {
            try
            {
                Reports.TestDescription = "DP3373_DP267_DP3384_DP3385_DP3389_DP3390_DP3450_DP3451_IIS: Phrase Abbreviation, Inserting & Create phrases, Limitations for editing required Phrases, Editing Phrases, Broken link when standard phrase is edited, Standard";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Pre Cond.: Validate Phrase.";
                PhraseValidation();

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Doc";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Navigate to document repository and verify saved doc.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                int requiredRowNumber = FastDriver.DocumentRepository.DocumentsTable.GetRowCount();
                Support.AreEqual(@"1", requiredRowNumber.ToString());

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "Bus Source", "Name", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click ALT+P.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");

                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                var value = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"True", value.Contains("Click OK to insert a phrase below the first phrase").ToString());

                Reports.TestStep = "Select Phrase type & enter name.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"TRNS/34B");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(5000);

                Reports.TestStep = "Verify the Phrase name and Business Contacts for the Business source.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                try
                {
                    var span = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("NPBS/NPBS"));
                    Support.AreEqual(@"2", span.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }

                Reports.TestStep = "Click on Phrase Link and Press ALT+S. from DP0009 - REG DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("s");

                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean().Contains("Click OK to insert the phrase below the first phrase").ToString());

                Reports.TestStep = "Click on OK without enter any data in Misc Phrase Dialog.";
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor Title", true, 20);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Phrase Link and Press ALT+S. from DP0009 - REG DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("s");

                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean().Contains("Click OK to insert the phrase below the first phrase").ToString());

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor Title", true, 20);
                FastDriver.DialogBottomFrame.ClickCancel();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(5000);

                Reports.TestStep = "Verify that A Misc. phrase requires at least one text character(Here I haven't Given anything as name) or control character, i.e. page break.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                try
                {
                    Support.AreEqual("True", FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(j => j.GetAttribute("src").Contains("images/ico_brokenlink.gif") && j.Displayed).Exists().ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Error ocurring finding element: " + e.Message, false);
                }

                Reports.TestStep = "Click ALT+P.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");
                Playback.Wait(2000);

                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean().Contains("Click OK to insert a phrase below the first phrase").ToString());

                Reports.TestStep = "Select Phrase type & enter name.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVR/JVR1");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(5000);

                Reports.TestStep = "Verify that new Phrase and Misc Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                try
                {
                    var span = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Clean() == "JVR/JVR1");
                    Support.AreEqual(@"1", span.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0003()
        {
            try
            {
                Reports.TestDescription = "DP3388_ADM: Uncheck Editable check box.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PhraseGroupName1 = "";
                string NewPhrase1 = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM site";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                PhraseGroupName1 = Support.RandomString("AAAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(PhraseGroupName1);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText(@"Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText(@"Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                NewPhrase1 = Support.RandomString("NZNA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(NewPhrase1);
                FastDriver.PhraseMaintenance.Description.FASetText(@"New created phrase1");
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseMaintenance.SwitchToContentFrame();
                var desc = FastDriver.PhraseMaintenance.Description.FAGetValue().Clean();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");//added
                sendKeysToPhraseEditor("^", "{SPACE}");//added
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Home Warranty Information");
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"HWBPHX");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search for a phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText(@"Automation*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", PhraseGroupName1, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "New created phrase1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Edit the phrase.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.Statuschangecomments.FAClick();

                Reports.TestStep = "Uncheck Editable field";
                if(FastDriver.PhraseMaintenance.Editable.Selected)
                    FastDriver.PhraseMaintenance.Editable.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the editable check box is Unchecked.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.PhraseMaintenance.Editable.Selected.ToString());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Check Editable field";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                if(!FastDriver.PhraseMaintenance.Editable.Selected)
                    FastDriver.PhraseMaintenance.Editable.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0004()
        {
            try
            {
                Reports.TestDescription = "IIS_DP3388_DP271_DP272_DP3403_DP3448_DP3467_DP3476_DP1737_DP1738_DP3480_DP3409_DP3475_EWC01_EWC04_EWC08: Verify that If Phrase is Non Editable in ADM then we cant Edit in File Side, Moving the Phrase, Saving phrases, Pre";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Pre Cond.: Validate Phrase.";
                PhraseValidation();

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "Bus Source", "Name", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");
                value = FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"TRNS/34B");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(5000);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("s");
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean().Contains("Click OK to insert the phrase below the first phrase").ToString());
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor Title", true, 20);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("s");
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean().Contains("Click OK to insert the phrase below the first phrase").ToString());
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor Title", true, 20);
                FastDriver.DialogBottomFrame.ClickCancel();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");
                Playback.Wait(2000);
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean().Contains("Click OK to insert a phrase below the first phrase").ToString());
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVR/JVR1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                
                //Reports.TestStep = "Create a Doc";
                //FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                //CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Refresh the screen using send keys on Document Preparation screen.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.DocumentPreparationMenu.NPBS.FAClick();
                while (true)
                {
                    FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                    FastDriver.DocumentPreparationMenu.NPBS.FAClick();
                    Playback.Wait(1000);
                    Keyboard.SendKeys("%p");
                    Playback.Wait(1000);
                    Keyboard.SendKeys("r");
                    value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                    if (value == "Do you wish to refresh this Phrase?")
                        break;
                }
                
                Reports.TestStep = "Do you wish to refresh this Phrase?.";
                Support.AreEqual(@"Do you wish to refresh this Phrase?", value);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                
                Reports.TestStep = "Validate for Phrase existance";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                try
                {
                    var span = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Contains("TRNS/34B"));
                    Support.AreEqual(@"2", span.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }
                
                Reports.TestStep = "Move the Phrase or change the Order of Phrases.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                FastDriver.DocumentPreparationMenu.NPBS.FAClick();
                Playback.Wait(5000); 
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); 
                Keyboard.SendKeys("o");
                while(true)
                {
                    try
                    {
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Re-Sequence", true, 20);
                        FastDriver.PhraseResequenceDlg.SwitchToDialogContentFrame();
                        FastDriver.PhraseResequenceDlg.WaitCreation(FastDriver.PhraseResequenceDlg.PhraseTable);
                        break;
                    }
                    catch (Exception)
                    {
                        FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                        FastDriver.DocumentPreparationMenu.NPBS.FAClick();
                        Playback.Wait(5000);
                        Keyboard.SendKeys("%p");
                        Playback.Wait(1000);
                        Keyboard.SendKeys("o");
                    }
                    
                }

                Reports.TestStep = "Select the Phrase and Move.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Re-Sequence", true, 20);
                FastDriver.PhraseResequenceDlg.WaitForScreenToLoad();
                FastDriver.PhraseResequenceDlg.PhraseTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.PhraseResequenceDlg.PhraseTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.PhraseResequenceDlg.PhraseTable.PerformTableAction("Phrase Name", "JVR1 Phrase Description", "Phrase Name", TableAction.Click);
                FastDriver.PhraseResequenceDlg.Up.FAClick();

                Reports.TestStep = "Select the Phrase and Move.";
                FastDriver.PhraseResequenceDlg.PhraseTable.PerformTableAction("Phrase Name", "JVR1 Phrase Description", "Phrase Name", TableAction.Click);
                FastDriver.PhraseResequenceDlg.PhraseTable.PerformTableAction("Phrase Name", "Phrase Marker", "Phrase Name", TableAction.Click);
                FastDriver.PhraseResequenceDlg.Up.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                
                Reports.TestStep = "Click ALT+P.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                FastDriver.DocumentPreparationMenu.NPBS.FAClick();
                Playback.Wait(3000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");
                while (true)
                {
                    try
                    {
                        FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                        break;
                    }
                    catch (Exception)
                    {
                        FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                        FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                        FastDriver.DocumentPreparationMenu.NPBS.FAClick();
                        Playback.Wait(5000);
                        Keyboard.SendKeys("%p");
                        Playback.Wait(1000);
                        Keyboard.SendKeys("p");
                    }

                }

                Reports.TestStep = "Enter the Description and add Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify for the Lock Image-Phrase is not editable.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.DocumentPreparationwin.LockImage.Exists().ToString());
                
                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(5000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");
                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("JVR/JVR1", true, 20);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Refresh the screen us send keys on Document Preparation screen.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                while (true)
                {
                    FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                    FastDriver.DocumentPreparationMenu.NPBS.FAClick();
                    Playback.Wait(1000);
                    Keyboard.SendKeys("%p");
                    Playback.Wait(1000);
                    Keyboard.SendKeys("r");
                    value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                    if (value == "Do you wish to refresh this Phrase?")
                        break;
                }
                
                Reports.TestStep = "Do you wish to refresh this Phrase?.";
                Support.AreEqual(@"Do you wish to refresh this Phrase?", value);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                
                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();
                Playback.Wait(3000);

                Reports.TestStep = "Verify that new Phrase and Misc Phrase Deleted from document after reset the screen.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                try
                {
                    var span = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Clean().Contains("TRNS/34B"));
                    Support.AreEqual(@"2", span.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }
                
                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Delete. Please verify Manually that Document is removed.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source", multipleDocs: true);

                Reports.TestStep = "Navigate to document repository and verify saved doc.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.BusSource.FAClick();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(5000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");
                
                Reports.TestStep = "Inserting Outline.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("NPBS/NPBS", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                try
                {
                    IWebElement img = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(p => p.GetAttribute("src").Contains("images/ico_numlist.gif"));
                    img.FAClick();
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Error searching for element: " + e.Message, false);
                }

                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click ALT+A Under Phrase Tab.";
                while (true)
                {
                    FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                    FastDriver.DocumentPreparationMenu.NPBS.FAClick();
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%p");
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("a");
                    value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                    if (value.Contains("Phrase NPBS/NPBS - Data Element Bus ID Dby Cont Name will be added to the Pending phrase group"))
                        break;
                }
                
                Reports.TestStep = "Data Element Bus ID Dby Cont Name will be added to the Pend phrase group.";
                //value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                //if(AutoConfig.UseCDFormType)
                //    Support.AreEqual(@"True", value.Contains("Phrase TRNS/34B - 34B will be added to the Pending phrase group").ToString());
                //else
                Support.AreEqual(@"True", value.Contains("Phrase NPBS/NPBS - Data Element Bus ID Dby Cont Name will be added to the Pending phrase group").ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                
                Reports.TestStep = "Click ALT+V Under Phrase Tab.";
                Playback.Wait(5000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("v");
                //Playback.Wait(8000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("^C");
                string content = System.Windows.Forms.Clipboard.GetText(TextDataFormat.UnicodeText);
                Debug.Print(content);
                if (content != "" && !content.Contains("Error"))
                    Reports.StatusUpdate("Phrase Content is present: " + content, true);
                else
                    Reports.StatusUpdate("Error ocurring on ViewPhrase operation", false);
                Keyboard.SendKeys("%{F4}");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                Reports.TestStep = "Click on Phrase Link and Press ALT+S.";
                while (true)
                {
                    FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                    Playback.Wait(1000);
                    Keyboard.SendKeys("%p");
                    Playback.Wait(1000);
                    Keyboard.SendKeys("s");
                    value = FastDriver.WebDriver.HandleDialogMessage(false, true).Clean();
                    if (value == "Click OK to insert the phrase below the first phrase, Cancel to insert a phrase above the first phrase.")
                        break;
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                }
                
                Reports.TestStep = "Click OK to insert the phrase below the first phrase Cancel to insert a phrase above the first phrase-Click on OK.";
                Support.AreEqual(@"Click OK to insert the phrase below the first phrase, Cancel to insert a phrase above the first phrase.", value);
                Playback.Wait(2000);

                Reports.TestStep = "Click on OK without enter any data in Misc Phrase Dialog.";
                Keyboard.SendKeys("{DELETE}");
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click ALT+D Under Phrase Tab.";
                while (true)
                {
                    try
                    {
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                        FastDriver.EditorDeleteDlg.SwitchToDialogContentFrame();
                        break;
                    }
                    catch (Exception)
                    {
                        FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                        FastDriver.DocumentPreparationMenu.NPBS.FAClick();
                        Playback.Wait(1000);
                        Keyboard.SendKeys("%p");
                        Playback.Wait(1000);
                        Keyboard.SendKeys("d");
                    }
                                        
                }
                
                Reports.TestStep = "Delete the Phrase.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                //FastDriver.EditorDeleteDlg.SwitchToDialogContentFrame();
                FastDriver.EditorDeleteDlg.SelectAll.FAClick();
                Support.AreEqual("True", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText(@"Removing/Waiving all the Phrases.");
                FastDriver.DialogBottomFrame.ClickDone();
                
                Reports.TestStep = "At least one phrase must remain for document to exist. Please try again.";
                Support.AreEqual(@"At least one phrase must remain for document to exist. Please try again.", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean());

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false, timeout: 20);

                Reports.TestStep = "Delete the Phrase.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                FastDriver.EditorDeleteDlg.WaitForScreenToLoad();
                FastDriver.EditorDeleteDlg.SelectAll.FAClick();
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText(@"Removing/Waiving all the Phrases.");
                if (FastDriver.EditorDeleteDlg.FirstCheckBox.Selected)
                    FastDriver.EditorDeleteDlg.FirstCheckBox.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                
                Reports.TestStep = "Preview the Document-ALT+V Under Document TAB.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0005()
        {
            try
            {
                Reports.TestDescription = "DP3388_ADM_REVERTING_BACK_CHANGES: Verify that Pending Phrase Added to the Pending Group-The Pending Group code is PENDING, description is Pending Phrase Group, and checking the editable check box.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PhraseGroupName1 = "";
                string NewPhrase1 = "";
                #endregion

                #region GUI interaction

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                PhraseGroupName1 = Support.RandomString("AAAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(PhraseGroupName1);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText(@"Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText(@"Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                NewPhrase1 = Support.RandomString("NZNA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(NewPhrase1);
                FastDriver.PhraseMaintenance.Description.FASetText(@"New created phrase1");
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseMaintenance.SwitchToContentFrame();
                string desc = FastDriver.PhraseMaintenance.Description.FAGetValue().Clean();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");//added
                sendKeysToPhraseEditor("^", "{SPACE}");//added
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Home Warranty Information");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"HWBPHX");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText(@"Automation*");
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", PhraseGroupName1, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "New created phrase1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.Statuschangecomments.FAClick();
                if (FastDriver.PhraseMaintenance.Editable.Selected)
                    FastDriver.PhraseMaintenance.Editable.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.PhraseMaintenance.Editable.Selected.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                if (!FastDriver.PhraseMaintenance.Editable.Selected)
                    FastDriver.PhraseMaintenance.Editable.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText(@"Automation*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", PhraseGroupName1, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                
                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "New created phrase1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Verify the editable check box is checked.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Editable.Selected.ToString());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search for a phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem(@"Miscellaneous Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText(@"Pending Phrase Group");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

                Reports.TestStep = "To verify that Pending Phrase is Present.";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Description", "Pending Phrase Group", "Description", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                
                Reports.TestStep = "To verify that Pending Phrase is added to the Pending Phrase Group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "NPBS/NPBS - Data Element Bus ID Dby Cont", 2, TableAction.Click);
                
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0006()
        {
            try
            {
                Reports.TestDescription = "3454_3459_3460_3461_3463: Once a document is finalized, it may only be delivered.  It may not be updated, nor edited; until the document has been unfinalized and it apply to Whole Document.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                if (!FastDriver.DocumentPreparationMenu.menuPhraseEdit.GetAttribute("style").Contains("display: none"))
                    Reports.StatusUpdate("Edit option is not available when document is in finalize state", false);
                else
                    Reports.StatusUpdate("Edit option is available when document is in finalize state", true);

                Reports.TestStep = "Click ALT+V Under Phrase Tab.";
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("^C");
                string content = System.Windows.Forms.Clipboard.GetText(TextDataFormat.UnicodeText);
                Debug.Print(content);
                if (content != "" && !content.Contains("Error"))
                    Reports.StatusUpdate("Phrase Content is present: " + content, true);
                else
                    Reports.StatusUpdate("Error ocurring on ViewPhrase operation", false);
                Keyboard.SendKeys("%{F4}");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                Reports.TestStep = "Refresh the screen us send keys on Document Preparation screen.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                if (!FastDriver.DocumentPreparationMenu.menuPhraseRefresh.GetAttribute("style").Contains("display: none"))
                    Reports.StatusUpdate("Refresh option is not available when document is in finalize state", false);
                else
                    Reports.StatusUpdate("Refresh option is available when document is in finalize state", true);

                Reports.TestStep = "Preview the Document-ALT+V Under Document TAB.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0007()
        {
            try
            {
                Reports.TestDescription = "Verify_DP3462_DP3464_ADM: Uncheck Editable check box.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PhraseGroupName1 = "";
                string NewPhrase1 = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for a phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText(@"QFE BUS*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

                Reports.TestStep = "To verify the search result.";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "QFE BUS/DBY", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(3, "Active", 3, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Edit the phrase.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.Statuschangecomments.FAClick();

                Reports.TestStep = "Verify the editable check box is Unchecked.";
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Editable.Selected.ToString());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0008()
        {
            try
            {
                Reports.TestDescription = "Verify_DP3462_DP3464_3465_IIS: NegVerify the Lock Image if Document is finalized no Notification will be accepted from change in ADM, Removing the finalized status.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify that No Lock Image.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                Support.AreEqual(@"False", FastDriver.DocumentPreparationwin.LockImage.Exists().ToString());

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                                
                Reports.TestStep = "Un Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"UnFinalized");
                                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");

                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("NPBS/NPBS", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                Playback.Wait(1000);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying tha Finalized Event.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Document Finalized]", "Event", TableAction.Click);

                Reports.TestStep = "Verifying tha Un-Finalized Event.";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Document Unfinalized]", "Event", TableAction.Click);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0009()
        {
            try
            {
                Reports.TestDescription = "DP3569_DP3394_DP4927: Draft Watermark,Un-Waiving a Phrase, Waive-Un-waive Multiple Phrases.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                Support.AreEqual(@"False", FastDriver.DocumentPreparationwin.LockImage.Exists().ToString());
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"UnFinalized");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");
                FastDriver.WebDriver.WaitForWindowAndSwitch("NPBS/NPBS", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                Playback.Wait(1000);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Document Finalized]", "Event", TableAction.Click);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Document Unfinalized]", "Event", TableAction.Click);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Delete. Please verify Manually that Document is removed.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source", multipleDocs: true);
                
                Reports.TestStep = "To navigate to document repository and verify saved doc.";
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+D Under Tools Tab.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DocumentPreparationwin.LockImage.Exists().ToString());

                Reports.TestStep = "Press ALT+D Under Tools Tab.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%t");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                FastDriver.DocumentPreparationMenu.MenuToolsDraft.FAClick();
                //Keyboard.SendKeys("d");
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "To navigate to document repository and Click on Water Mark to verify Draft.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.WMEllipsis.FAClick();

                Reports.TestStep = "Verify that Water Mark is Draft.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Edit Document", true, 20);
                FastDriver.WatermarkDlg.WaitForScreenToLoad();
                //FastDriver.WatermarkDlg.WaitCreation(FastDriver.WatermarkDlg.SelectWaterMark, 5);
                Support.AreEqual(@"Draft", FastDriver.WatermarkDlg.SelectWaterMark.FAGetSelectedItem().Clean());
                Keyboard.SendKeys("^Q");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                
                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+P Under Tools Tab.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.DocumentPreparationwin.LockImage.Exists().ToString());

                Reports.TestStep = "Press ALT+P Under Tools Tab.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%t");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(3000);

                Reports.TestStep = "To navigate to document repository and Click on Water Mark to verify Draft.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.WMEllipsis.FAClick();
                
                Reports.TestStep = "Verify that Water Mark is Pro forma.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Edit Document", true, 20);
                FastDriver.WatermarkDlg.WaitForScreenToLoad();
                //FastDriver.WatermarkDlg.WaitCreation(FastDriver.WatermarkDlg.SelectWaterMark, 5);
                Support.AreEqual(@"Pro forma", FastDriver.WatermarkDlg.SelectWaterMark.FAGetSelectedItem().Clean());
                Keyboard.SendKeys("^Q");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                
                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+P Under Tools Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%t");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(3000);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Delete. Please verify Manually that Document is removed.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();

                Reports.TestStep = "Select template & click on save button.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.AdHocDocuments.State.FASelectItem("CA");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTA A - Construction Loan Policy-N");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTA A - Construction Loan Policy-N", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateEdit.FAClick();
                Playback.Wait(4000);
                
                Reports.TestStep = "Press ALT+W Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(4000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("w");
                Playback.Wait(2000);

                Reports.TestStep = "Delete the Phrase.";
                FastDriver.EditorDeleteDlg.WaitForScreenToLoad();
                FastDriver.EditorDeleteDlg.SelectAll.FAClick();
                Support.AreEqual(@"True", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText("Removing/Waiving all the Phrases.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                Reports.TestStep = "Verifieng tha Removed Document  Event.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Removed Document]", "User", TableAction.GetText).Message);
                
                Reports.TestStep = "Verifieng tha Waived Event and User name.";
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Phrase Waived]", "User", TableAction.GetText).Message);
                
                Reports.TestStep = "Verifieng tha Waived Event and Source.";
                Support.AreEqual(@"QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Phrase Waived]", "Source", TableAction.GetText).Message);
                
                Reports.TestStep = "Verifieng tha Waived Event and Comments.";
                Support.AreEqual(@"Phrase 'zALTA A Construction Loan Policy' was waived in document 'ALTA A - Construction Loan Policy-N'. The reason is: Removing/Waiving all the Phrases.",
                    FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Phrase Waived]", "Comments", TableAction.GetText).Message);
                
                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Press ALT+W Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("w");
                
                Reports.TestStep = "Unwave The Document.";
                FastDriver.EditorDeleteDlg.WaitForScreenToLoad();
                FastDriver.EditorDeleteDlg.UnSelectAll.FAClick();
                Support.AreEqual(@"False", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText("UnWaiving all the Phrases.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verifieng tha UnWaived Event and User name.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Phrase un-waived]", "User", TableAction.GetText).Message);
                                
                Reports.TestStep = "Verifieng tha UnWaived Event and Source.";
                Support.AreEqual(@"QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Phrase un-waived]", "Source", TableAction.GetText).Message);

                Reports.TestStep = "Verifieng tha Un Waived Event and Comments.";
                Support.AreEqual(@"Phrase 'zALTA A Construction Loan Policy' was un-waived in document 'ALTA A - Construction Loan Policy-N'. The reason is: UnWaiving all the Phrases.", 
                    FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Phrase un-waived]", "Comments", TableAction.GetText).Message);
                
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0010()
        {
            try
            {
                Reports.TestDescription = "DP4926: 1 :DP4926 : Document Refresh. Create Template Without Phrase in ADM.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string InformationTemplateName = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Click on New button.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Provide template name, description & comments.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                InformationTemplateName = Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(InformationTemplateName);
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(@"Template for DPUC0002");
                if (FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.Selected)
                    FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FAClick();
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText(@"InformationComment");
                
                Reports.TestStep = "Enter data on Formatting TAB.";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFormating.MiddlePages.FAClick();
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();
                FastDriver.TemplateMaintenanceFormating.FormattingHeaderPhrase.FASelectItem(@"Header Ph1");
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItem(@"Footer Phrase one");
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItem(@"test");
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItem(@"Test Phrase");
                FastDriver.TemplateMaintenanceFormating.FormattingMarginTop.FASetText(@"0.5");
                FastDriver.TemplateMaintenanceFormating.FormattingMarginBottom.FASetText(@"0.5");

                Reports.TestStep = "Add phrase to the Template";//This is an additional TestStep need it to look up for the Template later on IIS
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Set Filters to ALL";//This is an additional TestStep need it to look up for the Template later on IIS
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateFilterSelectionDlg.ServiceTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.TrassactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProgrammeTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");

                Reports.TestStep = "Verify that Template is created and Select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "Template for DPUC0002", 2, TableAction.Click);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0011()
        {
            try
            {
                Reports.TestDescription = "DP3369: 1: DP3369 :Document Must contain at least 1 Phrase.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                
                Reports.TestStep = "verify that When no Phrase is there in Document then it wont appear in File Side.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys(@"Endorsement/Guarantee");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Template for DPUC0002");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                Reports.StatusUpdate("Template available.", FastDriver.AdHocDocuments.SearchResultsTable.GetRowCount() >= 1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0012()
        {
            try
            {
                Reports.TestDescription = "DP3405_DP3406: 1: DP3405 : Phrase must be setup in the system,2: DP3406 : Insertion by direct entry of the code.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string InformationTemplateName = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                cleanTemplateMaintenanceSummary(credentials);
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.New.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                InformationTemplateName = Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(InformationTemplateName);
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(@"Template for DPUC0002");
                if (FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.Selected)
                    FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FAClick();
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText(@"InformationComment");
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFormating.MiddlePages.FAClick();
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();
                FastDriver.TemplateMaintenanceFormating.FormattingHeaderPhrase.FASelectItem(@"Header Ph1");
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItem(@"Footer Phrase one");
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItem(@"test");
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItem(@"Test Phrase");
                FastDriver.TemplateMaintenanceFormating.FormattingMarginTop.FASetText(@"0.5");
                FastDriver.TemplateMaintenanceFormating.FormattingMarginBottom.FASetText(@"0.5");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");

                Reports.TestStep = "Verify that Template is created and Select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(1, InformationTemplateName.ToUpper(), 2, TableAction.Click);
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad().ClickPhrasesTab().WaitForScreenToLoad();
                //FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad().ClickPhrasesTab().WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify that selected phrase added to phrases table.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", "JVE/JV01", "Required", TableAction.On);

                Reports.TestStep = "Set Filters to ALL";//This is an additional TestStep need it to look up for the Template later on IIS\
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Filter Selection", true, 20);
                FastDriver.TemplateFilterSelectionDlg.SwitchToDialogContentFrame();
                FastDriver.TemplateFilterSelectionDlg.ServiceTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.TrassactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProgrammeTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0013()
        {
            try
            {
                Reports.TestDescription = "DP3354_DP3458: 3: DP3354 : Unresolved data element display,4: DP3458 : Save feature available at any time.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.AdHocDocuments.State.FASelectItem("CA");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTA A - Construction Loan Policy-N");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTA A - Construction Loan Policy-N", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateEdit.FAClick();
                Playback.Wait(3000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("w");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                FastDriver.EditorDeleteDlg.SwitchToDialogContentFrame();
                FastDriver.EditorDeleteDlg.SelectAll.FAClick();
                Support.AreEqual(@"True", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText("Removing/Waiving all the Phrases.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("w");
                FastDriver.EditorDeleteDlg.WaitForScreenToLoad();
                FastDriver.EditorDeleteDlg.UnSelectAll.FAClick();
                Support.AreEqual(@"False", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText("UnWaiving all the Phrases.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                
                Reports.TestStep = "verify that if at least one Phrase is in Document it will reflect in File Side.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Template for DPUC0002");
                FastDriver.AdHocDocuments.State.FASelectItem("CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Template for DPUC0002", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateEdit.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Verify the Phrase name added in ADM.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                try
                {
                    var value = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Clean() == ("JVE/JV01**") && p.Displayed);
                    Support.AreEqual(@"1", value.ToString());
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0014()
        {
            try
            {
                Reports.TestDescription = "DP3407_DP3409_ADM: 1: DP3409 : Positioning a Phrase.2:DP407Phrase Selection.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string InformationTemplateName = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");

                Reports.TestStep = "Verify that Template is created and Select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "Template for DPUC0002", 2, TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Verify the template Name and Type.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                Support.AreEqual(@"Template for DPUC0002", FastDriver.TemplateMaintenanceInformation.InformationDescription.FAGetValue().Clean());
                if (FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.Selected)
                    FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FAClick();

                Reports.TestStep = "Click on Edit Phrase Tab.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhraseTable.PerformTableAction(1, "JVE/JV01", 2, TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link after Move to end line.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("JV01 - JV01", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                //FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Select a data element & enter the value.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Home Warranty Information");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"HWBPHX");
                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select the Element Name from Phrase editor and Click on Cut Button then pasting on the same phrase.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("JV01 - JV01", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "A");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/Cut.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                //FastDriver.PhraseEditorDlg.Cut.FAClick();
                sendKeysToPhraseEditor("^", "V");
                
                Reports.TestStep = "After Moving cursor to end line.";
                Playback.Wait(2000);
                sendKeysToPhraseEditor("", "{END}");
                Playback.Wait(2000);
                sendKeysToPhraseEditor("", "{LEFT}");
                sendKeysToPhraseEditor("", "{LEFT}");

                Reports.TestStep = "Click on Show Properties Image.";
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/props.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                //FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();

                Reports.TestStep = "Enter Question Mark in Index Field.";
                FastDriver.DataElementsDlg.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.DataElementsDlg.CatalogDescription.Enabled.ToString());
                FastDriver.DataElementsDlg.Index.FASetText(@"?");
                FastDriver.DataElementsDlg.Ok.FAClick();
                
                Reports.TestStep = "Click on Show Properties Image.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("JV01 - JV01", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("", "{END}");
                Playback.Wait(5000);
                sendKeysToPhraseEditor("", "{LEFT}");
                sendKeysToPhraseEditor("", "{LEFT}");
                FastDriver.WebDriver.FindElements(By.TagName("img")).FirstOrDefault(i => i.GetAttribute("src").Contains("images/props.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                //FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();

                Reports.TestStep = "Enter Valid Value in Index Field.";
                FastDriver.DataElementsDlg.WaitForScreenToLoad();                
                Support.AreEqual(@"False", FastDriver.DataElementsDlg.CatalogDescription.Enabled.ToString());
                FastDriver.DataElementsDlg.Index.FASetText(@"2");
                FastDriver.DataElementsDlg.Ok.FAClick();
                
                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("JV01 - JV01", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Second Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"SecondPhraseInQQZQ");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"TDS/TDS");
                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                Reports.TestStep = "Verify that when new phrase added to the Template system will add it at the Bottom and we can move it as per requirement.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhraseTable.PerformTableAction(1, "TDS/TDS", 2, TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesUp.FAClick();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0015()
        {
            Reports.TestDescription = "DP3408_IIS: 1: DP3408 : View Phrase Text.";

            #region data setup//change credentials here
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            #endregion

            #region GUI interaction

            Reports.TestStep = "Login to FAST IIS";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            Reports.TestStep = "Create a detailed File";
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
            FastDriver.DocumentRepository.Add.FAClick();
            FastDriver.AdHocDocuments.WaitForScreenToLoad();
            FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
            FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
            FastDriver.AdHocDocuments.State.FASelectItem("CA");
            FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTA A - Construction Loan Policy-N");
            FastDriver.AdHocDocuments.FindNow.FAClick();
            FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTA A - Construction Loan Policy-N", "Description", TableAction.Click);
            FastDriver.AdHocDocuments.CreateEdit.FAClick();
            Playback.Wait(3000);
            FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
            Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%p");
            Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("w");
            FastDriver.EditorDeleteDlg.WaitForScreenToLoad();
            FastDriver.EditorDeleteDlg.SelectAll.FAClick();
            Support.AreEqual(@"True", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
            FastDriver.EditorDeleteDlg.ReasonNote.FASetText("Removing/Waiving all the Phrases.");
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(250);
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
            FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
            FastDriver.DocumentRepository.Edit.FAClick();
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%p");
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("w");
            FastDriver.EditorDeleteDlg.WaitForScreenToLoad();
            FastDriver.EditorDeleteDlg.UnSelectAll.FAClick();
            Support.AreEqual(@"False", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
            FastDriver.EditorDeleteDlg.ReasonNote.FASetText("UnWaiving all the Phrases.");
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(250);
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
            FastDriver.DocumentRepository.AddDocRep.FAClick();
            FastDriver.AdHocDocuments.WaitForScreenToLoad();
            FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
            FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
            FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Template for DPUC0002");
            FastDriver.AdHocDocuments.State.FASelectItem("CA");
            FastDriver.AdHocDocuments.FindNow.FAClick();
            FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Template for DPUC0002", "Description", TableAction.Click);
            FastDriver.AdHocDocuments.CreateSave.FAClick();
            Playback.Wait(5000);
 
            Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template for DPUC0002", 4, TableAction.Click);
            FastDriver.DocumentRepository.Edit.FAClick();

            Reports.TestStep = "Refresh the screen us send keys on Document Preparation screen.";
            FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%p");
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("r");

            Reports.TestStep = "Do you wish to refresh this Phrase?.";
            Support.AreEqual(@"Do you wish to refresh this Phrase?", FastDriver.WebDriver.HandleDialogMessage().Clean());
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            
            Reports.TestStep = "Verify Manually in screen that Element added in Phrase is reflect file side.";
            FastDriver.DocumentPreparationwin.SwitchToContentFrame();
            if(FastDriver.DocumentPreparationwin.firstBusPhoneAndExtNo.Displayed)
                Reports.StatusUpdate("Element 'firstBusPhoneAndExtNo' is present on the screen.", true);
            else
                Reports.StatusUpdate("Element 'firstBusPhoneAndExtNo' is present on the screen.", false);

            #endregion GUI interaction

        }

        [TestMethod]
        public void DPUC0002_REG0016()
        {
            try
            {
                Reports.TestDescription = "DP3939_DP3978_DP4006_ADM: 1: DP3939 : Multiple Phrase Markers,2: DP3978 : Auto-Outline Number reset3: DP4006 : Auto Outline Number reset.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");

                Reports.TestStep = "Verify that Template is created and Select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "Template for DPUC0002", 2, TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Delete the Phrases and Phrase markers.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                
                Reports.TestStep = "Adding Phrase Marker.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker.FAClick();

                Reports.TestStep = "Click on Phrase marker Edit button.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Edit the added Phrase Marker.";
                FastDriver.EditPhraseMarkerPropertiesDlg.WaitForScreenToLoad();
                if (!FastDriver.EditPhraseMarkerPropertiesDlg.PageBreak.Selected)
                    FastDriver.EditPhraseMarkerPropertiesDlg.PageBreak.FAClick();
                if (!FastDriver.EditPhraseMarkerPropertiesDlg.AutoOutlineRestart.Selected)
                    FastDriver.EditPhraseMarkerPropertiesDlg.AutoOutlineRestart.FAClick();
                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify the Phrase market added.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhraseTable.PerformTableAction(2, "PhraseMarker", 2, TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesUp.FAClick();

                Reports.TestStep = "Adding Phrase Marker.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesPhraseMarker.FAClick();

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();
                
                Reports.TestStep = "Enter the Description and add Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0017()
        {
            try
            {
                Reports.TestDescription = "DP3939_DP3978_DP4006_DP3380_IIS: 1: DP3939 : Multiple Phrase Markers.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.AdHocDocuments.State.FASelectItem("CA");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTA A - Construction Loan Policy-N");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTA A - Construction Loan Policy-N", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA A - Construction Loan Policy-N", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("w");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                FastDriver.EditorDeleteDlg.SwitchToDialogContentFrame();
                FastDriver.EditorDeleteDlg.SelectAll.FAClick();
                Support.AreEqual(@"True", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText("Removing/Waiving all the Phrases.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("w");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Editor", true, 20);
                FastDriver.EditorDeleteDlg.SwitchToDialogContentFrame();
                FastDriver.EditorDeleteDlg.UnSelectAll.FAClick();
                Support.AreEqual(@"False", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText("UnWaiving all the Phrases.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Template for DPUC0002");
                FastDriver.AdHocDocuments.State.FASelectItem("CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Template for DPUC0002", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template for DPUC0002", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Select the Phrase Marker and send keys of edit.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                FastDriver.DocumentPreparationwin.PhraseMarker.FAClick();

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");
                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("JVE/JV01 - JV01", true, 20);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                Reports.TestStep = "Preview the Document-ALT+V Under Document TAB.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template for DPUC0002", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0018()
        {
            try
            {
                Reports.TestDescription = "ADM_SETUP: Deleting the Phrase and phrase markers and adding again.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");

                Reports.TestStep = "Verify that Template is created and Select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "Template for DPUC0002", 2, TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Delete the Phrases and Phrase markers.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Phrase to verify on File side.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Business Source Contact Info.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"BSCI/BSCI");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Phrase to verify on File side.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Business Source Contact Info.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"VTST/PHR1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify the Phrase added.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", "VTST/PHR1", "Name", TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesUp.FAClick();

                Reports.TestStep = "Set Filters to ALL";//This is an additional TestStep need it to look up for the Template later on IIS
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateFilterSelectionDlg.ServiceTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.TrassactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProgrammeTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                string DPUC0002REG0018TemplateName = FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FAGetValue().Clean();
                
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0019()
        {
            try
            {
                Reports.TestDescription = "DP3375_DP3380_DP3381_DP3382_DP3383_DP3374_DP3401_DP3410_DP3456_DP3457_EWC06_EWC09: 1:Display Order,2:Phrases containing data text elements 3:Display Data Element 4:Refresh Elements Automatically 5:Element Description 6:T";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                #region Pre-Condition

                Reports.TestStep = "Add missing element to phrase.";
                AddElementToPhrase();

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");

                Reports.TestStep = "Verify that Template is created and Select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "Template for DPUC0002", 2, TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Delete the Phrases and Phrase markers.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Phrase to verify on File side.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Business Source Contact Info.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"BSCI/BSCI");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Phrase to verify on File side.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Business Source Contact Info.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"VTST/PHR1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify the Phrase added.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", "VTST/PHR1", "Name", TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesUp.FAClick();

                Reports.TestStep = "Set Filters to ALL";//This is an additional TestStep need it to look up for the Template later on IIS
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateFilterSelectionDlg.ServiceTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.TrassactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProgrammeTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                string DPUC0002REG0018TemplateName = FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FAGetValue().Clean();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "verify that if at least one Phrase is in Document it will reflect in File Side.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.AdHocDocuments.State.FASelectItem("CA");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Template for DPUC0002");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Template for DPUC0002", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateEdit.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);                

                Reports.TestStep = "Chang the Business Source contacts.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                if (!FastDriver.FileHomepage.BusinessPartyEditCont.Selected)
                    FastDriver.FileHomepage.BusinessPartyEditCont.FAClick();
                FastDriver.FileHomepage.BusinessPartyBusPhone.FASetText(@"1111111111");
                FastDriver.FileHomepage.BusinessPartyBusFax.FASetText(@"2222222222");
                FastDriver.FileHomepage.BusinessPartyCellPhone.FASetText(@"3333333333");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template for DPUC0002", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                                                
                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Un Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Unfinalized");

                Reports.TestStep = "Click on Done in Dialog Box."; 
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                //this is an additional step
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(250);
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                FastDriver.Insuranceflood.FindGAB("HUDFLINSR1");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template for DPUC0002", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify the Business Contacts for the Business source.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                string[] temp = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(i => i.Text == "BSCI/BSCI").GetAttribute("id").Split('_'); 

                Reports.TestStep = "Verify the Business Contacts for the Business source.";
                Support.value = FastDriver.WebDriver.FindElement(By.Id("grdDocuments_" + temp[1] + "_grdDocPhrase_0_txttextData")).FAGetValue().Clean();
                Support.AreEqual(@"(222)222-2222", Support.value);

                Support.value = FastDriver.WebDriver.FindElement(By.Id("grdDocuments_" + temp[1] + "_grdDocPhrase_1_txttextData")).FAGetValue().Clean();
                Support.AreEqual(@"(111)111-1111", Support.value);

                Support.value = FastDriver.WebDriver.FindElement(By.Id("grdDocuments_" + temp[1] + "_grdDocPhrase_2_txttextData")).FAGetValue().Clean();
                Support.AreEqual(@"(333)333-3333", Support.value);

                Support.value = FastDriver.WebDriver.FindElement(By.Id("grdDocuments_" + temp[1] + "_grdDocPhrase_3_txttextData")).FAGetValue().Clean();
                Support.AreEqual(@"busparty@regression.com", Support.value);

                Support.value = FastDriver.WebDriver.FindElement(By.Id("grdDocuments_" + temp[1] + "_grdDocPhrase_4_txttextData")).FAGetValue().Clean();
                Support.AreEqual(@"(982)541-5845", Support.value);

                Reports.TestStep = "Enter Rich Text in Text Column so that it will display in More than two lines for address.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                FastDriver.DocumentPreparationwin.BusinessAddressLine1.FASetText(@"BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1BusinessAddressLine1");
                Support.AreEqual(@"BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1 BusinessAddressLine1BusinessAddressLine1",
                    FastDriver.DocumentPreparationwin.BusinessAddressLine1.FAGetValue().Clean());

                Reports.TestStep = "Verify for the Broken Image after edit the Address in Phrase.";
                try
                {
                    //var value = FastDriver.WebDriver.FindElements(By.TagName("span")).Count(p => p.Text.Clean() == "BSCI/BSCI");
                    if(FastDriver.DocumentPreparationwin.BSCI.Displayed)
                        Reports.StatusUpdate("Element present on the screen.", true);
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not present. Error: " + e.Message, false);
                }
            
                Reports.TestStep = "Refresh the Element us send keys under element Tab.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000);
                FastDriver.DocumentPreparationMenu.BSCI.FAClick();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%e");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("r");
                
                Reports.TestStep = "Do you wish to refresh this Data Element?.";
                Support.AreEqual(@"Do you wish to refresh this Data Element?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "Verify the Address line after refresh the Element.";
                Playback.Wait(5000);
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                Support.value = FastDriver.WebDriver.FAFindElement(ByLocator.Id, "grdDocuments_" + temp[1] + "_grdDocPhrase_6_txttextData").FAGetValue().Clean();
                if("Fire Insurance 1 business street 1" == Support.value)
                    Support.AreEqual(@"Fire Insurance 1 business street 1", Support.value);
                else
                    Support.AreEqual(@"Flood Insurance 1 mailing street 1", Support.value);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.EndorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Verify the Address line after refresh the Element.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();

                Support.value = FastDriver.WebDriver.FAFindElement(ByLocator.Id, "grdDocuments_" + temp[1] + "_grdDocPhrase_6_txttextData").FAGetValue().Clean();
                if ("Fire Insurance 1 business street 1" == Support.value)
                    Support.AreEqual(@"Fire Insurance 1 business street 1", Support.value);
                else
                    Support.AreEqual(@"Flood Insurance 1 mailing street 1", Support.value);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0020()
        {
            try
            {
                Reports.TestDescription = "DP3372_DP3474_DP3446: Adding Phrase and two element in Phrase.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");

                Reports.TestStep = "Verify that Template is created and Select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "Template for DPUC0002", 2, TableAction.Click);

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Delete the Phrases and Phrase markers.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesRemove.FAClick();

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Phrase to verify on File side.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify the Phrase added.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhraseTable.PerformTableAction(1, "JVE/JV01", 2, TableAction.Click);
                FastDriver.TemplateMaintenancePhrase.PhrasesUp.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                Reports.TestStep = "Click on Phrase marker Edit button.";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();
                
                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link after Move to end line.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("JV01 - JV01", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                sendKeysToPhraseEditor("^", "{END}");
                FastDriver.WebDriver.FindElements(By.TagName("img")).FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                
                Reports.TestStep = "Enter Buyer Type Element.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Buyer");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"BUASIGNM");
                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("JV01 - JV01", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();

                Reports.TestStep = "Direct Enter the Data Element name.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"HWLADD1");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("JV01 - JV01", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                                
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0021()
        {
            try
            {
                Reports.TestDescription = "DP3372_DP3474_DP3446_DP3447_IIS: 1: DP3372 : Phrase Order , 2:DP3474 : Cut and Paste Functionality  ,3:: DP3446 : Element Description,4 :Commitment/Policy phrase removal event.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string content = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Pre cond.: Set all phrases as Non Required.";
                MarkPhrasesAsNonRequired();

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                                
                Reports.TestStep = "verify that if at least one Phrase is in Document it will reflect in File Side.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.AdHocDocuments.State.FASelectItem("CA");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Template for DPUC0002");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Template for DPUC0002", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(5000);
                
                Reports.TestStep = "Click ALT+D Under Phrase Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template for DPUC0002", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("d");

                Reports.TestStep = "Delete the Phrase.";
                FastDriver.EditorDeleteDlg.WaitForScreenToLoad();
                FastDriver.EditorDeleteDlg.SelectAll.FAClick();
                Support.AreEqual(@"True", FastDriver.EditorDeleteDlg.FirstCheckBox.Selected.ToString());
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText(@"Removing/Waiving all the Phrases.");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "At least one phrase must remain for document to exist. Please try again.";
                Support.AreEqual(@"At least one phrase must remain for document to exist. Please try again.", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify that one Phrase added to the file and Two Element in that file.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                Reports.StatusUpdate(@"Phrases available.", FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "tr").Where(p => p.GetAttribute("id").Contains("grdDocuments_") && 
                    p.GetAttribute("name").Contains("grdDocuments$") && p.Displayed).Count() >= 2);
                try
                {
                    FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(p => p.Text.Clean() == "Home Warranty: Billing Address (Line 1)");
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not found. Error: " + e.Message, false);
                }

                Reports.TestStep = "Deliver the Document as text ALT+V Under Phrase TAB.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.DocumentPreparationMenu.JV01.FAClick();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("v");
                Playback.Wait(3000);
                while (true)
                {
                    try
                    {
                        FastDriver.WebDriver.WaitForWindowAndSwitch("");
                        Keyboard.SendKeys("^A");
                        Playback.Wait(1000);
                        Keyboard.SendKeys("^C");
                        content = System.Windows.Forms.Clipboard.GetText(TextDataFormat.UnicodeText);
                        Debug.Print(content);
                        if (content != "" && !content.Contains("Error"))
                            break;
                    }
                    catch (Exception e)
                    {
                        FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                        FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                        FastDriver.DocumentPreparationMenu.JV01.FAClick();
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("%p");
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("v");
                        Playback.Wait(3000);
                    }
                }
                if (content != "" && !content.Contains("Error"))
                    Reports.StatusUpdate("Phrase Content is present: " + content, true);
                else
                    Reports.StatusUpdate("Error ocurring on ViewPhrase operation", false);
                Keyboard.SendKeys("%{F4}");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click ALT+P.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.DocumentPreparationMenu.JV01.FAClick();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("p");

                Reports.TestStep = "Select Phrase type & enter name.";
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(@"JVR/JVR1");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                Reports.TestStep = "Verify that new Phrase and Misc Phrase added to the Document.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                try
                {
                    int count = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").Count(p => p.Text.Clean() == "JVR/JVR1");
                    Reports.StatusUpdate("Element present on the screen.", count >= 1);
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Element not found. Error: " + e.Message, false);
                }
                                
                Reports.TestStep = "Save the Document.";
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("s");

                Reports.TestStep = "Click ALT+D Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("d");

                Reports.TestStep = "Select the first check Box.";
                FastDriver.EditorDeleteDlg.WaitForScreenToLoad();
                if (!FastDriver.EditorDeleteDlg.FirstCheckBox.Selected)
                    FastDriver.EditorDeleteDlg.FirstCheckBox.FAClick();
                FastDriver.EditorDeleteDlg.ReasonNote.FASetText(@"UnWaiving all the Phrases.");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                
                Reports.TestStep = "Verify the One phrase has been deleted.";
                FastDriver.DocumentPreparationwin.SwitchToContentFrame();
                try
                {
                    Support.AreEqual(@"False", FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(p => p.Text.Clean() == "JVE/JV01").Exists().ToString());

                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Element not present!", true);
                }
                
                Reports.TestStep = "Preview the Document-ALT+V Under Document TAB.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("v");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0022()
        {
            try
            {
                Reports.TestDescription = "DP13397_DP10997_DP10998_DP10999_DP11000_EWC13: 1:Policy w/o Title Reports – Select Insured ,2:The system shall allow user to access Document Preparation Screen for Policy w/o Title Reports.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247");
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Policy w/o Title Reports", "Template created for 6.3 updates", "Template created for 6.3 updates");

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();

                Reports.TestStep = "Add Title Report.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Title Reports");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTERNATE FLOW 1 - QTP - DO NOT TOUCH");
                FastDriver.AdHocDocuments.State.FASelectItem(@"CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Verify that title report added.";
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                CreateDocument("Lender Policy", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "CA", multipleDocs: true);

                Reports.TestStep = "Verify that Lender Policy added.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                
                Reports.TestStep = "Print the Selected Document.";
                FastDriver.DocumentRepository.Method.FASelectItem(@"PRINT");
                FastDriver.DocumentRepository.Deliver.FAClick();

                Reports.TestStep = "Deliver unfinalized doc and verifying for error.";
                string value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                Support.AreEqual(@"True", value.Contains(@"Delivery of unfinalized Policies, Endorsements, and Guarantees is not allowed.").ToString());
                Support.AreEqual(@"True", value.Contains(@"Mark as Draft/Pro forma to Deliver.").ToString());
                CreateDocument("Owner Policy", "ALTA Ext Owner Policy 1402.06 (2006)", "ALTA Ext Owner Policy 1402.06 (2006)", multipleDocs: true);

                Reports.TestStep = "Verify that Owner Policy added.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                //FastDriver.DocumentRepository.OwnerPolicyElement.FAClick();

                Reports.TestStep = "Print the Selected Document.";
                FastDriver.DocumentRepository.Method.FASelectItem(@"PRINT");
                FastDriver.DocumentRepository.Deliver.FAClick();

                Reports.TestStep = "Deliver unfinalized doc and verifying for error.";
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                Support.AreEqual(@"True", value.Contains(@"Delivery of unfinalized Policies, Endorsements, and Guarantees is not allowed.").ToString());
                Support.AreEqual(@"True", value.Contains(@"Mark as Draft/Pro forma to Deliver.").ToString());
                
                Reports.TestStep = "Select FAX delivery.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.Method.FASelectItem(@"FAX");
                FastDriver.DocumentRepository.Deliver.FAClick();

                Reports.TestStep = "Deliver unfinalized doc and verifying for error.";
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                Support.AreEqual(@"True", value.Contains(@"Delivery of unfinalized Policies, Endorsements, and Guarantees is not allowed.").ToString());
                Support.AreEqual(@"True", value.Contains(@"Mark as Draft/Pro forma to Deliver.").ToString());
                
                Reports.TestStep = "Select EMAIL delivery.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.Method.FASelectItem(@"EMAIL");
                FastDriver.DocumentRepository.Deliver.FAClick();

                Reports.TestStep = "Deliver unfinalized doc and verifying for error.";
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                Support.AreEqual(@"True", value.Contains(@"Delivery of unfinalized Policies, Endorsements, and Guarantees is not allowed.").ToString());
                Support.AreEqual(@"True", value.Contains(@"Mark as Draft/Pro forma to Deliver.").ToString());
                
                Reports.TestStep = "Navigate to Doc rep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                
                Reports.TestStep = "Verify that Owner Policy added.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                //FastDriver.DocumentRepository.OwnerPolicyElement.FAClick();

                Reports.TestStep = "Enter Effective Date & Edit the document before delivering";
                FastDriver.DocumentRepository.Info.FAClick();
                Playback.Wait(250);
                FastDriver.DocumentRepository.WaitCreation(FastDriver.DocumentRepository.PWTREffectiveDate, 20);
                FastDriver.DocumentRepository.PWTREffectiveDate.FASetText("01-01-2015");
                FastDriver.DocumentRepository.InfoSave.FAClick();
                FastDriver.DocumentRepository.SearchResults.FAClick();
                FastDriver.DocumentRepository.SearchResults.FAClick();
                Playback.Wait(250);
                FastDriver.DocumentRepository.WaitCreation(FastDriver.DocumentRepository.Edit, 20);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                //FastDriver.DocumentRepository.OwnerPolicyElement.FAClick();

                Reports.TestStep = "Preview the selected Document.";
                FastDriver.DocumentRepository.Method.FASelectItem(@"PREVIEW");
                FastDriver.DocumentRepository.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");
                                
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0023()
        {
            try
            {
                Reports.TestDescription = "DP13397_DP11001_DP11002_DP11003_DP11004_EW13_EW17_EW18_EW20_EW16_EW15_EW14: Verify error warning conditions.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247");
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Policy w/o Title Reports", "Template created for 6.3 updates", "Template created for 6.3 updates");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Title Reports");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTERNATE FLOW 1 - QTP - DO NOT TOUCH");
                FastDriver.AdHocDocuments.State.FASelectItem(@"CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(3000);
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                CreateDocument("Lender Policy", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "CA", multipleDocs: true);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                CreateDocument("Owner Policy", "ALTA Ext Owner Policy 1402.06 (2006)", "ALTA Ext Owner Policy 1402.06 (2006)", multipleDocs: true);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                Playback.Wait(250);
                FastDriver.DocumentRepository.WaitCreation(FastDriver.DocumentRepository.PWTREffectiveDate);
                FastDriver.DocumentRepository.PWTREffectiveDate.FASetText("01-01-2015");
                FastDriver.DocumentRepository.InfoSave.FAClick();
                while (true)
                {
                    FastDriver.DocumentRepository.SearchResults.FAClick();
                    FastDriver.DocumentRepository.SearchResults.FAClick();
                    Playback.Wait(5000);
                    try
                    {
                        FastDriver.DocumentRepository.WaitCreation(FastDriver.DocumentRepository.Edit);
                        break;
                    }
                    catch (Exception){}
                }
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                
                Reports.TestStep = "Select Policy without title report and Click edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template created for 6.3 updates", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "You must have an effective Date.";
                Support.AreEqual(@"You must have an effective Date", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click Info.";
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Click on save.";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "You must have an effective Date.";
                Support.AreEqual(@"You must have an Effective Date!", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "Enter effective date and click on Save.";
                FastDriver.DocumentInfo.SwitchToContentFrame();
                string value = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.DocumentInfo.policywotitlereporteffectiveDate.FASetText(value);
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Insured is Required.";
                Support.AreEqual(@"Insured is Required", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "verify exit with out save message and click on OK button.";
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual(@"Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Create Buyer with Exchange Company.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys(@"Individual");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(@"Buyer1FN");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText(@"EXCH01");
                FastDriver.ExchangeCompany.Find.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Policy without title report and Click edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template created for 6.3 updates", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                
                Reports.TestStep = "You must have an effective Date.";
                Support.AreEqual(@"You must have an effective Date", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "Click Info.";
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Select seller and click on save.";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                if (!FastDriver.DocumentInfo.Buyercheckbox.Selected)
                    FastDriver.DocumentInfo.Buyercheckbox.FAClick();
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "seller cannot be selected as insured.";
                Support.AreEqual(@"You must have an Effective Date!", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Uncheck Lender and click on save.";
                FastDriver.DocumentInfo.SwitchToContentFrame();
                if (FastDriver.DocumentInfo.LenderCheckBox.Selected)
                    FastDriver.DocumentInfo.LenderCheckBox.FAClick();
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                Support.AreEqual(@"You must have an Effective Date!", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.DocumentInfo.SwitchToContentFrame();
                value = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.DocumentInfo.policywotitlereporteffectiveDate.FASetText(value);
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Select Policy without title report and Click edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template created for 6.3 updates", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                
                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(3000);

                Reports.TestStep = "Please enter Liability information on TermsDatesStatus Screen to finalize the Policy.";
                Support.AreEqual(@"Policy Number/Guarantee Number is required to finalize the document.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "Enter charges to New loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000000");
                FastDriver.NewLoan.FindGABCode(@"247");
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                
                Reports.TestStep = "Navigate to Doc rep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                
                Reports.TestStep = "Verify that Lender Policy added.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                
                Reports.TestStep = "Click Info.";
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter the effective date and uncheck the property.";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                value = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.DocumentInfo.policywotitlereporteffectiveDate.FASetText(value);
                if (FastDriver.DocumentInfo.Propertycheckbox.Selected)
                    FastDriver.DocumentInfo.Propertycheckbox.FAClick();
                if (FastDriver.DocumentInfo.LenderCheckBox.Selected)
                    FastDriver.DocumentInfo.LenderCheckBox.FAClick();
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                Support.AreEqual(@"Insured is Required", FastDriver.WebDriver.HandleDialogMessage().Clean());

                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.WebDriver.FindElement(By.CssSelector("td[title=\"Document Repository\"]")).FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to Doc rep select Lender Policy click on edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Please enter Liability information on New Loan Screen to finalize the Policy.";
                Support.AreEqual(@"You must have an effective Date", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "Delete the liability amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"0.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to Doc rep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                
                Reports.TestStep = "Verify that Lender Policy added.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);

                Reports.TestStep = "Click Info.";
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Select property check box.";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                if (!FastDriver.DocumentInfo.Propertycheckbox.Selected)
                    FastDriver.DocumentInfo.Propertycheckbox.FAClick();
                value = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.DocumentInfo.policywotitlereporteffectiveDate.FASetText(value);
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Navigate to Doc rep select Lender Policy click on edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                
                Reports.TestStep = "Please enter Liability information on New Loan Screen to finalize the Policy.";
                Support.AreEqual(@"Policy Number/Guarantee Number is required to finalize the document.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "Enter the liability amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText(@"100.00");

                Reports.TestStep = "Navigate to Doc rep select Lender Policy click on edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                if (FastDriver.DocumentInfo.AutoNumber.Exists())
                    FastDriver.DocumentInfo.AssignNum.FAClick();
                else if (FastDriver.DocumentInfo.PolicyNum.Exists())
                    FastDriver.DocumentInfo.PolicyNum.FASetText("123126789");
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(1000);

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify the finalized status for Lender Policy.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                Support.AreEqual(@"Lender Policy", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 6, TableAction.GetText).Message);
                Support.AreEqual(@"Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 9, TableAction.GetText).Message);
                
                Reports.TestStep = "Navigate to Doc rep select Owner Policy click on edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                
                //Remove existing owner policy document
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //Add Owner Policy document
                CreateDocument("Owner Policy", "ALTA Ext Owner Policy 1402.06 (2006)", "ALTA Ext Owner Policy 1402.06 (2006)", "CA", multipleDocs: true);
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                
                Reports.TestStep = "You must have an effective Date";
                Support.AreEqual(@"You must have an effective Date", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Navigate to TDS screen and enter Sales Price.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.StatusDate.FASetText("01-01-2015");
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText(@"8,888,888.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Doc rep select Owner Policy click on edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.TitlePolicyInfoSave);
                value = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToDateString();
                //value = value.Replace("/", "-");
                if (FastDriver.DocumentInfo.policywotitlereporteffectiveDate.IsDisplayed())
                    FastDriver.DocumentInfo.policywotitlereporteffectiveDate.FASetText(value);
                if (!FastDriver.DocumentInfo.AutoNumber.IsDisplayed() && !FastDriver.DocumentInfo.AssignNum.IsDisplayed())
                {
                    //Additional step
                    FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Playback.Wait(5000);

                    FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Playback.Wait(2000);
                    FastDriver.WebDriver.HandleDialogMessage();

                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Info.FAClick();
                    Playback.Wait(5000);
                    //FastDriver.DocumentInfo.SwitchToContentFrame();
                    FastDriver.DocumentInfo.WaitForWindowToLoad(FastDriver.DocumentInfo.TitlePolicyInfoSave);
                    //FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.TitlePolicyInfoSave);
                    //--
                }
                if (FastDriver.DocumentInfo.AutoNumber.IsDisplayed())
                {
                    if (FastDriver.DocumentInfo.AutoNumber.Selected)
                    {
                        FastDriver.DocumentInfo.AssignNum.FAClick();
                        //FastDriver.DocumentInfo.PolicyNum.FASetText("123456789");
                    }
                }
                else
                {
                    if (FastDriver.DocumentInfo.AssignNum.IsDisplayed())
                        FastDriver.DocumentInfo.AssignNum.FAClick();
                    if (FastDriver.DocumentInfo.PolicyNum.IsDisplayed())
                    FastDriver.DocumentInfo.PolicyNum.FASetText("123456789");
                }
                //FastDriver.DocumentInfo.PolicyNum.FASetText(Support.RandomNumber(100000).ToString());
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Navigate to Doc rep select Owner Policy click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Press ALT+O+Z-Finalize the Document. From DP0024 - REG_DPUC0002";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(1000);

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify the finalized status for Owner Policy.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                Support.AreEqual(@"Owner Policy", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA Ext Owner Policy 1402.06 (2006)", 6, TableAction.GetText).Message);
                Support.AreEqual(@"Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA Ext Owner Policy 1402.06 (2006)", 9, TableAction.GetText).Message);
                
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0024()
        {
            try
            {
                Reports.TestDescription = "BR_DP13460_07USER: DP13460 : CPL Template Type .Verify that The CPL Document Template Type wont be accessible to Normal user.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.TemplateMaintenanceSummary.FindNow.Exists().ToString());
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"All");                
                Keyboard.SendKeys("c");

                Reports.TestStep = "CPL document type can be used only from Docprep region.";
                Support.AreEqual(@"CPL document type can be used only from Docprep region.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0025()
        {
            try
            {
                Reports.TestDescription = "BR_DP13460_SUPERUSER: DP13460 : CPL Template Type .Verify that The CPL Document Template Type can be accessible to only admin.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Sandpointe Region Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("191");

                Reports.TestStep = "Navigate to template maintenance summary screen and Select CPL as template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.TemplateMaintenanceSummary.FindNow.Exists().ToString());
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"All");
                Keyboard.SendKeys("c");

                Reports.TestStep = "CPL document type can be used only from Docprep region.";
                Support.AreEqual(@"CPL document type can be used only from Docprep region.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0026()
        {
            try
            {
                Reports.TestDescription = "BR_DP13460_SUPERUSER: DP13460 : CPL Template Type .Verify that The CPL Document Template Type can be accessible to only admin.";

                #region data setup//change credentials here
                var credentialsADM = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU
                };
                var credentialsIIS = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login ADM Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentialsADM, true);

                Reports.TestStep = "Navigate to Select Office Screen.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("196");
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to Template Maintenance Screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                
                Reports.TestStep = "Enter Template filerting criteria and click find now button";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("CPL");
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem("Both");
                FastDriver.TemplateMaintenanceSummary.State.FASelectItem("");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Closing Protection Letter (Slr)-AR-TEST");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();

                Reports.TestStep = "Select the required template from the results and click edit button.";
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", "Closing Protection Letter (Slr)-AR-TEST", "Type", TableAction.Click);
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                if(!FastDriver.TemplateMaintenanceInformation.InformationActive.Selected)
                    FastDriver.TemplateMaintenanceInformation.InformationActive.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Logon to IIS server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentialsIIS, true);

                Reports.TestStep = "Create Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247");
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Document Repository - click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"CPL");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Closing Protection Letter (Slr)-AR-TEST");
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Closing Protection Letter (Slr)-AR-TEST", "Description", TableAction.Click);

                if (FastDriver.AdHocDocuments.SearchResultsTable.GetRowCount() != 1)
                    Reports.StatusUpdate("Closing Protection Letter (Slr)-AR-TEST template can be in INACTIVE state. Logon to ADM with superuser - DOCPREP Corporate Region - DOCPREP Corporate Office - Change the status to Active.", false);
                else
                {
                    FastDriver.AdHocDocuments.CreateSave.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                    Reports.TestStep = "Verify that CPL document is added.";
                    FastDriver.DocumentRepository.SwitchToContentFrame();
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Closing Protection Letter (Slr)-AR-TEST", 4, TableAction.Click);

                    Reports.TestStep = "Preview the selected Document.";
                    FastDriver.DocumentRepository.Method.FASelectItem(@"PREVIEW");
                    FastDriver.DocumentRepository.Deliver.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow("Preview");
                }

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0027()
        {
            try
            {
                Reports.TestDescription = "BR_DP3513_EWC06: DP3513 : Prohibit deleting a data element in Doc Maintenance.";

                #region data setup//change credentials here
                var credentialsIIS = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Logon to IIS server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentialsIIS, true);

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247");
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"CPL");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Closing Protection Letter (Slr)-AR-TEST");
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Closing Protection Letter (Slr)-AR-TEST", "Description", TableAction.Click);
                if (FastDriver.AdHocDocuments.SearchResultsTable.GetRowCount() != 1)
                    Reports.StatusUpdate("Closing Protection Letter (Slr)-AR-TEST template can be in INACTIVE state. Logon to ADM with superuser - DOCPREP Corporate Region - DOCPREP Corporate Office - Change the status to Active.", false);
                else
                {
                    FastDriver.AdHocDocuments.CreateSave.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                    Playback.Wait(5000);

                    Reports.TestStep = "Verify that CPL document is added.";
                    FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Closing Protection Letter (Slr)-AR-TEST", 4, TableAction.Click);

                    Reports.TestStep = "Preview the selected Document.";
                    FastDriver.DocumentRepository.Method.FASelectItem(@"PREVIEW");
                    FastDriver.DocumentRepository.Deliver.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow("Preview");
                }

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();

                Reports.TestStep = "Select template created in ADM & click on save button.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Bus Source ");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Bus Source", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(5000);

                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Bus Source", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click ALT+E Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%p");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("e");
                
                Reports.TestStep = "After Moving cursor to end line.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("NPBS/NPBS", true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                Keyboard.SendKeys("^{END}");
                Keyboard.SendKeys("{SPACE}");
                Keyboard.SendKeys("TextDataElement");
                
                Reports.TestStep = "Click on Save and Done in Bottom Frame Dialogs";
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Reports.StatusUpdate("Document Repository screen is loaded", true);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0028()
        {
            try
            {
                Reports.TestDescription = "EWC16_EWC7_DP11005: Finalizing a Policy not associated with a Property and refreshing the whole document.";

                #region data setup//change credentials here
                var credentialsIIS = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Logon to IIS server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentialsIIS, true);

                Reports.TestStep = "Create Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247");
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.FileHomepage.ChangeOO.Exists().ToString());
                
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                
                Reports.TestStep = "Add Policy Without title report Document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Policy w/o Title Reports");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Template created for 6.3 updates");
                FastDriver.AdHocDocuments.State.FASelectItem(@"CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Template created for 6.3 updates", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();

                Reports.TestStep = "Add Title Report.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Title Reports");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTERNATE FLOW 1 - QTP - DO NOT TOUCH");
                FastDriver.AdHocDocuments.State.FASelectItem(@"CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                
                Reports.TestStep = "Verify that title report added.";
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTERNATE FLOW 1 - QTP - DO NOT TOUCH", 4, TableAction.Click);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();

                Reports.TestStep = "Add Owner Policy Document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Owner Policy");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTA Ext Owner Policy 1402.06 (2006)");
                FastDriver.AdHocDocuments.State.FASelectItem(@"");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTA Ext Owner Policy 1402.06 (2006)", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                
                Reports.TestStep = "Select the Owner Policy and Click on Info Tab.";
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Uncheck the Property and check the Buyer checkbox.";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                string value = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(value);
                if (FastDriver.DocumentInfo.Propertycheckbox.Selected)
                    FastDriver.DocumentInfo.Propertycheckbox.FAClick();
                if (!FastDriver.DocumentInfo.Buyercheckbox.Selected)
                    FastDriver.DocumentInfo.Buyercheckbox.FAClick();
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Owner Policy and Click on Edit for finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Click ALT+O and Alt Z Under Phrase Tab.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(3000);

                Reports.TestStep = "Please associate the Policy with a Property to finalize.";
                Support.AreEqual(@"Policy Number/Guarantee Number is required to finalize the document.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "Press ALT+O+R-Refresh the Document.";
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("r");
                
                Reports.TestStep = "Refresh will result in a loss of all data entered in text elements and reset data elements to current values in the file.";
                Support.AreEqual(@"Refresh will result in a loss of all data entered in text elements and reset data elements to current values in the file.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0029_PH()
        {
            try
            {
                Reports.TestDescription = "DP3467_DP1735_DP2640_DP3371_DP3370_DP3375_DP1736_DP3402_DP3377_DP7742_DP3397_DP3398_DP3399_DP3376: Verify these BRs manually. I scripted some N-issues script will get fail, verify carefully.";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0002_REG0030_PH()
        {
            try
            {
                Reports.TestDescription = "DP3372_DP3379_DP3391_DP3375_DP3409_DP3456_DP3354_DP3453_DP3449_EWC12: Verify these BRs manually. I scripted some N-issues script will get fail, verify carefully.";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Custom Class Method

        private void CreateDocument(string templateType, string templateName, string templateDescription, string state = "CA", bool multipleDocs = false)
        {

            FastDriver.DocumentRepository.SwitchToContentFrame();
            if (!multipleDocs)
                FastDriver.DocumentRepository.Add.FAClick();
            else
                FastDriver.DocumentRepository.AddDocRep.FAClick();
            Reports.TestStep = "Add Document to Document Repository screen.";
            FastDriver.AdHocDocuments.WaitForScreenToLoad();
            FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
            FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys(templateType);
            FastDriver.AdHocDocuments.TemplateDescription.FASetText(templateDescription);
            if (state != null)
                FastDriver.AdHocDocuments.State.FASelectItem(state);

            Reports.TestStep = "validate the data entered in Adhoc Documents.";
            Support.value = FastDriver.AdHocDocuments.Source.FAGetSelectedItem();
            if (Support.value == null)
                Support.value = "";
            Support.AreEqual(@"Both", Support.value);
            Support.value = FastDriver.AdHocDocuments.TemplateType.FAGetSelectedItem(); ;
            if (Support.value == null)
                Support.value = "";
            Support.AreEqual(templateType, Support.value);
            Support.AreEqual(templateDescription, FastDriver.AdHocDocuments.TemplateDescription.FAGetValue().Clean());
            FastDriver.AdHocDocuments.FindNow.FAClick();
            FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", templateName, "Description", TableAction.Click);
            FastDriver.AdHocDocuments.CreateSave.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            Playback.Wait(5000);
        }
        
        private void sendKeysToPhraseEditor(string sModifier, string sKeys)
        {
            //FastDriver.WebDriver.SwitchTo().Frame("tbContentElement");
            FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
            ModifierKeys modifier = ModifierKeys.None;
            if (sModifier == "^")
            {
                modifier = ModifierKeys.Control;
            }
            if (sModifier == "%")
            {
                modifier = ModifierKeys.Alt;
            }
            if (sModifier == "+")
            {
                modifier = ModifierKeys.Shift;
            }
            Keyboard.SendKeys(sKeys, modifier);
        }

        private void deleteTemplate()
        {
            FastDriver.TemplateMaintenanceSummary.SwitchToContentFrame();
            FastDriver.TemplateMaintenanceSummary.Edit.FAClick();
            FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
            FastDriver.TemplateMaintenanceInformation.InformationInactive.FAClick();
            FastDriver.BottomFrame.Done();
            Playback.Wait(250);
            FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad();

        }

        private void cleanTemplateMaintenanceSummary(Credentials credentials, bool  isIIS = false)
        {
            int tableLength = 0;
            //string statusID = "";
            //var element;

            if (isIIS)
            {
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem(@"Active");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                tableLength = FastDriver.TemplateMaintenanceSummary.Results.GetRowCount();
            }
            else
            {
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem(@"Active");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                tableLength = FastDriver.TemplateMaintenanceSummary.Results.GetRowCount();
            }

            while (true)
            {
                FastDriver.TemplateMaintenanceSummary.SwitchToContentFrame();
                //element = FastDriver.TemplateMaintenanceSummary.Status;

                if (FastDriver.TemplateMaintenanceSummary.Status.IsVisible())
                {
                    FastDriver.TemplateMaintenanceSummary.Status.FAClick();
                    deleteTemplate();
                }
                else
                {
                    break;
                }
            }

            //for (int i = 1; i < tableLength; i++)
            //{
            //    FastDriver.TemplateMaintenanceSummary.SwitchToContentFrame();
                //statusID = "rslt_dgridMaint_";
                //statusID = statusID + i + "_lblStatus";
                //element = FastDriver.WebDriver.FindElement(By.Id(statusID));
                
                
                //string value = element.Text.Clean();
                //if (value == "Active")
                //{
                //    element.FAClick();
                //    deleteTemplate();
                //}
            //}

        }
        
        private void PhraseValidation()
        {
            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            bool exists = false;
            #endregion
            
            Reports.TestStep = "Login to FAST IIS";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            Reports.TestStep = "Search for a phrase group.";
            FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
            FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem(@"Exception Phrase");
            FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText(@"Transmittal Phrases");

            Reports.TestStep = "To click on FindNow button";
            FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

            Reports.TestStep = "To verify that Pending Phrase is Present.";
            if (!FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.Text.Contains("Transmittal Phrases"))
            {
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
            }
            else
            {
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Description", "Transmittal Phrases", "Description", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                exists = true;
            }
            
            Reports.TestStep = "To verify that Pending Phrase is added to the Pending Phrase Group.";
            FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
            if (!exists)
            {
                Reports.TestStep = "Set phrase name and description.";
                FastDriver.PhraseGroupMaintenance.Name.FASetText(@"TRNS");
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText(@"Transmittal Phrases");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem(@"Exception Phrase");
                FastDriver.PhraseGroupMaintenance.Active.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
            }
            if (!FastDriver.PhraseGroupMaintenance.PhrasesTable.Text.Contains("34B"))
            {
                Reports.TestStep = "Click on Add phrase button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseName.FASetText(@"34B");
                FastDriver.PhraseMaintenance.Description.FASetText(@"New created phrase");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhraseName);
                //string desc = FastDriver.PhraseMaintenance.Description.FAGetValue().Clean();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("34B" + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                sendKeysToPhraseEditor("^", "{END}");//added
                sendKeysToPhraseEditor("^", "{SPACE}");//added
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();
                //FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Select a data element & enter the value.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElementGroup);
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Home Warranty Information");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"HWBPHX");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);

                Reports.TestStep = "Sending send keys of Save and Done.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                sendKeysToPhraseEditor("^", "{END}");
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            FastDriver.BottomFrame.Done();
        }

        private void MarkPhrasesAsNonRequired()
        {
            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            bool exists = false;
            #endregion

            Reports.TestStep = "Login ADM Side";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
            FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
            FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Endorsement/Guarantee");
            FastDriver.TemplateMaintenanceSummary.Description.FASetText(@"Template for DPUC0002");

            Reports.TestStep = "Verify that Template is created and Select the record.";
            FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
            FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "Template for DPUC0002", 2, TableAction.Click);

            Reports.TestStep = "Click on Edit.";
            FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

            Reports.TestStep = "Delete the Phrases and Phrase markers.";
            FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
            FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
            FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
            
            Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
            foreach (var item in FastDriver.TemplateMaintenancePhrase.PhrasesTable.FAFindElements(ByLocator.TagName, "input").Where(p => p.FAGetAttribute("type").Contains("checkbox") && p.Displayed))
            {
                item.FASetCheckbox(false);
            }

        }

        private void AddElementToPhrase()
        {
            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            #endregion

            Reports.TestStep = "Login to FAST IIS";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            Reports.TestStep = "Search for a phrase group.";
            FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
            FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem(@"Escrow Phrase");

            Reports.TestStep = "To click on FindNow button";
            FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

            Reports.TestStep = "To verify that Pending Phrase is Present.";
            FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", "BSCI", "Name", TableAction.Click);
            FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

            Reports.TestStep = "To verify that Pending Phrase is added to the Pending Phrase Group.";
            FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
            FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, "BSCI", 1, TableAction.Click);
            FastDriver.PhraseGroupMaintenance.Edit.FAClick();

            Reports.TestStep = "Click on Phrase Editor button.";
            FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhraseName);
            FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

            Reports.TestStep = "Click on Insert data element link.";
            FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
            sendKeysToPhraseEditor("^", "{END}");//added
            sendKeysToPhraseEditor("^", "{SPACE}");//added
            FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
            FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                && i.Displayed).FAClick();

            Reports.TestStep = "Select a data element & enter the value.";
            FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElementGroup);
            FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Home Warranty Information");
            FastDriver.DataElementSelectionDlg.DataElement.FASetText(@"FLMADD1");

            Reports.TestStep = "Click on Done in Dialog Box.";
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(250);

            Reports.TestStep = "Sending send keys of Save and Done.";
            FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
            sendKeysToPhraseEditor("^", "{END}");
            FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
            FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
            FastDriver.DialogBottomFrame.ClickSave();
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(250);

            Reports.TestStep = "Click on Save.";
            FastDriver.BottomFrame.Save();

            Reports.TestStep = "Click on Done.";
            FastDriver.BottomFrame.Done();
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
