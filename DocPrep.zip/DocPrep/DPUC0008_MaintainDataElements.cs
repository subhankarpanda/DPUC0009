﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using System.Text.RegularExpressions;
namespace DocPrep
{
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class DPUC0008 : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void DPUC0008_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MainCourse: Select Data Element.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for GOAL phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("CreatedForAutomationTesting");

                Reports.TestStep = "To click on Find Now button.";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "GOAL", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, "PHR1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link after Move to end line.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Playback.Wait(3000);
                Keyboard.SendKeys("^{END}");
                Playback.Wait(3000);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Direct Enter the Data Element name.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWLADD1");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);

                Reports.TestStep = "Click on Insert Data element Image button.";
                Playback.Wait(3000);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Direct Enter the Data Element name.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("BSCONSTATE");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save to save new data element.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, "PHR5", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link after Move to end line.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^{END}");
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Direct Enter the Data Element name.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("BUSIGN,BUSIGNSTK,SESIGN,SESIGNSTK");

                Reports.TestStep = "Click on Done in Data Element Selection Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on in Editor Save to save new data element.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0008_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse1: Edit text elements.";

                Reports.TestStep = "Select the Phrase and click on edit.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MainCourse: Select Data Element.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for GOAL phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("CreatedForAutomationTesting");

                Reports.TestStep = "To click on Find Now button.";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "GOAL", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, "PHR1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link after Move to end line.";
                //FastDriver.WebDriver.SwitchToWindow("PHR1 - FirstPhraseInGOAL");
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^{END}");
                Keyboard.SendKeys("TextDataElement");
                Playback.Wait(3000);

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0008_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse2: Insert Auto Outline Numbers.";

                Reports.TestStep = "Click on Phrase Editor button.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MainCourse: Select Data Element.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for GOAL phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("CreatedForAutomationTesting");

                Reports.TestStep = "To click on Find Now button.";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "GOAL", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, "PHR1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Inserting Outline and click on cancel.";
                //FastDriver.WebDriver.SwitchToWindow("PHR1 - FirstPhraseInGOAL");
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^A");
                Keyboard.SendKeys("^X");
                FastDriver.PhraseConditionsDlg.ClickAutoOutline();

                Reports.TestStep = "Click on the Done Button";
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0008_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse3: Start a new Auto Outline Number Group for this Phrase.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MainCourse: Select Data Element.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for GOAL phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("CreatedForAutomationTesting");

                Reports.TestStep = "To click on Find Now button.";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "GOAL", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, "PHR1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                String phraseTitle = FastDriver.PhraseMaintenance.PhraseName.FAGetValue().ToUpper() + " - " + FastDriver.PhraseMaintenance.Description.FAGetValue();
                FastDriver.WebDriver.WaitForWindowAndSwitch(phraseTitle, true, 20);

                Reports.TestStep = "Click on Insert data element link after Move to end line.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^{End}");
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Direct Enter the Data Element name.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWLADD1");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);

                Reports.TestStep = "Click on Properties to change outline format for the phrase.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Playback.Wait(8000);
                Keyboard.SendKeys("^{Home}");
                Playback.Wait(2000);
                Keyboard.SendKeys("{Del}");
                FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();
                Playback.Wait(3000);
                Reports.TestStep = "Change the order.";
                FastDriver.OrderListFormatDlg.WaitForScreenToLoad();
                FastDriver.OrderListFormatDlg.Format.FASelectItemByIndex(1);
                FastDriver.OrderListFormatDlg.btnOK.FAClick();

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0008_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse4: Edit Data Element Properties.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MainCourse: Select Data Element.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for GOAL phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("CreatedForAutomationTesting");

                Reports.TestStep = "To click on Find Now button.";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "GOAL", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, "PHR1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Playback.Wait(3000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("^X");
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWLADD1");

                Reports.TestStep = "Click on Done in Data Element Selection Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);

                Reports.TestStep = "Click on Show Properties Image.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Playback.Wait(1000);
                Keyboard.SendKeys("^{Home}");
                Playback.Wait(1000);
                Keyboard.SendKeys("{Del}");
                Playback.Wait(3000);
                FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();

                Reports.TestStep = "Modify the Data element properties and click on ok.";
                FastDriver.DataElementsDlg.WaitForScreenToLoad();
                string value = FastDriver.DataElementsDlg.Format.FAGetSelectedItem();
                Support.AreEqual("TEXT", value);

                FastDriver.DataElementsDlg.ReadOnly.FASetCheckbox(true);

                FastDriver.DataElementsDlg.Case.FASelectItem("UPPER");
                value = FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem();
                Support.AreEqual("LEFTJUST", value);

                value = FastDriver.DataElementsDlg.Required.FAGetSelectedItem();
                Support.AreEqual("Yes", value);

                if (FastDriver.DataElementsDlg.Index.IsDisplayed())
                    FastDriver.DataElementsDlg.Index.FASetText("1");

                FastDriver.DataElementsDlg.Description.FASetText("ModifiedDescriptions");

                FastDriver.DataElementsDlg.Ok.FAClick();

                Reports.TestStep = "Save and close the Phrase Editor";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validating and revert to Original values.";
                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^{Home}");

                FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();

                Reports.TestStep = "Modify the Data element properties and click on ok.";
                FastDriver.DataElementsDlg.WaitForScreenToLoad();
                value = FastDriver.DataElementsDlg.Format.FAGetSelectedItem();
                Support.AreEqual("TEXT", value);

                FastDriver.DataElementsDlg.ReadOnly.FASetCheckbox(false);

                FastDriver.DataElementsDlg.Case.FASelectItem("ASTYPED");
                value = FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem();
                Support.AreEqual("LEFTJUST", value);

                value = FastDriver.DataElementsDlg.Required.FAGetSelectedItem();
                Support.AreEqual("Yes", value);

                if (FastDriver.DataElementsDlg.Index.IsDisplayed())
                    FastDriver.DataElementsDlg.Index.FASetText("1");

                Reports.TestStep = "Validating for previous value.";
                Support.AreEqual("ModifiedDescriptions", FastDriver.DataElementsDlg.Description.FAGetValue());

                Reports.TestStep = "Updating Original values";
                FastDriver.DataElementsDlg.Description.FASetText("Buyer Name(s)");

                FastDriver.DataElementsDlg.Ok.FAClick();

                Reports.TestStep = "Save and close the Phrase Editor";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0008_BAT0006()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse4: Edit Data Element Properties.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MainCourse: Select Data Element.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for GOAL phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("CreatedForAutomationTesting");

                Reports.TestStep = "To click on Find Now button.";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "GOAL", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(1, "PHR1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();

                Reports.TestStep = "Select the Element Name from Phrase editor and Click on Cut Button then pasting on the same phrase.";
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("^X");
                Playback.Wait(1000);
                Keyboard.SendKeys("^V");
                Playback.Wait(1000);

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion

        #region REG
        [TestMethod]
        public void DPUC0008_REG0001()
        {
            try
            {
                Reports.TestDescription = "DP228_DP229_DP230: Create Phrase Group and add Phrase to Phrase Group and Data Element to the Phrase.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MainCourse: Select Data Element.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for GOAL phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create a new phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Name);
                string gPhrase = "G" + Support.RandomString("AAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(gPhrase);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("Created for Axe BAT script");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Add);
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string value = "" + Support.RandomString("ANN");
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhraseName);
                FastDriver.PhraseGroupMaintenance.PhraseName.FASetText(value);
                FastDriver.PhraseGroupMaintenance.PhraseDescritption.FASetText("Axe BAT script phrase");
                FastDriver.PhraseGroupMaintenance.PhraseComments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseGroupMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseGroupMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseGroupMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 5);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                Reports.TestStep = "To click on Find Now button.";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, gPhrase, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.InsertDataElement);
                Keyboard.SendKeys("^{END}");
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Select a data element & enter the value.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElement);
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWBPHX");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);

                Reports.TestStep = "Verify the Default properties of Selected data element.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.FontName);
                Support.AreEqual("Tahoma", FastDriver.PhraseEditorDlg.FontName.FAGetSelectedItem());
                Support.AreEqual("10", FastDriver.PhraseEditorDlg.FontSize.FAGetSelectedItem());

                Reports.TestStep = "Select the Phrase Name from Phrase editor and Click on Cut Button/ Remove Data Element.";
                Playback.Wait(3000);
                Keyboard.SendKeys("^A");
                Keyboard.SendKeys("^X");
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();

                Reports.TestStep = "Click on Save.";
                FastDriver.DialogBottomFrame.ClickSave();
                Reports.TestStep = "Click on Done.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Add);
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhraseName);
                FastDriver.PhraseMaintenance.Editable.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.UnderConstruction.FASetCheckbox(true);
                value = "" + Support.RandomString("ANN");
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhraseName);
                FastDriver.PhraseGroupMaintenance.PhraseName.FASetText(value);
                FastDriver.PhraseGroupMaintenance.PhraseDescritption.FASetText("New created phrase2");
                Support.AreEqual("Tahoma", FastDriver.PhraseMaintenance.Formatting_Name.FAGetSelectedItem());
                Support.AreEqual("10", FastDriver.PhraseMaintenance.Formatting_Size.FAGetSelectedItem());
                Support.AreEqual("0.21", FastDriver.PhraseMaintenance.Formatting_MarginTop.FAGetValue());
                Support.AreEqual("0.7", FastDriver.PhraseMaintenance.Formatting_MarginLeft.FAGetValue());
                Support.AreEqual("0.8", FastDriver.PhraseMaintenance.Formatting_MarginRight.FAGetValue());
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.Paste);
                FastDriver.PhraseEditorDlg.Paste.FAClick();
                //Pop up asking if I allow this page to access my clipboard, sending Allow via {Alt+A}
                Playback.Wait(3000);
                Keyboard.SendKeys("%A");

                Reports.TestStep = "Click on Save.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickSave();

                Reports.TestStep = "Click on Done.";
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0008_REG0002_3()
        {
            //Current bug: 756504

            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP233_DP235_DP236_DP237_DP238_DP240_DP241_DP243_9830_DP2004: Change the properties, Add Multiple element with in Phrase with the same properties. / DP246_DP247_DP249_DP250_DP251_DP252_DP2073_DP2005_DP4177_DP239: Verify the data Element Properties";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for GOAL phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create a new phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Name);
                string gPhrase = "G" + Support.RandomString("AAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(gPhrase);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("Created for Axe BAT script");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Add);
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string value = "" + Support.RandomString("ANN");
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhraseName);
                FastDriver.PhraseGroupMaintenance.PhraseName.FASetText(value);
                FastDriver.PhraseGroupMaintenance.PhraseDescritption.FASetText("Axe BAT script phrase");
                FastDriver.PhraseGroupMaintenance.PhraseComments.FASetText("Add phrase to Phrasegroup");

                FastDriver.PhraseGroupMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseGroupMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseGroupMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);

                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 5);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                Reports.TestStep = "To click on Find Now button.";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, gPhrase, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Select the Phrase and click on edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link.";
                Keyboard.SendKeys("^{END}");
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.InsertDataElement);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Select a data element & enter the value.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElement);
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWBPHX");
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.FontName);
                FastDriver.PhraseEditorDlg.FontName.FASelectItem("Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem("12");

                Reports.TestStep = "Select the Element Name from Phrase editor and Click on Cut Button then pasting on the same phrase.";
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                //Keyboard.SendKeys("^X");
                FastDriver.PhraseEditorDlg.Cut.FAClick();
                Playback.Wait(1000);
                //Keyboard.SendKeys("^V");
                FastDriver.PhraseEditorDlg.Paste.FAClick();
                //Pop up asking if I allow this page to access my clipboard, sending Allow via {Alt+A}
                Playback.Wait(3000);
                Keyboard.SendKeys("%A");

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Select a data element & enter the value (ID Code).";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElementGroup);
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Home Warranty Information");
                Playback.Wait(3000);
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWBPHX,HWBPHX");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);

                String[] DataElement = { "1HWBPHXa", "1HWBPHXb" };
                int i = 1;
                String[] formatVal = new String[2];
                String[] caseVal = new String[2];
                String[] alignVal = new String[2];
                String[] reqVal = new String[2];

                foreach (string de in DataElement)
                {

                    FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.Find);
                    FastDriver.PhraseEditorDlg.Find.FAClick();
                    FastDriver.FindDlg.WaitForScreenToLoad(FastDriver.FindDlg.TextToFind);
                    FastDriver.FindDlg.TextToFind.FASetText(de);
                    Playback.Wait(1000);
                    FastDriver.FindDlg.FindNext.FAClick();
                    Playback.Wait(1000);
                    FastDriver.FindDlg.Cancel.FAClick();
                    FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.ShowPropertiesElement);
                    FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();
                    FastDriver.DataElementsDlg.WaitForScreenToLoad(FastDriver.DataElementsDlg.Format);

                    formatVal[i - 1] = FastDriver.DataElementsDlg.Format.FAGetSelectedItem();
                    caseVal[i - 1] = FastDriver.DataElementsDlg.Case.FAGetSelectedItem();
                    alignVal[i - 1] = FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem();
                    reqVal[i - 1] = FastDriver.DataElementsDlg.Required.IsSelected().ToString();

                    FastDriver.DataElementsDlg.Ok.FAClick();

                    i++;
                }
                Support.AreEqualTrim(formatVal[0], formatVal[1]);
                Support.AreEqualTrim(caseVal[0], caseVal[1]);
                Support.AreEqualTrim(alignVal[0], alignVal[1]);
                Support.AreEqualTrim(reqVal[0], reqVal[1]);

                Reports.TestStep = "Click on Insert data element link.";
                Keyboard.SendKeys("^{END}");
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.InsertDataElement);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Direct Enter the Data Element name.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElement);
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWLADD1");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);

                Reports.TestStep = "Verify the Default properties of Selected data element.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Playback.Wait(1000);
                Keyboard.SendKeys("^{End}");
                Playback.Wait(6000);
                Support.AreEqual("Tahoma", FastDriver.PhraseEditorDlg.FontName.FAGetSelectedItem());
                Support.AreEqual("10", FastDriver.PhraseEditorDlg.FontSize.FAGetSelectedItem());

                Reports.TestStep = "Sending send keys of Save and Done.";
                Playback.Wait(2000);
                Keyboard.SendKeys("^A");
                FastDriver.PhraseEditorDlg.FontName.FASelectItem("Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem("12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify that User Cant edit the Phrase name once saved.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseName);
                Support.AreEqual("False", FastDriver.PhraseMaintenance.PhraseName.IsEnabled().ToString());

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data elSelect a data element & enter the value.ement link.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Default properties of Selected data element.";
                Playback.Wait(1000);
                Keyboard.SendKeys("^{End}");
                Playback.Wait(3000);
                Support.AreEqual("Times New Roman", FastDriver.PhraseEditorDlg.FontName.FAGetSelectedItem());
                Support.AreEqual("12", FastDriver.PhraseEditorDlg.FontSize.FAGetSelectedItem());

                Reports.TestStep = "Inserting Outline.";
                FastDriver.PhraseEditorDlg.AutoOutline.FAClick();

                Reports.TestStep = "Select the Element Name from Phrase editor and Click on Cut Button then pasting on the same phrase.";
                Playback.Wait(2000);
                Keyboard.SendKeys("^A");
                Playback.Wait(2000);
                Keyboard.SendKeys("^X");
                Playback.Wait(2000);
                Keyboard.SendKeys("%A");
                Playback.Wait(2000);
                Keyboard.SendKeys("^V");

                Reports.TestStep = "Inserting Symbol.";
                FastDriver.PhraseEditorDlg.Symbols.FASelectItem("§");
                Playback.Wait(1000);
                Keyboard.SendKeys("^{Home}+{End}");
                Playback.Wait(1000);
                Keyboard.SendKeys("{Del}");
                Playback.Wait(2000);
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #region Test DPUC0008_REG0003
                Reports.TestStep = "REG0003: Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, "G5U9", 1, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhrasesTable);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Fixing for GAP coverage", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("^X");
                Playback.Wait(3000);
                Keyboard.SendKeys("%A");
                Playback.Wait(3000);
                Keyboard.SendKeys("^V");
                Playback.Wait(1000);
                Keyboard.SendKeys("^{END}");
                Playback.Wait(1000);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Select a data element & enter the value.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElementGroup);
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Home Warranty Information");
                Playback.Wait(1000);
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWBPHX");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select the Element Name from Phrase editor and Click on Cut Button then pasting on the same phrase.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("^X");
                Playback.Wait(3000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("^V");

                Reports.TestStep = "Click on Show Properties Image.";
                FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();

                Reports.TestStep = "Please, select a data element.";
                Support.AreEqual("Please, select a data element", FastDriver.WebDriver.HandleDialogMessage(true, true, 3));

                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.FontName);
                FastDriver.PhraseEditorDlg.FontName.FASelectItem("Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem("12");
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Show Properties Image.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("^X");
                Playback.Wait(3000);
                Keyboard.SendKeys("^A");

                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();

                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Home Warranty Information");
                Playback.Wait(1000);
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("HWBPHX");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.ShowPropertiesElement);
                Keyboard.SendKeys("^{Home}");
                FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();

                Reports.TestStep = "Verify for the Properties.";
                FastDriver.DataElementsDlg.WaitForScreenToLoad(FastDriver.DataElementsDlg.CatalogDescription);
                Support.AreEqual("False", FastDriver.DataElementsDlg.CatalogDescription.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.DataElementsDlg.Name.FAGetValue().Contains("1HWBPHX").ToString());

                Reports.TestStep = "Modify the description.";
                FastDriver.DataElementsDlg.Description.FASetText("ModifiedDescriptionsModifiedDescriptionsModifiedDe1234");
                Support.AreEqual("TEXT", FastDriver.DataElementsDlg.Format.FAGetSelectedItem());
                Support.AreEqual("-1", FastDriver.DataElementsDlg.PictureSelection.FAGetSelectedIndex().ToString());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());

                Reports.TestStep = "Verify the description, Change format to date.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                Playback.Wait(1000);
                Support.AreEqual("yy-mm-dd", FastDriver.DataElementsDlg.PictureSelection.FAGetSelectedItem());
                Support.AreEqual("ex: 04/08/13", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED", FastDriver.DataElementsDlg.Case.FAGetSelectedItem());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());

                Reports.TestStep = "Filed Definition.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                Support.AreEqual("yy-mm-ddddyyyyMMMM/dd/yyyyddddALPHADAYOFMMMMMMMMddYYYY", FastDriver.DataElementsDlg.PictureSelection.FAGetText());
                Support.AreEqual("ex: 04/08/13", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED", FastDriver.DataElementsDlg.Case.FAGetSelectedItem());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());

                Reports.TestStep = "Filed Definition.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                FastDriver.DataElementsDlg.PictureSelection.FASelectItem("MMMMddYYYY");
                Support.AreEqual("ex: March 15, 1999", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED", FastDriver.DataElementsDlg.Case.FAGetSelectedItem());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());

                Reports.TestStep = "Filed Definition.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                FastDriver.DataElementsDlg.PictureSelection.FASelectItem("ALPHADAYOF");
                Support.AreEqual("ex: Fifteenth day of March, 1999", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED", FastDriver.DataElementsDlg.Case.FAGetSelectedItem());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());

                Reports.TestStep = "Filed Definition.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                FastDriver.DataElementsDlg.PictureSelection.FASelectItem("dd");
                Support.AreEqual("ex: 15", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED", FastDriver.DataElementsDlg.Case.FAGetSelectedItem());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());

                Reports.TestStep = "Filed Definition.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                FastDriver.DataElementsDlg.PictureSelection.FASelectItem("yyyy");
                Support.AreEqual("ex: 1999", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED", FastDriver.DataElementsDlg.Case.FAGetSelectedItem());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());

                Reports.TestStep = "Filed Definition.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                FastDriver.DataElementsDlg.PictureSelection.FASelectItem("MM");
                Support.AreEqual("ex: 3", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED", FastDriver.DataElementsDlg.Case.FAGetSelectedItem());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());

                Reports.TestStep = "Filed Definition.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                FastDriver.DataElementsDlg.PictureSelection.FASelectItem("dddd");
                Support.AreEqual("ex: fifteenth", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED", FastDriver.DataElementsDlg.Case.FAGetSelectedItem());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());

                Reports.TestStep = "Filed Definition.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                FastDriver.DataElementsDlg.PictureSelection.FASelectItem("MMMM");
                Support.AreEqual("ex: March", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED", FastDriver.DataElementsDlg.Case.FAGetSelectedItem());
                Support.AreEqual("LEFTJUST", FastDriver.DataElementsDlg.Alignment.FAGetSelectedItem());
                Support.AreEqual("Yes", FastDriver.DataElementsDlg.Required.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());

                Reports.TestStep = "Filed Definition.";
                Support.AreEqual("ModifiedDescriptionsModifiedDescriptionsModifiedDe", FastDriver.DataElementsDlg.Description.FAGetValue());
                FastDriver.DataElementsDlg.Format.FASelectItem("DATE");
                FastDriver.DataElementsDlg.PictureSelection.FASelectItem("MMMM");
                Support.AreEqual("ex: March", FastDriver.DataElementsDlg.PictureTextBox.FAGetValue());
                Support.AreEqual("ASTYPED LOWER SENTENCE TITLE UPPER", FastDriver.DataElementsDlg.Case.FAGetText());
                Support.AreEqual("ALIGNDEC CENTERTEXT FULLJUST LEFTJUST RTJUST", FastDriver.DataElementsDlg.Alignment.FAGetText());
                Support.AreEqual("Yes No", FastDriver.DataElementsDlg.Required.FAGetText());
                Support.AreEqual("1", FastDriver.DataElementsDlg.Index.FAGetValue());
                FastDriver.DataElementsDlg.InitialValue.FASetText("1");
                FastDriver.DataElementsDlg.Ok.FAClick();

                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0008_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "ERROR_WARNING: Verify the error warn conditions for Element.";

                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.New);
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Name);
                string value = "G" + Support.RandomString("AAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(value);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("Created for Axe BAT script");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Add);
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhraseName);
                FastDriver.PhraseMaintenance.PhraseName.FASetText("EXPH");
                FastDriver.PhraseMaintenance.Description.FASetText("phrase for Extension");
                FastDriver.PhraseMaintenance.Comments.FASetText("phrase for Extension");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.InsertDataElement);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Enter Invalid Description.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElement);
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("ABCD");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "The data element ABCD does not exist.";
                Support.AreEqualTrim("Data Element is invalid. Please enter valid data element", FastDriver.WebDriver.HandleDialogMessage(true, false, 5));

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.InsertDataElement);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                Reports.TestStep = "Enter Buyer Type Element.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElementGroup);
                Playback.Wait(3000);
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Buyer");
                Playback.Wait(3000);
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("BUASIGNM");

                Reports.TestStep = "Click on Done in Dialog Box.";
                Playback.Wait(3000);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Show Properties Image.";
                Keyboard.SendKeys("^{End}");
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.ShowPropertiesElement);
                FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();
                Support.AreEqual("Please, select a data element", FastDriver.WebDriver.HandleDialogMessage(true, true, 3));

                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(FastDriver.PhraseEditorDlg.FontName);
                FastDriver.PhraseEditorDlg.FontName.FASelectItem("Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem("12");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Show Properties Image.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Playback.Wait(3000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("^{Home}");
                FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();

                Reports.TestStep = "Enter Invalid Value in Index Field.";
                FastDriver.DataElementsDlg.WaitForScreenToLoad(FastDriver.DataElementsDlg.CatalogDescription);
                Support.AreEqual("False", FastDriver.DataElementsDlg.CatalogDescription.IsEnabled().ToString());
                Support.AreEqual("1BUASIGNMa", FastDriver.DataElementsDlg.Name.FAGetValue());
                Keyboard.SendKeys("{DELETE}");
                FastDriver.DataElementsDlg.Ok.FAClick();

                Reports.TestStep = "The Element Index can have values.";
                //Support.AreEqual("The Element Index can have values ? , * or positive Integer more than zero.", FastDriver.WebDriver.HandleDialogMessage(true, true, 3));

                Reports.TestStep = "Click on Save.";
                FastDriver.DialogBottomFrame.ClickSave();

                Reports.TestStep = "Click on Done.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Find Now button and select the record.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.FindNow);
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                value = FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(1, "BUS SRC", 2, TableAction.Click).Message;

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Unchecking for Under Construction checkbox.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction);
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                Playback.Wait(1000);
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesAdd);
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Phrase.";
                Playback.Wait(1000);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad(FastDriver.PhraseSelectDlg.Description);
                FastDriver.PhraseSelectDlg.Description.FASetText("CreatedForAutomationTesting");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                Playback.Wait(6000);
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("GOAL/PHR5");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0008_REG0005()
        {
            try
            {
                #region data setup
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FormType.HUD;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        }
                    };
                #endregion

                Reports.TestDescription = "DP253_DP245_DP3555_DP3556_DP3557_DP3558_DP3567: Create Preview From Hud screen For Seller only, Buyer Only and Combined. Please verify the PDF Manually.";

                Reports.TestStep = "Login to File side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Select template created in ADM & click on save button.";
                FastDriver.AdHocDocuments.AddDocument("Both", "Endorsement/Guarantee", "Bus Source", null);

                Reports.TestStep = "Verify saved doc.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Bus Source", 4, TableAction.Click);

                Reports.TestStep = "Perform preview delivery and Check for Buyer/Seller Alignment.";
                FastDriver.Delivery.Perform(FADeliveryMethod.Preview);
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview);

                Reports.TestStep = "Navigate to Hud screen.";
                FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Home>Order Entry>Escrow Closing>HUD-1 Statement").WaitForScreenToLoad(FastDriver.HUD1PrintOptions.Method);

                Reports.TestStep = "Perform Preview delivery.";
                FastDriver.Delivery.Perform(FADeliveryMethod.Preview);
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview);

                Reports.TestStep = "Select Seller only.";
                FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Home>Order Entry>Escrow Closing>HUD-1 Statement").WaitForScreenToLoad(FastDriver.HUD1PrintOptions.Combined);
                FastDriver.HUD1PrintOptions.Combined.FASetCheckbox(false);
                FastDriver.HUD1PrintOptions.SellerOnly.FASetCheckbox(true);
                FastDriver.HUD1PrintOptions.PrintCertigicationSignature.FASetCheckbox(false);
                FastDriver.HUD1PrintOptions.IncludeSec10001200Itemization.FASetCheckbox(false);
                
                Reports.TestStep = "Perform Preview delivery.";
                FastDriver.Delivery.Perform(FADeliveryMethod.Preview);
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview);

                Reports.TestStep = "Check Buyer Only check Box.";
                FastDriver.HUD1PrintOptions.WaitForScreenToLoad(FastDriver.HUD1PrintOptions.Combined);
                FastDriver.HUD1PrintOptions.SellerOnly.FASetCheckbox(false);
                FastDriver.HUD1PrintOptions.Combined.FASetCheckbox(false);
                FastDriver.HUD1PrintOptions.BuyerOnly.FASetCheckbox(true);

                Reports.TestStep = "Perform Preview delivery.";
                FastDriver.Delivery.Perform(FADeliveryMethod.Preview);
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0008_REG0006()
        {
            try
            {
                Reports.TestDescription = "Direct - Introduce New Data Elements under New Loan Related Parties for Lender Funding, Lender Processor and Lender Loan Officer";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region Data Setup Lender-Funding
                List<string> newLoanRelatedParties = new List<string>();
                newLoanRelatedParties.Add("NL1PCMADDA");
                newLoanRelatedParties.Add("NL1PCMCSZ");
                newLoanRelatedParties.Add("NL1PCEMAIL");
                newLoanRelatedParties.Add("NL1PCICD");
                newLoanRelatedParties.Add("NL1PCROLE");
                newLoanRelatedParties.Add("NL1PCNM");
                newLoanRelatedParties.Add("NL1FNMADDA");
                newLoanRelatedParties.Add("NL1FNMCSZ");
                newLoanRelatedParties.Add("NL1FNEMAIL");
                newLoanRelatedParties.Add("NL1FNICD");
                newLoanRelatedParties.Add("NL1FNROLE");
                newLoanRelatedParties.Add("NL1FNNM");
                newLoanRelatedParties.Add("NL1LOMADDA");
                newLoanRelatedParties.Add("NL1LOMCSZ");
                newLoanRelatedParties.Add("NL1LOEMAIL");
                newLoanRelatedParties.Add("NL1LOICD");
                newLoanRelatedParties.Add("NL1LOROLE");
                newLoanRelatedParties.Add("NL1LONM");
                #endregion

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.New);
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create a new phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Name);
                string phraseGroupName = Support.RandomString("ANAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroupName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("DPUC0008 Reg Test");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("DPUC0008 Reg Test");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Add to enter a new phrase name and description.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Add);
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.PhraseName);
                string phraseName = Support.RandomString("ANAN");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("New Loan Related Parties Phrase");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click the phrase editor button.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Insert Lender- Funding elements";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertTableElement);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.DataElementGroup);
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("New Loan Related Parties");
                Playback.Wait(2000);
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(element: FastDriver.DataElementSelectionDlg.SearchResultsTable);
                for (int i = 0; i < newLoanRelatedParties.Count; i++)
                {
                    FastDriver.DataElementSelectionDlg.SearchResultsTable.PerformTableAction(1, newLoanRelatedParties[i], 1, TableAction.DoubleClick);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Lender- Processor";
                FastDriver.NewLoan.WaitForScreenToLoad().ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "246");
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Lender- Processor");

                Reports.TestStep = "Add Lender- Funding ";
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.SelectItem, "Lender- Funding");

                Reports.TestStep = "Add Lender- Loan Officer";
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "248");
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(4, 1, TableAction.SelectItem, "Lender- Loan Officer");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Click on Add Button, select template and save it";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.Add);
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.SearchDocument("Both", "Escrow Instruction", "description", "CA");
                FastDriver.AdHocDocuments.WaitForResultsToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Select Document and Click on Edit Name Button.";
                FastDriver.DocumentRepository.WaitForScreenToLoad(element: FastDriver.DocumentRepository.DocumentsTable);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Click on Phrase link & enter Phrase Name";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Keyboard.SendKeys("%P");
                Playback.Wait(1000);
                Keyboard.SendKeys("%P");
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad(FastDriver.PhraseSelectDlg.PhraseType);
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad(FastDriver.PhraseSelectDlg.PhraseGroup);
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("DPUC0008 Reg Test[" + phraseGroupName + "]");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad(FastDriver.PhraseSelectDlg.ResultsTable);
                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.DoubleClick);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Verify that data elements where populated with data from related party entries";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad(FastDriver.DocumentPreparationwin.PhraseTable);
                string phraseHeaderID = FastDriver.DocumentPreparationwin.PhraseTable.FAFindElement(ByLocator.XPath, string.Format("//span[text()= '{0}/{1}']", phraseGroupName, phraseName)).FAGetAttribute("id");
                string phraseGroupTableID = phraseHeaderID.Split('_')[0] + "_" + phraseHeaderID.Split('_')[1] + "_grdDocPhrase";
                //Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).IsDisplayed(), "Verifying table was found.");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).PerformTableAction(2, "*NL1 LndrProcsr: ID Code", 3, TableAction.GetInputValue).Message.Clean().Equals("246"), "Verifying data element contains data");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).PerformTableAction(2, "*NL1 LndrProcsr: Lender Role", 3, TableAction.GetInputValue).Message.Clean().Equals("Lender- Processor"), "Verifying data element contains data");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).PerformTableAction(2, "*NL1 LndrProcsr: Name Line 1-2", 3, TableAction.GetCell).Element.FAGetText().Clean().Equals("Chase Manhattan Mortgage Corporation"), "Verifying data element contains data");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).PerformTableAction(2, "NL1 LndrFundng: ID Code", 3, TableAction.GetInputValue).Message.Clean().Equals("247"), "Verifying data element contains data");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).PerformTableAction(2, "NL1 LndrFundng: Lender Role", 3, TableAction.GetInputValue).Message.Clean().Equals("Lender- Funding"), "Verifying data element contains data");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).PerformTableAction(2, "NL1 LndrFundng: Name Line 1-2", 3, TableAction.GetCell).Element.FAGetText().Clean().Equals("Lenders Advantage A Division Of First American Title Ins."), "Verifying data element contains data");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).PerformTableAction(2, "NL1 LndrLnOfcr: ID Code", 3, TableAction.GetInputValue).Message.Clean().Equals("248"), "Verifying data element contains data");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).PerformTableAction(2, "NL1 LndrLnOfcr: Lender Role", 3, TableAction.GetInputValue).Message.Clean().Equals("Lender- Loan Officer"), "Verifying data element contains data");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, phraseGroupTableID).PerformTableAction(2, "NL1 LndrLnOfcr: Name Line 1-2", 3, TableAction.GetInputValue).Message.Clean().Equals("Midwest Financial Group"), "Verifying data element contains data");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0008_REG0007()
        {
            try
            {
                Reports.TestDescription = "TC805905: As user I can add the new Data Element for UW Employee's initials & UW Employee's name onto a template";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                #endregion
                #region create phrase with UW Employee

                string PhraseGroupName1 = "";
                string NewPhrase1 = "";
                string Tempname = "";
                string InformationDescription = "";

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for a phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                PhraseGroupName1 = Support.RandomString("AAAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(PhraseGroupName1);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText(@"Testing UW Employee Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem(@"Title Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText(@"Created for testing UW Employee Phrase");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                NewPhrase1 = Support.RandomString("NZNA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(NewPhrase1);
                FastDriver.PhraseMaintenance.Description.FASetText(@"New created UW Employee Phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("New for testing UW Employee Phrase");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.SwitchToContentFrame();
                var desc = FastDriver.PhraseMaintenance.Description.FAGetValue().Clean();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

                Reports.TestStep = "Click on Insert data element link.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.GetAttribute("src").Contains("images/AddItem.GIF") && i.GetAttribute("class").Contains("tbIcon")
                    && i.Displayed).FAClick();


                Reports.TestStep = "Select a UW Employee data element & enter the value.";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(@"Title Company");
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(FastDriver.DataElementSelectionDlg.SearchResultsTable);

                string DataElementIntials = "UWEMPINTL";
                FastDriver.DataElementSelectionDlg.SearchResultsTable.PerformTableAction(1, DataElementIntials, 1, TableAction.DoubleClick);
                Support.AreEqual(true, FastDriver.DataElementSelectionDlg.SearchResultsTable.FAGetText().Clean().Contains(DataElementIntials), "Found and double click on  " + DataElementIntials + " Underwriter Employee: Intials");
                               
                string DataElementName = "UWEMPNAME";
                FastDriver.DataElementSelectionDlg.SearchResultsTable.PerformTableAction(1, DataElementName, 1, TableAction.DoubleClick);
                Support.AreEqual(true, FastDriver.DataElementSelectionDlg.SearchResultsTable.FAGetText().Clean().Contains(DataElementName), "Found and double click on  " + DataElementName + " Underwriter Employee: Name");


                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);

                Reports.TestStep = "Sending send keys of Save and Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(NewPhrase1.ToUpper() + " - " + desc, true, 20);
                //FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                FastDriver.PhraseEditorDlg.FontName.FASelectItem(@"Times New Roman");
                FastDriver.PhraseEditorDlg.FontSize.FASelectItem(@"12");
                FastDriver.DialogBottomFrame.ClickSave();

                Reports.TestStep = "Verify Data Element for " + DataElementIntials + " and " + DataElementName;

                FastDriver.PhraseEditorDlg.SwitchToTextEditorArea();
                Support.AreEqual(true, FastDriver.PhraseEditorDlg.TextEditorArea.FAGetAttribute("innerHTML").Contains(DataElementIntials + "a"), "Verified" + DataElementIntials + "as UW_Employee Intials is added");
                Support.AreEqual(true, FastDriver.PhraseEditorDlg.TextEditorArea.FAGetAttribute("innerHTML").Contains(DataElementName + "a"), "Verified" + DataElementName + "as UW_Employee Name is added");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                Playback.Wait(1000);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                #region create template with that phrase

                Reports.TestStep = "Click on New button.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Misc Title Document");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Provide template name, description & comments.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                Support.AreEqual(@"0", FastDriver.TemplateMaintenanceInformation.TemplateID.Text.Clean());
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                Tempname = Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(Tempname);
                InformationDescription = Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(InformationDescription);
                if (FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.Selected)
                    FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FAClick();
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText(@"InformationComment");

                Reports.TestStep = "Provide template name, description & comments.";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Template ID will be assigned once the template has been saved.";
                 FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                                
                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateFilterSelectionDlg.Title.FAClick();
                FastDriver.TemplateFilterSelectionDlg.Escrow.FAClick();
                FastDriver.TemplateFilterSelectionDlg.SubEscrow.FAClick();
                FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.TrassactionTypeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.ProgrammeTypeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);
                           

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(@"Misc Title Document");

                Support.value = FastDriver.TemplateMaintenanceSummary.TemplateStatus.FAGetSelectedItem();
                if (Support.value == null)
                    Support.value = "";
                Support.AreEqual(@"Active", Support.value);
                FastDriver.TemplateMaintenanceSummary.Description.FASetText(InformationDescription);

                Reports.TestStep = "Click on Find Now and Select to Edit.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction("Description", InformationDescription, "Status", TableAction.Click);
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter the Description and add Phrase.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(@"Select Created Data Element.");
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem(@"Title Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 5);
                FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(PhraseGroupName1 + "/" + NewPhrase1);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                # region check UW Employee set up

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa07";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa07");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA07]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                FastDriver.BottomFrame.Done();
                #endregion

                #region create file with UW Employee and deliver a doc

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Create a FAST file via Home | Order Entry | Quick File Entry";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton();
                FastDriver.QuickFileEntry.SwitchToContentFrame();

                Reports.TestStep = "Enter a GAB and Required info in the Service area";
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                Reports.TestStep = "Verify that UW Employee default to Blank";
                FastDriver.QuickFileEntry.UW_Employee.IsVisible();
                Support.AreEqual(string.Empty, FastDriver.QuickFileEntry.UW_Employee.FAGetSelectedItem(), "Default to Blank");

                Reports.TestStep = "Select an UW Employee";
                FastDriver.QuickFileEntry.UW_Employee.FASelectItem("QA07, FAST");

                Reports.TestStep = "Enter a FULL Property Address: Street address, City, State, Zip, County";
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("123 Testing Ave");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92630");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");

                Reports.TestStep = "Click Done to create file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();

                Reports.TestStep = "Add Misc Title Document";
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Misc Title Document");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(InformationDescription);
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(2, InformationDescription, 2, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
               // FastDriver.DocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify document added.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, InformationDescription, 4, TableAction.Click);

                Reports.TestStep = "Perform Preview delivery";
                FastDriver.DocumentRepository.Method.FASelectItem("PREVIEW");
                FastDriver.DocumentRepository.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview, 300);

                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\temp2.PDF";
                SavePDFFile(tempPdfFile);

                Reports.TestStep = "Validate UW Employee on document";
                string pdfContent = Support.ReadPdfFile(tempPdfFile).Clean();
                Support.AreEqual("True", pdfContent.Contains("FQ FAST QA07").ToString(), true);

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}