﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.Common;
using System.Linq;
using AutoIt;
using FASTSelenium.PageObjects.IIS;
using System.IO;
//using System.Windows.Forms;

namespace DocPrep
{
    [CodedUITest]
    public class DPUC0016 : MasterTestClass
    {
        static int waitTime = Convert.ToInt32(AutoConfig.WaitTime);

        [TestMethod]
        public void DPUC0016_BAT0001()
        {
            try
            {
                Reports.TestDescription = "[PRE-REQUISITE]: Login TO FAST Application IIS  and delete all old messages in Queue(TestQueue).";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Click on QList link.";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem(@"TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                var rowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                if (rowCount <= 1)
                {
                    Reports.StatusUpdate("No messages are available in the Message Queue table !", true);
                }
                while (rowCount > 1)
                {
                    Reports.TestStep = "Select the doc in the first row and delete it.";

                    FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, "1", 7, TableAction.Click);
                    var msgStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, "1", 7, TableAction.GetText).Message;
                    if (msgStatus == "Locked")
                    {
                        FastDriver.WorkQueueMessagesBrowser.MessageUnlock.FAClick();
                        FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                        FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.Click);
                    }
                    FastDriver.WorkQueueMessagesBrowser.DeleteMessage.FAClick();
                    Playback.Wait(1000);
                    FastDriver.WebDriver.HandleDialogMessage();
                    if (rowCount < 2)
                    {
                        FastDriver.WebDriver.HandleDialogMessage();
                    }
                    FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                    rowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                }
                Support.CloseAllProcessStartingWith("iexplore");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
                Support.CloseAllProcessStartingWith("iexplore");
            }
        }


        [TestMethod]
        public void DPUC0016_BAT0002()
        {
            try
            {
                Reports.TestDescription = "[PRE-REQUISITE]: Login TO FAST Application IIS  and delete all old messages in Queue(email).";

                Reports.StatusUpdate("The below message clean-up steps don't need to be executed, as there are no scenarios involving 'EmailQueue' Queue !", true);

                /* Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Click on QList link.";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                //var 
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem(@"EmailQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                var rowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                while(rowCount > 1)
                {
                    Reports.TestStep = "Select the doc in the first row and delete it.";

                    FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.Click);
                    var msgStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.GetText).Message;
                    if(msgStatus == "Locked")
                    {
                        FastDriver.WorkQueueMessagesBrowser.MessageUnlock.FAClick();
                        FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                        FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.Click);
                    }
                    FastDriver.WorkQueueMessagesBrowser.DeleteMessage.FAClick();

                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                    rowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                }*/
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void DPUC0016_BAT0003()
        {
            try
            {
                Reports.TestDescription = "SetUp_3_ADM: Login TO FAST Application ADM  and set ManualQueue as default Queue.";

                Reports.TestStep = "Login to FAST ADM.";
                this.LoginToADM();

                Reports.TestStep = "Navigate to Region Level.";
                //Select region.
                SelectRegion("1486");

                Reports.TestStep = "Search with Login ID.";
                FastDriver.LeftNavigation.Navigate<ManageWorkQueueUsers>("Home>System Maintenance>Work Queue Setup>Manage Work Queue Users").WaitForScreenToLoad();

                FastDriver.ManageWorkQueueUsers.UserID.FASetText(@"Fastts\fastqa07");

                FastDriver.ManageWorkQueueUsers.SearchNow.FAClick();

                FastDriver.ManageWorkQueueUsers.WaitForScreenToLoad();
                FastDriver.ManageWorkQueueUsers.UserSummaryTable.PerformTableAction(2, "QA07 FAST", 2, TableAction.Click);

                FastDriver.ManageWorkQueueUsers.QueueSummaryTable.PerformTableAction("Queue Name", "QASWFE6", "Default?", TableAction.On);

                FastDriver.BottomFrame.Done();

                FastDriver.ManageWorkQueueUsers.WaitForScreenToLoad();

                Reports.TestStep = "Default Queue has been set on the ADM side. Now, check that the default Queue is 'QASWFE6' on IIS side.";
                LoginToIIS();
                
                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.ClickWorkQTab();
                HandlePostQueueSelectionBehavior();
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Validate that the default Queue is 'QASWFE6'";
                Support.AreEqual("QASWFE6", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod, DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void DPUC0016_BAT0004()
        {
            try
            {
                int UnpdCount = 0;
                int msgsCount = 0;
                Reports.TestDescription = "MF1: Login TO FAST Application File Side and upload a doc in WorkQ.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.ClickWorkQTab();
                HandlePostQueueSelectionBehavior();
                Support.CloseAllProcessStartingWith("AcroRd");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Get the Queue selected by default.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                var defaultWorkQueue = FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem();

                Reports.TestStep = "Select TestQueue from the dropdown.";
                SelectQueueOnWorkQueue("TestQueue");

                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                Support.AreEqual("TestQueue", FastDriver.WorkQueueMessagesBrowser.ForQueue.FAGetSelectedItem());
                GetMessageCountAndPublishOnWorkQ(out UnpdCount, out msgsCount);

                Reports.TestStep = "Upload a file.";
                if (!UploadFileOnWorkQ())
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }

                //int UnpdCount2 = int.Parse(FastDriver.WorkQueueTop.UnpdCount.FAGetText());
                //Support.AreEqual((UnpdCount + 1).ToString(), UnpdCount2.ToString());

                Reports.TestStep = "Upload the same file once again.";
                if (!UploadFileOnWorkQ())
                {
                    Reports.StatusUpdate("Second File upload is unsuccessful !", false);
                }

                Reports.TestStep = "Refresh Work Queue.";
                SelectQueueOnWorkQueue("FaxQueue");


                Reports.TestStep = "Change the Queue back to TestQueue.";
                SelectQueueOnWorkQueue("TestQueue");

                Reports.TestStep = "Click on Next.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.Next.FAClick();
                HandlePostQueueSelectionBehavior();
                Support.CloseAllProcessStartingWith("AcroRd");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                //FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Next again.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.Next.FAClick();
                HandlePostQueueSelectionBehavior();
                Support.CloseAllProcessStartingWith("AcroRd");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                //FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                Reports.TestStep = "Handle the alert, if appears.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate the Unpaid and Messages count.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                ValidateMessageCountOnWorkQ(UnpdCount, msgsCount, 2);

                Reports.TestStep = "Click on WorkN link.";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.WorkN.FAClick();
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();

                Support.AreEqual("false", FastDriver.WorkQueueTop.UnpdCount.IsVisible().ToString().ToLower());
                Support.CloseAllProcessStartingWith("iexplore");
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
                Support.CloseAllProcessStartingWith("iexplore");
            }
        }


        [TestMethod, DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void DPUC0016_BAT0005()
        {
            try
            {
                int UnpdCount = 0;
                int msgsCount = 0;

                Reports.TestDescription = "MF1: Login TO FAST Application File Side and upload a doc in WorkQ.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                // Reports.TestStep = "Create a file with default values.";
                // var fileNumber = CreateFile(true);

                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.ClickWorkQTab();

                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify Default value on Work Queue Screen.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                var defaultWorkQueue = FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem();

                Reports.TestStep = "Select TestQueue from the dropdown.";
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"TestQueue");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                //FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());

                GetMessageCountAndPublishOnWorkQ(out UnpdCount, out msgsCount);

                Reports.TestStep = "Upload a file.";
                if (!UploadFileOnWorkQ())
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }
                //int UnpdCount2 = int.Parse(FastDriver.WorkQueueTop.UnpdCount.FAGetText());
                //Support.AreEqual((UnpdCount + 1).ToString(), UnpdCount2.ToString());

                Reports.TestStep = "Refresh Work Queue.";
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"FaxQueue");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                //FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(10000);//wait in case any PDF file is still downloading to be displayed, which needs to be closed.
                Support.CloseAllProcessStartingWith("AcroRd");


                Reports.TestStep = "Select TestQueue from the dropdown.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"TestQueue");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                //FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(10000);//wait in case any PDF file is still downloading to be displayed, which needs to be closed.
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Unpaid and Messages count.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                ValidateMessageCountOnWorkQ(UnpdCount, msgsCount);


                Reports.TestStep = "Click on Attach.";
                FastDriver.WorkQueueTop.Attach.FAClick();

                Reports.TestStep = "Attach the file to workqueue.";
                FastDriver.AttachMessageDlg.WaitForScreenToLoad();

                FastDriver.AttachMessageDlg.Region.FASelectItem(AutoConfig.SelectedRegionName);

                FastDriver.AttachMessageDlg.FileNo.FASetText("test");
                FastDriver.AttachMessageDlg.DocumentType.FASelectItem(@"Escrow: Payoff Demand/Bills");
                FastDriver.AttachMessageDlg.DocumentName.FASelectItem("Miscellaneous");

                FastDriver.AttachMessageDlg.WQTriggerNames.FASelectItem(@"ATTY SCANNED");

                FastDriver.AttachMessageDlg.PageNumbersRange.FASetText("1");
                FastDriver.AttachMessageDlg.Comments.FASetText("Comments for Attachment.");
                FastDriver.AttachMessageDlg.Done.FAClick();


                Reports.TestStep = "Handle the alert.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Delete.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());
                FastDriver.WorkQueueTop.Delete.FAClick();

                Reports.TestStep = "Handle the alert.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on WorkN link.";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.WorkN.FAClick();
                Support.CloseAllProcessStartingWith("iexplore");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
                Support.CloseAllProcessStartingWith("iexplore");
            }
        }


        [TestMethod, DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void DPUC0016_BAT0006()
        {
            try
            {
                int UnpdCount;
                int msgsCount;

                Reports.TestDescription = "AF2: Click on workN link on Top Frame and upload the doc and move to other Queue.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.ClickWorkQTab();

                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Get the default value on the Work Queue Screen.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                var defaultWorkQueue = FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem();

                Reports.TestStep = "Select TestQueue from the dropdown.";
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"TestQueue");
                Playback.Wait(1000);
                HandlePostQueueSelectionBehavior();

                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());

                GetMessageCountAndPublishOnWorkQ(out UnpdCount, out msgsCount);

                Reports.TestStep = "Upload a file.";
                if (!UploadFileOnWorkQ())
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }
                //int UnpdCount2 = int.Parse(FastDriver.WorkQueueTop.UnpdCount.FAGetText());
                //Support.AreEqual((UnpdCount + 1).ToString(), UnpdCount2.ToString());

                Reports.TestStep = "Refresh Work Queue.";
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"FaxQueue");
                try
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                    {
                        FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                    }
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
                catch
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                }

                Reports.TestStep = "Select TestQueue from the dropdown.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"TestQueue");

                HandlePostQueueSelectionBehavior();

                Reports.TestStep = "Validate the Unpaid Count.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                ValidateMessageCountOnWorkQ(UnpdCount, msgsCount);

                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());


                Reports.TestStep = "Click on Move.";
                FastDriver.WorkQueueTop.Move.FAClick();


                Reports.TestStep = "Enter work Queue Name.";
                FastDriver.MoveWorkQMessageDlg.WaitForScreenToLoad();
                FastDriver.MoveWorkQMessageDlg.QueueList.FASelectItemByIndex(3);

                FastDriver.MoveWorkQMessageDlg.Comments.FASetText(@"Moving data to the Next Queue available");

                FastDriver.MoveWorkQMessageDlg.WaitForScreenToLoad(FastDriver.MoveWorkQMessageDlg.Done);
                FastDriver.MoveWorkQMessageDlg.Done.FAClick();
                HandlePostQueueSelectionBehavior();

                //Reports.TestStep = "Handle the alert.";
                //FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on WorkN link.";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.WorkN.FAClick();

                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                Support.CloseAllProcessStartingWith("iexplore");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
                Support.CloseAllProcessStartingWith("iexplore");
            }
        }


        [TestMethod, DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void DPUC0016_BAT0007()
        {
            try
            {
                int UnpdCount = 0;
                int msgsCount = 0;
                Reports.TestDescription = "AF3: Click on workN link on Top Frame and upload a doc and verify the same in work Queue message.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.ClickWorkQTab();
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify Default value on Work Queue Screen.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                var defaultWorkQueue = FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem();

                Reports.TestStep = "Select TestQueue from the dropdown.";
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"TestQueue");
                HandlePostQueueSelectionBehavior();

                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());
                GetMessageCountAndPublishOnWorkQ(out UnpdCount, out msgsCount);

                Reports.TestStep = "Upload a file.";
                if (!UploadFileOnWorkQ())
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }

                Reports.TestStep = "Upload the second file.";
                if (!UploadFileOnWorkQ())
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }

                Reports.TestStep = "Upload the third file.";
                if (!UploadFileOnWorkQ())
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }

                Reports.TestStep = "Refresh Work Queue.";
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"FaxQueue");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();


                Reports.TestStep = "Select TestQueue from the dropdown.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"TestQueue");
                HandlePostQueueSelectionBehavior();
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Unpaid and Messages Count.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                ValidateMessageCountOnWorkQ(UnpdCount, msgsCount, 3);
                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());

                Reports.TestStep = "Click on Delete.";
                FastDriver.WorkQueueTop.Delete.FAClick();

                //Try-catch block below added to catch the exception when 'No messages available...' pop-up is displayed with some delay.-25-05-2016
                Reports.TestStep = "Handle the alert.";
                try
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                    Playback.Wait(2000);
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                catch
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                Reports.TestStep = "Click on QList link.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.QList.FAClick();

                Reports.TestStep = "Select a doc. and delete it.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                HandlePostQueueSelectionBehavior();
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.Click);
                var deletedQueue = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                FastDriver.WorkQueueMessagesBrowser.DeleteMessage.FAClick();

                Reports.TestStep = "Click OK on the alert.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();


                Reports.TestStep = "Select the Queue and unlock the message.";
                if (!FastDriver.WorkQueueMessagesBrowser.DeletedOnly.IsSelected())
                {
                    FastDriver.WorkQueueMessagesBrowser.DeletedOnly.FAClick();
                }

                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, deletedQueue, 7, TableAction.Click);
                var currentQueueStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, deletedQueue, 7, TableAction.GetText).Message;
                if (currentQueueStatus != "Deleted" && currentQueueStatus != "Failed")
                {
                    Reports.StatusUpdate("The status of the deleted Queue is not either 'Deleted' or 'Failed' !", false, "", "", "", "", currentQueueStatus);
                }
                else
                {
                    Reports.StatusUpdate("The status of the deleted Queue is :'" + currentQueueStatus + "'", true);
                }

                FastDriver.WorkQueueMessagesBrowser.ViewSelectedImage.FAClick();
                HandlePostQueueSelectionBehavior();
                Support.CloseAllProcessStartingWith("AcroRd");
                if (!CloseFileViewerDialog())
                {
                    Reports.StatusUpdate("Attempt - 2 : Trying to locate the File Viewer Dialog and close it", true);
                    if (CloseFileViewerDialog())
                    {

                    }
                }
                Support.CloseAllProcessStartingWith("AcroRd");

                //This code block is meant for switching to an intended window and close it based on the name/title of the window. But, didn't work as intended.
                /*  var windowsColl = FastDriver.WebDriver.WindowHandles;
                  foreach(var wndHandle in windowsColl)
                  {
                      /*****************The below statement invariably hung while switching to the file veiwer dialog. But, successfully switching to the main window. No cause found so far.
                      var actualTitle = FastDriver.WebDriver.SwitchTo().Window(wndHandle).Title;
                      if(actualTitle.Contains("Work Queue Message Viewer"))
                      {
                          FastDriver.WebDriver.Close();
                        //  FastDriver.WebDriver.WaitForWindowAndSwitch()
                          FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                          break;
                      }
                  }*/

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                if (FastDriver.WorkQueueMessagesBrowser.DeletedOnly.IsSelected())
                {
                    FastDriver.WorkQueueMessagesBrowser.DeletedOnly.FAClick();
                    FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                }

                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, deletedQueue, 3, TableAction.Click);
                currentQueueStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, deletedQueue, 7, TableAction.GetText).Message;
                if (currentQueueStatus != "Waiting" && currentQueueStatus != "Locked" && currentQueueStatus != "Staging" && currentQueueStatus != "Attached")
                {
                    Reports.StatusUpdate("The undeleted Queue status should be 'Waiting'!", false, "", "", "", "", currentQueueStatus);
                }
                else
                {
                    Reports.StatusUpdate("The status of the undeleted Queue is :'" + currentQueueStatus + "'", true);
                }

                FastDriver.WorkQueueMessagesBrowser.MessageHistory.FAClick();

                FastDriver.WorkQueueMessageLogDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify the undeleted Queue has been recorded.";
                string comments = "";
                if (currentQueueStatus == "Staging" || currentQueueStatus == "Locked")
                {
                    FastDriver.WorkQueueMessageLogDlg.MsgQueueTable.PerformTableAction(2, currentQueueStatus, 3, TableAction.Click);
                    comments = FastDriver.WorkQueueMessageLogDlg.MsgQueueTable.PerformTableAction("Status", currentQueueStatus, "Comments", TableAction.GetText).Message;
                    Reports.StatusUpdate("Comments may be holding the empty string, as the current Queue status is not Received. Comments :" + comments, true);
                }
                else if (currentQueueStatus == "Waiting")
                {
                    FastDriver.WorkQueueMessageLogDlg.MsgQueueTable.PerformTableAction(2, "Received", 3, TableAction.Click);
                    comments = FastDriver.WorkQueueMessageLogDlg.MsgQueueTable.PerformTableAction("Status", "Received", "Comments", TableAction.GetText).Message;
                    Reports.StatusUpdate("Check that the file 'EMAIL_Offshore_Pdf.pdf' is mentioned in the comments ?", comments.Contains("EMAIL_Offshore_Pdf.pdf"));
                }

                FastDriver.WorkQueueMessageLogDlg.Done.FAClick();
                Support.CloseAllProcessStartingWith("iexplore");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
                Support.CloseAllProcessStartingWith("iexplore");
            }
        }

        [TestMethod]
        public void DPUC0016_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF4: Click on WorkN link on Top Frame , set the priority and Delete the Message and/or Undelete Message(s) for Process, Alternate Course: View Message History.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Open QList page.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.QList.FAClick();

                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Reports.TestStep = "Unlock a message.";
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                //HandlePostQueueSelectionBehavior();
                //Playback.Wait(3000);
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.Click);
                FastDriver.WorkQueueMessagesBrowser.MessageUnlock.FAClick();

                Reports.TestStep = "Set the priority for message the Message from Queue.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction("Status", "Waiting", "Status", TableAction.Click);
                FastDriver.WorkQueueMessagesBrowser.SetPriority.FAClick();

                Reports.TestStep = "Select the priority and Click on Done.";
                FastDriver.QueuePriorityDlg.WaitForScreenToLoad();
                FastDriver.QueuePriorityDlg.SelectPriority.FASelectItem("Critical");
                FastDriver.QueuePriorityDlg.Done.FAClick();

                Reports.TestStep = "Click on QList link.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.QList.FAClick();

                Reports.TestStep = "Verify that priority is critical.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                //FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction("Priority", "Critical", "Priority", TableAction.Click);
                int rowIdx = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction("Priority", "Critical", "Priority", TableAction.Click).CurrentRow + 1;
                FastDriver.WorkQueueMessagesBrowser.MessageUnlock.FAClick();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                var currentPriority = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIdx, 8, TableAction.GetText).Message;
                Reports.StatusUpdate("Verify the message is unlocked by testing current Priority of the message.", currentPriority.Clean() == string.Empty);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod, DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void DPUC0016_REG0001()
        {
            try
            {
                Reports.TestDescription = "DP7200_DP7202_DP10140_DP7204_DP7234_DP7347_DP10150_EWC_4_001: 1.Activat Work Queues 2.Enabl or Disable Work Queues 3.Work Queue User 4.Process Work Queue Process Toolbar 5.Upload Message 6.Attach Image Page 7.Del";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Open QList page.";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                SelectQueueOnQList("TestQueue");

                Reports.StatusUpdate("Checking that the number of files available on QList is more than 11.",true);
                if (FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount() > 11)
                {
                    Reports.StatusUpdate("Number of files available on QList is more than 11. About to remove files..only 10 files will be retained ! .", true);
                    RemoveFilesOnQList();
                }

                var docCountOnQList = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount() - 1;

                FastDriver.TopFrame.WaitForScreenToLoad();
                var a = FastDriver.TopFrame.QList.IsVisible().ToString().ToLower();
                var b = FastDriver.TopFrame.WorkQ.IsVisible().ToString().ToLower();
                Support.AreEqual("true", FastDriver.TopFrame.QList.IsVisible().ToString().ToLower());
                Support.AreEqual("true", FastDriver.TopFrame.WorkQ.IsVisible().ToString().ToLower());

                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.ClickWorkQTab();
                HandlePostQueueSelectionBehavior();
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                FastDriver.TopFrame.SwitchToTopFrame();
                Support.AreEqual("true", FastDriver.TopFrame.WorkN.IsVisible().ToString().ToLower());

                Reports.TestStep = "Upload a file for 'TestQueue'.";
                SelectQueueOnWorkQueue("TestQueue");
                Support.CloseAllProcessStartingWith("AcroRd");

                if (!UploadFileOnWorkQ())
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }

                Reports.TestStep = "Select EmailQueueedited in Queue.";
                SelectQueueOnWorkQueue("EmailQueueedited");
                Support.CloseAllProcessStartingWith("AcroRd");

                Reports.TestStep = "Select Manual Upload in Queue.";
                SelectQueueOnWorkQueue("TestQueue");
                Support.CloseAllProcessStartingWith("AcroRd");

                Reports.TestStep = "Navigate to QList and select 'TestQueue'";
                FastDriver.TopFrame.ClickQListTab();
                SelectQueueOnQList("TestQueue");
                Playback.Wait(3000);

                Reports.TestStep = "Validate Number of docs present.";

                int stagingCount = 0;
                if (FastDriver.WorkQueueMessagesBrowser.MessageTable.IsVisible())
                {
                    var rowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                    for (int i = 2; i <= rowCount;i++ )
                    {
                        var msgStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(i, 7, TableAction.GetText).Message;
                        if (msgStatus == "Staging")
                        {
                            stagingCount++;
                        }
                    }
                }
                docCountOnQList = docCountOnQList - stagingCount;
                if (FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount() <= 21)
                    Support.AreEqual((docCountOnQList + 1).ToString(), (FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount() - (1+stagingCount)).ToString());
                if (FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount() > 21)
                    Support.AreEqual((docCountOnQList + 1).ToString(), (FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount() - (2+stagingCount)).ToString());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void DPUC0016_REG0002()
        {
            try
            {
                Reports.TestDescription = "DP7200_DP7202_DP10140_DP7204_DP7234_DP7347_DP10150_EWC_4_001_1:";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Navigate to WorkQ.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WorkQ.FAClick();
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Select Manual Upload in Queue.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                SelectQueueOnWorkQueue("TestQueue");

                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());
                var msgs = int.Parse(FastDriver.WorkQueueTop.Msgs.FAGetText());
                var unpd = int.Parse(FastDriver.WorkQueueTop.Unpd.FAGetText());
                var skp = int.Parse(FastDriver.WorkQueueTop.Skp.FAGetText());
                Reports.StatusUpdate("Msgs count :" + msgs + ", Unpaid Count :" + unpd + ", Skip count :" + skp, true);
                if (msgs == 0)
                {
                    UploadFileOnWorkQ();
                }

                Reports.TestStep = "Click on Delete.";
                FastDriver.WorkQueueTop.Delete.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                Support.AreEqual((msgs - 1).ToString(), FastDriver.WorkQueueTop.Msgs.FAGetText());
                Support.AreEqual((unpd - 1).ToString(), FastDriver.WorkQueueTop.Unpd.FAGetText());
                if (skp > 0)
                    Support.AreEqual((skp - 1).ToString(), FastDriver.WorkQueueTop.Skp.FAGetText());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void DPUC0016_REG0003()
        {
            try
            {

                Reports.TestDescription = "DP7200_DP7202_DP10140_DP7204_DP7234_DP7347_DP10150_EWC_4_001_2:";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);

                Reports.TestStep = "Navigate to WorkQ.";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.ClickWorkQTab();
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Select Manual Upload in Queue.";
                SelectQueueOnWorkQueue("TestQueue");

                Reports.TestStep = "Upload a file.";
                if (!UploadFileOnWorkQ(@"\Hello.pdf"))
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }

                if (!UploadFileOnWorkQ(@"\Hello.pdf"))
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }
                if (!UploadFileOnWorkQ(@"\Hello.pdf"))
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }

                var msgs = int.Parse(FastDriver.WorkQueueTop.Msgs.FAGetText());
                var unpd = int.Parse(FastDriver.WorkQueueTop.Unpd.FAGetText());
                var skp = int.Parse(FastDriver.WorkQueueTop.Skp.FAGetText());

                /*Reports.TestStep = "Upload the same previous file second time.";
                if (!UploadFileOnWorkQ(@"\Hello.pdf"))
                {
                    Reports.StatusUpdate("Second instance of file upload is unsuccessful !", false);
                }

                Reports.TestStep = "Upload the same previous file third time.";
                if (!UploadFileOnWorkQ(@"\Hello.pdf"))
                {
                    Reports.StatusUpdate("Second instance of file upload is unsuccessful !", false);
                }

                Reports.TestStep = "Upload the same previous file fourth time.";
                if (!UploadFileOnWorkQ(@"\Hello.pdf"))
                {
                    Reports.StatusUpdate("Second instance of file upload is unsuccessful !", false);
                }

                Reports.TestStep = "Upload the same previous file fifth time.";
                if (!UploadFileOnWorkQ(@"\Hello.pdf"))
                {
                    Reports.StatusUpdate("Second instance of file upload is unsuccessful !", false);
                }*/

                Reports.TestStep = "Navigate to QList page.";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Reports.TestStep = "Select Manual Upload in Queue.";
                SelectQueueOnQList("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                Support.AreEqual("TestQueue", FastDriver.WorkQueueMessagesBrowser.ForQueue.FAGetSelectedItem());

                var msgCountOnQList = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();

                Reports.TestStep = "Select a File and Click on Message Details.";
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction("Status", "Waiting", "Status", TableAction.Click);
                FastDriver.WorkQueueMessagesBrowser.MessageDetails.FAClick();

                Reports.TestStep = "Add Comments to a Doc.";
                FastDriver.WorkQueueMessageDetailsDlg.WaitForScreenToLoad();
                FastDriver.WorkQueueMessageDetailsDlg.Comments.FASetText("Test for DPUC0016");
                FastDriver.WorkQueueMessageDetailsDlg.Done.FAClick();

                Reports.TestStep = "Verify Messages counter in WorkQ Menu Bar.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                SelectQueueOnWorkQueue("TestQueue");
                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());
                Support.AreEqual((msgs).ToString(), FastDriver.WorkQueueTop.Msgs.FAGetText());
                Support.AreEqual((unpd).ToString(), FastDriver.WorkQueueTop.Unpd.FAGetText());
                Support.AreEqual((skp).ToString(), FastDriver.WorkQueueTop.Skp.FAGetText());

                Reports.TestStep = "Click on Attach.";
                FastDriver.WorkQueueTop.Attach.FAClick();
                FastDriver.AttachMessageDlg.WaitForScreenToLoad();

                FastDriver.AttachMessageDlg.FileNo.FASetText(fileNumber);
                FastDriver.AttachMessageDlg.DocumentType.FASelectItem(@"Corporate Underwriting");
                FastDriver.AttachMessageDlg.DocumentName.FASelectItem(@"UW Misc");
                FastDriver.AttachMessageDlg.Comments.FASetText(@"Test for DPUC0016");
                FastDriver.AttachMessageDlg.Done.FAClick();

                Reports.TestStep = "Validate a Message and click on OK.";
                var alertText = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Attach submitted", alertText);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }




        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void DPUC0016_REG0004()
        {
            try
            {

                Reports.TestDescription = "DP7200_DP7202_DP10140_DP7204_DP7234_DP7347_DP10150_EWC_4_001_3:";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                //var fileNumber = CreateFile(true);
                var fileNumber = "123456";

                Reports.TestStep = "Navigate to WorkQ.";
                Support.CloseAllProcessStartingWith("AcroRd");

                //FastDriver.TopFrame.WaitForScreenToLoad();
                //FastDriver.TopFrame.WorkQ.FADoubleClick();
                //HandlePostQueueSelectionBehavior();

                //FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();

                FastDriver.TopFrame.ClickWorkQTab();

                //HandlePostQueueSelectionBehavior();
                Support.CloseAllProcessStartingWith("AcroRd");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Select Manual Upload in Queue.";
                SelectQueueOnWorkQueue("TestQueue");
                Support.CloseAllProcessStartingWith("AcroRd");

                Reports.TestStep = "Upload a file.";
                if (!UploadFileOnWorkQ(@"\Hello.pdf"))
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }
                else
                {
                    SelectQueueOnWorkQueue("FaxQueue");
                    SelectQueueOnWorkQueue("TestQueue");
                }

                var msgs = int.Parse(FastDriver.WorkQueueTop.Msgs.FAGetText());
                var unpd = int.Parse(FastDriver.WorkQueueTop.Unpd.FAGetText());
                var skp = int.Parse(FastDriver.WorkQueueTop.Skp.FAGetText());

                Reports.TestStep = "Open QList page.";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Reports.TestStep = "Select Manual Upload in Queue.";
                SelectQueueOnQList("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                Support.AreEqual("TestQueue", FastDriver.WorkQueueMessagesBrowser.ForQueue.FAGetSelectedItem());

                var msgCountOnQList = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();

                Reports.TestStep = "Select a File and click on Message Details.";
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction("Status", "Waiting", "Status", TableAction.Click);
                FastDriver.WorkQueueMessagesBrowser.MessageDetails.FAClick();

                Reports.TestStep = "Add Comments to a Doc.";
                FastDriver.WorkQueueMessageDetailsDlg.WaitForScreenToLoad();
                FastDriver.WorkQueueMessageDetailsDlg.Comments.FASetText("Test for DPUC0016");
                FastDriver.WorkQueueMessageDetailsDlg.Done.FAClick();

                Reports.TestStep = "Verify Messages counter in WorkQ Menu Bar-1.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                SelectQueueOnWorkQueue("FaxQueue");
                SelectQueueOnWorkQueue("TestQueue");
                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());
                Support.AreEqual((msgs).ToString(), FastDriver.WorkQueueTop.Msgs.FAGetText());
                Support.AreEqual((unpd).ToString(), FastDriver.WorkQueueTop.Unpd.FAGetText());
                Support.AreEqual((skp).ToString(), FastDriver.WorkQueueTop.Skp.FAGetText());

                Reports.TestStep = "Click on Attach.";
                FastDriver.WorkQueueTop.Attach.FAClick();
                FastDriver.AttachMessageDlg.WaitForScreenToLoad();

                FastDriver.AttachMessageDlg.FileNo.FASetText(fileNumber);
                FastDriver.AttachMessageDlg.DocumentType.FASelectItem(@"Corporate Underwriting");
                FastDriver.AttachMessageDlg.DocumentName.FASelectItem(@"UW Misc");
                FastDriver.AttachMessageDlg.Comments.FASetText(@"Test for DPUC0016");
                FastDriver.AttachMessageDlg.Done.FAClick();

                Reports.TestStep = "Validate a Message and click on OK.";
                var alertText = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Attach submitted", alertText);


                Reports.TestStep = "Verify Messages counter in WorkQ Menu Bar-2.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                SelectQueueOnWorkQueue("FaxQueue");
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                SelectQueueOnWorkQueue("TestQueue");
                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());
                //Support.AreEqual((msgs - 1).ToString(), FastDriver.WorkQueueTop.Msgs.FAGetText());
                //Support.AreEqual((unpd - 1).ToString(), FastDriver.WorkQueueTop.Unpd.FAGetText());
                Playback.Wait(2000);
                Support.AreEqual((msgs-1).ToString(), FastDriver.WorkQueueTop.Msgs.FAGetText());
                Support.AreEqual((unpd-1).ToString(), FastDriver.WorkQueueTop.Unpd.FAGetText());

                if (skp > 0)
                    Support.AreEqual((skp - 1).ToString(), FastDriver.WorkQueueTop.Skp.FAGetText());
                msgs = int.Parse(FastDriver.WorkQueueTop.Msgs.FAGetText());
                unpd = int.Parse(FastDriver.WorkQueueTop.Unpd.FAGetText());
                skp = int.Parse(FastDriver.WorkQueueTop.Skp.FAGetText());

                Reports.TestStep = "Verify that the number of messages on WorkQ is matching with the number of files on QList page with the status other than 'Attached'.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                SelectQueueOnWorkQueue("TestQueue");

                Reports.TestStep = "Get the current Message count.";
                var msgCountInOtherQueue = int.Parse(FastDriver.WorkQueueTop.Msgs.FAGetText());
                var unpdCountInOtherQueue = int.Parse(FastDriver.WorkQueueTop.Unpd.FAGetText());
                var skipCountInOtherQueue = int.Parse(FastDriver.WorkQueueTop.Skp.FAGetText());

                Reports.TestStep = "Select 'TestQueue' Queue.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                SelectQueueOnQList("TestQueue");

                /*if (IsWorkQMsgCountMatchingWithQlistFileCount(msgs))
                {
                    Reports.StatusUpdate("Number of Messages on WorkQ is matching with the number of non-attached files on QList !", true);
                }
                else
                {
                    Reports.StatusUpdate("Number of Messages on WorkQ is not matching with the number of non-attached files on QList !", false);
                }*/


                Reports.TestStep = "Click on Move.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                SelectQueueOnWorkQueue("TestQueue");
                FastDriver.WorkQueueTop.Move.FAClick();

                Reports.TestStep = "Enter details before moving message to another Queue.";
                FastDriver.MoveWorkQMessageDlg.WaitForScreenToLoad();

                FastDriver.MoveWorkQMessageDlg.QueueList.FASelectItem("EmailQueueedited");
                FastDriver.MoveWorkQMessageDlg.Comments.FASetText(@"Test for DPUC0016");
                FastDriver.MoveWorkQMessageDlg.Done.FAClick();

                Reports.TestStep = "Verify Messages counter in WorkQ Menu Bar for 'TestQueue.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                Support.AreEqual("TestQueue", FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem());
                var a = FastDriver.WorkQueueTop.Msgs.FAGetText();
                Support.AreEqual((msgs - 1).ToString(), FastDriver.WorkQueueTop.Msgs.FAGetText());
                Support.AreEqual((unpd - 1).ToString(), FastDriver.WorkQueueTop.Unpd.FAGetText());
                if (skp > 0)
                    Support.AreEqual((skp - 1).ToString(), FastDriver.WorkQueueTop.Skp.FAGetText());

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf"), DeploymentItem(@"Common\Support\GeneralForm.doc"), DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void DPUC0016_REG0005()
        {


            try
            {

                Reports.TestDescription = "DP9190_DP10139_DP10141_DP10145_003: 1.QList Work Queue Message Browser 2.Main FAST Menu Bar 3.QList Work Queue Message Browser Supervisor Rights 4.View Selected Image.";
                string[] docList = { @"\EMAIL_Offshore_Pdf.pdf", @"\Hello.pdf", @"\GeneralForm.doc", @"\GeneralForm.doc", @"\EMAIL_Offshore_Pdf.pdf", @"\Hello.pdf" };
                int fileCount = 0, docCountToBeUploaded = 0;
                int totalDocsRequired = 6;

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                /*****************Pre-requisite******************* */
                Reports.TestStep = "Navigate to WorkQ.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                SelectQueueOnQList("TestQueue");

                /*Count the number of files available on QList page for 'TestQueue' by default.*/

                var QList_CurrentMsgCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                if (QList_CurrentMsgCount < totalDocsRequired)
                {
                    docCountToBeUploaded = totalDocsRequired - (QList_CurrentMsgCount - 1); //deduction by one is to exclude the col header.
                    fileCount = QList_CurrentMsgCount - 1;
                }
                /*************************************************************/

                /*Based on the count of the files yet to be uplaoded, start uploading the files*/
                FastDriver.TopFrame.ClickWorkQTab();
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Select Manual Upload in Queue.";
                SelectQueueOnWorkQueue("TestQueue");

                while (docCountToBeUploaded <= totalDocsRequired)
                {
                    Reports.TestStep = "Upload a file-" + (fileCount + 1) + ".";
                    if (!UploadFileOnWorkQ(docList[fileCount]))
                    {
                        Reports.StatusUpdate("File upload is unsuccessful !", false);
                    }
                    else
                    {
                        Reports.StatusUpdate("File upload is successful !", true);
                        docCountToBeUploaded--;
                    }
                    fileCount++;
                    if (docCountToBeUploaded <= 0 || fileCount >= 6)
                    {
                        break;
                    }
                }
                /********************************************************/

                Reports.TestStep = "Open QList page.";
                FastDriver.TopFrame.ClickQListTab();

                Reports.TestStep = "Delete GeneralForm.doc as a part of pre-requisite for this test.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction("Status", "Waiting", "Status", TableAction.Click);
                FastDriver.WorkQueueMessagesBrowser.DeleteMessage.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueTop.WaitForScreenToLoad();


                var msgs = int.Parse(FastDriver.WorkQueueTop.Msgs.FAGetText());
                var unpd = int.Parse(FastDriver.WorkQueueTop.Unpd.FAGetText());
                var skp = int.Parse(FastDriver.WorkQueueTop.Skp.FAGetText());
                /****************************************************************/


                Reports.TestStep = "Open QList page.";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Reports.TestStep = "Select Manual Upload in Queue.";
                SelectQueueOnQList("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                Support.AreEqual("TestQueue", FastDriver.WorkQueueMessagesBrowser.ForQueue.FAGetSelectedItem());

                var msgCountOnQList = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();


                /************************Validate Delete Message Behavior***************************************/
                Reports.TestStep = "Check Delete only and view the order of deleted docs.";

                if (!FastDriver.WorkQueueMessagesBrowser.DeletedOnly.IsSelected())
                {
                    FastDriver.WorkQueueMessagesBrowser.DeletedOnly.FAClick();
                    FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                }

                bool locatedProcessedStatus = false;
                bool locatedDeletedStatus = false;
                for (int i = 1; i <= msgCountOnQList; i++)
                {
                    var fileStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(i, 7, TableAction.GetText).Message;
                    if (fileStatus == "Processed")
                    {
                        Reports.StatusUpdate("Located a file with Processed status", true);
                        locatedProcessedStatus = true;
                    }
                    if (fileStatus == "Deleted")
                    {
                        Reports.StatusUpdate("Located a file with Deleted status", true);
                        locatedDeletedStatus = true;
                    }
                    if (locatedDeletedStatus || locatedProcessedStatus)
                    {
                        break;
                    }
                }
                if (!locatedDeletedStatus)
                {
                    Reports.StatusUpdate("Could not locate a file with Deleted status", false);
                }
                if (!locatedProcessedStatus)
                {
                    Reports.StatusUpdate("Could not locate a file with Processed status", true);
                }

                if (FastDriver.WorkQueueMessagesBrowser.DeletedOnly.IsSelected())
                {
                    FastDriver.WorkQueueMessagesBrowser.DeletedOnly.FAClick();
                    FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                }
                /**********************************************************************************************************/

                /********************************View Selected Image****************************************************/
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction("Status", "Waiting", "Status", TableAction.Click);
                var fullFileName = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(7, "Waiting", 3, TableAction.GetText).Message;
                var actualFileName = fullFileName.Substring(fullFileName.LastIndexOf(@"\")).Split('@').FirstOrDefault().Replace("\\", string.Empty);

                FastDriver.WorkQueueMessagesBrowser.ViewSelectedImage.FAClick();
                HandlePostQueueSelectionBehavior();
                Playback.Wait(8000);
                Support.CloseAllProcessStartingWith("AcroRd");
                CloseFileViewerDialog();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Work Queue",true,12,false);
                //                var newWindowURL = FastDriver.WebDriver.Url;//.LastIndexOf(@"/");
                //var fileNameInURL = newWindowURL.Substring(newWindowURL.LastIndexOf(@"/")).Split('@').FirstOrDefault();
                //Support.AreEqual(actualFileName, fileNameInURL);
                //Keyboard.SendKeys("%{F4}");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true);
                /********************************************************************************************************/
                /******************************Unlock A Message********************************************************/
                bool fileLocatedWithLockedStatus = false;
                Reports.TestStep = "Unlock a message.Firstly, perform steps to have a Locked status for one of the files in Waiting status.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                SelectQueueOnWorkQueue("TestQueue");
                //SelectQueueOnWorkQueue("TestQueue");

                SelectQueueOnQList("TestQueue");
                //SelectQueueOnQList("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(7, "Locked", 7, TableAction.Click);
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(7, "Locked", 4, TableAction.GetText).Message);
                FastDriver.WorkQueueMessagesBrowser.MessageUnlock.FAClick();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                var a = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();

                for (int i = 1; i < FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount(); i++)
                {
                    var fileStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(i, 7, TableAction.GetText).Message;
                    if (fileStatus == "Locked")
                    {
                        Reports.StatusUpdate("DEFECT : File with Locked status is found even after unlocking !", false);
                        fileLocatedWithLockedStatus = true;
                    }
                }
                if (!fileLocatedWithLockedStatus)
                {
                    Reports.StatusUpdate("File with Locked status was not found after unlocking !", true);
                }
                /******************************************************************************************************/

                /************************************Move a doc to the top of the table**********************************/
                string fileToMoveToTop = "";
                string fileDateTimeForMoveToTop = "";
                string fileNameInFirstRow = "";
                string fileDateTimeInFirstRow = "";
                bool IsFileAvailableForMoving = false;
                a = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                int rowIndex = 2;
                while (rowIndex <= totalDocsRequired)
                {
                    var tmpStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIndex, 7, TableAction.GetText).Message;
                    var priority = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIndex, 8, TableAction.GetText).Message.Clean();
                    /*if (tmpStatus != "Converting" && tmpStatus != "Locked")
                    {
                        fileNameInFirstRow = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIndex, 3, TableAction.GetText).Message;
                        fileDateTimeInFirstRow = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIndex, 5, TableAction.GetText).Message;
                        break;
                    }*/

                    //Delete the document with status other than "Waiting".
                    if (tmpStatus == "Converting" || tmpStatus == "Locked" || tmpStatus == "Attached")
                    {
                        FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIndex, 3, TableAction.Click);
                        FastDriver.WorkQueueMessagesBrowser.DeleteMessage.FAClick();
                        FastDriver.WebDriver.HandleDialogMessage();
                        FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                    }
                    if (tmpStatus == "Waiting" && priority == string.Empty)
                    {
                        rowIndex = 2;
                        fileNameInFirstRow = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIndex, 3, TableAction.GetText).Message;
                        fileDateTimeInFirstRow = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIndex, 5, TableAction.GetText).Message;
                        break;
                    }
                    rowIndex++;
                }


                for (int i = rowIndex; i < FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount() - 1; i++)
                {
                    fileToMoveToTop = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(i, 3, TableAction.GetText).Message;
                    fileDateTimeForMoveToTop = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(i, 5, TableAction.GetText).Message;
                    //var b = DateTime.Parse(fileDateTimeForMoveToTop.Replace("AM", string.Empty).Replace("PM", string.Empty).Trim()).ToString("MM/dd/yyyy HH:mm:ss");
                    //var c = fileDateTimeInFirstRow.Replace("AM", string.Empty).Replace("PM", string.Empty).Trim();
                    var formatted_FileDateTimeForMoveToTop = DateTime.Parse(fileDateTimeForMoveToTop.Trim()).ToString("MM/dd/yyyy HH:mm:ss"); //24 hour datetime format
                    var formatted_FileDateTimeInFirstRow = DateTime.Parse(fileDateTimeInFirstRow.Trim()).ToString("MM/dd/yyyy HH:mm:ss");
                    if (fileNameInFirstRow != fileToMoveToTop && DateTime.Parse(formatted_FileDateTimeForMoveToTop) != DateTime.Parse(formatted_FileDateTimeInFirstRow))
                    {
                        IsFileAvailableForMoving = true;
                        break;
                    }
                }

                if (IsFileAvailableForMoving)
                {
                    FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(5, fileDateTimeForMoveToTop, 5, TableAction.Click);
                    FastDriver.WorkQueueMessagesBrowser.MoveToTop.FAClick();
                    FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                    var currentRowIndex = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(5, fileDateTimeForMoveToTop, 8, TableAction.Click).CurrentRow + 1;
                    var messagePriority = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(5, fileDateTimeForMoveToTop, 8, TableAction.GetText).Message;
                    Reports.StatusUpdate("Validate that the Priority of the file is updated to 'Critical'.", messagePriority == "Critical", "", "", "", "Critical", messagePriority);
                    //Reports.StatusUpdate("Validate the position/row index of the moved file in the Message Table.", currentRowIndex == 2, "", "", "", "2", currentRowIndex.ToString());
                    //fileNameInFirstRow = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIndex, 3, TableAction.GetText).Message;
                    //fileDateTimeInFirstRow = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rowIndex, 5, TableAction.GetText).Message;
                    //Support.AreEqual(fileToMoveToTop, fileNameInFirstRow);
                    //Support.AreEqual(fileDateTimeForMoveToTop, fileDateTimeInFirstRow);
                }
                else
                {
                    Reports.StatusUpdate("None of the file met criteria for moving to top !", false);
                }
                /********************************************************************************************************/

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void DPUC0016_REG0006()
        {
            try
            {
                Reports.TestDescription = "DP10146_DP10147_DP10143_DP10149_DP10144_004: 1.Move to Top 2.Move to a different Queue 3.Unlock Message 4.Set Priority.";
                Reports.StatusUpdate("This flow is already covered in REG0004()", true);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod, DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void DPUC0016_REG0007()
        {
            try
            {
                Reports.TestDescription = "DP10148_DP10142_005: 1.Message Details 2.Delete Message 3.Message History.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                /*****************Pre-requisite******************* */
                Reports.TestStep = "Navigate to WorkQ.";
                FastDriver.TopFrame.ClickWorkQTab();
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Select Manual Upload in Queue.";
                SelectQueueOnWorkQueue("TestQueue");

                Reports.TestStep = "Upload a file-1.";
                if (!UploadFileOnWorkQ(@"\EMAIL_Offshore_Pdf.pdf"))
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }

                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                SelectQueueOnQList("TestQueue");
                if (FastDriver.WorkQueueMessagesBrowser.DeletedOnly.IsSelected())
                {
                    FastDriver.WorkQueueMessagesBrowser.DeletedOnly.FAClick();
                    FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                }
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(7, "Waiting", 7, TableAction.Click);
                FastDriver.WorkQueueMessagesBrowser.MessageDetails.FAClick();
                FastDriver.WorkQueueMessageDetailsDlg.WaitForScreenToLoad();

                Support.AreEqual("Waiting", FastDriver.WorkQueueMessageDetailsDlg.Status.FAGetText());
                FastDriver.WorkQueueMessageDetailsDlg.Comments.FASetText("View Details");
                Support.AreEqual("TestQueue", FastDriver.WorkQueueMessageDetailsDlg.Queue.FAGetText());
                Support.AreEqual("1", FastDriver.WorkQueueMessageDetailsDlg.FolderName.FAGetText());
                FastDriver.WorkQueueMessageDetailsDlg.Done.FAClick();

                Reports.TestStep = "Select a Doc and set priority.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(7, "Waiting", 7, TableAction.Click);
                var defaultPriority = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(7, "Waiting", 7, TableAction.GetText).Message;
                Reports.StatusUpdate("Default Priority of the message on QList :" + defaultPriority, true);
                FastDriver.WorkQueueMessagesBrowser.SetPriority.FAClick();

                Reports.TestStep = "Set Priority to a Doc.";
                FastDriver.WorkQueueMessagesBrowserDlg.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowserDlg.SecondDoc.FASelectItem("High");
                FastDriver.WorkQueueMessagesBrowserDlg.Done.FAClick();

                Reports.TestStep = "Select a Doc and view Message History.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(7, "Waiting", 7, TableAction.Click);
                FastDriver.WorkQueueMessagesBrowser.MessageHistory.FAClick();

                Reports.TestStep = "Verify Message History.";
                FastDriver.WorkQueueMessageLogDlg.WaitForScreenToLoad();

                FastDriver.WorkQueueMessageLogDlg.MsgQueueTable.PerformTableAction("Status", "Staging", "Status", TableAction.Click);
                FastDriver.WorkQueueMessageLogDlg.Done.FAClick();

                Reports.TestStep = "Select a Doc and delete it.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                int currentRow = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, "1", 7, TableAction.Click).CurrentRow + 1;
                var msgForDeletion = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(currentRow, 3, TableAction.GetText).Message;
                var dateTimeOfTheMsg = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(currentRow, 5, TableAction.GetText).Message;
                var totalRowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();

                FastDriver.WorkQueueMessagesBrowser.DeleteMessage.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Reports.TestStep = "Validate deletion.";
                string msgName = "";
                string dateTime = "";
                bool IsDeletedMsgFound = false;
                for (int i = 1; i < FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount(); i++)
                {

                    msgName = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(i, 3, TableAction.GetText).Message;
                    dateTime = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(i, 5, TableAction.GetText).Message;

                    if (msgName == msgForDeletion && dateTime == dateTimeOfTheMsg)
                    {
                        Reports.StatusUpdate("DEFECT : Deleted message is still found !\r\n Deleted Message = " + msgForDeletion + " \r\n Date And Time :" + dateTimeOfTheMsg, false);
                        IsDeletedMsgFound = true;
                    }
                }
                if (!IsDeletedMsgFound)
                {
                    Reports.StatusUpdate("Successfully deleted the message :'" + msgForDeletion + "'!", true);
                }
                Reports.StatusUpdate("Is total number of message count reduced by one ?", (totalRowCount - 1) == FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount());
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod, DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void DPUC0016_REG0009()
        {
            try
            {

                Reports.TestDescription = "EWC_1_2_001: 1.No more messages available in the Queue to process 2.You have not attached the current document to a file. What would you like to do with this document?” Retain in Queue or Delete.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Open the QList screen.";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                //As a part of the pre-requisite for testing a part of this scenario, 'QASWFE6' is the optimal Queue input selection. Previously TestQueue was chosen, which was not optimal.
                SelectQueueOnQList("QASWFE6");
                if (FastDriver.WorkQueueMessagesBrowser.MessageTable.IsVisible())
                {
                    var rowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                    while (rowCount >= 2)
                    {
                        Reports.TestStep = "Select the doc in the first row and delete it.";
                        FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.Click);
                        var msgStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.GetText).Message;
                        if (msgStatus == "Locked")
                        {
                            FastDriver.WorkQueueMessagesBrowser.MessageUnlock.FAClick();
                            FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                            FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.Click);
                        }
                        FastDriver.WorkQueueMessagesBrowser.DeleteMessage.FAClick();

                        FastDriver.WebDriver.HandleDialogMessage();
                        FastDriver.WebDriver.HandleDialogMessage();
                        FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                        rowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                    }
                }

                /*Reports.TestStep = "Navigate to WorkQ.";
                FastDriver.TopFrame.ClickWorkQTab();
                HandlePostQueueSelectionBehavior();
                Support.CloseAllProcessStartingWith("AcroRd");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueTop.WaitForScreenToLoad();*/

                //FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                //SelectQueueOnQList("TestQueue");
                Reports.TestStep = "Navigate to WorkQ page and check that the expected pop-up appears.";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.WorkQ.FAClick();
                //FastDriver.TopFrame.ClickWorkQTab();
                //FastDriver.WorkQueueTop.WaitForScreenToLoad();

                //Reports.TestStep = "Select a different Queue on WorkQ page before selecting the intended one.";
                //SelectQueueOnWorkQueue("FaxQueue");

                //Reports.TestStep = "Select 'QASWFE6' on WorkQ page to validate that the expected pop-up appears.";
                //FastDriver.WorkQueueTop.SelectQueue.FASelectItem("QASWFE6");
                var alertText = FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                if (alertText == "No more messages available in the Queue to process" && FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem() == "QASWFE6" && int.Parse(FastDriver.WorkQueueTop.Msgs.FAGetText()) == 0)
                {
                    Support.AreEqual("No more messages available in the Queue to process", alertText);
                }
                else
                {
                    Reports.StatusUpdate("The expected pop-up with the message 'No more messages available in the Queue to process' did not appear", false);
                }


                Reports.TestStep = "Upload a file-1 just to ensure to encounter the required pop-up.";
                if (!UploadFileOnWorkQ(@"\EMAIL_Offshore_Pdf.pdf"))
                {
                    Reports.StatusUpdate("File upload is unsuccessful !", false);
                }

                SelectQueueOnWorkQueue("QASWFE6");
                SelectQueueOnWorkQueue("TestQueue");

                FastDriver.WorkQueueTop.SelectQueue.FASelectItem("QASWFE6");
                Reports.TestStep = "Verify that 'Retain In Queue/Delete' Dlg appears.";
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.CheckIfTheAlertMessageIsAsIntended();
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }


                /*bool alertTriggered = false;
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                var totalQueueCount = FastDriver.WorkQueueTop.SelectQueue.FAGetDropdownOptions().Count;
                int idx = 1;
                while (!alertTriggered && idx <= totalQueueCount)
                {
                    FastDriver.WorkQueueTop.Next.FAClick();
                    if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                    {
                        FastDriver.RetaininQDeleteDlg.CheckIfTheAlertMessageIsAsIntended();
                        FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                        alertTriggered = true;
                    }
                    HandlePostQueueSelectionBehavior();
                    idx++;
                }*/
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void DP7206_DPREG0010_PH()
        {
            Reports.TestDescription = "7207_DP10238_DP9191_DP11881: These cannot be scripted 1.Work Queue Layout User View 2.FAST Usability within Work Queue 3.Display Email Icon 4.Work Queue Layout Supervisor View 5.Required Activity Right.";
            Assert.Inconclusive("This Flow has NOT been Automated ! Please perform this MANUALLY !");
        }


        [TestMethod]
        public void DPUC0016_DPREG0011_PH()
        {
            Reports.TestDescription = "DP10239 : This cannot be scripted:Upload Message.";
            Assert.Inconclusive("This Flow has NOT been Automated ! Please perform this MANUALLY !");
        }




        #region Private Methods

        private void LoginToIIS()
        {
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            catch (Exception)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }


        private void LoginToADM()
        {
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            }
            catch (Exception)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }


        private bool CloseFileViewerDialog()
        {
            Reports.StatusUpdate("Closing the File Viewer Dialog !", true);
            Support.CloseAllProcessStartingWith("AcroRd");
            bool ClosedTheDialog = false;
            try
            {
                BrowserWindow PDFViewer = GetBrowserWindow();
                if (PDFViewer == null)
                {
                    if (!BringFrontMainWindow())
                    {
                        Reports.StatusUpdate("Could not bring forth the main browser window !", true);
                        return false;
                    }
                    else
                    {
                        Reports.StatusUpdate("Brought the main browser window to the front !", true);
                        return true;
                    }
                }

                if (PDFViewer != null)
                {
                    WinTitleBar titleBar = new WinTitleBar(PDFViewer);
                    titleBar.SearchProperties.Add("ClassName", "IEFrame", PropertyExpressionOperator.Contains);
                    //titleBar.SearchProperties.Add("ClassName", "WindowsForms10.Window", PropertyExpressionOperator.Contains); 
                    WinButton closeBtn = new WinButton(titleBar);
                    closeBtn.SearchProperties["Name"] = "Close";
                    closeBtn.DrawHighlight();
                    Mouse.Click(closeBtn);
                    Reports.StatusUpdate("Closed the File Viewer Dialog !", true);
                    ClosedTheDialog = true;
                }
                else
                {
                    ClosedTheDialog = false;
                }
                return ClosedTheDialog;
            }
            catch (Exception e)
            {
                Support.CloseAllProcessStartingWith("AcroRd");
                Reports.StatusUpdate("Did not close the File Viewer Dialog ! Message :" + e.Message, true);
                return false;
            }
        }

        private BrowserWindow GetBrowserWindow()
        {
            BrowserWindow PDFViewer = new BrowserWindow();
            try
            {
                PDFViewer.SearchProperties.Add("ClassName", "IEFrame", PropertyExpressionOperator.Contains);
                PDFViewer.SearchProperties.Add("Name", "Work Queue Message Viewer", PropertyExpressionOperator.Contains);
                if (PDFViewer.Exists)
                {
                    return PDFViewer;
                }
                else
                {
                    Reports.StatusUpdate("File Viewer Dialog with 'Work Queue Message Viewer' title was not located. Trying to locate '404.0 - Not Found' dialog !", true);
                    PDFViewer.SearchProperties.Add("ClassName", "IEFrame", PropertyExpressionOperator.Contains);
                    PDFViewer.SearchProperties.Add("Name", "404.0 - Not Found", PropertyExpressionOperator.Contains);

                    if (PDFViewer.Exists)
                    {
                        return PDFViewer;
                    }
                }
            }
            catch (Exception e)
            {
                Reports.StatusUpdate("Exception in GetBrowserWindow() :" + e.Message, true);
            }
            return PDFViewer;
        }

        private bool BringFrontMainWindow()
        {
            Reports.StatusUpdate("Trying to bring forth the main window !", true);
            Support.CloseAllProcessStartingWith("AcroRd");
            try
            {
                BrowserWindow FASTMainWindow = new BrowserWindow();
                FASTMainWindow.SearchProperties.Add("ClassName", "IEFrame", PropertyExpressionOperator.Contains);
                FASTMainWindow.SearchProperties.Add("Name", "- " + Support.FASTWindowName, PropertyExpressionOperator.Contains);

                if (FASTMainWindow.Exists)
                {
                    HtmlEdit fileMRU = new HtmlEdit(FASTMainWindow);
                    fileMRU.SearchProperties["Id"] = "SelFileEdit";
                    fileMRU.SearchProperties[HtmlEdit.PropertyNames.TagName] = "INPUT";
                    Mouse.DoubleClick(fileMRU);
                    Reports.StatusUpdate("Located the main browser window !", true);
                    return true;
                }
                else
                {
                    Reports.StatusUpdate("Could not locate main browser window !", true);
                    return false;
                }
            }
            catch (Exception e)
            {
                Support.CloseAllProcessStartingWith("AcroRd");
                Reports.StatusUpdate("ould not locate main browser window ! Message :" + e.Message, true);
                return false;
            }
        }

        private void HandlePostQueueSelectionBehavior()
        {
            Support.CloseAllProcessStartingWith("AcroRd");
            FastDriver.WebDriver.HandleDialogMessage();
            if (CodedUIInteractions.HandleFileDownloadPrompt_WithPauseAndResume())
            {
                Reports.StatusUpdate("PDF attachment opened and closed !", true);
            }
            else
            {
                Reports.StatusUpdate("File download prompt not handled !", true);
            }
            if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
            {
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
            }
            //FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
            Support.CloseAllProcessStartingWith("AcroRd");
            FastDriver.WebDriver.HandleDialogMessage();
        }



        private bool RemoveFilesOnQList(int filesToBeRetained = 10)
        {
            try
            {
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                //As a part of the pre-requisite for testing a part of this scenario, 'QASWFE6' is the optimal Queue input selection. Previously TestQueue was chosen, which was not optimal.
                SelectQueueOnQList("TestQueue");
                if (FastDriver.WorkQueueMessagesBrowser.MessageTable.IsVisible())
                {
                    var rowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                    while (rowCount > filesToBeRetained+1)
                    {
                        Reports.TestStep = "Select the doc in the first row and delete it.";
                        FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.Click);
                        var msgStatus = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.GetText).Message;
                        if (msgStatus == "Locked")
                        {
                            FastDriver.WorkQueueMessagesBrowser.MessageUnlock.FAClick();
                            FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                            FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(1, "1", 7, TableAction.Click);
                        }
                        FastDriver.WorkQueueMessagesBrowser.DeleteMessage.FAClick();

                        FastDriver.WebDriver.HandleDialogMessage();
                        FastDriver.WebDriver.HandleDialogMessage();
                        FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                        rowCount = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                    }
                    if(rowCount == filesToBeRetained+1)
                    {
                        return true;
                    }
                }
                return false;
            }
            catch(Exception e)
            {
                Reports.StatusUpdate("Exception while removing files on QList ! Message:" + e.Message, true);
                return false;
            }
        }

        private bool UploadFileOnWorkQ(string filename = @"\EMAIL_Offshore_Pdf.pdf")
        {
            try
            {
                FastDriver.WorkQueueTop.Upload.FAClick();
                FastDriver.UploadFileToQueueDlg.WaitForScreenToLoad();

                try
                {
                    Playback.Wait(2000);
                    FastDriver.UploadFileToQueueDlg.imageFilePath.FADoubleClick();
                }
                catch (Exception ex)
                {
                    Reports.StatusUpdate("Exception caught :" + ex.Message, true);
                    FastDriver.UploadFileToQueueDlg.imageFilePath.SendKeys(Reports.DEPLOYDIR + filename);
                }
                //FastDriver.UploadFileToQueueDlg.imageFilePath.SendKeys(Reports.DEPLOYDIR + filename);


                /*  BrowserWindow wnd = new BrowserWindow();
                  wnd.SearchProperties[BrowserWindow.PropertyNames.ClassName] = "IEFrame";

                  UITestControl frm1 = new UITestControl(wnd);
                  frm1.SearchProperties.Add("Id","FAFDialog_0_iframe");
                  frm1.SearchProperties[UITestControl.PropertyNames.ClassName] = "HtmlFrame";
                  frm1.DrawHighlight();

                  UITestControl frm2 = new UITestControl(frm1);
                  frm2.SearchProperties[UITestControl.PropertyNames.Name] = "fraWorkQTop";
                  frm2.SearchProperties[UITestControl.PropertyNames.ClassName] = "HtmlFrame";
                  frm2.DrawHighlight();

                  HtmlControl doc = new HtmlControl(frm2);
                  doc.SearchProperties[HtmlControl.PropertyNames.Title] = "UploadFileToQueue";

                  HtmlControl browseFileInput = new HtmlControl(doc);
                  browseFileInput.SearchProperties[UITestControl.PropertyNames.Name] = "imageFile";
                  browseFileInput.SearchProperties[UITestControl.PropertyNames.ClassName] = "HtmlFileInput";
                  browseFileInput.DrawHighlight();
                  Mouse.Click(browseFileInput);
                  Playback.Wait(1000);

                
                  UITestControl fileOpenWindow = new UITestControl();
                  fileOpenWindow.SearchProperties[UITestControl.PropertyNames.ClassName] = "#32770";
                  fileOpenWindow.SearchProperties[UITestControl.PropertyNames.ClassName] = "Choose File to Upload";
                  fileOpenWindow.DrawHighlight();

                  UITestControl fileNameEdit = new UITestControl(fileOpenWindow);
                  fileNameEdit.SearchProperties[UITestControl.PropertyNames.ClassName]  = "Edit";
                  fileNameEdit.SearchProperties[UITestControl.PropertyNames.Name] = "File name:";
                  fileNameEdit.DrawHighlight();

                  UITestControl openButton = new UITestControl(fileOpenWindow);
                  openButton.SearchProperties[UITestControl.PropertyNames.ClassName] = "Button";
                  openButton.SearchProperties[UITestControl.PropertyNames.Name] = "Open";

                  fileNameEdit.SetProperty(Microsoft.VisualStudio.TestTools.UITesting.WinControls.WinEdit.PropertyNames.Text, Reports.DEPLOYDIR + filename);
                  openButton.DrawHighlight();
                  Mouse.Click(openButton);*/

                int j = 0;
                bool IsFileOpenDialogOpened = false;
                //MessageBox.Show(Reports.DEPLOYDIR + filename);
                Playback.Wait(3000);

                while (true)
                {
                    while (j <= 5)
                    {
                        if (AutoIt.AutoItX.WinExists(title: "Choose File to Upload", text: "") == 1)
                        {
                            Reports.StatusUpdate("Calling AutoItX APIs to perform the file upload operation...!", true);
                            AutoIt.AutoItX.WinActivate("Choose File to Upload", "");
                            AutoIt.AutoItX.ControlSetText("Choose File to Upload", "", "[CLASS:Edit;INSTANCE:1]", Reports.DEPLOYDIR + filename);
                            AutoIt.AutoItX.ControlClick("Choose File to Upload", "", "[CLASS:Button;TEXT:&Open]");
                            AutoIt.AutoItX.WinWaitClose("Choose File to Upload", "", 10);
                            Reports.StatusUpdate("Finished performing the file upload operation through AutoItX...!", true);
                            IsFileOpenDialogOpened = true;
                            break;
                        }
                        else
                        {
                            j = j + 5;
                            Playback.Wait(5000);
                        }
                    }
                    j = 0;
                    while (j <= 5)
                    {
                        if (AutoIt.AutoItX.WinExists(title: "Upload File to Queue", text: "") == 1)
                        {
                            Reports.StatusUpdate("Calling AutoItX APIs to perform the file upload operation...!", true);
                            AutoIt.AutoItX.WinActivate("Upload File to Queue", "");
                            AutoIt.AutoItX.ControlSetText("Upload File to Queue", "", "[CLASS:Edit;INSTANCE:1]", filename);
                            AutoIt.AutoItX.ControlClick("Upload File to Queue", "", "[CLASS:Button;TEXT:&Open]");
                            AutoIt.AutoItX.WinWaitClose("Upload File to Queue", "", 10);
                            Reports.StatusUpdate("Finished performing the file upload operation through AutoItX...!", true);
                            IsFileOpenDialogOpened = true;
                            break;
                        }
                        else
                        {
                            j = j + 5;
                            Playback.Wait(5000);
                        }
                    }
                    if (!IsFileOpenDialogOpened)
                    {
                        j = 0;
                        FastDriver.UploadFileToQueueDlg.imageFilePath.FADoubleClick();
                        Playback.Wait(2000);
                    }
                    else
                    {
                        break;
                    }
                }

                Reports.StatusUpdate("Clicking Upload button !", true);
                FastDriver.UploadFileToQueueDlg.Upload.FAClick();

                //Wait till the UploadDocumentDlg disappears.
                int k = 1;
                if (FastDriver.UploadDocumentDlg.Upload.IsVisible())
                {
                    while (k <= 25)
                    {
                        Playback.Wait(1000);
                        k = k + 1;
                        if (!FastDriver.UploadDocumentDlg.Upload.IsVisible())
                        {
                            break;
                        }
                    }
                }

                Reports.StatusUpdate("Clicked Upload button !", true);

                //If UploadDocumentDlg is still visible, there could be some app issue. Hence, click Cancel to proceed further.
                if (FastDriver.UploadFileToQueueDlg.Cancel.IsVisible())
                {
                    FastDriver.UploadFileToQueueDlg.Cancel.FAClick();
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                return true;
            }
            catch (Exception e)
            {
                Reports.StatusUpdate("Exception occurred in UploadFileOnWorkQ routine ! Details :" + e.Message, false);
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                return false;
            }
        }

        private bool GetMessageCountAndPublishOnWorkQ(out int UnpdCount, out int msgsCount)
        {
            try
            {
                UnpdCount = int.Parse(FastDriver.WorkQueueTop.UnpdCount.FAGetText());

                msgsCount = int.Parse(FastDriver.WorkQueueTop.Msgs.FAGetText());
                Reports.StatusUpdate("Got Unpd count", true, actualValue: UnpdCount.ToString());
                //Reports.StatusUpdate("Got Skip count", true, actualValue: UnpdCount.ToString());
                Reports.StatusUpdate("Got Messages count", true, actualValue: msgsCount.ToString());
                return true;
            }
            catch
            {
                UnpdCount = -1;
                msgsCount = -1;
                return false;
            }
        }



        private bool SelectRegion(string BUID)
        {
            try
            {
                Reports.TestStep = "Select QA Automation Region - DO NOT TOUCH region without selecting office.";
                try
                {
                    FastDriver.SecuritySelectRegionOffice.Open();
                    FastDriver.SecuritySelectRegionOffice.EnterBUID(BUID);
                    return true;
                }
                catch
                {
                    FastDriver.SecuritySelectRegionOffice.Open();
                    FastDriver.SecuritySelectRegionOffice.EnterBUID(BUID);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }


        private bool ValidateMessageCountOnWorkQ(int UnpdCount, int msgsCount, int increment = 1)
        {
            try
            {
                var UnpdCount2 = int.Parse(FastDriver.WorkQueueTop.UnpdCount.FAGetText());
                var MsgsCount2 = int.Parse(FastDriver.WorkQueueTop.Msgs.FAGetText());
                Support.AreEqual((UnpdCount + increment).ToString(), UnpdCount2.ToString());
                Support.AreEqual((msgsCount + increment).ToString(), MsgsCount2.ToString());
                return true;
            }
            catch
            {
                return false;
            }
        }


        private bool SelectQueueOnWorkQueue(string workQueue = "TestQueue")
        {
            try
            {
                Reports.TestStep = "Select the specified Queue on WorkQ.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@workQueue);
                Reports.TestStep = "Handle the PDF Download Toolbar and the PDF Window, if necessary.";
                HandlePostQueueSelectionBehavior();
                Reports.TestStep = "Handle 'Retain In Queue/Delete' Dlg, if appeared.";
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                Reports.TestStep = "Handle any pop-ups, if appeared.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage();
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                return true;
            }
            catch
            {
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                return false;
            }
        }

        private bool SelectQueueOnQList(string workQueue = "TestQueue")
        {
            try
            {
                Reports.TestStep = "Select the specified Queue on QList.";
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem(@workQueue);
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                return true;
            }
            catch
            {
                return false;
            }
        }


        private bool IsWorkQMsgCountMatchingWithQlistFileCount(int msgsCnt)
        {
            try
            {
                var fileCountOnQList = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                int nonAttachedCnt = 0;
                for (int i = 2; i <= fileCountOnQList; i++)
                {
                    var status = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(i, 7, TableAction.GetText).Message;
                    if (status != "Attached")
                    {
                        nonAttachedCnt++;
                    }
                }
                if (msgsCnt == nonAttachedCnt)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }

        }


        private string CreateFile(bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            string buyerRandomVal = Support.RandomString("AAAAAZ");
            string[] State = { "CR", "AR" };
            Reports.TestStep = "Generate a random buyer name.";
            Support.DataSave("RandomBuyerName", buyerRandomVal);

            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();

                if (OnDemandRequest)
                {

                    fileRequest.File.AutoNumberIndicator = IsAutoNumber;
                    fileRequest.File.FileNumber = "AU" + Support.RandomString("NNNNNN");

                    /*fileRequest.File = new File()
                    {
                        AutoNumberIndicator = IsAutoNumber,
                        FileNumber = "AU" + Support.RandomString("NNNNNN")
                    };*/

                    if (!string.IsNullOrEmpty(GABCode))
                    {
                        fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
                        fileRequest.File.BusinessParties[0].RoleTypeObjectCD = "BUSSOURCE";
                        fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.OtherRealEstateAgent;

                        /* fileRequest.File = new File()
                         {
                             //AutoNumberIndicator = IsAutoNumber,
                             BusinessParties = new FileBusinessParty[] 
                        {
                             new FileBusinessParty()
                             {
                                 AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode),
                                 RoleTypeObjectCD = "BUSSOURCE",
                                 AdditionalRole = new AdditionalRoleList()
                                 {
                                     eAddtionalRole = AdditionalRoleType.OtherRealEstateAgent
                                 }
                             }
                        }
                         };*/
                    }

                    fileRequest.File.Buyers[0].FirstName = buyerRandomVal;

                    /*fileRequest.File.Buyers =
                    new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            //Type = "Individual",
                            //SSN = "123-45-6789",
                            FirstName = buyerRandomVal,
                           // LastName = "Buyer1Lastname",
                        },                        
                    };*/

                    /*fileRequest.File.Properties[0].PropertyAddress[0].State = "AL";
                    fileRequest.File.Properties[0].PropertyAddress[0].County = "AUTAUGA";
                    //fileRequest.File.Properties[0].PropertyAddress[0].City = "PHOENIX";*/

                    fileRequest.File.Properties[0].PropertyAddress[0].State = "AR";
                    fileRequest.File.Properties[0].PropertyAddress[0].County = "LAWRENCE";
                    //fileRequest.File.Properties[0].PropertyAddress[0].City = "PHOENIX";
                    fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                    /*fileRequest.File.Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "AR", 
//                                    City = "ALBANY", 
  //                                  County = "ALAMEDA", 
    //                                Country = "USA" 
                                } 
                            } 
                        } 
                    };*/
                }

                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch //If not able to create file via web service, create file via FAST GUI
            {

            }
            if (string.IsNullOrEmpty(fileNumber))
            {
                throw new Exception("File creation is unsuccessful ! Aborting the test !");
            }
            return fileNumber;
        }
        #endregion










        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
