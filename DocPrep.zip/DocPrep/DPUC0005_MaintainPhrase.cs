﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;
using System.Linq;
using System.Windows.Input;


namespace DocPrep
{
    [CodedUITest]
    public class DPUC0005 : FASTHelpers
    {
        #region BAT
        [TestMethod]
        public void DPUC0005_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1A_AF1_FD_PGPS_FD_PGM_FD_PM: To add new phrase group.";

                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroupName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Escrow Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                phraseGroupName = Support.RandomString("AAA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseGroupName);
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Validate the revision history.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());
                Support.AreEqual("Created: Add phrase to Phrasegroup", FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean());


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF2_AF3_DP2146_DP3855_DP2148_DP2149_DP2150_DP2153_FD_PGPS_FD_PGM: To search for a Phrase Group.";
                ////
                //Reports.TestStep = "Login To FAST";
                //this.Login(true);

                ////
                //Reports.TestStep = "Search for a phrasegroup"; 
                //FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                //FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                ////
                //Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                //FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                ////
                //Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                //string phraseGroupName = Support.RandomString("AAA");
                //FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroupName);
                //FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase");
                //FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                //FastDriver.PhraseGroupMaintenance.Comments.FASetText("Created for Axe BAT script");
                //FastDriver.BottomFrame.Save();
                //Playback.Wait(3000);
                //Playback.Wait(2000);
                //FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroupName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Escrow Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Validate the revision history.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());
                Support.AreEqual("Created: Add phrase to Phrasegroup", FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean());

                //breakpoint

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                // 
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                // 
                Reports.TestStep = "Edit Phrase Group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Title Phrase");
                FastDriver.PhraseGroupMaintenance.FontNameTYPE.FASelectItem("Times New Roman");
                FastDriver.PhraseGroupMaintenance.FontSize.FASelectItem("12");
                FastDriver.PhraseGroupMaintenance.MarginTop.FASetText("0.25");
                FastDriver.PhraseGroupMaintenance.MarginLeft.FASetText("0.75");
                FastDriver.PhraseGroupMaintenance.MarginRight.FASetText("0.85");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the phrase group after Edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                Support.AreEqual("Title Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("Times New Roman", FastDriver.PhraseGroupMaintenance.FontNameTYPE.FAGetSelectedItem().Clean());
                Support.AreEqual("12", FastDriver.PhraseGroupMaintenance.FontSize.FAGetSelectedItem().Clean());
                Support.AreEqual("0.25", FastDriver.PhraseGroupMaintenance.MarginTop.FAGetValue().Clean());
                Support.AreEqual("0.75", FastDriver.PhraseGroupMaintenance.MarginLeft.FAGetValue().Clean());
                Support.AreEqual("0.85", FastDriver.PhraseGroupMaintenance.MarginRight.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                // 
                Reports.TestStep = "To verify that Phrase Group Maitenance Summary screen is loaded";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF5_AF6_FD_PGM: Deactivate a Phrase Group.";
                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroupName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Escrow Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Validate the revision history.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());
                Support.AreEqual("Created: Add phrase to Phrasegroup", FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean());

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");
                // 
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(4500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();

                // 
                Reports.TestStep = "To change the status of the phrase to Inactive.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Inactive.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "To verify that phrase and phrase group status changed to inactive.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PhraseGroupMaintenance.Inactive.Enabled.ToString());
                Support.AreEqual("Inactive", FastDriver.PhraseGroupMaintenance.PhraseStatus.FAGetText().ToString());

                // 
                Reports.TestStep = "To verify that Copy button is disabled for inactive phrase.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                Support.AreEqual("False", FastDriver.PhraseGroupMaintenance.Copy.Enabled.ToString());

                // 
                Reports.TestStep = "To change the status of the phrase to Active.";
                FastDriver.PhraseGroupMaintenance.Active.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                // 
                Reports.TestStep = "To verify that phrase and phrase group status changed to Active.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PhraseGroupMaintenance.Active.Enabled.ToString());
                Support.AreEqual("Inactive", FastDriver.PhraseGroupMaintenance.PhraseStatus.FAGetText().ToString());

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF7_FD_PGM: To edit Phrase via Phrase Maintenance.";
                //
                this.Login(true);
                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroupName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Escrow Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Validate the revision history.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());
                Support.AreEqual("Created: Add phrase to Phrasegroup", FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean());

                //breakpoint

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                // 
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                // 
                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Edit.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();

                // 
                Reports.TestStep = "Edit the phrase.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase-Edit");
                FastDriver.PhraseMaintenance.Formatting_Name.FASelectItem("Verdana");
                FastDriver.PhraseMaintenance.Formatting_Size.FASelectItem("12");
                FastDriver.PhraseMaintenance.Formatting_MarginTop.FASetText("0.8");
                FastDriver.PhraseMaintenance.Formatting_MarginLeft.FASetText("2.2");
                FastDriver.PhraseMaintenance.Formatting_MarginRight.FASetText("0.9");
                if (!FastDriver.PhraseMaintenance.Status_Active.Selected)
                    FastDriver.PhraseMaintenance.Status_Active.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                // 
                Reports.TestStep = "To verify the phrase group after Edit.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("Axe BAT script phrase-Edit", FastDriver.PhraseMaintenance.Description.FAGetValue().Clean());
                Support.AreEqual("Verdana", FastDriver.PhraseMaintenance.Formatting_Name.FAGetSelectedItem().Clean());
                Support.AreEqual("12", FastDriver.PhraseMaintenance.Formatting_Size.FAGetSelectedItem().Clean());
                Support.AreEqual("0.8", FastDriver.PhraseMaintenance.Formatting_MarginTop.FAGetValue().Clean());
                Support.AreEqual("2.2", FastDriver.PhraseMaintenance.Formatting_MarginLeft.FAGetValue().Clean());
                Support.AreEqual("0.9", FastDriver.PhraseMaintenance.Formatting_MarginRight.FAGetValue().Clean());
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF8_FD_PM: Edit Phrase via Navigation Tree.";
                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Escrow Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Escrow Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Search for a phrase.";
                FastDriver.LeftNavigation.Navigate<EditPhrase>("Home>System Maintenance>Document Preparation>Edit Phrase").WaitForScreenToLoad();
                FastDriver.EditPhrase.PhraseGroupCode.FASetText(phraseGroupName + @"/" + phraseName);
                FastDriver.EditPhrase.PhraseProperties.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Edit the phrase.";
                this.EnterPhraseMaintenanceData(description: "Axe BAT script phrase-Editphrase", formatting_Name: "Times New Roman", formatting_Size: "14", formatting_MarginTop: "1.15", formatting_MarginLeft: "3.2", formatting_MarginRight: "4.5");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                Reports.TestStep = "To verify the phrase group after Edit.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("Axe BAT script phrase-Editphrase", FastDriver.PhraseMaintenance.Description.FAGetValue().Clean());
                Support.AreEqual("Times New Roman", FastDriver.PhraseMaintenance.Formatting_Name.FAGetSelectedItem().Clean());
                Support.AreEqual("14", FastDriver.PhraseMaintenance.Formatting_Size.FAGetSelectedItem().Clean());
                Support.AreEqual("1.15", FastDriver.PhraseMaintenance.Formatting_MarginTop.FAGetValue().Clean());
                Support.AreEqual("3.2", FastDriver.PhraseMaintenance.Formatting_MarginLeft.FAGetValue().Clean());
                Support.AreEqual("4.5", FastDriver.PhraseMaintenance.Formatting_MarginRight.FAGetValue().Clean());
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());
                string revisedDate = Convert.ToDateTime(FastDriver.PhraseMaintenance.RevisedDate1.FAGetText()).Date.ToString("MM/dd/yyyy");
                string fixedDate = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/dd/yyyy");
                Support.AreEqual("True", revisedDate.Contains(fixedDate).ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF9_AF10_FD_PM: Deactivate a Phrase.";
                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroupName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Escrow Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                // 
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Edit.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //Playback.Wait(100000000);
                //
                Reports.TestStep = "To change the status of the phrase to Inactive.";
                if (FastDriver.PhraseMaintenance.UnderConstruction.Selected)
                    FastDriver.PhraseMaintenance.UnderConstruction.FAClick();
                if (!FastDriver.PhraseMaintenance.Status_Inactive.Selected)
                    FastDriver.PhraseMaintenance.Status_Inactive.FAClick();
                Playback.Wait(500);
                FastDriver.PhraseMaintenance.Status_StatusChangeComments.FASetText("Changed status to inactive");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);


                // 
                Reports.TestStep = "Verify the status of the phrase is changed to inactive.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.PhraseMaintenance.UnderConstruction.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Status_Active.Enabled.ToString());
                //Support.AreEqual("Inactive", FastDriver.PhraseMaintenance.Revisedby.FAGetAttribute("title").ToString());
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());
                string revisedDate = FastDriver.PhraseMaintenance.RevisedDate1.FAGetText();
                Support.AreEqual(@"fastts\FASTQA07", FastDriver.PhraseMaintenance.Revisedby.FAGetText().Clean());
                string fixedDate = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/%d/yyyy");
                Support.AreEqual("True", fixedDate.Contains(revisedDate).ToString(), "Comparing revised Date= " + revisedDate + " With current fixed date= " + fixedDate);
                FastDriver.BottomFrame.Save();


                //
                Reports.TestStep = "To change the status of the phrase to Active.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.UnderConstruction.FAClick();
                if (!FastDriver.PhraseMaintenance.Status_Active.Selected)
                    FastDriver.PhraseMaintenance.Status_Active.FAClick();
                FastDriver.PhraseMaintenance.Status_StatusChangeComments.FASetText("Changed status to active");

                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Verify the status of the phrase is changed to active.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PhraseMaintenance.UnderConstruction.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Status_Active.Enabled.ToString());
                //Support.AreEqual("Inactive", FastDriver.PhraseMaintenance.Revisedby.FAGetAttribute("title").ToString());
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());
                string revisedDate1 = FastDriver.PhraseMaintenance.RevisedDate1.FAGetText();
                string fixedDate1 = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/%d/yyyy");
                Support.AreEqual("True", fixedDate1.Contains(revisedDate1).ToString(), "Comparing revised Date= " + revisedDate1 + " With current fixed date= " + fixedDate1);
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Statuschangecomments.FAGetText().Contains("Changed status to active").ToString());
                FastDriver.BottomFrame.Save();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF11_FD_PGM: Copy Phrase via Phrase Maintenance.";

                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Title Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Title Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Copy.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Copy.FAClick();
                Playback.Wait(3000);

                string copyName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Copyphrasename.FASetText(copyName);
                FastDriver.PhraseGroupMaintenance.Copyphrasedescription.FASetText("Copied phrase description");
                FastDriver.PhraseGroupMaintenance.Save.FAClick();
                Playback.Wait(4000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                // 
                Reports.TestStep = "To verify that new phrase is created by copy.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Copied phrase description", 2, TableAction.Click);


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF12_EWC010_EWC017_EWC041_EWC042_FD_PC: Copy Phrase via Navigation Tree.";
                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create a new phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Title Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Title Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Copy.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Copy.FAClick();
                Playback.Wait(3000);

                string copyName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Copyphrasename.FASetText(copyName);
                FastDriver.PhraseGroupMaintenance.Copyphrasedescription.FASetText("Copied phrase description");
                FastDriver.PhraseGroupMaintenance.Save.FAClick();
                Playback.Wait(4000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                // 
                Reports.TestStep = "To verify that new phrase is created by copy.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Copied phrase description", 2, TableAction.Click);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2500);

                //breakpoint
                Reports.TestStep = "To navigate to Phrase Copy screen and select the phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseGroup.FASelectItem(phraseGroupName + " - Automation BAT Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...",false);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                if (!FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_Select.FAClick();

                //PhraseGroupName variable is used on both copytoPhrase and copyfromphrases check this.
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.Copy.FAClick();
                Playback.Wait(3000);
                FastDriver.PhraseCopy.CopyStatus_DUP.FAClick();

                // 
                Reports.TestStep = "Duplicate phrase created by phrase copy.";
                Support.AreEqual("FAILED: Phrase to copy is already exists", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To navigate to Phrase Copy screen and select the phrase group.";
                string copyToPhrasesPhraseName = Support.RandomString("AAA");
                // FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText(copyToPhrasesPhraseName);
                FastDriver.PhraseCopy.CopyToPhrases_Description.FASetText("Axe BAT script phrase-Copied");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To verify that new phrase is created by copy.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Copied phrase description", 2, TableAction.Click);
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF13_FD_PC: Copy Phrase to Another Phrase Group via Navigation Tree.";

                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Axe1-Phrase group", phraseType: "Escrow Phrase", comments: "Created for Axe1 BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "To copy the phrases from one phrase group to another phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();
                if (!FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_Select.FAClick();
                FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_Description.FASetText("Axe BAT script phrase-via navigation");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Phrase copied successfully.";
                //to fix No dialog Present
                // Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage().Contains("SUCEEDED").ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                //
                Reports.TestStep = "To click on clear button.";
                FastDriver.PhraseCopy.Clear.FAClick();

                //
                Reports.TestStep = "To validate after Click on Clear button.";
                Support.AreEqual("False", FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected.ToString());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FAGetText());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FAGetText());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyToPhrases_GroupName.FAGetText());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FAGetText());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyToPhrases_Description.FAGetText());

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Axe1*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "Axe1-Phrase group", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the phrase.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Axe1-Phrase groupnotuse");
                FastDriver.BottomFrame.Save();


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0010()
        {
            try
            {
                Reports.TestDescription = "AF14_FD_PC: Copy All Phrases from One Phrase Group to Another via Navigation Tree.";


                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Axe1-Phrase group", phraseType: "Escrow Phrase", comments: "Created for Axe1 BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                #region new addition
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupNameadded2 = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupNameadded2, description: "Axe1-Phrase group", phraseType: "Escrow Phrase", comments: "Created for Axe1 BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseNameadded2 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                #endregion new addition

                //
                Reports.TestStep = "To copy the phrases from one phrase group to another phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();
                if (!FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_Select.FAClick();
                FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_Description.FASetText("Axe BAT script phrase-via navigation");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Phrase copied successfully.";
                //to fix No dialog Present
                // Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage().Contains("SUCEEDED").ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                ////
                //Reports.TestStep = "To click on clear button.";
                //FastDriver.PhraseCopy.Clear.FAClick();

                ////
                //Reports.TestStep = "To validate after Click on Clear button.";
                //Support.AreEqual("False", FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected.ToString());
                //Support.AreEqual("", FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FAGetText());
                //Support.AreEqual("", FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FAGetText());
                //Support.AreEqual("", FastDriver.PhraseCopy.CopyToPhrases_GroupName.FAGetText());
                //Support.AreEqual("", FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FAGetText());
                //Support.AreEqual("", FastDriver.PhraseCopy.CopyToPhrases_Description.FAGetText());

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Axe1*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "Axe1-Phrase group", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the phrase.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Axe1-Phrase groupnotuse");
                FastDriver.BottomFrame.Save();
                Playback.Wait(10000);

                //breakpoint
                //Reports.TestStep = "Login To FAST";
                //this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName2 = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName2, description: "Axe2-Phrase group", phraseType: "Title Phrase", comments: "Created for Axe2 BAT script");
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                string phraseName2 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName2, description: "New created phrase1", comments: "Test Phrase-Automation");
                //FastDriver.Phrase
                FastDriver.BottomFrame.Save();
                Playback.Wait(2300);

                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.New.FAClick();
                //
                //Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                //FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                //FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                //FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create a new phrase .";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                string phraseName3 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName3, description: "New created phrase2", comments: "Test Phrase-Automation");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2300);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                string phraseGroupName3 = Support.RandomString("AAAN");
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName3, description: "TestAxe3-Phrase group", phraseType: "Escrow Phrase", comments: "Test phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "To copy all phrases from one phrase group to another phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();

                FastDriver.PhraseCopy.CopyFromPhrases_PhraseGroup.FASelectItem(phraseGroupName2 + " - Axe2-Phrase group");
                if (!FastDriver.PhraseCopy.CopyFromPhrases_All.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_All.FAClick();

                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName3);
                FastDriver.PhraseCopy.CopyToPhrases_GroupName1.FASetText(phraseGroupName3);
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Phrase copied successfully.";
                //to fix No dialog Present
                // Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage().Contains("SUCEEDED").ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("TestAxe3*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName3, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To verify that new phrase is created by copy.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "New created phrase1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "New created phrase2", 2, TableAction.Click);
                //FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the phrase group.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("TestAxe3-Phrase groupnot");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3500);

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Axe2*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName2, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the phrase.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Axe2-Phrase groupnotuse");
                FastDriver.BottomFrame.Save();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0011()
        {
            try
            {
                Reports.TestDescription = "Revert1: Revert the Phrase Group to initial values.";
                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation", phraseType: "Title Phrase", comments: "Created for Axe1 BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Reverting the Phrase Group to initial values.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase-not use");
                FastDriver.BottomFrame.Save();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_BAT0012()
        {
            try
            {
                Reports.TestDescription = "AF4: Delete Phrase Group.";
                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: "DELP", description: "Delete Test Phrase", phraseType: "Escrow Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Delete*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                //
                Reports.TestStep = "To verify that Phrase Group is deleted";
                Support.AreEqual("1", FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.GetRowCount().ToString());

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "Delete Test Phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Delete.FAClick();
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Delete*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        [Description("EWC01_EWC02_EWC015: User tries to save the new phrase group creation instance when Phrase Group Name is blank")]
        public void DPUC0005_REG0001()
        {
            try
            {
                Reports.TestDescription = "EWC01_EWC02_EWC015: User tries to save the new phrase group creation instance when Phrase Group Name is blank";

                FAST_Login_ADM();

                #region Navigate to Phrase Maintenance screen and click on New button
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Save Phrase Group without Phrase group name
                Reports.TestStep = "Save Phrase Group without Phrase group name";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(description: "Automation test DPUC0005 REG0001", phraseType: "Escrow Phrase", comments: "EWC01_EWC02_EWC015");
                FastDriver.BottomFrame.Save();
                #endregion

                #region User tries to save the new phrase group creation instance when Phrase Group Name is blank
                Reports.TestStep = "User tries to save the new phrase group creation instance when Phrase Group Name is blank";
                Support.AreEqual("Name is required. Please enter a Name", FastDriver.WebDriver.HandleDialogMessage(true, true));
                #endregion

                #region User tries to save the instance when Phrase Group Description is blank
                Reports.TestStep = "User tries to save the instance when Phrase Group Description is blank";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: "XTES", description: "");
                FastDriver.BottomFrame.Save();
                #endregion

                #region User tries to save the new phrase group creation instance when Phrase Group Description is blank
                Reports.TestStep = "User tries to save the new phrase group creation instance when Phrase Group Description is blank";
                Support.AreEqual("Phrase Group Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.BottomFrame.Cancel();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("EWC03_DP213_DP2139: User tries to save the new phrase group creation instance when Duplicate Phrase Group Name exist")]
        public void DPUC0005_REG0002()
        {
            try
            {
                Reports.TestDescription = "EWC03_DP213_DP2139: User tries to save the new phrase group creation instance when Duplicate Phrase Group Name exist";

                FAST_Login_ADM();

                #region Navigate to Phrase Maintenance screen and click on New button
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Save 1st Phrase Group with a given Phrase Group Name
                Reports.TestStep = "Save 1st Phrase Group with a given Phrase Group Name";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0002", phraseType: "Escrow Phrase", comments: "EWC03_DP213_DP2139");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click on New when the Phrase Group Maitenance Summary screen loads
                Reports.TestStep = "Click on New when the Phrase Group Maitenance Summary screen loads";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Save 2nd Phrase Group with the previous Phrase Group Name
                Reports.TestStep = "Save 2nd Phrase Group with the previous Phrase Group Name";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0002", phraseType: "Escrow Phrase", comments: "EWC03_DP213_DP2139");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify whether duplicate error message has displayed
                Reports.TestStep = "Verify whether duplicate error message has displayed";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.ErrorMessage);
                Support.AreEqual("Error[PhraseGrp]: Phrase Group Name already exists.  Please enter a new Name.", FastDriver.PhraseGroupMaintenance.ErrorMessage.FAGetText(), "ErrorMessage");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                #endregion

                #region Search for a Phrase Group and delete it
                Reports.TestStep = "Search for a Phrase Group and delete it";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.DeletePhraseGroup(type: "Escrow Phrase", description: "Automation test DPUC0005 REG0002");
                Playback.Wait(3000);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("EWC04_EWC05_EWC06_EWC015: User tries to save the new phrase creation instance when Duplicate phrase Name exists")]
        public void DPUC0005_REG0003()
        {
            try
            {
                Reports.TestDescription = "EWC04_EWC05_EWC06_EWC015: User tries to save the new phrase creation instance when Duplicate phrase Name exists";

                FAST_Login_ADM();

                #region Navigate to Phrase Maintenance screen and click on New button
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Save Phrase Group with a given Phrase Group Name
                Reports.TestStep = "Save Phrase Group with a given Phrase Group Name";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0003", phraseType: "Escrow Phrase", comments: "EWC04_EWC05_EWC06_EWC015");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Add when the Phrase Group Maitenance screen loads
                Reports.TestStep = "Click on Add when the Phrase Group Maitenance screen loads";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                #endregion

                #region Add a new Phrase
                Reports.TestStep = "Add a new Phrase";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                var phraseName = Support.RandomString("AAAA");
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Automation test DPUC0005 REG0003", comments: "EWC04_EWC05_EWC06_EWC015");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate saving new Phrase without any name or description value
                Reports.TestStep = "Validate saving new Phrase without any name or description value";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.New.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: "XTES");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Phrase Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: "", description: "DescText");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Phrase Name is required. Please enter a Name", FastDriver.WebDriver.HandleDialogMessage(true, true));
                #endregion

                #region Try to create a new Phrase with same name as previous Phrase
                Reports.TestStep = "Try to create a new Phrase with same name as previous Phrase";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Automation test DPUC0005 REG0003", comments: "EWC04_EWC05_EWC06_EWC015");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify whether duplicate error message has displayed
                Reports.TestStep = "Verify whether duplicate error message has displayed";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.ErrorMessage);
                Support.AreEqual("Error[PhraseGrp]: Phrase Name already exists. Please enter a new Name.", FastDriver.PhraseMaintenance.ErrorMessage.FAGetText(), "ErrorMessage");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                #endregion

                #region Search for a Phrase Group and validate DELETE is disabled
                Reports.TestStep = "Search for a Phrase Group and validate DELETE is disabled";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.SearchForPhraseGroup(type: "Escrow Phrase", description: "Automation test DPUC0005 REG0003");
                Support.AreEqual("False", FastDriver.PhraseGroupMaintenanceSummary.Delete.IsEnabled().ToString(), "Delete IsEnabled");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("EWC07_EWC08_EWC09_DP2146_DP3855_DP2148_DP2149_DP2150: User attempts to enter top/left/right margin value greater than 7.0")]
        public void DPUC0005_REG0004()
        {
            try
            {
                Reports.TestDescription = "EWC07_EWC08_EWC09_DP2146_DP3855_DP2148_DP2149_DP2150: User attempts to enter top/left/right margin value greater than 7.0";

                FAST_Login_ADM();

                #region Navigate to Phrase Maintenance screen and click on New button
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Save Phrase Group with a given Phrase Group Name
                Reports.TestStep = "Save Phrase Group with a given Phrase Group Name";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0004", phraseType: "Escrow Phrase", comments: "EWC07_EWC08_EWC09_DP2146_DP3855_DP2148_DP2149_DP2150");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Add when the Phrase Group Maitenance screen loads
                Reports.TestStep = "Click on Add when the Phrase Group Maitenance screen loads";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                #endregion

                #region Verify adding a new Phrase entering top/left/right margin greater that 7.0
                Reports.TestStep = "Verify adding a new Phrase entering top/left/right margin greater that 7.0";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                var phraseName = Support.RandomString("AAAA");
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Automation test DPUC0005 REG0004", comments: "EWC07_EWC08_EWC09_DP2146_DP3855_DP2148_DP2149_DP2150", formatting_MarginTop: "7.1");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Incorrect Top Margin value. Valid Values are decimals between 0.00 and 7.00", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(formatting_MarginTop: "1.0", formatting_MarginLeft: "7.1");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Incorrect Left Margin value. Valid Values are decimals between 0.00 and 7.00", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(formatting_MarginLeft: "1.0", formatting_MarginRight: "7.1");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Incorrect Right Margin value. Valid Values are decimals between 0.00 and 7.00", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                #endregion

                #region Search for a Phrase Group and delete it
                Reports.TestStep = "Search for a Phrase Group and delete it";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.DeletePhraseGroup(type: "Escrow Phrase", description: "Automation test DPUC0005 REG0004");
                Playback.Wait(3000);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BusinessRuleSet1: User attempts to copy to a phrase Name that already exists")]
        public void DPUC0005_REG0005()
        {
            try
            {
                Reports.TestDescription = "BusinessRuleSet1: User attempts to copy to a phrase Name that already exists";
                //  (EWC010_EWC011_EWC012_EWC013_EWC020_EWC021_EWC022_EWC023_EWC024_EWC025_EWC026_EWC027_EWC028_EWC029_BR_DP1678_DP1680_DP1681)
                FAST_Login_ADM();

                #region Navigate to Phrase Maintenance screen and click on New button
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Save Phrase Group with a given Phrase Group Name
                Reports.TestStep = "Save Phrase Group with a given Phrase Group Name";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0005", phraseType: "Escrow Phrase", comments: "None");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Add when the Phrase Group Maitenance screen loads
                Reports.TestStep = "Click on Add when the Phrase Group Maitenance screen loads";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                #endregion

                #region Add a new Phrase
                Reports.TestStep = "Add a new Phrase";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                var phraseName = Support.RandomString("AAAA");
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Automation test DPUC0005 REG0005", comments: "None");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Copy to an existing phrase name
                Reports.TestStep = "Copy to an existing phrase name";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.GetPhrase(1).FAClick();
                FastDriver.PhraseGroupMaintenance.Copy.FAClick();
                FastDriver.PhraseGroupMaintenance.Save.FAClick();
                Support.AreEqual("The phrase Code \"" + groupName + "/" + phraseName + "\" already exists Please enter a new code.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Cancel.FAClick();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                #endregion

                #region Navigate to Phrase Copy screen and validate fields
                Reports.TestStep = "Navigate to Phrase Copy screen and validate fields";
                FastDriver.PhraseCopy.Open();
                FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FASetText("X@G#");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Support.AreEqual("Phrase Group Name is not valid", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FASetText("");
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText("*#@W");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Playback.Wait(6000);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_ERR.FAClick();
                Support.AreEqual("Invalid copy from Phrase Group Name", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText("", continueOnFailure: true);
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_ERR.FAClick();
                Support.AreEqual("Invalid copy from Phrase Group Name", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText("X@G#");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Support.AreEqual("Phrase Group Name is not valid", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText("");
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText("{");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Support.AreEqual("Name may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" + - = ( ) . , characters", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText("");
                FastDriver.PhraseCopy.CopyToPhrases_Description.FASetText("{");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , characters", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_ERR.FAClick();
                Support.AreEqual("Invalid copy from Phrase Group Name", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("EWC016: User attempts to Cancel the changes in Phrase Maintenance Screen")]
        public void DPUC0005_REG0006()
        {
            try
            {
                Reports.TestDescription = "EWC016: User attempts to Cancel the changes in Phrase Maintenance Screen";

                FAST_Login_ADM();

                #region Navigate to Phrase Maintenance screen and click on New button
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Save Phrase Group with a given Phrase Group Name
                Reports.TestStep = "Save Phrase Group with a given Phrase Group Name";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0006", phraseType: "Escrow Phrase", comments: "EWC016");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify User attempts to Cancel the changes in Phrase Maintenance Screen
                Reports.TestStep = "Verify User attempts to Cancel the changes in Phrase Maintenance Screen";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.EditPhraseGroup(type: "Escrow Phrase", description: "Automation test DPUC0005 REG0006");
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(phraseType: "Title Phrase");
                FastDriver.BottomFrame.Cancel();
                Support.IsTrue(true, FastDriver.WebDriver.HandleDialogMessage(true, true));
                #endregion

                #region Search for a Phrase Group and delete it
                Reports.TestStep = "Search for a Phrase Group and delete it";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.DeletePhraseGroup(type: "Escrow Phrase", description: "Automation test DPUC0005 REG0006");
                Playback.Wait(3000);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("EWC030_EWC031: User tries to copy phrases with one or more phrases selected for copy have invalid entries")]
        public void DPUC0005_REG0007()
        {
            try
            {
                Reports.TestDescription = "EWC030_EWC031: User tries to copy phrases with one or more phrases selected for copy have invalid entries";

                FAST_Login_ADM();

                #region Navigate to Phrase Maintenance screen and click on New button
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Create 1st Phrase Group with a Phrase
                Reports.TestStep = "Create 1st Phrase Group with a Phrase";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0007", phraseType: "Escrow Phrase", comments: "EWC030_EWC031");
                FastDriver.BottomFrame.Save();
                //
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                //
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                var phraseName = Support.RandomString("AAAA");
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Automation test DPUC0005 REG0007", comments: "EWC030_EWC031");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create 2nd Phrase Group without any Phrase
                Reports.TestStep = "Create 2nd Phrase Group without any Phrase";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                //
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName2 = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName2, description: "Automation test DPUC0005 REG0007", phraseType: "Escrow Phrase", comments: "EWC030_EWC031");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify copying phrase from 1st phrase group to the 2nd
                Reports.TestStep = "Verify copying phrase from 1st phrase group to the 2nd";
                FastDriver.PhraseCopy.Open();
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseGroup.FASelectItem(groupName + " - Automation test DPUC0005 REG0007");
                Playback.Wait(5000);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate missing selected phrase";
                FastDriver.PhraseCopy.Copy.FAClick();
                Support.AreEqual("No phrases selected.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyFromPhrases_Select.FASetCheckbox(true);
                //
                Reports.TestStep = "Validate missing 2nd phrase group name";
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_ERR.FAClick();
                Support.AreEqual("To Phrase Group Name is blank", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate missing 2nd phrase name";
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(groupName2);
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText("");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_ERR.FAClick();
                Support.AreEqual("To Phrase Name is blank", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate copying phrase from 1st phrase group to the 2nd";
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.Copy.FAClick();
                Playback.Wait(5000);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_OK.FAClick();
                Support.AreEqual("SUCCEEDED: Phrase " + groupName + "-" + phraseName + " has been inserted.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate copying already exsting phrase";
                FastDriver.PhraseCopy.Copy.FAClick();
                Support.AreEqual("1 out of 1 Phrases were already copied and could not be copied again.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("EWC018_EWC019: User selects Phrase Properties button without entering valid Phrase Group Name/Phrase Name")]
        public void DPUC0005_REG0008()
        {
            try
            {
                Reports.TestDescription = "EWC018_EWC019: User selects Phrase Properties button without entering valid Phrase Group Name/Phrase Name";

                FAST_Login_ADM();

                #region Navigate to Phrase Editor screen and enter invalid Phrase Group/Phrase Code
                Reports.TestStep = "Navigate to Phrase Editor screen and enter invalid Phrase Group/Phrase Code";
                FastDriver.EditPhrase.Open();
                FastDriver.EditPhrase.PhraseGroupCode.FASetText("$#/*&");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                #endregion

                #region Verify user cannot view Phrase Properties for invalid Phrase Group/Phrase Code
                Reports.TestStep = "Verify user cannot view Phrase Properties for invalid Phrase Group/Phrase Code";
                FastDriver.EditPhrase.PhraseProperties.FAClick();
                Support.AreEqual("Phrase Group Code / Phrase Code is not valid", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.EditPhrase.WaitForScreenToLoad();
                #endregion

                #region Verify user cannot view Phrase Editor for invalid Phrase Group/Phrase Code
                Reports.TestStep = "Verify user cannot view Phrase Editor for invalid Phrase Group/Phrase Code";
                FastDriver.EditPhrase.PhraseEditor.FAClick();
                Support.AreEqual("Phrase Group Code / Phrase Code is not valid", FastDriver.WebDriver.HandleDialogMessage(true, true));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("EWC032_EWC033_EWC034_EWC035_EWC036_EWC037_EWC038_EWC039_EWC040_BR_DP1685: User tries to copy with no values in the row selected")]
        public void DPUC0005_REG0009()
        {
            try
            {
                Reports.TestDescription = "EWC032_EWC033_EWC034_EWC035_EWC036_EWC037_EWC038_EWC039_EWC040_BR_DP1685: User tries to copy with no values in the row selected";

                FAST_Login_ADM();

                #region Navigate to Phrase Maintenance screen and click on New button
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Create 1st Phrase Group with a Phrase
                Reports.TestStep = "Create 1st Phrase Group with a Phrase";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0009", phraseType: "Escrow Phrase", comments: "None");
                FastDriver.BottomFrame.Save();
                //
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                //
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                var phraseName = Support.RandomString("AAAA");
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Automation test DPUC0005 REG0009", comments: "None");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create 2nd Phrase Group without any Phrase
                Reports.TestStep = "Create 2nd Phrase Group without any Phrase";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                //
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName2 = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName2, description: "Automation test DPUC0005 REG0009", phraseType: "Escrow Phrase", comments: "None");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify User tries to copy without all required info
                Reports.TestStep = "Verify User tries to copy without all required info";
                FastDriver.PhraseCopy.Open();
                //
                Reports.TestStep = "Validate missing selected phrase";
                FastDriver.PhraseCopy.Copy.FAClick();
                Support.AreEqual("No phrases selected.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate missing From-Group Name";
                FastDriver.PhraseCopy.CopyFromPhrases_Select.FASetCheckbox(true);
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_ERR.FAClick();
                Support.AreEqual("From Phrase Group Name is blank", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                //
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseGroup.FASelectItem(groupName + " - Automation test DPUC0005 REG0009");
                Playback.Wait(5000);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyFromPhrases_Select.FASetCheckbox(true);
                //
                Reports.TestStep = "Validate missing 1st phrase name";
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText("", continueOnFailure: true);
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_ERR.FAClick();
                Support.AreEqual("From Phrase Name is blank", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate missing 2nd phrase group name";
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText("");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_ERR.FAClick();
                Support.AreEqual("To Phrase Group Name is blank", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate missing 2nd phrase name";
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(groupName2);
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText("");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyStatus_ERR.FAClick();
                Support.AreEqual("To Phrase Name is blank", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Revertphrsgrp: To revert the Phrase group")]
        public void DPUC0005_REG0010()
        {
            try
            {
                Reports.TestDescription = "Revertphrsgrp: To revert the Phrase group";

                FAST_Login_ADM();

                #region Navigate to Phrase Maintenance screen and click on New button
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Create Phrase Group with a given Description
                Reports.TestStep = "Save Phrase Group with a given Phrase Group Name";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0010", phraseType: "Escrow Phrase", comments: "None");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Modify Phrase Group Description
                Reports.TestStep = "Modify Phrase Group Description";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("EDITED Automation test DPUC0005 REG0010");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify Phrase Group changes were saved
                Reports.TestStep = "Verify Phrase Group changes were saved";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.SearchForPhraseGroup(type: "Escrow Phrase", description: "EDITED Automation test DPUC0005 REG0010");
                Support.IsTrue(FastDriver.PhraseGroupMaintenanceSummary.SearchResult.Exists(3), "SearchResult Exists");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        //  DPUC0005_REG0011 was Not Found

        [TestMethod]
        [Description("BR_DP217_DP218_DP219_DP223_DP8307_FD_PGM_FD_PM: Add data element to a phrase group")]
        public void DPUC0005_REG0012()
        {
            try
            {
                Reports.TestDescription = "BR_DP217_DP218_DP219_DP223_DP8307_FD_PGM_FD_PM: Add data element to a phrase group";

                FAST_Login_ADM();

                #region Navigate to Phrase maintenance screen & click on New button
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Create new Phrase Group by entering the mandatory details
                Reports.TestStep = "Create new Phrase Group by entering the mandatory details";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0012", phraseType: "Title Phrase", comments: "BR_DP217_DP218_DP219_DP223_DP8307_FD_PGM_FD_PM",
                    fontNameType: "Tahoma", fontSize: "10", marginTop: "0.21", marginLeft: "0.70", marginRight: "0.80");
                FastDriver.BottomFrame.Save();
                var createdDate = DateTime.UtcNow.ToPST().ToString("MM/%d/yyyy");
                #endregion

                #region Verify the Created By and Created Date
                Reports.TestStep = "Verify the Created By and Created Date";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                Support.AreEqual("Super User", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText(), "Created By");
                Support.Match(createdDate, FastDriver.PhraseGroupMaintenance.CreatedDate.FAGetText(), "Created Date");
                #endregion

                #region Click on Add button
                Reports.TestStep = "Click on Add button";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                #endregion

                #region Create new Phrase by entering the mandatory details
                Reports.TestStep = "Create new Phrase by entering the mandatory details";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                var phraseName = Support.RandomString("AAAA");
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Automation test DPUC0005 REG0012", comments: "BR_DP217_DP218_DP219_DP223_DP8307_FD_PGM_FD_PM", editable: true, underConstruction: true,
                    formatting_Name: "Tahoma", formatting_Size: "10", formatting_MarginTop: "0.21", formatting_MarginLeft: "0.70", formatting_MarginRight: "0.80");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Change the formatting of the phrase
                Reports.TestStep = "Change the formatting of the phrase";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(editable: true, underConstruction: true, formatting_Name: "Verdana", formatting_Size: "12", formatting_MarginTop: "0.80", formatting_MarginLeft: "2.22", formatting_MarginRight: "0.90");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Load Phrase Editor
                Reports.TestStep = "Load Phrase Editor";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                Playback.Wait(3000);
                #endregion

                #region Click on Insert data element link
                Reports.TestStep = "Click on Insert data element link";
                var editorWindowName = phraseName + " - Automation test DPUC0005 REG0012";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(windowName: editorWindowName);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                #endregion

                #region Select a data element & enter the value
                Reports.TestStep = "Select a data element & enter the value";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Buyer");
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("Text");
                FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
                FastDriver.DataElementSelectionDlg.GetSearchResult(1).FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Click on Save and then Done in Editor Dialog Box
                Reports.TestStep = "Click on Save and then Done in Editor Dialog Box";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(windowName: editorWindowName);
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Verify Phrase is marked as Edited
                Reports.TestStep = "Verify Phrase is marked as Edited";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/%d/yyyy"), FastDriver.PhraseMaintenance.RevisedDate1.FAGetText(), "Phrase RevisedDate");
                Support.AreEqual("feva-sa-su", FastDriver.PhraseMaintenance.Revisedby.FAGetText(), "Phrase RevisedBy");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_DP217_DP218_DP219_DP223_Fileside_FD_PM: Verify data element in file side")]
        public void DPUC0005_REG0013()
        {
            try
            {
                Reports.TestDescription = "BR_DP217_DP218_DP219_DP223_Fileside_FD_PM: Verify data element in file side";

                FAST_Login_ADM(isSuperUser: false);
                #region Navigate to Phrase maintenance screen & click on New button
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                //Chris Code
                string groupName = Support.RandomString("NANA");
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Name.FASetText(groupName);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation test DPUC0005 REG0013");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Title Phrase");
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                Reports.TestStep = "Click on Phrase Editor";
                string phraseName = Support.RandomString("NANA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Phrase US# 753369");
                FastDriver.PhraseMaintenance.Editable.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();

                Reports.TestStep = "Right Click and Select 'Insert Data Element'";
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Under Data Element select the Data element";
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("BUFMLN");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);

                Reports.TestStep = "Click on Save, Done";
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save, Done";
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Template Maintenance";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                string templateDescription = Support.RandomString("AAANNN");
                Reports.TestStep = "From the Template Type dropdown select Form and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "Enter Name for the Form, Enter Description, Uncheck the Under Construction option";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                string templateName = Support.RandomString("NANAN");
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(templateName);
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(templateDescription);
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FASetCheckbox(false);

                Reports.TestStep = "Click on Phrases tab, Click on Add button";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "From Phrase Type dropdwon Select Title Phrase";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Title Phrase");
                Playback.Wait(1000);

                Reports.TestStep = "From Phrase Group select the newly created phrase";
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("Automation test DPUC0005 REG0013" + "[" + groupName + "]");
                Playback.Wait(10000);

                Reports.TestStep = "Select the newly from the Results Grid and click on Done";
                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.DoubleClick);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Formatting Tab";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();

                Reports.TestStep = "Click on First, Middle, Page Before Last and Last pages";
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();
                FastDriver.TemplateMaintenanceFormating.MiddlePages.FAClick();
                FastDriver.TemplateMaintenanceFormating.PageBeforeLast.FAClick();
                FastDriver.TemplateMaintenanceFormating.LastPage.FAClick();

                Reports.TestStep = "Select the Filtering Tab";
                FastDriver.TemplateMaintenanceFormating.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad();

                Reports.TestStep = "Select All under Service Type, Owning Office, Property Type, Product Type,Transaction Type, Business Segment, Search Type, Program Type";
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateFilterSelectionDlg.ServiceTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.TrassactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProgrammeTypeSelectAll.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save and Done buttons";
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                //end Chris Code

                //#endregion

                #region FAST Login IIS side, WCF Create File and open in FAST
                Reports.TestStep = "FAST Login IIS side, WCF Create File and open in FAST";
                FAST_Login_IIS();
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Document Repository and click on Add a Document
                Reports.TestStep = "Navigate to Document Repository and click on Add a Document";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.Add.FAClick();
                #endregion

                #region Search for the template
                Reports.TestStep = "Search for the template";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(templateDescription);
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.WaitForResultsToLoad();
                #endregion

                #region Select the document and click on Create/Edit
                Reports.TestStep = "Select the document and click on Create/Edit";
                Playback.Wait(2000);
                FastDriver.AdHocDocuments.SearchResults1stRow.FAClick();
                FastDriver.AdHocDocuments.CreateEdit.FAClick();
                #endregion

                #region Edit the phrase
                Reports.TestStep = "Edit the phrase";
                Playback.Wait(2000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                FastDriver.DocumentPreparation.WaitForWindowToLoad();
                Playback.Wait(2000);
                Support.AreEqual("Buyer1Firstname Buyer1Middlename Buyer1Lastname", FastDriver.DocumentPreparation.DocumenPhraseTable.PerformTableAction(2, "Buyer First, Middle, Last Name", 3, TableAction.GetCell).Element.FindElement(By.TagName("textarea")).FAGetValue(), "Buyer Last, First, Middle Name");
                FastDriver.DocumentPreparation.DocumenPhraseTable.PerformTableAction(2, "Buyer First, Middle, Last Name", 3, TableAction.GetCell).Element.FindElement(By.TagName("textarea")).FASetText("DPUC0005_REG0013");
                FASTHelpers.KeyboardSendKeys("P", System.Windows.Input.ModifierKeys.Alt);
                FASTHelpers.KeyboardSendKeys("E", System.Windows.Input.ModifierKeys.Alt);
                #endregion

                #region Verify Phrase is not editable
                Reports.TestStep = "Verify Phrase is not editable";
                Support.AreEqual("You cannot update this phrase.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_DP1999_FD_PGM: Global properties update")]
        public void DPUC0005_REG0014()
        {
            try
            {
                Reports.TestDescription = "BR_DP1999_FD_PGM: Global properties update";

                FAST_Login_ADM();

                #region Navigate to Phrase maintenance screen & click on New button
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Create new Phrase Group by entering the mandatory details
                Reports.TestStep = "Create new Phrase Group by entering the mandatory details";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0014", phraseType: "Escrow Phrase", comments: "BR_DP1999_FD_PGM");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Add button
                Reports.TestStep = "Click on Add button";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                #endregion

                #region Create new Phrase by entering the mandatory details
                Reports.TestStep = "Create new Phrase by entering the mandatory details";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                var phraseName = Support.RandomString("AAAA");
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Automation test DPUC0005 REG0014", comments: "BR_DP1999_FD_PGM");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Check Apply To All Phrases
                Reports.TestStep = "Check Apply To All Phrases";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.ApplytoallPhrases.FASetCheckbox(true);
                #endregion

                #region Edit Phrase Group properties and propagating to phrase
                Reports.TestStep = "Edit Phrase Group properties and propagating to phrase";
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(fontNameType: "Times New Roman", fontSize: "12", marginTop: "0.25", marginLeft: "0.75", marginRight: "0.85", applyToAllPhrases: true);
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Do you want to apply the Phrase Group properties to all Phrases?", FastDriver.WebDriver.HandleDialogMessage(true, true));
                #endregion

                #region Verify the phrase properties changed via phrase maintenance
                Reports.TestStep = "Verify the phrase properties changed via phrase maintenance";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.GetPhrase(1).FAClick();
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("Times New Roman", FastDriver.PhraseMaintenance.Formatting_Name.FAGetValue(), "Formatting_Name");
                Support.AreEqual("12", FastDriver.PhraseMaintenance.Formatting_Size.FAGetValue(), "Formatting_Size");
                Support.AreEqual("0.25", FastDriver.PhraseMaintenance.Formatting_MarginTop.FAGetValue(), "Formatting_MarginTop");
                Support.AreEqual("0.75", FastDriver.PhraseMaintenance.Formatting_MarginLeft.FAGetValue(), "Formatting_MarginLeft");
                Support.AreEqual("0.85", FastDriver.PhraseMaintenance.Formatting_MarginRight.FAGetValue(), "Formatting_MarginRight");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_DP2145_DP2146_DP3855_DP2148_DP2149_DP2150: Required margin properties for creating Phrase Groups")]
        public void DPUC0005_REG0015()
        {
            try
            {
                Reports.TestDescription = "BR_DP2145_DP2146_DP3855_DP2148_DP2149_DP2150: Required margin properties for creating Phrase Groups";

                FAST_Login_ADM();

                #region Navigate to Phrase maintenance screen & click on New button
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Verify Top Margin is required
                Reports.TestStep = "Verify Top Margin is required";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0015", phraseType: "Title Phrase", comments: "BR_DP2145_DP2146_DP3855_DP2148_DP2149_DP2150",
                    marginTop: "", marginLeft: "0.70", marginRight: "0.80");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Top Margin is required", FastDriver.WebDriver.HandleDialogMessage(true, true));
                #endregion

                #region Verify Left Margin is required
                Reports.TestStep = "Verify Left Margin is required";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(marginTop: "0.20", marginLeft: "");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Left Margin is required", FastDriver.WebDriver.HandleDialogMessage(true, true));
                #endregion

                #region Verify Right Margin is required
                Reports.TestStep = "Verify Right Margin is required";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(marginLeft: "0.70", marginRight: "");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Right Margin is required", FastDriver.WebDriver.HandleDialogMessage(true, true));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        [TestMethod]
        [Description("BR_DP8305A_DP9089A: Invalid Characters in Phrase Group name and Descriptions")]
        public void DPUC0005_REG0016()
        {
            try
            {
                Reports.TestDescription = "BR_DP8305A_DP9089A: Invalid Characters in Phrase Group name and Descriptions";

                FAST_Login_ADM();

                #region Navigate to Phrase maintenance screen & click on New button
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Verify error message for invalid characters in Phrase Group name
                Reports.TestStep = "Verify error message for invalid characters in Phrase Group name";
                Action<string, string> validateNameInput = delegate(string characters, string errorMessage)
                {
                    foreach (char symbol in characters)
                    {
                        FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                        Reports.TestStep = "Do not use " + symbol + " in phrase group name";
                        FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: symbol.ToString());
                        FastDriver.BottomFrame.Save();
                        Support.AreEqual(errorMessage, FastDriver.WebDriver.HandleDialogMessage(true, true));
                    }
                };
                validateNameInput("~`!@^_{}|/\\[]", "Name may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" + - = ( ) . , characters");
                #endregion

                #region Verify error message for invalid characters in Phrase Group description
                Reports.TestStep = "Verify error message for invalid characters in Phrase Group description";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: "ABCD");
                Action<string, string> validateDescriptionInput = delegate(string characters, string errorMessage)
                {
                    foreach (char symbol in characters)
                    {
                        FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                        Reports.TestStep = "Do not use " + symbol + " in phrase group description";
                        FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(description: symbol.ToString());
                        FastDriver.BottomFrame.Save();
                        Support.AreEqual(errorMessage, FastDriver.WebDriver.HandleDialogMessage(true, true));
                    }
                };
                validateDescriptionInput("~`!@^_{}|\\[]", "Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , characters");
                FastDriver.BottomFrame.Cancel();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_DP8305B_DP9089B: Invalid Characters in Phrase name and Descriptions")]
        public void DPUC0005_REG0017()
        {
            try
            {
                Reports.TestDescription = "BR_DP8305B_DP9089B: Invalid Characters in Phrase name and Descriptions";

                FAST_Login_ADM();

                #region Navigate to Phrase maintenance screen & click on New button
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                #endregion

                #region Create new Phrase Group by entering the mandatory details
                Reports.TestStep = "Create new Phrase Group by entering the mandatory details";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "Automation test DPUC0005 REG0017", phraseType: "Escrow Phrase", comments: "BR_DP8305B_DP9089B");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Add button
                Reports.TestStep = "Click on Add button";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                #endregion

                #region Verify error message for invalid characters in Phrase name
                Reports.TestStep = "Verify error message for invalid characters in Phrase name";
                Action<string, string> validateNameInput = delegate(string characters, string errorMessage)
                {
                    foreach (char symbol in characters)
                    {
                        FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                        Reports.TestStep = "Do not use " + symbol + " in Phrase name";
                        FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: symbol.ToString());
                        FastDriver.BottomFrame.Save();
                        Support.AreEqual(errorMessage, FastDriver.WebDriver.HandleDialogMessage(true, true));
                    }
                };
                validateNameInput("~`!@^_{}|/\\[]", "Phrase Name may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" + - = ( ) . , characters");
                #endregion

                #region Verify error message for invalid characters in Phrase description
                Reports.TestStep = "Verify error message for invalid characters in Phrase description";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: "ABCD");
                Action<string, string> validateDescriptionInput = delegate(string characters, string errorMessage)
                {
                    foreach (char symbol in characters)
                    {
                        FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                        Reports.TestStep = "Do not use " + symbol + " in Phrase description";
                        FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(description: symbol.ToString());
                        FastDriver.BottomFrame.Save();
                        Support.AreEqual(errorMessage, FastDriver.WebDriver.HandleDialogMessage(true, true));
                    }
                };
                validateDescriptionInput("~`!@^_{}|\\[]", "Phrase Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , characters");
                FastDriver.BottomFrame.Cancel();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void DPUC0005_REG0018()
        {
            try
            {
                Reports.TestDescription = "BR_DP2641: Restrictions.";
                this.Login(true);

                //
                Reports.TestStep = "To verify that Shortlegal desription exists in Phrase Type";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                Support.AreEqual("True", FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FAGetAllTextFromSelect().Contains("Short Legal Description").ToString(), "Checks if Short Legal Description is an Phrase Type Option");

                //
                Reports.TestStep = "Navigate to Template maintenance screen & Click on New button.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.New.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();

                //
                Reports.TestStep = "Click on Phrases Tab & add button to add phrase.";
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();

                //
                Reports.TestStep = "Verify that Phrase Type does not contain Short Legal Description Phrase.";
                Support.AreEqual("False", FastDriver.PhraseSelectDlg.PhraseType.FAGetAllTextFromSelect().Contains("Short Legal Description").ToString());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0019()
        {
            try
            {
                Reports.TestDescription = "BR_DP9090_DP1931_FD_PC: Prevent copy of phrases with invalid entries.";
                this.Login(true);
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                #region required phrases creation
                //PhraseGroupName1
                Reports.TestStep = "To create new phrase group.";
                string phraseGroupName1 = Support.RandomString("AANN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName1, description: "RegressionBR PGP4", phraseType: "Title Phrase");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();

                //PhraseGroupRegBR3
                Reports.TestStep = "Create new Phrase Group by entering the mandatory details";
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                var groupName = Support.RandomString("AAAA");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(name: groupName, description: "RegressionBR PGP2", phraseType: "Escrow Phrase", comments: "BR_DP8305B_DP9089B");
                FastDriver.BottomFrame.Save(); 
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();

                //PhraseGroupName3
                Reports.TestStep = "To create new phrase group.";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                string phraseGroupName3 = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName3, description: "Axe2-Phrase group", phraseType: "Title Phrase");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                #endregion required phrases creation


                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To create new phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                //PhraseGroupRegBR3
                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "RegressionBR PGP5", phraseType: "Title Phrase");
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                
                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                // 
                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                //NewPhrase3
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                string phraseName = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "New created phrase1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.New.FAClick();
                Playback.Wait(1500);


                // 
                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //NewPhrase3
                string phraseName2 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName2, description: "New created phrase1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3500);

                //
                Reports.TestStep = "To copy all phrases from one phrase group to another phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseGroup.FASelectItem(phraseGroupName + " - RegressionBR PGP5");
                Playback.Wait(10000);
                if (!FastDriver.PhraseCopy.CopyFromPhrases_All.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_All.FASetCheckbox(true);
                FastDriver.PhraseCopy.CopyToPhrases_SelectGroup.FAClick();

                //
                Reports.TestStep = "To select the Phrasegroup.";
                FastDriver.PhraseGroupSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseGroupSelectDlg.PhrasegroupDlgTable.PerformTableAction("Name", phraseGroupName1,"Name",TableAction.Click);

                //
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                //
                Reports.TestStep = "To enter the second Phrase to copy group name.";
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyToPhrases_SelectGroup1.FAClick();
                Playback.Wait(2000);

                //
                Reports.TestStep = "To select the Phrasegroup.";
                FastDriver.PhraseGroupSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseGroupSelectDlg.PhrasegroupDlgTable.PerformTableAction("Name", phraseGroupName3, "Name", TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();

                //
                Reports.TestStep = "To enter invalid Phrase name.";
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText("ABCD");
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASendKeys(Keys.Tab);
                
                //
                Reports.TestStep = "Invalid Phrase name.";
                Playback.Wait(10000);
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage().Contains("Phrase Name is not Valid").ToString());

                //
                Reports.TestStep = "To click on Copy button.";
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                FastDriver.PhraseCopy.Copy.FAClick();

                //
                Reports.TestStep = "User tries to copy without all required info.";
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage().Contains("Copy Phrase Action aborted due to errors").ToString());

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("RegressionBR*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(5500);

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "RegressionBR PGP4", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To verify that Phrases are not copied.";
                Support.AreEqual("0",FastDriver.PhraseGroupMaintenance.PhrasesTable.GetRowCount().ToString());
                
                //
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {
                
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0020()
        {
            try
            {
                Reports.TestDescription = "FD_PGPS: Field validation in Phrase Group Summary screen.";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase Maintenance screen and click on New button";
                FastDriver.PhraseGroupMaintenanceSummary.Open();
                Support.AreEqual("True", FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FAGetText().Contains(@"Continue From Phrase Continue On Phrase Escrow Phrase Exception Phrase Exception Phrase Marker Footer Phrase Header Phrase Informational Notes Phrase Informational Notes Phrase Marker Miscellaneous Phrase Requirement Phrase Marker Requirements Phrase Short Legal Description Phrase Title Phrase").ToString());
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("");
                Keyboard.SendKeys("%w");

                // 
                Reports.TestStep = "To verify that description is cleared after click on New Search";
                Support.AreEqual("", FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FAGetText());


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0021()
        {
            try
            {
                Reports.TestDescription = "FD_PGM: Field validation in Phrase Group Maintenance screen.";

                // 
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                this.Login(true);
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                // 
                Reports.TestStep = "Field validation in PhraseGroupMaintenance.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetText().Contains(@"Continue From Phrase Continue On Phrase Escrow Phrase Exception Phrase Exception Phrase Marker Footer Phrase Header Phrase Informational Notes Phrase Informational Notes Phrase Marker Miscellaneous Phrase Requirement Phrase Marker Requirements Phrase Short Legal Description Phrase Title Phrase").ToString());
                Support.AreEqual("8 10 12 14 18 24 36", FastDriver.PhraseGroupMaintenance.FontSize.FAGetText().Clean());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0022()
        {
            try
            {
                Reports.TestDescription = "BR_DP8307_FD_PM: Field validation in Phrase Maintenance screen.";

                // 
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                this.Login(true);
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                // 
                Reports.TestStep = "To create new phrase group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Testphrasedescriptionfieldmlengthbounda", phraseType: "Escrow Phrase");
                Keyboard.SendKeys(FAKeys.Tab);
                Support.AreEqual("Testphrasedescriptionfieldmlengthbounda", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());

                // 
                Reports.TestStep = "To verify the min field length of phrase group desc.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Testphrasedescriptionfieldmlengthboundar");
                Keyboard.SendKeys(FAKeys.Tab);
                Support.AreEqual("True", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean().Contains("Testphrasedescriptionfieldmlengthboundar").ToString());
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                // 
                Reports.TestStep = "Field validation in Phrase Maintenance screen.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Editable.Selected.ToString());
                Support.AreEqual("False", FastDriver.PhraseMaintenance.UnderConstruction.Selected.ToString());
                this.EnterPhraseMaintenanceData(phraseName: "TPST", description: "Testphrasedescriptionfieldmlengthboundar");
                Keyboard.SendKeys(FAKeys.Tab);
                Support.AreEqual("False", FastDriver.PhraseMaintenance.UnderConstruction.Selected.ToString());
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Description.FAGetValue().Clean().Contains("Testphrasedescriptionfieldmlengthboundar").ToString());
                Support.AreEqual("8 10 12 14 18 24 36", FastDriver.PhraseMaintenance.Formatting_Size.FAGetText().Clean());
                Support.AreEqual("False", FastDriver.PhraseMaintenance.Formatting_FullJustify.Selected.ToString());
                Support.AreEqual("False", FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.Selected.ToString());
                Support.AreEqual("False", FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.Selected.ToString());

                // 
                Reports.TestStep = "Field length for Phrase desc.";
                FastDriver.PhraseMaintenance.Description.FASetText("Testphrasedescriptionfieldmlengthbounda");
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.PhraseMaintenance.PhraseName.Click();
                Playback.Wait(250);
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Description.FAGetValue().Clean().Contains("Testphrasedescriptionfieldmlengthbounda").ToString());

                if (!FastDriver.PhraseMaintenance.Status_Inactive.Selected)
                    FastDriver.PhraseMaintenance.Status_Inactive.FAClick();
                // 
                Reports.TestStep = "Verify field length.";
                Support.AreEqual("False", FastDriver.PhraseMaintenance.UnderConstruction.Selected.ToString());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0023()
        {
            try
            {
                Reports.TestDescription = "FD_EP: Field validation in Edit Phrase screen.";

                Reports.TestStep = "Field validation of Edit Phrase.";
                this.Login(true);

                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "To create new phrase group.";

                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "RegressionBR PGP5", phraseType: "Title Phrase");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.New.FAClick();

                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                string phraseName = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "New created phrase");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);


                FastDriver.LeftNavigation.Navigate<EditPhrase>("Home>System Maintenance>Document Preparation>Edit Phrase").WaitForScreenToLoad();
                Keyboard.SendKeys("%S");
                Reports.StatusUpdate("Using ALT + S for clicking on Select Button", true);

                //
                Reports.TestStep = "Field validation1.";
                FastDriver.SelectPhraseGroupPhraseDlg.WaitForScreenToLoad();
                FastDriver.SelectPhraseGroupPhraseDlg.PhraseGroupTable.PerformTableAction(1, phraseGroupName, 1, TableAction.Click);
               // Playback.Wait(2000);
                FastDriver.SelectPhraseGroupPhraseDlg.Next.FAClick();
                FastDriver.SelectPhraseGroupPhraseDlg.Previous.FAClick();
                Keyboard.SendKeys("%C");
                Reports.StatusUpdate("Using ALT + C for clicking on Cancel Button", true);
                Playback.Wait(2000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //FastDriver.SelectPhraseGroupPhraseDlg.PhraseGroup.

                //
                Reports.TestStep = "Field validation of Edit Phrase.";
                FastDriver.LeftNavigation.Navigate<EditPhrase>("Home>System Maintenance>Document Preparation>Edit Phrase").WaitForScreenToLoad();
                Playback.Wait(3000);
                Keyboard.SendKeys("%S");
                Reports.StatusUpdate("Using ALT + S for clicking on Select Button", true);
                Playback.Wait(5000);

                //
                Reports.TestStep = "Field validation2.";
                //Fix table issue;
                FastDriver.SelectPhraseGroupPhraseDlg.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.SelectPhraseGroupPhraseDlg.PhraseGroupTable.PerformTableAction(1, phraseGroupName, 1, TableAction.Click);
                FastDriver.SelectPhraseGroupPhraseDlg.Next.FAClick();
                Playback.Wait(2000);

                //while (!FastDriver.SelectPhraseGroupPhraseDlg.PhraseGroupTable.GetRowCount().ToString().Equals("1"))
                //{
                //    Playback.Wait(500);
                //}
                FastDriver.SelectPhraseGroupPhraseDlg.WaitForScreenToLoad(FastDriver.SelectPhraseGroupPhraseDlg.PhraseGroupTable2);
                Playback.Wait(2000);
                //FastDriver.SelectPhraseGroupPhraseDlg.PhraseGroupTable.GiveFocus();
                FastDriver.SelectPhraseGroupPhraseDlg.PhraseGroupTable2.PerformTableAction(1, phraseName, 1, TableAction.Click);

                //FastDriver.SelectPhraseGroupPhraseDlg.Previous.FAClick();
                Keyboard.SendKeys("%o");
                Reports.StatusUpdate("Using ALT + o for clicking on Done Button", true);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Field validation3.";
                Keyboard.SendKeys("%E");
                Reports.StatusUpdate("Using ALT + E for clicking on Phrase Editor Button", true);
                Playback.Wait(10000);

                //
                //Reports.TestStep = "Verify Phrase Maintenance screen is loaded.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To verify Phrase Editor is loaded.";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^Q");
                Reports.StatusUpdate("Using CTRL + Q for clicking on Phrase Editor Button", true);

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0024()
        {
            try
            {
                Reports.TestDescription = "ADMRevert_PhraseGroup: To revert the Phrase group.";

                this.Login(true);
                for (int i = 1; i < 6; i++)
                {
                    FastDriver.PhraseGroupMaintenanceSummary.Open();
                    FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                    FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                    //
                    Reports.TestStep = "To create new phrase group.";

                    string phraseGroupName = Support.RandomString("AAAN");
                    this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "RegressionBR PGP" + i, phraseType: "Escrow Phrase");
                    FastDriver.BottomFrame.Save();
                    Playback.Wait(3000);
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(3000);
                }

                FastDriver.PhraseGroupMaintenanceSummary.Open();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "To create new phrase group.";

                string phraseGroupNameLarger = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupNameLarger, description: "Testphrasedescriptionfieldmlengthboundar", phraseType: "Escrow Phrase");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("RegressionBR*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "RegressionBR PGP2", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the template.";
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(description: "RegressionBR PGP2not");
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("RegressionBR*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "RegressionBR PGP4", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the template.";
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(description: "RegressionBR PGP4not");
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("RegressionBR*");

                //  
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "RegressionBR PGP5", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the template.";
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(description: "RegressionBR PGP5not");
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Testphrasedescriptionfieldmlengthboundar*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "Testphrasedescriptionfieldmlengthboundar", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Delete.FAClick();
                Playback.Wait(1000);
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0025()
        {
            try
            {
                Reports.TestDescription = "ADMRevert_Template: To revert the Template.";
                this.Login(true);

                // 
                Reports.TestStep = "Navigate to Template maintenance screen & Searching for template.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template Brief Info.");

                // 
                Reports.TestStep = "Click on Find Now button and select the record.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(1500);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "Template Brief Info.", 2, TableAction.Click);

                // 
                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

                // 
                Reports.TestStep = "Edit the Template Description.";
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(description: "Template Brief Infonot.");
                FastDriver.BottomFrame.Save();


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0026()
        {
            try
            {
                Reports.TestDescription = "BR_DP211_DP212_DP215_DP227_DP1998_DP2138_DP2140_DP2141_DP2143_DP8306_DP8307_FD_PGPS_FD_PGM_FD_PM: To add new phrase group.";
                this.Login(true);

                // 
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";

                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Escrow Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                // 
                Reports.TestStep = "To verify the new phrase created.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue());
                Support.AreEqual("Escrow Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem());
                //Support.AreEqual("Escrow Phrase", FastDriver.PhraseGroupMaintenance.Createdby.FAGetValue());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText());
                //AutoConfig.UserName.ToUpper
                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.New.FAClick();

                // 
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup", formatting_fullJustify: true, formatting_keepLinesTogether: true, Formatting_LinkToPreviousPhrase: true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                // 
                Reports.TestStep = "Validate the revision history.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.UserName.ToUpper(), FastDriver.PhraseMaintenance.Revisedby.FAGetText().Clean().ToUpper());
                Support.AreEqual("Created: Add phrase to Phrasegroup", FastDriver.PhraseMaintenance.Statuschangecomments.FAGetText().Clean());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0027()
        {
            try
            {
                Reports.TestDescription = "BR_DP2146_DP3855_DP2148_DP2149_DP2150_DP2153_FD_PGPS_FD_PGM: To search for a Phrase Group.";

                this.Login(true);
                // 
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";

                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Escrow Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(3000);

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                Playback.Wait(1000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();



                // 
                Reports.TestStep = "Edit Phrase Group.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Title Phrase");
                FastDriver.PhraseGroupMaintenance.FontNameTYPE.FASelectItem("Times New Roman");
                FastDriver.PhraseGroupMaintenance.FontSize.FASelectItem("12");
                FastDriver.PhraseGroupMaintenance.MarginTop.FASetText("0.25");
                FastDriver.PhraseGroupMaintenance.MarginLeft.FASetText("0.75");
                FastDriver.PhraseGroupMaintenance.MarginRight.FASetText("0.85");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "To verify the phrase group after Edit.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                Support.AreEqual("Title Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("Times New Roman", FastDriver.PhraseGroupMaintenance.FontNameTYPE.FAGetSelectedItem().Clean());
                Support.AreEqual("12", FastDriver.PhraseGroupMaintenance.FontSize.FAGetSelectedItem().Clean());
                Support.AreEqual("0.25", FastDriver.PhraseGroupMaintenance.MarginTop.FAGetValue().Clean());
                Support.AreEqual("0.75", FastDriver.PhraseGroupMaintenance.MarginLeft.FAGetValue().Clean());
                Support.AreEqual("0.85", FastDriver.PhraseGroupMaintenance.MarginRight.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0028()
        {
            try
            {
                Reports.TestDescription = "BR_DP3783_FD_PGM: Deactivate a Phrase Group.";

                this.Login(true);
                // 
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";

                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Title Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                //FastDriver.BottomFrame.Done();
                // Playback.Wait(3000);

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(3000);

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To change the status of the phrase to Inactive.";
                if (!FastDriver.PhraseGroupMaintenance.Inactive.Selected)
                    FastDriver.PhraseGroupMaintenance.Inactive.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                // 
                Reports.TestStep = "To verify that phrase and phrase group status changed to inactive.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PhraseGroupMaintenance.Inactive.Enabled.ToString());
                Support.AreEqual("Inactive", FastDriver.PhraseGroupMaintenance.PhraseStatus.FAGetText());

                // 
                Reports.TestStep = "To verify that Copy button is disabled for inactive phrase.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                Support.AreEqual("False", FastDriver.PhraseGroupMaintenance.Copy.Enabled.ToString());

                // 
                Reports.TestStep = "To change the status of the phrase to Active.";
                if (!FastDriver.PhraseGroupMaintenance.Active.Selected)
                    FastDriver.PhraseGroupMaintenance.Active.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                // 
                Reports.TestStep = "To verify that phrase and phrase group status changed to Active.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PhraseGroupMaintenance.Active.Enabled.ToString());
                Support.AreEqual("Inactive", FastDriver.PhraseGroupMaintenance.PhraseStatus.FAGetText());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0029()
        {
            try
            {
                Reports.TestDescription = "BR_DP2141_FD_PGM: To edit Phrase via Phrase Maintenance.";

                this.Login(true);

                // 
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";

                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Title Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(3000);

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Edit.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Edit the phrase.";
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(description: "Axe BAT script phrase-Edit", formatting_Name: "Verdana", formatting_Size: "12", formatting_MarginTop: "0.8", formatting_MarginLeft: "2.2", formatting_MarginRight: "0.9");
                if (!FastDriver.PhraseMaintenance.Status_Active.Selected)
                    FastDriver.PhraseMaintenance.Status_Active.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                // 
                Reports.TestStep = "Verify the phrase after Edit the phrase.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("Axe BAT script phrase-Edit", FastDriver.PhraseMaintenance.Description.FAGetValue().Clean());
                Support.AreEqual("Verdana", FastDriver.PhraseMaintenance.Formatting_Name.FAGetSelectedItem().Clean());
                Support.AreEqual("12", FastDriver.PhraseMaintenance.Formatting_Size.FAGetSelectedItem().Clean());
                Support.AreEqual("0.8", FastDriver.PhraseMaintenance.Formatting_MarginTop.FAGetValue().Clean());
                Support.AreEqual("2.2", FastDriver.PhraseMaintenance.Formatting_MarginLeft.FAGetValue().Clean());
                Support.AreEqual("0.9", FastDriver.PhraseMaintenance.Formatting_MarginRight.FAGetValue().Clean());
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());
                String revisedDate = Convert.ToDateTime(FastDriver.PhraseMaintenance.RevisedDate1.FAGetText()).Date.ToString("MM/dd/yyyy");
                string fixedDate = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/dd/yyyy");
                Support.AreEqual("True", revisedDate.Contains(fixedDate).ToString());
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0030()
        {
            try
            {
                Reports.TestDescription = "DP212_DP227_DP8306_FD_PM: Edit Phrase via Navigation Tree.";
                this.Login(true);

                // 
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";

                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Title Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Search for a phrase.";
                FastDriver.LeftNavigation.Navigate<EditPhrase>("Home>System Maintenance>Document Preparation>Edit Phrase").WaitForScreenToLoad();
                FastDriver.EditPhrase.PhraseGroupCode.FASetText(phraseGroupName + @"/" + phraseName);
                FastDriver.EditPhrase.PhraseProperties.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Edit the phrase.";
                this.EnterPhraseMaintenanceData(description: "Axe BAT script phrase-Editphrase", formatting_Name: "Times New Roman", formatting_Size: "14", formatting_MarginTop: "1.15", formatting_MarginLeft: "3.2", formatting_MarginRight: "4.5");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                Reports.TestStep = "To verify the phrase group after Edit.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("Axe BAT script phrase-Editphrase", FastDriver.PhraseMaintenance.Description.FAGetValue().Clean());
                Support.AreEqual("Times New Roman", FastDriver.PhraseMaintenance.Formatting_Name.FAGetSelectedItem().Clean());
                Support.AreEqual("14", FastDriver.PhraseMaintenance.Formatting_Size.FAGetSelectedItem().Clean());
                Support.AreEqual("1.15", FastDriver.PhraseMaintenance.Formatting_MarginTop.FAGetValue().Clean());
                Support.AreEqual("3.2", FastDriver.PhraseMaintenance.Formatting_MarginLeft.FAGetValue().Clean());
                Support.AreEqual("4.5", FastDriver.PhraseMaintenance.Formatting_MarginRight.FAGetValue().Clean());
                Support.AreEqual(AutoConfig.UserName.ToLower(), FastDriver.PhraseMaintenance.RevisionHistoryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().ToLower());
                string revisedDate = Convert.ToDateTime(FastDriver.PhraseMaintenance.RevisedDate1.FAGetText()).Date.ToString("MM/dd/yyyy");
                string fixedDate = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/dd/yyyy");
                Support.AreEqual("True", revisedDate.Contains(fixedDate).ToString());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0031()
        {
            try
            {

                // 
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                this.Login(true);
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";

                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Title Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseMaintenance.Description.FASetText("Axe BAT script phrase");
                FastDriver.PhraseMaintenance.Comments.FASetText("Add phrase to Phrasegroup");
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(true);
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(3000);

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Edit.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Edit.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Edit the phrase.";
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(description: "Axe BAT script phrase-Edit", formatting_Name: "Verdana", formatting_Size: "12", formatting_MarginTop: "0.8", formatting_MarginLeft: "2.2", formatting_MarginRight: "0.9");
                if (FastDriver.PhraseMaintenance.UnderConstruction.Selected)
                    FastDriver.PhraseMaintenance.UnderConstruction.FAClick();

                if (!FastDriver.PhraseMaintenance.Status_Inactive.Selected)
                    FastDriver.PhraseMaintenance.Status_Inactive.FAClick();
                Playback.Wait(400);
                FastDriver.PhraseMaintenance.Status_StatusChangeComments.FASetText("Changed status to inactive" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                // 
                Reports.TestStep = "Verify the status of the phrase is changed to Inactive.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.PhraseMaintenance.UnderConstruction.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Status_Inactive.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Status_Inactive.Enabled.ToString());
                string revisedDate = Convert.ToDateTime(FastDriver.PhraseMaintenance.RevisedDate1.FAGetText()).Date.ToString("MM/dd/yyyy");
                string fixedDate = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/dd/yyyy");
                Support.AreEqual("True", revisedDate.Contains(fixedDate).ToString());
                Support.AreEqual("Changed status to inactive", FastDriver.PhraseMaintenance.Statuschangecomments.FAGetText());

                // 
                Reports.TestStep = "To activate the phrase.";
                if (!FastDriver.PhraseMaintenance.Status_Active.Selected)
                    FastDriver.PhraseMaintenance.Status_Active.FAClick();
                Playback.Wait(400);
                FastDriver.PhraseMaintenance.Status_StatusChangeComments.FASetText("Changed status to active" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Verify the status of the phrase is changed to active.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PhraseMaintenance.UnderConstruction.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Status_Active.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PhraseMaintenance.Status_Active.Enabled.ToString());
                string revisedDate2 = Convert.ToDateTime(FastDriver.PhraseMaintenance.RevisedDate1.FAGetText()).Date.ToString("MM/dd/yyyy");
                string fixedDate2 = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/dd/yyyy");
                Support.AreEqual("True", revisedDate2.Contains(fixedDate2).ToString(), "Revised Date Validation");
                Support.AreEqual("Changed status to active", FastDriver.PhraseMaintenance.Statuschangecomments.FAGetText());
            }

            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0032()
        {
            try
            {
                Reports.TestDescription = "DP216_FD_PGM: Copy Phrase via Phrase Maintenance.";
                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Title Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Title Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Copy.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Copy.FAClick();
                Playback.Wait(3000);

                string copyName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Copyphrasename.FASetText(copyName);
                FastDriver.PhraseGroupMaintenance.Copyphrasedescription.FASetText("Copied phrase description");
                FastDriver.PhraseGroupMaintenance.Save.FAClick();
                Playback.Wait(4000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                // 
                Reports.TestStep = "To verify that new phrase is created by copy.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Copied phrase description", 2, TableAction.Click);

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0033()
        {
            try
            {
                Reports.TestDescription = "AF12_EWC010_EWC017_EWC041_EWC042_FD_PC: Copy Phrase via Navigation Tree.";
                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create a new phrase group.";
                string phraseGroupName = Support.RandomString("AAA");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Automation BAT Phrase", phraseType: "Title Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(2000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "To verify the new phrase created.";
                Support.AreEqual("Automation BAT Phrase", FastDriver.PhraseGroupMaintenance.Descritption.FAGetValue().Clean());
                Support.AreEqual("Title Phrase", FastDriver.PhraseGroupMaintenance.PhraseType.FAGetSelectedItem().Clean());
                Support.AreEqual("FAST QA07", FastDriver.PhraseGroupMaintenance.Createdby.FAGetText().Clean());
                Support.AreEqual(phraseGroupName, FastDriver.PhraseGroupMaintenance.Namepane.FAGetText().Clean());

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAA");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To select the phrase from PhraseGroupMaintenance screen and click on Copy.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.Copy.FAClick();
                Playback.Wait(3000);

                string copyName = Support.RandomString("AAA");
                FastDriver.PhraseGroupMaintenance.Copyphrasename.FASetText(copyName);
                FastDriver.PhraseGroupMaintenance.Copyphrasedescription.FASetText("Copied phrase description");
                FastDriver.PhraseGroupMaintenance.Save.FAClick();
                Playback.Wait(4000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                // 
                Reports.TestStep = "To verify that new phrase is created by copy.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Copied phrase description", 2, TableAction.Click);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2500);

                //breakpoint
                Reports.TestStep = "To navigate to Phrase Copy screen and select the phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseGroup.FASelectItem(phraseGroupName + " - Automation BAT Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);
                FastDriver.PhraseCopy.WaitForScreenToLoad();
                if (!FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_Select.FAClick();


                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.Copy.FAClick();
                Playback.Wait(3000);
                FastDriver.PhraseCopy.CopyStatus_DUP.FAClick();

                // 
                Reports.TestStep = "Duplicate phrase created by phrase copy.";
                Support.AreEqual("FAILED: Phrase to copy is already exists", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To navigate to Phrase Copy screen and select the phrase group.";
                string copyToPhrasesPhraseName = Support.RandomString("AAA");
                FastDriver.PhraseCopy.CopyToPhrases_Description.FASetText("Axe BAT script phrase-Copied");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Automation*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction("Name", phraseGroupName, "Name", TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To verify that new phrase is created by copy.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "Axe BAT script phrase", 2, TableAction.Click);
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0034()
        {
            try
            {
                Reports.TestDescription = "BR_DP1674_DP2017_DP1685_FD_PC: Copy Phrase to Another Phrase Group via Navigation Tree.";

                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Axe1-Phrase group", phraseType: "Escrow Phrase", comments: "Created for Axe1 BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //
                Reports.TestStep = "To copy the phrases from one phrase group to another phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();
                if (!FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_Select.FAClick();
                FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_Description.FASetText("Axe BAT script phrase-via navigation");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Phrase copied successfully.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                //
                Reports.TestStep = "To click on clear button.";
                FastDriver.PhraseCopy.Clear.FAClick();

                //
                Reports.TestStep = "To validate after Click on Clear button.";
                Support.AreEqual("False", FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected.ToString());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FAGetText());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FAGetText());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyToPhrases_GroupName.FAGetText());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FAGetText());
                Support.AreEqual("", FastDriver.PhraseCopy.CopyToPhrases_Description.FAGetText());

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Axe1*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "Axe1-Phrase group", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the phrase.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Axe1-Phrase groupnotuse");
                FastDriver.BottomFrame.Save();


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void DPUC0005_REG0035()
        {
            try
            {
                Reports.TestDescription = "BR_DP1685_FD_PC: Copy All Phrases from One Phrase Group to Another via Navigation Tree.";


                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Axe1-Phrase group", phraseType: "Escrow Phrase", comments: "Created for Axe1 BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                #region new addition
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupNameadded2 = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupNameadded2, description: "Axe1-Phrase group", phraseType: "Escrow Phrase", comments: "Created for Axe1 BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseNameadded2 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                #endregion new addition

                //
                Reports.TestStep = "To copy the phrases from one phrase group to another phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();
                if (!FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_Select.FAClick();
                FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_Description.FASetText("Axe BAT script phrase-via navigation");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Phrase copied successfully.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Axe1*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "Axe1-Phrase group", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the phrase.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Axe1-Phrase groupnotuse");
                FastDriver.BottomFrame.Save();
                Playback.Wait(10000);

                //breakpoint

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName2 = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName2, description: "Axe2-Phrase group", phraseType: "Title Phrase", comments: "Created for Axe2 BAT script");
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                string phraseName2 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName2, description: "New created phrase1", comments: "Test Phrase-Automation");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2300);

                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.New.FAClick();

                //
                Reports.TestStep = "Enter mandatory info to create a new phrase .";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                string phraseName3 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName3, description: "New created phrase2", comments: "Test Phrase-Automation");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2300);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                string phraseGroupName3 = Support.RandomString("AAAN");
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName3, description: "TestAxe3-Phrase group", phraseType: "Escrow Phrase", comments: "Test phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "To copy all phrases from one phrase group to another phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();

                FastDriver.PhraseCopy.CopyFromPhrases_PhraseGroup.FASelectItem(phraseGroupName2 + " - Axe2-Phrase group");
                if (!FastDriver.PhraseCopy.CopyFromPhrases_All.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_All.FAClick();

                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName3);
                FastDriver.PhraseCopy.CopyToPhrases_GroupName1.FASetText(phraseGroupName3);
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Phrase copied successfully.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("TestAxe3*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName3, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To verify that new phrase is created by copy.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "New created phrase1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "New created phrase2", 2, TableAction.Click);

                //
                Reports.TestStep = "To change the description of the phrase group.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("TestAxe3-Phrase groupnot");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3500);

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Axe2*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName2, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the phrase.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Axe2-Phrase groupnotuse");
                FastDriver.BottomFrame.Save();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0036()
        {
            try
            {
                Reports.TestDescription = "PGRevert1: Revert the Phrase Group to initial values.";

                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName, description: "Axe1-Phrase group", phraseType: "Escrow Phrase", comments: "Created for Axe1 BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                #region new addition
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupNameadded2 = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupNameadded2, description: "Axe1-Phrase group", phraseType: "Escrow Phrase", comments: "Created for Axe1 BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseNameadded2 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName, description: "Axe BAT script phrase", comments: "Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                #endregion new addition

                //
                Reports.TestStep = "To copy the phrases from one phrase group to another phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();
                if (!FastDriver.PhraseCopy.CopyFromPhrases_Select.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_Select.FAClick();
                FastDriver.PhraseCopy.CopyFromPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyFromPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName);
                FastDriver.PhraseCopy.CopyToPhrases_PhraseName.FASetText(phraseName);
                FastDriver.PhraseCopy.CopyToPhrases_Description.FASetText("Axe BAT script phrase-via navigation");
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Phrase copied successfully.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Axe1*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "Axe1-Phrase group", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the phrase.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Axe1-Phrase groupnotuse");
                FastDriver.BottomFrame.Save();
                Playback.Wait(10000);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                string phraseGroupName2 = Support.RandomString("AAAN");
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName2, description: "Axe2-Phrase group", phraseType: "Title Phrase", comments: "Created for Axe2 BAT script");
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "click on Add button.";
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Create new phrase by Enter mandatory details.";
                string phraseName2 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName2, description: "New created phrase1", comments: "Test Phrase-Automation");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2300);

                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.New.FAClick();

                //
                Reports.TestStep = "Enter mandatory info to create a new phrase .";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                string phraseName3 = Support.RandomString("AAAN");
                this.EnterPhraseMaintenanceData(phraseName: phraseName3, description: "New created phrase2", comments: "Test Phrase-Automation");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2300);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                string phraseGroupName3 = Support.RandomString("AAAN");
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                this.EnterGroupPhraseMaintenanceData(name: phraseGroupName3, description: "TestAxe3-Phrase group", phraseType: "Escrow Phrase", comments: "Test phrasegroup");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "To copy all phrases from one phrase group to another phrase group.";
                FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy").WaitForScreenToLoad();

                FastDriver.PhraseCopy.CopyFromPhrases_PhraseGroup.FASelectItem(phraseGroupName2 + " - Axe2-Phrase group");
                if (!FastDriver.PhraseCopy.CopyFromPhrases_All.Selected)
                    FastDriver.PhraseCopy.CopyFromPhrases_All.FAClick();

                FastDriver.PhraseCopy.CopyToPhrases_GroupName.FASetText(phraseGroupName3);
                FastDriver.PhraseCopy.CopyToPhrases_GroupName1.FASetText(phraseGroupName3);
                FastDriver.PhraseCopy.Copy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Phrase copied successfully.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PhraseCopy.WaitForScreenToLoad();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("TestAxe3*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName3, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To verify that new phrase is created by copy.";
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "New created phrase1", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenance.PhrasesTable.PerformTableAction(2, "New created phrase2", 2, TableAction.Click);

                //
                Reports.TestStep = "To change the description of the phrase group.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("TestAxe3-Phrase groupnot");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3500);

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItemBySendingKeys("Title Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Axe2*");

                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                //
                Reports.TestStep = "To select the search phrasegroup for edit";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName2, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "To change the description of the phrase.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Axe2-Phrase groupnotuse");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                //BREAKPOINT
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Axe1*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(1, phraseGroupName, 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Edit.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Reverting the Phrase Group to initial values.";
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation BAT Phrase-not use");
                FastDriver.BottomFrame.Save();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0037()
        {
            try
            {
                Reports.TestDescription = "BR_DP4173: Delete Phrase Group.";
                //
                Reports.TestStep = "Login To FAST";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Phrase maintenance screen & click on New button";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                //
                Reports.TestStep = "To verify that PhraseGroupMaintenance screen is loaded.";
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter mandatory info to create anew phrase group.";
                this.EnterGroupPhraseMaintenanceData(name: "DELP", description: "Delete Test Phrase", phraseType: "Escrow Phrase", comments: "Created for Axe BAT script");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

                //
                Reports.TestStep = "Search for a phrasegroup";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupDescription.FASetText("Delete*");

                //
                Reports.TestStep = "To click on FindNow button";
                FastDriver.PhraseGroupMaintenanceSummary.FindNow.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "To verify the search result";
                Support.AreEqual("1", FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.GetRowCount().ToString());
                FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.PerformTableAction(2, "Delete Test Phrase", 2, TableAction.Click);
                FastDriver.PhraseGroupMaintenanceSummary.Delete.FAClick();
                Playback.Wait(1500);
                FastDriver.PhraseGroupMaintenanceSummary.WaitForScreenToLoad();

                // 
                Reports.TestStep = "To verify that Phrase Group is deleted";
                Support.AreEqual("0", FastDriver.PhraseGroupMaintenanceSummary.SearchresultSummarytable.GetRowCount().ToString());

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void DPUC0005_REG0038()
        {
            try
            {
                Reports.TestDescription = "To verified 785666: To verified PROD-IE10: Hot keys for Save and Done button is not working fine phrase editor screen.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                #region UI Work

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to System Maintenance/Document preparation/Template Maintenance.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();

                Reports.TestStep = "Select any template ( Any template types).";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.SearchResultsTable(4, "Active", 4, TableAction.Click);
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on Edit button.";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();

                Reports.TestStep = "Go to Phrases tab.";
                FastDriver.TemplateMaintenanceInformation.ClickPhrasesTab();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();

                Reports.TestStep = "Click on Edit.";
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.FAClick();
                FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

                Reports.TestStep = "Click on Phrase Editor.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add/Update any text.";
                sendKeysToPhraseEditor("^", "{END}");
                Keyboard.SendKeys("{ENTER}");
                Keyboard.SendKeys("Test");


                Reports.TestStep = "Use hot keys to press on Save Ctrl+S/Ctrl+D.";
                FastDriver.PhraseEditorDlg.TextArea.FAClick();
                Keyboard.SendKeys("^S");
                Playback.Wait(1000);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^D");
                Playback.Wait(1000);
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();


                Reports.TestStep = "Click on Phrase Editor and Verify the page is update with the change.";
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                Support.Equals("Test", FastDriver.PhraseEditorDlg.TextArea.FAGetText().Clean());
                sendKeysToPhraseEditor("^", "{BACK}");


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Custom Class Methods
        private void Login(bool admLogin = false)
        {
            if (!admLogin)
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,                // AutoConfig.UserName,
                    Password = AutoConfig.UserPassword            //AutoConfig.UserPassword
                };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            else
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            }
        }

        private void EnterGroupPhraseMaintenanceData(string name = null, string description = null, string phraseType = null, string comments = null, string fontNameType = null, string fontSize = null, string marginTop = null, string marginLeft = null, string marginRight = null)
        {
            if (name != null)
                FastDriver.PhraseGroupMaintenance.Name.FASetText(name);
            if (description != null)
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText(description);
            if (phraseType != null)
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem(phraseType);
            if (comments != null)
                FastDriver.PhraseGroupMaintenance.Comments.FASetText(comments);
            if (fontNameType != null)
                FastDriver.PhraseGroupMaintenance.FontNameTYPE.FASelectItem(fontNameType);
            if (fontSize != null)
                FastDriver.PhraseGroupMaintenance.FontSize.FASelectItem(fontSize);
            if (marginTop != null)
                FastDriver.PhraseGroupMaintenance.MarginTop.FASetText(marginTop);
            if (marginLeft != null)
                FastDriver.PhraseGroupMaintenance.MarginLeft.FASetText(marginLeft);
            if (marginRight != null)
                FastDriver.PhraseGroupMaintenance.MarginRight.FASetText(marginRight);
        }

        public void EnterPhraseMaintenanceData(string phraseName = null, string description = null, string comments = null, bool? formatting_fullJustify = null, bool? formatting_keepLinesTogether = null, bool? Formatting_LinkToPreviousPhrase=null , string formatting_Name = null, string formatting_Size = null, string formatting_MarginTop = null, string formatting_MarginLeft = null, string formatting_MarginRight = null)
        {
            if (phraseName != null)
                FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
            if (description != null)
                FastDriver.PhraseMaintenance.Description.FASetText(description);
            if (comments != null)
                FastDriver.PhraseMaintenance.Comments.FASetText(comments);
            if (formatting_Name != null)
                FastDriver.PhraseMaintenance.Formatting_Name.FASelectItem(formatting_Name);
            if (formatting_Size != null)
                FastDriver.PhraseMaintenance.Formatting_Size.FASelectItem(formatting_Size);
            if (formatting_MarginTop != null)
                FastDriver.PhraseMaintenance.Formatting_MarginTop.FASetText(formatting_MarginTop);

            if (formatting_MarginLeft != null)
                FastDriver.PhraseMaintenance.Formatting_MarginLeft.FASetText(formatting_MarginLeft);
            if (formatting_MarginRight != null)
                FastDriver.PhraseMaintenance.Formatting_MarginRight.FASetText(formatting_MarginRight);
            if (formatting_fullJustify != null)
                FastDriver.PhraseMaintenance.Formatting_FullJustify.FASetCheckbox(formatting_fullJustify);
            if (formatting_keepLinesTogether != null)
                FastDriver.PhraseMaintenance.Formatting_KeepLinesTogether.FASetCheckbox(formatting_keepLinesTogether);
            if (Formatting_LinkToPreviousPhrase != null)
                FastDriver.PhraseMaintenance.Formatting_LinkToPreviousPhrase.FASetCheckbox(Formatting_LinkToPreviousPhrase);
        }

        private void sendKeysToPhraseEditor(string sModifier, string sKeys)
        {
            //FastDriver.WebDriver.SwitchTo().Frame("tbContentElement");
            FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
            ModifierKeys modifier = ModifierKeys.None;
            if (sModifier == "^")
            {
                modifier = ModifierKeys.Control;
            }
            if (sModifier == "%")
            {
                modifier = ModifierKeys.Alt;
            }
            if (sModifier == "+")
            {
                modifier = ModifierKeys.Shift;
            }
            Keyboard.SendKeys(sKeys, modifier);
        }

        //private void 
        #endregion Custom Class Methods

        #region Class CleanUp
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
        #endregion Class Cleanup
    }
}
