﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using System.Threading;


namespace DocPrep
{
    
    [CodedUITest]
    public class DRUC0004 : MasterTestClass
    {

        #region REG

        #region DRUC0004_REG0001
        [TestMethod]
        public void DRUC0004_REG0001()
        {
            try
            {

                Reports.TestDescription = "MF1_2a: The user selects report option to display the report selection screen, User selects either �All� to display all Template Types within a region.";
                
                Reports.TestStep = "Log into FAST ADM site.";
                LoginFastADMSite(AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Navigate to Templates by Template Type link & Select Select All checkbox and click on Generate Reports.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsTemplatesbyTemplateType>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Templates by Template Type").WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesbyTemplateType.SelectAll.FASetCheckbox(true);
                FastDriver.DocPrepReportsTemplatesbyTemplateType.GenerateReport.FAClick();

                Reports.TestStep = "Verify for the image on list phrase by template screen.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Templates by Template Type", true, 200);
                FastDriver.ListTemplatesbyTemplateType.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ListTemplatesbyTemplateType.EagleImage.IsDisplayed().ToString());
                Support.AreEqual("Endorsement/Guarantee", FastDriver.ListTemplatesbyTemplateType.ListTemplatesbyTemplateTypeTable.PerformTableAction(1, "ENDORSE", 2, TableAction.GetText).Message.Clean());
                FastDriver.WebDriver.Quit();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region DRUC0004_REG0002
        [TestMethod]
        public void DRUC0004_REG0002()
        {
            try
            {

                Reports.TestDescription = "MF2b_3a: Select more than one Phrase group and click on Generate Reports.";

                Reports.TestStep = "Log into FAST ADM site.";
                LoginFastADMSite(AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Select more than one Phrase group and click on Generate Reports.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsTemplatesbyTemplateType>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Templates by Template Type").WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(2, 1, TableAction.On);
                string TemplateType1 = FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                string TemplateTypeDesc1 = FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(3, 1, TableAction.On);
                string TemplateType2 = FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean();
                string TemplateTypeDesc2 = FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(3, 3, TableAction.GetText).Message.Clean();
                FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(4, 1, TableAction.On);
                string TemplateType3 = FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(4, 2, TableAction.GetText).Message.Clean();
                string TemplateTypeDesc3 = FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(4, 3, TableAction.GetText).Message.Clean();
                FastDriver.DocPrepReportsTemplatesbyTemplateType.GenerateReport.FAClick();

                Reports.TestStep = "Validate template type is displayed on table";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Templates by Template Type", true, 200);
                FastDriver.ListTemplatesbyTemplateType.WaitForScreenToLoad();
                Support.AreEqual(TemplateTypeDesc1, FastDriver.ListTemplatesbyTemplateType.ListTemplatesbyTemplateTypeTable.PerformTableAction(1, TemplateType1, 2, TableAction.GetText).Message.Clean());
                Support.AreEqual(TemplateTypeDesc2, FastDriver.ListTemplatesbyTemplateType.ListTemplatesbyTemplateTypeTable.PerformTableAction(1, TemplateType2, 2, TableAction.GetText).Message.Clean());
                Support.AreEqual(TemplateTypeDesc3, FastDriver.ListTemplatesbyTemplateType.ListTemplatesbyTemplateTypeTable.PerformTableAction(1, TemplateType3, 2, TableAction.GetText).Message.Clean());
                FastDriver.WebDriver.Quit();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region DRUC0004_REG0003
        [TestMethod]
        public void DRUC0004_REG0003()
        {
            try
            {

                Reports.TestDescription = "MF3b: Navigate to Templates by Template Type link & Selecting SelectAll checkbox and click on Generate Reports.";

                Reports.TestStep = "Log into FAST ADM site.";
                LoginFastADMSite(AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Select a Phrase group and click on Generate Reports.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsTemplatesbyTemplateType>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Templates by Template Type").WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(2, 1, TableAction.On);
                string TemplateType1 = FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                string TemplateTypeDesc1 = FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                FastDriver.DocPrepReportsTemplatesbyTemplateType.GenerateReport.FAClick();

                Reports.TestStep = "Validate template type is displayed on table";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Templates by Template Type", true, 200);
                FastDriver.ListTemplatesbyTemplateType.WaitForScreenToLoad();
                Support.AreEqual(TemplateTypeDesc1, FastDriver.ListTemplatesbyTemplateType.ListTemplatesbyTemplateTypeTable.PerformTableAction(1, TemplateType1, 2, TableAction.GetText).Message.Clean());
                FastDriver.WebDriver.Quit();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region DRUC0004_REG0004
        [TestMethod]
        public void DRUC0004_REG0004()
        {
            try
            {

                Reports.TestDescription = "MF3b: Navigate to Templates by Template Type link & Selecting SelectAll checkbox and click on Generate Reports.";

                Reports.TestStep = "Log into FAST ADM site.";
                LoginFastADMSite(AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Select 'Endorsement/Guarantee' template and click on Select Templates button.";
                FastDriver.LeftNavigation.Navigate<DocPrepReportsTemplatesbyTemplateType>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Templates by Template Type").WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(3, "Endorsement/Guarantee", 1, TableAction.On);
                FastDriver.DocPrepReportsTemplatesbyTemplateType.SelectTemplates.FAClick();

                Reports.TestStep = "Selecting multiple templates.";
                FastDriver.DocPrepReportsPhrasesbyTemplate1.WaitForScreenToLoad();
                FastDriver.DocPrepReportsPhrasesbyTemplate1.SelectTemplateTable.PerformTableAction(3, 1, TableAction.On);
                FastDriver.DocPrepReportsPhrasesbyTemplate1.SelectTemplateTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.DocPrepReportsPhrasesbyTemplate1.SelectTemplateTable.PerformTableAction(5, 1, TableAction.On);
                FastDriver.DocPrepReportsPhrasesbyTemplate1.GenerateReport.FAClick();

                Reports.TestStep = "Validate template type is displayed on table";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Templates by Template Type", true, 200);
                FastDriver.ListTemplatesbyTemplateType.WaitForScreenToLoad();
                Support.AreEqual("ENDORSE", FastDriver.ListTemplatesbyTemplateType.ListTemplatesbyTemplateTypeTable.PerformTableAction(2, "Endorsement/Guarantee", 1, TableAction.GetText).Message.Clean());
                FastDriver.WebDriver.Quit();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region DRUC0004_REG0005
        [TestMethod]
        public void DRUC0004_REG0005()
        {
            try
            {

                Reports.TestDescription = "DP3665_DP3726_EWC_FD_HK: Navigate to Templates by Template Type link & Selecting template and click on Generate Reports.";

                Reports.TestStep = "Log into FAST ADM site.";
                LoginFastADMSite(AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Navigate to Template Maintenance screen, click on New button.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Provide template name, description & comments.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                string templateName = "#" + Support.RandomString("AAAZZZ");
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(templateName);
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(@"Template for DRUC0004 REG0005");
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText(@"Template for DRUC0004 REG0005");

                Reports.TestStep = "Enter data on Formatting TAB.";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();
                FastDriver.TemplateMaintenanceFormating.FormattingHeaderPhrase.FASelectItem(@"Header Ph1");
                FastDriver.TemplateMaintenanceFormating.FormattingFooterPhrase.FASelectItem(@"Footer Phrase one");
                FastDriver.TemplateMaintenanceFormating.FormattingContinueFrom.FASelectItemByIndex(1);
                FastDriver.TemplateMaintenanceFormating.FormattingContinueOn.FASelectItemByIndex(1);
                FastDriver.TemplateMaintenanceFormating.FormattingMarginTop.FASetText(@"0.5");
                FastDriver.TemplateMaintenanceFormating.FormattingMarginBottom.FASetText(@"0.5");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Templates by Template Type screen, select 'Endorsement/Guarantee', click Generate Report button";
                Thread.Sleep(10000); // wait for template to show up on report
                FastDriver.LeftNavigation.Navigate<DocPrepReportsTemplatesbyTemplateType>(@"Home>System Maintenance>Document Preparation>DocPrep Reports>Templates by Template Type").WaitForScreenToLoad();
                FastDriver.DocPrepReportsTemplatesbyTemplateType.DocPrepReportsTemplatesbyTemplateTypeTable.PerformTableAction(3, "Endorsement/Guarantee", 1, TableAction.On);
                FastDriver.DocPrepReportsTemplatesbyTemplateType.GenerateReport.FAClick();

                Reports.TestStep = "Validate template description is displayed on table";
                FastDriver.WebDriver.WaitForWindowAndSwitch("List Templates by Template Type", true, 200);
                FastDriver.ListTemplatesbyTemplateType.WaitForScreenToLoad();
                Support.AreEqual("Template for DRUC0004 REG0005", FastDriver.ListTemplatesbyTemplateType.ListTemplatesbyTemplateTypeTable.PerformTableAction(3, templateName, 4, TableAction.GetText).Message.Clean());
                FastDriver.WebDriver.Quit();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region Private Methods

        private void LoginFastADMSite(string UserName = null, string Password = null)
        {

            var ADMSiteURL = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(ADMSiteURL, Credentials, true);
        }

        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
