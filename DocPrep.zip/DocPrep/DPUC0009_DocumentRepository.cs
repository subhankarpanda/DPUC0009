﻿using OpenQA.Selenium;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTWCFHelpers;
using System.Linq;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using FASTWCFHelpers.Factories;
using System.Threading;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using AutoIt;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.IO;

namespace DocPrep
{
    [CodedUITest]
    public class DPUC0009 : FASTHelpers
    {
        #region BAT

        [TestMethod]
        public void DPUC0009_BAT0001()
        {
            try
            {

                Reports.TestDescription = "MainFlow: Create a Document (other than a Title Report, Policy, or Endorsement)";

           
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Title Reports", "Automation Test Title Report", "CA");

                Reports.TestStep = "Verify Document is added";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Title Reports", "Name", TableAction.GetText).Message.ToString();
                Support.AreEqual("Automation Test Title Report", document);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse1: Add Ad-Hoc Document";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Escrow Instruction", "Accomm Signing-Customer Buyer", "CA");

                Reports.TestStep = "Verify Document is added";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Escrow Instruction", "Name", TableAction.GetText).Message.ToString();
                Support.AreEqual("Accomm Signing-Customer Buyer", document);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0003()
        {
            try

            {
                Reports.TestDescription = "AlternateCourse2: Create a Document Containing Multi-Entity Data Element";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);


                //#region precondition

                //Reports.TestStep = "Log into FAST application.";
                //ADMLOGIN();
                ////need to create a template again to remove dependency with BAT01
                //Reports.TestStep = "Navigate to Template Maintenance screen";
                //FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                //FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                //Reports.TestStep = "Select Template Type and click on New";
                //FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Title Reports");
                //FastDriver.TemplateMaintenanceSummary.New.FAClick();

                //Reports.TestStep = "Enter information related to tempalte in Information tab";
                //string templateName = "DP9" + "bat" + Support.RandomString("AAAANANA");
                //FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                //FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                //string templateNamedes = "Template for " + templateName;
                //FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

               
                //Reports.TestStep = "Click on Formatting tab and enter required data";
                ////FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();

                //FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                //FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                //Reports.TestStep = "Add filters to the template.";
                //FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                //FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                //FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                //FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();


                //FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformationByDefaultAlltheFields();

                //Reports.TestStep = "Click on Done in Dialog Box.";
                //FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);
                //FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);

                //Reports.TestStep = "Add Phrases to the Template";
                ////FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                //FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                //FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                //FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();
                //FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                //FastDriver.PhraseSelectDlg.PhraseName.FASetText("JVE/JV01");
                //FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.BottomFrame.Save();

                //FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                //FastDriver.TemplateMaintenancePhrase.PhrasesEdit.FAClick();

               
                //Reports.TestStep = "Click on Phrase Editor button.";
                //FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                //FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                //Playback.Wait(1000);

                //Reports.TestStep = "Click on Insert data element link.";
                //FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                //FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();

                //Reports.TestStep = "Select a data element & enter the value.";
                //FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                //FastDriver.DataElementSelectionDlg.DataElement.FASetText("buname");

                //Reports.TestStep = "Click on Done in Dialog Box.";
                //FastDriver.DialogBottomFrame.ClickDone();

                //FastDriver.PhraseEditorDlg.AddPropertiesToDataElement();
                //Playback.Wait(3000);

                //FastDriver.DataElementsDlg.DataElementProppertiesPageToLoad();
                //FastDriver.DataElementsDlg.Index.FASetText("?");
                //FastDriver.DataElementsDlg.Ok.JSClick();
                //Playback.Wait(1000);
                //FastDriver.DialogBottomFrame.ClickSave();
                //FastDriver.DialogBottomFrame.ClickDone();

                //Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                //FastDriver.BottomFrame.Save();
                //FastDriver.BottomFrame.Done();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                //#endregion
                //#region region Basic File Creation
                //IISLOGIN();
                //CreateBasicFile();
                //#endregion

                //#region GUI Intreaction
                //Reports.TestStep = "Click on Add Button.";
                //FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                //FastDriver.DocumentRepository.Add.FAClick();
                //FastDriver.AdHocDocuments.AddDocument("Both", "Title Reports", templateName, "CA");

                //Reports.TestStep = "Verify Document is added";
                //FastDriver.DocumentRepository.WaitForScreenToLoad();
                //string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Title Reports", "Name", TableAction.GetText).Message.ToString();
                //Support.AreEqual("Automation Test Title Report", document);
                //#endregion
              
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse3, BR DP7491: Add Images to Document Repository";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Verify the scanned document is available in document repository screen ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("INST-Estimated Settlement Statement PO-Invoice", document);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_BAT0005()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse 4,5 and 6,15: 1.Split (Break-up) Images and Save to Document Repository and Deliver the document 2.Prevent Creation of Split Image with Only One Page";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();

                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);


                Reports.TestStep = "Click on Split Image";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[1].FindElement(By.TagName("IMG")).FADoubleClick();
                FastDriver.SplitDocumentScreenDlg.WaitForDialogLoad();
                FastDriver.SplitDocumentScreenDlg.PageRange.FASetText("1");
                FastDriver.SplitDocumentScreenDlg.WaitForDialogLoad();
                FastDriver.SplitDocumentScreenDlg.Split.GiveFocus();
                FastDriver.SplitDocumentScreenDlg.Split.FAClick();
                FastDriver.SplitDocumentScreenDlg.WaitForDialogLoad();
                FastDriver.SplitDocumentScreenDlg.Save.GiveFocus();
                FastDriver.SplitDocumentScreenDlg.Save.FAClick();

                Reports.TestStep = "Enter Document Name Dlg";
                FastDriver.DocumentNameDlg.WaitForDialogLoad1();
                FastDriver.DocumentNameDlg.DocName.FASetText("Document name:pradeep");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the splitted document is added ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("Document name:pradeep", document);

                Reports.TestStep = "Prevent Creation of Split Image with Only One Page";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[1].FindElement(By.TagName("IMG")).FAClick();
                Support.AreEqual("Splitting not supported. Active document has less than 2 pages.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Deliver the document";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.DocumentRepository.Method.FASelectItem("EMAIL");
                FastDriver.DocumentRepository.Deliver.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);


                Reports.TestStep = "Verify for Event Log is updation";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");

                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[E-mail]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains(AutoConfig.DeliverEmailTo).ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0006()
        {

            Reports.TestDescription = "AlternateCourse5: Split (Break-up) Images and Deliver through Normal Delivery Methods";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_BAT0005", true);
        }

        [TestMethod]
        public void DPUC0009_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse7,DP9081: Create a Title Report";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add Document.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Click on Info Tab and enter details";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.InfoDescription.FASetText("Automation Test Title Report_BAT7");
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.Exceptions.FASetText("CCCC/ABC1");
                FastDriver.DocumentRepository.Requirements.FASetText("JV1/JV1");
                FastDriver.DocumentRepository.Information.FASetText("ATPZ/38");
                FastDriver.DocumentRepository.InfoSourceRegion.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.DocumentRepository.btnInfoSave.FAClick();

                Reports.TestStep = "Verify the Title Report Document is created";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("Automation Test Title Report_BAT7", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report_BAT7", 4, TableAction.GetText).Message);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0008()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse8: Propose a Policy to a Title Report";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = " Add a Lender Policy document ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                Reports.TestStep = "Add a Lender Policy document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem("Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("Lender Policy");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText("LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.AdHocDocuments.State.FASelectItem("CA");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Thread.Sleep(1000);
                Reports.TestStep = "Verify Warning message";
                string message = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual("NO Commitment document on file", message);

                Reports.TestStep = "Add a Title Report document and then add Lender Policy document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                Support.AreEqual("    LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "    LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.GetText).Message);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0009()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse9: Create a Proposed Policy";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Add a Title Report document and then add Lender Policy document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "CLTA 1 Litigation Guarantee-N");

                Reports.TestStep = "Click on Info Tab and enter details";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.btnInfoSave.FAClick();

                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.PWTREffectiveDate.FAGetValue();
                Support.AreEqual(DateTime.Now.AddDays(-3).ToDateString(), FastDriver.DocumentRepository.PWTREffectiveDate.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0010()
        {

            try
            {
                Reports.TestDescription = "Alternate Course 10:  Create Multiple Documents";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create mutiple documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Template FOr TFS101656");

                Reports.TestStep = "Verify all added documents";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                Support.AreEqual("Automation Test Title Report", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.GetText).Message.ToString());
                Support.AreEqual("ATP-Commitment -N", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ATP-Commitment -N", 4, TableAction.GetText).Message.ToString());
                Support.AreEqual("Template FOr TFS101656", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template FOr TFS101656", 4, TableAction.GetText).Message.ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0011()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse11: Edit a Document";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create a document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Verify added documents";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                Support.AreEqual("Automation Test Title Report", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.GetText).Message.ToString());

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("INPUT")).FADoubleClick();

                Reports.TestStep = "Change the Name of the document";
                Playback.Wait(1000);
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.Name.FASetText("DPUC0009_BAT0011");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);

                Reports.TestStep = "Vrrify the newly updated document name";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string docname = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("DPUC0009_BAT0011", docname);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);

                Reports.TestStep = "click on Edit button";
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Enter directly Phrase names in the Phrase Name field and click on Done";
                PhraseSelectionDlg();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(1000);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify the Pharse is added";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Support.AreEqual("JVE/JV01", FastDriver.DocumentPreparationMenu.PharseJVE.FAGetText());
                #endregion

              
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0012()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse12: Create a PDF Image";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add a documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                FastDriver.DocumentRepository.WaitForPageToLoad();

                Reports.TestStep = "enter efective date";
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.btnInfoSave.FAClick();

                Reports.TestStep = "Deliver the document using IMGDOC delivery method";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
                FastDriver.DocumentRepository.Method.FASelectItem("IMAGEDOC");
                FastDriver.DocumentRepository.Deliver.FAClick();
                Reports.TestStep = "Click on Imagedoc button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.SwitchToDialogContentFrame();
                FastDriver.ImageDocDlg.WaitCreation(FastDriver.ImageDocDlg.ImageDoc);
                FastDriver.ImageDocDlg.ImageDoc.Highlight();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                Reports.TestStep = "Vrify the PDF IconNext to the Document name";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string PDFImage = FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[2].FindElements(By.TagName("TD"))[0].FindElement(By.TagName("IMG")).TagName.ToString();
                Support.AreEqual("img", PDFImage);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0014()
        {

            Reports.TestDescription = "AlternateCourse15: Deliver a Document";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_BAT0005", true);
        }

        [TestMethod]
        public void DPUC0009_BAT0015()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse14: Remove a Document";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create mutiple documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Verify added documents";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                Support.AreEqual("Automation Test Title Report", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.GetText).Message.ToString());

                Reports.TestStep = "Remove the added document";
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Verify the Document id Removed";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                Support.AreEqual("False", FastDriver.DocumentRepository.DocumentsTable.FAGetText().Contains("Automation Test Title Report").ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0016_PH()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse13: Edit an image";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0017()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse16,17: Copy Exceptions and/or Requirements and/or Informational Notes from a Title Report or Policy Document";

                #region region Basic File Creation
                CheckAssignNumADM();
                IISLOGIN();
                CreateBasicFile();
                CreateRequestForAddProductusingWCF("ALTA Extended Owner Policy");
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add Document.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Click on Info Tab and enter the Exceptions and/or Requirements and/or Informational Notes details";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.InfoDescription.FASetText("Automation Test Title Report");
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.Exceptions.FASetText("#/GP");
                FastDriver.DocumentRepository.InfoExceptions.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.DocumentRepository.Requirements.FASetText("JV1/JV1");
                FastDriver.DocumentRepository.Information.FASetText("ATPZ/38");
                FastDriver.DocumentRepository.InfoSourceRegion.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.DocumentRepository.btnInfoSave.FAClick();

                Reports.TestStep = "Add one more document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");
                Reports.TestStep = "Click on Info Tab and Copy the Exceptions and/or Requirements and/or Informational Notes details";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentInfo.CopyFrom.FAClick();
                FastDriver.CopyFrom.WaitForScreenToLoad();
                FastDriver.CopyFrom.CheckBox1.FASetCheckbox(true);
                FastDriver.CopyFrom.AddPhrases.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.CopyFrom.WaitForScreenToLoad();
                FastDriver.CopyFrom.Requirements.FAClick();
                FastDriver.CopyFrom.AddPhrases.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.CopyFrom.WaitForScreenToLoad();
                FastDriver.CopyFrom.Info.FAClick();
                FastDriver.CopyFrom.AddPhrases.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.CopyFrom.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the Exceptions and/or Requirements and/or Informational Notes are copied";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ATP-Commitment -N", 4, TableAction.Click);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                Support.AreEqual("#/GP", FastDriver.DocumentRepository.Exceptions.FAGetValue());
                Support.AreEqual("JV1/JV1", FastDriver.DocumentRepository.Requirements.FAGetValue());
                Support.AreEqual("ATPZ/38", FastDriver.DocumentRepository.Information.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0018()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse 20,22:Create/Save Endorsement and Linking Endorsement to Policy ";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = " Add a Title Policy document ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");


                Reports.TestStep = "Add two Lender Policy documents";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "Short Form Commercial LP (6-2000)-N");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Lender Policy", "LenderPolicyforDP0009FV", "CA");

                Reports.TestStep = "Add a Endorsement document and Link to Policy";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Endorsement/Guarantee", "0 Template For DP0007c BAT", "CA");
                FastDriver.TitleSelection.WaitForScreenToLoad();
                FastDriver.TitleSelection.Select.FAClick();
                FastDriver.DocumentRepository.WaitForPageToLoad();
                Support.AreEqual("0 Template For DP0007c BAT", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(3, 4, TableAction.GetText).Message.ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0019_PH()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse19_Place_Holder: De-archive Documents";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0020()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse21: Create/Edit Endorsement";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = " Add a Title Policy document ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");


                Reports.TestStep = "Add Lender Policy documents";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "Short Form Commercial LP (6-2000)-N");

                Reports.TestStep = "Create/Edit Endorsement document";
                Thread.Sleep(10);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.CreateandEditDocument("Both", "Endorsement/Guarantee", "00000 Desc 2811GLXNNA ", "CA");

                Reports.TestStep = "Verify Document Preparation Edit screen is loaded and edit Buyer name";
                Thread.Sleep(100);
                FastDriver.DocumentPreparation.WaitForWindowToLoad();
                FastDriver.DocumentPreparation.BuyerNames.FASetText("Buyer1Firstname Buyer1LastnameBuyer1Firstname Buyer1Lastname");
                FastDriver.BottomFrame.Done();

                Playback.Wait(1000);
                Reports.TestStep = "Verify the Buyer name";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "00000 Desc 2811GLXNNA", 3, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparation.WaitForWindowToLoad();
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                FastDriver.DocumentPreparationMenu.WaitCreation(FastDriver.DocumentPreparationMenu.Expand1);
                FastDriver.DocumentPreparationMenu.Expand1.Click();
                Support.AreEqual("Buyer1Firstname Buyer1LastnameBuyer1Firstname Buyer1Lastname", FastDriver.DocumentPreparationMenu.BuyerNames.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0021_PH()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse22_Place_Holder: Linking Endorsement to Policy";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0022()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse23_24_25_26_27_28_29: 1.Create First Associated Document Package 2.Create Additional Document Package 3.Prevent Creation of New Document Package with Only One Document 4.Add a Document to an Existing Docum";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create mutiple documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Template FOr TFS101656");


                Reports.TestStep = "Select all the documents and click on Associate";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();

                Reports.TestStep = "Associated Documents Sequencing dialog.";
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.AssocDocSeqDlg.PackageIDName.FASetText("Associated package1");

                Reports.TestStep = "Remove a Document from Associated Documents Sequencing dialog.";
                FastDriver.AssocDocSeqDlg.DocumentTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.AssocDocSeqDlg.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                Support.AreNotEqual("Automation Test Title Report", FastDriver.AssocDocSeqDlg.DocumentTable.PerformTableAction(2, 2, TableAction.GetCell).Message.ToString());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select all the documents and click on Associate";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();

                Reports.TestStep = "Create Additional Document Package";
                FastDriver.DocPackageDlg.WaitForScreenToLoad();
                FastDriver.DocPackageDlg.CreateNewPackage.FAClick();
                Playback.Wait(4000);
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.AssocDocSeqDlg.PackageIDName.FASetText("Associated package2");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify Package is added";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                Playback.Wait(4000);
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual("True", FastDriver.DocumentRepository.AssPackageTable.FAGetText().Contains("Associated package1".ToString()).ToString());
                Support.AreEqual("True", FastDriver.DocumentRepository.AssPackageTable.FAGetText().Contains("Associated package2".ToString()).ToString());

                Reports.TestStep = "Prevent Creation of New Document Package with Only One Document";
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                Playback.Wait(4000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.DocumentRepository.Associate.FAClick();

                Reports.TestStep = "Verify the Create New Package button is disabled";
                FastDriver.DocPackageDlg.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DocPackageDlg.CreateNewPackage.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Add a Document to an Existing Document Package";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();

                FastDriver.DocPackageDlg.WaitForScreenToLoad();
                FastDriver.DocPackageDlg.SelectPackage1.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify the duplicated documents can be added";
                string duplicatemsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Duplicate documents will not be added to package.", duplicatemsg);


                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Preliminary Report (all states)");
                FastDriver.DocumentRepository.Associate.FAClick();
                Playback.Wait(4000);
                FastDriver.DocPackageDlg.WaitForScreenToLoad();
                FastDriver.DocPackageDlg.SelectPackage1.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(4000);

                Reports.TestStep = "Verify the Document is added to Existing Package";
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual("True", FastDriver.DocumentRepository.PackageDocumentsTable.FAGetText().Contains("Preliminary Report (all states)".ToString()).ToString());

                Reports.TestStep = "Modify Document Package";
                FastDriver.DocumentRepository.Modify.FAClick();
                Playback.Wait(4000);
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.AssocDocSeqDlg.PackageIDName.FASetText("Associated package_modified");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(4000);
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual("True", FastDriver.DocumentRepository.AssPackageTable.FAGetText().Contains("Associated package_modified".ToString()).ToString());

                Reports.TestStep = "Remove a Document Package from the Associate Docs Tab";
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                FastDriver.DocumentRepository.PackageRemove.FAClick();
                string removeassdoc = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Remove Associated Documents package?", removeassdoc);
                Playback.Wait(1000);
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreNotEqual("True", FastDriver.DocumentRepository.AssPackageTable.FAGetText().Contains("Associated package_modified".ToString()).ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0023()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse23_24_25_26_27_28_29_1: 1.Create First Associated Document Package 2.Create Additional Document Package 3.Prevent Creation of New Document Package with Only One Document 4.Add a Document to an Existing Doc";
                Reports.StatusUpdate("AlternateCourse23_24_25_26_27_28_29:faunctionality has covered in DPUC0009_BAT0022", true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0009_BAT0024_PH()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse30_Place_Holder: Search Results Filter";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            //Assert.AreEqual(true, Reports.TestResult, "TestSuccess:Refer Test Reports for Details");

        }

        [TestMethod]
        public void DPUC0009_BAT0025()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse31: Change Document Name – Images Only";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create a document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("INPUT")).FADoubleClick();

                Reports.TestStep = "Change the Name of the document";
                Playback.Wait(1000);
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.Name.FASetText("DPUC0009_BAT0025");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);

                Reports.TestStep = "Vrrify the newly updated document name";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string docname = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("DPUC0009_BAT0025", docname);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0026_PH()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse32_33_34_35_36_Place_Holder: 1.Request Recorded Document – Submit 2.Request Recorded Document – Status and Refresh 3.Request Recorded Document – Requesting Additional Doc Types 4.Request Recorded Document";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0009_BAT0027()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse37_38_39_40_41_42_43_44_45, DP8789,, DP7989: 1.Create First Real Time Mail Document Package 2.Create Additional Real Time Mail Document Package 3.Add a Document to an Existing RTM Package 4.Modify Real Time Mail Docu";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create mutiple documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Template FOr TFS101656");


                Reports.TestStep = "Select documets and Click on RTM button";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.RTMPackage.FAClick();

                Reports.TestStep = "Verify the fields under RTM Package Tab";
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                Support.AreEqual("ATP-Commitment -N", FastDriver.DocumentRepository.RTMPackageName.FAGetValue());

                Reports.TestStep = "Re Name the Package name";
                FastDriver.DocumentRepository.RTMPackageName.FASetText("RTM Package1");

                Reports.TestStep = "Remove a document from RTM package";
                FastDriver.DocumentRepository.RTMPackageNameSubTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.DocumentRepository.RTMPackageRemoveDocument.FAClick();
                Playback.Wait(1000);
                string removeRTMDoc = FastDriver.WebDriver.HandleDialogMessage();

                Support.AreEqual("Remove document from RTM package?", removeRTMDoc);
                Playback.Wait(4000);
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                Support.AreNotEqual("True", FastDriver.DocumentRepository.RTMPackageNameSubTable.FAGetText().Contains("Automation Test Title Report").ToString());

                Reports.TestStep = "Update Tab,No of Documents and Color printing";
                FastDriver.DocumentRepository.RTMPackageNameSubTable.PerformTableAction(2, 4, TableAction.SetText, "TAB1");
                FastDriver.DocumentRepository.RTMPackageNameSubTable.PerformTableAction(2, 5, TableAction.SetText, "3");
                FastDriver.DocumentRepository.RTMPackageNameSubTable.PerformTableAction(2, 6, TableAction.Click);

                Reports.TestStep = "Add RTM Addresses";
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                FastDriver.DocumentRepository.AddAddressees.FAClick();
                Playback.Wait(4000);
                FastDriver.AddRTMPackageAddressesDlg.ADDRTMPackageAddress();

                Reports.TestStep = "Select a Address from RTM Addresses";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.MailTo.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.SelectAddresses.FAClick();
                Playback.Wait(4000);
                FastDriver.RTMMailToAddresseesDlg.WaitForScreenToLoad();
                FastDriver.RTMMailToAddresseesDlg.RTMPackageAddressees.FAClick();
                FastDriver.RTMMailToAddresseesDlg.WaitForScreenToLoad();
                FastDriver.RTMMailToAddresseesDlg.tabAddressTM_SelectRTMAll.FAClick();
                FastDriver.RTMMailToAddresseesDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RTMMailToAddresseesDlg.RTMPackageAddres1.Selected.ToString(), "known issue");
                FastDriver.RTMMailToAddresseesDlg.RTMPackageAddres1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify Tab Name is missing for one or more documents";
                Playback.Wait(8000);
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.Packaging.FASelectItem("3 - Hole Booklet");
                FastDriver.BottomFrame.Save();
                Playback.Wait(1000);
                string tabname = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("True", tabname.Contains("Tab name is missing for one or more").ToString());
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.Packaging.FASelectItem("Standard");

                Reports.TestStep = "Select Return to address";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.ReturnTo.FAClick();
                FastDriver.RTM.ReturnToOfficeName.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the RTM Package ID";
                Playback.Wait(1000);
                FastDriver.RTM.WaitForScreenToLoad();
                string c = FastDriver.DocumentRepository.RTMPackageId.GetAttribute("title").ToString();
                Support.AreEqual("True", FastDriver.DocumentRepository.RTMPackageId.GetAttribute("title").ToString().Contains("Package ID:").ToString());

                Reports.TestStep = "Verify the  Up,Down and Remove Documents buttons are hidden";
                FastDriver.RTM.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.RTM.Up.IsVisible().ToString());
                Support.AreEqual("False", FastDriver.RTM.Down.IsVisible().ToString());
                Support.AreEqual("False", FastDriver.RTM.RemoveDocument.IsVisible().ToString());

                Reports.TestStep = "Verify the Package Name,Tab,Copies and Color fields are diabled";
                Support.AreEqual("False", FastDriver.DocumentRepository.RTMPackageName.IsVisible().ToString());
                Support.AreEqual("False", FastDriver.RTM.Tab.IsVisible().ToString());
                Support.AreEqual("False", FastDriver.RTM.Copies.IsVisible().ToString());
                Support.AreEqual("False", FastDriver.RTM.Color.IsVisible().ToString());

                Reports.TestStep = "Create Additional Real Time Mail Document Package";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                //FastDriver.DocumentRepository.SelectAllDocuments();
                //FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
                FastDriver.DocumentRepository.RTMPackage.FAClick();
                Playback.Wait(4000);
                FastDriver.DocPackageDlg.WaitForScreenToLoad();
                FastDriver.DocPackageDlg.CreateNewPackage.FAClick();
                Playback.Wait(4000);
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.PackageIDName2.FASetText("RTM Package2");
                FastDriver.BottomFrame.Save();
                Playback.Wait(1000);
                FastDriver.RTM.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RTM.RTMPackage2.IsVisible().ToString());

                Reports.TestStep = "Add a Document to an Existing RTM Package";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);

                FastDriver.DocumentRepository.RTMPackage.FAClick();
                FastDriver.DocPackageDlg.WaitForScreenToLoad();
                FastDriver.DocPackageDlg.SelectPackage1.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.RTM.WaitForScreenToLoad();
                string newaddeddoc = FastDriver.DocumentRepository.RTMPackageNameSubTable.FAGetText();
                Support.AreEqual("True", newaddeddoc.Contains("Automation Test Title Report").ToString());
                FastDriver.BottomFrame.Save();
                Thread.Sleep(5000);

                Reports.TestStep = "Modify Real Time Mail Document Package";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.RTMPackage2.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.Modify.JSClick();
                Playback.Wait(4000);
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.PackageIDName2.FASetText("Modify package name");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Save();
                Playback.Wait(4000);
                Playback.Wait(4000);
                FastDriver.RTM.WaitForScreenToLoad();
                Support.AreEqual("Modify package name", FastDriver.RTM.RTMPackage2.FAGetText());

                Reports.TestStep = "Remove a Real Time Mail Document Package";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.RTMPackage2.FAClick();
                FastDriver.RTM.Remove.FAClick();
                string removertm = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Remove RTM Package?", removertm);
                Playback.Wait(1000);
                FastDriver.RTM.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.RTM.RTMPackage2.IsVisible().ToString());

                Reports.TestStep = "Re-sequence Documents in a Package";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.Modify.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.DocumentRepository.RTMPackageNameSubTable.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.RTM.Down.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                Playback.Wait(10000);
                Support.AreEqual("ATP-Commitment -N", FastDriver.DocumentRepository.RTMPackageNameSubTable.PerformTableAction(3, 2, TableAction.GetText).Message.ToString());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Add effective date all title report document";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.DocumentsTab.FAClick();
                Playback.Wait(4000);
                AddEffectiveDatetoDocument("Automation Test Title Report");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.SearchResults.FAClick();
                Playback.Wait(4000);
                AddEffectiveDatetoDocument("ATP-Commitment -N");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.SearchResults.FAClick();
                Playback.Wait(4000);
                AddEffectiveDatetoDocument("Template FOr TFS101656");

                Reports.TestStep = "Deliver RTM Package";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.RTMPackagesTab.FAClick();
                Playback.Wait(4000);
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.DeliverMethod.FASelectItem("EMAIL");
                FastDriver.RTM.DeliverButton.FAClick();
                Playback.Wait(4000);
                FastDriver.EmailDlg.WaitForDialogToLoad();
                FastDriver.EmailDlg.ToText.FASetText("pattada@firstam.com");
                FastDriver.EmailDlg.Email.FAClick();


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0009_BAT0028()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse 49_50: View and Edit Delivery Instructions";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "View and Edit Delivery Instruction";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                Thread.Sleep(7000);
                FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.FAClick();
                Playback.Wait(10000);
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.EnterDeliveryInstructionsforSelectedRow("Business Source");

                Reports.TestStep = "Verify the Updated Delivery Instructions";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                Playback.Wait(1000);
                FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.FAClick();
                Playback.Wait(10000);
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.VerifyDeliveryInstructionsforSelectedRow("Business Source").ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0029_PH()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse19,EW13_,EW14Place_Holder: De-archive Documents";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_BAT0030_PH()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse51_52_53_54_55_56_57_Place_Holder: 1:Create Document – Web Service 2:Create ImageDoc – Web Service 3:Finalize Document – Web Service 4:Submit Document Request – Web Service 5:Un-finalize Document – Web Ser";


                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_BAT0031()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse58_59_60_61_62_63,DP13158,DP13159: 1:Change Document Type Only 2:Change Document Type with Standard Document Name 3:Change Doc Type with Free Form Text for Document Name 4:Remove and Restore Image or Document 5:Purge Imag";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);

                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Click on Split Image";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("input")).FAClick();

                Reports.TestStep = "Change Document Type with Standard Document Name";
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.ChangeDocumentType.FASetCheckbox(true);
                string docname = FastDriver.EditDocumentDlg.EditDocumentName.FAGetValue();
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.DocumentType.FASelectItem("Escrow: Misc");
                FastDriver.EditDocumentDlg.DocumentName.FASelectItem("Miscellaneous");


                Reports.TestStep = "System removes text from Edit Document Name field and disables";
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.EditDocumentDlg.EditDocumentName.FAGetValue());
                Support.AreEqual("False", FastDriver.EditDocumentDlg.EditDocumentName.Enabled.ToString());

                Reports.TestStep = "Verify Additional Information Field is populated with Document Name";
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                Support.AreEqual(docname, FastDriver.EditDocumentDlg.AdditionalInformaton.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Verify for Event Log is updation";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");

                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Doc Name Changed]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains(fileNumber).ToString());

                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Doc Type Changed]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains(fileNumber).ToString());


                Reports.TestStep = "Remove Image or Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                int rowcount = FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous INST-Estimated Settlement Statement PO-Invoice", 3, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Verify Document is Removed";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual((rowcount - 1).ToString(), FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count().ToString());

                Reports.TestStep = "Verify Document is Restored";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.DocumentRepository.Restore.FAClick();
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual(rowcount.ToString(), FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count().ToString());

                Reports.TestStep = "Publish an Image Document from Document Repository";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous INST-Estimated Settlement Statement PO-Invoice", 7, TableAction.GetText).Element.FAClick();
             
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[6].FindElement(By.TagName("input")).FADoubleClick();
                FastDriver.DocumentRepository.PublishButton.FAClick();
                Playback.Wait(1000);
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                FastDriver.PublishDocumentsDlg.SelectAll.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                 string backgroundtoindicateitispublished = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous INST-Estimated Settlement Statement PO-Invoice", 7, TableAction.GetText).Element.FindElement(By.TagName("input")).GetAttribute("style");
             
                Support.AreEqual("True", backgroundtoindicateitispublished.Contains("rgb").ToString());

                Reports.TestStep = "Purge 'Removed' File Documents ";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous INST-Estimated Settlement Statement PO-Invoice", 3, TableAction.Click);              
                FastDriver.DocumentRepository.Remove.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4,"Miscellaneous INST-Estimated Settlement Statement PO-Invoice",3, TableAction.Click);
                rowcount = FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count();
                FastDriver.DocumentRepository.Purge.FAClick();
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual((rowcount - 1).ToString(), FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count().ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_BAT0032()
        {

            try
            {
                Reports.TestDescription = "AlternateCourse 4_2 Split (Break-up) Images and verify the document count in ";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();

                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);


                Reports.TestStep = "Click on Split Image";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[1].FindElement(By.TagName("IMG")).FADoubleClick();
                FastDriver.SplitDocumentScreenDlg.WaitForDialogLoad();
                FastDriver.SplitDocumentScreenDlg.PageRange.FASetText("1");
                FastDriver.SplitDocumentScreenDlg.WaitForDialogLoad();
                FastDriver.SplitDocumentScreenDlg.Split.GiveFocus();
                FastDriver.SplitDocumentScreenDlg.Split.FAClick();
                FastDriver.SplitDocumentScreenDlg.WaitForDialogLoad();
                FastDriver.SplitDocumentScreenDlg.Save.GiveFocus();
                FastDriver.SplitDocumentScreenDlg.Save.FAClick();

                Reports.TestStep = "Enter Document Name Dlg";
                FastDriver.DocumentNameDlg.WaitForDialogLoad1();
                FastDriver.DocumentNameDlg.DocName.FASetText("Document name:pradeep");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the splitted document is added ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("Document name:pradeep", document);

                Reports.TestStep = "Prevent Creation of Split Image with Only One Page";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[1].FindElement(By.TagName("IMG")).FAClick();
                Support.AreEqual("Splitting not supported. Active document has less than 2 pages.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Deliver the document";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.DocumentRepository.Method.FASelectItem("EMAIL");
                FastDriver.DocumentRepository.Deliver.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);


                Reports.TestStep = "Verify for Event Log is updation";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");

                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[E-mail]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains(AutoConfig.DeliverEmailTo).ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #endregion

        #region REG

        [TestMethod]
        public void DPUC0009_EWC1()
        {
            try
            {
                Reports.TestDescription = "Error Message 4,22,6,7,9,10";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add Document.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 7, DocName: "0 Template For DP0007c BAT");

                Reports.TestStep = "Deliver the Endorsement Document";
                FastDriver.DocumentRepository.Deliver.FAClick();
                string EW_22 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Delivery of unfinalized Policies, Endorsements, and Guarantees is not allowed. Mark as Draft/Pro forma to Deliver.", EW_22);

                Reports.TestStep = "Finalize Docuent";
                FinalizeDocument();

                Reports.TestStep = "Remove the Finalized Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "0 Template For DP0007c BAT", 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();
                string EW_4 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("This document is in finalized status and cannot be removed.", EW_4);

                Reports.TestStep = "Add a Title Report Document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(1).ToDateString());
                FastDriver.DocumentRepository.btnInfoSave.FAClick();
                string EW_6 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(" Commitment Effective Date should be less or equal today's date", EW_6);

                Reports.TestStep = "Validate Invalid Phrase";
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.Exceptions.FASetText("invalidphraseew10");
                FastDriver.DocumentRepository.btnInfoSave.FAClick();
                string EW_10 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Invalid Phrase(s): /invalidphraseew10 ", EW_10);

                Reports.TestStep = "Add Lender Policy Document and remove Description";
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.InfoLenderDescription.FASetText(" ");
                FastDriver.DocumentRepository.Save.FAClick();
                string EW_9 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Description is missing", EW_9);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_EWC2()
        {
            try
            {
                Reports.TestDescription = "Error Message 23";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add Title Report and Lender policy document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.PWTREffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.PolicyNumber.FASetText("ew23");
                FastDriver.DocumentRepository.propertychk.FASetCheckbox(false);
                FastDriver.DocumentRepository.Save.FAClick();

                Reports.TestStep = "Finalize the document";
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.SearchResults.FAClick();
                Playback.Wait(10000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify the error warning message'Please associate the Policy with a Property.'";
                Playback.Wait(9000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                FastDriver.DocumentPreparationMenu.WaitCreation(FastDriver.DocumentPreparationMenu.Expand1);
                FastDriver.DocumentPreparationMenu.Expand1.Click();
                Playback.Wait(2000);
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%z");
                string er_23 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please associate the Policy with a Property to finalize.", er_23);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_EWC3()
        {
            try
            {
                Reports.TestDescription = "Error Message 26,29";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add Title Report and Lender policy document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");

                Reports.TestStep = "Try to Remove Title Report document";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 2, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();
                string ew_29 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("This Title Report is associated to a Policy and cannot be removed.", ew_29);

                Reports.TestStep = "Select all the documents and click on Associate";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();

                Reports.TestStep = "Associated Documents Sequencing dialog.";
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Remove the document from the document repository";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                FastDriver.DocumentRepository.Deliver.FAClick();
                string ew_26 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("True", ew_26.Contains("Package contains a Void or Removed document and cannot be printed, emailed, faxed, imaged or delivered to").ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_EWC4()
        {
            try
            {
                Reports.TestDescription = "Error Message 27, 34, 33,13383 Prevent Removal of Documents when when it's attached to a created, pending or issued wire disbursement";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan_DocsTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Edit the scanned document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("input")).FADoubleClick();
                Reports.TestStep = "Remove the document Name and save it";
                Playback.Wait(1000);
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.ChangeDocumentType.FASetCheckbox(true);
                FastDriver.EditDocumentDlg.DocumentType.FASelectItemByIndex(0);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(4000);
                string er_27 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual("Document Type and Document Name are required fields.", er_27);
                Playback.Wait(4000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Reports.TestStep = "Verify the ER_33 and ER_34";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("input")).FADoubleClick();
                Playback.Wait(1000);
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.ChangeDocumentType.FASetCheckbox(true);
                FastDriver.EditDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.EditDocumentDlg.DocumentName.FASelectItem("PO-Commission Instructions");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Edit disbursement symmary";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad(FastDriver.SelectWireInstructionsDlg.Instruction1);
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.ReceivingBankABANumber);
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Commission Instructions INST-Estimated Settlement Statement PO-Invoice",10,TableAction.GetCell).Element.FAClick();
                Playback.Wait(100);
                string er_33 = FastDriver.WebDriver.HandleDialogMessage(false,true);
                Playback.Wait(1000);
                Support.AreEqual("The following Document Name cannot be edited because it's attached to a created, pending or issued wire disbursement. Please remove from wire disbursement before editing Document Name.", er_33);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Remove.FAClick();
                string er_34 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("The following Document cannot be removed because it's attached to a created, pending or issued wire disbursement. Please remove from wire disbursement before deleting Document Name.", er_34);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_EWC5()
        {
            try
            {
                Reports.TestDescription = "Error Message 28 - Document Name is required.";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = " Add a Title Policy document ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("input")).FADoubleClick();
                Reports.TestStep = "Remove the document Name and save it";
                Playback.Wait(1000);
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.EditDocumentName.FASetText(" ");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);
                string er_28 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual("Document Name is required.", er_28);



                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG1()
        {
            try
            {
                Reports.TestDescription = "BR_DP4105, checks the Display Order of Documents";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add a Title Report Document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Add a Lender Policy Document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");


                Reports.TestStep = "Add a Image Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan_DocsTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Verify the Document Order";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string order1 = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                string order2 = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString();
                string order3 = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(3, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("Automation Test Title Report", order1);
                Support.AreEqual("    LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", order2);
                Support.AreEqual("INST-Estimated Settlement Statement PO-Invoice", order3);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG2_PH()
        {
            try
            {
                Reports.TestDescription = "BR DP7476, DP4107,DP13148,DP13149";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG3()
        {
            try
            {
                Reports.TestDescription = "BR DP11006, DP11007, DP11008, DP11009";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Verify the Policy w/o Title Reports Template is available";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                string temptype = FastDriver.AdHocDocuments.TemplateType.FAGetText();
                Support.AreEqual("True", temptype.Contains("Policy w/o Title Reports").ToString());

                Reports.TestStep = "Add a Policy w/o Title Reports  Document with out creating Title report document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 82, DocName: "Template created for 6.3 updates");

                Reports.TestStep = "verify the Policy w/o Title Report is created";
                string PolicyTitleReport = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("Template created for 6.3 updates", PolicyTitleReport);

                Reports.TestStep = "Verify the Info Tab and Effective Date is blank";
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                string effectivedate = FastDriver.DocumentRepository.PWTREffectiveDate.FAGetText();
                Support.AreEqual("", effectivedate);


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG4()
        {
            try
            {
                Reports.TestDescription = "BR DP11006, DP11007, DP11008, DP11009";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Add a Policy w/o Title Reports  Document with out creating Title report document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 82, DocName: "Template created for 6.3 updates");

                Reports.TestStep = "verify the Policy w/o Title Report is created";
                string PolicyTitleReport = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("Template created for 6.3 updates", PolicyTitleReport);

                Reports.TestStep = "Verify the Info Tab and Effective Date is blank";
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                string effectivedate = FastDriver.DocumentRepository.PWTREffectiveDate.FAGetText();
                Support.AreEqual("", effectivedate);

                Reports.TestStep = "Verify the same field elements for Policy w/o Title Reports as for a Lender Policy.";
                Support.AreEqual("True", FastDriver.DocumentInfo.LenderOwnerDescription.Exists().ToString());
                Support.AreEqual("True", FastDriver.DocumentInfo.Buyeramount.Exists().ToString());
                Support.AreEqual("True", FastDriver.DocumentInfo.Selleramount.Exists().ToString());
                Support.AreEqual("True", FastDriver.DocumentInfo.PolicyNum.Exists().ToString());
                Support.AreEqual("True", FastDriver.DocumentInfo.TitlePolicyInfoSave.Exists().ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG5()
        {
            try
            {
                Reports.TestDescription = "DP7558 Adding Phrases into Documents";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add a Title Report Document and click on Edit button";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                FastDriver.DocumentRepository.Edit.FAClick();


                Reports.TestStep = "Enter directly Phrase names in the Phrase Name field and click on Done";
                PhraseSelectionDlg();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(1000);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify the Pharse is added";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Support.AreEqual("JVE/JV01", FastDriver.DocumentPreparationMenu.PharseJVE.FAGetText());

                Reports.TestStep = "Add other resion phrase codeds";
                PhraseSelectionDlg();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(1000);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("*RA/1");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify the Pharse is added";
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Support.AreEqual("*RA/1", FastDriver.DocumentPreparationMenu.PharseJVE.FAGetText());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG6()
        {

            try
            {
                Reports.TestDescription = "BR DP4061, DP4063 enter the Buyer and/or Seller Premium Amount when editing the Policy information.";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Add a Title Report document and then add Lender Policy document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");

                Reports.TestStep = "Verify the Liability Amount";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Support.AreEqual("$5,000.00", FastDriver.DocumentInfo.LiabilityAmount.FAGetText());

                Reports.TestStep = "Enter Buyer and Seller Amount";
                FastDriver.DocumentInfo.Buyeramount.FASetText("100");
                FastDriver.DocumentInfo.Selleramount.FASetText("300");
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Navigate and update the New loan liability amount";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("200");

                Reports.TestStep = "Verify the Liability amount, Seller and Buyer Amount";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH ", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Support.AreEqual("$200.00", FastDriver.DocumentRepository.LiabilityAmt.FAGetText());
                Support.AreEqual("0.00", FastDriver.DocumentInfo.Buyeramount.FAGetValue());
                Support.AreEqual("0.00", FastDriver.DocumentInfo.Selleramount.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG7()
        {
            try
            {

                Reports.TestDescription = "BR DP4068, DP4070. DP13176: to search for a starter file from which an inheritable document ";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                string source = fileNumber;
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add Title Report and Lender policy document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.Exceptions.FASetText("CCCC/ABC1");
                FastDriver.DocumentRepository.btnInfoSave.FAClick();
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");

                Reports.TestStep = "Create One more File and Copy all the document form the already created";
                CreateBasicFile();
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(source);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                Playback.Wait(1000);
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Navigate to Document Repository screen and verify the document are added";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
               
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("Automation Test Title Report", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.GetText).Message);

                Reports.TestStep = "Verify the exceptions/requirements from inheritable documents.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForWindowToLoad();
                Support.AreEqual("CCCC/ABC1", FastDriver.DocumentInfo.Exceptions.FAGetText());


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_REG8()
        {
            try
            {

                Reports.TestDescription = " DP9855, DP9856 rename copied image and split it";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Verify the scanned document is available in document repository screen ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("INST-Estimated Settlement Statement PO-Invoice", document);

                Reports.TestStep = "Create One more File and Copy all the document form the already created";
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                Reports.TestStep = "Create File using web service.";
                string secondfile = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(secondfile);
                FileNo = FileService.GetFilesByFileNum(secondfile.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;


                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(fileNumber);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                Playback.Wait(1000);
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Navigate to Document Repository screen and verify the document are added";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "INST-Estimated Settlement Statement PO-Invoice", 4, TableAction.Click);

                Reports.TestStep = "Rename the Document";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("INPUT")).FADoubleClick();

                Playback.Wait(1000);
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.Name.FASetText("Document_Reg08");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);

                Reports.TestStep = "Verify document name has changed";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("Document_Reg08", "Document_Reg08");


                Reports.TestStep = "Click on Split Image";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[1].FindElement(By.TagName("IMG")).FADoubleClick();
                Playback.Wait(1000);
                FastDriver.SplitDocumentScreenDlg.WaitForDialogLoad();
                FastDriver.SplitDocumentScreenDlg.PageRange.FASetText("1");
                FastDriver.SplitDocumentScreenDlg.WaitForDialogLoad();
                FastDriver.SplitDocumentScreenDlg.Split.GiveFocus();
                FastDriver.SplitDocumentScreenDlg.Split.FAClick();
                FastDriver.SplitDocumentScreenDlg.WaitForDialogLoad();
                FastDriver.SplitDocumentScreenDlg.Save.GiveFocus();
                FastDriver.SplitDocumentScreenDlg.Save.FAClick();

                Reports.TestStep = "Enter Document Name Dlg";
                FastDriver.DocumentNameDlg.WaitForDialogLoad1();
                FastDriver.DocumentNameDlg.DocName.FASetText("Document name:pradeep");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the splitted document is added ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("Document name:pradeep", document);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_REG9()
        {

            try
            {
                Reports.TestDescription = " DP9771:Documents/Images with 'SEC-' prefix shall be accessible only to users who have 'View Secured Documents Activity' rights";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button. and add a Secure Document";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Exchange : Secured", "SEC-CIP", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Login to the ADM as Super uaser and remove the activity rights for Fastqa06 user";
                ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                List<IWebElement> roles = FastDriver.BusinessUnitRoleAssignment.RemoveAssociatedRolesforfastqa06();

                Reports.TestStep = "Login as Fastqa06 user";
                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                Reports.TestStep = "Serach file number which fastqa07 user already created";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Go to document repository screen and select the document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "SEC-CIP PO-Invoice", 3, TableAction.Click);

                Reports.TestStep = "Verify the wthether fastqa06 user able to deliver document";
                Support.AreEqual("False", FastDriver.DocumentRepository.Deliver.IsEnabled().ToString());

                Reports.TestStep = "Reset the roles";
                if (roles.Count > 0)
                {
                    ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                    FastDriver.BusinessUnitRoleAssignment.ResetRolesforfastqa06(roles);
                }
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG10()
        {
            try
            {
                Reports.TestDescription = "BR DP7557 Creating a template in DOCREP region with filter criteria as all";

                #region precondition

                Reports.TestStep = "Log into FAST application.";
                ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region
                //need to create a template again to remove dependency with BAT01
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DPUC0009" + "reg10" + Support.RandomString("ANANA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);

                Reports.TestStep = "Add Phrases to the Template";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();

                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();


                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformationByDefaultAlltheFields();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion
                #endregion

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Verify the Template is displaying which was created in ADM";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                Support.AreEqual("True", FastDriver.DocumentRepository.SearchTable.Text.ToString().Contains(templateName).ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG11()
        {
            try
            {

                Reports.TestDescription = "BR DP7557";

                Reports.StatusUpdate("Functionality has overed in DPUC0009_REG10 ", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG12()
        {
            try
            {

                Reports.TestDescription = " BR DP8779, DP8784, DP8785, DP8781";

                Reports.StatusUpdate("Functionality has overed in DPUC0009_BAT0027 ", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG13()
        {
            try
            {
                Reports.TestDescription = "BR DP8786, DP8787 Automatically remove file party or office addressee ,Automatically remove buyer or seller addressee ";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create mutiple documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Template FOr TFS101656");
                #endregion

                Reports.TestStep = "Select documets and Click on RTM button";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.RTMPackage.FAClick();

                Reports.TestStep = "Verify the fields under RTM Package Tab";
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                Support.AreEqual("ATP-Commitment -N", FastDriver.DocumentRepository.RTMPackageName.FAGetValue());

                Reports.TestStep = "Add Escrow Office and Lender address to RTM Mail To AddresseesDlg ";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.MailTo.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.SelectAddresses.FAClick();
                Playback.Wait(4000);
                FastDriver.RTMMailToAddresseesDlg.WaitForScreenToLoad();
                FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.RTMMailToAddresseesDlg.FileOffices.FAClick();
                FastDriver.RTMMailToAddresseesDlg.WaitForScreenToLoad();
                FastDriver.RTMMailToAddresseesDlg.AddressOwningOfficeSelection.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);

                Reports.TestStep = "Verify the address are added to Mail To Tab";
                FastDriver.RTM.WaitForScreenToLoad();
                int Rowcount = FastDriver.RTM.MailToTable.FindElements(By.TagName("tr")).Count();
                Support.AreEqual("True", (Rowcount>1).ToString());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to New loan screen and change the lender address";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(1000);

                Reports.TestStep = "Navigate to File Homepage screen and remove escrow services";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SwitchToContentFrame();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the Address are removed from RTM-Mail To";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.RTMPackagesTab.FAClick();

                Reports.TestStep = "Add Escrow Office and Lender address to RTM Mail To AddresseesDlg ";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.MailTo.FAClick();
                Playback.Wait(1000);
                FastDriver.RTM.WaitForScreenToLoad();
                int visible_rows = FastDriver.RTM.MailToTable.FindElements(By.TagName("tr")).Count;
                Support.AreEqual("True", (visible_rows < 1).ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0009_REG14()
        {
            try
            {
                Reports.TestDescription = "Precondition, DP11012, DP11013 Display templates filtered for All under Geographic Filter and Display document templates with region filter matching the file";

                #region precondition

                Reports.TestStep = "Log into FAST application.";
                ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region
                //need to create a template again to remove dependency with BAT01
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "DP9" + "reg14" + Support.RandomString("ANANATEST");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);
                string tempdes = "Template for " + templateName;
                AddPhraseToTemplate();

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();

                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();

                FastDriver.TemplateFilterSelectionDlg.AddStateSelection();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformationByDefaultAlltheFields();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion
                #endregion

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Verify the Template is displaying based on Geographic Filter criteria";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                Support.AreEqual("True", FastDriver.DocumentRepository.SearchTable.Text.ToString().Contains(tempdes).ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG15()
        {
            try
            {
                Reports.TestDescription = "BR DP4052 Validate in File side that only Active with Phrase template appears in DOC Rep";

                #region precondition

                Reports.TestStep = "Log into FAST application.";
                ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region
                //need to create a template again to remove dependency with BAT01
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "Dp9" + "rg15" + Support.RandomString("ANANATEST");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(templateName, "Template for " + templateName, "Comments for Template - " + templateName, underConstruction: false);


                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Add filters to the template.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();

                FastDriver.TemplateFilterSelectionDlg.AddStateSelection();
                FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformationByDefaultAlltheFields();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion
                #endregion

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Verify the Template is not displaying in Doc Rep which not having Phrase in it";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                Support.AreEqual("False", FastDriver.DocumentRepository.SearchTable.Text.ToString().Contains(templateName).ToString());

                #endregion

                #region precondition

                Reports.TestStep = "Log into FAST application.";
                ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();


                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "DeActviate the Existing Template";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Escrow Instruction");

                Reports.TestStep = "Click on Find Now button and select the record with temp name.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.SearchResultsTable(2, "Template for " + templateName, 2, TableAction.Click);

                Reports.TestStep = "De Active the Template";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.InformationInactive.FAClick();
                AddPhraseToTemplate();
                FastDriver.BottomFrame.Save();

                #endregion

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Verify the In Active Template is  displaying in Doc Rep ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                Support.AreEqual("False", FastDriver.DocumentRepository.SearchTable.Text.ToString().Contains(templateName).ToString());

                #endregion

                #region precondition

                Reports.TestStep = "Log into FAST application.";
                ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();


                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "DeActviate the Existing Template";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem("InActive");
                Reports.TestStep = "Click on Find Now button and select the record with temp name.";
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.SearchResultsTable(2, "Template for " + templateName, 2, TableAction.Click);

                Reports.TestStep = "Active the Template";
                FastDriver.TemplateMaintenanceSummary.Edit.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.InformationActive.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion


                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Verify the  Active Template is  displaying in Doc Rep ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                Support.AreEqual("True", FastDriver.DocumentRepository.SearchTable.Text.ToString().Contains(templateName).ToString());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG16()
        {
            try
            {

                Reports.TestDescription = "BR DP4052 Uncheck underconstruction checkbox in the template and add phrase to it";

                Reports.StatusUpdate("Functionality has overed in DPUC0009_REG15 ", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG17()
        {
            try
            {
                Reports.TestDescription = "BR DP4092 Verify the updated template are pulled in Doc Repo";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Verify the Ad-Hoc Document template list contains Regional and Corporate Documents are displaying";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem("Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("Title Reports");
                FastDriver.AdHocDocuments.FindNow.FAClick();

                Reports.TestStep = "Verify Document is added";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                bool exist = FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Source", "R", "Source", TableAction.Click).Element.Exists();
                Support.AreEqual("True", exist.ToString());
                exist = FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Source", "C", "Source", TableAction.Click).Element.Exists();

                Support.AreEqual("True", exist.ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG18()
        {
            try
            {
                Reports.TestDescription = "BR DP9055, DP4111 Verify FAST Search results In Doc Rep, Expected Failure if the Fast search is not complete";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();

                #region region Basic File Creation
                IISLOGIN();
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.CreateStandardFile();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                fileNumber = FastDriver.FileHomepage.FileNum.FAGetValue().ToString();
                #endregion

                #region GUI Intreaction


                Reports.TestStep = "Verify for Event Log is updation";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();

                Reports.TestStep = "Validate [Fast Search Initiated] event";
                Support.AreEqual("[Fast Search Initiated]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fast Search Initiated]", 1, TableAction.GetText).Message.Clean(), "Event");
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Playback.Wait(10000);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
               
                Reports.TestStep = "Validate [FS Request Completed] event";
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Support.AreEqual("[FS Request Completed]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 1, TableAction.GetText).Message.Clean(), "Event");



                Reports.TestStep = "Verify the Search results and Serch Type are displaying Doc Rep";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Search Result", "Type", TableAction.Click).Element.Exists().ToString();
                Support.AreEqual("True", document);

                Reports.TestStep = "Delivery of Non-Sys Gen Docs ";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.Method.FASelectItem("EMAIL");
                FastDriver.DocumentRepository.Deliver.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Reports.TestStep = "Select 'All' from Event Category and Verify the Email is Delivered";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Playback.Wait(1000);
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 5, TableAction.GetText).Message.Clean().Contains(fileNumber).ToString(), "Event");


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG19()
        {
            try
            {
                Reports.TestDescription = "BR DP11014_DP9077_DP9078: Login to QA Automation and add docs of QA sandpoint";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Create a Title Report Template Type Document which is from QA SANDPOINTE REGION";
                FastDriver.AdHocDocuments.AddDocument("QA SANDPOINTE REGION", "Title Reports", "COMMITMENT", "CA");

                Reports.TestStep = "Verify Document is added";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Title Reports", "Name", TableAction.GetText).Message.ToString();
                Support.AreEqual("COMMITMENT", document);

                Reports.TestStep = "Add a QA SANDPOINTE REGION region leder policy document";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.AddDocument("QA SANDPOINTE REGION", "Lender Policy", "Lender Policy", "CA");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Name", TableAction.Click).Element.Text;
                Support.AreEqual("    Lender Policy", document);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG20()
        {

            try
            {
                Reports.TestDescription = "BR DP9080, DP9087,9088 Copying Exception/Requirement/IN Phrases from files other Region and Requirements for entering phrase codes on Title Report Informati";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add a Document.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Click on Info Tab and enter the Exceptions and/or Requirements and/or Informational Notes details from QA SANDPOINTE REGION";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.InfoDescription.FASetText("Automation Test Title Report");
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.Exceptions.FASetText("#/GP");
                FastDriver.DocumentRepository.InfoExceptions.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.DocumentRepository.Requirements.FASetText("FADM/FADM");
                FastDriver.DocumentRepository.InfoRequirement.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.DocumentRepository.Information.FASetText("ATPZ/38");
                FastDriver.DocumentRepository.InfoSourceRegion.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.DocumentRepository.btnInfoSave.FAClick();

                Reports.TestStep = "Verify the Execeptions, Reqirements and Information Notes";
                Support.AreEqual("#/GP", FastDriver.DocumentRepository.Exceptions.FAGetValue());
                Support.AreEqual("FADM/FADM", FastDriver.DocumentRepository.Requirements.FAGetValue());
                Support.AreEqual("ATPZ/38", FastDriver.DocumentRepository.Information.FAGetValue());


                Reports.TestStep = "Validate the phrase and the Source as QA Automation";
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.InfoExceptions.FASelectItem("QA Automation Region - CD");
                Playback.Wait(1000);
                string errormsg = alert();
                Support.AreEqual("True", errormsg.Contains("You may enter phrase codes from one region only").ToString());
                Support.AreEqual("True", errormsg.Contains("Do you want to change all codes previously entered to the new Source Region?").ToString());
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.btnInfoSave.FAClick();
                string invalidphrase = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Invalid Phrase(s): #/GP ", invalidphrase);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG21()
        {

            try
            {
                Reports.TestDescription = "BR DP9079, DP9085, DP9086Copying Exception/Requirement/IN Phrases from files other Region,Inserting Phrase Codes on Disabled Title Report Information";

                #region source file

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                string soorcefile = fileNumber;
                #endregion
                Reports.TestStep = "Add a Document.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Edit document and add other than login region phrase";
                FastDriver.DocumentRepository.Edit.FAClick();
                PhraseSelectionDlg();
                FastDriver.WebDriver.HandleDialogMessage();


                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Source.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("LK02/TST1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                #endregion

                #region region Basic File Creation
                CreateBasicFile();
               
                #endregion
                #region target file
                Reports.TestStep = "Add a Document.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Edit document and add other than login region phrase";
                FastDriver.DocumentRepository.Edit.FAClick();
               PhraseSelectionDlg();
                FastDriver.WebDriver.HandleDialogMessage();
                

                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Source.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("LK02/TST1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Edit document and add other than login region phrase";
                PhraseSelectionDlg();
                FastDriver.WebDriver.HandleDialogMessage();


                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Source.FASelectItem("QA-Canada");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("HEEL/DFSD");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Title Report Document and Click on Info Tab.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Validate that the exception phrase is disabled";
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                Support.AreEqual("False", FastDriver.DocumentRepository.Exceptions.IsEnabled().ToString());

                Reports.TestStep = "Validate that the Exception source selection is disabled";
                FastDriver.DocumentInfo.WaitForWindowToLoad();
                Support.AreEqual("False", FastDriver.DocumentInfo.Exceptions.IsEnabled().ToString());
                Support.AreEqual("Multiple Regions", FastDriver.DocumentInfo.MultipleSource.FAGetText());
                                

                Reports.TestStep = "Click on Copy From button.";
                FastDriver.DocumentInfo.WaitForWindowToLoad();
                FastDriver.DocumentInfo.CopyFrom.FAClick();

                Reports.TestStep = "Search for Sorce file";
                    FastDriver.CopyFrom.WaitForScreenToLoad();
                FastDriver.CopyFrom.FileNumber.FASetText(soorcefile);
                FastDriver.CopyFrom.Refresh.FAClick();
                Playback.Wait(1000);
                FastDriver.CopyFrom.WaitForScreenToLoad();
                FastDriver.CopyFrom.CheckBox1.FASetCheckbox(true);
                FastDriver.CopyFrom.AddPhrases.FAClick();

                Reports.TestStep = "Validate that the phrase is copied";
               Support.AreEqual("Phrases From Automation Test Title Report are successfully Processed.", FastDriver.WebDriver.HandleDialogMessage());
               FastDriver.BottomFrame.Done();

               Reports.TestStep = "Validate the status of Title policy is in created state";
               FastDriver.DocumentRepository.Open();
               FastDriver.DocumentRepository.WaitForScreenToLoad();
               FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
             Support.AreEqual("Created",  FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 9, TableAction.GetText).Message.ToString());
               FastDriver.DocumentRepository.Info.FAClick();

               Reports.TestStep = "Validate that the exception phrase is disabled";
               FastDriver.DocumentRepository.WaitForInfoTabToLoad();
               Support.AreEqual("False", FastDriver.DocumentRepository.Exceptions.IsEnabled().ToString());

               Reports.TestStep = "Validate that the phrase is copied from the file";
               Support.AreEqual("HEEL/DFSD,LK02/TST1,LK02/TST1", FastDriver.DocumentRepository.Exceptions.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void DPUC0009_REG22()
        {
            try
            {
                Reports.TestDescription = "BR DP8790  Verify Special characters";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create mutiple documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Template FOr TFS101656");


                Reports.TestStep = "Select documets and Click on RTM button";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.RTMPackage.FAClick();

                Reports.TestStep = "Verify the fields under RTM Package Tab";
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                Support.AreEqual("ATP-Commitment -N", FastDriver.DocumentRepository.RTMPackageName.FAGetValue());

                Reports.TestStep = "Verify the Package name with Special Character";
                FastDriver.DocumentRepository.RTMPackageName.FASetText("!");
                string PackageName = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("This field may only contain the following characters: 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", PackageName);

                Reports.TestStep = "Verify the Package Tab with Special Character";
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                FastDriver.DocumentRepository.RTMPackageName.FASetText("Reg23");
                FastDriver.DocumentRepository.RTMPackageNameSubTable.PerformTableAction(2, 4, TableAction.SetText, "!");
                string Tab = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("This field may only contain the following characters: 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", Tab);

                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                Reports.TestStep = "Select Return to address";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.ReturnTo.FAClick();
                FastDriver.RTM.ReturnToAttention.FASetText("!");
                string Attention = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("This field may only contain the following characters: 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", Attention);

                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.ReturnToReference.FASetText("!");
                string Reference = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("This field may only contain the following characters: 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", Reference);


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

          [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void DPUC0009_REG23()
        {
            try
            {
                Reports.TestDescription = "BR DP8792, DP8793  Prevent delivery of package with unedited policy and Restrict RTM Package Documents to .PDF-Convertible File Formats";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create Title Report Document document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.btnInfoSave.FAClick();

                Reports.TestStep = "Add Lender Policy documents";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "Short Form Commercial LP (6-2000)-N");


                Reports.TestStep = "Select all documets and Click on RTM button";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.RTMPackage.FAClick();


                Reports.TestStep = "Add RTM Addresses";
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                FastDriver.DocumentRepository.AddAddressees.FAClick();
                Playback.Wait(4000);
                FastDriver.AddRTMPackageAddressesDlg.ADDRTMPackageAddress();

                Reports.TestStep = "Select a Address from RTM Addresses";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.MailTo.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.SelectAddresses.FAClick();
                Playback.Wait(4000);
                FastDriver.RTMMailToAddresseesDlg.WaitForScreenToLoad();
                FastDriver.RTMMailToAddresseesDlg.RTMPackageAddressees.FAClick();
                FastDriver.RTMMailToAddresseesDlg.WaitForScreenToLoad();
                FastDriver.RTMMailToAddresseesDlg.RTMPackageAddres1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.Packaging.FASelectItem("Standard");

                Reports.TestStep = "Select Return to address";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.ReturnTo.FAClick();
                FastDriver.RTM.ReturnToOfficeName.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();

                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.DeliverMethod.FASelectItem("EMAIL");
                FastDriver.RTM.DeliverButton.FAClick();
                Playback.Wait(4000);

                string preventdelivery = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("The Document Short Form Commercial LP (6-2000)-N Must be edited before it may be delivered.", preventdelivery);

                Reports.TestStep = "Add a .jpg document to Document Reository screen";
                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the System is Restrictring .jpg file to RTM Package";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous test", 4, TableAction.Click);
                FastDriver.DocumentRepository.RTMPackage.FAClick();
                string JPGfiletoRTM = FastDriver.WebDriver.HandleDialogMessage();

                Support.AreEqual("The following file(s) cannot be added to an RTM Package: Miscellaneous test", JPGfiletoRTM);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void DPUC0009_REG24()
        {

            try
            {
                Reports.TestDescription = "BR DP8796 Allow identical document names in a package";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add two documents with same name";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Select documets and Click on RTM button";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.RTMPackage.FAClick();
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                FastDriver.BottomFrame.Save();

                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.RTMPackage.FAClick();
                FastDriver.DocPackageDlg.WaitForScreenToLoad();
                FastDriver.DocPackageDlg.SelectPackage1.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the identical document names in a package";
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();
                string identicaldocument1 = FastDriver.DocumentRepository.RTMPackageNameSubTable.PerformTableAction(2, 1, TableAction.GetText).Message.ToString();
                string identicaldocument2 = FastDriver.DocumentRepository.RTMPackageNameSubTable.PerformTableAction(3, 1, TableAction.GetText).Message.ToString();
                Support.AreEqual("Automation Test Title Report", identicaldocument1);
                Support.AreEqual("Automation Test Title Report", identicaldocument1);


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG25()
        {

            try
            {
                Reports.TestDescription = "BR DP6598, DP4056, DP4104 Multiple Document Delivery";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create mutiple documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                AddEffectiveDatetoDocument("Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");
                AddEffectiveDatetoDocument("ATP-Commitment -N");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Template FOr TFS101656");

                Reports.TestStep = "Select two documents and deliver it";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.SelectDeliveryMethod("Email");
                FastDriver.DocumentRepository.ClickDeliver();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);

                Reports.TestStep = "Verify for Event Log is updation";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");

                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[E-mail]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains(AutoConfig.DeliverEmailTo).ToString());

                string date = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[E-mail]", "Start Date/Time", TableAction.GetText).Message.ToString();

                string c1 = DateTime.Now.ToString("MM/dd/yyyy");
                Support.AreEqual("True", date.Contains(DateTime.Now.ToString("MM/dd/yyyy")).ToString());

                Reports.TestStep = "Print the .PDF file and verify the PDF Preview";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, 4, TableAction.Click);
                FastDriver.DocumentRepository.SelectDeliveryMethod("PRINT");
                FastDriver.DocumentRepository.ClickDeliver();

                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\temp.PDF";

                SavePDFFile(tempPdfFile);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG26()
        {
            try
            {

                Reports.TestDescription = "DP7964 Printing of PDF Documents (Imagedoc) and .doc document.";

                Reports.StatusUpdate("Functionality has overed in DPUC0009_REG25", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG27()
        {

            try
            {
                Reports.TestDescription = "Test Case No: 37.8 Paired with Test_Case_No_53_5";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Add a Title Report,Lender Policy and Owner Policy Document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Owner Plolicy", "ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", "CA");

                Reports.TestStep = "Remove Lender and Owner Policy Documents";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Remove Title Report";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Restore Lender Policy";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.DocumentRepository.Restore.FAClick();
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("A Title Report must be available to link to the Lender or Owner policy.  Please Create or Restore a Title Report", message);

                Reports.TestStep = "Restore Owner Policy";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.DocumentRepository.Restore.FAClick();
                message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("A Title Report must be available to link to the Lender or Owner policy.  Please Create or Restore a Title Report", message);

                Reports.TestStep = "Restore Title, Lender and Owner policy and verify it";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.DocumentRepository.Restore.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.DocumentRepository.Restore.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.DocumentRepository.Restore.FAClick();

                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string titlereport = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("Automation Test Title Report", titlereport);
                string lenderpolicy = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("    LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", lenderpolicy);
                string ownerpolicy = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(3, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("    ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", ownerpolicy);



                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_REG28()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse3, BR DP7491: Add Images to Document Repository";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Verify Change Document Type check box is disabled";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("input")).FAClick();

                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                string documenttype = FastDriver.EditDocumentDlg.DocumentType.Enabled.ToString();
                Support.AreEqual("False", documenttype);
                string documentname = FastDriver.EditDocumentDlg.DocumentName.Enabled.ToString();
                Support.AreEqual("False", documentname);

                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG29()
        {
            try
            {

                Reports.TestDescription = "Precondition for BR DP13884, DP13885, DP13886, DP14441";


                #region region Basic File Creation
                IISLOGIN();
                CreateFileInSandPointRegion();
                #endregion


                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Verify QC @ Closing tab is enabled.";
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case BAT0001C. 
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);


                Reports.TestStep = "Navigate to CD screen.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Press Delivery Options tab.";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();

                Reports.TestStep = "Select Delivery Method Imagedoc.";
                FastDriver.ClosingDisclosure.Combined.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Imagedoc");

                Reports.TestStep = "Press Delivery button.";
                FastDriver.ClosingDisclosure.DeliveryButton.FAMoveToElement();
                FastDriver.ClosingDisclosure.DeliveryButton.Click();

                Reports.TestStep = "Perform Imagedoc delivery.";
                FastDriver.ImageDocDlg.Deliver();
                Playback.Wait(1000);

                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.WaitCreation(FastDriver.DocumentRepository.DocumentsTab);
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                Playback.Wait(1000);
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.WaitCreation(FastDriver.DocumentRepository.DocumentsTab);
                int i;
                for (i = 0; 10 >= i; i++)
                {
                    if (FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count() < 3)
                    {
                        Thread.Sleep(9000);
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                        FastDriver.DocumentRepository.SwitchToContentFrame();
                        FastDriver.DocumentRepository.WaitCreation(FastDriver.DocumentRepository.DocumentsTab);
                        FastDriver.DocumentRepository.DocumentsTab.FAClick();
                        FastDriver.DocumentRepository.SwitchToContentFrame();
                        FastDriver.DocumentRepository.WaitCreation(FastDriver.DocumentRepository.DocumentsTab);
                    }
                    else
                    {
                        break;
                    }
                }

                Support.AreEqual("CD - Combined - Draft", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString());
                Support.AreEqual("FABS-QCatClosing", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG30()
        {

            Reports.TestDescription = "BR DP13884, DP13885, DP13886, DP14441";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_REG29", true);
        }

        [TestMethod]
        public void DPUC0009_REG31_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP13886, DP14441 Manually HUD document in the Proview";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG32()
        {

            try
            {
                Reports.TestDescription = "BR DP14437, DP14439.DP14440 Publish Documents to Business Source for Delivery Methods and Publish Documents to Loan Investors";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create a documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                AddEffectiveDatetoDocument("Automation Test Title Report");
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.SearchResults.FAClick();
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);


                Reports.TestStep = "Deliver the document using print method";
                FastDriver.DocumentRepository.SelectDeliveryMethod("PRINT");
                FastDriver.DocumentRepository.ClickDeliver();

                Reports.TestStep = "'Publish' option in the delivery dialog";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.PublishDocument.FASetCheckbox(true);
                FastDriver.PrintDlg.Print.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Verify Business Source role in Publish Documents Dialog";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[2].FindElements(By.TagName("TD"))[6].FindElement(By.TagName("input")).FADoubleClick();


                Playback.Wait(1000);
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PublishDocumentsDlg.Select2.FAGetAttribute("checked").ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);


                Reports.TestStep = "Publish Documents to Loan Investors ";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanInvestors.FAClick();
                FastDriver.LoanInvestors.WaitForScreenToLoad();
                FastDriver.LoanInvestors.Add.FAClick();
                FastDriver.LoanInvestorsDlg.WaitForScreenToLoad();
                FastDriver.LoanInvestorsDlg.LoanInvestorsTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LoanInvestors.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Verify Loan Investor role in Publish Documents Dialog and also verif the Bus. Sorce also selected";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[2].FindElements(By.TagName("TD"))[6].FindElement(By.TagName("input")).FADoubleClick();
                Playback.Wait(1000);
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PublishDocumentsDlg.Select9.FAGetAttribute("checked").ToString());
                Support.AreEqual("true", FastDriver.PublishDocumentsDlg.Select2.FAGetAttribute("checked").ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG33()
        {

            Reports.TestDescription = "BR DP14440 Keep Bus. Source Selected When Selecting Loan Investor  ";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_REG32", true);
        }

        [TestMethod]
        public void DPUC0009_REG33A()
        {

            Reports.TestDescription = "BR DP13884, DP13885, DP13886, DP14441";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_REG29", true);
        }

        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void DPUC0009_REG35()
        {

            try
            {
                Reports.TestDescription = "BR DP14442, DP14443, DP14591 Allow Loan Investor & LI Contact Selection for Any Image,Deselect Loan Investor & LI Contact if Loan Investor Removed  and Deselect Loan Investor & LI Contact if Loan Investor Removed ";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create a documents";
                UploadPDFDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                Playback.Wait(500);

                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.PerformDelivery("Imagedoc");
                Reports.TestStep = "Click on Imagedoc button.";

                FastDriver.ImageDocDlg.SwitchToDialogContentFrame();
                FastDriver.ImageDocDlg.WaitCreation(FastDriver.ImageDocDlg.ImageDoc);
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                Reports.TestStep = "Select or Deselect the Loan Investor File Role or Loan Investor Contact File Role manually";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                Playback.Wait(1000);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[6].FindElement(By.TagName("input")).FAClick();


                Playback.Wait(1000);
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                FastDriver.PublishDocumentsDlg.Select10.FASetCheckbox(true);
                FastDriver.PublishDocumentsDlg.Select9.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);

                Reports.TestStep = "Verify the Loan Investor and Loan Investor Contact File Roles are selected";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[6].FindElement(By.TagName("input")).FAClick();


                Playback.Wait(1000);
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PublishDocumentsDlg.Select9.FAGetAttribute("checked").ToString());
                Support.AreEqual("true", FastDriver.PublishDocumentsDlg.Select10.FAGetAttribute("checked").ToString());

                Reports.TestStep = "Deselect Loan Investor and Loan Investor Contact File Roles";
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                FastDriver.PublishDocumentsDlg.Select10.FASetCheckbox(false);
                FastDriver.PublishDocumentsDlg.Select9.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Verify the Loan Investor and Loan Investor Contact File Roles are Deselected";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[6].FindElement(By.TagName("input")).FADoubleClick();


                Playback.Wait(1000);
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.PublishDocumentsDlg.Select9.Selected.ToString());
                Support.AreEqual("False", FastDriver.PublishDocumentsDlg.Select10.Selected.ToString()); ;
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Publish Documents to Loan Investors ";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanInvestors.FAClick();
                FastDriver.LoanInvestors.WaitForScreenToLoad();
                FastDriver.LoanInvestors.Add.FAClick();
                FastDriver.LoanInvestorsDlg.WaitForScreenToLoad();
                FastDriver.LoanInvestorsDlg.LoanInvestorsTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LoanInvestors.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Loan Investor and Loan Investor Contact File Roles are Deselected";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[6].FindElement(By.TagName("input")).FADoubleClick();
                Playback.Wait(1000);
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PublishDocumentsDlg.Select9.FAGetAttribute("checked").ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);


                Reports.TestStep = "Remove Loan Inventor";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanInvestors.FAClick();
                FastDriver.LoanInvestors.WaitForScreenToLoad();
                FastDriver.LoanInvestors.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LoanInvestors.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();


                Reports.TestStep = "Verfiy the Loan Inventor file role is removed from PublishDocumentsDlg ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[6].FindElement(By.TagName("input")).FADoubleClick();
                Playback.Wait(1000);
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.PublishDocumentsDlg.Select9.Selected.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG36()
        {

            try
            {
                Reports.TestDescription = "DP7465  Removed Policy Numbers  ";
                CheckAssignNumADM(false);
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = " Add a Title Policy document ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                AddEffectiveDatetoDocument("Automation Test Title Report");

                Reports.TestStep = "Add two Lender Policy documents";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "Short Form Commercial LP (6-2000)-N");

                Reports.TestStep = "click on Edit button";
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(10000);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Assign Num to lender policy";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Short Form Commercial LP (6-2000)-N", 4, TableAction.Click);

                //FastDriver.DocumentRepository.SearchResultsTable.PerformTableAction("Description", "    Short Form Commercial LP (6-2000)-N", "Description", TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.AssignNum.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.PolicyNumber.FASetText("12345");
                FastDriver.DocumentRepository.Save.FAClick();

                Reports.TestStep = "Navigate to File Homepage screen and remove Title service";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SwitchToContentFrame();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Doc screen and select lender policy to verify Assign Num button is not exist";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Short Form Commercial LP (6-2000)-N", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                Support.AreEqual("False", FastDriver.DocumentRepository.AssignNum.Exists().ToString());

                Reports.TestStep = "Navigate to File Homepage screen and add Title service";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.Title.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Doc screen and select lender policy to verify Assign Num button is exist, Click on it";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Short Form Commercial LP (6-2000)-N", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.AssignNum.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.PolicyNumber.FASetText("12345");
                FastDriver.DocumentRepository.Save.FAClick();

                Reports.TestStep = "Verify the Policy Number";
                Support.AreEqual("12345", FastDriver.DocumentRepository.PolicyNumber.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG37()
        {
            try
            {
                Reports.TestDescription = "BR DP7465 Create a Target file";

                Reports.StatusUpdate("Functionality has covered in DPUC0009_REG36", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG38()
        {
            try
            {
                Reports.TestDescription = "BR DP7465 Create a Target file";

                Reports.StatusUpdate("Functionality has covered in DPUC0009_REG36", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG39()
        {
            try
            {
                Reports.TestDescription = "BR DP7465 Create a Target file";

                Reports.StatusUpdate("Functionality has covered in DPUC0009_REG36", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG40()
        {

            try
            {
                Reports.TestDescription = "BR DP11043 Delivery with Watermark when Policy/Endorsement is unfinalized  ";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add a Endorsement document and Deliver without finalizing";
                CreateDocumentusingWCFService(DocTemplateTypeId: 7, DocName: "0 Template For DP0007c BAT");
                FastDriver.DocumentRepository.SelectDeliveryMethod("Email");
                FastDriver.DocumentRepository.ClickDeliver();

                string ErrMasg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Delivery of unfinalized Policies, Endorsements, and Guarantees is not allowed.\n\n\t Mark as Draft/Pro forma to Deliver.", ErrMasg);
                Reports.TestStep = "Select lender policy and Click on Water Mark to verify Draft.";

                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[7].FindElement(By.TagName("input")).FAClick();

                Reports.TestStep = "Select a Watermark";
                FastDriver.WatermarkDlg.WaitForScreenToLoad();
                FastDriver.WatermarkDlg.SelectWaterMark.FASelectItem("Draft");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Print document";
                FastDriver.DocumentRepository.SelectDeliveryMethod("Email");
                FastDriver.DocumentRepository.ClickDeliver();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG41()
        {
            try
            {
                Reports.TestDescription = "BR DP13156 Allow User to Restore  ,";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add a Endorsement document(0 Template For DP0007c BAT) and remove it";
                CreateDocumentusingWCFService(DocTemplateTypeId: 7, DocName: "0 Template For DP0007c BAT");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                int rowcount = FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count();
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Verify Document is Removed";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual((rowcount - 1).ToString(), FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count().ToString());

                Reports.TestStep = "Add one more Endorsement document(0 Template For DP0007c BAT)";
                CreateDocumentusingWCFService(DocTemplateTypeId: 7, DocName: "0 Template For DP0007c BAT");
                FastDriver.DocumentRepository.WaitForPageToLoad();

                Reports.TestStep = "Restore removed document and verify the two document are displaying in with same name in main view of doc rep";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.DocumentRepository.Restore.FAClick();

                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("0 Template For DP0007c BAT", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString());
                Support.AreEqual("0 Template For DP0007c BAT", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString());


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG42()
        {
            try
            {

                Reports.TestDescription = "BR DP13173 Prevent Copy of SEC- Doc ";


                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction


                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button. and add a Secure Document";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Exchange : Secured", "SEC-CIP", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Add Title Report Document to  Doc Rep screen";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");


                Reports.TestStep = "Try to Copy SEC the document form the already created file";
                IISLOGIN();
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                Reports.TestStep = "Create File using web service.";
                string secondfile = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(secondfile);
                FileNo = FileService.GetFilesByFileNum(secondfile.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;




                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(fileNumber);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                Playback.Wait(1000);

                Reports.TestStep = "Verify the SEC document is not displaying in Copydocuments page";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                Support.AreNotEqual("True", FastDriver.CopyDocuments.DocListTable.FAGetText().Contains("SEC-CIP PO-Invoice").ToString());



                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG43()
        {

            Reports.TestDescription = "BR DP13173, DP13148, DP13176, DP13148, DP13149 B";

            Reports.StatusUpdate("Functionality has covered in DP13173-DPUC0009_REG42,DP13176-DPUC0009_REG7,DP13148 and DP13149 are Ph", true);
        }

        [TestMethod]
        public void DPUC0009_REG44()
        {

            Reports.TestDescription = "BR DP13173, DP13148, DP13176, DP13148, DP13149 B";

            Reports.StatusUpdate("Functionality has covered in DP13173-DPUC0009_REG42,DP13176-DPUC0009_REG7,DP13148 and DP13149 are Ph", true);
        }

        [TestMethod]
        public void DPUC0009_REG45()
        {

            Reports.TestDescription = "BR DP13173, DP13148, DP13176, DP13148, DP13149 B";

            Reports.StatusUpdate("Functionality has covered in DP13173-DPUC0009_REG42,DP13176-DPUC0009_REG7,DP13148 and DP13149 are Ph", true);
        }

        [TestMethod]
        public void DPUC0009_REG46()
        {

            Reports.TestDescription = "BR DP13173, DP13148, DP13176, DP13148, DP13149 B";

            Reports.StatusUpdate("Functionality has covered in DP13173-DPUC0009_REG42,DP13176-DPUC0009_REG7,DP13148 and DP13149 are Ph", true);
        }

        [TestMethod]
        public void DPUC0009_REG47()
        {

            Reports.TestDescription = "BR DP13173, DP13148, DP13176, DP13148, DP13149 B";

            Reports.StatusUpdate("Functionality has covered in DP13173-DPUC0009_REG42,DP13176-DPUC0009_REG7,DP13148 and DP13149 are Ph", true);
        }

        [TestMethod]
        public void DPUC0009_REG47A()
        {

            Reports.TestDescription = "BR DP13173, DP13148, DP13176, DP13148, DP13149 B";

            Reports.StatusUpdate("Functionality has covered in DP13173-DPUC0009_REG42,DP13176-DPUC0009_REG7,DP13148 and DP13149 are Ph", true);
        }

        [TestMethod]
        public void DPUC0009_REG48()
        {
            try
            {

                Reports.TestDescription = "BR DP11047, DP11048, DP11049 List currently existing Properties in Properties section,Set first Property as default and Multiple properties associated with a Policy";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = " Add a Title Policy document ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Add a Lender Policy documents";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "Short Form Commercial LP (6-2000)-N");

                Reports.TestStep = "Add a Property address in Properties/Tax Info Screen";
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("reg48");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Reg48");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Orange");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("CA");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();


                Reports.TestStep = "Verify the newly added address is displaying in Properties section Doc Rep screen";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Short Form Commercial LP (6-2000)-N", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                Support.AreEqual("reg48", FastDriver.DocumentRepository.Properties.PerformTableAction(3, 2, TableAction.GetText).Message.ToString());

                Reports.TestStep = "Verify the first first property is selected as default";
                Support.AreEqual("True", FastDriver.DocumentRepository.propertychk.IsSelected().ToString());

                Reports.TestStep = "Verify user able to select second property and deselect first property";
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.propertychk.FAClick();
                FastDriver.DocumentRepository.Properties2chkbox.FASetCheckbox(true);
                FastDriver.DocumentRepository.Save.FAClick();
                Playback.Wait(1000);
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                Support.AreEqual("True", FastDriver.DocumentRepository.propertychk.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.DocumentRepository.Properties2chkbox.IsSelected().ToString());

                Reports.TestStep = "Verify user able to select second property and deselect first property";
                FastDriver.DocumentRepository.Properties2chkbox.FASetCheckbox(true);
                FastDriver.DocumentRepository.Save.FAClick();
                Playback.Wait(1000);
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                Support.AreEqual("True", FastDriver.DocumentRepository.propertychk.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.DocumentRepository.Properties2chkbox.IsSelected().ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG49()
        {
            try
            {

                Reports.TestDescription = "BR DP11022 : Allow creation and finalization of templates with no filters ";

                #region Precondition for DP11022;
                ADMLOGIN();

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = Support.RandomString("ANANAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(templateName);
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(templateName);
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText(templateName);
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FASetCheckbox(false);

                Reports.TestStep = "Click on Formatting tab and click on first page";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();

                Reports.TestStep = "Add Phrases to the Template";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.BottomFrame.Save();

                #endregion

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                Reports.TestStep = "Add a" + templateName + " document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem("Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("Escrow Instruction");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(templateName);
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", templateName, "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(5000);

                Reports.TestStep = "Verify Document is added";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 4, TableAction.Click);

                FinalizeDocumentthroughUI();

                Reports.TestStep = "Verify the document id finalized";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 9, TableAction.GetText).Message.ToString());
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG50()
        {
            try
            {

                Reports.TestDescription = "BR DP11022 Allow creation and finalization of templates with no filters ";
                Reports.StatusUpdate("Functionality has covered in DPUC0009_REG49", true);
               
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG51()
        {
            try
            {

                Reports.TestDescription = "BR DP11019, DP11020, DP11021 matching states for templates with State validatio, List names of templates with non-matching states and Prevent finalization of document for non-matching states";

                #region 

                ADMLOGIN();

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);
                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                string templateName = "AA"+Support.RandomString("ANANAAAA");
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(templateName);
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(templateName);
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText(templateName);
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FASetCheckbox(false);

                Reports.TestStep = "Click on Formatting tab and click on first page";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();

                Reports.TestStep = "Add Phrases to the Template";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("JVE/JV01");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Add validation to the Template";
                FastDriver.TemplateMaintenanceInformation.SwitchToContentFrame();
                FastDriver.TemplateMaintenanceInformation.linkValidation.FAClick();
                FastDriver.TemplateMaintenanceValidation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceValidation.State);

                Reports.TestStep = "Click on Template Validation.";
                FastDriver.TemplateMaintenanceValidation.ValidationSelect.FAClick();

                Reports.TestStep = "Select the state filter for Template.";
                FastDriver.StateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateFilterSelectionDlg.AddRemoveState.FAClick();

                Reports.TestStep = "Add a new state.";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.grdState0SelState.FASetCheckbox(true);
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.StateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.StateFilterSelectionDlg.WindowTitle, false, 15);

                Reports.TestStep = "Click on Save Template Validation.";
                FastDriver.BottomFrame.Save();

                #endregion

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion
                #region GUI Intreaction
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                Reports.TestStep = "Add a" + templateName + " document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem("Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("Endorsement/Guarantee");
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                Playback.Wait(10000);
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SelectMutipleDocuments(templateName);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(10000);
                Thread.Sleep(1000);
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("True", message.Contains("Templates cannot be created or saved.").ToString());
                Support.AreEqual("True", message.Contains("State filter for the following Templates does not match with the states on the file:").ToString());

                Reports.TestStep = "Navigate Properties/Tax Info and change state to AA";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.ClickSummaryTable(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("AA");
                Thread.Sleep(10000);
                alert();
                //FastDriver.WebDriver.HandleDialogMessage(false,true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to Document Repository and add a document which from under state 'AA'";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                Reports.TestStep = "Add a" + templateName + " document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem("Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("Endorsement/Guarantee");
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(templateName);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                Playback.Wait(10000);
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(4000);
                Reports.TestStep = "Navigate Properties/Tax Info and change state to CA";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.ClickSummaryTable(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("CA");
                Playback.Wait(1000);
                alert();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to Document Repository and finalize the document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify the error warning message";
                Playback.Wait(2000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                FastDriver.DocumentPreparationMenu.WaitCreation(FastDriver.DocumentPreparationMenu.label1);
                FastDriver.DocumentPreparationMenu.label1.Click();
                Playback.Wait(2000);
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%z");
                string wrnmsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("True", wrnmsg.Contains("Document cannot be finalized.").ToString());
                Support.AreEqual("True", wrnmsg.Contains("State Filter on the template does not match with the existing Property states on the file.").ToString());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_REG52()
        {
            try
            {

                Reports.TestDescription = "BR DP13420, DP13432, Prevent Change of Doc Type – Starter Ref and Prevent Change of Document Type for Removed Void Status  ";                

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Verify the scanned document is available in document repository screen ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("INST-Estimated Settlement Statement PO-Invoice", document);

                Reports.TestStep = "Create One more File and Copy all the document form the already created";
                IISLOGIN();
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                Reports.TestStep = "Create File using web service.";
                string secondfile = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(secondfile);
                FileNo = FileService.GetFilesByFileNum(secondfile.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;


                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(fileNumber);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                Playback.Wait(1000);
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                Playback.Wait(1000);
                Playback.Wait(1000);

                Reports.TestStep = "Navigate to Document Repository screen and verify the document are added";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("INST-Estimated Settlement Statement PO-Invoice", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "INST-Estimated Settlement Statement PO-Invoice", 4, TableAction.GetText).Message);

                Reports.TestStep = "Verify the User able to change the Starter-Ref image document type";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("input")).FADoubleClick();
                Thread.Sleep(1000);
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                Support.AreEqual("False",FastDriver.EditDocumentDlg.ChangeDocumentType.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the use able remove the starter-image in target file";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DocumentRepository.Remove.Enabled.ToString());

                Reports.TestStep = "Verify the use able remove the starter-image in source file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[2].Click();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DocumentRepository.Remove.Enabled.ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_REG53()
        {

            try
            {
                Reports.TestDescription = "BR DP13433, DP13292, DP13157, DP13154,  DP13293, DP13796, DP13850";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();

                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Click on Scan Button.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.Scan_DocsTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);


                Reports.TestStep = "Remove Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                int rowcount = FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Verify Document is Removed";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual((rowcount - 1).ToString(), FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count().ToString());

                Reports.TestStep = "Verify Info Tab is not displaying for removed documents";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 3, TableAction.Click);
                Support.AreEqual("False", FastDriver.DocumentRepository.Info.IsVisible().ToString());

                Reports.TestStep = "Verify user able to edit removed document";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DocumentRepository.Edit.Enabled.ToString());

                Reports.TestStep = "Verify system is allowing user to preview removed document";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("PREVIEW", FastDriver.DocumentRepository.Method.FAGetSelectedItem());

                Reports.TestStep = "Remove Image";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                 rowcount = FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Verify the removed image";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 3, TableAction.Click);
                string m = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 4, TableAction.GetText).Element.Text.ToString();
                Support.AreEqual("INST-Estimated Settlement Statement PO-Invoice", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 4, TableAction.GetText).Element.Text.ToString());

                Reports.TestStep = "Restore the removed image";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.DocumentRepository.Restore.FAClick();

                Reports.TestStep = "Verify the image is restored";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("INST-Estimated Settlement Statement PO-Invoice", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString());


                Reports.TestStep = "Verify for Event Log is updation";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Removed Image]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains("INST-Estimated Settlement Statement PO-Invoice").ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG54()
        {
            try
            {
                
                Reports.TestDescription = "BR DP13463, DP13471, DP13474, DP13462, DP13741, DP13742, DP13475, DP13476, DP13680, DP13477, DP13656 A";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                Reports.TestStep = "Add a document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem("Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("CPL");
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1,2, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(5000);
                Reports.TestStep = "Verify CPL Document is added";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "CPL", "Type", TableAction.GetText).Message.ToString();
                Support.AreEqual("CPL", document);

                Reports.TestStep = "Navigate Properties/Tax Info and add zip";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.ClickSummaryTable(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("63001");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Store CPL document";
                 FastDriver.LeftNavigation.Navigate<ClosingProtectionLetter>("Home>Order Entry>Closing Protection Letter");
                FastDriver.ClosingProtectionLetter.WaitForScreenToLoad();
                FastDriver.ClosingProtectionLetter.Office.FASelectItem("DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.ClosingProtectionLetter.BuyerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.SellerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.LenderTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ClosingProtectionLetter.SubmitCPLRequest.FAClick();
                Playback.Wait(10000);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Verify the CPL document is displaying in doc rep screen which was created through Closing Protection Letter";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("Closing Protection Letter - LENDER", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString());

                Reports.TestStep = "Select all the documents and click on Associate";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();

                Reports.TestStep = "Associated Documents Sequencing dialog.";
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Deliver Associated Package";
                FastDriver.AssociateDocs.WaitForScreenToLoad();
                Playback.Wait(4000);
                //This portion of code is added to cover the test related with bug:828566
                FastDriver.AssociateDocs.DeliverMethod.FASelectItem("FAX");
                FastDriver.AssociateDocs.DeliverButton.FAClick();
                FastDriver.FaxDlg.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.FaxDlg.imageDocument.IsSelected(), "Image document check box should not be selected by default.");
                FastDriver.FaxDlg.Cancel.FAClick();
                FastDriver.AssociateDocs.WaitForScreenToLoad();
                //

                FastDriver.AssociateDocs.DeliverMethod.FASelectItem("EMAIL");
                FastDriver.AssociateDocs.DeliverButton.FAClick();
                Playback.Wait(4000);
                FastDriver.EmailDlg.WaitForDialogToLoad();
                Support.AreEqual(false, FastDriver.EmailDlg.imgDocument.IsSelected(), "Image document check box should not be selected by default.");
                FastDriver.EmailDlg.ToText.FASetText("pattada@firstam.com");
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Email);
                Playback.Wait(5000);

                Reports.TestStep = "Verify user able to removed the CPL document that part of package";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();
                Support.AreEqual("Do you wish to Void the selected CPL(s)?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = " Prevent Document Removal - Finalized Status";
                Playback.Wait(1000);
                
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);

                FinalizeDocumentthroughUI();

                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();
                Support.AreEqual("This document is in finalized status and cannot be removed.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify Document is removed and updated the status as Void";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string RemovedCpl = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "CPL", "Status", TableAction.Click).Element.Text.ToString();
              Support.AreEqual("Void", RemovedCpl);

              Reports.TestStep = "Voided CPL documents can only be previewed";
              FastDriver.DocumentRepository.WaitForScreenToLoad();
              Support.AreEqual("PREVIEW", FastDriver.DocumentRepository.Method.FAGetSelectedItem());

              Reports.TestStep = " Prevent Restore for Documents with Void Status";
              FastDriver.DocumentRepository.WaitForScreenToLoad();
              FastDriver.DocumentRepository.Restore.FAClick();
              Support.AreEqual("Documents with the status of Void cannot be Restored.", FastDriver.WebDriver.HandleDialogMessage());


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG55()
        {

            Reports.TestDescription = "!!Expected Failue if CPL is not Configured!!. BR DP13463, DP13471, DP13474, DP13462, DP13741, DP13742, DP13475, DP13476, DP13680, DP13477, DP13656 B";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_REG54", true);
        }

        [TestMethod]
        public void DPUC0009_REG56()
        {

            Reports.TestDescription = "!!Expected Failue if CPL is not Configured!! BR DP13463, DP13471, DP13474, DP13462, DP13741, DP13742, DP13475, DP13476, DP13680, DP13477, DP13656 C";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_REG54", true);
        }

        [TestMethod]
        public void DPUC0009_REG57()
        {
            try
            {

                Reports.TestDescription = "BR DP13744 Remove Documents One at a Time  ";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
              
                Reports.TestStep = "Navigate Properties/Tax Info and add zip";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.ClickSummaryTable(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("63001");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Store CPL document";
                FastDriver.LeftNavigation.Navigate<ClosingProtectionLetter>("Home>Order Entry>Closing Protection Letter");
                FastDriver.ClosingProtectionLetter.WaitForScreenToLoad();
                FastDriver.ClosingProtectionLetter.Office.FASelectItem("DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.ClosingProtectionLetter.BuyerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.SellerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.LenderTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ClosingProtectionLetter.SubmitCPLRequest.FAClick();
                Playback.Wait(4000);
                Thread.Sleep(1000);
                FastDriver.LeftNavigation.Navigate<ClosingProtectionLetter>("Home>Order Entry>Closing Protection Letter");
                FastDriver.ClosingProtectionLetter.WaitForScreenToLoad();
                FastDriver.ClosingProtectionLetter.Office.FASelectItem("DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.ClosingProtectionLetter.BuyerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.SellerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.LenderTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ClosingProtectionLetter.SubmitCPLRequest.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Select all CPL documents and remove it";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Closing Protection Letter - LENDER", 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();
               Support.AreEqual("Do you wish to Void the selected CPL(s)?", FastDriver.WebDriver.HandleDialogMessage());
               Playback.Wait(1000);
                
                Reports.TestStep = "Verify removed documents are available in removed items list";                
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
               Support.AreEqual("True",(FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("tr")).Count>1).ToString());

               Reports.TestStep = "Add CPL documents from document repository";
               FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
               FastDriver.DocumentRepository.WaitForScreenToLoad();
               FastDriver.DocumentRepository.AddDocRep.FAClick();
               Reports.TestStep = "Add a document.";
               FastDriver.AdHocDocuments.WaitForScreenToLoad();
               FastDriver.AdHocDocuments.Source.FASelectItem("Both");
               FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("CPL");
               FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
               FastDriver.AdHocDocuments.FindNow.FAClick();
               FastDriver.AdHocDocuments.WaitForScreenToLoad();
               FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 2, TableAction.Click);
               FastDriver.AdHocDocuments.CreateSave.FAClick();
               FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
               Playback.Wait(5000);
               Reports.TestStep = "Verify CPL Document is added";
               FastDriver.DocumentRepository.WaitForScreenToLoad();
               FastDriver.DocumentRepository.AddDocRep.FAClick();
               Reports.TestStep = "Add a document.";
               FastDriver.AdHocDocuments.WaitForScreenToLoad();
               FastDriver.AdHocDocuments.Source.FASelectItem("Both");
               FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("CPL");
               FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
               FastDriver.AdHocDocuments.FindNow.FAClick();
               FastDriver.AdHocDocuments.WaitForScreenToLoad();
               FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 2, TableAction.Click);
               FastDriver.AdHocDocuments.CreateSave.FAClick();
               FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
               Playback.Wait(5000);

               Reports.TestStep = "Select all documents and verify the status of the remove button";
               FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
               FastDriver.DocumentRepository.WaitForScreenToLoad();
               FastDriver.DocumentRepository.SelectAllDocuments();
               FastDriver.DocumentRepository.WaitForScreenToLoad();
               Support.AreEqual("False", FastDriver.DocumentRepository.Remove.Enabled.ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
      
        [TestMethod]
        public void DPUC0009_REG58_ExpectedFailure()
        {
            try
            {
               
                Reports.TestDescription = "Validate in Doc Rep screen";
                Reports.TestStep = "Not required";
               
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG59()
        {
            
            try
            {
                
                Reports.TestDescription = "Make business party Etitle enabled";

                #region pre condetion
                ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office");
                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("10156");

                Reports.TestStep = "Navigate to address book.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.New.FAClick();

                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.EntityType.FASelectItem("Lender");
                FastDriver.BusinessPartyOrganizationSetUp.CorporateParent.FASelectItem("Wells Fargo");
                FastDriver.BusinessPartyOrganizationSetUp.Name1.FASetText("pradeep"+Support.RandomString("AAAAA"));
                string lender = Support.RandomString("AAAAA") + "2";
                FastDriver.BusinessPartyOrganizationSetUp.IDCode.FASetText(lender);
                FastDriver.BottomFrame.Done();
                #endregion


                #region region Basic File Creation
                IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                CreateFileInCaliforniaRegion(lender);
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Navigate to New loan screen and change the lender address";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText(lender);
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = " Add a Title Policy document ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Title Reports", "Commitment", "CA");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");               
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                AddEffectiveDatetoDocument("Commitment");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = " Add a Lender Policy document and finalize it";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Lender Policy", "ALTA Residential Ltd Cov Jr LP-N", "CA");

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA Residential Ltd Cov Jr LP-N", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(10000);
                FastDriver.BottomFrame.Done();

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA Residential Ltd Cov Jr LP-N", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.AssignNum.FAClick();
                FastDriver.BottomFrame.Done();

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA Residential Ltd Cov Jr LP-N", 4, TableAction.Click);
                Playback.Wait(10000);
                FinalizeDocumentthroughUI();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the eTitle is enabled document";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string eT = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 1, TableAction.Click).Element.FindElement(By.TagName("img")).Exists().ToString();
                Support.AreEqual("True", eT);

                Reports.TestStep = "Default Option for EPOLICY ";
                Support.AreEqual("EPOLICY", FastDriver.DocumentRepository.Method.FAGetSelectedItem());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void DPUC0009_REG60_ExpectedFailure()
        {
            try
            {

                Reports.TestDescription = "Check the check box is unchecked for DFS for QFE in DOCPREP region";
                Reports.TestStep = "Not required";

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG61()
        {
            try
            {

                Reports.TestDescription = "Make the check box checked";
                Reports.TestStep = "Not required";

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG62_ExpectedFailure()
        {
            try
            {

                Reports.TestDescription = "Uncheck the checkbox if it is not checked in the region";
                Reports.TestStep = "Not required";

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG63()
        {

            Reports.TestDescription = "BRDP12672, DP13011, DP12746 Validate Etitle icon is displayed on Doc Rep";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_REG59", true);
        }

        [TestMethod]
        public void DPUC0009_REG64()
        {

            Reports.TestDescription = "BR DP12672 Validate the eT icon in doc rep screen";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_REG59", true);
        }

        [TestMethod]
        public void DPUC0009_REG65_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP7486,DP7487,DP7488,DP7489,DP7490,DP7987";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG66_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP14438,DP14435";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
   
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG67_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP14434";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG68_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP14436,DP15060,DP7891";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG69_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP7495";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG70_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP3472";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG71_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP4232";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG72_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP13410";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG73_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP6600,DP6601,DP6602";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG74_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP7358,DP7385,DP7386";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG75_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder BR DP7987";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG76()
        {
            try
            {

                Reports.TestDescription = "DP14540 - Render AgentNet Policy Number for Policy Number Data Element.";
               
                #region region Basic File Creation
                CheckAssignNumADM();
                IISLOGIN();
                CreateBasicFile();
                FastDriver.FileHomepage.AddFileProduct("*ALTA Extended Loan Policy");
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Request for Policy Number";
                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number").WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem(@"First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                Playback.Wait(1000);
                FastDriver.RequestPolicyNumber.Table.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                Playback.Wait(10000);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                Reports.TestStep = "Add a document.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem("Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("Policy w/o Title Reports");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText("Template created for 6.3 updates");
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Assign policy number and take note of policy number";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Template created for 6.3 updates", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.PWTREffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.InfoTabAssignPolicyNumberButton.FAClick();
                string policy = FastDriver.DocumentRepository.PolicyNumber.FAGetValue();
                FastDriver.DocumentRepository.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Edit and verify the policy # whih was noted in info tab screen";
                Playback.Wait(10000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(2000);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(2000);
                Support.AreEqual(policy, FastDriver.DocumentPreparationMenu.policynumber.FAGetValue());
                
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG77_PH()
        {
            try
            {

                Reports.TestDescription = "BR DP7486 Archived Files  ";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG78_PH()
        {
            try
            {

                Reports.TestDescription = "BR DP7486 Archived Files  ";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG79_PH()
        {
            try
            {

                Reports.TestDescription = "BR DP7486 ";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG80_PH()
        {
            try
            {

                Reports.TestDescription = "PlaceHolder BR DP11045, DP13336, DP13346";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG81_PH()
        {
            try
            {

                Reports.TestDescription = "PlaceHolder BR DP14729, DP14733";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #region SRT- R06
        //Team                  :  ServReq-Team1
        //Iteration             :  r06
        //UserStory             :  User Story 607842
        //TestCase              :  780858
        //Appended By/ Created By: Amarnathh

        [TestMethod]
        public void DPUC0009_REG83()
        {
            CreatePhraseGroup();

            #region Pulling Document in the file

            try
            {
                Reports.TestStep = "Navigate to Document Repositort, click on Add Button, select template and save it.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Order Entry>Document Repository");
                Playback.Wait(4000);
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                Playback.Wait(6000);
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText("US#607842*");
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.WaitForResultsToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();

                Reports.TestStep = "Select Document and Deliver.";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.SelectDeliveryMethod("Preview");
                FastDriver.DocumentRepository.ClickDeliver();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            #endregion
        }

        //Team                  :  ServReq-Team1
        //Iteration             :  r06
        //UserStory             :  User Story 607842
        //TestCase              :  780904
        //Appended By/ Created By: Amarnathh

        [TestMethod]
        public void DPUC0009_REG84()
        {
            CreatePhraseGroup();

            #region Editing Document in the file

            try
            {
                Reports.TestStep = "Navigate to Document Repositort, click on Add Button, select template and save it.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Order Entry>Document Repository");
                Playback.Wait(4000);
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                Playback.Wait(6000);
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText("US#607842*");
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.WaitForResultsToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();

                Reports.TestStep = "Edit the document.";
                Playback.Wait(4000);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(4000);
                FastDriver.DocumentPreparationwin.grdDocumenPhrase0textData.FASetText("SnehaSivakumar.gif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                Reports.TestStep = "Select Document and Deliver.";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.SelectDeliveryMethod("Preview");
                FastDriver.DocumentRepository.ClickDeliver();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

            #endregion
        }
        #endregion SRT- R06

        [TestMethod, DeploymentItem(@"Common\Support\Advanced Rails.pdf")]
        public void DPUC0009_REG0088()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "User Story 836942: INC2954325 - 10.5 Issue - Unable to Split Documents - when splitting more that 2 pages it doubles the package instead of splits";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "FL";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ALACHUA";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessSegmentObjectCD = "DFTCOM";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                ToggleDisplayPDFinBrowser(true);
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad();

                Reports.TestStep = "Upload PDF or Tiff imaged documents having more than 2 pages";
                FastDriver.DocumentRepository.Upload.FAClick();
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FAClick();
                Reports.StatusUpdate(Reports.DEPLOYDIR + @"\Advanced Rails.pdf", true);
                FastDriver.OpenImageDlg.UploadImage(Reports.DEPLOYDIR + @"\Advanced Rails.pdf");
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.Upload.FAClick();
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItemByIndex(1);
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItemByIndex(1);
                var docName = FastDriver.SaveDocumentDlg.DocumentName.FAGetSelectedItem().Clean();
                FastDriver.SaveDocumentDlg.WQTriggerNames.FASelectItemByIndex(1);
                FastDriver.SaveDocumentDlg.Ok.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    try
                    {
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad();
                        FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, docName, 2, TableAction.Click);
                        return true;
                    }
                    catch
                    {
                        return false;
                    }

                }, timeout: 400);

                Reports.TestStep = "Click on Split icon.";
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();

                Reports.TestStep = @"Enter page range as 2-4,6-8.";
                FastDriver.SplitDocumentScreenDlg.PageRange.FASetText("2-4,6-8");

                Reports.TestStep = "Click on Split and save it.";
                FastDriver.SplitDocumentScreenDlg.Split.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.SplitDocumentScreenDlg.WaitForScreenToLoad();
                FastDriver.SplitDocumentScreenDlg.Save.FAClick();
                //FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.DocumentNameDlg.WaitForScreenToLoad();
                var splittedDocName = FastDriver.DocumentNameDlg.DocName.FAGetValue().Clean() + " Splitted";
                FastDriver.DocumentNameDlg.DocName.FASetText(splittedDocName);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.DocumentRepository.WaitForScreenToLoad();

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad();
                    return !FastDriver.DocumentRepository.DocumentsTable.FAGetText().Contains(splittedDocName);
                }, timeout: 400);

                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, splittedDocName, 1, TableAction.Click);
                FastDriver.Delivery.Perform(FADeliveryMethod.Preview);
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview, 300);
                Reports.TestStep = "Save PDF file";
                string savePath = @"C:\Reports\" + DateTime.Today.ToString("MMMddyyyy");
                CreateDirectory(savePath);
                string tempPdfFile = savePath + "\\temp" + DateTime.Now.ToString("hh-mm") + ".pdf";
                SavePDFFile(tempPdfFile);

                Reports.TestStep = "Validate PDF file having correct amount of pages";
                Support.AreEqual(true, PDFHelper.GetPdfPageCount(tempPdfFile) == 6, "Validating PDF has 6 pages.");
                ToggleDisplayPDFinBrowser(false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG0089()
        {
            try
            {
                //UAT 10.6
                //INC2947043_TFS835390
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest(12837, 12839);
                fileRequest.Source = "LVIS";
                #endregion

                Reports.TestDescription = "Next Gen: Non-migrated templates showing as migrated in admin";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Doc Gen office.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID("12839");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Template Maintenance scren.";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.TemplateType);

                Reports.TestStep = "Select Template Type and click Find Now.";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Title Reports");
                FastDriver.TemplateMaintenanceSummary.Description.FASetText("Template Test-1");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();

                Reports.TestStep = "Select template and edit.";
                FastDriver.TemplateMaintenanceSummary.WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.Results);
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, "Template Test-1", 2, TableAction.DoubleClick);

                Reports.TestStep = "Verify *Migrated to NextGen* icon not displayed.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.TemplateMaintenanceInformation.MigratedToNextGenIcon.IsDisplayed(), "MigratedToNextGenIcon IsDisplayed");
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST File Site application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Doc Gen office.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID("12839");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository.";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.TemplateSearchButton);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Search for the non-migrated template.";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Template Test-1");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Confirm the non-migrated template is not present.";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.TemplatesTable);
                Support.AreEqual(false, FastDriver.NextGenDocumentRepository.TemplatesTable.FAGetText().Contains("Template Test-1"), "Verify Templates table text for text *Template Test-1*");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        //Team                      :  ServReq-Team1
        //Iteration                 :  r10
        //UserStory                 :  [Bug] INC2787311 - Direct - RE Broker License Number Data Elements Reversed";
        //TestCase                  : 
        //Appended By/ Created By   :  Swetha Neelakantaiah
        [TestMethod]
        public void DPUC0009_REG0090_PH()
        {
            Reports.TestDescription = "PlaceHolder  SRT US#801647 - INC2787311 - Direct - RE Broker License Number Data Elements Reversed";
            Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
            Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);
        }

        //Team                                    : ServReq
        //Iteration                               : r10
        //UserStory                               : User Story 748571:INC2374897 - Direct [Bug] - Spell Check missing from Email and Fax Modules
        //TestCase                                : 884495
        //Appended By/ Created By                 : Nikhil
        [TestMethod]
        public void DPUC0009_REG0093()
        {

            try
            {
                Reports.TestDescription = "US748571:Spell check for Email and Fax.";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");


                Reports.TestStep = "Select document and deliver it";
                FastDriver.DocumentRepository.SelectDeliveryMethod("Email");
                FastDriver.DocumentRepository.ClickDeliver();
                //Include Email and Fax
                FastDriver.SpellingErrorDlg.SpellCheck_Email();

                FastDriver.DocumentRepository.SelectDeliveryMethod("Fax");
                FastDriver.DocumentRepository.ClickDeliver();
                FastDriver.SpellingErrorDlg.SpellCheck_Fax();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        [TestMethod]
        public void DPUC0009_REG94()
        {
            try
            {
                Reports.TestDescription = "Create an Assoc Doc Package and Removing the Package";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile().FileID);

                Reports.TestStep = "Search for newly created file.";
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Document Repository and click on Add button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add the UK ENDOR T Endorsement Document to Document Repository screen.";
                FastDriver.AdHocDocuments.SearchDocument("Both", "Endorsement/Guarantee", "UK ENDOR T", "");
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Endorsement/Guarantee", "Type", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to Document Repository and click on Add button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add the Accomm Sign-Customer Buyer Escrow Instruction Document to Document Repository screen.";
                FastDriver.AdHocDocuments.SearchDocument("Both", "Escrow Instruction", "Accomm Signing-Customer Buyer", "");
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Escrow Instruction", "Type", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to Document Repository and click on Add button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add the Automation Test Title Report Document to Document Repository screen.";
                FastDriver.AdHocDocuments.SearchDocument("Both", "Title Reports", "Automation Test Title Report", "");
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Title Reports", "Type", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Select Multiple Docs For create Assoc Docs Package.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();

                Reports.TestStep = "Enter Package name and click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Associated Documents Sequencing", true, 20);
                FastDriver.AssocDocSeqDlg.SwitchToDialogContentFrame();
                FastDriver.AssocDocSeqDlg.PackageIDName.FASetText("AssocPack");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                #region script for bug 829870
                Reports.StatusUpdate(@"Bug 829870 reported during 10.5. Check if it occurs again during regression", true);
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                List<string> Doc = new List<string>();
                Doc.Add("Automation Test Title Report");
                FastDriver.DocumentRepository.SelectAllDocuments().SelectDocumentsByName(Doc);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.btnInfoSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.SearchResults.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                string DeliveryMethod = "PRINT";
                Support.AreEqual("False", IsCheckedImageDocCheckbox(DeliveryMethod).ToString());
                DeliveryMethod = "FAX";
                Support.AreEqual("False", IsCheckedImageDocCheckbox(DeliveryMethod).ToString());
                DeliveryMethod = "EMAIL";
                Support.AreEqual("False", IsCheckedImageDocCheckbox(DeliveryMethod).ToString());
                Reports.StatusUpdate(@"End of Bug verification", true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        //
        #region Bug785666
        [TestMethod]
        public void DPUC0009_REG95()
        {
            Reports.TestDescription = "Bug78566_Validate hot keys for PhraseEditor save and done button";

            #region Data setup

            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

            #endregion

            #region ADM Login

            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            #endregion

            #region Phrase Creation

            Reports.TestStep = "Create a new Phrase Group.";
            FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
            FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

            Reports.TestStep = "Enter mandatory info to create a new phrase group.";
            FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
            string phraseGroup = "G" + Support.RandomString("AAN");
            FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroup);
            FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation Phrase Group");
            FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
            FastDriver.PhraseGroupMaintenance.Comments.FASetText("Bug#785666 Testing");
            FastDriver.BottomFrame.Save();

            Reports.TestStep = "Click on Add button.";
            FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
            FastDriver.PhraseGroupMaintenance.Add.FAClick();

            Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
            string phraseName = "G" + Support.RandomString("AAN");
            FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
            FastDriver.PhraseGroupMaintenance.PhraseName.FASetText(phraseName);
            FastDriver.PhraseGroupMaintenance.PhraseDescritption.FASetText("Automation Phrase");
            FastDriver.PhraseGroupMaintenance.PhraseComments.FASetText("Bug#785666 Testing : Add phrase to Phrasegroup");
            FastDriver.BottomFrame.Save();

            Reports.TestStep = "Click on Phrase Editor button.";
            FastDriver.PhraseMaintenance.SwitchToContentFrame();
            FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
            FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
            FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();


            Reports.TestStep = "Select the Signature Data Elements.";
            FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
            FastDriver.DataElementSelectionDlg.SwitchToDialogContentFrame();
            FastDriver.DataElementSelectionDlg.DataElement.FASetText("BSREP1SIGN");

            Reports.TestStep = "Click on Done in Dialog Box.";
            FastDriver.DataElementSelectionDlg.SwitchToDialogBottomFrame();
            FastDriver.DataElementSelectionDlg.Done.FAClick();
            Playback.Wait(3000);

            FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
            Reports.TestStep = "Click on Save.";
            FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.btnSave.GiveFocus();
            Keyboard.SendKeys("^S");
            Thread.Sleep(4000);
            Reports.TestStep = "Click on Done.";
            FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.btnDone.GiveFocus();
            Keyboard.SendKeys("^D");
            Thread.Sleep(4000);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            Support.AreEqual("True", FastDriver.PhraseMaintenance.WaitForScreenToLoad().Description.IsDisplayed().ToString(),"If it Fails Then Check hot keys for save and done manually");
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }
            #endregion
        #endregion
        #region FD

        [TestMethod]
        public void DPUC0009_FD1()
        {
            try
            {

                Reports.TestDescription = "Field Definitions 6.1.2, 6.1.3";

                #region region Basic File Creation
                IISLOGIN();
                CreateFilethroughUI();
                #endregion

                #region GUI Intreaction
               

                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                Reports.TestStep = "Disabled in the Filtered Templates tab";
                Support.AreEqual("False", FastDriver.DocumentRepository.Deliver.Enabled.ToString());

                Reports.TestStep = "Displays a list of templates, which meet the criteria of the search in the Search Results section";
                Support.AreEqual("True", (FastDriver.DocumentRepository.SearchResultsTable.GetRowCount() > 2).ToString());

                Reports.TestStep = "New Searcc: Clears all fields in the Template Search Criteria section";
                FastDriver.DocumentRepository.NewSearch.FAClick();
                Playback.Wait(10000);
                FastDriver.DocumentRepository.WaitForDocumentRepositoryTemplatesScreenToLoad();
                int c=(FastDriver.DocumentRepository.SearchResultsTable.GetRowCount());
                Support.AreEqual("False", (FastDriver.DocumentRepository.SearchResultsTable.GetRowCount() > 2).ToString());

                string  TemplateType= FastDriver.DocumentRepository.TemplateType.FAGetText();
                string  TemplateType_actual = "All Available TemplatesCPLEndorsement/GuaranteeEscrow InstructionEscrow Ltr/TransmittalExchange DelayedExchange MiscellaneousExchange Reverse/ConstructionFax Cover SheetFormGen'd Data ElementGuaranteeLegal Size PaperLegal/Recordable DocLender PolicyMisc Escrow DocumentMisc Title DocumentOwner PolicyPolicy w/o Title ReportsSDN ResultTitle Ltr/TransmittalTitle Reports ";

               Support.AreEqual(TemplateType_actual,TemplateType);

                Reports.TestStep = "verify that description cannot exceed 60 character";
                FastDriver.DocumentRepository.TemplateDescription.FASetText("");//62 char
                Keyboard.SendKeys("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefgh");//62 char
               Support.value = FastDriver.DocumentRepository.FindNow.IsEnabled().ToString();
               Support.value = FastDriver.DocumentRepository.TemplateDescription.FAGetValue();
               Support.AreEqual("False",Support.value.Contains("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefg").ToString());//failure for 62 char

                Reports.TestStep = "verify that description accepts 60 character";
                FastDriver.DocumentRepository.TemplateDescription.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdef");//60 char
               Support.value = FastDriver.DocumentRepository.FindNow.IsEnabled().ToString();
               Support.value = FastDriver.DocumentRepository.TemplateDescription.FAGetValue();
               Support.AreEqual(@"abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdef",Support.value);
                FastDriver.DocumentRepository.TemplateDescription.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz");
               Support.value = FastDriver.DocumentRepository.FindNow.IsEnabled().ToString();
               Support.value = FastDriver.DocumentRepository.TemplateDescription.FAGetValue();
               Support.AreEqual(@"abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz",Support.value);//53 char
                FastDriver.DocumentRepository.TemplateDescription.FASetText("abcdefghijklmnopqrstuvwxyz7890123456789*");
               Support.value = FastDriver.DocumentRepository.FindNow.IsEnabled().ToString();
                //boundary value code ends here
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.NewSearch.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);

                //Assuming that user profile allows for scanning authority, scan button is enabled - refer REG9 for disabling.
               Support.value = FastDriver.DocumentRepository.Scan.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
                //Assuming that user profile allows for scanning authority upload button is enabled- refer REG9 for disabling.
               Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.Add.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.CreateEdit.IsEnabled().ToString();
               Support.AreEqual(@"False",Support.value);
               Support.value = FastDriver.DocumentRepository.CreateSave.IsEnabled().ToString();
               Support.AreEqual(@"False",Support.value);
                Support.value = FastDriver.DocumentRepository.TemplateDescription.FAGetValue();
                Support.AreEqual(@"abcdefghijklmnopqrstuvwxyz7890123456789*", Support.value);

                Reports.TestStep = "Select a form on Filtered Temp tab";
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.TemplateDescription.FASetText(" ");
                FastDriver.DocumentRepository.FindNow.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchResultsTable.PerformTableAction(3,"Form",3,TableAction.Click);

                Reports.TestStep = "Verify If Delivery is disabled and others are enabled";
                FastDriver.DocumentRepository.WaitForScreenToLoad();

               Support.value = FastDriver.DocumentRepository.CreateEdit.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.CreateSave.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.Deliver.IsEnabled().ToString();
               Support.AreEqual(@"False",Support.value);
               Support.value = FastDriver.DocumentRepository.FindNow.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.NewSearch.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
                //Assuming that user profile allows for scanning authority, scan button is enabled
               Support.value = FastDriver.DocumentRepository.Scan.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
                //Assuming that user profile allows for scanning authority upload button is enabled
               Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.Add.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);

                //ends here 
                Reports.TestStep = "Select a lenders Policy on Filtered Temp tab";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchResultsTable.PerformTableAction(3, "Lender Policy", 3, TableAction.Click);

                Reports.TestStep = "Verify If Delivery and create edit is disabled and others are enabled on Filtered Temp tab";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Playback.Wait(2000);
               Support.value = FastDriver.DocumentRepository.Method.FAGetText();
               Support.data = "PRINTFAXEMAILPREVIEWIMAGEDOC ";
                //adding as per fd
                Support.AreEqual(Support.data,Support.value);
               Support.value = FastDriver.DocumentRepository.Deliver.IsEnabled().ToString();
               Support.AreEqual(@"False",Support.value);
               Support.value = FastDriver.DocumentRepository.CreateEdit.IsEnabled().ToString();
               Support.AreEqual(@"False",Support.value);
               Support.value = FastDriver.DocumentRepository.CreateSave.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);

                //adding as per fd comment no. 122
               Support.value = FastDriver.DocumentRepository.FindNow.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.NewSearch.IsEnabled().ToString();

               Support.AreEqual(@"True",Support.value);
                //Assuming that user profile allows for scanning authority, scan button is enabled
               Support.value = FastDriver.DocumentRepository.Scan.IsEnabled().ToString();

               Support.AreEqual(@"True",Support.value);
                //Assuming that user profile allows for scanning authority upload button is enabled
               Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();

               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.Add.IsEnabled().ToString();

               Support.AreEqual(@"True",Support.value);
               FastDriver.BottomFrame.Reset();
                //ends here
                //..........ends here

                Reports.TestStep = "Verify Filtered Temp Tab is shown when no doc in Doc Repo";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                Reports.TestStep = "Select a Owner Policy on Filtered Temp tab";
                FastDriver.DocumentRepository.WaitForScreenToLoad();

                Playback.Wait(10000);
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                 FastDriver.DocumentRepository.WaitForDocumentRepositoryTemplatesScreenToLoad();
                 FastDriver.DocumentRepository.SearchResultsTable.PerformTableAction(3, "Owner Policy", 3, TableAction.Click);
              

                Reports.TestStep = "Verify If Delivery and create edit is disabled and others are enabled on Filtered Temp tab";

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Playback.Wait(2000);

               Support.value = FastDriver.DocumentRepository.Method.FAGetText();
               Support.data = "PRINTFAXEMAILPREVIEWIMAGEDOC ";
                //adding as per fd

                Support.AreEqual(Support.data,Support.value);
               Support.value = FastDriver.DocumentRepository.Deliver.IsEnabled().ToString();

               Support.AreEqual(@"False",Support.value);
               Support.value = FastDriver.DocumentRepository.CreateEdit.IsEnabled().ToString();

               Support.AreEqual(@"False",Support.value);
               Support.value = FastDriver.DocumentRepository.CreateSave.IsEnabled().ToString();

               Support.AreEqual(@"True",Support.value);

                //adding as per fd comment no. 122
               Support.value = FastDriver.DocumentRepository.FindNow.IsEnabled().ToString();

               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.NewSearch.IsEnabled().ToString();

               Support.AreEqual(@"True",Support.value);
                //Assuming that user profile allows for scanning authority, scan button is enabled
               Support.value = FastDriver.DocumentRepository.Scan.IsEnabled().ToString();

               Support.AreEqual(@"True",Support.value);
                //Assuming that user profile allows for scanning authority upload button is enabled
               Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.Add.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);

                Reports.TestStep = "Select a lenders Policy on Filtered Temp tab";
                FastDriver.DocumentRepository.WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.SearchResultsTable.PerformTableAction(3, "Lender Policy", 3, TableAction.Click);

                Reports.TestStep = "Verify If Delivery and create edit is disabled and others are enabled on Filtered Temp tab";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Playback.Wait(2000);

               Support.value = FastDriver.DocumentRepository.Method.FAGetText();
               Support.data = "PRINTFAXEMAILPREVIEWIMAGEDOC ";
                Support.AreEqual(Support.data,Support.value);
               Support.value = FastDriver.DocumentRepository.Deliver.IsEnabled().ToString();
               Support.AreEqual(@"False",Support.value);
               Support.value = FastDriver.DocumentRepository.CreateEdit.IsEnabled().ToString();
               Support.AreEqual(@"False",Support.value);
               Support.value = FastDriver.DocumentRepository.CreateSave.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.FindNow.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.NewSearch.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
                //Assuming that user profile allows for scanning authority, scan button is enabled
               Support.value = FastDriver.DocumentRepository.Scan.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
                //Assuming that user profile allows for scanning authority upload button is enabled
               Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);
               Support.value = FastDriver.DocumentRepository.Add.IsEnabled().ToString();
               Support.AreEqual(@"True",Support.value);

                Reports.TestStep = "Click on Find Now Button";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.TemplateDescription.FASetText("");
                FastDriver.DocumentRepository.FindNow.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "To wait till the Button add is displayed";
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "To check if ad hoc documents page is displayed";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
               Support.value = FastDriver.AdHocDocuments.State.IsVisible().ToString();
               Support.AreEqual(@"True",Support.value);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void DPUC0009_FD2()
        {

            try
            {

                Reports.TestDescription = "Field Definitions 6.6.2, 6.6.3";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "select title report doc and click on edit using short keys.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
              
                Playback.Wait(5000);

                Reports.TestStep = "Click on Edit Name button using hot keys : alt + E";
                Keyboard.SendKeys("%E");
                Playback.Wait(5000);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.DocumentPreparationMenu.menuDocument.Exists().ToString());
                FastDriver.BottomFrame.Done();

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
                Reports.TestStep = "Click on details using details button using hot keys : alt + L";
                Keyboard.SendKeys("%L");
                Playback.Wait(5000);
                FastDriver.DocumentDetailsScreen.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.DocumentDetailsScreen.DocID.Exists().ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Add Button.";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Playback.Wait(5000);
                
                Support.value = FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                if (Support.value == "True")
                {
                    FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.FAClick();

                    Playback.Wait(4000);

                    Reports.TestStep = "Verify for View Delivery Instruction dialog";
                    FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                    Playback.Wait(2000);
                    Support.AreEqual(@"True",FastDriver.ViewDeliveryInstrucionsDlg.Imagedoc.Exists().ToString());

                    Reports.TestStep = "Click on cancel in Dialog Box.";
                   FastDriver.DialogBottomFrame.ClickCancel();
                }
                else
                {
                    Reports.StatusUpdate("Distribution and delivery dialog is disabled. Verify failed", true);
                }
                //..........................................................Ends here

                //check no publish Ellipse for non image doc

                Reports.TestStep = "Select All items from search type.";
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("All Items");
                Playback.Wait(30000);

                FastDriver.DocumentRepository.WaitForScreenToLoad();
               Support.value= FastDriver.DocumentRepository.EditnameButton.IsEnabled().ToString();
                Support.AreEqual("True", Support.value);
               
                // check ends here
                Reports.TestStep = "Click on Add Button.";
               
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Add a Form";
               
                 FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem("Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem("Form");
                FastDriver.AdHocDocuments.FindNow.FAClick();

                Playback.Wait(6000);
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type","Form","Type",TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();

                Playback.Wait(5000);

                Reports.TestStep = "Select a Form";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                 FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 6, TableAction.Click);

                Reports.TestStep = "Verify Button status when a template is selected.";
                Playback.Wait(2000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Playback.Wait(2000);
                Support.value = FastDriver.DocumentRepository.Method.FAGetText();
                Support.data = "PRINTFAXEMAILPREVIEWIMAGEDOC ";
                Support.AreEqual(Support.data, Support.value);
                Support.value = FastDriver.DocumentRepository.Deliver.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.Scan_DocsTab.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();

                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.AddDocRep.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.SearchType.FAGetText();

                Support.data = "All Items FAST Document Images Recorded Documents Removed Items Search Results";
                Support.AreEqualTrim("True", Support.value.Contains(Support.data).ToString());
                Support.value = FastDriver.DocumentRepository.RecordedDocsRequest.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.ScheduleBDocs.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Edit.IsEnabled().ToString();

                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.Remove.IsEnabled().ToString();

                Support.AreEqual(@"True", Support.value);

                Support.value = FastDriver.DocumentRepository.Associate.IsEnabled().ToString();

                Support.data = "False";//true when associate package is created.

                Support.AreEqual(Support.data, Support.value);

                Support.value = FastDriver.DocumentRepository.RTMPackage.IsEnabled().ToString();

                Support.AreEqual(@"True", Support.value);

                Reports.TestStep = "Click on Remove button using short keys.";
                Playback.Wait(5000);

                FastDriver.DocumentRepository.WaitForScreenToLoad();

                Keyboard.SendKeys("%R");

                Playback.Wait(10000);

                Reports.TestStep = "Click on Upload button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Upload.FAClick();

                Playback.Wait(5000);

                Reports.TestStep = "Browse document and upload a pdf.";
                UploadPDFDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                Playback.Wait(500);

                Playback.Wait(5000);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);

                Reports.TestStep = "Select Images from search type.";
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();

                FastDriver.DocumentRepository.SearchType.FASelectItem("Images");
                Playback.Wait(30000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string c = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous test ", 4, TableAction.GetText).Message.ToString();
                Support.AreEqual("Miscellaneous test", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous test", 4, TableAction.GetText).Message.ToString());
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous test", 4, TableAction.Click);
                FastDriver.DocumentRepository.WaitForScreenToLoad();

                Support.value = FastDriver.DocumentRepository.Method.FAGetText();
                Support.data = "PRINTFAXEMAILPREVIEWIMAGEDOC ";
                Support.AreEqual(Support.data, Support.value);
                Support.value = FastDriver.DocumentRepository.Deliver.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.PublishButton.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.Scan_DocsTab.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.AddDocRep.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.SearchType.FAGetText();
                Support.AreEqualTrim("True", Support.value.Contains("All Items FAST Document Images Recorded Documents Removed Items Search Results").ToString());
                Support.value = FastDriver.DocumentRepository.RecordedDocsRequest.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.ScheduleBDocs.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Edit.IsEnabled().ToString();

                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Remove.IsEnabled().ToString();

                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.Associate.IsEnabled().ToString();
                Support.AreEqual("False", Support.value);
                Support.value = FastDriver.DocumentRepository.RTMPackage.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);

                Reports.TestStep = "Click on Remove button.";
                Playback.Wait(5000);

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Remove.FAClick();

                Playback.Wait(10000);

                Playback.Wait(5000);

                Reports.TestStep = "Select Remove items from search type.";
                Playback.Wait(5000);

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                Reports.TestStep = "Select a Form";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 4, TableAction.Click);
                Support.AreEqual("PREVIEW", FastDriver.DocumentRepository.Method.FAGetText());
                Support.value = FastDriver.DocumentRepository.Deliver.IsEnabled().ToString();
                Support.AreEqual("True", Support.value);
                Support.value = FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.PublishButton.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Scan_DocsTab.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Add.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.SearchType.FAGetText();
                Support.data = "All Items FAST Document Images Recorded Documents Removed Items Search Results ";
                Support.AreEqual("True", Support.value.Contains(Support.data).ToString());
                Support.value = FastDriver.DocumentRepository.Restore.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.value = FastDriver.DocumentRepository.EditnameButton.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Purge.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);//changed to true after clarification
                Support.value = FastDriver.DocumentRepository.RecordedDocsRequest.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.ScheduleBDocs.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Edit.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Remove.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Details.IsEnabled().ToString();   
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.De_archive.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Associate.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.RTMPackage.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);

                Reports.TestStep = "Select Escrow: Misc Document";
                Playback.Wait(3000);

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous test", 4, TableAction.Click);

                Reports.TestStep = "Verify Publish is enabled";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.value = FastDriver.DocumentRepository.Deliver.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.PublishButton.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.Scan.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Add.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.SearchType.FAGetText();
                
                Support.data = "All Items FAST Document Images Recorded Documents Removed Items Search Results ";
                Support.AreEqualTrim("True", Support.value.Contains(Support.data).ToString());
                Support.value = FastDriver.DocumentRepository.Restore.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.Purge.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);//changed to True after clarification
                Support.value = FastDriver.DocumentRepository.RecordedDocsRequest.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.ScheduleBDocs.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Edit.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Remove.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Details.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Associate.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.RTMPackage.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);

                Reports.TestStep = "Navigate to document Repository.";               
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);
                Reports.TestStep = "Verify Button status on Doc Repo";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Playback.Wait(2000);
                Support.value = FastDriver.DocumentRepository.Method.FAGetText();
                Support.data = "PRINTFAXEMAILPREVIEWIMAGEDOC ";
                Support.AreEqual(Support.data, Support.value);
                Support.value = FastDriver.DocumentRepository.Deliver.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.PublishButton.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.WMEllipsis.Exists().ToString();
                Support.value = FastDriver.DocumentRepository.Scan_DocsTab.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.Upload.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.AddDocRep.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.SearchType.FAGetText();               
                Support.data = "All Items FAST Document Images Recorded Documents Removed Items Search Results ";
                Support.AreEqual("True", Support.value.Contains(Support.data).ToString());
                Support.value = FastDriver.DocumentRepository.RecordedDocsRequest.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.ScheduleBDocs.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Edit.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Remove.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Details.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.Associate.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);
                Support.value = FastDriver.DocumentRepository.RTMPackage.IsEnabled().ToString();
                Support.AreEqual(@"False", Support.value);

                Reports.TestStep = "Select Multiple Docs and verify Button status";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                Support.value = FastDriver.DocumentRepository.Associate.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentRepository.RTMPackage.IsEnabled().ToString();
                Support.AreEqual(@"True", Support.value);

                Reports.TestStep = "Verify for lender policy.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);

                Reports.TestStep = "Click on Remove button.";
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Remove.FAClick();
                Playback.Wait(12000);

                Reports.TestStep = "Verify Publish Ellipsis is Disabled for non Image doc";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
                Support.value = FastDriver.DocumentRepository.PublishButton.IsEnabled().ToString();
                Support.value = FastDriver.DocumentRepository.WMEllipsis.Exists().ToString();

               
                Playback.Wait(12000);

               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void DPUC0009_FD3()
        {
            try
            {

                Reports.TestDescription = "Field Definitions 6.7.2, 6.7.3";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Click on Upload button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Upload.FAClick();

                Playback.Wait(5000);
                Reports.TestStep = "Browse document and upload a pdf.";
                UploadPDFDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                Playback.Wait(500);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Remove button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);

                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous test", 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Verify for Event Log is updation";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Playback.Wait(10000);
                Reports.TestStep = "Verify the document name. ";
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Removed Image]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains("Miscellaneous test").ToString());

                Reports.TestStep = "Verify the document type. ";
                Support.AreEqual("True", deposit.Contains("Escrow: Payoff Demand").ToString());

                Reports.TestStep = "Verify the delivery status";
                Support.AreEqual("True", deposit.Contains("Successful").ToString());

                Reports.TestStep = "Verify the user name";
                 Support.AreEqual("True", deposit.Contains("FAST QA07").ToString());

                 Reports.TestStep = "Select Remove items from search type.";
                 FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                 Playback.Wait(5000);
                 FastDriver.DocumentRepository.WaitForScreenToLoad();
                 FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                 FastDriver.DocumentRepository.WaitForScreenToLoad();
                string docname = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 4, TableAction.GetText).Message.ToString();
              Support.AreEqual("True", docname.Contains("Miscellaneous test").ToString());
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 4, TableAction.Click);
              Support.AreEqual("True",FastDriver.DocumentRepository.Restore.Enabled.ToString());
              FastDriver.DocumentRepository.Restore.FAClick();

              Reports.TestStep = "Verify the document is restored";
              FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
              Playback.Wait(5000);
                docname = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Escrow: Payoff Demand/...", 4, TableAction.GetText).Message.ToString();
             Support.AreEqual("True", docname.Contains("Miscellaneous test").ToString());

             FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Escrow: Payoff Demand/...", 10, TableAction.Click);
                //FastDriver.DocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[2].FindElements(By.TagName("TD"))[9].FindElement(By.TagName("INPUT")).FADoubleClick();

             Reports.TestStep = "Verify File No is disabled";
             Playback.Wait(1000);
             FastDriver.EditDocumentDlg.WaitForScreenToLoad();
             Support.AreEqual("False", FastDriver.EditDocumentDlg.FileNo.Enabled.ToString());

             Reports.TestStep = "Verify Doc Name is enabled";
             Playback.Wait(1000);
             FastDriver.EditDocumentDlg.WaitForScreenToLoad();
             Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocumentName.Enabled.ToString());

             Reports.TestStep = "Verify Document Type is disabled";
             Playback.Wait(1000);
             FastDriver.EditDocumentDlg.WaitForScreenToLoad();
             Support.AreEqual("False", FastDriver.EditDocumentDlg.DocumentType.Enabled.ToString());

             Reports.TestStep = "Verify Comments field is disabled";
             Playback.Wait(1000);
             FastDriver.EditDocumentDlg.WaitForScreenToLoad();
             Support.AreEqual("False", FastDriver.EditDocumentDlg.Comment.Enabled.ToString());

             Reports.TestStep = "Verify Create Copy field is enabled";
             Playback.Wait(1000);
             FastDriver.EditDocumentDlg.WaitForScreenToLoad();
             Support.AreEqual("False", FastDriver.EditDocumentDlg.CreateCopy.Enabled.ToString());

             FastDriver.DialogBottomFrame.ClickCancel();

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void DPUC0009_FD4()
        {
            try
            {

                Reports.TestDescription = "Field Definitions 6.8.2, 6.8.2";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Click on Upload button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Upload.FAClick();

                Playback.Wait(5000);
                Reports.TestStep = "Browse document and upload a pdf.";
                UploadPDFDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                Playback.Wait(500);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Derails button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                Playback.Wait(5000);

                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous test", 4, TableAction.Click);
                FastDriver.DocumentRepository.Details.FAClick();
                Reports.TestStep="Verify the Image Doc details in Image Details Page";
                FastDriver.ImageDetails.WaitForScreenToLoad();
                string documentdetails = FastDriver.ImageDetails.Table.FAGetText();
                Support.AreEqual("True", documentdetails.Contains("Active").ToString());
                Support.AreEqual("True", documentdetails.Contains("Comments   Source ID - " + fileNumber).ToString());
                string date=DateTime.Now.ToUniversalTime().AddHours(-8).ToString("M/d/yyyy").ToString();
                Support.AreEqual("True", documentdetails.Contains(date).ToString());
                Support.AreEqual("True", documentdetails.Contains("Pages").ToString());
                Support.AreEqual("True", documentdetails.Contains("Status Change Date").ToString());
                Support.AreEqual("True", documentdetails.Contains("Status Changed By").ToString());
                Support.AreEqual("True", documentdetails.Contains("Modified Date ").ToString());
                Support.AreEqual("True", documentdetails.Contains("Image Edit Status").ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD5()
        {
            try
            {

                Reports.TestDescription = "Field Definitions 6.9.2, 6.9.3";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add Title Report and Lender policy document";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.Exceptions.FASetText("CCCC/ABC1");
                FastDriver.DocumentRepository.btnInfoSave.FAClick();
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");

                Reports.TestStep = "Create One more File and Copy all the document form the already created";
                IISLOGIN();
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                Reports.TestStep = "Create File using web service.";
                string secondfile = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(secondfile);
                FileNo = FileService.GetFilesByFileNum(secondfile.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;


                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(fileNumber);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                Playback.Wait(1000);
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Navigate to Document Repository screen and verify the document are added";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("Automation Test Title Report", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.GetText).Message);

                Reports.TestStep = "Verify the exceptions/requirements from inheritable documents.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForWindowToLoad();
                Support.AreEqual("CCCC/ABC1", FastDriver.DocumentInfo.Exceptions.FAGetText());


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD6()
        {
            try
            {

                Reports.TestDescription = "Field Definitions 6.10.2, 6.10.3";

                #region region Basic File Creation
                CheckAssignNumADM(false);
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Select the Lender Policy and Click on Info Tab.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Select the Lender Policy and Click on Edit to get the Policy to Created state.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(10000);
                FastDriver.BottomFrame.Done();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("Created", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 9, TableAction.GetText).Message.ToString());

                Reports.TestStep = "Select the Lender Policy and Click on Edit to finalize.";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.AssignNum.FAClick();
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                Playback.Wait(10000);
                FinalizeDocumentthroughUI();

                Reports.TestStep = "Select the Lender Policy and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Playback.Wait(5000);

                Reports.TestStep = "Validate the Lenders Policy";
                Support.value = FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue();
                Support.AreEqual("LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", Support.value);
                Support.value = FastDriver.DocumentInfo.Buyeramount.Exists().ToString();

                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentInfo.Selleramount.Exists().ToString();

                Support.AreEqual("True", Support.value);
                Support.value = FastDriver.DocumentInfo.TitlePolicyInfoSave.IsEnabled().ToString();

                Support.AreEqual("True", Support.value);

                Reports.TestStep = "Verify the Buttons and Document name on lenders policy";
                Support.value = FastDriver.DocumentInfo.LenderCopyFrom.Enabled.ToString();
                Support.AreEqual("False", Support.value);

                FastDriver.DocumentInfo.PolicyNum.FASetText("ASDFGHJKL1");

                FastDriver.DocumentInfo.LenderOwnerDescription.FASetText("!@#$%^&*()_+$%^&*()_ asjkfhaklsdfhk96332");
                Support.value = FastDriver.DocumentInfo.Buyeramount.Exists().ToString();

                Support.AreEqual("True", Support.value);
                Support.value = FastDriver.DocumentInfo.Selleramount.Exists().ToString();

                Support.AreEqual("True", Support.value);
                Support.value = FastDriver.DocumentInfo.LiabilityAmount.FAGetText();

                Support.AreEqual("$5,000.00", Support.value);
                Support.value = FastDriver.DocumentInfo.SalesLiabilityAmount.FAGetText();

                Support.AreEqual("$5,000.00", Support.value);

                Support.value = FastDriver.DocumentInfo.Exceptions1.IsEnabled().ToString();
                Support.AreEqual("True", Support.value);

                Support.value = FastDriver.DocumentInfo.Waived.IsEnabled().ToString();

                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DocumentInfo.TitlePolicyInfoSave.IsEnabled().ToString();

                Support.AreEqual(@"True", Support.value);

                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD7()
        {
            try
            {

                Reports.TestDescription = "Field Definitions 6.10.2, 6.10.3";

                #region region Basic File Creation
                CheckAssignNumADM(true);
                IISLOGIN();
                CreateBasicFile();
                FastDriver.FileHomepage.AddFileProduct("*ALTA Extended Loan Policy");
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Request for Policy Number";
                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number").WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem(@"First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                Playback.Wait(1000);
                FastDriver.RequestPolicyNumber.Table.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                Playback.Wait(10000);


                Reports.TestStep = "Select the Lender Policy and Click on Info Tab.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Select the Lender Policy and Click on Edit to get the Policy to Created state.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(10000);
                FastDriver.BottomFrame.Done();
                FastDriver.DocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Select the Lender Policy and Assign Policy Number button";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.AssignPolicyNumber.FAClick();
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Verify the Policy Nmber Field is disabled";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DocumentInfo.PolicyNum.Enabled.ToString());

                Reports.TestStep = "Prevent the File Number as a Policy Number";
                Support.AreEqual("False", FastDriver.DocumentInfo.PolicyNum.FAGetText().Contains(fileNumber).ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD8()
        {

            Reports.TestDescription = "Make business party Etitle enabled";
            Reports.StatusUpdate("Functionality has covered in DPUC0009_REG59", true);
        }

        [TestMethod]
        public void DPUC0009_FD8A()
        {
            try
            {

                Reports.TestDescription = "DP14532 Assign AgentNet Policy Number Before Policy Issue Date";

                #region region Basic File Creation
                CheckAssignNumADM(true);
                IISLOGIN();
                CreateBasicFile();
                FastDriver.FileHomepage.AddFileProduct("*ALTA Extended Loan Policy");
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Request for Policy Number";
                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number").WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem(@"First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                Playback.Wait(1000);
                FastDriver.RequestPolicyNumber.Table.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                Playback.Wait(10000);


                Reports.TestStep = "Select the Lender Policy and Click on Info Tab.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Select the Lender Policy and Click on Edit ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(10000);
                FastDriver.BottomFrame.Done();
                FastDriver.DocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Issue date field is disabled when the Assign Policy Number was not assigned";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DocumentInfo.IssueDate.Enabled.ToString());

                Reports.TestStep = "Click Assign Policy Number and enter issue date";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.AssignPolicyNumber.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.IssueDate.FASetText(DateTime.Now.AddDays(-2).ToDateString());
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Support.AreEqual((DateTime.Now.AddDays(-2).ToDateString()), FastDriver.DocumentInfo.IssueDate.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD8B()
        {
            try
            {

                Reports.TestDescription = "DP14532 Assign AgentNet Policy Number Before Policy Issue Date";

                #region region Basic File Creation
                CheckAssignNumADM(true);
                IISLOGIN();
                CreateBasicFile();
                FastDriver.FileHomepage.AddFileProduct("*ALTA Extended Loan Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Loan Policy");
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Request for Policy Number";
                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number").WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem(@"First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                Playback.Wait(1000);
                FastDriver.RequestPolicyNumber.Table.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                Playback.Wait(10000);
                FastDriver.RequestPolicyNumber.WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Table.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                Playback.Wait(10000);


                Reports.TestStep = "Select the Lender Policy and Click on Info Tab.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

                Reports.TestStep = "Select the Lender Policy and Click on Edit ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(10000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Assign Policy Number and verify the assign policy number dialog";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.AssignPolicyNumber.FAClick();

                FastDriver.PolicyNumberListDlg.SwitchToDialogContentFrame();
                string policynumberDlg = FastDriver.PolicyNumberListDlg.Select.Exists().ToString();
                Support.AreEqual("True", policynumberDlg);
                FastDriver.PolicyNumberListDlg.Select.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD9()
        {

            try
            {
                Reports.TestDescription = "Field Definitions 6.14.2,6.14.3";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Select the Title Report Document and Click on Info Tab.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Enter effective date and click on Save.";
                AddEffectiveDatetoDocument("Automation Test Title Report");

                Reports.TestStep = "Select the Lender policy and Click on Info Tab.";
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");


                Reports.TestStep = "Select the owner policy and Click on Info Tab.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Owner Plolicy", "ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", "CA");

                Reports.TestStep = "Select all the documents and click on Associate";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();

                Reports.TestStep = "Associated Documents Sequencing dialog.";
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.AssocDocSeqDlg.PackageIDName.FASetText("Associated package1");

                Reports.TestStep = "Remove a Document from Associated Documents Sequencing dialog.";
                FastDriver.AssocDocSeqDlg.DocumentTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.AssocDocSeqDlg.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                Support.AreNotEqual("Automation Test Title Report", FastDriver.AssocDocSeqDlg.DocumentTable.PerformTableAction(2, 2, TableAction.GetCell).Message.ToString());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select the Title Report Document.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
                FastDriver.DocumentRepository.Associate.FAClick();
                FastDriver.DialogBottomFrame.ClickCancel();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD10()
        {

            try
            {
                Reports.TestDescription = "Field Definitions 6.16.2, 6.16.3";
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = " Add a Title Policy document ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");


                Reports.TestStep = "Add two Lender Policy documents";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "Short Form Commercial LP (6-2000)-N");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Lender Policy", "LenderPolicyforDP0009FV", "CA");

                Reports.TestStep = "Add a Endorsement document and Link to Policy";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Endorsement/Guarantee", "0 Template For DP0007c BAT", "CA");
                FastDriver.TitleSelection.WaitForScreenToLoad();

                Reports.TestStep = "Verify that select button is enabled. ";
                Support.AreEqual("True", FastDriver.TitleSelection.Select.Enabled.ToString());
                FastDriver.TitleSelection.Select.FAClick();
                FastDriver.DocumentRepository.WaitForPageToLoad();
                Support.AreEqual("0 Template For DP0007c BAT", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(3, 4, TableAction.GetText).Message.ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD11()
        {

            try
            {
                Reports.TestDescription = "Field Definitions 7.3.1, 7.3.2";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Verify Associate document tab. ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();

                Reports.TestStep = "Verify that no associate document are present and Remove and modify buttons are disabled. ";

                Playback.Wait(4000);
                FastDriver.AssociateDocs.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.AssociateDocs.Remove.Enabled.ToString());
                Support.AreEqual("False", FastDriver.AssociateDocs.Modify.Enabled.ToString());

                Reports.TestStep = "create mutiple documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");


                Reports.TestStep = "Select all the documents and click on Associate";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();

                Reports.TestStep = "Associated Documents Sequencing dialog.";
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.AssocDocSeqDlg.PackageIDName.FASetText("Associated package1");


                Reports.TestStep = "Check remove up and down button disabled.";
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.AssocDocSeqDlg.Remove.Enabled.ToString());
                Support.AreEqual("False", FastDriver.AssocDocSeqDlg.Up.Enabled.ToString());
                Support.AreEqual("False", FastDriver.AssocDocSeqDlg.Down.Enabled.ToString());

                Reports.TestStep = "Select first row and verify that Down button is enabled.";
                FastDriver.AssocDocSeqDlg.DocumentTable.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.AssocDocSeqDlg.Remove.Enabled.ToString());
                Support.AreEqual("False", FastDriver.AssocDocSeqDlg.Up.Enabled.ToString());
                Support.AreEqual("True", FastDriver.AssocDocSeqDlg.Down.Enabled.ToString());

                Reports.TestStep = "Click on down button and verify that Down button is disabled and up button is enabled.";
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.AssocDocSeqDlg.Down.Click();
                Playback.Wait(5000);
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.AssocDocSeqDlg.Remove.Enabled.ToString());
                Support.AreEqual("True", FastDriver.AssocDocSeqDlg.Up.Enabled.ToString());
                Support.AreEqual("False", FastDriver.AssocDocSeqDlg.Down.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Validate that The system shall prevent the user from removing more than one document at a time (no multi select).";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.AssocDocSeqDlg.SelectAllDocuments();
                Support.AreEqual("True", FastDriver.AssocDocSeqDlg.Remove.Enabled.ToString());

                Reports.TestStep = "Select first row and verify that Down button is enabled and up button is disabled.";
                FastDriver.AssocDocSeqDlg.DocumentTable.PerformTableAction(1, 2, TableAction.Click);
                Support.AreEqual("True", FastDriver.AssocDocSeqDlg.Remove.Enabled.ToString());
                Support.AreEqual("False", FastDriver.AssocDocSeqDlg.Up.Enabled.ToString());
                Support.AreEqual("True", FastDriver.AssocDocSeqDlg.Down.Enabled.ToString());

                Reports.TestStep = "Click on down button and verify that Down button is disabled and up button is enabled.";
                FastDriver.AssocDocSeqDlg.DocumentTable.PerformTableAction(3, 2, TableAction.Click);
                Support.AreEqual("True", FastDriver.AssocDocSeqDlg.Remove.Enabled.ToString());
                Support.AreEqual("True", FastDriver.AssocDocSeqDlg.Up.Enabled.ToString());
                Support.AreEqual("False", FastDriver.AssocDocSeqDlg.Down.Enabled.ToString());

                Reports.TestStep = "System displays message if user highlights a document on the Associated Documents Sequencing dialog and clicks the Remove button. User clicks OK to remove the document from the package.";
                FastDriver.AssocDocSeqDlg.Remove.FAClick();
                Support.AreEqual("Remove highlighted document from Associated Documents package?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "check that package name do not exceed 75 character";
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.AssocDocSeqDlg.PackageIDName.FASetText("Checkingifpackagenameallowsmaximumofseventyfivecharactersssdfsasfs687072747678");
                FastDriver.AssocDocSeqDlg.PackageIDName.FASendKeys(Keys.Tab);
                Support.AreEqual("75", FastDriver.AssocDocSeqDlg.PackageIDName.FAGetValue().Length.ToString());


                Reports.TestStep = "check that package name do not accept some character";
                FastDriver.AssocDocSeqDlg.WaitForScreenToLoad();
                FastDriver.AssocDocSeqDlg.PackageIDName.FASetText("Checking!123~");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);
                Support.AreEqual("Package Name may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_FD12()
        {
            try
            {
                Reports.TestDescription = "Field Definitions 7.6.1,7.6.2,7.11.2,7.11.3,7.11.4";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Verify that no associate document are present and Remove and modify buttons are disabled. ";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.AssociateDocs.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.AssociateDocs.Remove.Enabled.ToString());
                Support.AreEqual("False", FastDriver.AssociateDocs.Modify.Enabled.ToString());


                Reports.TestStep = " Add a Title Policy document ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Select document and Click on the associate button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Add one more document to doc rep and associate";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Template FOr TFS101656");
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();

                Reports.TestStep = "Verify that  done button is disabled. ";
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.WaitCreation(FastDriver.DialogBottomFrame.btnDone);
                Support.AreEqual("False", FastDriver.DialogBottomFrame.btnDone.Enabled.ToString());

                Reports.TestStep = "Verify that  create new package button is unselected. ";
                FastDriver.DocPackageDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.DocPackageDlg.CreateNewPackage.Enabled.ToString());
                Support.AreEqual("False", FastDriver.DocPackageDlg.SelectPackage1.Selected.ToString());

                Reports.TestStep = "Select the first package ";
                FastDriver.DocPackageDlg.CreateNewPackage.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();





                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD13()
        {

            try
            {
                Reports.TestDescription = "Field Definitions 7.8.2,7.8.3,7.9.2,7.9.3, 7.10.1,7.10.2";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "create mutiple documents";
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "ATP-Commitment -N");

                Reports.TestStep = "Click RTM package button.";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.RTMPackage.FAClick();

                FastDriver.RTM.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.RTM.Color.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.RTM.RemoveDocument.Enabled.ToString());
                Support.AreEqual("False", FastDriver.RTM.Up.Enabled.ToString());
                Support.AreEqual("False", FastDriver.RTM.Down.Enabled.ToString());

                FastDriver.RTM.Remove.FAClick();
                Support.AreEqual("Remove RTM Package?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Select the Mutiple Document. and click on RTM button";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.RTMPackage.FAClick();

                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.Color.FAClick();
                Support.AreEqual("True", FastDriver.RTM.RemoveDocument.Enabled.ToString());
                Support.AreEqual("False", FastDriver.RTM.Up.Enabled.ToString());
                Support.AreEqual("True", FastDriver.RTM.Down.Enabled.ToString());

                Reports.TestStep = "Click on down button.";
                FastDriver.RTM.Down.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RTM.RemoveDocument.Enabled.ToString());
                Support.AreEqual("True", FastDriver.RTM.Up.Enabled.ToString());
                Support.AreEqual("False", FastDriver.RTM.Down.Enabled.ToString());

                Reports.TestStep = "Delivery method REAL TIME MAIL option is present in RTM Package tab. ";
                FastDriver.RTM.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RTM.DeliverMethod.FAGetText().ToString().Contains("REAL TIME MAIL").ToString());


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD13A()
        {
            try
            {

                Reports.TestDescription = "DP11011 Linking Endorsement to Policy w/o Title Reports";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Add two Policy w/o Title Reports  Documents ";
                CreateDocumentusingWCFService(DocTemplateTypeId: 82, DocName: "Template created for 6.3 updates");
                CreateDocumentusingWCFService(DocTemplateTypeId: 82, DocName: "1377 Document Security Filters");


                Reports.TestStep = "Add a Endorsement document and Link to Policy w/o Title";
                FastDriver.DocumentRepository.WaitForPageToLoad();
                FastDriver.DocumentRepository.AddDocRep.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", "Endorsement/Guarantee", "0 Template For DP0007c BAT", "CA");
                FastDriver.TitleSelection.WaitForScreenToLoad();
                FastDriver.TitleSelection.TitleReport.FAClick();
                FastDriver.TitleSelection.Select.FAClick();

                Reports.TestStep = "Validate the Docments sequence";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string policdocID = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "1377 Document Security Filters", 4, TableAction.Click).Element.GetParent().GetAttribute("id");

                int rowindex = (int.Parse(policdocID.Substring(policdocID.Length - 1)));
                policdocID = policdocID.Replace(rowindex.ToString(), (rowindex + 1).ToString()).ToString();
                string rowvalue = FastDriver.WebDriver.FAFindElement(ByLocator.Id, policdocID).FAFindElements(ByLocator.TagName, "td").ToList()[3].FAGetText();
                Support.AreEqual("0 Template For DP0007c BAT", rowvalue);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD14()
        {

            try
            {
                Reports.TestDescription = "Field Definitions 7.14.2,7.14.3,7.16.5";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Change Underwriter to new Underwriter";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItem("New Underwriter");
                alert();
                FastDriver.BottomFrame.Save();


                Reports.TestStep = " Add a Title Policy document ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.DocumentRepository.Exceptions.FASetText("CCCC/ABC1");
                FastDriver.DocumentRepository.btnInfoSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Add Lender Policy document";
                Thread.Sleep(100);
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Click on Copy From button.";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                FastDriver.DocumentInfo.LenderCopyFrom.FAClick();

                Reports.TestStep = "Copy Exceptions from other document";
                FastDriver.CopyFrom.WaitForScreenToLoad();
                FastDriver.CopyFrom.CheckBox1.FAClick();
                FastDriver.CopyFrom.List1.FAClick();

                Reports.TestStep = "Click on Select All";
                FastDriver.SelectExcReqInfNote.SwitchToDialogContentFrame();
                FastDriver.SelectExcReqInfNote.WaitCreation(FastDriver.SelectExcReqInfNote.SelectAllPhrase);
                FastDriver.SelectExcReqInfNote.SelectAllPhrase.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Add Phrases";
                FastDriver.CopyFrom.WaitForScreenToLoad();
                FastDriver.CopyFrom.CheckBox1.FASetCheckbox(true);
                FastDriver.CopyFrom.AddPhrases.FAClick();
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(1000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify exceptions are copied from lender doc to Title report doc";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Support.AreEqual("CCCC/ABC1", FastDriver.DocumentInfo.Exceptions1.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD15()
        {

            try
            {
                Reports.TestDescription = "Field Definitions  7.15.5,7.15.5";

                #region region Basic File Creation
                CheckAssignNumADM(false);
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = " Add a Title Policy document and edit it ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");
                AddEffectiveDatetoDocument("Automation Test Title Report");
                FastDriver.BottomFrame.Done();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(10000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Lender Policy document and edit it";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 6, DocName: "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(10000);
                FastDriver.BottomFrame.Done();

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.AssignNum.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Finalize Lender and Tile report documents";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                Playback.Wait(10000);
                FinalizeDocumentthroughUI();
                FastDriver.BottomFrame.Done();

                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
                Playback.Wait(10000);
                FinalizeDocumentthroughUI();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select all the documents and click on Associate";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments();
                FastDriver.DocumentRepository.Associate.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Perform PDC Delivery.";
                FastDriver.AssociateDocs.WaitForScreenToLoad();
                FastDriver.AssociateDocs.DeliverMethod.FASelectItem("PDC");
                FastDriver.AssociateDocs.DeliverButton.FAClick();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_FD16()
        {

            try
            {
                Reports.TestDescription = "Field Definitions 7.6.1,7.6.2,7.11.2,7.11.3,7.11.4";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = " Add a Title Policy document and edit it ";
                Thread.Sleep(10);
                CreateDocumentusingWCFService(DocTemplateTypeId: 4, DocName: "Automation Test Title Report");

                Reports.TestStep = "Verify that Recorded Docs Request button is enabled";
                Support.AreEqual("True", FastDriver.DocumentRepository.RecordedDocsRequest.Enabled.ToString());

                Reports.TestStep = "Verify that Schedule B Docs button is enabled";
                Support.AreEqual("False", FastDriver.DocumentRepository.ScheduleBDocs.Enabled.ToString());

                Reports.TestStep = "Click on Recorded Docs Request";
                FastDriver.DocumentRepository.RecordedDocsRequest.FAClick();

                FastDriver.RecordedDocsDlg.WaitForScreenToLoad();
                Playback.Wait(10000);
                Support.AreEqual("False", FastDriver.RecordedDocsDlg.Scan.Enabled.ToString());
                Support.AreEqual("False", FastDriver.RecordedDocsDlg.Add.Enabled.ToString());
                Support.AreEqual("False", FastDriver.RecordedDocsDlg.Submit.Enabled.ToString());
                Support.AreEqual("True", FastDriver.RecordedDocsDlg.Refresh.Enabled.ToString());
                Support.AreEqual("True", FastDriver.RecordedDocsDlg.State.Enabled.ToString());
                Support.AreEqual("True", FastDriver.RecordedDocsDlg.County.Enabled.ToString());

                FastDriver.RecordedDocsDlg.County.FASelectItem("Orange");
                Playback.Wait(10000);
                FastDriver.RecordedDocsDlg.WaitForScreenToLoad();
                FastDriver.RecordedDocsDlg.gdRecordedDocs0Select.FASetCheckbox(true);
                Support.AreEqual("Please Enter the Value for Required Field.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.RecordedDocsDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RecordedDocsDlg.Add.Enabled.ToString());
                Keyboard.SendKeys("933");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("15");
                Keyboard.SendKeys("{TAB}");
                FastDriver.RecordedDocsDlg.WaitForScreenToLoad();
                FastDriver.RecordedDocsDlg.Submit.FAClick();
                String status = null;

                for (int i = 0; i < 10; i++)
                {
                    if (status != "Completed")
                    {
                        FastDriver.RecordedDocsDlg.WaitForScreenToLoad();
                        FastDriver.RecordedDocsDlg.Refresh.FAClick();
                        FastDriver.RecordedDocsDlg.WaitForScreenToLoad();
                        status = FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(1, 13, TableAction.GetText).Message.ToString();
                    }
                }
                Support.AreEqual("Completed", FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(1, 13, TableAction.GetText).Message.ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Gap coverage 9.9 to 10.4
      
        //user story : 665700
        //Title      : REQ0717500 - NCS - FAE Region - Add SEC in front of 3 Doc Names
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif"), DeploymentItem(@"Common\Support\Hello.pdf")]
        public void DPUC0009_REG85()
        {
           
            try
            {
                Reports.TestStep = "Verify the document names are displaying while upload and scan in doc rep Secured Documents- CIP, Miscellaneous and REL Package prefixed with SEC";
               
               #region region Basic File Creation
                IISLOGIN("fastts\\fastqa01","F!rst@m1");
                CreateFileInFAERegion();
                #endregion

                #region GUI Intreaction
               
                UploadPDFDoc("Exchange : Secured", "SEC-CIP", "test");
                Playback.Wait(500);
                 Reports.TestStep = "Exchange Secured documents shall be prefixed with SEC";
                string sec_docnames = SaveDocumentDlg.documentname;
                Reports.TestStep = "Upload documents and verify the Secured documents are available";
                Support.AreEqual("True",sec_docnames.Contains("SEC-CIP").ToString());
                Support.AreEqual("True", sec_docnames.Contains("SEC-Misc").ToString());
                Support.AreEqual("True", sec_docnames.Contains("SEC-REL").ToString());
                FastDriver.BottomFrame.Done();

                 Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                Reports.TestStep = "Verify the SEC-CIP,SEC-Misc and SEC-REL Package documents are displaying";
               Support.AreEqual("SEC-CIPSEC-MiscSEC-REL Package", SaveDocument());
                

               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void DPUC0009_REG86()
        {

            try
            {
                Reports.TestDescription = "User story: 518150-Verify the use able to purge, delivered documents";

                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile(true);

                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Click on Scan Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button. and upload document";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click document and go for email delver";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);

                 Reports.TestStep = "Deliver the document";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.DocumentRepository.Method.FASelectItem("EMAIL");
                FastDriver.DocumentRepository.Deliver.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);

                Reports.TestStep="Remove the delvered document";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);
               FastDriver.DocumentRepository.Remove.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.DocumentRepository.Purge.FAClick();
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify for Event Log is updated with Purge Image";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");

                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Purged Image]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains("Image Name: INST-Estimated Settlement Statement PO-Invoice").ToString());
                
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void DPUC0009_REG87_PH()
        {
            try
            {

                Reports.TestDescription = "US#691992 # 213177-System shall finalize the document with Assumption loan Lender Policy Liability,User Story Create Doc Prep Data Elements for License Information ";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #endregion
        #region Private TestMethods
        private void CreateDirectory(string DirectoryName)
        {
            if (!Directory.Exists(DirectoryName))
            {
                Directory.CreateDirectory(DirectoryName);
            }
        }

        private void IISLOGIN(string UserName = null, string Password = null)
        {
            var credentials = new Credentials() { UserName = UserName, Password = Password };
            if (UserName == null)
            {
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            }
            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
        }

        private void CreateBasicFile()
        {

            var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

            Reports.TestStep = "Create File using web service.";
            fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);

            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            FileNo = FileService.GetFilesByFileNum(fileNumber.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;


        }
        private void CreateBasicFile(bool defaultrequest = true)
        {

            var fileRequest = RequestFactory.GetCreateFileDefaultRequest();

            Reports.TestStep = "Create File using web service.";
            fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);

            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            FileNo = FileService.GetFilesByFileNum(fileNumber.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;


        }

        private string fileNumber;
        private void CreateFullOrder([Optional] int file)
        {
            var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

            Reports.TestStep = "Create File using web service.";
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);


            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            FileNo = FileService.GetFilesByFileNum(fileNumber.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;

        }

        private int FileNo;
        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }

        private void CheckAssignNumADM(bool ANPolicyNumber=true)
        {

            Reports.TestStep = "Make assign num enabled";

            ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);

            Reports.TestStep = "Navigate to Region Level.";
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office");
            FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);

            Reports.TestStep = "Navigate to Auto cd office and check the Assign policy check box";
            FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").SwitchToContentFrame();
            FastDriver.OfficeSetupOffice.ANPolicyNumber.FASetCheckbox(ANPolicyNumber);
            FastDriver.BottomFrame.Done();
            Playback.Wait(1000);

        }

        private int TitleDocId;

        private void CreateDocumentusingWCFService(int DocTemplateTypeId, string DocName)
        {
            int documentId = 0;
            int templateID = 0;
            string DocumentName;
            string DocType;
            Reports.TestStep = "Create Document";
            var GetDocTempReq = FastDriver.DocumentRepository.GetDocTemplatesDefaultRequest(DocTemplateTypeId);
            var GetDocTempRes = FASTWCFHelpers.FileService.GetDocTemplates(GetDocTempReq);
            int des;
            for (des = 0; GetDocTempRes.Templates.Length - 1 >= des; des++)
            {

                if (GetDocTempRes.Templates[des].Descr == DocName)
                {
                    break;
                }
            }
            templateID = Convert.ToInt32(GetDocTempRes.Templates[des].TemplateID);
            DocumentName = GetDocTempRes.Templates[des].Descr.ToString();
            DocType = GetDocTempRes.Templates[des].TemplateType.ToString();

            Reports.TestStep = "Invoke CreateDocument service to create a document";
            var CreateDocReq = RequestFactory.GetCreateDocumentDefaultRequest(FileNo, templateID);
            CreateDocReq.TemplateID = templateID;
            CreateDocReq.FileID = FileNo;
            CreateDocReq.TitleReportDocumentID = TitleDocId;


            var CreateDocRes = FASTWCFHelpers.FileService.CreateDocument(CreateDocReq);
            documentId = Convert.ToInt32(CreateDocRes.DocumentID);
            TitleDocId = Convert.ToInt32(CreateDocRes.DocumentID);

            FastDriver.DocumentRepository.Open();
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, DocumentName, 4, TableAction.Click);

        }

        private void CreateRequestForAddProductusingWCF(string productname)
        {
            Reports.TestStep = "Construct AddProductRequest object.";
            FASTWCFHelpers.AdminService.GetAllProducts();
            int Product;
            int productid = 0;
            for (Product = 0; FASTWCFHelpers.AdminService.GetAllProducts().Products.Length - 1 >= Product; Product++)
            {
                if (FASTWCFHelpers.AdminService.GetAllProducts().Products[Product].ProductName == productname)
                {
                    productid = int.Parse(FASTWCFHelpers.AdminService.GetAllProducts().Products[Product].ProductID.ToString());
                    break;
                }
            }

            var request = new FASTWCFHelpers.FastFileService.AddProductRequest()
            {
                FielID = FileNo,
                Product = new FASTWCFHelpers.FastFileService.Product()
                {
                    ProductID = productid
                }
            };
            FASTWCFHelpers.FileService.AddProduct(request);
            //FASTWCFHelpers.FileService.GetFileService().AddProduct(request);
        }

        private void AddEffectiveDatetoDocument(string DocumentName)
        {
            FastDriver.DocumentRepository.DocumentsTab.FAClick();
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, DocumentName, 4, TableAction.Click);
            FastDriver.DocumentRepository.WaitForScreenToLoad();
            FastDriver.DocumentRepository.Info.FAClick();
            FastDriver.DocumentRepository.WaitForInfoTabToLoad();
            FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
            FastDriver.DocumentRepository.btnInfoSave.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
        }

        private void PhraseSelectionDlg()
        {
            Reports.TestStep = "Get pharse dialog";
            FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
            FastDriver.DocumentPreparationMenu.WaitCreation(FastDriver.DocumentPreparationMenu.Expand1);
            FastDriver.DocumentPreparationMenu.Expand1.Click();
            Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%p");
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%p");
            Playback.Wait(1000);
            //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
        }

        private void FinalizeDocument()
        {
            var FinalizeDocReq = RequestFactory.GetFinalizeDocumentRequest(FileNo, TitleDocId);
            var FinalizeDocRes = FASTWCFHelpers.FileService.FinalizeDocument(FinalizeDocReq);
        }

        private void FinalizeDocument(int DocNo)
        {
            var FinalizeDocReq = RequestFactory.GetFinalizeDocumentRequest(FileNo, DocNo);
            var FinalizeDocRes = FASTWCFHelpers.FileService.FinalizeDocument(FinalizeDocReq);
        }

        private void AddPhraseToTemplate()
        {
            Reports.TestStep = "Add Phrases to the Template";
            FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
            FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
            FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
            FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.PhraseName.FASetText("JVE/JV01");
            FastDriver.DialogBottomFrame.ClickDone();
        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        private void SetupforQCClosing()
        {
            try
            {
                Reports.TestDescription = "Setup for QC Closing.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to address book.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();

                Reports.TestStep = "Search for a gab code.";
                FastDriver.AddressBookSearch.SearchAddressBook("247");
                FastDriver.AddressBookSearch.EditAddress("247");

                Reports.TestStep = "Select QC @ Closing Client checkbox.";
                FastDriver.BusPartyOrgSetUp.QCClosingClient.FASetCheckbox(true);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        private void CreateFileInSandPointRegion()
        {

            Reports.TestStep = "Navigate to QA Automation Region-CD";
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.Office.FAClick();
            FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
            FastDriver.SecuritySelectRegionOffice.SearchbyBUID.FASetText("191" + FAKeys.Tab);
            Playback.Wait(5000);
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
            FastDriver.HomePage.WaitForHomeScreen();

            Reports.TestStep = "Create Order";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

            FastDriver.QuickFileEntry.WaitForScreenToLoad();

            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();

            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);

            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
            FastDriver.FileHomepage.WaitForScreenToLoad();
            fileNumber = FastDriver.FileHomepage.FileNum.FAGetValue().ToString();
        }

        private void CreateFileInCaliforniaRegion(string lender)
        {

            Reports.TestStep = "Navigate to QA Automation Region-CD";
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.Office.FAClick();
            FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
            FastDriver.SecuritySelectRegionOffice.SearchbyBUID.FASetText("10156" + FAKeys.Tab);
            Playback.Wait(5000);
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
            FastDriver.HomePage.WaitForHomeScreen();

            Reports.TestStep = "Create Order";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

            FastDriver.QuickFileEntry.WaitForScreenToLoad();

            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(lender);
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();

            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);

            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(lender);
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
            FastDriver.FileHomepage.WaitForScreenToLoad();
            fileNumber = FastDriver.FileHomepage.FileNum.FAGetValue().ToString();
        }

        private void UploadPDFDoc(string docType, string docName, string addtlInfo)
        {
            Reports.TestStep = "Navigate to Doc Repository and Click on Upload.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
            FastDriver.DocumentRepository.Upload.FAClick();

            Reports.TestStep = "Browse document and upload it (pdf).";
            if (!((Reports.DEPLOYDIR + "\\Hello.pdf").ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support.Hello.pdf", Reports.DEPLOYDIR + "\\Hello.pdf");
            }
            string FilePath = Reports.DEPLOYDIR + "\\Hello.pdf";
            FastDriver.UploadDocumentDlg.UploadFile(FilePath);

            Reports.TestStep = "Save Scanned doc,entering Name so that it will appear in Edit Disb Screen.";
            FastDriver.SaveDocumentDlg.SaveDocument(docType, docName, addtlInfo);
            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false);
            }
            catch (TimeoutException)
            {
                Reports.StatusUpdate("Saving... NoTitle window has closed fast.", true);
            }
        }

        private void FinalizeDocumentthroughUI()
        {
            Reports.TestStep = "Finalize the document";
            Playback.Wait(10000);
            FastDriver.DocumentRepository.WaitForScreenToLoad();
            FastDriver.DocumentRepository.Edit.FAClick();
            Playback.Wait(2000);
            FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
            FastDriver.DocumentPreparationMenu.WaitCreation(FastDriver.DocumentPreparationMenu.Expand1);
            FastDriver.DocumentPreparationMenu.Expand1.Click();
            Playback.Wait(2000);
            Keyboard.SendKeys("%o");
            Playback.Wait(1000);
            Keyboard.SendKeys("%z");
            Playback.Wait(4000);
            FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
            FastDriver.DocPrepTextEditorDlg.Note.FASetText("Finalize the document");
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
        }

        private void DataElementPropertiesDlg()
        {
            BrowserWindow wnd = new BrowserWindow();
            wnd.SearchProperties.Add("Name", "FAST", PropertyExpressionOperator.Contains);
            HtmlDocument fraviewdoc = new HtmlDocument(wnd);
            HtmlIFrame frame = new HtmlIFrame(fraviewdoc);
            frame.SearchProperties.Add("Id", "FAFDialog_1_iframe", PropertyExpressionOperator.EqualTo);
            
            fraviewdoc = new HtmlDocument(frame);
            HtmlIFrame innerframe = new HtmlIFrame(fraviewdoc);
            innerframe.SearchProperties.Add("Id", "fraPageWin", PropertyExpressionOperator.EqualTo);
            bool t = innerframe.Exists;
            HtmlDocument DOC = new HtmlDocument(innerframe);
            HtmlEdit index = new HtmlEdit(DOC);
            index.SearchProperties.Add("Id", "txtIndex", PropertyExpressionOperator.EqualTo);
           t= index.Exists;
            index.Text = "?";

            HtmlButton ok = new HtmlButton(DOC);
            ok.SearchProperties.Add("Id", "cmdsave", PropertyExpressionOperator.EqualTo);
            Mouse.Click(ok);
           
        }

        private string alert(bool clickAcceptButton = true)
        {
            string alertText = null;
            string WinDlg = "[TITLE:Message from webpage;CLASS:#32770]";
            if (AutoItX.WinExists(WinDlg) != 0)
            {
                AutoItX.WinActivate(WinDlg);
                alertText = AutoItX.ControlGetText(WinDlg, "", "[CLASS:Static; INSTANCE:2]");
                if (!clickAcceptButton)
                    AutoItX.Send("{SPACE}");    // to switch from default button

                AutoItX.Send("{ENTER}");
                Reports.UpdateDebugLog("AutoIt", "Alert", "Handle Dialog*", "", "", alertText, Reports.Result(true), "");
            }
            return alertText;
        }
        private void selectitem(IWebElement element,string selectitem)
        {
            //element.FAClick();
            List<IWebElement> options = element.FAFindElements(ByLocator.TagName, "option").ToList();
            for(int i=0;i<=options.Count-1;i++)
            {
                 if(options[i].Text.ToString()==selectitem)
                {
                     options[i].FAClickAction();
                     break;
                 }

            }
            
        }

        private void CreateFilethroughUI()
        {

            Reports.TestStep = "Navigate to QA Automation Region DO NOT TOUCH";

            Reports.TestStep = "Create Order";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

            FastDriver.QuickFileEntry.WaitForScreenToLoad();

            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();

            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);

            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
            FastDriver.FileHomepage.WaitForScreenToLoad();
            fileNumber = FastDriver.FileHomepage.FileNum.FAGetValue().ToString();
        }

        private void CreateFileInFAERegion()
        {
            Reports.TestStep = "Login to FAST FAE application ";
            FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry");
            FastDriver.ExchangeFileEntry.WaitForScreenToLoad();

            FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Reverse / Construction");
            FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
           FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemByIndex(2);
           FastDriver.BottomFrame.Done();
           
        }

        private string SaveDocument()
        {
            WinWindow win_save = new WinWindow();
            win_save.SearchProperties.Add("Name", "Save Document");
            win_save.SearchProperties.Add("ClassName", "ThunderRT6FormDC");
            win_save.DrawHighlight();
            WinWindow Subwin_save = new WinWindow(win_save);
            win_save.SearchProperties.Add("ControlId", "10");
            WinComboBox cmb = new WinComboBox(Subwin_save);
            UITestControlCollection coll = cmb.FindMatchingControls();
            coll[3].DrawHighlight();
            ((WinComboBox)coll[1]).SetProperty("SelectedItem", "Exchange : Secured");
            ((WinComboBox)coll[0]).SetProperty("SelectedItem", "SEC-CIP");
            ((WinComboBox)coll[3]).SetProperty("SelectedItem", "1099");
            string cmbvalue = ((WinComboBox)coll[0]).Items[0].Name.ToString() + ((WinComboBox)coll[0]).Items[3].Name.ToString() + ((WinComboBox)coll[0]).Items[5].Name.ToString();
           
            WinButton ok = new WinButton(win_save);
            ok.SearchProperties.Add("Name", "OK");
            Mouse.Click(ok);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
            return cmbvalue;
        }
        //
        public bool IsCheckedImageDocCheckbox(string DeliveryMethod)
        {
            FastDriver.DocumentRepository.SelectDeliveryMethod(DeliveryMethod);
            FastDriver.DocumentRepository.ClickDeliver();
            bool isChecked = true;
            switch (DeliveryMethod)
            {
                case "PRINT": 
                    FastDriver.PrintDlg.WaitForScreenToLoad();
                    isChecked = FastDriver.PrintDlg.ImageDocument.IsSelected();
                    FastDriver.PrintDlg.ClickCancel();
                    break;
                case "FAX": 
                    FastDriver.FaxDlg.WaitForScreenToLoad();
                    isChecked = FastDriver.FaxDlg.imageDocument.IsSelected();
                    FastDriver.FaxDlg.Cancel.FAClick();
                    break;

                case "EMAIL": 
                    FastDriver.EmailDlg.WaitForScreenToLoad();
                    isChecked = FastDriver.EmailDlg.imgDocument.IsSelected();
                    FastDriver.EmailDlg.Cancel.FAClick();
                    break;
            }
            return isChecked;
        }
        #endregion

        #region SRT R06
        public void CreatePhraseGroup()
        {
            try
            {
                Reports.TestDescription = "Create Phrase Group and add Phrase to Phrase Group, add Data Element to the Phrase, add Phrase to a Template and pull it on file side.";

                #region Data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion

                Reports.TestDescription = "MainCourse: Add a Template which has signature data elements.";

                #region ADM Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #endregion

                #region Phrase Creation

                Reports.TestStep = "Create a new Phrase Group.";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter mandatory info to create a new phrase group.";
                FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
                string phraseGroup = "G" + Support.RandomString("AAN");
                FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroup);
                FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation Phrase Group");
                FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseGroupMaintenance.Comments.FASetText("US#607842 Testing");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Add button.";
                FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
                FastDriver.PhraseGroupMaintenance.Add.FAClick();

                Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
                string phraseName = "G" + Support.RandomString("AAN");
                FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
                FastDriver.PhraseGroupMaintenance.PhraseName.FASetText(phraseName);
                FastDriver.PhraseGroupMaintenance.PhraseDescritption.FASetText("Automation Phrase");
                FastDriver.PhraseGroupMaintenance.PhraseComments.FASetText("US#607842 Testing : Add phrase to Phrasegroup");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Phrase Editor button.";
                FastDriver.PhraseMaintenance.SwitchToContentFrame();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();


                Reports.TestStep = "Select the Signature Data Elements.";
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.SwitchToDialogContentFrame();
                FastDriver.DataElementSelectionDlg.DataElement.FASetText("BSREP1SIGN,BSREP2SIGN,EASIGN,EOSIGN,USRSIGN,TASIGN,TOSIGN");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DataElementSelectionDlg.SwitchToDialogBottomFrame();
                FastDriver.DataElementSelectionDlg.Done.FAClick();
                Playback.Wait(3000);

                FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
                Reports.TestStep = "Click on Save.";
                FastDriver.DialogBottomFrame.ClickSave();
                Reports.TestStep = "Click on Done.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                #endregion

                #region Template creation

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad(FastDriver.TemplateMaintenanceSummary.New);

                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter information related to tempalte in Information tab";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                string templateName = "G" + Support.RandomString("AAN");
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(templateName);
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FAClick();
                string templateDesc = "US#607842" + Support.RandomString("AAN");
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(templateDesc);
                FastDriver.TemplateMaintenanceInformation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.TemplateMaintenanceInformation.InformationComments.FASetText("US#607842 Testing");

                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFormatting);
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");

                Reports.TestStep = "Click on Phrases Tab & Click on Add button.";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkPhrases);
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesAdd);
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "Enter phrases.";
                string phrases = phraseGroup + "/" + phraseName;
                FastDriver.PhraseSelectDlg.EnterPhraseInformation(name: phrases);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseSelectDlg.WindowTitle, false, 15);

                Reports.TestStep = "Verify that selected phrase added to phrases table.";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad(FastDriver.TemplateMaintenancePhrase.PhrasesTable);
                FastDriver.TemplateMaintenancePhrase.PhrasesTable.PerformTableAction("Name", phrases, "Required", TableAction.Click);


                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                #endregion

                #region IIS Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion

                #region Create File

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("1243");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.Title.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItemByIndex(14);
                FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FASelectItemByIndex(2);
                FastDriver.QuickFileEntry.EscrowOwningOfficeAssistant.FASelectItemByIndex(2);
                FastDriver.QuickFileEntry.TitleOwningOfficeOfficer.FASelectItemByIndex(2);
                FastDriver.QuickFileEntry.TitleOwningOfficeAssistant.FASelectItemByIndex(2);
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion SRT R06

        #region SRT R08
        public void ValidateFinalizedDocs(string docType, int index)
        {

            #region Add Document in the file

            try
            {
                List<int> documentsToSelect = new List<int>();
                documentsToSelect.Add(index);


                Reports.TestStep = " Scenario Execution for " + docType;

                Reports.TestStep = "Navigate to Document Repository, click on Add Button, select template and save it.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(docType);
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.WaitForResultsToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(1000);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectRowsByIndex(documentsToSelect);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.SwitchToContentFrame();

                if (docType != "Title Reports")
                {
                    FastDriver.DocumentRepository.PolicyNumber.FASetText("123456");
                    FastDriver.DocumentRepository.EffectiveDatePolicy.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                    FastDriver.DocumentRepository.btnInfoSavePolicy.FAClick();
                }
                else
                {
                    FastDriver.DocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                    FastDriver.DocumentRepository.btnInfoSave.FAClick();
                }

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.DocumentRepository.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Finalize the document";
                if (docType == "Lender Policy" || docType == "Owner Policy")
                    Playback.Wait(24000);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.SelectRowsByIndex(documentsToSelect);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();

                Playback.Wait(20000);
                Keyboard.SendKeys("%o");
                Playback.Wait(1000);
                Keyboard.SendKeys("%z");
                Playback.Wait(2000);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);

                Reports.TestStep = "Validate Copy From button is disabled";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Order Entry>Document Repository");
                FastDriver.DocumentRepository.SelectRowsByIndex(documentsToSelect);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.DocumentRepository.SwitchToContentFrame();
                var copyFromEnabled = "NA";
                var helpText = "NA";

                if (docType == "Title Reports")
                {
                    copyFromEnabled = FastDriver.DocumentRepository.CopyFrom.IsEnabled().ToString();
                    helpText = FastDriver.DocumentRepository.CopyFrom.GetAttribute("title").ToString();

                }
                else
                {
                    copyFromEnabled = FastDriver.DocumentRepository.CopyFromPolicy.IsEnabled().ToString();
                    helpText = FastDriver.DocumentRepository.CopyFromPolicy.GetAttribute("title").ToString();
                }

                Reports.TestStep = "Verify If Copy From Button is Inactive";
                Support.AreEqual("False", copyFromEnabled);
                Support.AreEqual("Copy From cannot be performed as the document has been Finalized", helpText);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            #endregion
        }
        #endregion SRT R08

        #region MARS 10.8
        [TestMethod, DeploymentItem(@"Common\Support\\Hello.pdf")]
        public void DPUC0009_Bug_811642()
        {

            # region login and create a basic file
            IISLOGIN();
            CreateBasicFile();
            #endregion


            #region Copy Hello.PDF from one path to other and create HelloCopied.pdf

            string fileName = "\\Hello.pdf";
            string filename1 = Support.RandomString("AAAAAANNNAAA") + ".pdf";
            string sourcePath = Reports.DEPLOYDIR;
            string targetPath = "\\\\faiblr04waut05.intl.corp.firstam.com\\AxeResults\\FASTRunConfigs\\SupportFiles\\";

            // Use Path class to manipulate file and directory paths.
            string sourceFile = sourcePath + fileName;
            string destFile = targetPath + filename1;
            Reports.TestStep = "Copy " + fileName + " from " + sourcePath + " to " + targetPath + " and rename to " + filename1;

            if (Directory.Exists(targetPath))
            {
                Directory.CreateDirectory(targetPath);
            }

            System.IO.File.Copy(sourceFile, destFile, true);

            if (System.IO.File.Exists(destFile))
            {
                Support.AreEqual(true, true, "File exists in destination path");
            }
            else
            {
                Support.AreEqual(true, false, "File is not copied to destination path");
            }

            #endregion

            #region Upload Document
            Reports.TestStep = "Navigate to Doc Repository and Click on Upload.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.Upload);
            Playback.Wait(5000);
            FastDriver.DocumentRepository.Upload.FAClick();

            Reports.TestStep = "Browse document and upload it.";
            if (!((destFile).ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support." + fileName, destFile);
            }

            FastDriver.UploadDocumentDlg.UploadFile(destFile);

            Reports.TestStep = "Save Scanned doc,entering Name so that it will appear in Edit Disb Screen.";
            FastDriver.SaveDocumentDlg.SaveDocument("Escrow: Payoff Demand/Bills", "PO-Invoice", "PO-Invoice");

            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false);
            }
            catch (TimeoutException)
            {
                Reports.StatusUpdate("Saving... NoTitle window has closed fast.", true);
            }

            Reports.TestStep = "Verify the scanned document is available in document repository screen ";
            Playback.Wait(5000);
            Reports.TestStep = "Navigate to document Repository.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); FastDriver.DocumentRepository.DocumentsTab.FAClick();

            Reports.TestStep = "Verify that Document is uploaded to the FAST.";
            FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
            if (!FastDriver.DocumentRepository.DocumentsTable.IsDisplayed()) FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
            FastDriver.DocumentRepository.WaitForPageToLoad();
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Invoice PO-Invoice", 4, TableAction.Click);
            #endregion

            #region Delete the file and verify if file is deleted
            Reports.TestStep = "Delete file from" + targetPath + "and verify if " + filename1 + "is deleted in remote location";
            System.IO.File.Delete(destFile);
            Playback.Wait(5000);
            string[] files = System.IO.Directory.GetFiles(targetPath);
            string fileName2;
            int i = 0;

            foreach (string s in files)
            {
                fileName2 = System.IO.Path.GetFileName(s);
                if (fileName2.ToString() == filename1)
                {
                    i = 1;
                    break;
                }
            }
            if (i == 0)
            {
                Support.AreEqual(true, true, "File does not exists in destination path after deleting the same");
            }
            else
            {
                Support.AreEqual(false, true, "File exists in destination path even after deleting the same");
            }

            #endregion

        }


        [TestMethod]
        public void DPUC0009_Bug_821049_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder_INC2868651 - Issue- 10.4 Triage - page numbers not showing in imaging workbench.";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void DPUC0009_Bug_811644_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder_INC2783580 - 10.3 Issue - Cannot split in Doc Rep (unable to enlarge window popup)";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Bug
        public void abd()
        {
            Reports.TestDescription = "Create Phrase Group and add Phrase to Phrase Group, add Data Element to the Phrase, add Phrase to a Template and pull it on file side.";

            #region Data setup

            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

            #endregion

            Reports.TestDescription = "MainCourse: Add a Template which has signature data elements.";

            #region ADM Login

            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            #endregion

            #region Phrase Creation

            Reports.TestStep = "Create a new Phrase Group.";
            FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad(FastDriver.PhraseGroupMaintenanceSummary.PhraseGroupType);
            FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();

            Reports.TestStep = "Enter mandatory info to create a new phrase group.";
            FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
            string phraseGroup = "G" + Support.RandomString("AAN");
            FastDriver.PhraseGroupMaintenance.Name.FASetText(phraseGroup);
            FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Automation Phrase Group");
            FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Escrow Phrase");
            FastDriver.PhraseGroupMaintenance.Comments.FASetText("US#607842 Testing");
            FastDriver.BottomFrame.Save();

            Reports.TestStep = "Click on Add button.";
            FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
            FastDriver.PhraseGroupMaintenance.Add.FAClick();

            Reports.TestStep = "Enter mandatory info In Phrase Maintenance screen.";
            string phraseName = "G" + Support.RandomString("AAN");
            FastDriver.PhraseGroupMaintenance.SwitchToContentFrame();
            FastDriver.PhraseGroupMaintenance.PhraseName.FASetText(phraseName);
            FastDriver.PhraseGroupMaintenance.PhraseDescritption.FASetText("Automation Phrase");
            FastDriver.PhraseGroupMaintenance.PhraseComments.FASetText("US#607842 Testing : Add phrase to Phrasegroup");
            FastDriver.BottomFrame.Save();

            Reports.TestStep = "Click on Phrase Editor button.";
            FastDriver.PhraseMaintenance.SwitchToContentFrame();
            FastDriver.PhraseMaintenance.WaitForScreenToLoad(FastDriver.PhraseMaintenance.PhraseEditor);
            FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
            FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();


            Reports.TestStep = "Select the Signature Data Elements.";
            FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
            FastDriver.DataElementSelectionDlg.SwitchToDialogContentFrame();
            FastDriver.DataElementSelectionDlg.DataElement.FASetText("BSREP1SIGN,BSREP2SIGN,EASIGN,EOSIGN,USRSIGN,TASIGN,TOSIGN");

            Reports.TestStep = "Click on Done in Dialog Box.";
            FastDriver.DataElementSelectionDlg.SwitchToDialogBottomFrame();
            FastDriver.DataElementSelectionDlg.Done.FAClick();
            Playback.Wait(3000);

            FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
            Reports.TestStep = "Click on Save.";
            FastDriver.DialogBottomFrame.ClickSave();
            Reports.TestStep = "Click on Done.";
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }
        #endregion
        #endregion
    }
}
