﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0113 : MasterTestClass
    {
        private static int waitTime = Convert.ToInt32(AutoConfig.WaitTime);

        [TestMethod]
        public void FMUC0113_BAT0001()
        {
            try
            {
                Reports.TestDescription = "AF2: Verify if 'No match found' message appears upon searching for an invalid file number.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                var fileNumber = "1122334455";
                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Verify the default state of the fields.";
                FastDriver.FileSearch.VerifyTheStateOfFields();

                Reports.TestStep = "Enter the file number.";
                FastDriver.FileSearch.SetFileNumber(fileNumber: fileNumber, IsNonExistingFile: true);

                Reports.TestStep = "Click the Find Now button.";
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Verify that No match found alert appears upon searching for a non-existing file.";
                FastDriver.FileSearch.VerifyIfNoMatchFoundMessageAppears();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_FM2023: Perform exact match and verify if the approppriate file is opened.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Perform a valid file search and verify if the same file is opened.";
                FastDriver.FileSearch.PerformExactSearchAndVerifyIfTheFileIsOpenedExchange(fileNumber);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_BAT0003()
        {
            try
            {
                Reports.TestDescription = "Test the New Search functionality. Check if all the fields are reset upon clicking the New Search button.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Enter details.";
                FastDriver.FileSearch.SetValues(isExchange: true);

                Reports.TestStep = "Click the Find Now button.";
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Verify that No match found alert appears.";
                FastDriver.FileSearch.VerifyIfNoMatchFoundMessageAppears();

                FastDriver.FileSearch.WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Verify if the FindNow button is still enabled.";
                Support.AreEqual("True", FastDriver.FileSearch.FindNow.Enabled.ToString());

                Reports.TestStep = "Click the New Search button.";
                FastDriver.FileSearch.NewSearch.FAClick();

                Reports.TestStep = "Verify that all the fields are reset to the default values.";
                FastDriver.FileSearch.VerifyTheStateOfFields();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_BAT0004()
        {
            try
            {
                Reports.TestDescription = "82930 : Perform wild card search. Check the count of the total number of files listed is at least 2 ";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create 2 files with default values.";
                string filePrefix = "wcs";
                var fileNumber1 = CreateFile(filePrefix);
                var fileNumber2 = CreateFile(filePrefix);

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Enter file number with wild card character.";
                FastDriver.FileSearch.SetFileNumber(AddWildcard(filePrefix));

                Reports.TestStep = "Click the Find Now button.";
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Handle 'More than 100 Records found' message, if more than 100 Records are found.";
                FastDriver.FileSearch.HandleMoreThan100RecordsFoundAlert(120);

                Reports.TestStep = "Check the count of the total number of files listed is at least 2.";
                FastDriver.FileNumberSearchSelectionDlg.CheckTheFileCountIsNotBelowTheSpecifiedValue(refFileCount: 2);

                Reports.TestStep = "Check if the specified file is listed in the dialog.Then, open the file listed next to this file.";
                int currentRow = FastDriver.FileNumberSearchSelectionDlg.SelectTheSpecifiedFileInTheDialog(fileNumber1);
                FastDriver.FileNumberSearchSelectionDlg.OpenNextFileFromTheRow(currentRow, isExchange: true);

                //Reports.TestStep = "Navigate to File Search screen";
                //FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();

                //Reports.TestStep = "Enter multiple search criteria";
                //Support.DataLoad("RandomBuyerName");
                //var buyerName = Support.data;
                //FastDriver.FileSearch.Principals.FASetText(buyerName);
                //FastDriver.FileSearch.State.FASelectItem("AR");
                //FastDriver.FileSearch.OpenDate.FAClick();
                //FastDriver.FileSearch.DateFrom1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());
                //FastDriver.FileSearch.DateTo1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());

                //Reports.TestStep = "Search for the file.";
                //if (!FastDriver.FileSearch.RetryFileSearch())
                //{
                //    Reports.StatusUpdate("File wasn't located !", false);
                //}

                //Reports.TestStep = "Verify if the appropriate file is opened.";
                //FastDriver.ExchangeFileEntry.SwitchToContentFrame();
                //FastDriver.ExchangeFileEntry.WaitCreation(FastDriver.ExchangeFileEntry.TransactionType);
                //Support.AreEqual(fileNumber1, FastDriver.ExchangeFileEntry.FileNo.FAGetValue());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF6 : File Number Search in MRU - Check if 'No match found' alert appears.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Search for a non-existent file and check if the appropriate alert is displayed.";
                var fileNumber = "1122334455";
                FastDriver.TopFrame.SearchForNonExistentFileAndVerifyTheAlert(fileNumber);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF4 : File Number Search in MRU - Exact macth.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create first file with default values.";
                var fileNumber1 = CreateFile();

                Reports.TestStep = "Create second file with default values.This file is needed to be created to test if an appropriate file is opened upon searching for the same.";
                var fileNumber2 = CreateFile();

                System.Threading.Thread.Sleep(5000);// to avoid the occurrence of getting the 'No match found' alert.

                Reports.TestStep = "Set the first file just created in the MRU and press the 'Enter' key.";
                FastDriver.TopFrame.SetNumberAndPressEnter(fileNumber1);

                Reports.TestStep = "Navigate to Exchange File Entry.";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry");
                FastDriver.ExchangeFileEntry.SwitchToContentFrame();
                FastDriver.ExchangeFileEntry.WaitCreation(FastDriver.ExchangeFileEntry.TransactionType);
                var fileNo = FastDriver.ExchangeFileEntry.FileNo.FAGetValue();

                Reports.TestStep = "Verify if the appropriate file is opened.";
                Support.AreEqual(fileNumber1, fileNo);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF4 : Wild card search in MRU.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create first file with default values.";
                var fileNumber1 = CreateFile();

                Reports.TestStep = "Create second file with default values.";
                var fileNumber2 = CreateFile();

                System.Threading.Thread.Sleep(12000);// to avoid the delay in getting the file listed.

                Reports.TestStep = "Enter the few digitis of the file number with wild card and search.";
                FastDriver.TopFrame.SetNumberAndPressEnter(AddWildcard(fileNumber1, 1));

                Reports.TestStep = "File Number Search Dialog should open. Handle 'More than 100 Records found' message, if appears.";
                FastDriver.FileSearch.HandleMoreThan100RecordsFoundAlert();

                Reports.TestStep = "Check the count of the total number of files listed is at least 2.";
                FastDriver.FileNumberSearchSelectionDlg.CheckTheFileCountIsNotBelowTheSpecifiedValue(refFileCount: 2, timeOutValue: 60);

                Reports.TestStep = "Check if the first file just created is listed in the File Number Search dialog. Then, open the same.";
                int returnVal = FastDriver.FileNumberSearchSelectionDlg.SelectTheSpecifiedFileInTheDialog(fileNumber1, true);
                Reports.StatusUpdate("Has the file been tried to open by double clicking the File No. cell in the dialog ?", returnVal == -1);

                Reports.TestStep = "Navigate to Exchange File Entry.";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry");
                FastDriver.ExchangeFileEntry.SwitchToContentFrame();
                FastDriver.ExchangeFileEntry.WaitCreation(FastDriver.ExchangeFileEntry.TransactionType);
                var fileNo = FastDriver.ExchangeFileEntry.FileNo.FAGetValue();

                Reports.TestStep = "Verify if the appropriate file is opened.";
                Support.AreEqual(fileNumber1, fileNo);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0001()
        {
            try
            {
                Reports.TestDescription = "[DUPLICATED]";
                Reports.StatusUpdate("This scenario is already covered in BAT0004", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0002()
        {
            try
            {
                Reports.TestDescription = "AF4_FM827_FM2019 : File Number Search in MRU - wild card search.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with different values for GAB Code and State.";
                var fileNumber = CreateFile(addBuyer: true);

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Enter search criterion in the month field and perform the search.";
                FastDriver.FileSearch.Month.FASetText("1");
                FastDriver.FileSearch.Month.FASendKeys(FAKeys.Tab);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTableExchange, Convert.ToInt32(AutoConfig.WaitTime));
                FastDriver.FileSearch.VerifyMoreThan100RecordsFoundNote();
                FastDriver.FileSearch.VerifyIfTheFileCreationDateIsWithinTheMonthCriterion(1, true);

                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(4, "Open", 4, TableAction.Click);

                Reports.TestStep = "Click New Search to perform a fresh search.";
                FastDriver.FileSearch.NewSearch.FAClick();

                Reports.TestStep = "Enter search criterion with wild card in the Principals field.";
                FastDriver.FileSearch.BuyerExchange.FAClick();
                FastDriver.FileSearch.Principals.FASetText("Buyer*");

                Reports.TestStep = "Enter search criterion in Other Parties sectin and perform the search.";
                //FastDriver.FileSearch.OtherParties.FASetText("Lenders Advantage");
                //FastDriver.FileSearch.RoleType.FASelectItem("Other Real Estate Agent");
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.SwitchToContentFrame();
                //FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                Reports.TestStep = "Search for the file.";
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTableExchange))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }

                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTableExchange, Convert.ToInt32(AutoConfig.WaitTime));
                //FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(1, fileNumber, 1, TableAction.Click); //this line is commented because it takes sometimes longer duration to get the newly created file number appear in the result list.
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(4, "Open", 4, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0003()
        {
            try
            {
                Reports.TestDescription = "AF4 : File Number Search in MRU - wild card search.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with different GAB ID.";
                var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();

                List<string> userItems = LoadTheList();

                Reports.TestStep = "Enter search criterion in the month field and perform the search.";
                FastDriver.FileSearch.VerifyAllItemsInRoleTypeDropdown(userItems);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0004()
        {
            try
            {
                Reports.TestDescription = "AF4 : File Number Search in MRU - wild card search.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the first file with default values.";
                var fileNumber = CreateFile(addBuyer: true);

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Enter search criterion in the month field and perform the search.";
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.SwitchToContentFrame();
                //FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTableExchange, Convert.ToInt32(AutoConfig.WaitTime));
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTableExchange))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(1, fileNumber, 1, TableAction.Click);//zzzzzzzzzzz
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(4, "Open", 4, TableAction.Click);

                Reports.TestStep = "Click New Search to perform a fresh search.";
                FastDriver.FileSearch.NewSearch.FAClick();

                Reports.TestStep = "Enter search criterion with wild card in the Principals field.";
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.State);
                FastDriver.FileSearch.State.FASelectItem("CA");
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.FindNow);
                //FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTableExchange, Convert.ToInt32(AutoConfig.WaitTime));
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTableExchange))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(4, "Open", 4, TableAction.Click);

                Reports.TestStep = "Click New Search to perform a fresh search.";
                FastDriver.FileSearch.NewSearch.FAClick();

                Reports.TestStep = "Search by Property Parcel and Lot criteria.";
                FastDriver.FileSearch.PropertyLot.FASetText("1");
                FastDriver.FileSearch.PropertyParcel.FASetText("2");
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Verify that No match found alert appears upon searching for a non-existing file.";
                FastDriver.FileSearch.VerifyIfNoMatchFoundMessageAppears();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM2022_FM774_FM805_FM2024: Dates Section :- Search based on 'From' Date Only, then both 'From' Date and 'To' Date, and then based on # of months.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the first file with default values.";
                var fileNumber = CreateFile(addBuyer: true);

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();
                string fromDate = DateTime.Now.AddDays(-200).ToDateString();
                string toDate = DateTime.Now.ToDateString();

                Reports.TestStep = "Enter only From Date value.";
                FastDriver.FileSearch.DateFrom1.FASetText(fromDate);
                FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if the search fetches results.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTableExchange, Convert.ToInt32(AutoConfig.WaitTime));
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(4, "Open", 4, TableAction.Click);

                Reports.TestStep = "Check the Opened Date of the last file number in the list within the date range critera.";
                int lastRow = FastDriver.FileSearch.SearchResultTableExchange.GetRowCount();
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(lastRow, 1, TableAction.Click);
                FastDriver.FileSearch.View.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("File Summary", true, waitTime);
                FastDriver.FileSummaryDlg.SwitchToDialogContentFrame();

                Reports.StatusUpdate("Check that the Opened Date falls within the From Date entered", Convert.ToDateTime(fromDate) <= Convert.ToDateTime(FastDriver.FileSummaryDlg.OpenedDateExchange.FAGetText()));
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Enter 'From Date' and 'To Date' values.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.NewSearch);
                FastDriver.FileSearch.NewSearch.FAClick();
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.NewSearch);
                FastDriver.FileSearch.DateFrom1.FASetText(fromDate);
                FastDriver.FileSearch.DateTo1.FASetText(toDate);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);

                Reports.TestStep = "Check if the search fetches results including the file number just created.";
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTableExchange))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(4, "Open", 4, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0006()
        {
            try
            {
                Reports.TestDescription = "[DUPLICATED]";
                //Reports.TestDescription = "[DUPLICATED] FM827_FM2019_FM2020_FM2023  : File Search Results, Tool Tips for Result Section, Search Processing Region, Exact Match.";
                Reports.StatusUpdate("This scenario is already covered in BAT0002 and REG0002", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM775: Search on Leading Char String.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.Numbers.FASetText("*a");
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Validate the message.";
                Support.AreEqual("Searching with wildcard or leading wildcard characters is not allowed", FastDriver.WebDriver.HandleDialogMessage());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM4988: Case Insensitive Search Criteria.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a new file with buyer values in Capital letters.";
                string fileNumber = CreateFile(isUpper: true, addBuyer: true);

                Reports.TestStep = "Navigate to File Search screen.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Enter buyer in small caps except the first letter.";
                FastDriver.FileSearch.Principals.FASetText("BuyerLastName");
                FastDriver.FileSearch.BuyerExchange.FAClick();
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTableExchange, Convert.ToInt32(AutoConfig.WaitTime));
                Support.AreEqual("Open", FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(1, fileNumber, 4, TableAction.GetText).Message);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0009()
        {
            try
            {
                Reports.TestDescription = "FM5004  Access Rights to Results.";

                Reports.TestStep = "Login to FAST ADM.";
                this.LoginToADM();

                Reports.TestStep = "Select the Region as specified in the AutoConfig";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for the intended user account and open the same.";
                FastDriver.LeftNavigation.Navigate<EmployeeSecurity>(@"Home>System Maintenance>Security Maintenance>Employee Security").WaitForScreenToLoad();
                FastDriver.EmployeeSecurity.LoginNameTextbox.FASetText(AutoConfig.UserName);
                FastDriver.EmployeeSecurity.SearchNowButton.FAClick();

                FastDriver.EmployeeSecurity.ResultsTable.PerformTableAction(1, "[" + AutoConfig.UserName.ToUpper() + "]", 1, TableAction.DoubleClick);

                Reports.TestStep = "Validate that the File Entry Activity role is assigned to the selected office via Business Units to Role view.";
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad(null, Convert.ToInt32(AutoConfig.WaitTime));
                FastDriver.BusinessUnitRoleAssignment.SelectBusinessUnit(AutoConfig.SelectedRegionBUID);
                FastDriver.BusinessUnitRoleAssignment.SelectOfficeUnderBusinessUnits_(AutoConfig.SelectedOfficeBUID);
                if (FastDriver.BusinessUnitRoleAssignment.CheckActivityRightInRole("IT - all", "File Entry Activity"))
                {
                    Reports.StatusUpdate("The Activity Role : File Entry Activity has been located !", true);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0017()
        {
            try
            {
                //AutoConfig.SelectedRegionName
                Reports.TestDescription = "FM5004_2 : Search by different region.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                //Reports.TestStep = "Create the first file with default values.";
                //var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Select the Region that the file has just been created in and perform the search.";
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.Region.FASelectItem(@"02 QA LOAD TEST REGION - DO NOT USE WITHOUT APPROVAL");
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if the Search Results table lists open orders.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTableExchange, Convert.ToInt32(AutoConfig.WaitTime));
                //FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(4, "Open", 4, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0010()
        {
            try
            {
                Reports.TestDescription = "FV1: Verify the Display format.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                //Reports.TestStep = "Create the first file with default values.";
                //var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                Reports.TestStep = "Verify the field type";
                Support.AreEqual("radio", FastDriver.FileSearch._FileSearch.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.PendingOrderSearch.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.Principals.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.BuyerExchange.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Seller.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Debtor.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.AnyPrincipals1.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.IndividualHusband.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.TrustEstate.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.BussinessEntity.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.AnyPrincipals2.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.OtherParties.FAGetAttribute("type"));
                Support.AreEqual("select", FastDriver.FileSearch.RoleType.TagName);
                Support.AreEqual("text", FastDriver.FileSearch.PropertyAddress.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertyName.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertyLot.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertyTract.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertyParcel.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertySubDiv.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.APNTaxNo.FAGetAttribute("type"));
                Support.AreEqual("select", FastDriver.FileSearch.State.TagName);
                Support.AreEqual("text", FastDriver.FileSearch.County.FAGetAttribute("type"));
                Support.AreEqual("select", FastDriver.FileSearch.Country.TagName);
                Support.AreEqual("select", FastDriver.FileSearch.Region.TagName);
                Support.AreEqual("radio", FastDriver.FileSearch.FileNo.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.PrincipalsReg.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.ExtNo.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.EntityRef.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.InvoiceNo.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.BussinessSource.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.OutsideRef.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.AnyNumbers.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Open.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Closed.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.OpeninError.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.AnyStatus.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Cancelled.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.DateFrom1.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.DateTo1.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.Month.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.OpenDate.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.SettlementDate.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.CancelledDate.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.EstSettlementDate.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.EmployeeName.FAGetAttribute("type"));
                Support.AreEqual("select", FastDriver.FileSearch.EmployeeType.TagName);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0011()
        {
            try
            {
                Reports.TestDescription = "FV2: Verify the field validation of File number field.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Check how the page behaves upon entering an invalid character in Numbers field.";
                SetNumberAndSearch("@abc");
                Support.AreEqual(@"Please enter valid file search characters: letters, numbers, *, ?", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers); // this line enables to switch in

                Reports.TestStep = "Click New Search button.";
                FastDriver.FileSearch.NewSearch.FAClick();
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Check how the page behaves upon entering valid characters yet non-existing file.";
                SetNumberAndSearch("randomFn");
                FastDriver.FileSearch.AnyStatusExchg.FAClick();
                FastDriver.FileSearch.VerifyIfNoMatchFoundMessageAppears();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0012()
        {
            try
            {
                Reports.TestDescription = "FV3: Verify the File Search Result List.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the first file with default values.";
                var fileNumber = CreateFile(addBuyer: true);

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                FastDriver.FileSearch.Principals.FASetText(@"BuyerFirstName BuyerLastName");
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.BuyerExchange.FAClick();
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestDescription = "Verify the File Search Result List.";
                FastDriver.FileSearch.WaitForScreenToLoad();
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(1, fileNumber, 2, TableAction.Click);
                Support.AreEqual("True", FastDriver.FileSearch.View.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.FindNow.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.NewSearch.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.Select.IsEnabled().ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0113_REG0013()
        {
            try
            {
                Reports.TestDescription = "FV4: Field definition of File Search screen.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                //Reports.TestStep = "Create the first file with default values.";

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>1031 Exchange>File Search").WaitForFileSearchScreenToLoad();

                FastDriver.FileSearch.PropertyLot.FASetText("12432adsfdv");
                Support.AreEqual("12432adsfdv", FastDriver.FileSearch.PropertyLot.FAGetValue());

                Reports.TestStep = "Validate Property Lot field with exact value.";
                FastDriver.FileSearch.PropertyLot.FASetText("");
                FastDriver.FileSearch.PropertyLot.FASetText(@"11111111111111111111111111111111111111111111111111");
                Support.AreEqual(@"11111111111111111111111111111111111111111111111111", FastDriver.FileSearch.PropertyLot.FAGetValue());

                Reports.TestStep = "Enter Property Lot field with upper boundary value+1.";
                FastDriver.FileSearch.PropertyLot.FASetText("");
                FastDriver.FileSearch.PropertyLot.FASetText(@"111111111111111111111111111111111111111111111111111");
                Reports.TestStep = "Validate user is not able to type more than the exact value.";
                Support.AreEqual(@"11111111111111111111111111111111111111111111111111", FastDriver.FileSearch.PropertyLot.FAGetValue());

                Reports.TestStep = "Validate Property Tract with lower boundary.";
                FastDriver.FileSearch.PropertyTract.FASetText(@"1@334354657bghghj");
                Support.AreEqual(@"1@334354657bghghj", FastDriver.FileSearch.PropertyTract.FAGetValue());

                Reports.TestStep = "Validate Property Tract with exact value.";
                FastDriver.FileSearch.PropertyTract.FASetText("");
                FastDriver.FileSearch.PropertyTract.FASetText(@"1@334354657bghghjkuy");
                Support.AreEqual(@"1@334354657bghghjkuy", FastDriver.FileSearch.PropertyTract.FAGetValue());

                Reports.TestStep = "Enter Property Tract field with upper boundary value+1.";
                FastDriver.FileSearch.PropertyTract.FASetText("");
                FastDriver.FileSearch.PropertyTract.FASetText(@"334354657bghghjkuyase");
                Reports.TestStep = "Validate user is not able to type more than the exact value.";
                Support.AreEqual(@"334354657bghghjkuyas", FastDriver.FileSearch.PropertyTract.FAGetValue());

                Reports.TestStep = "Validate Property Parcel with lower boundary.";
                FastDriver.FileSearch.PropertyParcel.FASetText("");
                FastDriver.FileSearch.PropertyParcel.FASetText("ddfref333333333333333333g");
                Support.AreEqual(@"ddfref333333333333333333g", FastDriver.FileSearch.PropertyParcel.FAGetValue());

                Reports.TestStep = "Validate Property Parcel with exact value.";
                FastDriver.FileSearch.PropertyParcel.FASetText("");
                FastDriver.FileSearch.PropertyParcel.FASetText("ddfref333333333333333333gfrgr1");
                Support.AreEqual(@"ddfref333333333333333333gfrgr1", FastDriver.FileSearch.PropertyParcel.FAGetValue());

                Reports.TestStep = "Validate Property Parcel with upper boundary value+1.";
                FastDriver.FileSearch.PropertyParcel.FASetText("");
                FastDriver.FileSearch.PropertyParcel.FASetText("fref333333333333333333gfrgr1123");
                Support.AreEqual(@"fref333333333333333333gfrgr112", FastDriver.FileSearch.PropertyParcel.FAGetValue());

                Reports.TestStep = "Validate APN/Tax No. with lower boundary.";
                FastDriver.FileSearch.APNTaxNo.FASetText("");
                FastDriver.FileSearch.APNTaxNo.FASetText("ddfref333333333333333333g");
                Support.AreEqual(@"ddfref333333333333333333g", FastDriver.FileSearch.APNTaxNo.FAGetValue());

                Reports.TestStep = "Validate APN/Tax No. with exact value.";
                FastDriver.FileSearch.APNTaxNo.FASetText("");
                FastDriver.FileSearch.APNTaxNo.FASetText("ddfref333333333333333333gfrgr1");
                Support.AreEqual(@"ddfref333333333333333333gfrgr1", FastDriver.FileSearch.APNTaxNo.FAGetValue());

                Reports.TestStep = "Validate APN/Tax No. with upper boundary value+1.";
                FastDriver.FileSearch.APNTaxNo.FASetText("");
                FastDriver.FileSearch.APNTaxNo.FASetText("fref333333333333333333gfrgr1123");
                Support.AreEqual(@"fref333333333333333333gfrgr112", FastDriver.FileSearch.APNTaxNo.FAGetValue());

                Reports.TestStep = "Validate Principals, Other Parties, Property Name, Employee Name fields with lower boundary.";
                FastDriver.FileSearch.Principals.FASetText("");
                FastDriver.FileSearch.Principals.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZ", FastDriver.FileSearch.Principals.FAGetValue());

                FastDriver.FileSearch.OtherParties.FASetText("");
                FastDriver.FileSearch.OtherParties.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZ", FastDriver.FileSearch.OtherParties.FAGetValue());

                FastDriver.FileSearch.PropertyName.FASetText("");
                FastDriver.FileSearch.PropertyName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZ", FastDriver.FileSearch.PropertyName.FAGetValue());

                FastDriver.FileSearch.EmployeeName.FASetText("");
                FastDriver.FileSearch.EmployeeName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZ", FastDriver.FileSearch.EmployeeName.FAGetValue());

                Reports.TestStep = "Validate Principals field with upper boundary value+1.";
                FastDriver.FileSearch.Principals.FASetText("");
                FastDriver.FileSearch.Principals.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNeXTRA");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMN", FastDriver.FileSearch.Principals.FAGetValue());

                Reports.TestStep = "Validate Other Parties field with upper boundary value+1.";
                FastDriver.FileSearch.OtherParties.FASetText("");
                FastDriver.FileSearch.OtherParties.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOextra");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNO", FastDriver.FileSearch.OtherParties.FAGetValue());

                Reports.TestStep = "Validate Property Name field with upper boundary value+1.";
                FastDriver.FileSearch.PropertyName.FASetText("");
                FastDriver.FileSearch.PropertyName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOExtra");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNO", FastDriver.FileSearch.PropertyName.FAGetValue());

                Reports.TestStep = "Validate Employee Name field with upper boundary value+1.";
                FastDriver.FileSearch.EmployeeName.FASetText("");
                FastDriver.FileSearch.EmployeeName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOExtra");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNO", FastDriver.FileSearch.EmployeeName.FAGetValue());

                Reports.TestStep = "Validate Principals field with exact value.";
                FastDriver.FileSearch.Principals.FASetText("");
                FastDriver.FileSearch.Principals.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMN", FastDriver.FileSearch.Principals.FAGetValue());

                Reports.TestStep = "Validate Other Parties field with exact value.";
                FastDriver.FileSearch.OtherParties.FASetText("");
                FastDriver.FileSearch.OtherParties.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.FileSearch.OtherParties.FAGetValue());

                Reports.TestStep = "Validate Property Name field with exact value.";
                FastDriver.FileSearch.PropertyName.FASetText("");
                FastDriver.FileSearch.PropertyName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.FileSearch.PropertyName.FAGetValue());

                Reports.TestStep = "Validate Employee Name field with exact value.";
                FastDriver.FileSearch.EmployeeName.FASetText("");
                FastDriver.FileSearch.EmployeeName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.FileSearch.EmployeeName.FAGetValue());

                Reports.TestStep = "Validate Month field with lower boundary.";
                FastDriver.FileSearch.Month.FASetText("");
                //FastDriver.FileSearch.Month.SendKeys(OpenQA.Selenium.Keys.Delete);
                FastDriver.FileSearch.Month.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.FileSearch.Month.FASetText("12");
                Support.AreEqual(@"12", FastDriver.FileSearch.Month.FAGetValue());

                Reports.TestStep = "Validate Month field with exact value.";
                FastDriver.FileSearch.Month.FASetText("");
                FastDriver.FileSearch.Month.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.FileSearch.Month.FASetText("123");
                Support.AreEqual(@"123", FastDriver.FileSearch.Month.FAGetValue());

                Reports.TestStep = "Validate Month field with upper boundary+1.";
                FastDriver.FileSearch.Month.FASetText("");
                FastDriver.FileSearch.Month.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.FileSearch.Month.FASetText("1234");
                Support.AreEqual(@"123", FastDriver.FileSearch.Month.FAGetValue());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #region Private Methods

        private void LoginToIIS()
        {
            #region data setup

            var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };

            #endregion data setup

            try
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Exchange region/office.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();
                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SearchbyBUID.FASetText("12386" + FAKeys.Enter);
                Keyboard.SendKeys(FAKeys.Enter);
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.HomePage.WaitForHomeScreen(reportBuildNumber: true);
            }
            catch (Exception ex)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }

        private void LoginToADM()
        {
            #region data setup

            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

            #endregion data setup

            try
            {
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            }
            catch (Exception ex)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }

        public static Service GetService(string typeObjectCD)
        {
            return new Service()
            {
                OfficeInfo = new OfficeInfo()
                {
                    RegionID = 410,//int.Parse(AutoConfig.SelectedRegionBUID),
                    BUID = 518,//int.Parse(AutoConfig.SelectedOfficeBUID),
                    ProductionOffices = new ProductionOffice[]
                    {
                        new ProductionOffice()
                        {
                            BUID = 0,
                            OfficeCode = 0,
                            RegionID = 0,
                            SeqNum = 0
                        }
                    }
                },
                //ServiceTypeObjectCD = typeObjectCD
            };
        }

        private void SetNumberAndSearch(string fileNo)
        {
            FastDriver.FileSearch.Numbers.FASetText(@fileNo);
            FastDriver.FileSearch.FindNow.Click();
        }

        private string CreateFileWithBuyerCaps()
        {
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = RequestFactory.GetCreateFileDefaultRequest();

            fileRequest.File.Buyers[0].FirstName = "BUYERNAME";
            fileRequest.File.Buyers[0].LastName = "BUYERLASTNAME";

            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            return fileNumber;
        }

        /*fileRequest.File = new File()
            {
                Buyers = new BuyerSeller[]
                {
                        new BuyerSeller()
                        {
                            FirstName = "BUYERNAME",
                            LastName = "BUYERLASTNAME",
                        }
                },
            };*/

        private string AddWildcard(string fileNumber, int substrLength = 3)
        {
            return fileNumber.Substring(0, substrLength) + "*";
        }

        private string GetParsedUserIDWithSpace(string userID, bool IsToBeReversed = false)
        {
            string parsedUserID = "";
            if (userID.Contains("\\"))
            {
                parsedUserID = userID.Split('\\').LastOrDefault().Substring(0, 4) + " " + userID.Split('\\').LastOrDefault().Substring(4, 4);
            }
            if (IsToBeReversed)
            {
                parsedUserID = parsedUserID.Split(' ').LastOrDefault() + ", " + parsedUserID.Split(' ').FirstOrDefault();
                return parsedUserID.ToUpper();
            }
            return parsedUserID;
        }

        private string CreateFileWithEmployeeDetails()
        {
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = RequestFactory.GetCreateFileDefaultRequest();

            fileRequest.File.Services[0].OfficerObjectCD = "FASTQA07A"; //Employee Name for Title Officer Role
            fileRequest.File.Services[1].OfficerObjectCD = "FASTQA07A"; //Employee Name for Escrow Officer Role

            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            return fileNumber;
        }

        private string CreateFile(string FileName = null, bool isUpper = false, bool addBuyer = false)
        {
            string fileNumber = "";
            Reports.TestStep = "Create File using FAST GUI.";
            FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>(@"Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
            FastDriver.BottomFrame.SwitchToBottomFrame();
            if (FastDriver.BottomFrame.btnNew.IsEnabled())
            {
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
            }
            FastDriver.ExchangeFileEntry.SwitchToContentFrame();
            FastDriver.ExchangeFileEntry.AutoNumber.FASetCheckbox(false);

            if (!string.IsNullOrEmpty(FileName)) FastDriver.ExchangeFileEntry.FileNo.FASetText(FileName + Support.RandomString("AAA"));
            else if (isUpper) FastDriver.ExchangeFileEntry.FileNo.FASetText(Support.RandomString("AAAAAA").ToUpper());
            else FastDriver.ExchangeFileEntry.FileNo.FASetText(Support.RandomString("AAAAAA"));

            FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
            FastDriver.ExchangeFileEntry.ActualIDDate.FASetText("07-08-2015");
            FastDriver.ExchangeFileEntry.RelinquishedTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
            FastDriver.ExchangeFileEntry.SwitchToContentFrame();
            Playback.Wait(1000);

            FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Personal Property");
            Playback.Wait(1000);
            FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");

            if (addBuyer)
            {
                FastDriver.ExchangeFileEntry.RelCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.RelActualCOE.FASetCheckbox(true);

                FastDriver.ExchangeFileEntry.RelBuyersAddNew.FAClick();
                FastDriver.ExchangeFileEntry.WaitCreation(FastDriver.ExchangeFileEntry.RelBuyersType);
                FastDriver.ExchangeFileEntry.RelBuyersType.FASelectItem("Individual");
                FastDriver.ExchangeFileEntry.WaitCreation(FastDriver.ExchangeFileEntry.RelBuyersIndividualFirstName);
                FastDriver.ExchangeFileEntry.RelBuyersIndividualFirstName.FASetText("BuyerFirstName");
                FastDriver.ExchangeFileEntry.RelBuyersIndividualLastName.FASetText("BuyerLastName");
                FastDriver.ExchangeFileEntry.RelBuyersState.FASelectItem("CA");
            }

            FastDriver.ExchangeFileEntry.ReplacementTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
            FastDriver.ExchangeFileEntry.SwitchToContentFrame();
            Playback.Wait(1000);

            FastDriver.ExchangeFileEntry.REPPropertyType.FASelectItem("Personal Property");
            FastDriver.ExchangeFileEntry.REPPropertyState.FASelectItem("CA");
            FastDriver.BottomFrame.Done();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
            FastDriver.ExchangeFileEntry.SwitchToContentFrame();
            Playback.Wait(5000);

            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
            fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

            Playback.Wait(20000);   //Adding static wait as there is application latency between file creation and same getting reflected in the Filesearch
            return fileNumber;
        }

        private string CreateFile2(bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            string buyerRandomVal = Support.RandomString("AAAAAZ");
            string[] State = { "CR", "AR" };
            Reports.TestStep = "Generate a random buyer name.";
            Support.DataSave("RandomBuyerName", buyerRandomVal);

            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();

                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                {
                    GetService("TO")
                };

                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch
            {
                Reports.TestStep = "Create File using FAST GUI.";
            }
            if (string.IsNullOrEmpty(fileNumber))
            {
                throw new Exception("File creation is unsuccessful ! Aborting the test !");
            }
            return fileNumber;
        }

        private NewFileParameters SetNewFileParameters(string buyerRandomVal)
        {
            return new NewFileParameters()
            {
                BusinessSourceGABcode = "HUDFLINSR1",
                Title = true,
                Escrow = true,
                BusinessSegment = "Residential",
                TransactionType = "Sale w/Mortgage",
                PropertyState = "AR",
                Buyer1Type = "Individual",
                Buyer1FirstName = buyerRandomVal,
                Buyer1LastName = "Buyer1Lastname",
                Seller1Type = "Individual",
                Seller1FirstName = "Seller1Firstname",
                Seller1LastName = "Seller1Lastname",
                PropertyPropTaxAPN1 = "Prop1APN1",
                PropertyBookAddrLin1 = "J305",
                PropertyCity = "ALBANY",
                PropertyZipCode = "12345",
                PropertyCounty = "Lawrence",
            };
        }

        private List<string> LoadTheList()
        {
            return new List<string>
            {
                "Associated Party",
                "Assumption Lender",
                "Broker Disbursement Payee",
                "Business Source",
                "Buyer",
                "Buyer's Attorney",
                "Buyer's Broker",
                "Buyer's RE Broker Transaction Coordinator",
                "Buyer's Real Estate Agent",
                "Construction Company/Builder",
                "Directed By",
                "For Sale by Owner",
                "Hazard Insurance Underwriter",
                "HOA - Management Company",
                "Home Warranty",
                "Homeowner Association",
                "IBA Beneficiary",
                "Inspection and Repair",
                "Insurance Agent",
                "Lender",
                "Lender - 3rd Party Payee",
                "Lender's Attorney",
                "Lessor",
                "Miscellaneous",
                "Mortgage Broker",
                "Mortgage Broker - 3rd Party Payee",
                "New Lender",
                "Other",
                "Other Real Estate Agent",
                "Other Real Estate Broker",
                "Outside Escrow Company",
                "Outside Title Company",
                "Owner Office",
                "Payee",
                "Payoff Lender",
                "Production Office",
                "Real Estate Investment Trust",
                "Seller",
                "Seller's Attorney",
                "Seller's Broker",
                "Seller's Real Estate Agent",
                "Split Entity",
                "Split Office",
                "Survey",
                "Tax Collector",
                "Title Agent",
                "Title Company/Draft",
                "Trustee",
                "Utility Company"
            };
        }

        #endregion Private Methods

        private string GenerateInvoiceNo()
        {
            string returnValue = string.Empty;
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 4, TableAction.SetText, "2000.00");
            var rowCollection = FastDriver.FileFees.TitleandescrowTable.FindElements(By.TagName("tr"));
            try
            {
                //rowCollection[2].FindElements(By.TagName("td"))[6].FindElement(By.TagName("span")).FindElement(By.TagName("input")).FASetText("1000.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 7, TableAction.SetText, "1000.00");
            }
            catch (Exception e)
            {
                //rowCollection[2].FindElements(By.TagName("td"))[5].FindElement(By.TagName("span")).FindElement(By.TagName("input")).FASetText("1000.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 6, TableAction.SetText, "1000.00");
            }

            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(3, 1, TableAction.On);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(3, 4, TableAction.SetText, "200.00");
            try
            {
                //rowCollection[2].FindElements(By.TagName("td"))[6].FindElement(By.TagName("span")).FindElement(By.TagName("input")).FASetText("100.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(3, 7, TableAction.SetText, "100.00");
            }
            catch (Exception e)
            {
                //rowCollection[2].FindElements(By.TagName("td"))[5].FindElement(By.TagName("span")).FindElement(By.TagName("input")).FASetText("100.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(3, 6, TableAction.SetText, "100.00");
            }
            FastDriver.BottomFrame.Done();
            FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
            FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 8, TableAction.On);

            System.Threading.Thread.Sleep(2000);
            FastDriver.InvoiceFees.Final.FAClick();
            if (FastDriver.InvoiceFees.WaitUntilInvoiceNumberIsGeneratedForTheFirstInvName())
            {
                returnValue = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, 2, TableAction.GetText).Message;
            }
            return returnValue;
        }

        private void EnterSearchCriteriaForPendingSearch(string state, string buyer = "BuyerFirstName")
        {
            FastDriver.FileSearch.BuyerExchange.FAClick();
            FastDriver.FileSearch.Principals.FASetText(buyer);
            FastDriver.FileSearch.State.FASelectItem(state);
            FastDriver.FileSearch.DateFrom1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());
            FastDriver.FileSearch.DateTo1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());
            //FastDriver.FileSearch.EmployeeName.FASetText("Jeella, Venkateswara");
            FastDriver.FileSearch.EmployeeName.FASetText(GetParsedUserIDWithSpace(userID: AutoConfig.UserName, IsToBeReversed: true));
            FastDriver.FileSearch.EmployeeType.FASelectItem("Escrow Officer");
        }

        private void WaitForAppropriateElementsState()
        {
            FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers, 60);
            FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Principals);
            FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.TrustEstate);
        }

        private void SearchForFile(string fileNumber, string fileStatus)
        {
            int retryCount = 1;
            //bool IsMatchFound = false;
            bool MultipleRecordsDisplayed = false;
            string alertMessage = "";

            FastDriver.FileSearch.Country.FASelectItem("USA");
            Playback.Wait(4000); // to avoid failures due to screen refresh multiple times upon selecting an option from the Country dropdown.
            FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

            if (fileStatus.Equals("Opened in Error"))
                FastDriver.FileSearch.Numbers.FASetText(AddWildcard(fileNumber: fileNumber, substrLength: 4));

            if (!fileStatus.Equals("Opened in Error"))
                FastDriver.FileSearch.Numbers.FASetText(fileNumber);

            switch (fileStatus)
            {
                case "Opened in Error":
                    FastDriver.FileSearch.OpeninError.FAClick();
                    break;

                case "Closed":
                    FastDriver.FileSearch.Closed.FAClick();
                    break;

                case "Cancelled":
                    FastDriver.FileSearch.Cancelled.FAClick();
                    break;
            }

            while (retryCount <= 5) // sometimes no match found alert appears, though the file exists. Try five times searching for the file with 5 seconds wait between searches.
            {
                FastDriver.FileSearch.FindNow.FAClick();

                if (retryCount == 1)
                {
                    Reports.TestStep = "In case more than one record found, handle the message alert/file number selection dialog appropriately.";
                }

                alertMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, Convert.ToInt32(AutoConfig.WaitTime));
                if (!alertMessage.Contains(fileStatus) && !alertMessage.Equals("No match found."))
                {
                    if (FastDriver.FileSearch.SearchResultTableExchange.IsVisible())
                    {
                        MultipleRecordsDisplayed = true;
                        break;
                    }
                }

                if (!alertMessage.Equals("No match found."))
                {
                    break;
                }

                if (alertMessage.Equals("No match found."))
                {
                    FastDriver.FileSearch.SwitchToContentFrame();
                    Reports.TestStep = "No match found alert is shown up. Retrying... : " + retryCount++;
                    System.Threading.Thread.Sleep(5000);
                    continue;
                }
            }

            if (!MultipleRecordsDisplayed)
            {
                if (alertMessage.Contains("Opened in Error"))
                {
                    Reports.StatusUpdate("Opened in Error alert popped-up !", true);
                }
                VerifyFileIsOpenedOnFileHomePage(fileNumber, fileStatus);
            }

            if (MultipleRecordsDisplayed)
            {
                //Reports.TestStep = "Check if the file created in this test is listed in the dialog";
                //int currentRow = FastDriver.FileNumberSearchSelectionDlg.SelectTheSpecifiedFileInTheDialog(fileNumber);
                //FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Check the file just created is listed.";
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(4, GetFileStatusLabel(fileStatus), 4, TableAction.Click);
                FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(1, fileNumber, 1, TableAction.DoubleClick);

                if (fileStatus.Equals("Opened in Error"))
                {
                    Reports.TestStep = "Handle 'Opened in Error' message alert."; ;
                    FastDriver.WebDriver.HandleDialogMessage();//if more than 100 records found alert appeared, this alert pops-up with the message containing 'Cancelled'.
                }
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //FastDriver.FileSearch.SwitchToContentFrame();
                VerifyFileIsOpenedOnFileHomePage(fileNumber, fileStatus);
            }
        }

        private void VerifyFileIsOpenedOnFileHomePage(string fileNumber, string fileStatus)
        {
            FastDriver.FileHomepage.WaitForScreenToLoad();
            if (fileNumber == FastDriver.FileHomepage.GetFileNumber())
                Reports.StatusUpdate(fileStatus + " file opened on File Homepage!", true);
        }

        private string GetFileStatusLabel(string fileStatus)
        {
            string fileStatusLabel = "";
            switch (fileStatus)
            {
                case "Opened in Error":
                    fileStatusLabel = "Open In Error";
                    break;

                case "Closed":
                    fileStatusLabel = "Closed";
                    break;

                case "Cancelled":
                    fileStatusLabel = "Cancelled";
                    break;
            }
            return fileStatusLabel;
        }

        private bool WaitForEitherElementsAndRetryFileSearch(string fileNumber = "")
        {
            int retryCount = 1;
            string alertMessage = "";
            bool result = false;
            while (retryCount <= 10)
            {
                FastDriver.FileSearch.FindNow.FAClick();

                if (retryCount == 1)
                {
                    Reports.TestStep = "Handle 'No match found' alert, if appears.";
                }
                alertMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, 30);

                if (alertMessage.Equals("No match found."))
                {
                    System.Threading.Thread.Sleep(7000);
                    Reports.StatusUpdate("Retrying for file search after waiting for 5 seconds : " + retryCount++, true);
                    FastDriver.FileSearch.SwitchToContentFrame();
                    continue;
                }

                WaitForEitherElements(FastDriver.FileSearch.SearchResultTableExchange, FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo);

                FastDriver.FileSearch.SwitchToContentFrame();
                if (!alertMessage.Equals("No match found.") && FastDriver.FileSearch.SearchResultTableExchange.IsVisible())
                {
                    if (!string.IsNullOrEmpty(fileNumber) && !FastDriver.FileSearch.SearchResultTableExchange.FAGetText().Contains(fileNumber))
                    {
                        System.Threading.Thread.Sleep(5000);
                        Reports.StatusUpdate("Retrying search from the Search Results Grid after waiting for 5 seconds : " + retryCount++, true);
                        continue;
                    }
                    FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                    FastDriver.FileSearch.SearchResultTableExchange.PerformTableAction(4, "Pending", 4, TableAction.Click);
                    FastDriver.FileSearch.Select.FAClick();
                    result = true;
                    break;
                }

                if (!alertMessage.Equals("No match found.") && FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.IsVisible())
                {
                    result = true;
                    break;
                }
            }
            return result;
        }

        private bool WaitForEitherElements(IWebElement element, IWebElement alternateElement)
        {
            return Report.UpdateLog<bool>(element, "Wait", "Visible", "Element, Alternate Element", () =>
            {
                WebDriverWait Wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(Convert.ToInt32(AutoConfig.WaitTime)));
                try
                {
                    FastDriver.FileSearch.SwitchToContentFrame();
                    Wait.Until(FAExpectedConditions.ElementIsVisible(element));
                }
                catch (WebDriverTimeoutException)
                {
                    FastDriver.NewFileEntry.SwitchToContentFrame();
                    if (alternateElement.IsVisible())
                    {
                        return true;
                    }
                    throw;
                }
                return true;
            });
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}