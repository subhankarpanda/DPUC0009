﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using System.Linq;


namespace FileManagement
{
    [CodedUITest]
    public class FPUC0014 : MasterTestClass
    {
        #region BAT

        #region FPUC0014_BAT0001_02

        [TestMethod]
        public void FPUC0014_BAT0001_02()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "MF1_00: Saving a Favorite Filter.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Remove filter 'FPUC0014-1'";
                FastDriver.MyFASTToday.RemoveFilter(@"FPUC0014-1");

                Reports.TestStep = "Navigate to MFT and select a Employee and click add remove workgroup";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Click on Save button.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.Save.FAClick();
                
                Reports.TestStep = "Save the filter not as primary.";
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.PrimaryFilter.FASetCheckbox(true);
                FastDriver.SaveMyFastTodayFilterDlg.FilterName.FASetText(@"FPUC0014-1");
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);

                Reports.TestStep = "Verify the saved filter.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                value = FastDriver.MyFASTToday.MyFilters.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual("FPUC0014-1", value);
                Support.AreEqual("True", FastDriver.MyFASTToday.FilterEmployee.Exists().ToString());

                #region FPUC0014_BAT0002

                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"Title");

                Reports.TestStep = "Click on Add Remove WorkGroup";
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Click on Save button.";
                FastDriver.MyFASTToday.Save.FAClick();

                Reports.TestStep = "Save the filter not as primary.";
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.PrimaryFilter.FASetCheckbox(true);
                FastDriver.SaveMyFastTodayFilterDlg.FilterName.FASetText(@"FPUC0014-1");
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false, timeout: 10);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.Cancel.FAClick();

                Reports.TestStep = "Verify the user.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                value = FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"QA07, FAST", value);
                value = FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"All", value);
                value = FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"QA07, FAST", value);
                value = FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Title", value);
                value = FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Show all", value);

                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0002


        [TestMethod]
        public void FPUC0014_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.StatusUpdate("This TC was merged with FPUC0014_BAT0001.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0003

        [TestMethod]
        public void FPUC0014_BAT0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF2_00: Clear Filters.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Clear Filters.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItem(@"");
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"Title");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Add remove task office.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();

                Reports.TestStep = "Select a Task Office";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on ClearSearchFilter.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.ClearSearchFilter.FAClick();
                
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the default values after clicking on Clear.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                value = FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"QA07, FAST", value);
                value = FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"All Categories", value);
                value = FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Show all", value);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0004

        [TestMethod]
        public void FPUC0014_BAT0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF3_00: Delete a Favorite Filter.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MFT and select a Employee and click add remove workgroup";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Click on Save button.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.Save.FAClick();

                Reports.TestStep = "Save the filter not as primary.";
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.PrimaryFilter.FASetCheckbox(true);
                FastDriver.SaveMyFastTodayFilterDlg.FilterName.FASetText(@"FPUC0014-Delete");
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);

                Reports.TestStep = "Verify the saved filter.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                
                Reports.TestStep = "Delete a Favorite Filter.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItem(@"FPUC0014-Delete");
                FastDriver.MyFASTToday.Delete.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the My filters after deleting the filter.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                value = FastDriver.MyFASTToday.MyFilters.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"", value);
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0005

        [TestMethod]
        public void FPUC0014_BAT0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF5_00: Active Tasks � Filter by Employee.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Active Tasks � Filter by Employee.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"Title");
                
                Reports.TestStep = "Select Unassigned  in Work Group";
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Add remove task office.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();

                Reports.TestStep = "Select a Task Office";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();

                Reports.TestStep = "Validate the fields when filtered by task office.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                value = FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"QA07, FAST", value);
                value = FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Title", value);
                FastDriver.MyFASTToday.TaskNameElement.FAClick();
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();

                Reports.TestStep = "Select a Task Name in Dlg";
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Verify the active tasks shown for the selected employee.";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("Assigned To", "QA07, FAST", "Assigned To", TableAction.Click);
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0006

        [TestMethod]
        public void FPUC0014_BAT0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF6_00: Active Tasks � Filter by Workgroup.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Active Tasks � Filter by Employee.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"Title");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                                
                Reports.TestStep = "Select a WorkGroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Accounting", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                
                Reports.TestStep = "Click on Find Now";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the fields when filtered by employee and workgroup.";
                value = FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"QA07, FAST", value);
                value = FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Title", value);
                FastDriver.MyFASTToday.AccountingElement.FAClick();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0007

        [TestMethod]
        public void FPUC0014_BAT0007()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF7_00: Active Tasks � Filter by Task Name.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Active Tasks � Filter by Task Name.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();
                
                Reports.TestStep = "Select a Task Name in Dlg";
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Click on Add remove task office.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();

                Reports.TestStep = "Select a Task Office";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Add Remove Task Name";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();

                Reports.TestStep = "Select a Task Name in Dlg";
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Validate the fields when filtered by task office.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                value = FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"QA07, FAST", value);
                value = FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"All Categories", value);
                FastDriver.MyFASTToday.TaskNameElement.FAClick();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0008

        [TestMethod]
        public void FPUC0014_BAT0008()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF8_00: Active Tasks � Filter by Task Office.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Active Tasks � Filter by Task Name.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();

                Reports.TestStep = "Select a Task Name in Dlg";
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the fields when filtered by task name.";
                value = FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"QA07, FAST", value);
                value = FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"All Categories", value);
                FastDriver.MyFASTToday.ADECITIBILLFULL.FAClick();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0009_10

        [TestMethod]
        public void FPUC0014_BAT0009_10()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF9_00: Active Tasks � Filter by Task Region.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Active Tasks � Filter by Task Name.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();
                
                Reports.TestStep = "Select a Task Name in Dlg";
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the fields when filtered by task region.";
                value = FastDriver.MyFASTToday.TaskRegion.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(AutoConfig.SelectedRegionName, value);
                Support.AreEqual("ADEC-ITI-BILL-FULL", FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("Assigned To", "QA07, FAST", "Task", TableAction.GetText).Message.Clean());
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("WorkGroup", "Unassigned", "Assigned To", TableAction.GetText).Message.Clean());

                #region FPUC0014_BAT0010

                Reports.StatusUpdate("AF10_00: Active Tasks - Select for File Workflow Screen Viewing.", true);

                Reports.TestStep = "Active Tasks - Select for File Workflow Screen Viewing.";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("Task", "ADEC-ITI-BILL-FULL", "Task", TableAction.DoubleClick);
                                
                Reports.TestStep = "Verify the File Work Flow screen.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                
                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0010

        [TestMethod]
        public void FPUC0014_BAT0010()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF10_00: Active Tasks - Select for File Workflow Screen Viewing.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FPUC0014_BAT0009.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0011

        [TestMethod]
        public void FPUC0014_BAT0011()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF11_00: Active Tasks - View Event Log Dialog Box.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click find, select task and click Event log.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.SelectActiveTask1.FAClick();
                FastDriver.MyFASTToday.EventLogTasks.FAClick();

                Reports.TestStep = "Validate the event log page";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                value = FastDriver.EventTrackingLogDlg.EventCategory.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Workflow", value);
                
                Reports.TestStep = "Click on Done after verifying Manually";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the MyFastToday screen.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0012

        [TestMethod]
        public void FPUC0014_BAT0012()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF12_00: Active Tasks � Start a Task.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Active Tasks � Start a Task.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 10, TableAction.Click);
                FastDriver.MyFASTToday.AssignedTo.FASelectItem(@"++View Offices...");
                                
                Reports.TestStep = "Select an employee.";
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                FastDriver.EmployeeSelectionbyOfficeDlg.SelectOffice.FASelectItem(AutoConfig.SelectedOfficeName);
                FastDriver.EmployeeSelectionbyOfficeDlg.QA08.FAClick();
                FastDriver.EmployeeSelectionbyOfficeDlg.Select.FAClick();
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0013

        [TestMethod]
        public void FPUC0014_BAT0013()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF13_00: Active Tasks - Assigned To.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Active Tasks � Start a Task.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 10, TableAction.Click);
                FastDriver.MyFASTToday.AssignedTo.FASelectItem(@"++View Offices...");

                Reports.TestStep = "Select an employee.";
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                FastDriver.EmployeeSelectionbyOfficeDlg.SelectOffice.FASelectItem(AutoConfig.SelectedOfficeName);
                FastDriver.EmployeeSelectionbyOfficeDlg.QA08.FAClick();
                FastDriver.EmployeeSelectionbyOfficeDlg.Select.FAClick();

                Reports.TestStep = "Verify the Assigned To column.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(9, "QA08, FAST", 9, TableAction.Click);
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0014


        [TestMethod]
        public void FPUC0014_BAT0014()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF13_00: Active Tasks - Assigned To.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Active Tasks � Start a Task.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 10, TableAction.Click);
                FastDriver.MyFASTToday.AssignedTo.FASelectItem(@"++View Offices...");

                Reports.TestStep = "Select an employee.";
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                FastDriver.EmployeeSelectionbyOfficeDlg.SelectOffice.FASelectItem(AutoConfig.SelectedOfficeName);
                FastDriver.EmployeeSelectionbyOfficeDlg.QA09.FAClick();
                FastDriver.EmployeeSelectionbyOfficeDlg.Select.FAClick();

                Reports.TestStep = "Verify the Assigned To column.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(9, "QA09, FAST", 9, TableAction.Click);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0015

        [TestMethod]
        public void FPUC0014_BAT0015()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF15_00: Active Tasks � Workgroup � View More Workgroup.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Active Tasks � Workgroup � View More Workgroup.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 8, TableAction.Click);
                FastDriver.MyFASTToday.WorkgroupSelect.FASelectItem(@"++View More Workgroups...");
                                                
                Reports.TestStep = "Select a Work Group";
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem(@"Accounting");
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Verify the changed Workgroup in the active tasks table.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Accounting", 7, TableAction.Click);
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_BAT0016

        [TestMethod]
        public void FPUC0014_BAT0016()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                int selectedRow = 0;
                var taskName = "";
                int rowCount = 0;
                bool navFlag = true;
                #endregion

                #region UI Interaction

                Reports.TestDescription = "AF16_00: Active Tasks � Complete a Task.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                
                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Remove filter.";
                FastDriver.MyFASTToday.RemoveFilter("Test Filter");

                Reports.TestStep = "Set Filters to Perform the search.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Perform the Search and Mark Task as Completed.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                selectedRow = FastDriver.MyFASTToday.MarkTaskAs(FastDriver.MyFASTToday._ActiveTasksTable, TaskStatus.Complete);
                Support.AreEqual(@"QA07, FAST", FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(selectedRow, 9, TableAction.GetText).Message.Clean());
                Support.AreEqual(@"True", FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(selectedRow, 1, TableAction.GetCell).Element.FAFindElements(ByLocator.TagName, "input").GetAllVisible()
                    .FirstOrDefault(i => i.FAGetAttribute("id").Contains("chkStart")).Selected.ToString(), "Verify whether the Start checkbox is select.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(selectedRow, 2, TableAction.GetCell).Element.FAFindElements(ByLocator.TagName, "input").GetAllVisible()
                    .FirstOrDefault(i => i.FAGetAttribute("id").Contains("chkComplete")).Selected.ToString(), "Verify whether the Complete checkbox is select.");
                taskName = FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(selectedRow, 5, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Save filter as Test Filter";
                FastDriver.MyFASTToday.Save.FAClick();
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.PrimaryFilter.FASetCheckbox(true);
                FastDriver.SaveMyFastTodayFilterDlg.FilterName.FASetText(@"Test Filter");
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                FastDriver.MyFASTToday.WaitForScreenToLoad();

                Reports.TestStep = "Verify whether the event Log has been created and check the User Name.";
                FastDriver.MyFASTToday.EventLogTasks.FAClick();
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual(@"QA07, FAST", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Owner Assigned]", 4, TableAction.GetText).Message.Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verify whether the process has been Started ir Completed in FileWorkflow screen.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(selectedRow, 5, TableAction.DoubleClick);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    if (navFlag)
                    {
                        navFlag = false;
                        return FastDriver.FileWorkflow.ProcessStarted.Exists() || FastDriver.FileWorkflow.ProcessCompleted.Exists();
                    }
                    FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                    return FastDriver.FileWorkflow.ProcessStarted.Exists() || FastDriver.FileWorkflow.ProcessCompleted.Exists();
                }, timeout: 90, idleInterval: 10);
                Reports.StatusUpdate("The task is completed, process appears in Started/Completed status.", FastDriver.FileWorkflow.ProcessStarted.Exists() || FastDriver.FileWorkflow.ProcessCompleted.Exists());

                Reports.TestStep = "Verify event log for the Completed Task in Event/Tracking Log screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                rowCount = FastDriver.EventTrackingLog.EventTable.GetRowCount();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"All");
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    return rowCount != FastDriver.EventTrackingLog.EventTable.GetRowCount();
                }, timeout: 20, idleInterval: 2);
                Support.AreEqual(@"Task: " + taskName, FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Task Completed]", "Comments", TableAction.GetText).Message.Clean());


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region REG

        #region FPUC0014_REG0001

        [TestMethod]
        public void FPUC0014_REG0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "TFS_Enh_104928_DW002: Validate in Regional Process screen that Eligible as Priority Process check box is present";

                Reports.TestStep = "Log into FAST application, ADM side.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad().EnterBUID(AutoConfig.SelectedRegionBUID);
                
                Reports.TestStep = "Navigate to Regional Process Summary and select a template";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction("Process Name", "AUTO_DONOT_TOUCH_StandardTemplateForSanity", "Process Name", TableAction.Click);
                                
                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add/Remove button for Process Event Selection.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();

                Reports.TestStep = "Select File With Open State and Pending State";
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProcessEventSelectionDlg.FilecreatedwithOpenstatus.FASetCheckbox(true);
                FastDriver.ProcessEventSelectionDlg.FilecreatedwithPendingStatus.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the presence of Eligible Priority process checkbox";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select a task and click on Refresh button.";
                FastDriver.PendingRefreshSummary.RefreshProcessTemplate("AUTO_DONOT_TOUCH_StandardTemplateForSanity");
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0002_03

        [TestMethod]
        public void FPUC0014_REG0002_03()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "TFS_Enh_104928_SMUC0048: Add the activity right:EXPECTED FAILURE ONLY WHEN IF THE RIGHT IS ALREADY ADDED";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Verify whether the Role exists.";
                if(AutoConfig.UseCDFormType)
                    CreateRole("QA Load Test Regional Role - CD");
                else
                    CreateRole("QA Load Test Regional Role - HUD");

                Reports.TestStep = "Select QA Load Test Regional Role.";
                FastDriver.LeftNavigation.Navigate<RoleMaintenanceSummary>(@"Home>System Maintenance>Security Maintenance>Role Maintenance").WaitForScreenToLoad();
                if(AutoConfig.UseCDFormType)
                    FastDriver.RoleMaintenanceSummary.QALoadTestRegionalRole.FAClick();
                else
                    FastDriver.RoleMaintenanceSummary.QALoadTestRegionalRoleHUD.FAClick();
                Playback.Wait(500);
                Keyboard.SendKeys("%E");

                Reports.TestStep = "Validate that activity right is present in region level and add the Activity right.";
                FastDriver.RoleSetup.WaitForScreenToLoad(FastDriver.RoleSetup.Region);
                if (AutoConfig.UseCDFormType)
                    FastDriver.RoleSetup.ActivityGroup.FASelectItemByIndex(4);
                else if (!AutoConfig.UseCDFormType)
                    FastDriver.RoleSetup.ActivityGroup.FASelectItemByIndex(7);
                value = FastDriver.RoleSetup.ActivityGroup.FAGetSelectedItem();
                if (value == null)
                    value = "";
                if (AutoConfig.UseCDFormType)
                    Support.AreEqual(@"Office Business Unit Processing Activity Group", value);
                else if (!AutoConfig.UseCDFormType)
                    Support.AreEqual(@"Regional Owning Workflow Processing Activity Group", value);
                if (FastDriver.RoleSetup.AvailableRightsTable.Text.Contains("Workflow Priority Flag Activity"))
                {
                    FastDriver.RoleSetup.AvailableRightsTable.PerformTableAction(2, "Workflow Priority Flag Activity", 1, TableAction.On);
                    FastDriver.RoleSetup.Add.FAClick();

                    Reports.TestStep = "Click on Save.";
                    FastDriver.BottomFrame.Save();

                    Reports.TestStep = "Track changes while Create Group Setup.";
                    FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                    FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText(@"123");
                    FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();
                }
                else
                    Reports.StatusUpdate("Right is already added.", true);

                #region FPUC0014_REG0003

                Reports.StatusUpdate("************FPUC0014_REG0003************", true);

                Reports.TestStep = "Validate that the activity right is added.";
                FastDriver.RoleSetup.WaitForScreenToLoad();
                FastDriver.RoleSetup.SelectedRightsTable.PerformTableAction(2, "Workflow Priority Flag Activity", 2, TableAction.Click);
                
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0003


        [TestMethod]
        public void FPUC0014_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "TFS_Enh_104928_SMUC0048_Validation: Validate that the activity right is added";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FPUC0014_REG0002.", true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0005

        [TestMethod, Timeout(Int32.MaxValue)]
        public void FPUC0014_REG0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "REG_001: (FP7016_FP9411_FP9412_FP9413_FP9414_FP9417_FP9418)1.My FAST Today Screen 2.Alerts 3.Select Alerts Assigned To An Employee 4.Summary Alerts 5.Filter Alerts Based on Assignment 6.File Alerts Type 7.Service Added,";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select a task and click on Assign to";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    if (FastDriver.MyFASTToday._ActiveTasksTable.Text.Contains("AUTO_ProActiveTask_DONOTTOUCH_Task1"))
                    {
                        FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(5, "AUTO_ProActiveTask_DONOTTOUCH_Task1", 10, TableAction.Click);
                        return true;
                    }
                    else
                    {
                        FastDriver.MyFASTToday.Next.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                        FastDriver.MyFASTToday.WaitForScreenToLoad();
                    }
                    return !FastDriver.MyFASTToday.Next.Enabled;
                }, timeout: 5000, idleInterval: 5);
                FastDriver.MyFASTToday.AssignedTo.FASendKeys(@"++");

                Reports.TestStep = "Select an employee.";
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                FastDriver.EmployeeSelectionbyOfficeDlg.SelectOffice.FASelectItem(AutoConfig.SelectedOfficeName);
                FastDriver.EmployeeSelectionbyOfficeDlg.HomeOfficeOnly.FASetCheckbox(false);
                FastDriver.EmployeeSelectionbyOfficeDlg.QA071.FAClick();
                FastDriver.EmployeeSelectionbyOfficeDlg.Select.FAClick();

                Reports.TestStep = "Select a Task Region";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);

                Reports.TestStep = "Click on Add remove task name.";
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();

                Reports.TestStep = "Select a Task a Name and Click on Select button.";
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Waive a Task";
                FastDriver.MyFASTToday.WaiveTask.FASetCheckbox(true);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to FWF.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();

                Reports.TestStep = "Validate File Workflow Screen and validate Service Removed";
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Escrow Service Removed", "Message", TableAction.Click);
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0006

        [TestMethod]
        public void FPUC0014_REG0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "REG_002: (FP7017_FP7105_FP7018_FP4680_FP4687_FP7019_FP7020_FP7021_FP7023_FP7024_FP7026_FP7027_FP9743_FP9773_FP9775)1.Primary Filters 2.Active Task Filters 3.Default Filter when User has Non Saved 4.Employee or FOR Filter";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigating to MFT Screen and Verify functionality";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                Support.AreEqual(@"False", FastDriver.MyFASTToday.DeleteAlerts.Selected.ToString(), "Verify whether the 'DeleteAlerts' checkbox is uncheked.");
                Support.AreEqual(@"False", FastDriver.MyFASTToday.Save.Enabled.ToString(), "Verify whether the 'Save' button is Disabled.");
                Support.AreEqual(@"False", FastDriver.MyFASTToday.Delete.Enabled.ToString(), "Verify whether the 'Delete' button is Disabled.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday.ClearSearchFilter.Enabled.ToString(), "Verify whether the 'ClearSearchFilter' button is Enabled.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday.Apply.Enabled.ToString(), "Verify whether the 'Apply' button is Enabled.");
                value = FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"QA07, FAST", value);
                value = FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"All Categories", value);
                value = FastDriver.MyFASTToday.FileOwningRegion.FAGetSelectedIndex().ToString();
                if (value == null)
                    value = "";
                Support.AreEqual(@"0", value, "Verify whether the selected index of 'FileOwningRegion' is Zero.");
                value = FastDriver.MyFASTToday.TaskRegion.FAGetSelectedIndex().ToString();
                if (value == null)
                    value = "";
                Support.AreEqual(@"0", value, "Verify whether the selected index of 'FileOwningRegion' is Zero.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday.AddRemoveWorkGroup.Enabled.ToString(), "Verify whether the 'AddRemoveWorkGroup' button is Enabled.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday.AddRemoveTaskOffice.Enabled.ToString(), "Verify whether the 'AddRemoveTaskOffice' button is Enabled.");
                Support.AreEqual(@"False", FastDriver.MyFASTToday.AddRemoveTaskName.Enabled.ToString(), "Verify whether the 'AddRemoveTaskName' button is Disabled.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday.FindNow.Enabled.ToString(), "Verify whether the 'FindNow' button is Enabled.");

                Reports.TestStep = "Validate Filter Employee or For";
                value = FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("QA07, FAST", value);
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Validate a Work Group in Dlg";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Validate Filter Task Category";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                value = FastDriver.MyFASTToday.FilterTaskCategory.Text;
                if (value == null)
                    value = "";
                Support.AreEqual("True", value.Contains("All Categories Open Order Title Escrow Epic Post Closing Miscellaneous").ToString(), 
                    "Verify whether 'All Categories Open Order Title Escrow Epic Post Closing Miscellaneous' options are available within 'FilterTaskCategory' dropdown.");
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();

                Reports.TestStep = "Validate a Task Office in Dlg";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();

                Reports.TestStep = "Validate Filter File Owning Region";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                Support.AreEqual(@"True", FastDriver.MyFASTToday.AddRemoveTaskName.Enabled.ToString(), "Verify whether the 'AddRemoveTaskName' button is Enabled.");
                FastDriver.MyFASTToday.TaskRegion.FAClick();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate a Message and click on OK";
                Support.AreEqual(@"A Task Name is required when a Task Region is selected.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click on Add Remove Task Name";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();

                Reports.TestStep = "Validate a Task Name in Dlg";
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0007

        [TestMethod]
        public void FPUC0014_REG0007()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "REG_003: (FP7029_FP7030_FP7106_FP7103_FP7104_FP7107_FP7031_FP7032)1.Additional Search Filters 2.Business Source 3.Invoking GAB Search 4.Exact Match on ID Code or Name 5.Direct Search by ID Code 6.Direct Search by Name 7.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigating to MFT Screen and select workgroup, taskOffice and taskName.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.TaskRegion.FAClick();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Expand Additional Filter Search and Click on Find Button";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.TaskRegion.FASelectItemByIndex(0);
                FastDriver.MyFASTToday.AddSearchFexpand.FAClick();
                Support.AreEqual(@"True", FastDriver.MyFASTToday.EditAdditionalFilters.Enabled.ToString(), "Verify whether the 'EditAdditionalFilters' button is Enabled.");
                FastDriver.MyFASTToday.Find.FAClick();

                Reports.TestStep = "Enter a GAB Code, Search, Select and Click on Done";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.IDCode.FASetText(@"MORTLNDR");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.SearchResultsRadio.FASetCheckbox(true);
                Support.AreEqual(@"MORTLNDR", FastDriver.AddressBookSearchDlg.SearchresultIDcode.Text.Clean());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate ID Code after searching from Address Book and click on Find";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreEqual(@"MORTLNDR", FastDriver.MyFASTToday.AddSearchIDCodePane.Text.Clean());
                FastDriver.MyFASTToday.Find.FAClick();

                Reports.TestStep = "Enter a GAB Code, Search, Select and Click on Done";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.EntityName);
                FastDriver.AddressBookSearchDlg.EntityName.FASetText(@"Lenders Advantage");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.SearchResultsRadio.FASetCheckbox(true);
                Support.AreEqual(@"247", FastDriver.AddressBookSearchDlg.SearchresultIDcode.Text.Clean());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate ID Code and make a Direct Search by GAB";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreEqual(@"247", FastDriver.MyFASTToday.AddSearchIDCodePane.Text.Clean());
                FastDriver.MyFASTToday.GABCode.FASetText(@"HUDASLNDR1");
                FastDriver.MyFASTToday.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Validate ID Code and make a Direct Search by Name";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreEqual(@"HUDASLNDR1", FastDriver.MyFASTToday.AddSearchIDCodePane.Text.Clean());
                FastDriver.MyFASTToday.GABName.FASetText(@"Thomas Freeman");
                FastDriver.MyFASTToday.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Validate ID Code and Recent used GAB Code";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreEqual(@"255", FastDriver.MyFASTToday.AddSearchIDCodePane.Text.Clean());

                Reports.TestStep = "Click on ClearSearchFilter";
                FastDriver.MyFASTToday.ClearAddSearchFilter.FAClick();

                Reports.TestStep = "Enter a GAB Code and click on Find";
                FastDriver.MyFASTToday.GABCode.FASetText(@"HUDFLINSR1");
                FastDriver.MyFASTToday.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Find Now";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.FindNow.FAClick();
                value = FastDriver.MyFASTToday._ActiveTasksTable.Text;

                Reports.TestStep = "Select a File Owning Office and Click On Find Now";
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.FindNow.FAClick();
                Support.AreEqual(@"True", FastDriver.MyFASTToday._ActiveTasksTable.Text.Contains(value).ToString(), "Verify table content consistency.");
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0008

        [TestMethod]
        public void FPUC0014_REG0008()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "REG_004: (FP7033_FP7034_FP7035_FP7036_FP7037_FP7038_FP7039_FP7040_FP7041_FP7042_FP7043_FP7045_FP7046_FP7047_FP7048_FP7049_FP7050_FP7051_FP7052_FP7053_FP7054_FP7055_FP7056_FP7057_FP7058_FP7059_FP7060_FP7061) 1. Service Ty";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MFT and click on Edit Additional features";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.EditAdditionalFilters.FAClick();

                Reports.TestStep = "Verify the functionality in the Screen 1";
                FastDriver.FilterSelectionCriteriaDlg.WaitForScreenToLoad();
                Support.AreEqualTrim(@"Title Escrow Title/Escrow Title/SubEscrow Escrow/SubEscrow", FastDriver.FilterSelectionCriteriaDlg.Service.Text.Clean());
                Support.AreEqualTrim(@"Accommodation Bulk Sale Construction Disbursement Construction Finance Construction Loan Equity Loan Foreclosure Limited Escrow Mortgage Modification Mtg Mod w/Endorsement Mtg Mod w/Increased Liability Refinance REO REO Sale w/Mortgage REO Sale/Cash Sale w/Construction Loan Sale w/Mortgage Sale/Cash Sale/Exchange Search Package Second Mortgage Settlement Statement Only Short Sale Short Sale w/Mortgage Short Sale/Cash", 
                    FastDriver.FilterSelectionCriteriaDlg.TransType.Text.Clean());
                Support.AreEqualTrim(@"Residential Commercial New Home/Subdivision New Home Subdivision Default Time Share Default-Residential Default-Commercial", FastDriver.FilterSelectionCriteriaDlg.BusSeg.Text.Clean());
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveProdtype.Enabled.ToString(), "Verify whether the 'AddRemoveProdtype' button is Enabled.");
                Support.AreEqual(@"False", FastDriver.FilterSelectionCriteriaDlg.AddRemoveEscrowowning.Enabled.ToString(), "Verify whether the 'AddRemoveEscrowowning' button is Disabled.");
                Support.AreEqual(@"False", FastDriver.FilterSelectionCriteriaDlg.AddRemoveTitleowning.Enabled.ToString(), "Verify whether the 'AddRemoveTitleowning' button is Disabled.");
                Support.AreEqualTrim(@"USA CANADA", FastDriver.FilterSelectionCriteriaDlg.Country.Text.Clean());
                Support.AreEqual(@"63", FastDriver.FilterSelectionCriteriaDlg.State.FAFindElements(ByLocator.TagName, "option").Count().ToString(), "Verify the numbers of items contained within 'State' dropdown.");
                Support.AreEqual(@"0", FastDriver.FilterSelectionCriteriaDlg.County.FAFindElements(ByLocator.TagName, "option").Count().ToString(), "Verify the numbers of items contained within 'County' dropdown.");
                                
                Reports.TestStep = "Verify the functionality in the Screen 2";
                FastDriver.FilterSelectionCriteriaDlg.Country.FASelectItem(@"USA");
                Support.AreEqualTrim(@"AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY", 
                    FastDriver.FilterSelectionCriteriaDlg.State.Text.Clean());
                Support.AreEqual(@"0", FastDriver.FilterSelectionCriteriaDlg.County.FAFindElements(ByLocator.TagName, "option").Count().ToString(), "Verify the numbers of items contained within 'County' dropdown.");
                
                Reports.TestStep = "Verify the functionality in the Screen 3";
                FastDriver.FilterSelectionCriteriaDlg.State.FASelectItem(@"CA");
                Support.AreEqualTrim(@"ALAMEDA ALPINE AMADOR BUTTE CALAVERAS COLUSA CONTRA COSTA DEL NORTE EL DORADO FRESNO GLENN HUMBOLDT IMPERIAL INYO KERN KINGS LAKE LASSEN LOS ANGELES MADERA MARIN MARIPOSA MENDOCINO MERCED MODOC MONO MONTEREY NAPA NEVADA ORANGE PLACER PLUMAS RIVERSIDE SACRAMENTO SAN BENITO SAN BERNARDINO SAN DIEGO SAN FRANCISCO SAN JOAQUIN SAN LUIS OBISPO SAN MATEO SANTA BARBARA SANTA CLARA SANTA CRUZ SHASTA SIERRA SISKIYOU SOLANO SONOMA STANISLAUS SUTTER TEHAMA TRINITY TULARE TUOLUMNE VENTURA YOLO YUBA", 
                    FastDriver.FilterSelectionCriteriaDlg.County.Text.Clean());
                Support.AreEqualTrim(@"Escrow Assistant Escrow Officer Title Assistant Title Officer", FastDriver.FilterSelectionCriteriaDlg.EmpRole.Text.Clean());
                Support.AreEqual(@"1", FastDriver.FilterSelectionCriteriaDlg.EmpName.FAFindElements(ByLocator.TagName, "option").Count().ToString(), "Verify the numbers of items contained within 'EmpName' dropdown.");
                                
                Reports.TestStep = "Verify the functionality in the Screen 4";
                FastDriver.FilterSelectionCriteriaDlg.EmpRole.FASelectItem(@"Title Officer");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.EmpName.Text.Clean().Contains(@"FAST QA07").ToString(), "Verify whether 'FAS QA07' text is present within 'EmpName' element text.");

                Reports.TestStep = "Verify the functionality in the Screen 5";
                Support.AreEqual(@"true", FastDriver.FilterSelectionCriteriaDlg.TransType.FAGetAttribute("multiple") ?? "False", "Verify whether 'TransType' element is multiple options.");
                Support.AreEqual(@"true", FastDriver.FilterSelectionCriteriaDlg.BusSeg.FAGetAttribute("multiple") ?? "False", "Verify whether 'BusSeg' element has multiple options.");
                Support.AreEqual(@"true", FastDriver.FilterSelectionCriteriaDlg.Country.FAGetAttribute("multiple") ?? "true", "Verify whether 'Country' element doesn't have multiple options.");
                Support.AreEqual(@"true", FastDriver.FilterSelectionCriteriaDlg.State.FAGetAttribute("multiple") ?? "False", "Verify whether 'State' element has multiple options.");
                Support.AreEqual(@"true", FastDriver.FilterSelectionCriteriaDlg.County.FAGetAttribute("multiple") ?? "False", "Verify whether 'County' element has multiple options.");
                
                Reports.TestStep = "Click on Add Remove Products";
                FastDriver.FilterSelectionCriteriaDlg.AddRemoveProdtype.FAClick();

                Reports.TestStep = "Select a Product from the table.";
                FastDriver.ProductSelectionDialog.WaitForScreenToLoad();
                FastDriver.ProductSelectionDialog.TableProducts.PerformTableAction(2, "Abstract", 1, TableAction.On);
                FastDriver.ProductSelectionDialog.Clear.FAClick();
                FastDriver.ProductSelectionDialog.Select.FAClick();

                Reports.TestStep = "Click on Done";
                FastDriver.FilterSelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.FilterSelectionCriteriaDlg.Service.FASelectItem(@"");
                FastDriver.FilterSelectionCriteriaDlg.TransType.FASelectItem(@"");
                FastDriver.FilterSelectionCriteriaDlg.BusSeg.FASelectItem(@"");
                FastDriver.FilterSelectionCriteriaDlg.Country.FASelectItem(@"");
                FastDriver.FilterSelectionCriteriaDlg.Done.FAClick();
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0009

        [TestMethod]
        public void FPUC0014_REG0009()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "REG_005: (FP7062_FP7063_FP7064_FP7065_FP7066_FP9489)1.Favorite Filters 2.Personalize My Filter 3.Save Filter 4.Delete Filter 5.Clear Filter 6.Default Filter when User has Saved Filters";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify whether Filter 'New criteria' does exist, if not create it.";
                CreateFilter(@"New criteria");

                Reports.TestStep = "Verify the State of Buttons of My Filter";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                Support.AreEqual(@"False", FastDriver.MyFASTToday.Save.Enabled.ToString(), "Verify whether the 'Save' button is Disabled.");
                Support.AreEqual(@"False", FastDriver.MyFASTToday.Delete.Enabled.ToString(), "Verify whether the 'Delete' button is Disabled.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday.ClearSearchFilter.Enabled.ToString(), "Verify whether the 'ClearSearchFilter' button is Enabled.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday.Apply.Enabled.ToString(), "Verify whether the 'Apply' button is Enabled.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday.FindNow.Enabled.ToString(), "Verify whether the 'FindNow' button is Enabled.");
                                
                Reports.TestStep = "Navigate to MFT and select a saved Filter";
                FastDriver.MyFASTToday.MyFilters.FASelectItem(@"New criteria");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreEqual(@"QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Title", FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem() ?? "");
                Support.AreEqual(AutoConfig.SelectedRegionName, FastDriver.MyFASTToday.FileOwningRegion.FAGetSelectedItem() ?? "");
                Support.AreEqual(AutoConfig.SelectedRegionName, FastDriver.MyFASTToday.TaskRegion.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem() ?? "");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Click on Save button.";
                FastDriver.MyFASTToday.Save.FAClick();

                Reports.TestStep = "Save a Primary Filter";
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.PrimaryFilter.FASetCheckbox(true);
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();

                Reports.TestStep = "Click on ClearSearchFilter.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.ClearSearchFilter.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqual(@"Clear current filter values?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "Click on Find Now.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Click on Save button.";
                FastDriver.MyFASTToday.Save.FAClick();
                
                Reports.TestStep = "Save a Primary Filter";
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.PrimaryFilter.FASetCheckbox(true);
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqual(@"Filter Name was not entered", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Save a Filter";
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.FilterName.FASetText(@"FPUCReg");
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();

                Reports.TestStep = "Navigate to MFT and Validate My Filter Primary";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                Support.AreEqual(@"FPUCReg", FastDriver.MyFASTToday.MyFilters.FAGetSelectedItem() ?? "");

                Reports.TestStep = "Click on Delete";
                FastDriver.MyFASTToday.Delete.FAClick();

                Reports.TestStep = "Validate a Message and click on OK";
                Support.AreEqual(@"Delete selected filter?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                Reports.TestStep = "Validate the Deletion of a Filter";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.MyFASTToday.MyFilters.Text.Contains(@"FPUCReg").ToString(), "Verify whether 'FPUCReg' option is not present within 'MyFilters' dropdown.");
                Support.AreEqual(@"False", FastDriver.MyFASTToday.Save.Enabled.ToString(), "Verify whether the 'Save' button is Disabled.");
                Support.AreEqual(@"True", FastDriver.MyFASTToday.Delete.Enabled.ToString(), "Verify whether the 'Delete' button is Enabled.");
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0010

        [TestMethod]
        public void FPUC0014_REG0010()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP8268_FP9420_FP7113_FP9421_FP9423_FP7112_FP9444: 1.Navigate to FAST Main Source Screen in Split Screen Workflow 2.Active Tasks 3.Active Task Roll Off 4.Active Tasks Visible 5.File Number 6.Navigate to File Workflow 7.St";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Start a Task with Priority";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                var tableID = FastDriver.FileWorkflow.CheckPriorityWaive_Process(@"AUTO_DONOTTOUCH_Template Setup Maintenan");
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(4, "3", 1, TableAction.On);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on Find Now,Select a Task and save file number";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("WorkGroup", "Unassigned", "WorkGroup", TableAction.Click);
                var Filenumber = FastDriver.MyFASTToday.Filenumber.FAGetText().Clean();

                Reports.TestStep = "Dclick on the task";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("WorkGroup", "Unassigned", "WorkGroup", TableAction.DoubleClick);

                Reports.TestStep = "Verify File Workflow page is loaded";
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Verify File No";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(Filenumber, FastDriver.FileHomepage.FileNum.FAGetValue().Clean());

                Reports.TestStep = "Navigate to MFT and Verify File No";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                Support.AreEqual(Filenumber, FastDriver.MyFASTToday.Filenumber.FAGetText().Clean());

                Reports.TestStep = "Dclick on the task";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("WorkGroup", "Unassigned", "WorkGroup", TableAction.DoubleClick);
                
                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Open in error.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(@"Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem() ?? "");
                FastDriver.TermsDatesStatus.Status.FASelectItem(@"Open In Error");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to MFT and Neg Verify the file no";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                Support.AreNotEqual(Filenumber, FastDriver.MyFASTToday.Filenumber.FAGetText().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0011

        [TestMethod]
        public void FPUC0014_REG0011()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var FileNum1 = "";
                var TaskName1 = "";
                var TaskOffice1 = "";
                var FileNumber = "";
                var WorkGroup1 = "";
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP9422_FP9425_FP9426_FP9427_FP9431_FP9432_FP9438_FP9428: 1.Active Task Name 2.Assigned To 3.Assign Employee To a Task 4.Owner Office Tool Tip 5.Change the Employee Name on a Task 6.Unique Employee ID 7.Reassign Employee";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FileNum1 = File.FileNumber;

                Reports.TestStep = "Start a Task with Priority and save task and office name and Click Apply";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                var processTableID = FastDriver.FileWorkflow.CheckPriorityWaive_Process(@"AUTO_DONOTTOUCH_Template Setup Maintenan");
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(4, "3", 1, TableAction.On);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                //FastDriver.FileWorkflow.ProcessTask1.FAClick();
                TaskName1 = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(1, 5, TableAction.GetText).Message.Clean();
                TaskOffice1 = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(2, 6, TableAction.GetText).Message.Clean();
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Find Now,Select a Task and  verify Task Name nad Task Office";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("WorkGroup", "Unassigned", "WorkGroup", TableAction.Click);
                Support.AreEqualTrim(@"QA07, FAST", FastDriver.MyFASTToday.SelectActiveTask1.FAGetText().Clean());
                Support.AreEqual(@"True", FastDriver.MyFASTToday.Filenumber.FAGetAttribute("title").Clean().Contains("Office: " + AutoConfig.SelectedOfficeName).ToString(), "Verify whether the File belongs to the correct Office.");

                Reports.TestStep = "Click On a Task and verify Assigned to";
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 10, TableAction.Click);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AssignedTo.FAGetSelectedItem() ?? "");
                FileNumber = FastDriver.MyFASTToday.Filenumber.FAGetText().Clean();

                Reports.TestStep = "Assign to a Emp and Verify that";
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.AssignedTo.FASelectItem(@"Unassigned");
                Keyboard.SendKeys("%F");
                Support.AreNotEqual(FileNumber, FastDriver.MyFASTToday.Filenumber.FAGetText().Clean());

                Reports.TestStep = "Save Work Group and reassign to Emp";
                WorkGroup1 = FastDriver.MyFASTToday.WorkGroupPane1.FAGetText().Clean();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 10, TableAction.Click);
                FastDriver.MyFASTToday.AssignedTo.FASelectItem(@"QA07, FAST");
                Keyboard.SendKeys("%F");
                Support.AreNotEqual(FileNumber, FastDriver.MyFASTToday.Filenumber.FAGetText().Clean());

                Reports.TestStep = "Verify the Reassign";
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                Support.AreNotEqual(FileNumber, FastDriver.MyFASTToday.Filenumber.FAGetText().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0012

        [TestMethod]
        public void FPUC0014_REG0012()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP9438_FP9439_FP9452: 1.Maintain Workgroup 2.Re-Assign Workgroup 3.Search for Tasks with Unassigned Employee and Specific Workgroup";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MyFastToday, set filters criteria and click on Find Now.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Select a Task and save the properties";
                var WG1 = FastDriver.MyFASTToday.WorkGroupPane1.FAGetText().Clean();
                var AssignTo1 = FastDriver.MyFASTToday.SelectActiveTask1.FAGetText().Clean();
                var FileNum1 = FastDriver.MyFASTToday.Filenumber.FAGetText().Clean();

                Reports.TestStep = "Select a task and assign a workgroup";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 8, TableAction.Click);
                FastDriver.MyFASTToday.WorkgroupSelect.FASendKeys(@"++");

                Reports.TestStep = "Select a Work Group";
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem(@"Accounting");
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Validate the assign of workgroup";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreEqual(@"Accounting", FastDriver.MyFASTToday.WorkGroupPane1.FAGetText().Clean());
                Support.AreEqualTrim(@"Unassigned", FastDriver.MyFASTToday.SelectActiveTask1.FAGetText().Clean());
                Support.AreEqual(FileNum1, FastDriver.MyFASTToday.Filenumber.FAGetText().Clean());

                Reports.TestStep = "Select a Emp and others to find the task";
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"Unassigned");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select a WorkGroup";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Accounting", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                
                Reports.TestStep = "Add Task Category and Task Office";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();

                Reports.TestStep = "Select a Task Office";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate a Task and WorkGroup";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Accounting", 1, TableAction.Off);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                              
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreNotEqual(WG1, FastDriver.MyFASTToday.WorkGroupPane1.FAGetText().Clean());
                Support.AreNotEqual(AssignTo1, FastDriver.MyFASTToday.SelectActiveTask1.FAGetText().Clean());
                Support.AreEqualTrim(FileNum1, FastDriver.MyFASTToday.Filenumber.FAGetText().Clean());
                
                Reports.TestStep = "Select a Task and Change the Work Group";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Accounting", 8, TableAction.Click);
                FastDriver.MyFASTToday.WorkgroupSelect.FASelectItem(@"Unassigned");

                Reports.TestStep = "Select a Task and Change the Assign To";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 10, TableAction.Click);
                FastDriver.MyFASTToday.AssignedTo.FASelectItem(@"QA07, FAST");
                Keyboard.SendKeys("%L");
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();

                Reports.TestStep = "Click on Find Now";
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the Task Presence";
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                Support.AreEqualTrim(@"Unassigned", FastDriver.MyFASTToday.WorkGroupPane1.FAGetText().Clean());
                Support.AreEqual(AssignTo1, FastDriver.MyFASTToday.SelectActiveTask1.FAGetText().Clean());
                Support.AreEqualTrim(FileNum1, FastDriver.MyFASTToday.Filenumber.FAGetText().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0013


        [TestMethod]
        public void FPUC0014_REG0013()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP9436_FP9424_FP7110_FP9457: 1.Active Task Due Date 2.Service Type 3.File Information 4.Call Event Log";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MyFastToday screen, select Filter Employee and click on FindNow.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                var FileNum1 = FastDriver.MyFASTToday.Filenumber.FAGetText().Clean();
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the Task Presence";
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Select a Task and click on SELECT";
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("WorkGroup", "Unassigned", "WorkGroup", TableAction.Click);
                FastDriver.MyFASTToday.TasksSelect.FAClick();

                Reports.TestStep = "Select a Task and click on Details";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.HideComplete.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.QA07_FAST.Exists() && FastDriver.FileWorkflow.QA07_FAST.Displayed)
                {
                    FastDriver.FileWorkflow.QA07_FAST.FAClick();
                    Keyboard.SendKeys("%T");
                }
                else
                    Reports.StatusUpdate(@"Task with user 'QA07, FAST' not found.", false);
                
                Reports.TestStep = "Enter Due date";
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                var DueDate = DateTime.Now.ToUniversalTime().AddHours(-8).ToDateString();
                //var DueDate = DateTime.Now.ToDateString();
                FastDriver.TaskDetailsDlg.DueDate.FASetText(DueDate);
                FastDriver.TaskDetailsDlg.Done.FAClick();

                Reports.TestStep = "Click On Find Now, Select a task and Click FileInfo";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.Click();
                FastDriver.MyFASTToday.MyFilters.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.FAGetAttribute("value").Contains("0")).FAClick();
                Playback.Wait(2000);
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(4, FileNum1, 5, TableAction.Click);
                
                Reports.TestStep = "Click on File Info.";
                FastDriver.MyFASTToday.FileInfo.FAClick();

                Reports.TestStep = "Validate the Service Type";
                FastDriver.FileSummaryDlg.WaitForScreenToLoad();
                Support.AreEqualTrim(@"Title/Escrow", FastDriver.FileSummaryDlg.ServiceType.FAGetText().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0014


        [TestMethod]
        public void FPUC0014_REG0014()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP9458_FP9448_FP11863_FP9445_FP9440: 1.Return to Calling Page 2.Next Active Task List 3.Ability to navigate to the desired page number 4.Completing a Task 5.Protect Workgroup On Completed And Waived Tasks";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MyFastToday screen and set filter criteria.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click On Next, Enter Page No and click on Go to page";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.Next.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.MyFASTToday.PagePane.FAGetText().Clean().Contains(@"2 of").ToString(), "Verify whether the page number pane contains '2 of'.");
                FastDriver.MyFASTToday.PageNumber.FASetText(@"2");
                FastDriver.MyFASTToday.GoToPage.FAClick();

                Reports.TestStep = "Validate the Page Number";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.MyFASTToday.PagePane.FAGetText().Clean().Contains("2 of").ToString(), "Verify whether the page number pane contains '2 of'.");

                Reports.TestStep = "Complete a task and validate the non presence of the task";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("WorkGroup", "Unassigned", "C", TableAction.On);
                FastDriver.MyFASTToday.CompleteTask.FASetCheckbox(true);
                Support.AreEqual(@"True", FastDriver.MyFASTToday.CompleteTask.Selected.ToString(), "Check whether the CompleteTask is checked.");
                Support.AreEqual(@"False", FastDriver.MyFASTToday.WaiveTask.Selected.ToString(), "Check whether the WaiveTask is unchecked.");
                var FileNum = FastDriver.MyFASTToday.Filenumber.FAGetText().Clean();
                Keyboard.SendKeys("%F");
                Support.AreNotEqual(FileNum, FastDriver.MyFASTToday.Filenumber.FAGetText().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0015

        [TestMethod]
        public void FPUC0014_REG0015()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP9449: 1.Search For Tasks with Unassigned Workgroup";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MyFastToday and set filter criteria.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Find Now and save the Table";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                var ActiveTask = FastDriver.MyFASTToday._ActiveTasksTable.FAGetText();

                Reports.TestStep = "Click on Add Remove WorkGroup";
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Find Now and Validate table";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                Support.AreEqual(@"Unassigned", FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(9, "QA07, FAST", 7, TableAction.GetText).Message.Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0016

        [TestMethod]
        public void FPUC0014_REG0016()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP9453: 1.Search For Tasks with All Employees and a Specific Workgroup";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Start a Task with Priority and save task and office name and Click Apply";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.PriorityProcess.Displayed)
                    FastDriver.FileWorkflow.PriorityProcess.FASetCheckbox(true);
                var processTableID = FastDriver.FileWorkflow.CheckPriorityWaive_Process(@"AUTO_DONOTTOUCH_Template Setup Maintenan");
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(4, "3", 1, TableAction.On);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                //FastDriver.FileWorkflow.ProcessTask1.FAClick();
                var TaskName1 = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(1, 5, TableAction.GetText).Message.Clean();
                var TaskOffice1 = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(2, 6, TableAction.GetText).Message.Clean();
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Start a Task with Priority and save task and office name and Click Apply";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                TaskName1 = FastDriver.WebDriver.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(4, "3", 5, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Assign a WorkGroup to a Task";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(4, "3", 9, TableAction.Click);
                FastDriver.FileWorkflow.SelWorkgrp.FASendKeys(@"++");

                Reports.TestStep = "Select a workgroup from Active Tasks table.";
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem(@"Escrow");
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Assign a Employee to a Task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(4, "3", 11, TableAction.Click);
                FastDriver.FileWorkflow.SelAssgTo.FASendKeys(@"++");

                Reports.TestStep = "Select an employee";
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                FastDriver.EmployeeSelectionbyOfficeDlg.SelectOffice.FASelectItem(AutoConfig.SelectedOfficeName);
                FastDriver.EmployeeSelectionbyOfficeDlg.QA08.FAClick();
                FastDriver.EmployeeSelectionbyOfficeDlg.Select.FAClick();

                Reports.TestStep = "Click On Apply Button";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                
                Reports.TestStep = "Navigate to MFT and fill Filters";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"All Employees");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select a WorkGroup";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Accounting", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                
                Reports.TestStep = "Add Task Category and Task Office";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();

                Reports.TestStep = "Select a Task Office";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Select employee and task category.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate task";
                var value = FastDriver.MyFASTToday.Task1.FAGetText().Clean();
                Support.AreEqualTrim(value, FastDriver.MyFASTToday.Task1.FAGetText().Clean());

                Reports.TestStep = "Waive a Task";
                FastDriver.MyFASTToday.WaiveTask.FASetCheckbox(true);
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion//need to test
        #region FPUC0014_REG0017

        [TestMethod]
        public void FPUC0014_REG0017()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP10092: 1.Navigate to New File Entry for a pending file task";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to NFE and Click on Skip Search.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                                
                Reports.TestStep = "Create a NFE in Pending Status";
                FastDriver.NewFileEntry.FileStatus.FASelectItem(@"Pending");
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsPropertyType.FASelectItem(@"Single Family Residence");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText(@"1 FAW");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem(@"Orange");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Get the Created file no.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad(FastDriver.NewFileEntry.DetailsNewFileEntryMasterFile);
                var FileNum1 = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue().Clean();

                Reports.TestStep = "Start a Task with Priority and save task and office name and Click Apply";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                var processTableID = FastDriver.FileWorkflow.CheckPriorityWaive_Process(@"AUTO_DONOT_TOUCH_StandardTemplateForSanity");
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(4, "2", 1, TableAction.On);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ProcessTask1.FAClick();
                var TaskName1 = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(1, 5, TableAction.GetText).Message.Clean();
                var TaskOffice1 = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, processTableID).PerformTableAction(2, 6, TableAction.GetText).Message.Clean();
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0018

        [TestMethod]
        public void FPUC0014_REG0018()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP7067: 1.File Access Security";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to QA Sandpointe Office";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(@"191");

                Reports.TestStep = "Navigate to MFT and fill Filters";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(0);
                FastDriver.MyFASTToday.WaitForScreenToLoad(FastDriver.MyFASTToday.FilterEmployee);
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"User, EWB");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(@"California");
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.MyFASTToday.WaitForScreenToLoad(FastDriver.MyFASTToday._ActiveTasksTable);
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(2, 5, TableAction.DoubleClick);
                //if(FastDriver.MyFASTToday._ActiveTasksTable.GetRowCount() > 1)
                //{
                //    FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 5, TableAction.Click);
                //}
                //else
                //{
                //    FastDriver.MyFASTToday.FileOwningRegion.FASelectItemByIndex(0);
                //    FastDriver.MyFASTToday.FindNow.FAClick();
                //    FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 5, TableAction.Click);
                //}
                //FastDriver.MyFASTToday.TasksSelect.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Reports.StatusUpdate("Validate String", System.Text.RegularExpressions.Regex.IsMatch(FastDriver.WebDriver.HandleDialogMessage().Clean(), @"File Access is not allowed for File Number: [0-9]*.*"));

                //Reports.TestStep = "Navigate to Region level QA Automation";
                //FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedOfficeBUID);
                                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0020

        [TestMethod]
        public void FPUC0014_REG0020()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "EWC_2_1: User selects Find Now when Unassigned or All Employees is selected for Employee and Unassigned is selected for Workgroup";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MFT and select a Employee and click add remove workgroup";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"Unassigned");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Find Now";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqualTrim(@"Unassigned or All for Employee requires specific Workgroup and Task Office", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0021

        [TestMethod]
        public void FPUC0014_REG0021()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "EWC_1: User selects Find Now when Unassigned or All Workgroups is selected for Workgroup and Unassigned is selected for Employee";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MFT and select a Employee and click add remove workgroup";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"Unassigned");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Select All Employees in Employee Filter";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"All Employees");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqualTrim(@"Unassigned or All for Employee requires specific Workgroup and Task Office", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0022

        [TestMethod]
        public void FPUC0014_REG0022()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "EWC_4: In the Summary Alerts section Select is pressed but no Alert is highlighted";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MFT and select a Employee and click add remove workgroup";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"Unassigned");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Select All Employees in Employee Filter";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"All Employees");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqualTrim(@"Unassigned or All for Employee requires specific Workgroup and Task Office", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click Select on Summary Alerts";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AlertsSelect.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqualTrim(@"Please Select a Row from the Summary Alerts", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0023

        [TestMethod]
        public void FPUC0014_REG0023()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "EWC_5_I: In the Active Tasks section Select or Event Log is pressed but no Task is highlighted";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                
                Reports.TestStep = "Navigate to MFT and select a Employee and click add remove workgroup";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"Unassigned");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Select All Employees in Employee Filter";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"All Employees");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqualTrim(@"Unassigned or All for Employee requires specific Workgroup and Task Office", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click Select on Active Tasks";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.TasksSelect.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqualTrim(@"Please Select a Row from the Task List", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0024

        [TestMethod]
        public void FPUC0014_REG0024()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "EWC_5_II: In the Active Tasks section Select or Event Log is pressed but no Task is highlighted";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MFT and select a Employee and click add remove workgroup";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"Unassigned");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select Unassigned workgroup.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Select All Employees in Employee Filter";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"All Employees");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqualTrim(@"Unassigned or All for Employee requires specific Workgroup and Task Office", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click Event Log on Active Tasks";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.EventLogTasks.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqualTrim(@"Please Select a Row from the Task List", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0025

        [TestMethod]
        public void FPUC0014_REG0025()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "EWC_6: Select is pressed in Employee Selection by Office dialog box without selecting an employee";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select a task and click on Assign to";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 10, TableAction.Click);
                FastDriver.MyFASTToday.AssignedTo.FASendKeys(@"++");

                Reports.TestStep = "Click on Select";
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("%s");

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqualTrim(@"Error: No Employee was selected.", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Click on Cancel";
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("%c");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0026

        [TestMethod]
        public void FPUC0014_REG0026()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "EWC_7: User selects Find Now when Task Region is selected and the Task Name field is blank";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select a task and click on Assign to";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(7, "Unassigned", 10, TableAction.Click);
                FastDriver.MyFASTToday.AssignedTo.FASendKeys(@"++");
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("%c");

                Reports.TestStep = "Select a Task Region";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.TaskRegion.FAClick();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqual(@"A Task Name is required when a Task Region is selected.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0027

        [TestMethod]
        public void FPUC0014_REG0027()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "EWC_8: when user clicks on Go To Page button entering number/s out of range";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MFT and and click on Find Now";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.PageNumber.FASetText(@"1000");
                FastDriver.MyFASTToday.GoToPage.FAClick();

                Reports.TestStep = "Validate the Message and click on OK";
                Support.AreEqual(@"Please enter the valid Page Number.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0029

        [TestMethod]
        public void FPUC0014_REG0029()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FD_EQUAL: Name of the Filter";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to MFT.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();

                Reports.TestStep = "Click on Find Now.";
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Click on Save button.";
                FastDriver.MyFASTToday.Save.FAClick();

                Reports.TestStep = "Save a Filter";
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.FilterName.FASetText(@"ABCDEFGHIJ1234567890abcdefghijAbCdEfGhIj");
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();

                Reports.TestStep = "Verify Filter Name";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.DeleteAlerts.FASetCheckbox(true);
                FastDriver.MyFASTToday.Delete.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0030

        [TestMethod]
        public void FPUC0014_REG0030()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FD_Greater: Name of the Filter";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Find Now";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Click on Save button.";
                FastDriver.MyFASTToday.Save.FAClick();

                Reports.TestStep = "Save a Filter";
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.FilterName.FASetText(@"ABCDEFGHIJ1234567890abcdefghijAbCdEfGhIj");
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();

                Reports.TestStep = "Verify Filter Name";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.DeleteAlerts.FASetCheckbox(true);
                FastDriver.MyFASTToday.Delete.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0032

        [TestMethod]
        public void FPUC0014_REG0032()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "TFS_Enh_104928_DW002_post: Undo the checkbox";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Regional Process Summary and select a template";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>("Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction("Process Name", "AUTO_DONOT_TOUCH_StandardTemplateForSanity", "Process Name", TableAction.Click);

                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();

                Reports.TestStep = "Validate the presence of Eligible Priority process checkbox";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(false);

                if (FastDriver.RegionalProcessEdit.PriorityProcess.Selected)
                {
                    FastDriver.RegionalProcessEdit.PriorityProcess.FAClick();
                }
                else
                {
                    /*Forces the checkbox to be checked and then unchecked so the app will always 
                     *detect a change and will  always show something on pending refresh summary*/
                    FastDriver.RegionalProcessEdit.PriorityProcess.FAClick();
                    FastDriver.BottomFrame.SwitchToBottomFrame();
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.PriorityProcess.FAClick();
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select a task and click on Refresh button.";
                RefreshTemplate(@"AUTO_DONOT_TOUCH_StandardTemplateForSanity");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0033

        [TestMethod]
        public void FPUC0014_REG0033()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "TFS_Enh_104928_SMUC0048_post: Undo the rights";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Select QA Load Test Regional Role.";
                FastDriver.LeftNavigation.Navigate<RoleMaintenanceSummary>(@"Home>System Maintenance>Security Maintenance>Role Maintenance").WaitForScreenToLoad();
                if (AutoConfig.UseCDFormType)
                    FastDriver.RoleMaintenanceSummary.QALoadTestRegionalRole.FAClick();
                else
                    FastDriver.RoleMaintenanceSummary.QALoadTestRegionalRoleHUD.FAClick();
                Playback.Wait(500);
                Keyboard.SendKeys("%E");
                
                Reports.TestStep = "Uncheck the activity right.";
                FastDriver.RoleSetup.WaitForScreenToLoad();
                if (!FastDriver.RoleSetup.Region.Selected)
                    FastDriver.RoleSetup.Region.FAClick();
                if (AutoConfig.UseCDFormType)
                    FastDriver.RoleSetup.ActivityGroup.FASelectItemByIndex(4);
                else if (!AutoConfig.UseCDFormType)
                    FastDriver.RoleSetup.ActivityGroup.FASelectItemByIndex(7);
                if(FastDriver.RoleSetup.SelectedRightsTable.Text.Contains("Workflow Priority Flag Activity"))
                {
                    FastDriver.RoleSetup.SelectedRightsTable.PerformTableAction(2, "Workflow Priority Flag Activity", 1, TableAction.On);
                }
                else if(!FastDriver.RoleSetup.SelectedRightsTable.Text.Contains("Workflow Priority Flag Activity"))
                {
                    FastDriver.RoleSetup.AvailableRightsTable.PerformTableAction(2, "Workflow Priority Flag Activity", 1, TableAction.On);
                    FastDriver.RoleSetup.Add.FAClick();
                    FastDriver.RoleSetup.SelectedRightsTable.PerformTableAction(2, "Workflow Priority Flag Activity", 1, TableAction.On);
                }
                FastDriver.RoleSetup.Remove.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Track changes while Create Group Setup.";
                if (FastDriver.TrackChangeHistoryDialog.IsTrackChangeHistoryDlgVisible())
                {
                    FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                    FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText(@"123");
                    FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();
                }
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0034

        [TestMethod]
        public void FPUC0014_REG0034()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FD_EWC2_EWC8_EWC9_EWC10_FP7020_FP7022_FP7029_FP14256_FP14255_FP7120_FP14258_FP14257_FP14253_FP14254";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to MFT.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();

                Reports.TestStep = "Select employee as Unassigned and click on Find Now button.";
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"Unassigned");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate error message for Unassigned workgroup and unassigned employee.";
                Support.AreEqual(@"Unassigned or All for Employee requires specific Workgroup and Task Office", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Select a Task Region";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(0);
                FastDriver.MyFASTToday.WaitForScreenToLoad(FastDriver.MyFASTToday.FilterEmployee);
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "Validate Task Name error message when Task Region is selected.";
                Support.AreEqual(@"A Task Name is required when a Task Region is selected.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Select employee as 'QA07, FAST' and click on Workgroup.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Select first five check box.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(3, 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(5, 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(6, 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(7, 1, TableAction.On);
                                
                Reports.TestStep = "Validate error message for filter criteria.";
                Support.AreEqual(@"The maximum limit of 5 selections for this filter has reached.", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Click on Select button.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Click on Add remove task office.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();

                Reports.TestStep = "Multiselect the filter.";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(3, 1, TableAction.On);
                                
                Reports.TestStep = "Validate the message for multiple selection.";
                Support.AreEqual(@"Multi select option is available (allowed) only on one filter within a single search.", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());
                
                Reports.TestStep = "Click on Select button.";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();

                Reports.TestStep = "Select employee as 'QA07, FAST' and click on Workgroup.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();

                Reports.TestStep = "Unselect the five checked check box.";
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, 1, TableAction.Off);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(3, 1, TableAction.Off);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(4, 1, TableAction.Off);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(5, 1, TableAction.Off);
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(6, 1, TableAction.Off);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                
                Reports.TestStep = "Click on Add remove task name.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();

                Reports.TestStep = "Multiselect the filter.";
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(3, 1, TableAction.On);
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(5, 1, TableAction.On);
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(6, 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Click on Add remove task office.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();

                Reports.TestStep = "Unselect the five checked check box.";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, 1, TableAction.Off);
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(3, 1, TableAction.Off);
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(4, 1, TableAction.Off);
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(5, 1, TableAction.Off);
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(6, 1, TableAction.Off);
                
                Reports.TestStep = "Click on Select button.";
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();

                Reports.TestStep = "Enter a GAB Code and click on Find";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AddSearchFexpand.FAClick();
                FastDriver.MyFASTToday.GABCode.FASetText(@"HUDFLINSR1");
                FastDriver.MyFASTToday.Find.FAClick();

                Reports.TestStep = "Enter a GAB Name and click on Find";
                FastDriver.MyFASTToday.GABName.FASetText(@"Thomas Freeman");
                Keyboard.SendKeys("%n");

                Reports.TestStep = "Select The File owning office and click on Additional filter.";
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.EditAdditionalFilters.FAClick();

                Reports.TestStep = "Validate that when service type is blank then both EOO and TOO button is enabled.";
                FastDriver.FilterSelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.FilterSelectionCriteriaDlg.Service.FASelectItem(@"");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveProdtype.Enabled.ToString(), "Verify whether the 'AddRemoveProdtype' button is Enabled.");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveEscrowowning.Enabled.ToString(), "Verify whether the 'AddRemoveEscrowowning' button is Enabled.");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveTitleowning.Enabled.ToString(), "Verify whether the 'AddRemoveTitleowning' button is Enabled.");
                                
                Reports.TestStep = "Validate that when service type is title then Ego is disabled.";
                FastDriver.FilterSelectionCriteriaDlg.Service.FASelectItem(@"Title");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveProdtype.Enabled.ToString(), "Verify whether the 'AddRemoveProdtype' button is Enabled.");
                Support.AreEqual(@"False", FastDriver.FilterSelectionCriteriaDlg.AddRemoveEscrowowning.Enabled.ToString(), "Verify whether the 'AddRemoveEscrowowning' button is Disabled.");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveTitleowning.Enabled.ToString(), "Verify whether the 'AddRemoveTitleowning' button is Enabled.");

                Reports.TestStep = "Validate that when service type is Escrow then TOO is disabled.";
                FastDriver.FilterSelectionCriteriaDlg.Service.FASelectItem(@"Escrow");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveProdtype.Enabled.ToString(), "Verify whether the 'AddRemoveProdtype' button is Enabled.");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveEscrowowning.Enabled.ToString(), "Verify whether the 'AddRemoveEscrowowning' button is Enabled.");
                Support.AreEqual(@"False", FastDriver.FilterSelectionCriteriaDlg.AddRemoveTitleowning.Enabled.ToString(), "Verify whether the 'AddRemoveTitleowning' button is Disabled.");
                
                Reports.TestStep = "Validate that when service type is Title/Sub Escrow then EOO is disabled.";
                FastDriver.FilterSelectionCriteriaDlg.Service.FASelectItem(@"Title/SubEscrow");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveProdtype.Enabled.ToString(), "Verify whether the 'AddRemoveProdtype' button is Enabled.");
                Support.AreEqual(@"False", FastDriver.FilterSelectionCriteriaDlg.AddRemoveEscrowowning.Enabled.ToString(), "Verify whether the 'AddRemoveEscrowowning' button is Disabled.");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveTitleowning.Enabled.ToString(), "Verify whether the 'AddRemoveTitleowning' button is Enabled.");

                Reports.TestStep = "Validate that when service type is Escrow/Sub Escrow then TOO is disabled.";
                FastDriver.FilterSelectionCriteriaDlg.Service.FASelectItem(@"Escrow/SubEscrow");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveProdtype.Enabled.ToString(), "Verify whether the 'AddRemoveProdtype' button is Enabled.");
                Support.AreEqual(@"True", FastDriver.FilterSelectionCriteriaDlg.AddRemoveEscrowowning.Enabled.ToString(), "Verify whether the 'AddRemoveEscrowowning' button is Enabled.");
                Support.AreEqual(@"False", FastDriver.FilterSelectionCriteriaDlg.AddRemoveTitleowning.Enabled.ToString(), "Verify whether the 'AddRemoveTitleowning' button is Disabled.");
                FastDriver.FilterSelectionCriteriaDlg.Done.FAClick();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0035


        [TestMethod]
        public void FPUC0014_REG0035()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP9456_FP9459_PlaceHolder: 1.Event Log 2.My FAST Today Task Event Log";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Set Filters to Perform the search.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.FindNow.FAClick();

                Reports.TestStep = "On the Active Task section, User selects a task and selects Event Log.";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("WorkGroup", "Unassigned", "WorkGroup", TableAction.Click);
                FastDriver.MyFASTToday.EventLogTasks.FAClick();

                Reports.TestStep = "User is navigated to a filtered event log page for the selected file. ";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();

                Reports.TestStep = "Event Log will be displayed for the selected file ";
                Support.AreEqual(@"True", FastDriver.EventTrackingLogDlg.EventTable.Displayed.ToString(), "Verify whether the Event Table is displayed.");

                Reports.TestStep = "User closes the Event Log dialog box to return to the FAST Today page.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Create LVIS Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.Source = "LVIS";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                
                Reports.TestStep = "Verify log entry in the Alert table.";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                    FastDriver.MyFASTToday.AlertType.FASelectItem(@"LVIS");
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.MyFASTToday.WaitForScreenToLoad();
                    if (FastDriver.MyFASTToday.SummaryAlertsTable.Text.Contains(File.FileNumber))
                    {
                        FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction("File Number", File.FileNumber, "File Number", TableAction.Click);
                        Reports.StatusUpdate(String.Format(@"File Number '{0}' is present in the Alert Table.", File.FileNumber), true);
                    }
                    return FastDriver.MyFASTToday.SummaryAlertsTable.Text.Contains(File.FileNumber);
                }, timeout: 120, idleInterval: 10);

                Reports.TestStep = "Verify log entry in the TaskEventLog table.";
                FastDriver.MyFASTToday.FindNow.FAClick();
                var selectedRow = FastDriver.MyFASTToday.MarkTaskAs(FastDriver.MyFASTToday._ActiveTasksTable, TaskStatus.Start);
                FastDriver.MyFASTToday.Apply.FAClick();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(selectedRow, 5, TableAction.Click);
                FastDriver.MyFASTToday.EventLogTasks.FAClick();
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Started]", 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FPUC0014_REG0036


        [TestMethod]
        public void FPUC0014_REG0036()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestDescription = "FP9446_PlaceHolder: 1.Delete Warnings & Alerts";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Set Filters to Perform the search.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"All Categories");
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();

                Reports.TestStep = "Perform the Search and Mark Task as Completed.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                var selectedRow = FastDriver.MyFASTToday.MarkTaskAs(FastDriver.MyFASTToday._ActiveTasksTable, TaskStatus.Complete);
                var FileNum = FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(selectedRow, 4, TableAction.GetText).Message.Clean();
                var taskName = FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(selectedRow, 5, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Verify whether the task has been removed from the ActiveTaskTable.";
                FastDriver.MyFASTToday.Apply.FAClick();
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    return !FastDriver.MyFASTToday._ActiveTasksTable.Text.Contains(FileNum);
                }, timeout: 60, idleInterval: 5);
                Reports.StatusUpdate(String.Format("Task '{0}' related to FileNumber '{1}' has been removed.", taskName, FileNum), !FastDriver.MyFASTToday._ActiveTasksTable.Text.Contains(FileNum));

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
       
        #endregion

        #region HelpMethods
                
        private void CreateRole(string roleName = "QA Load Test Regional Role - FPUC0014 - CD")
        {
            FastDriver.LeftNavigation.Navigate<RoleMaintenanceSummary>(@"Home>System Maintenance>Security Maintenance>Role Maintenance").WaitForScreenToLoad();
            bool exists = AutoConfig.UseCDFormType ? !FastDriver.RoleMaintenanceSummary.QALoadTestRegionalRole.Exists() : !FastDriver.RoleMaintenanceSummary.QALoadTestRegionalRoleHUD.Exists();
            if (exists)
            {
                Reports.TestStep = "Click on New.";
                FastDriver.RoleMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Set Role Name as 'QA Load Test Regional Role'.";
                FastDriver.RoleSetup.WaitForScreenToLoad();
                FastDriver.RoleSetup.RoleName.FASetText(roleName);

                Reports.TestStep = "Select 'Office' option of Role Security Level.";
                if (AutoConfig.UseCDFormType)
                    FastDriver.RoleSetup.Office.FAClick();
                else
                    FastDriver.RoleSetup.Region.FAClick();

                Reports.TestStep = "Select an Activity Group/Right and click on Add.";
                if (AutoConfig.UseCDFormType)
                    FastDriver.RoleSetup.ActivityGroup.FASelectItemByIndex(4);
                else if (!AutoConfig.UseCDFormType)
                    FastDriver.RoleSetup.ActivityGroup.FASelectItemByIndex(7);
                FastDriver.RoleSetup.AvailableRightsTable.PerformTableAction(2, "Workflow Priority Flag Activity", 1, TableAction.On);
                FastDriver.RoleSetup.Add.FAClick();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Track changes while Create Group Setup.";
                FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText(Support.RandomNumber(999).ToString());
                FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();

                Reports.TestStep = "Verify whether the Role has been added.";
                FastDriver.LeftNavigation.Navigate<RoleMaintenanceSummary>(@"Home>System Maintenance>Security Maintenance>Role Maintenance").WaitForScreenToLoad();
                FastDriver.RoleMaintenanceSummary.QALoadTestRegionalRole.FAClick();
            }
            else
                Reports.StatusUpdate("Role does exist.", true);
        }

        private void CreateFilter(string filterName)
        {
            if (!FastDriver.MyFASTToday.VerifyFilterAvailability(@"New criteria"))
            {
                Reports.TestStep = "Navigate to MyFastToday screen and set the Filter criteria.";
                FastDriver.MyFASTToday.Open();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem(@"Title");
                FastDriver.MyFASTToday.AddRemoveTaskOffice.FAClick();
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.SelectTaskOfficesTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, "ADEC-ITI-BILL-FULL", 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.TaskStatus.FASelectItem(@"Show all");
                FastDriver.MyFASTToday.FindNow.FAClick();
                                                
                Reports.TestStep = "Save filter as " + filterName;
                FastDriver.MyFASTToday.Save.FAClick();
                FastDriver.SaveMyFastTodayFilterDlg.WaitForScreenToLoad();
                FastDriver.SaveMyFastTodayFilterDlg.PrimaryFilter.FASetCheckbox(false);
                FastDriver.SaveMyFastTodayFilterDlg.FilterName.FASetText(filterName);
                FastDriver.SaveMyFastTodayFilterDlg.Save.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
            }
            else
                Reports.StatusUpdate(@"Filter does exist.", true);
        }

        private bool RefreshTemplate(string templateName)
        {

            bool ret = false;
            try
            {
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<PendingRefreshSummary>("Home>System Maintenance>Process Setup>Pending Refresh Summary").WaitForScreenToLoad();
                    return FastDriver.PendingRefreshSummary.SummaryTable.Text.Contains(templateName);
                }, timeout: 45, idleInterval: 5);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<PendingRefreshSummary>("Home>System Maintenance>Process Setup>Pending Refresh Summary").WaitForScreenToLoad();
                    return !FastDriver.PendingRefreshSummary.SummaryTable.Text.Contains(templateName);
                }, timeout: 300, idleInterval: 20);
                ret = true;
            }
            catch (Exception)
            {
                ret = false;
            }

            return ret;
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}