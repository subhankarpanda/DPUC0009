﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using System.Threading;
using System.Collections.Generic;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers;


namespace FileManagement
{
    [CodedUITest]
    public class FPUC0013 : FASTHelpers
    {
        #region Dependency
        // Bug ID 812741 : Change time zone to PST and execute this Usecase or Execute it from 12:30 PM IST  to 11:30 PM IST if time zone of machine is IST. 
        #endregion
        #region BAT
        #region Test FPUC0013_BAT0001
        [TestMethod]
        public void FPUC0013_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_001: View FAST Today Summary Alerts.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //           
                Reports.TestStep = "To view Summary Alerts Alert Type & Employee filter.";
                FastDriver.MyFASTToday.Open();
                Support.AreEqualTrim("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                Support.AreEqualTrim(@"QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem());
                // 
                Reports.TestStep = "Summary Alerts section shall display all alerts that meet the filtered criteria.";
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"FastWeb");
                Support.AreEqualTrim(@"FastWeb", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"File");
                Support.AreEqualTrim(@"File", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"Overdue");
                Support.AreEqualTrim(@"Overdue", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"Service Added");
                Support.AreEqualTrim(@"Service Added", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"Wintrack");
                Support.AreEqualTrim(@"Wintrack", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"Owning Office Changed");
                Support.AreEqualTrim(@"Owning Office Changed", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"Service Removed");
                Support.AreEqualTrim(@"Service Removed", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"ATP");
                Support.AreEqualTrim(@"ATP", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"LA.COM");
                Support.AreEqualTrim(@"LA.COM", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"WSP");
                Support.AreEqualTrim(@"WSP", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"Hold Funds");
                Support.AreEqualTrim(@"Hold Funds", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"Electronic Wire");
                Support.AreEqualTrim(@"Electronic Wire", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
 //
                Reports.TestStep = "Set user as QA06";
                FastDriver.MyFASTToday.AlertUser.FASelectItem(@"QA06, FAST");
                Reports.TestStep = "Summary Alerts section shall display all alerts that meet the filtered criteria.";
                FastDriver.MyFASTToday.WaitCreation(FastDriver.MyFASTToday.AlertUser);
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"Fannie Mae");
                Support.AreEqualTrim(@"Fannie Mae", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"FW-AgentFirst");
                Support.AreEqualTrim(@"FW-AgentFirst", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem());
                //
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(10, "File", "QA07, FAST");
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(10, "All", "QA06, FAST");
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(100, "All", "Current Office");
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(200, "All", "Unassigned");
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(50, "Service Added", "Unassigned");
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(50, "Service Removed", "Unassigned");
                DeleteOverdueAlertsCreatedBefore1Hr(200);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion Test
        #region Test FPUC0013_BAT0002
        [TestMethod]
        public void FPUC0013_BAT0002()
        {

            try
            {
                Reports.TestDescription = "AF4: Set Service Added Alert.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service removed";
                string FileNumber = CreateFile(0,false, true, false);
                // 
                Reports.TestStep = "Click on Title.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.Title.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate Alert in MFT";
                string AlertType = @"Service Added";
                string AlertMessage = "Title Service Added";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());              
                //
                Reports.TestStep = "Verifying Alert in FileWork Flow";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage, "Message", TableAction.Click).Status.ToString());     
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test    
        #region Test FPUC0013_BAT0003
        [TestMethod]
        public void FPUC0013_BAT0003()
        {

            try
            {
                Reports.TestDescription = "AF8: Set Service Removed Alert.";
                ProjectFileChk(true,"1234");
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
               string FileNumber= CreateFile();
                // 
                Reports.TestStep = "Remove Title service.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(10000);
                //
                Reports.TestStep = "Validate Alert in MFT";
                string AlertType=@"Service Removed";
                string AlertMessage="Title Service Removed";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());               
                // 
                Reports.TestStep = "Verifying service Removed alerts in file workflow";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage, "Message", TableAction.Click).Status.ToString());  
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0004
        [TestMethod]
        public void FPUC0013_BAT0004()
        {

            try
            {
                Reports.TestDescription = "AF9_FP5318_1: Set Owning Office Changed Alert.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
               string FileNumber= CreateFile();
                //              
                Reports.TestStep = "Chang Escrow Own Office.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                Thread.Sleep(3000);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(6000);
                // 
                Reports.TestStep = "Click on Yes button."; 
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }
                // 
                // 
                Reports.TestStep = "Validate Alert in MFT";
                string AlertType = @"Owning Office Changed";
                string AlertMessage = "Escrow Owning Office Changed";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());
                FastDriver.MyFASTToday.AlertsSelect.FAClick();
                Thread.Sleep(6000);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                // 
                // 
                Reports.TestStep = "Verifying Escrow Owning Office Changed alerts on File workflow";
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage, "Message", TableAction.Click).Status.ToString());                 
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0005

        [TestMethod]
        public void FPUC0013_BAT0005()
        {

            try
            {
                Reports.TestDescription = "AF10: Set 1099-S Alert and Add Settlement Date.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                // 
                Reports.TestStep = "Navigate to Seller screen and click on Edit";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(4, "Individual", 4, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                Thread.Sleep(2000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItem(@"1099-S");
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);

                // 
                // 
                //Reports.TestStep = "Select Husband/Wife Seller and click on Edit";
                //FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                //FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(4, @"Husband/Wife", 4, TableAction.Click);
                //FastDriver.BuyerSellerSummary.Edit();
                //Thread.Sleep(2000);
                //FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                //FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItem(@"1099-S");
                //FastDriver.BottomFrame.Done();
                //Thread.Sleep(2000);
                // 
                Reports.TestStep = "Navigate to TDS screen and Enter the current date as settlement date.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.UpdateStatusDateWithServerDate();
                string SettlementDate = DateTime.Now.ToDateString();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(SettlementDate);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(2000);

                // 
                // 
                Reports.TestStep = "Select the required criteria for 1099S type alerts.";
                string AlertType = @"1099-S";
                string AlertMessage = @"Settlement Date is Added. Please create and print seller's 1099-S.";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());
                FastDriver.MyFASTToday.AlertsSelect.FAClick();
                Thread.Sleep(6000);
                // 
                Reports.TestStep = "Verifying 1099-S alerts";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
               Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage, "Message", TableAction.Click).Status.ToString());    
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0006

        [TestMethod]
        public void FPUC0013_BAT0006()
        {

            try
            {
                Reports.TestDescription = "AF11: Set 1099-S Alert Change 1099-S Data.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Sales price and Title Service and escrow service";
                string FileNumber = CreateFile(250000);
                // 
                Reports.TestStep = @"Navigate to Individual Seller screen and Set 1099-S classification value";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(4, "Individual", 4, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                Thread.Sleep(2000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItem(@"1099-S");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText(@"1234-56-789");
                FastDriver.BottomFrame.Done();
                Thread.Sleep(7000);
                //         
                Reports.TestStep = "Navigate to HusbandWife Seller screen and Set 1099-S classification value";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(4, @"Husband/Wife", 4, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                Thread.Sleep(2000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.HusbandSpouse1099sClassification1.FASelectItem(@"1099-S");
                FastDriver.BuyerSellerSetup.HusbandSpous1SSN.FASetText(@"1234-56-789");
                FastDriver.BottomFrame.Done();
                Thread.Sleep(7000);
                //Reports.TestStep = "Navigate to TDS screen and Enter the current date as settlement date.";
                //FastDriver.TermsDatesStatus.Open();
                //FastDriver.TermsDatesStatus.UpdateStatusDateWithServerDate();
                //string SettlementDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString(); ;
                //FastDriver.TermsDatesStatus.SettlementDate.FASetText(SettlementDate);
                //FastDriver.BottomFrame.Done();
                //Thread.Sleep(2000);
                // 
                Reports.TestStep = "Distributing amounts for sale price";
                FastDriver._1099S.Open();
                FastDriver._1099S.Set1099sRecordDetails("Seller1FirstName Seller1LastName", FastDriver._1099S);
                FastDriver._1099S.SetGrossProceedsDollorAmount("Seller1FirstName Seller1LastName",@"125,000.00");
                //FastDriver.WebDriver.HandleDialogMessage();
                // 
                Reports.TestStep = "Distributing amounts for sale price for second seller";
                FastDriver._1099S.Set1099sRecordDetails("Seller2FirstName Seller2LastName", FastDriver._1099S);
                FastDriver._1099S.SetGrossProceedsDollorAmount("Seller2FirstName Seller2LastName", @"125,000.00");
                // 
                Reports.TestStep = "Click on Save button.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                Thread.Sleep(5000);
                // 
                Reports.TestStep = "Navigate to TDS screen and Enter the current date as settlement date.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.UpdateStatusDateWithServerDate();
                string SettlementDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(SettlementDate);
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Error message for 1099-S alert";
                string IEMEssage = "Please update the 1099-S record and print the 1099-S form for the seller.";
                Support.AreEqualTrim(IEMEssage, FastDriver.WebDriver.HandleDialogMessage());
                // 
                Reports.TestStep = "Select the required criteria for 1099S type alerts.";
                string AlertType = @"1099-S";
                string AlertMessage = "1099-S data has changed. Please update and reprint 1099-S.";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());
                // 
                Reports.TestStep = "Verifying 1099-S alerts";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("Success",FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage.Trim(), "Message", TableAction.Click).Status.ToString());
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0007
        [TestMethod]
        public void FPUC0013_BAT0007()
        {

            try
            {
                Reports.TestDescription = "AF15: Delete Active Alerts (not on FAST Today).";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts";
                string AlertMessage = "To delete an alert or reminder";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage);
                // 
                Reports.TestStep = @"To delete Alerts/ reminder";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.DeleteAlertOrReminder(AlertMessage);
                // 
                Reports.TestStep = "Verify the Active alerts and reminder is deleted from message table";
                FastDriver.FileWorkflow.Open();
                Support.AreEqualTrim("False", FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains(AlertMessage).ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0008
        /// <summary>
        /// FP4616_1  Delete Active File Reminders, Alerts
        /// FP4585  Manual Delete from Summary Alert  
        /// </summary>

        [TestMethod]
        public void FPUC0013_BAT0008()
        {

            try
            {
                Reports.TestDescription = "AF14_FP4585_FP4616_1: Delete Summary Alerts.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts";
                string AlertMessage = "To delete an alert and reminder";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage,true);
                // 
                Reports.TestStep = "Verify active alert.";
                Support.AreEqual("True",FastDriver.MyFASTToday.ValidateAlertOnMFT("File", AlertMessage, FileNumber, "QA07, FAST").ToString());
                Reports.TestStep = "Delete active alert.";
                Support.AreEqual("True",FastDriver.MyFASTToday.DeleteAlertOnMFT("All", AlertMessage, FileNumber, "QA07, FAST").ToString()); 
                // 
                Reports.TestStep = "Verify the active alerts and reminder is deleted from message table";
                FastDriver.FileWorkflow.Open();
                Support.AreEqualTrim("1", FastDriver.FileWorkflow.MessagesTable.GetRowCount().ToString());
                // 
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0009
        /// <summary>
        /// FP4618  Delete Pending File Reminders and Alerts  
        /// </summary>
        [TestMethod]
        public void FPUC0013_BAT0009()
        {

            try
            {
                Reports.TestDescription = "AF12_FP4618: Delete Pending File Reminders and Alerts.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts";
                string AlertMessage = "To delete an alert and reminder";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage, false,ClickApply:false);
                //
                Reports.TestStep = "Click on RemoveReminder button";
                FastDriver.FileWorkflow.RemoveRemainder.FAClick();
                Thread.Sleep(2000);                
                // 
                Reports.TestStep = "In Pending Reminders and Alerts, user selects a Reminder or Alert and clicks the Delete button";
                string IEMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Delete selected File Reminder or Alert?", IEMessage);
                // 
                Reports.TestStep = "Verify the pending alerts and reminder is deleted";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqualTrim("1", FastDriver.FileWorkflow.PendingReminderTable.GetRowCount().ToString());
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0010_PH
        [TestMethod]
        public void FPUC0013_BAT0010_PH()
        {

                Reports.TestDescription = "AF18_001: Set Electronic Wire Alert from Manual Process.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_BAT0011

        [TestMethod]
        public void FPUC0013_BAT0011()
        {

            try
            {
                Reports.TestDescription = "AF18_002: Set Electronic Wire Alert from Manual Process.";
                Reports.StatusUpdate("This flow is covered in BAT0010", true);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0012

        [TestMethod]
        public void FPUC0013_BAT0012()
        {

            try
            {
                Reports.TestDescription = "AF18_003: Set Electronic Wire Alert from Manual Process.";
                Reports.StatusUpdate("This flow is covered in BAT0010", true);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0013

        [TestMethod]
        public void FPUC0013_BAT0013()
        {

            try
            {
                Reports.TestDescription = "AF18_004: Set Electronic Wire Alert from Manual Process.";
                Reports.StatusUpdate("This flow is covered in BAT0010", true);              
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0014A
        /// <summary>
        /// 4616_2 : Veify that the warning is deleted
        /// </summary>
        [TestMethod]
        public void FPUC0013_BAT0014A()
        {

            try
            {
                Reports.TestDescription = "AF3_001_4616_2: Set Workflow Template Task Alerts and Warnings. and Delete warnings";
                // 
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FPUC0013_Common_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Limited Escrow";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent = "File created with Open status";
                ProcParams.Tasks = new[] { "FPUC0013_Alerts_Task", "FPUC0013_Alerts_Task1" };
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams);
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Select the task";
                FastDriver.FileWorkflow.Open();
                Thread.Sleep(2000);
                if (!FastDriver.FileWorkflow.ActiveOnly.IsSelected())
                {
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }

                Thread.Sleep(2000);             
                Reports.TestStep = "Set and verify warning alert for task.";
               Support.AreEqualTrim("Success", SetWarningAlertForTask(ProcParams.ProcessName, ProcParams.Tasks[0]));
                // 
                Reports.TestStep = "Set and Verify overdue alerts";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqualTrim("Success", SetOverDueAlertForTask(ProcParams.ProcessName, ProcParams.Tasks[1]));
                // 
                Reports.TestStep = "Select Warning alert to delete";
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Warning for Task: " + ProcParams.Tasks[0], @"Del?", TableAction.On);
                // 
                Reports.TestStep = "Verify the warning is deleted";
                FastDriver.FileWorkflow.Open();
                Support.AreEqualTrim("1", FastDriver.FileWorkflow.PendingReminderTable.GetRowCount().ToString());
                // 
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0014B

        [TestMethod]
        public void FPUC0013_BAT0014B()
        {

                Reports.TestDescription = "Precondition: Validate for Task is enabled.";
                Reports.StatusUpdate("This flow is covered in BAT0014A", true);
                // 


        }
        #endregion Test
        #region Test FPUC0013_BAT0014C

        [TestMethod]
        public void FPUC0013_BAT0014C()
        {

                Reports.TestDescription = "Dependency Flow: Process for Manual Activation, if Task is not in Activate status";
                Reports.StatusUpdate("This flow is covered in BAT0014A", true);
           
        }
        #endregion Test
        #region Test FPUC0013_BAT0014D

        [TestMethod]
        public void FPUC0013_BAT0014D()
        {

                Reports.TestDescription = "Continuation from FPUC0013_BAT0014A";
                Reports.StatusUpdate("This flow is covered in BAT0014A", true);

        }
        #endregion Test
        #region Test FPUC0013_BAT0015
        /// <summary>
        /// 
        /// </summary>
        [TestMethod]
        public void FPUC0013_BAT0015()
        {

            try
            {
                Reports.TestDescription = "AF3_002: Set Workflow Template Task Alerts and Warnings.";
                // 
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FPUC0013_Common_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Limited Escrow";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent ="File created with Open status";
                ProcParams.Tasks = new[] { "FPUC0013_Alerts_Task"};
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams);
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow TransactionType: @"LTDESCROW"
                // 
                Reports.TestStep = "Go to file work flow and select task";
                FastDriver.FileWorkflow.Open();
                Thread.Sleep(2000);
                if (!FastDriver.FileWorkflow.ActiveOnly.IsSelected())
                {
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                }
                Thread.Sleep(2000);
                Reports.TestStep = "Validate for Task is activated.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Select a process to add task";
                if (!FastDriver.FileWorkflow.CollapseAll.IsSelected())
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                string MiscTaskName = "MiscTaskTest";
                FastDriver.FileWorkflow.AddMiscTaskToProcess(ProcParams.ProcessName, MiscTaskName);    
                // 
                Reports.TestStep = "Verify the Misc Task added.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.SelectTask(ProcParams.ProcessName, MiscTaskName).ToString());
                // 
                Reports.TestStep = "Set and verify warning Alert For Task.";
                Support.AreEqual("Success", SetWarningAlertForTask(ProcParams.ProcessName, "MiscTaskTest"));
                //
                Reports.TestStep = "Set and verify Over Due Alert For Task.";
                Support.AreEqual("Success",SetOverDueAlertForTask(ProcParams.ProcessName, "MiscTaskTest"));
                
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0016

        [TestMethod]
        public void FPUC0013_BAT0016()
        {

            try
            {
                Reports.TestDescription = "AF3: Set Workflow Template Task Alerts and Warnings.";
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                Reports.TestStep = "Create process and add task to it with due type and due time";
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FPUC0013_Common_Template";
                ProcParams.ProcessType = "Open Order Pending";
                ProcParams.TranType = "Limited Escrow";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent = "File created with Open status";
                ProcParams.Tasks = new[] { "FPUC0013_Alerts_Task", "FPUC0013_Alerts_Task1" };
                string DueMinute="1";
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams, DueTypeForFirstTask: @"After Task Started", DueMin: DueMinute);
                //                
                //
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow TransactionType: @"LTDESCROW"
                //               
                Reports.TestStep = "Start task.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.ClickStartTaskCheckboxForTask(ProcParams.ProcessName,ProcParams.Tasks[0]);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Thread.Sleep(4000);
                Reports.TestStep = "Wait for " + DueMinute + " in process template.";
                WaitForWarnDueMin(DueMinute);
                Reports.TestStep = "Validate Overdue alert in Fileworkflow";
                for (int i = 0; i < 5; i++)
                {
                    Thread.Sleep(3000);
                    FastDriver.FileWorkflow.Open();
                    if (FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains("Overdue Task"))
                    {
                        Support.AreEqualTrim("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Overdue Task: " + ProcParams.Tasks[0], "Message", TableAction.Click).Status.ToString());
                        break;
                    }
                    else
                    {
                        Thread.Sleep(5000);
                    }
                    if (i == 4)
                    {
                        Reports.StatusUpdate("Task Overdue alert is not triggered", false);
                    }
                }
                // 
                Reports.TestStep = "Validate Overdue alert in MFT";
                FastDriver.MyFASTToday.Open();
                string AlertType = "Overdue";
                string AlertMessage = "Overdue Task: " + ProcParams.Tasks[0];
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber,"QA07, FAST").ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion Test
        #region Test FPUC0013_BAT0017

        [TestMethod]
        public void FPUC0013_BAT0017()
        {

            try
            {
                Reports.TestDescription = "AF3_004: Set Workflow Template Task Alerts and Warnings.";
                Reports.StatusUpdate("This flow is covered in BAT0016", true);
               
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0018

        [Obsolete,TestMethod]
        public void FPUC0013_BAT0018()
        {
                Reports.TestDescription = "AF3_005: Set Workflow Template Task Alerts and Warnings.";
                Reports.TestStep = "This flow was scripted to remove automation related process template. Not required now.";

        }
        #endregion Test
        #region Test FPUC0013_BAT0019_PH

        [TestMethod]
        public void FPUC0013_BAT0019_PH()
        {
            Reports.TestDescription = "AF16: View FASTWeb Order Alert.";
            Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
            Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_BAT0020

        [TestMethod]
        public void FPUC0013_BAT0020()
        {
            Reports.TestDescription = "AF17_FP5489 : View Wintrack Order Alert.";
            try
            {
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                string Interface = "WINTRACK";
                Dictionary<string, int> FileData = CreateOrderForInterfaces(Interface);
                string FileNumber = FileData["FileNumber"].ToString();
                Reports.TestStep = "Verify Wintrack alert on MFT.";
                FastDriver.MyFASTToday.Open();
                string AlertType = "Wintrack";
                string AlertMessage = "New Wintrack order was created";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber,"Unassigned").ToString());
                Reports.TestStep = "Validate that wintrack alert is not assigned to current office or any other employee";
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber,"Current Office").ToString());
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "QA07, FAST").ToString());
                Reports.TestStep = "Verifying Alert in FileWork Flow";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage, "Message", TableAction.Click).Status.ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_BAT0021_PH

        [TestMethod]
        public void FPUC0013_BAT0021_PH()
        {

                Reports.TestDescription = "AF5_PlaceHolder: Set Hold Funds Alerts.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_BAT0022_PH
        [TestMethod]
        public void FPUC0013_BAT0022_PH()
        {
                Reports.TestDescription = "AF1_AF2_AF7_002_AF13_PlaceHolder: View Active & Pending File Reminders and Alerts/Set Manual File Task Warning or Overdue Alert (Verify the Hold Funds message in File Workflow screen).";
                // 
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_BAT0023_PH
        [TestMethod]
        public void FPUC0013_BAT0023_PH()
        {
                Reports.TestDescription = "AF19_AF20_AF21_AF22_AF23_AF24_AF25_PlaceHolder: View WSP Program Type Mismatch/View LA.com Order Alert.";
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_BAT0024_PH

        [TestMethod]
        public void FPUC0013_BAT0024_PH()
        {

                Reports.TestDescription = "MF_002_AF7_001_PlaceHolder: View FAST Today Summary Alerts (Verify the Hold Funds message in File Workflow and MFT screens after 1 day).";
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
                // 
        }
        #endregion Test
        #endregion
        #region REG
        #region Test FPUC0013_REG0001

        [TestMethod]
        public void FPUC0013_REG0001()
        {

            try
            {
                Reports.TestDescription = "EWC1_EWC2: User clicks on Select button without selecting any row in Summary Alert.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(); 
                // 
                Reports.TestStep = "Navigate to MFT.";
                FastDriver.MyFASTToday.Open();
                FastDriver.MyFASTToday.TasksSelect.FAClick();
                Thread.Sleep(2000);
                // 
                Reports.TestStep = "User clicks on Select button without selecting any row in Summary Alert";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Please Select a Row from the Task List", Message);
                // 
                Reports.TestStep = "Slect Event log button.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.EventLogAlerts.FAClick();
                Thread.Sleep(2000);
                // 
                Reports.TestStep = "User clicks on Select button without selecting any row in Summary Alert";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Please Select a Row from the Summary Alerts", Message);

                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0002

        [TestMethod]
        public void FPUC0013_REG0002()
        {

            try
            {
                Reports.TestDescription = "EWC3_EWC4_EWC5: In Pending Reminders and Alerts, user clicks on Delete button without selecting any Pending Reminder or Alert.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                // 
                Reports.TestStep = "Navigate to File workflow.";
                FastDriver.FileWorkflow.Open();
                Reports.TestStep = "Click on RemoveReminder button";
                FastDriver.FileWorkflow.RemoveRemainder.FAClick();
                Thread.Sleep(2000);
                // 
                Reports.TestStep = "In Pending Reminders and alerts, user clicks Delete button when there are no Pending Reminders or Alerts";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"No File Reminders are Available", Message);
                // 
                Reports.TestStep = "Select and Remove Reminder";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.New.FAClick();
                FastDriver.FileWorkflow.Visibility.FASelectItem(@"Alert");
                // 
                Reports.TestStep = "Click on RemoveReminder button";
                FastDriver.FileWorkflow.RemoveRemainder.FAClick();
                // 
                Reports.TestStep = "In Pending Reminders and Alerts, user selects a Reminder or Alert and clicks the Delete button";
                 Message = FastDriver.WebDriver.HandleDialogMessage();
                 Support.AreEqual(@"Delete selected File Reminder or Alert?", Message); 
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string AlertMessage=@"Enter a new reminder or alert";
                string NotifyDate = DateTime.Today.AddDays(Convert.ToInt32("1")).ToDateString();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage, true, NotifyDate);
                // 
                Reports.TestStep = "Navigate to FWF.";
                FastDriver.FileWorkflow.Open();
                // 
                Reports.TestStep = "Click on RemoveReminder button";
                FastDriver.FileWorkflow.RemoveRemainder.FAClick();
                Thread.Sleep(2000);
                // 
                Reports.TestStep = "In Pending Reminders and Alerts, user clicks on Delete button without selecting any Pending Reminder or Alert";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Please Select Row to Delete", Message); 
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0003

        [TestMethod]
        public void FPUC0013_REG0003()
        {

            try
            {
                Reports.TestDescription = "FP3209_FP3957_1: Alerts/File Reminders.";
                
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FPUC0013_Common_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Limited Escrow";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent ="File created with Open status";
                ProcParams.Tasks = new[] { "FPUC0013_Alerts_Task" };
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams);
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts";
                string AlertMessage = @"To view pending reminders and alerts";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage, ClickApply: true);
                Reports.TestStep = "Add misc task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                //
                string MiscTaskName = "MiscTaskTest";
                FastDriver.FileWorkflow.AddMiscTaskToProcess(ProcParams.ProcessName, MiscTaskName);
                // 
                Reports.TestStep = "Verify the Misc Task added.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.SelectTask(ProcParams.ProcessName,MiscTaskName).ToString());
                // 
                Reports.TestStep = "Set and verify warning alert.";
                               Support.AreEqual("Success", SetOverDueAlertForTask(ProcParams.ProcessName, MiscTaskName));
               

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0004

        [TestMethod]
        public void FPUC0013_REG0004()
        {

            try
            {
                Reports.TestDescription = "FP3957_2_FP4616_FP4618: File Reminders/Delete Active File Reminders, Alerts, Warnings.";
                Reports.StatusUpdate("BRs FP4616 and FP4618 are covered in BAT0008, Reg002", true);
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                // 
                Reports.TestStep = "Insert Active Reminder";
                string AlertMessage = "To delete reminder";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage,false);
                // 
                Reports.TestStep = "To delete a Reminder";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.DeleteAlertOrReminder(AlertMessage);
                // 
                Reports.TestStep = "Verify the active alert is deleted from message table";
                FastDriver.FileWorkflow.Open();
                Support.AreEqualTrim("False", FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains(AlertMessage).ToString());
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0005

        [TestMethod]
        public void FPUC0013_REG0005()
        {

            try
            {
                Reports.TestDescription = "FP3216: Alert Types.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                Reports.TestStep = "Verify Alert types.";
                FastDriver.MyFASTToday.Open();
                string ALertType=FastDriver.MyFASTToday.AlertType.FAGetText();
                //
                Support.AreEqualTrim(@"All 1099-S ATP Electronic Wire Fannie Mae FastWeb FW-AgentFirst File Hold Funds Overdue Owning Office Changed Service Added Service Removed Wintrack WSP AgentFirst Auto Updates Restricted LA.COM IBA myFIRSTAM FAMOS AgentNet LVIS AttorneyFirst", ALertType);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0006

        [TestMethod]
        public void FPUC0013_REG0006()
        {
            
            try
            {
                Reports.TestDescription = "FP3955_1: Overdue Tasks Alert.";
                // 
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FPUC0013_Common_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Limited Escrow";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent ="File created with Open status";
                ProcParams.Tasks = new[] { "FPUC0013_Alerts_Task" };
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams); 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                Reports.TestStep = "Overdue alert clean up";
                DeleteOverdueAlertsCreatedBefore1Hr(100);
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Go to filw workflow and select the task";
                FastDriver.FileWorkflow.Open();
                Thread.Sleep(2000);              
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Reports.TestStep = "Set and verify OverDue Alert For Task";
                Support.AreEqual("Success", SetOverDueAlertForTask(ProcParams.ProcessName, ProcParams.Tasks[0]));
                //
                Reports.TestStep = "Verify Overdue alert on MFT.";
                FastDriver.MyFASTToday.Open();
                string AlertType = "Overdue";
                string AlertMessage = "Overdue Task: "+ProcParams.Tasks[0];
               Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage,FileNumber).ToString());
                // 
                Reports.TestStep = "Delete Overdue alert.";
                Support.AreEqual("True", FastDriver.MyFASTToday.DeleteAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString()); 
                // 
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0007

        [TestMethod]
        public void FPUC0013_REG0007()
        {

            Reports.TestDescription = "FP3955_2: Overdue Tasks Alert.";
            Reports.StatusUpdate("This flow is covered in BAT0015", true);
        }
        #endregion Test
        #region Test FPUC0013_REG0008

        [TestMethod]
        public void FPUC0013_REG0008()
        {
            try
            {
                Reports.TestDescription = "FP3955_3: Overdue Tasks Alert.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FPUC0013_Common_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Limited Escrow";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent ="File created with Open status";
                ProcParams.Tasks = new[] { "FPUC0013_Alerts_Task" };
                string DueMinute = "1";
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams, DueTypeForFirstTask: @"After Task Activated", DueMin: DueMinute);
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Overdue alert clean up";
                DeleteOverdueAlertsCreatedBefore1Hr(100);
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Go to file wworkflow and select the task";
                FastDriver.FileWorkflow.Open();
                Thread.Sleep(2000);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Thread.Sleep(4000);
                Reports.TestStep = "Wait for due min.";
                WaitForWarnDueMin(DueMinute);
                Reports.TestStep = "Validate Overdue alert in Fileworkflow";
                string AlertMessage = "Overdue Task: " + ProcParams.Tasks[0];
                for (int i = 0; i < 5; i++)
                {
                    Thread.Sleep(3000);
                    FastDriver.FileWorkflow.Open();
                    if (FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains("Overdue Task"))
                    {
                        Support.AreEqualTrim("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", AlertMessage, "Message", TableAction.Click).Status.ToString());
                        break;
                    }
                    else
                    {
                        Thread.Sleep(5000);
                    }
                    if (i == 4)
                    {
                        Reports.StatusUpdate("Task Overdue alert is not triggered", false);
                    }
                }               
                // 
                Reports.TestStep = "Verify Overdue alert on MFT.";
                FastDriver.MyFASTToday.Open();
                string AlertType = "Overdue";
               Support.AreEqual("True",FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());
                // 
                Reports.TestStep = "Delete Overdue alert.";
                Support.AreEqual("True", FastDriver.MyFASTToday.DeleteAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString()); 

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0009

        [TestMethod]
        public void FPUC0013_REG0009()
        {

                Reports.TestDescription = "FP3955_4: Overdue Tasks Alert.";
                Reports.StatusUpdate("This flow is covered in REG0008", true);

        }
        #endregion Test
        #region Test FPUC0013_REG0010

        [TestMethod]
        public void FPUC0013_REG0010()
        {

                Reports.TestDescription = "FP3956_1_FP4616: Task Warning Alerts/Delete Active File Reminders, Alerts, Warnings.";
                Reports.StatusUpdate("This flow is covered in BAT0008 and BAT0014A", true);
               

        }
        #endregion Test
        #region Test FPUC0013_REG0011

        [TestMethod]
        public void FPUC0013_REG0011()
        {
                Reports.TestDescription = "FP3956_2: Task Warning Alerts.";
                Reports.StatusUpdate("This flow is covered in BAT0015", true);

        }
        #endregion Test
        #region Test FPUC0013_REG0012

        [TestMethod]
        public void FPUC0013_REG0012()
        {

            try
            {
                Reports.TestDescription = "FP3956_3: Task Warning Alerts.";

                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FPUC0013_Common_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Limited Escrow";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent ="File created with Open status";
                ProcParams.Tasks = new[] { "FPUC0013_Alerts_Task" };
                string WarnDueMinute = "1";
                Dictionary<string, string> ProcDetails = CreateNewProcess(ProcParams, DueTypeForFirstTask: @"After Task Started", WarnMin: WarnDueMinute,DueMin:"30");
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Go to file work flow and select task";
                FastDriver.FileWorkflow.Open();
                Thread.Sleep(2000);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Reports.TestStep = "Start the task";
                FastDriver.FileWorkflow.ClickStartTaskCheckboxForTask(ProcParams.ProcessName, ProcParams.Tasks[0]);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Thread.Sleep(4000);
                Reports.TestStep = "Wait for warn minute.";
                WaitForWarnDueMin(WarnDueMinute);
                Reports.TestStep = "Validate Warning alert in Fileworkflow";
                for (int i = 0; i < 5; i++)
                {
                    Thread.Sleep(3000);
                    FastDriver.FileWorkflow.Open();
                    if (FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains("Warning for Task"))
                    {
                        Support.AreEqualTrim("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Warning for Task: " + ProcParams.Tasks[0], "Message", TableAction.Click).Status.ToString());
                        break;
                    }
                    else
                    {
                        Thread.Sleep(7000);
                    }
                    if(i==4)
                    {
                        Reports.StatusUpdate("Task warning alert is not triggered", false);
                    }
                }              
                // 

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0013

        [TestMethod]
        public void FPUC0013_REG0013()
        {

                Reports.TestDescription = "FP3956_4: Task Warning Alerts.";
               Reports.StatusUpdate("This flow is covered in REG0012",true);

        }
        #endregion Test
        #region Test FPUC0013_REG0014

        [Obsolete,TestMethod]
        public void FPUC0013_REG0014()
        {
                Reports.TestDescription = "FP3956_5: Task Warning Alerts _reverting.";
                Reports.StatusUpdate("As the new process templated is created afresh everytime, these steps to revert process related changes is not required", true);
                

        }
        #endregion Test
        #region Test FPUC0013_REG0015_PH

        [TestMethod]
        public void FPUC0013_REG0015_PH()
        {

                Reports.TestDescription = "FP4202: Hold Funds Alert.";
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");


        }
        #endregion Test
        #region Test FPUC0013_REG0016

        [TestMethod]
        public void FPUC0013_REG0016()
        {

            try
            {
                Reports.TestDescription = "FP4659_FP5317: Service Added Alert/Active File Alerts Visible.";
                // 
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service removed";
                string FileNumber = CreateFile(0, false, true, false);
                // 
                Reports.TestStep = "Click on Title.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.Title.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate Alert in MFT";
                string AlertType = @"Service Added";
                string AlertMessage = "Title Service Added";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());
                //
                Reports.TestStep = "Verifying Alert in FileWork Flow";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage, "Message", TableAction.Click).Status.ToString());
                // 
                Reports.TestStep = "Remove Escrow.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(10000);
                //
                Reports.TestStep = "Validate Alert in MFT";
                AlertType = @"Service Removed";
                AlertMessage = "Escrow Service Removed";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());
                //
                Reports.TestStep = "Verifying Alert in FileWork Flow";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage, "Message", TableAction.Click).Status.ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0017

        [TestMethod]
        public void FPUC0013_REG0017()
        {
                Reports.TestDescription = "FP5317_FP4659: Service Removed Alert/Active File Alerts Visible.";
                Reports.StatusUpdate("This flow is covered in BAT0002, REG0016", true);
        }
        #endregion Test
        #region Test FPUC0013_REG0018

        [TestMethod]
        public void FPUC0013_REG0018()
        {

            try
            {
                Reports.TestDescription = "FP5318_2: Owning Office Changed Alert/Active File Alerts Visible.";
                Reports.StatusUpdate("FP5318_1 is covered in BAT0004", true);
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                //              
                Reports.TestStep = "Change Title Owning Office.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                Thread.Sleep(3000);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(6000);

                // 
                Reports.TestStep = "Click on Yes button.";
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }
                // 
                // 
                Reports.TestStep = "Validate Alert in MFT";
                string AlertType = @"Owning Office Changed";
                string AlertMessage = "Title Owning Office Changed";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());
                FastDriver.MyFASTToday.AlertsSelect.FAClick();
                Thread.Sleep(6000);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                // 
                // 
                Reports.TestStep = "Verifying Title Owning Office Changed alerts on File workflow";
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage, "Message", TableAction.Click).Status.ToString());
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0019

        [TestMethod]
        public void FPUC0013_REG0019()
        {

            try
            {
                Reports.TestDescription = "FP4601: File Alerts.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(); 
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts";
                string AlertMessage = @"File Alert";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage);
                // 
                Reports.TestStep = "Verify and delete the file alert";
                FastDriver.FileWorkflow.DeleteAlertOrReminder(AlertMessage);
                //
                Reports.TestStep = "Verify the active alert is deleted from message table";
                FastDriver.FileWorkflow.Open();
                Support.AreEqualTrim("False", FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains(AlertMessage).ToString());
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts";
                AlertMessage = @"File Alert New";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage);
                // 
                Reports.TestStep = "Go to My Fast Today and verify alert";
                FastDriver.MyFASTToday.Open();
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT("All", AlertMessage, FileNumber, "QA07, FAST").ToString());
                //
                Reports.TestStep = "Delete alert from MFT and verify";
                Support.AreEqual("True", FastDriver.MyFASTToday.DeleteAlertOnMFT("All", AlertMessage, FileNumber, "QA07, FAST").ToString());
                //
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0020

        [TestMethod]
        public void FPUC0013_REG0020()
        {

            Reports.TestDescription = "FP6449_1: 1099-S Alerts/Active File Alerts Visible.";
            Reports.StatusUpdate("This flow is covered in BAT0005", true);
              
        }
        #endregion Test
        #region Test FPUC0013_REG0021

        [TestMethod]
        public void FPUC0013_REG0021()
        {
         Reports.TestDescription = "FP6449_2: 1099-S Alerts/Active File Alerts Visible.";
         Reports.StatusUpdate("This flow is covered in BAT0006", true);

        }
        #endregion Test
        #region Test FPUC0013_REG0022
        [TestMethod]
        public void FPUC0013_REG0022()
        {

            try
            {
                Reports.TestDescription = "FP4757_FP4758_1_FP4617: Multiple File Alerts/Active File Alerts Visible.";
                // 
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FPUC0013_Common_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Limited Escrow";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent = "File created with Open status";
                ProcParams.Tasks = new[] { "FPUC0013_Alerts_Task", "FPUC0013_Alerts_Task1" };
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams);
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "FP4617  Insert Pending Reminders and Alerts";
                string FileAlert = @"File Alert";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(FileAlert, ClickApply: false);
                // 
                Reports.TestStep = "Remove Title service.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(10000);
                //
                Reports.TestStep = "Validate that Service added Alert is associated to Unassigned";
                string AlertType3 = @"Service Removed";
                string ServiceRemovedAlert = "Title Service Removed";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType3, ServiceRemovedAlert, FileNumber, "Unassigned").ToString());
                Reports.TestStep = "Go to file work flow and set warnng alert for task";
                FastDriver.FileWorkflow.Open();
                SetWarningAlertForTask(ProcParams.ProcessName, ProcParams.Tasks[0]);
                Reports.TestStep = "set overdue alert for task";
               SetOverDueAlertForTask(ProcParams.ProcessName, ProcParams.Tasks[1]);
               string WarningAlert = "Warning for Task: " + ProcParams.Tasks[0];
               string OverDueAlert = "Overdue Task: " + ProcParams.Tasks[1];

                //

                Reports.TestStep = "Verifying all alerts on file workflow";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                 Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", OverDueAlert, "Message", TableAction.Click).Status.ToString());
                 Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", WarningAlert, "Message", TableAction.Click).Status.ToString());
                 Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", ServiceRemovedAlert, "Message", TableAction.Click).Status.ToString());
                 Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", FileAlert, "Message", TableAction.Click).Status.ToString());
                // 
                Reports.TestStep = "FP4758 Verify all alert on MFT (Multiple alerts at same time)."; // note warning alert wont show on MFT
                FastDriver.MyFASTToday.Open();
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(20, "All", "Unassigned");
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(10, "All", "QA07, FAST");
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT("File", FileAlert, FileNumber,"QA07, FAST").ToString());
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT("Service Removed", ServiceRemovedAlert, FileNumber).ToString());
                // 
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.MyFASTToday.WaitForScreenToLoad();
                    FastDriver.MyFASTToday.AlertType.FASelectItem("Overdue");
                    FastDriver.MyFASTToday.AlertUser.FASelectItem("Unassigned");
                    FastDriver.MyFASTToday.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false, timeoutSeconds: 30);
                    Thread.Sleep(2000);
                    FastDriver.MyFASTToday.WaitForScreenToLoad();
                    int rowCount = FastDriver.MyFASTToday.SummaryAlertsTable.GetRowCount();
                    if (rowCount >= 100)
                        FastDriver.MyFASTToday.DeleteObsoleteAlerts(200, "Overdue", "Unassigned");
                    else
                        break;
                }
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT("Overdue", OverDueAlert, FileNumber).ToString());
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0023
        [TestMethod]
        public void FPUC0013_REG0023()
        {

            try
            {
                Reports.TestDescription = "FP4758_2: Multiple Alerts at one time. Single services added alert";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service";
                string FileNumber = CreateFile(0, true, false, false);
                // 
                Reports.TestStep = "Add escrow.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.Escrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //
                Reports.TestStep = "Remove Title service.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(10000);
                //
                Reports.TestStep = "Validate that sub escrow is disabled this time. Hence Not more than single service added alert will be displayed";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.IsEnabled().ToString());
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //
                Reports.TestStep = " Insert Pending Reminders and Alerts";
                string AlertMessage1 = @"File Alert";
                string AlertMessage2 = @"Reminder";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage1);
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage2, false);
                //
                Reports.TestStep = "Validate Alert in MFT";
                string AlertType = @"Service Added";
                string AlertMessage = "Escrow Service Added";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());
                //
                Reports.TestStep = "Verifying Alert in FileWork Flow";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage, "Message", TableAction.Click).Status.ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0024

        [TestMethod]
        public void FPUC0013_REG0024()
        {
                Reports.TestDescription = "FP4585: Manual Delete from Summary Alert/Pending File Reminders and Alerts.";
                Reports.StatusUpdate("The BR _FP4617 is covered in REG0022", true);
                Reports.StatusUpdate("The BR FP4585 is covered in BAT0008", true);
                // 
               
        }
        #endregion Test
        #region Test FPUC0013_REG0025

        [TestMethod]
        public void FPUC0013_REG0025()
        {

            try
            {
                Reports.TestDescription = "FP4645_FP4647_FP4646: Summary Alert Type Filter.";
                Reports.StatusUpdate("FP4647_FP4646 is covered in REG0026", true);
                Reports.StatusUpdate("FP4645 is covered in REG0027", true);
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0026

        [TestMethod]
        public void FPUC0013_REG0026()
        {

            try
            {
                Reports.TestDescription = "FP4868_FP4584_FP3217_FP4647_FP4646 : Summary Alerts Visible/Alert Type Filter Sort/Summary Alerts.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts";
                string AlertMessage1 = @"To view pending reminders and alerts";
                string AlertMessage2 = @"File Alert";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage1);
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage2);
                // 
                Reports.TestStep = "Verify all alert on MFT and first alert type is ALL.";
                string AlertType = "All";
                FastDriver.MyFASTToday.Open();
                string AlertTypes=FastDriver.MyFASTToday.AlertType.FAGetText();
                Support.AreEqualTrim(@"All 1099-S ATP Electronic Wire Fannie Mae FastWeb FW-AgentFirst File Hold Funds Overdue Owning Office Changed Service Added Service Removed Wintrack WSP AgentFirst Auto Updates Restricted LA.COM IBA myFIRSTAM FAMOS AgentNet LVIS AttorneyFirst", AlertTypes);
                FastDriver.MyFASTToday.AlertType.FASelectItem(@"All");
                Thread.Sleep(5000);
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage1, FileNumber,"QA07, FAST").ToString());
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage2, FileNumber, "QA07, FAST").ToString());
                Reports.TestStep = "Verify all alert on MFT and first alert type is ALL.";
                Support.AreEqual("True", ValidateOrderOfALertsOnMFT("All").ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0027
        /// <summary>
        /// FP4648  For Employee Filter  
        ///   When an employee is selected the system shall display all File Alerts created by the selected Employee.
        ///   The Employee filter enables viewing of alerts by employee(s).
        ///   The Employee filter has four criteria:
        ///   1.  "Current Office" representing all Employees in the current office
        ///   2.  a list of all the Employee names whose home office is the current office
        ///   3.   "Unassigned".
        ///   4.  Groups in the current office
        /// </summary>
        [TestMethod]
        public void FPUC0013_REG0027()
        {

            try
            {
                Reports.TestDescription = "FP4648_FP4652_FP4645: For Employee Filter/For Employee Filter Sort.";
                // 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(); 
                // 
                Reports.TestStep = "Create file Alert";
                string AlertMessage1 = @"File Alert";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage1);
                //
                Reports.TestStep = "Remove Title service.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(10000);
                //
                Reports.TestStep = "Validate that Service added Alert is associated to Unassigned";
                string AlertType = @"Service Removed";
                string AlertMessage = "Title Service Removed";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "Unassigned").ToString());
                // 
                Reports.TestStep = "Verify file alert is displayed when particular employee is selected in drop down.";
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "QA07, FAST").ToString());
                // 
                Reports.TestStep = "Verify file alert is displayed when employee belongs to current office.";
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "Current Office").ToString());

                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0028
        /// <summary>
        /// 5.7.2.3  FP4656  All Alerts Employee Filter  
        ///   The All Alert Type filter combined with the Employee filter shall display all Alert Types assigned to the selected Employee.
        ///   When an individual employee is selected with the All Alert Type filter, the system shall display:
        ///   File Alerts created by the employee
        ///   Overdue Tasks where the employee has been assigned
        /// </summary>
        [TestMethod]
        public void FPUC0013_REG0028()
        {

            try
            {
                Reports.TestDescription = "FP4656: All Alerts Employee Filter.";
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FPUC0013_Common_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Limited Escrow";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent = "File created with Open status";
                ProcParams.Tasks = new[] { "FPUC0013_Alerts_Task" };
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams);
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(title:false,TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts (File Alerts created by the employee)";
                string AlertMessage1 = @"To view pending reminders and alerts";
               // string AlertMessage2 = @"File Alert";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage1, ClickApply: false);
                // 
                Reports.TestStep = "Open file workflow";
                FastDriver.FileWorkflow.Open();
                Thread.Sleep(2000);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Reports.TestStep = "Select a task and then click on details";
                FastDriver.FileWorkflow.SelectTask("FPUC0013_Common_Template", "FPUC0013_Alerts_Task");
                // 
                Reports.TestStep = "Click on Details.";
                FastDriver.FileWorkflow.Details.FAClick();
                // 
                Reports.TestStep = "Enter DueDate date";
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                string DueDate = DateTime.Now.ToDateString();
                FastDriver.TaskDetailsDlg.DueDate.FASetText(DueDate);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Thread.Sleep(4000);
                Reports.TestStep = "Navigate to Seller screen and click on Edit";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(4, "Individual", 4, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                Thread.Sleep(2000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItem(@"1099-S");
                FastDriver.BottomFrame.Done();
                Thread.Sleep(2000);
                // 
                Reports.TestStep = "Navigate to TDS screen and Enter the current date as settlement date.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.UpdateStatusDateWithServerDate();
                string SettlementDate = DateTime.Now.ToDateString();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(SettlementDate);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(2000);
                // 
                Reports.TestStep = "Select the required criteria for 1099S type alerts.";
                string AlertType = @"1099-S";
                string AlertMessage = @"Settlement Date is Added. Please create and print seller's 1099-S.";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());
                // 
                Reports.TestStep = "Click on Title.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.Title.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate Alert in MFT";
                string AlertType2 = @"Service Added";
                string AlertMessage2 = "Title Service Added";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType2, AlertMessage2, FileNumber).ToString());  
                //
                Reports.TestStep = "Chang Escrow Own Office.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                Thread.Sleep(3000);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(6000);

                // 
                Reports.TestStep = "Click on Yes button.";
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }
                // 
                // 
                Reports.TestStep = "Validate Alert in MFT";
                string AlertType3 = @"Owning Office Changed";
                string AlertMessage3 = "Escrow Owning Office Changed";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType3, AlertMessage3, FileNumber).ToString());
                Reports.TestStep = "Validate that file workflow is loaded on clicking select button";
                FastDriver.MyFASTToday.AlertsSelect.FAClick();
                Thread.Sleep(6000);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.FileWorkflow.CollapseAll.IsDisplayed().ToString());
    
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0029
        /// <summary>
        /// FP4653  File Alert Employee Filter  
        ///   File alert type combined with the Employee filter shall display only File alerts created by the selected Employee.
        ///
        ///   When an individual Employee is selected the system shall display any file associated to the current office that 
        ///       has a file alert which was created by the selected employee shall be displayed.
        ///
        ///   "Unassigned" Employee is not applicable and shall not be a valid selection.
        ///
        ///   When "Current Office", aka all Employees, is selected the system shall display any file associated to the current office
        ///       that has a file alert which was created by an employee whose home office is also the current office.
        /// </summary>
        [TestMethod]
        public void FPUC0013_REG0029()
        {

            try
            {
                Reports.TestDescription = "FP4653: File Alert Employee Filter.";
                // 
                Reports.TestStep = "Log into FAST application with FAST/QA06 user.";
                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber1 = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts (File Alerts created by the employee)";
                string AlertMessage1 = @"alerts for FastQA06";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage1);
                //
                Reports.TestStep = "Log into FAST application with FAST/QA07 user.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber2 = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Insert Pending Reminders and Alerts (File Alerts created by the employee)";
                string AlertMessage2 = @"alerts for FastQA07";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage2);
                //
                Reports.TestStep = "Log into FAST application with superuser.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN(AutoConfig.UserNameSU,AutoConfig.UserPasswordSU);
                Reports.TestStep = "Navigate to Office Level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");
                Reports.TestStep = "Validate all alerts for fastqa07 user.";
                FastDriver.MyFASTToday.Open();
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(5, "File", "QA07, FAST");
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(5, "File", "QA06, FAST");
                FastDriver.MyFASTToday.DeleteObsoleteAlerts(5, "File", "Current Office");
               Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT("File", AlertMessage2, FileNumber2, "QA07, FAST").ToString());
                //
                Reports.TestStep = "Validate all alerts for fastqa06 user.";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT("File", AlertMessage1, FileNumber1, "QA06, FAST").ToString());
                //
                Reports.TestStep = "Validate all alerts for Current office user.";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT("File", AlertMessage1, FileNumber1, "Current Office").ToString());
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT("File", AlertMessage2, FileNumber2, "Current Office").ToString());
                // 
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FPUC0013_REG0030_PH

        [TestMethod]
        public void FPUC0013_REG0030_PH()
        {
                Reports.TestDescription = "FP4654: Hold Funds Employee Filter.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
                
       }
        #endregion Test
        //
        #region Test FPUC0013_REG0031

        [TestMethod]
        public void FPUC0013_REG0031()
        {

            try
            {
                Reports.TestDescription = "FP4651: Overdue Employee Filter.";
                // 
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName ="FPUC0013_Common_Template";
                 ProcParams.ProcessType="Title Production";  
                  ProcParams.TranType    ="Limited Escrow"; 
                  ProcParams.State   ="CA"     ;
                  ProcParams.County   ="Alameda"    ;
                  ProcParams.ProcessEvent = "File created with Open status";
                  ProcParams.Tasks  =new[] { "FPUC0013_Alerts_Task" };
                  Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams);
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile(TransactionType: @"LTDESCROW"); //Limited escrow
                // 
                Reports.TestStep = "Select the task and set due date";
                FastDriver.FileWorkflow.Open();
                Thread.Sleep(2000);
                // Reports.TestStep = "Validate for Task is activated.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Reports.TestStep = "Select a task and then click on details";
                FastDriver.FileWorkflow.SelectTask(ProcParams.ProcessName, ProcParams.Tasks[0]);
                // 
                Reports.TestStep = "Click on Details Button for Manual Activation.";
                FastDriver.FileWorkflow.Details.FAClick();
                // 
                Reports.TestStep = "Enter DueDate date";
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                string DueDate = DateTime.Now.ToDateString();
                FastDriver.TaskDetailsDlg.DueDate.FASetText(DueDate);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Thread.Sleep(4000);
                // 
                Reports.TestStep = "Verifying overdue alerts on file workflow";
                string AlertMessage = "Overdue Task: " + ProcParams.Tasks[0];
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", AlertMessage, "Message", TableAction.Click).Status.ToString());
                // 
                Reports.TestStep = "Verify Overdue alert on MFT for Unassigned.";
                FastDriver.MyFASTToday.Open();
                string AlertType = "Overdue";
                Support.AreEqual("True",FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber,"Unassigned").ToString());
                // 
                Reports.TestStep = "Select the task and assign it to fast qa07";
                FastDriver.FileWorkflow.Open();
                Thread.Sleep(2000);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Reports.TestStep = "Select a task and then click on details";
                FastDriver.FileWorkflow.AssignTaskTo(ProcParams.ProcessName, ProcParams.Tasks[0], "QA07, FAST");
               // FastDriver.FileWorkflow.AssignTaskTo("FPUC0013_Common_Template", "FPUC0013_Alerts_Task", "QA07, FAST");
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                //
                Reports.TestStep = "Verify Overdue alert on MFT for fast qa07.";
                FastDriver.MyFASTToday.Open();
                Support.AreEqual("True",FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "QA07, FAST").ToString());
                Thread.Sleep(2000);
                //
                Reports.TestStep = "Verify Overdue alert on MFT for Current Office.";
                FastDriver.MyFASTToday.Open();
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "Current Office").ToString());
                Thread.Sleep(2000);
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0032

        [TestMethod]
        public void FPUC0013_REG0032()
        {

            try
            {
                Reports.TestDescription = "FP4877: Service Added Employee Filter.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service removed";
                string FileNumber = CreateFile(0, false, true, false);
                // 
                Reports.TestStep = "Click on Title.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.Title.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate that Service added Alert is associated to Unassigned";
                string AlertType = @"Service Added";
                string AlertMessage = "Title Service Added";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber,"Unassigned").ToString());   
                // 
                Reports.TestStep = "Verify that Service Added alert should not be displayed with Employee Filter as current office.";
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "Current Office").ToString());
                Reports.TestStep = "Verify that Service Added alert should not be displayed with Employee Filter as any other employee.";
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, @"QA07, FAST").ToString());  
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0033

        [TestMethod]
        public void FPUC0013_REG0033()
        {

            try
            {
                Reports.TestDescription = "FP5492: Owning Office Changed Employee Filter.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                //              
                Reports.TestStep = "Chang Escrow Own Office.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                Thread.Sleep(3000);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(6000);
                // 
                Reports.TestStep = "Click on Yes button.";
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }
                // 
                Reports.TestStep = "Validate that Owning Office Changed Alert is associated to Unassigned";
                string AlertType = @"Owning Office Changed";
                string AlertMessage = "Escrow Owning Office Changed";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber,"Unassigned").ToString()); 
                // 
                Reports.TestStep = "Verify that Owning Office Changed alert should not be displayed with Employee Filter as current office.";
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "Current Office").ToString());   
                //
                Reports.TestStep = "Verify that Owning Office Changed alert should not be displayed with Employee Filter as any other employee.";
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, @"QA07, FAST").ToString());               
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0034

        [TestMethod]
        public void FPUC0013_REG0034()
        {

            try
            {
                Reports.TestDescription = "FP5493: Service Type Removed Employee Filter.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                // 
                Reports.TestStep = "Remove Title service.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(10000);
                //
                Reports.TestStep = "Validate that Service Removed Alert is associated to Unassigned";
                string AlertType = @"Service Removed";
                string AlertMessage = "Title Service Removed";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber).ToString());       
                // 
                Reports.TestStep = "Verify that Service removed alert should not be displayed with Employee Filter as current office.";
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "Current Office").ToString());   
                // 
                Reports.TestStep = "Verify that Service removed alert should not be displayed with Employee Filter as any other employee.";
                Support.AreEqual("False", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, @"QA07, FAST").ToString());  
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FPUC0013_REG0035

        [TestMethod]
        public void FPUC0013_REG0035()
        {

            try
            {
                Reports.TestDescription = "FP4876_FD2: For Employee Filter Cache/Field definition for MFT.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service removed";
                string FileNumber = CreateFile(0, false, true, false);
                // 
                Reports.TestStep = "Validate default employee filter.";
                FastDriver.MyFASTToday.Open();
                Support.AreEqual(@"QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem());
                Thread.Sleep(2000);
                // 
                Reports.TestStep = "Click on Title.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.Title.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate that Service added Alert is associated to Unassigned";
                string AlertType = @"Service Added";
                string AlertMessage = "Title Service Added";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT(AlertType, AlertMessage, FileNumber, "Unassigned").ToString());
                FastDriver.MyFASTToday.AlertUser.FASelectItem("QA06, FAST");
                FastDriver.LeftNavigation.ClickHome();
                // 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN(CleanSession:false);
                Reports.TestStep = "Validate default employee filter is unassigned (changed in last step).";
                FastDriver.MyFASTToday.Open();
                Support.AreEqual(@"QA06, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem());
                Thread.Sleep(2000);
                // 
                FastDriver.MyFASTToday.AlertUser.FASelectItem("Unassigned");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false, timeoutSeconds: 30);
                Thread.Sleep(2000);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate field definition.";
                Support.AreEqual(@"True", FastDriver.MyFASTToday.AlertUser.IsEnabled().ToString());
                Support.AreEqual(@"True", FastDriver.MyFASTToday.AlertType.IsEnabled().ToString());
                Support.AreEqual(@"True", FastDriver.MyFASTToday.AlertsSelect.IsEnabled().ToString());
                Support.AreEqual(@"True", FastDriver.MyFASTToday.EventLogAlerts.IsEnabled().ToString());
                Support.AreEqual(@"True", FastDriver.MyFASTToday.DeleteAlerts.IsEnabled().ToString());
                Thread.Sleep(2000);
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0036

        [TestMethod]
        public void FPUC0013_REG0036()
        {

            try
            {
                Reports.TestDescription = "FP4619: User specified File Reminders and Alerts.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                // 
                Reports.TestStep = "Create Alert";
                string AlertMessage1 = "To create alert";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage1, true);
                Reports.TestStep = "Create Pending Reminder";
                string AlertMessage2 = "To create reminder";
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage2, false);
                Reports.TestStep = "Verify active alert on MFT.";
                Support.AreEqual("True", FastDriver.MyFASTToday.ValidateAlertOnMFT("All", AlertMessage1, FileNumber, "QA07, FAST").ToString());
                // 
                Reports.TestStep = "Verify alert and reminder in FileWorkflow.";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage1, "Message", TableAction.Click).Status.ToString());
                Support.AreEqual("Success", FastDriver.FileWorkflow.MessagesTable.PerformTableAction(@"Message", AlertMessage2, "Message", TableAction.Click).Status.ToString()); 
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0037

        [TestMethod]
        public void FPUC0013_REG0037()
        {

            try
            {
                Reports.TestDescription = "FD1: Field definition for file workflow.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create new order with Title Service and escrow service";
                string FileNumber = CreateFile();
                // 
                Reports.TestStep = "Create Alert";
                string AlertMessage = "To create alert";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage, true);
                //
                Reports.TestStep = "Validating field definition";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual(@"True",FastDriver.FileWorkflow.Del.IsEnabled().ToString());
                // 
                Reports.TestStep = "Validating field definition pending reminders";
                FastDriver.FileWorkflow.New.FAClick();
                Support.AreEqual(@"True", FastDriver.FileWorkflow.Visibility.IsEnabled().ToString());
                Support.AreEqual(@"True", FastDriver.FileWorkflow.NotifyDate.IsEnabled().ToString());
                Support.AreEqual(@"True", FastDriver.FileWorkflow.Note.IsEnabled().ToString());
                Support.AreEqual(@"True", FastDriver.FileWorkflow.RemCal.IsEnabled().ToString());
                
                // 
                Reports.TestStep = "Validating field definition pending reminders NOTE with lower boundary";
                   string AlertMessage1 = @"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRS1";
                   FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage1, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                Thread.Sleep(2000);

                // 
                Reports.TestStep = "Validating field definition pending reminders NOTE with exact value";
                string AlertMessage2 = @"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRS12";
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage2, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                Thread.Sleep(2000);

                // 
                Reports.TestStep = "Validating field definition pending reminders NOTE with upper boundary";
                string AlertMessage3 = @"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRS1234";
                FastDriver.FileWorkflow.CreateNewAlertOrReminder(AlertMessage3, true);

                // 
                Reports.TestStep = "Warning when message exceeds 255 characters";
                string IEMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Warning!  Reminder Note was truncated to 255 characters", IEMessage);
                // 
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                Thread.Sleep(2000);
                // 
                Reports.TestStep = "To delete a pending reminder";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FileWorkflow.New.GiveFocus();
                    Keyboard.SendKeys("%N");
                    if (FastDriver.FileWorkflow.Visibility.IsDisplayed())
                        break;
                }

                FastDriver.FileWorkflow.Visibility.FASelectItem(@"Alert");

                string NotifyDate = DateTime.Now.ToDateString();
                FastDriver.FileWorkflow.NotifyDate.FASetText(NotifyDate);
                FastDriver.FileWorkflow.Note.FASetText(@"Removing alert using hotkey");
                bool result = false;
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FileWorkflow.RemoveRemainder.GiveFocus();
                    Keyboard.SendKeys("%R");
                    IEMessage = FastDriver.WebDriver.HandleDialogMessage();
                    result =IEMessage.Contains(@"Delete selected File Reminder or Alert?");
                    if(result)
                    {
                        break;
                    }
                }
                // 
                Reports.StatusUpdate("Pending alert is removed", result);
                // 

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FPUC0013_REG0038_PH

        [TestMethod]
        public void FPUC0013_REG0038_PH()
        {

                Reports.TestDescription = "FP5482: Wintrack Alert/Wintrack Employee Filter.";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_REG0039_PH

        [TestMethod]
        public void FPUC0013_REG0039_PH()
        {

                Reports.TestDescription = "FP5481_FP5488: FASTWeb Alert/FASTWeb Employee Filter.";
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_REG0040_PH

        [TestMethod]
        public void FPUC0013_REG0040_PH()
        {

            Reports.TestDescription = "FP4592_FP4202_FP9408_FP5477_FP8709_4658: Alert Visible/Hold Funds Alert.";
                // 
                // "FP 4658 Verify order of all alerts on file workflow"
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_REG0041_PH

        [TestMethod]
        public void FPUC0013_REG0041_PH()
        {


                Reports.TestDescription = "FP5478_FP5479_FP7446_FP7556_FP4931: Fax Delivery Failure/E-mail Delivery Failure.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");


        }
        #endregion Test
        #region Test FPUC0013_REG0042_PH

        [TestMethod]
        public void FPUC0013_REG0042_PH()
        {


                Reports.TestDescription = "FP9294_FP9292_FP9293_FP8116_FP4644_FP4875: WSP Program Type Mismatch -See File Notes for Detail/Auto Delete Warnings.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_REG0043_PH

        [TestMethod]
        public void FPUC0013_REG0043_PH()
        {


                Reports.TestDescription = "FP4657_FP4586_FP4614_FP5325_FP8710_FP4930_FP4587: WSP Employee Filter/Auto Delete Alerts & Warnings.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #region Test FPUC0013_REG0044_PH

        [TestMethod]
        public void FPUC0013_REG0044_PH()
        {

                Reports.TestDescription = "FP9294_FP9292_FP9293_FP8116_FP4644: WSP Program Type Mismatch -See File Notes for Detail/Auto Delete Warnings.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion Test
        #endregion
        #region PrivateMethods
        private void IISLOGIN(string UserName = null, string Password = null,bool CleanSession=true)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, CleanSession);

        }
        //
        private void ADMLOGIN(string UserName = null, string Password = null)
        {
                Reports.TestStep = "Log in to the Admin site";
                UserName = UserName ?? AutoConfig.UserNameSU;
                Password = Password ?? AutoConfig.UserPasswordSU;
                Credentials credentials = new Credentials() { UserName = UserName, Password = Password };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
        }
        //
        private void DeleteOverdueAlertsCreatedBefore1Hr(int NumberOfALerts)
        {
            FastDriver.MyFASTToday.Open();
            FastDriver.MyFASTToday.WaitForScreenToLoad();
            FastDriver.MyFASTToday.AlertType.FASelectItem("Overdue");
            FastDriver.MyFASTToday.AlertUser.FASelectItem("Unassigned");
            FastDriver.MyFASTToday.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false, timeoutSeconds: 30);
            Thread.Sleep(2000);
            FastDriver.MyFASTToday.WaitForScreenToLoad();
            int rowCount = FastDriver.MyFASTToday.SummaryAlertsTable.GetRowCount();
            if (rowCount >= 100)
            {
                DateTime MFTAlertDate;
                Reports.TestStep = "Delete alerts in MFT";
                for (int i = 1; i < (NumberOfALerts > rowCount ? rowCount : NumberOfALerts); i++)
                {
                    string AlertTime=FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction(i, 3, TableAction.GetText).Message;
                    if (AlertTime.Length > 10)
                    {
                        MFTAlertDate = Convert.ToDateTime(AlertTime.Substring(0, 18)).ToUniversalTime();

                    }
                    else
                    {
                        MFTAlertDate = Convert.ToDateTime(AlertTime.Substring(0, 10));
                        continue;
                    }
                    if ((DateTime.UtcNow-MFTAlertDate).TotalHours >= 1) // delete alerts created before last 1 hr
                    {
                        FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction(i, 1, TableAction.Click);
                    }
                }
            }
            FastDriver.MyFASTToday.Open();
        }
        //
        private Dictionary<string, int> CreateOrderForInterfaces(string SOURCE)
        {
            Dictionary<string, int> FileData = new Dictionary<string, int>();
            try
            {
                Reports.TestStep = "Create a " + SOURCE + " file";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();

                fileRequest.Source = SOURCE;

                int FileId = (int)FileService.CreateFile(fileRequest).FileID;
                var File = FileService.GetOrderDetails(FileId);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FileData.Add("FileId", FileId);
                FileData.Add("FileNumber", Convert.ToInt32(File.FileNumber));
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return FileData;
        }
        //
        private void WaitForWarnDueMin(string WarnDueMinute)
        {
            int MilliSec = Convert.ToInt32(WarnDueMinute) *60* 1000;
            Thread.Sleep(MilliSec);
        }
        //
        private Dictionary<string, string> CreateNewProcess(ProcessParameters ProcParams, string DueTypeForFirstTask = "", string WarnMin = "", string DueMin = "")
        {
            Dictionary<string, string> ProcDetails = new Dictionary<string, string>();
            try
            {
                FastDriver.TaskTemplateSelection.Open();
                if (ProcParams.Tasks == null)
                {
                    ProcParams.Tasks = new string[2];
                    for (int i = 0; i < ProcParams.Tasks.Length; i++)
                    {
                        ProcParams.Tasks[i] = FastDriver.TaskTemplateSelection.CreateNewTask();
                    }
                }

                else
                {
                    for (int i = 0; i < ProcParams.Tasks.Length; i++)
                    {
                        if (!FastDriver.TaskTemplateSelection.CheckIfTaskExists(ProcParams.Tasks[i]))
                            FastDriver.TaskTemplateSelection.CreateNewTask(ProcParams.Tasks[i]);
                    }
                }
                FastDriver.RegionalProcessSummary.Open();
                //
                Reports.TestStep = "Enter process Name";
                if (string.IsNullOrEmpty(ProcParams.ProcessName))
                    ProcParams.ProcessName = "Process_New_" + Guid.NewGuid().GetHashCode();

                //
                Reports.TestStep = "Remove process if already exists";
                if (FastDriver.RegionalProcessSummary.ProcessSummaryTable.Text.Contains(ProcParams.ProcessName))
                {
                    FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction("Process Name", ProcParams.ProcessName, "Process Name", TableAction.Click);
                    FastDriver.RegionalProcessSummary.Remove.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                }
                FastDriver.RegionalProcessSummary.New.FAClick();
                FastDriver.RegionalProcessEdit.SwitchToContentFrame();
                FastDriver.RegionalProcessEdit.ProcessType.FASelectItem(ProcParams.ProcessType);
                //
                FastDriver.RegionalProcessEdit.ProcessName.FASetText(ProcParams.ProcessName);
                FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
                FastDriver.RegionalProcessEdit.Description.FASetText("!!!!!!This is QA automation template. DO NOT TOUCH!!!!!");
                //   Support.AreEqual("1486", this.ProcessOwner.FAGetValue());

                Reports.TestStep = "create the process template selection criteria";
                FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.TranType.FASelectItem(ProcParams.TranType);
                FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();
                Thread.Sleep(4000);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                Thread.Sleep(2000);
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", ProcParams.State, "Select", TableAction.On);
                //FastDriver.StateSelectionDlg.grdState8SelState.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();

                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();
                Thread.Sleep(4000);
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                Thread.Sleep(2000);
                FastDriver.CountySelectionDlg.Table.PerformTableAction("#2", ProcParams.County.ToUpper(), "#1", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                Thread.Sleep(4000);
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.Done.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction("Process Events", ProcParams.ProcessEvent, "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Add a newly created task to new process";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.Add.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                for (int i = 0; i < ProcParams.Tasks.Length; i++)
                {
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, ProcParams.Tasks[i], 2, TableAction.On);
                    FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                    ProcDetails.Add("Task" + i, ProcParams.Tasks[i]);
                }
                FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.RegionalProcessEdit.SwitchToContentFrame();
                FastDriver.RegionalProcessEdit.Inactive.FASetCheckbox(false);


                if (!string.IsNullOrEmpty(DueTypeForFirstTask))
                {
                    Reports.TestStep = "Set duetype, due min for the 1st task";
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.DueType.FASelectItem(DueTypeForFirstTask);
                    if (!string.IsNullOrEmpty(WarnMin))
                        FastDriver.RegionalProcessEdit.WarnMin.FASetText(WarnMin);
                    if (!string.IsNullOrEmpty(DueMin))
                        FastDriver.RegionalProcessEdit.DueMin.FASetText(DueMin);
                }
                FastDriver.BottomFrame.Done();
                Thread.Sleep(7000);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "ACtivate the process";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select a process and click Edit button";
                FastDriver.RegionalProcessSummary.SwitchToContentFrame();
                FastDriver.RegionalProcessSummary.SelectProcessFromSummaryTable(1, ProcParams.ProcessName, 1, TableAction.Click);
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.SwitchToContentFrame();
                FastDriver.StatusEdit.Activate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.LeftNavigation.Navigate<PendingRefreshSummary>(@"Home>System Maintenance>Process Setup>Pending Refresh Summary").WaitForScreenToLoad();
                FastDriver.PendingRefreshSummary.WaitForScreenToLoad();
                Reports.TestStep = "Select a process and click on Refresh button.";
                if (FastDriver.PendingRefreshSummary.SummaryTable.Text.Contains(ProcParams.ProcessName))
                {
                    FastDriver.PendingRefreshSummary.SummaryTable.PerformTableAction("#2", ProcParams.ProcessName, "#1", TableAction.On);
                    FastDriver.PendingRefreshSummary.RefreshProcess.FAClick();
                    Thread.Sleep(5000);
                    FastDriver.PendingRefreshSummary.RefreshTemplate(ProcParams.ProcessName);
                }
                ProcDetails.Add("ProcessName", ProcParams.ProcessName);

                return ProcDetails;
            }
            catch
            {
                throw;
            }
        }
        //
        private string CreateFile(int SalesPrice = 0, bool title = true, bool escrow = true, bool subescrow = false,string TransactionType="SALE")
        {
            try
            {
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.File.Services = RequestFactory.GetServices(title, escrow, subescrow);
                customizableFileRequest.File.TransactionTypeObjectCD = TransactionType;
                customizableFileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[] 
                    { 
                         new FASTWCFHelpers.FastFileService.BuyerSeller() 
                        {
                            FirstName = "Buyer1FirstName",
                            LastName = "Buyer1LastName",
                            EntityTypeID = 48,
                            Type = "Individual",
                        },
                         new FASTWCFHelpers.FastFileService.BuyerSeller() 
                        {
                            FirstName = "Buyer2FirstName",
                            LastName = "Buyer2LastName",
                            SpouseFirstName= "Buyer2SpouseName",
                            EntityTypeID = 48,
                            Type = "Husband And Wife",
                        }
                        
                    };
                customizableFileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[] 
                    {
                        new FASTWCFHelpers.FastFileService.BuyerSeller() 
                        {
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1LastName",
                            EntityTypeID = 48,
                            Type = "Individual"
                        },
                         new FASTWCFHelpers.FastFileService.BuyerSeller() 
                        {
                            FirstName = "Seller2FirstName",
                            LastName = "Seller2LastName",
                            SpouseFirstName= "Seller2SpouseName",
                            EntityTypeID = 48,
                            Type = "Husband And Wife"
                        }
                        
                    };
                if(SalesPrice!=0)
                customizableFileRequest.File.SalesPriceAmount = SalesPrice;
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(customizableFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                return fileNumber;
            }
            catch (Exception)
            {
                try
                {
                    return CreateQFEWithSalesDetails(SalesPrice, title, escrow, subescrow);
                }
                catch (Exception ex)
                {
                    throw new Exception("Unable to create QFE", ex);
                }

            }
        }
        private string CreateQFEWithSalesDetails(int SalesPrice = 0, bool title = true, bool escrow = true, bool subescrow = false)
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            NewFileParameters QFEParams = new NewFileParameters();
            QFEParams = NewFileParameters.GetDefaultParams();
            QFEParams.Title = title;
            QFEParams.Escrow = escrow;
            QFEParams.SubEscrow = subescrow;
            if (SalesPrice != 0)
                QFEParams.TermsDatesSalesPrice = SalesPrice.ToString();
            QFEParams.PropertyInformationName = "J305";
            QFEParams.PropertyInformationType = "Single Family Residence";
            QFEParams.PropertyInformationLot = "Lot1";
            QFEParams.PropertyInformationBlock = "Block1";
            QFEParams.PropertyInformationUnit = "Unit1";
            QFEParams.PropertyPropTaxAPN1 = "Prop1APN1";
            QFEParams.PropertyPropTaxAPN2 = "9845012345";
            QFEParams.PropertyBookAddrLin1 = "J305";
            QFEParams.PropertyBookAddrLin2 = "JJEJAMQ";
            QFEParams.PropertyBookAddrLin3 = "JJEJAMQ";
            QFEParams.PropertyCity = "ALBANY";
            QFEParams.PropertyState = "CA";
            QFEParams.PropertyZipCode = "12345";
            QFEParams.PropertyCounty = "ALAMEDA";
            FastDriver.QuickFileEntry.CreateFile(QFEParams);
            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }
            Thread.Sleep(5000);
            FastDriver.FileHomepage.WaitForScreenToLoad();
            FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.FileNum, true);
            return FastDriver.FileHomepage.FileNum.FAGetValue();
        }
        //
        private bool ValidateOrderOfALertsOnMFT(string AlertType, string AlertUser = "Unassigned")
        {
            FastDriver.MyFASTToday.AlertType.FASelectItem(AlertType);
            FastDriver.MyFASTToday.AlertUser.FASelectItem(AlertUser);
            FastDriver.MyFASTToday.WebDriver.WaitForWindowAndSwitch("Loading Summary Alerts...", toExist: false, timeoutSeconds: 20);
            Thread.Sleep(2000);
            FastDriver.MyFASTToday.WaitForScreenToLoad();

            Reports.TestStep = "Verify " + AlertType + " alerts in MFT";
            bool status = false;
            int RowCount = FastDriver.MyFASTToday.SummaryAlertsTable.GetRowCount();
            int count = 0;
            for (int i = RowCount; i > 0; i--)
            {
                DateTime MFTAlertDate2 = Convert.ToDateTime(FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Substring(0, 10));
                DateTime MFTAlertDate1 = Convert.ToDateTime(FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction(--i, 3, TableAction.GetText).Message.Substring(0, 10));
                if (MFTAlertDate1 <= MFTAlertDate2)
                {
                    status = true;
                    count++;
                }
                else
                {
                    status = false;
                    break;
                }
                if (count == 5)
                    break;
            }
            return status;       
        }
        //

        //
        private string SetOverDueAlertForTask(string ProcessName, string TaskName)
        {
            FastDriver.FileWorkflow.SelectTask(ProcessName, TaskName);
            // 
            Reports.TestStep = "Click on Details Button.";
            FastDriver.FileWorkflow.Details.FAClick();
            // 
            FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
            Reports.TestStep = "Clear warn date if any";
            FastDriver.TaskDetailsDlg.WarnDate.Clear();
            Reports.TestStep = "Enter overdue date";
            string DueDate = DateTime.UtcNow.AddHours(-8).ToDateString();
            FastDriver.TaskDetailsDlg.DueDate.FASetText(DueDate);
            FastDriver.DialogBottomFrame.ClickDone();
            string message = FastDriver.WebDriver.HandleDialogMessage();
            if (message.Contains(@"Error!"))
            {
                string NewDueDate = Convert.ToDateTime(DueDate).AddDays(1).ToDateString();
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                FastDriver.TaskDetailsDlg.WarnDate.FASetText(NewDueDate);
                FastDriver.DialogBottomFrame.ClickDone();
            }
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            Thread.Sleep(4000);
            // 
            Reports.TestStep = "Verifying overdue alerts";
            FastDriver.FileWorkflow.WaitForScreenToLoad();
            return FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Overdue Task: " + TaskName, "Message", TableAction.Click).Status.ToString();
        }
        //
        private string SetWarningAlertForTask(string ProcessName, string TaskName)
        {
            FastDriver.FileWorkflow.SelectTask(ProcessName, TaskName);
            // 
            Reports.TestStep = "Click on Details Button.";
            FastDriver.FileWorkflow.Details.FAClick();
            // 
            Reports.TestStep = "Enter Warn date";
            FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
            string WarnDate = DateTime.UtcNow.AddHours(-8).ToDateString();
            FastDriver.TaskDetailsDlg.WarnDate.FASetText(WarnDate);
            FastDriver.DialogBottomFrame.ClickDone();
            string message = FastDriver.WebDriver.HandleDialogMessage();
            if(message.Contains(@"Error!"))
            {
                string NewWarnDate = Convert.ToDateTime(WarnDate).AddDays(1).ToDateString();
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                FastDriver.TaskDetailsDlg.WarnDate.FASetText(NewWarnDate);
                FastDriver.DialogBottomFrame.ClickDone();
            }
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            Thread.Sleep(4000);
            // 
            FastDriver.FileWorkflow.WaitForScreenToLoad();
            Reports.TestStep = "Select Warning alerts";
            return FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Warning for Task: " + TaskName, "Message", TableAction.Click).Status.ToString();
        }
        #endregion
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

