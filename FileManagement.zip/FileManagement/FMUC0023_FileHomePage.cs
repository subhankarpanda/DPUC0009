﻿using AutoIt;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Text.RegularExpressions;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium;

namespace FileManagement
{

    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class FMUC00023 : MasterTestClass
    {

        #region BAT

        [TestMethod]
        [Description("MF1_00: Modify File Homepage data && MF1_AF10_00: Selecting a Specific Program Type when Business Source has none. && AF1_00: Reset Changes to Original File Homepage Values && AF2_00: Cancel Changes to Homepage && AF3_01: Change Escrow Owning Office when Deposits exist && AF5_01: Remove Escrow Service Type when Deposits exist.")]
        public void FMUC0023_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Modify File Homepage data && MF1_AF10_00: Selecting a Specific Program Type when Business Source has none. && AF1_00: Reset Changes to Original File Homepage Values && AF2_00: Cancel Changes to Homepage && AF3_01: Change Escrow Owning Office when Deposits exist && AF5_01: Remove Escrow Service Type when Deposits exist.";

                #region MF1_00: Modify File Homepage data

                Reports.TestStep = "MF1_00: Modify File Homepage data.";
                Reports.StatusUpdate("MF1_00: Modify File Homepage data.", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                #region Changing existing information on own office(s) section’s officer and assistant
                Reports.TestStep = "Changing exist information on own office(s) section’s officer and assistant.";

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");

                FastDriver.FileHomepage.TitleOwningOfficeOfficer.FASelectItem("QA08, FAST");
                FastDriver.FileHomepage.TitleOwningOfficeAssistant.FASelectItem("QA08, FAST");


                #endregion

                #region "Change exist file underwriter
                Reports.TestStep = "Change exist file underwriter.";
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("New Underwriter");
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Save button.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verifying forUnderwriter comments
                Reports.TestStep = "Verifying forUnderwriter comments";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Underwriter Changed]", "Event", TableAction.Click);
                #endregion


                #endregion

                #region MF1_AF10_00: Selecting a Specific Program Type when Business Source has none
                Reports.TestStep = "MF1_AF10_00: Selecting a Specific Program Type when Business Source has none.";
                Reports.StatusUpdate("MF1_AF10_00: Selecting a Specific Program Type when Business Source has none.", true);

                #region Select the program type from dialog.
                Reports.TestStep = "Select the program type from dialog.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProgramType.FASelectItemBySendingKeys("++View More...");

                Reports.TestStep = "Select a program type.";
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad();
                FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction("Program Name", "PT_DO_NOT_DELETE", "Sel", TableAction.On);

                FastDriver.DialogBottomFrame.ClickDone();

                #endregion

                #region Select the program type from list
                Reports.TestStep = "Select the program type from list.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.SwitchToContentFrame();
                FastDriver.FileHomepage.ProgramType.FASelectItemBySendingKeys("PT_DO_NOT_DELETE");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

                #region Add the product when transaction type is changed
                Reports.TestStep = "Add the product when transaction type is changed.";
                FastDriver.FileHomepage.SwitchToContentFrame();
                FastDriver.FileHomepage.ProductsTable.PerformTableAction(2, 1, TableAction.On);

                Reports.TestStep = "Click on Save button.";
                FastDriver.BottomFrame.Save();

                #endregion

                #region Verify the products and search type after change the program
                Reports.TestStep = "Verify the products and search type after change the program.";
                FastDriver.FileHomepage.SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.ProductsTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.CssSelector, "input[type=\"checkbox\"]").IsDisplayed().ToString(), "Verifying Products Check is displayed");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.SearchType.FAGetText().Contains("BK-Updated PR w/Bankruptcy").ToString(), "Verifying Search Type Select contains: BK-Updated PR w/Bankruptcy");

                #endregion

                #endregion

                #region AF1_00: Reset Changes to Original File Homepage Values
                Reports.TestStep = "AF1_00: Reset Changes to Original File Homepage Values.";
                Reports.StatusUpdate("AF1_00: Reset Changes to Original File Homepage Values.", true);

                string BusinessPartyBusPhoneValueBeforeUpdate = FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Trim();
                string BusinessPartyBusPhoneBeforeUpdate = FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Trim();
                string BusinessPartyEmailAddressBeforeUpdate = FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue().Trim();

                Reports.TestStep = "Reset Changes to Original File Homepage Values.";
                FastDriver.FileHomepage.BusinessPartyEditCont.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessPartyBusPhone.FASetText("(745)451-0848");
                FastDriver.FileHomepage.BusinessPartyBusFax.FASetText("(631)315-4841");
                FastDriver.FileHomepage.BusinessPartyEmailAddress.FASetText("abc@abc.com");

                FastDriver.FileHomepage.DirectedByEditCont.FASetCheckbox(true);
                FastDriver.FileHomepage.DirectedByBusPhone.FASetText("(907)382-8844");
                FastDriver.FileHomepage.DirectedByBusFax.FASetText("(847)582-8844");
                FastDriver.FileHomepage.DirectedByEmailAddress.FASetText("abc@abc.com");

                FastDriver.BottomFrame.Reset();
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Verify the fields after reset.";
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.BusinessPartyEditCont.IsSelected().ToString());
                Support.AreEqual(BusinessPartyBusPhoneValueBeforeUpdate, FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Trim());
                Support.AreEqual(BusinessPartyBusPhoneBeforeUpdate, FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Trim());
                Support.AreEqual(BusinessPartyEmailAddressBeforeUpdate, FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue().Trim());


                #endregion

                #region AF2_00: Cancel Changes to Homepage
                Reports.TestStep = "AF2_00: Cancel Changes to Homepage.";
                Reports.StatusUpdate("AF2_00: Cancel Changes to Homepage.", true);

                Reports.TestStep = "Cancel Changes to Homepage.";

                FastDriver.FileHomepage.BusinessPartyEditCont.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessPartyBusPhone.FASetText("(907)382-8844");
                FastDriver.FileHomepage.BusinessPartyBusFax.FASetText("(847)582-8844");
                FastDriver.FileHomepage.BusinessPartyEmailAddress.FASetText("abc@abc.com");

                FastDriver.FileHomepage.DirectedByEditCont.FASetCheckbox(true);
                FastDriver.FileHomepage.DirectedByBusPhone.FASetText("(907)382-8844");
                FastDriver.FileHomepage.DirectedByBusFax.FASetText("(847)582-8844");
                FastDriver.FileHomepage.DirectedByEmailAddress.FASetText("abc@abc.com");

                Reports.TestStep = "Click on File Homepage.";
                FastDriver.LeftNavigation.ClickHome();

                Reports.TestStep = "Verify the fields after reset.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.FileHomepage.Open();
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.BusinessPartyEditCont.IsSelected().ToString());
                Support.AreEqual(BusinessPartyBusPhoneValueBeforeUpdate, FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Trim());
                Support.AreEqual(BusinessPartyBusPhoneBeforeUpdate, FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Trim());
                Support.AreEqual(BusinessPartyEmailAddressBeforeUpdate, FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue().Trim());
                #endregion

                #region AF3_01: Change Escrow Owning Office when Deposits exist
                Reports.TestStep = "AF3_01: Change Escrow Owning Office when Deposits exist.";
                Reports.StatusUpdate("AF3_01: Change Escrow Owning Office when Deposits exist.", true);

                #region Deposit a Cash on behalf of Buyer
                Reports.TestStep = "Deposit a Cash on behalf of Buyer.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 6;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Initial Deposit";
                DepositData.Description = "Initial Deposit";
                DepositData.ReceivedFrom = "Buyer";
                DepositData.Comments = "Abcd";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Change Escrow Own Office
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify error message when escrow office is Changed
                Reports.TestStep = "Verify error message when escrow office is Changed.";
                FastDriver.DialogBottomFrame.ClickYes();

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("Service File: Current Available Funds is not $0.00. You cannot change the Escrow Owning Office or remove Escrow Service Type.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #endregion

                #region AF5_01: Remove Escrow Service Type when Deposits exist.
                Reports.TestStep = "AF5_01: Remove Escrow Service Type when Deposits exist.";
                Reports.StatusUpdate("AF5_01: Remove Escrow Service Type when Deposits exist.", true);

                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify error message when escrow is removed.";

                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("Service File: Current Available Funds is not $0.00. You cannot change the Escrow Owning Office or remove Escrow Service Type.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("AF3_02: Change Escrow Owning Office when no deposits exist. && AF5_02: Remove Escrow Service Type when no deposits exist")]
        public void FMUC0023_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF3_02: Change Escrow Owning Office when no deposits exist. && AF5_02: Remove Escrow Service Type when no deposits exist";

                #region AF3_02: Change Escrow Owning Office when no deposits exist

                Reports.TestStep = "AF3_02: Change Escrow Owning Office when no deposits exist";
                Reports.StatusUpdate("AF3_02: Change Escrow Owning Office when no deposits exist.", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                #region Change exist information on service section
                Reports.TestStep = "Change exist information on service section.";

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");

                Reports.TestStep = "Wait and Click on Done";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                #region Click on Change OO button and Change Escrow Own Office
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify blank for Escrow own office(s) section’s officer and assistant
                Reports.TestStep = "Verify blank for Escrow own office(s) section’s officer and assistant.";

                FastDriver.DialogBottomFrame.ClickYes();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual("", FastDriver.FileHomepage.EscrowOwningOfficeOfficer.FAGetSelectedItem().Trim());
                Support.AreEqual("", FastDriver.FileHomepage.EscrowOwningOfficeAssistant.FAGetSelectedItem().Trim());

                Reports.TestStep = "Click on Save button.";
                FastDriver.BottomFrame.Save();

                #endregion

                #region Verify changing of Owning Office, Verify the Escrow own office changed message,Verify all the deposits should be removed and Verify the escrow office changed time
                Reports.TestStep = "Verify changing of Owning Office";
                FastDriver.EventTrackingLog.Open();

                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Change Owning Office]", "Event", TableAction.Click);

                Reports.TestStep = "Verify the Escrow own office changed message.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Escrow Owning Office Changed", "Message", TableAction.Click);


                Reports.TestStep = "Verify all the deposits should be removed.";
                FastDriver.ActiveDisbursementSummary.Open(FastDriver.ActiveDisbursementSummary.Note);
                Support.AreEqual(false.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.IsDisplayed().ToString(), "Verify all the deposits should be removed");

                Reports.TestStep = "Verify the escrow office changed time.";
                FastDriver.TermsDatesStatus.Open();

                Support.AreEqual(true.ToString(), FastDriver.TermsDatesStatus.EscrowOwningOfficeChanged.FAGetText().Contains(DateTime.Now.ToString("MM/dd/yyyy")).ToString(), "Verify if EscrowOwningOfficeChanged is set to today");
                #endregion

                #endregion

                #region AF5_02: Remove Escrow Service Type when no deposits exist

                Reports.TestStep = "AF5_02: Remove Escrow Service Type when no deposits exist.";
                Reports.StatusUpdate("AF5_02: Remove Escrow Service Type when no deposits exist.", true);

                #region Click on Change OO button and Remove Escrow Service Type
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verifying for Escrow Service was removed comments and Verify the Escrow Service removed message
                Reports.TestStep = "Verifying for Escrow Service was removed comments";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", "Escrow Service was removed", "Event", TableAction.Click);

                Reports.TestStep = "Verify the Escrow Service removed message.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Escrow Service Removed", "Message", TableAction.Click);
                #endregion

                #region Click on Escrow and Remove Escrow Service Type
                Reports.TestStep = "Click on Escrow.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.Escrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(true);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify all the deposits should be removed
                Reports.TestStep = "Verify all the deposits should be removed.";
                FastDriver.ActiveDisbursementSummary.Open(FastDriver.ActiveDisbursementSummary.Note);
                Support.AreEqual(false.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.IsDisplayed().ToString(), "Verify all the deposits should be removed");
                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("AF4_01: Change Title Owning Office when Fees exist. && REG_FM5509: Change the File Underwriter.")]
        public void FMUC0023_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF4_01: Change Title Owning Office when Fees exist. && REG_FM5509: Change the File Underwriter.";

                #region AF4_01: Change Title Owning Office when Fees exist. && REG_FM5509: Change the File Underwriter.

                Reports.TestStep = "AF4_01: Change Title Owning Office when Fees exist. && REG_FM5509: Change the File Underwriter.";
                Reports.StatusUpdate("AF4_01: Change Title Owning Office when Fees exist. && REG_FM5509: Change the File Underwriter.", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                #region Change exist information on service section
                Reports.TestStep = "Change exist information on service section.";

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");

                Reports.TestStep = "Wait and Click on Done";
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Create a Fee
                Reports.TestStep = "Create a Fee.";

                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.00");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on Fee Transfer Button
                Reports.TestStep = "Click on Fee Transfer Button.";

                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Click OK on Overdraftdialog.";
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();

                #endregion

                #region Change File status and Fee date
                Reports.TestStep = "Change File status and Fee date.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();

                FastDriver.ChangeFileStatusDlg.FileStatus.FASelectItem("Open");
                FastDriver.ChangeFileStatusDlg.FeeDate.FASetText("09-26-2012");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);


                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Click on Change OO button and Change Title Own Office
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Title Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.DialogBottomFrame.ClickYes();

                #endregion

                Reports.TestStep = "Verify error message when Title is removed.";

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("Service File: File has issued fee disbursements. You cannot change the Owning Office or remove Service Type.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                #region Create File
                Reports.TestStep = "Create new Order.";
                OrderDetailsResponse File2 = _CreateBasicFile();
                #endregion

                #region CreateNewLoan
                Reports.TestStep = "Add New Loan.";
                var newLoan = new NewLoanParameters()
                {
                    Type = "",
                    Amount = "5000",
                    GABCode = "HUDLEASE03"
                };
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText(Support.RandomString("ANNANA"));
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion


                Reports.TestStep = "Select a Loan Policy from the table.";

                FastDriver.FileHomepage.AddFileProduct("*ALTA Extended Loan Policy");
                FastDriver.FileHomepage.RemoveAllFileProductsBut("*ALTA Extended Loan Policy");
                FastDriver.FileHomepage.WaitForScreenToLoad();

                if (!FastDriver.RequestPolicyNumber.CanNavigateTo())
                {

                    Reports.TestStep = "Login to AdminSite, Select an Office and Click on New.";

                    _ADMLOGIN();
                    FastDriver.SecuritySelectRegionOffice.Open();
                    FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                    FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices");

                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction(2, "7878", 1, TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();

                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    Reports.TestStep = "Checking for the Request Policy number Checkbox.";
                    FastDriver.OfficeSetupOffice.ANPolicyNumber.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();

                    #region Login
                    _IISLOGIN();
                    #endregion

                    #region Navigate to File
                    Reports.TestStep = "Navigate to file";
                    FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);
                    #endregion
                }


                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>("Home>Order Entry>Request Policy Number");
                FastDriver.RequestPolicyNumber.WaitForScreenToLoad();

                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem("First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem("DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.RequestPolicyNumber.WaitForScreenToLoad();

                FastDriver.RequestPolicyNumber.Table.PerformTableAction(1, "*ALTA Extended Loan Policy", 1, TableAction.Click);
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                FastDriver.RequestPolicyNumber.WaitForScreenToLoad();

                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Add Button.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();

                FastDriver.DocumentRepository.AddDocRep.FAClick();

                Reports.TestStep = "Add Document to Document Repository screen.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument("Both", "Title Reports", "Automation Test Title Report", "");

                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Automation Test Title Report", "Description", TableAction.Click);

                FastDriver.AdHocDocuments.CreateSave.FAClick();

                Reports.TestStep = "Select the Title Report Document and Click on Info Tab.";
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();

                Reports.TestStep = "Enter Document Information for Title report.";

                Support.AreEqual("Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue());
                FastDriver.DocumentInfo.EffectiveDate.FASetText("06-20-2012");
                FastDriver.DocumentInfo.Save.FAClick();

                Reports.TestStep = "Verify Document Information for Title report.";
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                Support.AreEqual("Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue());
                Support.AreEqual("06-20-2012", FastDriver.DocumentInfo.EffectiveDate.FAGetValue());
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();

                FastDriver.DocumentRepository.AddDocRep.FAClick();

                Reports.TestStep = "Add Document to Document Repository screen.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument("Both", "Lender Policy", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "");

                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();

                Reports.TestStep = "Press ALT o+z to Select Finalize link";
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "Name", TableAction.Click);
                FastDriver.DocumentRepository.DocumentsTable.FASendKeys(FAKeys.Alt + "oz");

                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                FastDriver.DocumentPreparation.SwitchToContentFrame();
                FastDriver.DocumentPreparation.WaitForScreenToLoad();

                FastDriver.DocumentPreparation.BuyerNames.FASetText(FastDriver.DocumentPreparation.BuyerNames.FAGetValue().Trim() + " " + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                FastDriver.DocumentRepository.WaitForScreenToLoad();

                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "Name", TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();

                Reports.TestStep = "Click on Policy number button.";
                FastDriver.DocumentRepository.InfoTabAssignPolicyNumberButton.FAClick();
                FastDriver.DocumentRepository.Save.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                Reports.TestStep = "Change Title Own Office.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItemBySendingKeys("JVR Office PR: STEST Off: 1234 (2379)");

                Support.AreEqual("File has AgentNet Policy Numbers. Please void all policy numbers and then you can change Title Owning Office.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("New Underwriter");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);


                Reports.TestStep = "Select the Lender Policy Document and Click on Info Tab.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "Name", TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForInfoTabToLoad();
                Support.AreEqual(false.ToString(), FastDriver.DocumentRepository.InfoTabAssignPolicyNumberButton.IsEnabled().ToString(), "Verify Assign Policy Button is disabled");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                Reports.TestStep = "FM14640_FM14641 Prevent Product Edit if File Has AgentNet Policy Numbers ";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, "*ALTA Extended Loan Policy", 1, TableAction.Off);
                Support.AreEqual("File has an AgentNet policy number for this product. Please void the policy number and then you may remove the product.", FastDriver.WebDriver.HandleDialogMessage());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Kindly execute AF_11 manually as this flow is related to Round Trip testing")]
        public void FMUC0023_BAT00010_PH()
        {
            try
            {
                Reports.TestDescription = "Kindly execute AF_11 manually as this flow is related to Round Trip testing.";
                Reports.TestStep = "Kindly execute AF_11 manually as this flow is related to Round Trip testing";
                Reports.StatusUpdate("Kindly execute AF_11 manually as this flow is related to Round Trip testing.", false);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("AF4_02: Change Title Owning Office when no Fees exist && AF6_02: Remove Title Service Type when no Fees exist.")]
        public void FMUC0023_BAT0011()
        {
            try
            {
                Reports.TestDescription = "AF4_02: Change Title Owning Office when no Fees exist && AF6_02: Remove Title Service Type when no Fees exist..";

                #region AF4_02: Change Title Owning Office when no Fees exist

                Reports.TestStep = "AF4_02: Change Title Owning Office when no Fees exist";
                Reports.StatusUpdate("AF4_02: Change Title Owning Office when no Fees exist", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                #region Click on Change OO button and Change Title Own Office
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Title Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify blank for Escrow own office(s) section’s officer and assistant
                Reports.TestStep = "Verify blank for Escrow own office(s) section’s officer and assistant.";

                FastDriver.DialogBottomFrame.ClickYes();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual("", FastDriver.FileHomepage.TitleOwningOfficeOfficer.FAGetSelectedItem().Trim());
                Support.AreEqual("", FastDriver.FileHomepage.TitleOwningOfficeAssistant.FAGetSelectedItem().Trim());

                FastDriver.FileHomepage.TitleOwningOfficeOfficer.FASelectItem("QA03, FAST");
                FastDriver.FileHomepage.TitleOwningOfficeAssistant.FASelectItem("QA03, FAST");

                Reports.TestStep = "Click on Save button.";
                FastDriver.BottomFrame.Save();
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify changing of Owning Office
                Reports.TestStep = "Verify changing of Owning Office";
                FastDriver.EventTrackingLog.Open();

                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Change Owning Office]", "Event", TableAction.Click);

                Reports.TestStep = "Verify the Title own office changed message.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Title Owning Office Changed", "Message", TableAction.Click);

                Reports.TestStep = "Verify the title office changed time.";
                FastDriver.TermsDatesStatus.Open();

                Support.AreEqual(true.ToString(), FastDriver.TermsDatesStatus.TitleOwningOfficeChanged.FAGetText().Contains(DateTime.Now.ToString("MM/dd/yyyy")).ToString(), "Verify if TitleOwningOfficeChanged is set to today");
                #endregion

                #endregion

                #region AF6_02: Remove Title Service Type when no Fees exist.

                Reports.TestStep = "AF6_02: Remove Title Service Type when no Fees exist.";
                Reports.StatusUpdate("AF6_02: Remove Title Service Type when no Fees exist.", true);

                #region Click on Change OO button and Change Title Own Office
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Title Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verifying for Title Service was removed comments
                Reports.TestStep = "Verifying for Title Service was removed comments";
                FastDriver.EventTrackingLog.Open();

                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", "Title Service was removed", "Event", TableAction.Click);

                Reports.TestStep = "Verify the Title Service removed message.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Title Service Removed", "Message", TableAction.Click);

                #endregion

                #region Click on Change OO button and Click on Title
                Reports.TestStep = "Click on Title.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.Title.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Title Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(true);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                Reports.TestStep = "Click on Save button.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on Change OO button and Click on Title
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Title Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("AF9_00: Select Production Offices.")]
        public void FMUC0023_BAT0013()
        {
            try
            {
                Reports.TestDescription = "AF9_00: Select Production Offices.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                #region Change exist information on production office section.
                Reports.TestStep = "Change exist information on production office section.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveOwningOff.FAClick();

                Reports.TestStep = "Select office.";

                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Office6.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save button.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("AF7_01: Remove Sub Escrow Service Type when deposits exist.")]
        public void FMUC0023_BAT0014()
        {
            try
            {
                Reports.TestDescription = "AF7_01: Remove Sub Escrow Service Type when deposits exist.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicTitleSubEscrowFile();
                #endregion

                #region Deposit a Cash on behalf of Buyer
                Reports.TestStep = "Deposit a Cash on behalf of Buyer.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 6;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Initial Deposit";
                DepositData.Description = "Initial Deposit";
                DepositData.ReceivedFrom = "Buyer";
                DepositData.Comments = "Abcd";

                FastDriver.DepositInEscrow.Open();

                FastDriver.DepositInEscrow.Amount.FASetText(DepositData.Amount.ToString());
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(DepositData.TypeofFunds);
                FastDriver.DepositInEscrow.Representing.FASelectItem(DepositData.Representing);
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(DepositData.ReceivedFrom);
                FastDriver.DepositInEscrow.Description.FASetText(DepositData.Description);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Click on Change OO button and Remove Sub Escrow Service Type
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify error message when sub escrow is removed
                Reports.TestStep = "Verify error message when sub escrow is removed.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("Service File: Current Available Funds is not $0.00. You cannot change the Title Owning Office or remove Sub Escrow Service Type.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("AF7_02: Remove Sub Escrow Service Type when no deposits exist.")]
        public void FMUC0023_BAT0015()
        {
            try
            {
                Reports.TestDescription = "AF7_02: Remove Sub Escrow Service Type when no deposits exist.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicTitleSubEscrowFile();
                #endregion


                #region Click on Change OO button and Remove Sub Escrow Service Type
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verifying for Sub Escrow Service was removed
                Reports.TestStep = "Verifying for Sub Escrow Service was removed comments";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", "Sub Escrow Service was removed", "Event", TableAction.Click);

                Reports.TestStep = "Verify the Sub Escrow Service removed message.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Sub Escrow Service Removed", "Message", TableAction.Click);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region REGRESSION


        [TestMethod]
        [Description("FM4206_FM4627_FM4629_FM5509: Non Editable Sections.")]
        public void FMUC0023_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM4206_FM4627_FM4629_FM5509: Non Editable Sections && FM14762_FM14763_FM14764_FM14765: Prevent View of File Homepage Sections.";

                #region FM4206_FM4627_FM4629_FM5509: Non Editable Sections

                Reports.TestStep = "FM4206_FM4627_FM4629_FM5509: Non Editable Sections.";
                Reports.StatusUpdate("FM4206_FM4627_FM4629_FM5509: Non Editable Sections.", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                #region Validate user will not have the ability to edit the Search Instructions section Terms & Dates,Property,Buyer/Seller, New Lender or Notes section
                Reports.TestStep = "Validate user will not have the ability to edit the Search Instructions section Terms & Dates,Property,Buyer/Seller, New Lender or Notes section.";

                FastDriver.FileHomepage.Open();

                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.FileNumPrefix.IsEnabled().ToString().ToString(), "Verify  FileNumPrefix is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.FileNum.IsEnabled().ToString().ToString(), "Verify FileNum is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.FileNumSufix.IsEnabled().ToString().ToString(), "Verify FileNumSufix is Disabled or Read Only");

                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.AddRemoveInstructions.IsEnabled().ToString().ToString(), "Verify AddRemoveInstructions is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.AddInstruction.IsEnabled().ToString().ToString(), "Verify AddInstruction is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.TermsDatesPrice.IsEnabled().ToString().ToString(), "Verify TermsDatesPrice is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.TermsDatesLiabilityAmnt.IsEnabled().ToString().ToString(), "TermsDatesLiabilityAmnt FileNumSufix is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.TermsDatesNewLoanAmnt.IsEnabled().ToString().ToString(), "Verify TermsDatesNewLoanAmnt is Disabled or Read Only");

                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.TermsDatesNewLoanLiability.IsEnabled().ToString().ToString(), "Verify TermsDatesNewLoanLiability is Disabled or Read Only");

                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.PropertyName.IsEnabled().ToString().ToString(), "Verify PropertyName is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.PropertyType.IsEnabled().ToString().ToString(), "Verify PropertyType is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.PropertyState.IsEnabled().ToString().ToString(), "Verify PropertyState is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.Buyer1Type.IsEnabled().ToString().ToString(), "Verify Buyer1Type is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.Seller1Type.IsEnabled().ToString().ToString(), "Verify Seller1Type is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.BusinessPartyLenderGABcode.IsEnabled().ToString().ToString(), "Verify BusinessPartyLenderGABcode is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.BusinessPartyLenderFind.IsEnabled().ToString().ToString(), "Verify BusinessPartyLenderFind is Disabled or Read Only");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.AssociateBusinessPartyAddtionalRole.IsEnabled().ToString().ToString(), "Verify AssociateBusinessPartyAddtionalRole is Disabled or Read Only");

                #endregion


                #endregion


                Reports.TestStep = "FM14762_FM14763_FM14764_FM14765: Prevent View of File Homepage Sections.";
                Reports.StatusUpdate("FM14762_FM14763_FM14764_FM14765: Prevent View of File Homepage Sections.", true);

                Reports.TestStep = "Check for the access rights for the fastts\fastqa06 employee in ADM side";
                _ADMLOGIN();

                Reports.TestStep = "Select office - QA automation region - Do NOT TOUCH";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Verify IT- LimitedPlus Roles__FMUC0023_REG0001 Role is created if not, create it";

                if (!FastDriver.RoleMaintenanceSummary.VerifyRoleExists(RoleName: "IT- LimitedPlus Roles for FMUC0023_REG0001"))
                {
                    RoleSetupParameters roleParamenters = RoleSetupParameters.GetInstance();
                    roleParamenters.RoleName = "IT- LimitedPlus Roles for FMUC0023_REG0001";
                    roleParamenters.ActivityGroup = "Office File Processing Activity-Limited Group";
                    roleParamenters.SecurityLevel = RoleSecurityLevel.Office;
                    roleParamenters.AvailableActivityRights.Add("Buyer/Seller Only");
                    roleParamenters.AvailableActivityRights.Add("New Loan Only");
                    FastDriver.RoleSetup.CreateRole(roleParamenters);
                }


                Reports.TestStep = @"Check for the Buyer/Seller, Business Party, DirectedBy, New Lender and Associated Party existence for the fastts\fastqa06 employee in IIS side";

                #region Login
                _IISLOGIN();
                #endregion

                _CreateBasicFile();

                FastDriver.FileHomepage.Open();
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.BusinessPartyGABcode.IsDisplayed().ToString(), "Verify BusinessPartyGABcode is displayed");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.DirectedByGABcode.IsDisplayed().ToString(), "Verify DirectedByGABcode is displayed");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.Buyer1FirstName.IsDisplayed().ToString(), "Verify Buyer1FirstName is displayed");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.Seller1FirstName.IsDisplayed().ToString(), "Verify Seller1FirstName is displayed");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.BusinessPartyLenderGABcode.IsDisplayed().ToString(), "Verify BusinessPartyLenderGABcode is displayed");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.AssociateBusinessPartyGABcode.IsDisplayed().ToString(), "Verify AssociateBusinessPartyGABcode is displayed");


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("FM4205: Editable Sections.")]
        public void FMUC0023_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM4205: Editable Sections.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                #region Change the data in FHP
                Reports.TestStep = "Change the data in FHP.";

                FastDriver.FileHomepage.Open();

                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText("HUDASLNDR2");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.FileHomepage.WaitForScreenToLoad();
                
                FastDriver.FileHomepage.DirectedByGABcode.FASetText("HUDASLNDR2");
                FastDriver.FileHomepage.DirectedByName.FASetText("");
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");

                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Bulk Sale");
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Change the data in FHP.";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.AssociateBusinessPartyGABcode.FASetText("HUDASLNDR2");
                FastDriver.FileHomepage.AssociateBusinessPartyFind.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.ProductSummaryTable.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Select Agency Post Closing";
                FastDriver.FileHomepage.AddFileProduct("Agency Post Closing");

                #endregion

                Reports.TestStep = "Select Product Abstract.";
                FastDriver.FileHomepage.AddFileProduct("Abstract");

                Reports.TestStep = "Select Product Agency File Scanning.";
                FastDriver.FileHomepage.AddFileProduct("Agency File Scanning");

                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate the products added.";
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, "Abstract", 2, TableAction.Click);

                Reports.TestStep = "Validate the products added.";
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, "Agency File Scanning", 2, TableAction.Click);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to File Search.";
                FastDriver.FileSearch.NavigateTo();

                FastDriver.FileSearch.Numbers.FASetText("249929");
                FastDriver.FileSearch.Region.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Navigate to File Homepage.";
                FastDriver.FileSearch.WaitForScreenToLoad();
                if (FastDriver.FileSearch.SearchResultTable.IsDisplayed())
                {
                    FailTest("SearchResultTable is not dd stuff happened");


                }
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.OrderSourceExpand.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.ExternalID.IsDisplayed().ToString(), "Verify ExternalID is Displayed");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.OrderSource.IsDisplayed().ToString(), "Verify OrderSource Name is Displayed");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("FM4767_FM4768_FM4769: Add Service Type.")]
        public void FMUC0023_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM4767_FM4768_FM4769: Add Service Type.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicEscrowFile();
                #endregion

                #region Click on Title.
                Reports.TestStep = "Click on Title.";

                FastDriver.FileHomepage.Open();

                FastDriver.FileHomepage.Title.FASetCheckbox(true);

                Reports.TestStep = "Wait and Click on Save";
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                #region Verifying for Tite add on EventTrackingLog and FileWorkFlow
                Reports.TestStep = "Verifying for Title Service added-1";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Title Service Added]", "Event", TableAction.Click);

                Reports.TestStep = "Verifying for Title Service added-2";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", "Title Service was added.", "Comments", TableAction.Click);

                Reports.TestStep = "Validate the source for Program type override";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "File Homepage", "Source", TableAction.Click);

                Reports.TestStep = "Verify the Title Service added message.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Title Service Added", "Message", TableAction.Click);
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM6066_FM6068: Add Sub Escrow Service.")]
        public void FMUC0023_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM6066_FM6068: Add Sub Escrow Service.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicEscrowFile();
                #endregion

                #region Click on Title.
                Reports.TestStep = "Click on Title.";

                FastDriver.FileHomepage.Open();

                FastDriver.FileHomepage.SubEscrow.FASetCheckbox(true);

                Reports.TestStep = "Wait and Click on Save";
                FastDriver.BottomFrame.Save();

                #endregion

                Reports.TestStep = "To verify Proration link doesn't exist.";
                FastDriver.LeftNavigation.CanNavigateTo<EscrowChargeSetup>("Home>System Maintenance>Escrow Charge Processes");

                Support.AreEqual(false.ToString(), FastDriver.LeftNavigation.Proration.IsDisplayed().ToString());

                Reports.TestStep = "Validate the Proration section is disabled for Subescrow file.";
                FastDriver.UtilityDetail.Open();

                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.CreditSeller.IsEnabled().ToString(), "Verify  CreditSeller is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.DayofClosePaidbySeller.IsEnabled().ToString(), "Verify DayofClosePaidbySeller is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.ProrationAmount.IsEnabled().ToString(), "Verify ProrationAmount is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.FromDate.IsEnabled().ToString(), "Verify FromDate is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.fromInclusive.IsEnabled().ToString(), "Verify fromInclusive is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.fromProrateDate.IsEnabled().ToString(), "Verify fromProrateDate is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.BasedOn.IsEnabled().ToString(), "Verify BasedOn is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.Per.IsEnabled().ToString(), "Verify Per is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.ToDate.IsEnabled().ToString(), "Verify ToDate is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.toInclusive.IsEnabled().ToString(), "Verify toInclusive is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.UtilityDetail.toProrateDate.IsEnabled().ToString(), "Verify toProrateDate is Readonly or disabled");

                Reports.TestStep = "Validate that Proration fields are disabled.";
                FastDriver.HomeownerAssociation.Open();
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationSellerCredit.IsEnabled().ToString(), "Verify ProrationSellerCredit is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.DayofClosePaidbySeller.IsEnabled().ToString(), "Verify DayofClosePaidbySeller is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationAmount.IsEnabled().ToString(), "Verify ProrationAmount is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.FromDate.IsEnabled().ToString(), "Verify FromDate is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.fromInclusive.IsEnabled().ToString(), "Verify fromInclusive is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.fromProrate.IsEnabled().ToString(), "Verify fromProrate is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.BasedOn.IsEnabled().ToString(), "Verify BasedOn is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.Per.IsEnabled().ToString(), "Verify Per is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ToDate.IsEnabled().ToString(), "Verify ToDate is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.toInclusive.IsEnabled().ToString(), "Verify toInclusive is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.toProrateDate.IsEnabled().ToString(), "VerifytoProrateDate  is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationDescription.IsEnabled().ToString(), "Verify ProrationDescription is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationBuyerCharge.IsEnabled().ToString(), "Verify ProrationBuyerCharge is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationBuyerCredit.IsEnabled().ToString(), "Verify ProrationBuyerCredit is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationSellerCharge.IsEnabled().ToString(), "Verify ProrationSellerCharge  is Readonly or disabled");
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationSellerCredit.IsEnabled().ToString(), "Verify ProrationSellerCredit is Readonly or disabled");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM6066_FM6068: Add Sub Escrow Service.")]
        public void FMUC0023_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM10518: Calculated Rates for Service Type.";

                #region Login
                _ADMLOGIN();
                #endregion

                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);


                FastDriver.FeeSetup.CheckSubjectToCalculationFee("Eagle Lender Policy - 1", "Title - Lenders Policy", "CA - All", true);
                FastDriver.FeeSetup.CheckSubjectToCalculationFee("Record Deed", "Recording Fee - Deed", "CA - All", true);


                #region Login
                _IISLOGIN();
                #endregion

                #region Create File and Verify Values
                _CreateBasicFile();

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";

                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem());
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetAttribute("value"));
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetAttribute("value"));
                Support.AreEqual(@"Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetAttribute("value"));
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetAttribute("value"));
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetAttribute("value"));
                Support.AreEqual(@"9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetAttribute("value"));
                Support.AreEqual(@"Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetAttribute("value"));
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetAttribute("value"));
                Support.AreEqual(@"CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem());
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetAttribute("value"));
                //Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                //Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                //Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                //Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                //Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                //Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                //Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem());
                //Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetAttribute("value"));
                //Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetAttribute("value"));
                //Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetAttribute("value"));
                //Support.AreEqual(@"Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem());
                //Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetAttribute("value"));
                //Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetAttribute("value"));
                //Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem());
                //Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetAttribute("value"));
                //Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetAttribute("value"));
                //Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetAttribute("value"));
                //Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetAttribute("value"));

                #endregion

                Reports.TestStep = "Add new Loan.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();

                Reports.TestStep = "Add Endorsement Fee.";
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();

                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction(2, "[ALTA 3-06] Zoning - unimproved land", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("2");

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.Next.FAClick();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAnswersTable);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select View More option.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Eagle Lender Policy - 1");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.ClickOnFeeResultCheckbox(0);

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select View More option for the last fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(FastDriver.CalculateFees.SummaryTable.GetRowCount(), 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select mortgage fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem(@"Recording Fee - Deed");
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Record Deed");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Descriptions For the Fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                int SummaryTableRowCount = FastDriver.CalculateFees.SummaryTable.GetRowCount();

                if (SummaryTableRowCount >= 3)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 4, TableAction.SelectItemByIndex, "1");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 5, TableAction.SelectItem, "Seller");
                }

                if (SummaryTableRowCount >= 4)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(4, 4, TableAction.SelectItem, "Record Deed");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(4, 5, TableAction.SelectItem, "Seller");
                }

                if (SummaryTableRowCount >= 5)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(5, 4, TableAction.SelectItem, "Record Deed");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(5, 5, TableAction.SelectItem, "Seller");
                }

                if (SummaryTableRowCount >= 6)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(6, 4, TableAction.SelectItem, "Record Deed");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(6, 5, TableAction.SelectItem, "Seller");
                }

                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5520_FM5500_FM5502: Prevent Owning Office changes based on Invoice Status.")]
        public void FMUC0023_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM5520_FM5500_FM5502: Prevent Owning Office changes based on Invoice Status.";

                #region Login
                _ADMLOGIN();
                #endregion

                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);


                #region Click on Title.

                #endregion

                FastDriver.FeeSetup.CheckSubjectToCalculationFee("New Home Rate (Title Only)", "Title - Owners Policy", "All", false);


                #region Login
                _IISLOGIN();
                #endregion


                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                #region Create a Fee
                Reports.TestStep = "Create a Fee.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.00");
                FastDriver.BottomFrame.Done();

                #endregion

                Reports.TestStep = "Click on Estimate.";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.Estimate.FAClick();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Chang Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Reports.TestStep = "Verify error message when invoice is finalized [US#686119 - TC#775242: System shall not allow changing owing office if file has valid Invoice]";
                Support.AreEqual("Service File: You cannot Change the Owning Office or Remove a service type when the file contains invoices in statuses Estimated, Estimated Adjusted, Final and Final Adjusted.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Uncheck the first fee.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.Off);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Chang Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Reports.TestStep = "Verify error message when invoice is finalized.";
                Support.AreEqual("Service File: You cannot Change the Owning Office or Remove a service type when the file contains invoices in statuses Estimated, Estimated Adjusted, Final and Final Adjusted.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "check the first fee.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Set on final button in Invoice screen.";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Click on Change OO button.";

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Chang Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Reports.TestStep = "Verify error message when invoice is finalized.";
                Support.AreEqual("Service File: You cannot Change the Owning Office or Remove a service type when the file contains invoices in statuses Estimated, Estimated Adjusted, Final and Final Adjusted.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();


                Reports.TestStep = "Cancel the Invoice.";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);

                FastDriver.InvoiceFees.Cancel.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Chang Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();
                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Reports.TestStep = "Validate Own office has changed.";
                Support.AreEqual("JVR Office PR: STEST Off: 1234 (2379)", FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify the Escrow own office changed message.";
                FastDriver.FileWorkflow.Open();

                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Escrow Owning Office Changed", "Message", TableAction.Click);

                Reports.TestStep = "Verify changing of Owning Office";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Change Owning Office]", "Event", TableAction.Click);

                Reports.TestStep = "Validate the source for Program type override";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "File Homepage", "Source", TableAction.Click);

                Reports.TestStep = "Verify the Event Log for File created(User)";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("User", @"FASTTS\FASTQA07", "User", TableAction.Click);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5520_FM5500_FM5502: Prevent Owning Office changes based on Invoice Status.")]
        public void FMUC0023_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM5515: Use File Number Prefix and Suffix from EOO.";


                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                Reports.TestStep = "FM9715: Validate the Filenum Prefix and suffix.";
                FastDriver.FileHomepage.Open();
                if (FastDriver.FileHomepage.FileNumPrefix.FAGetValue() == "QAPF")
                {
                    Support.AreEqual("QAPF", FastDriver.FileHomepage.FileNumPrefix.FAGetValue().Trim());
                }
                else {
                    Support.AreEqual("QAFDS", FastDriver.FileHomepage.FileNumPrefix.FAGetValue().Trim());
                }

                if (FastDriver.FileHomepage.FileNumSufix.FAGetValue() == "QASF")
                {
                    Support.AreEqual("QASF", FastDriver.FileHomepage.FileNumSufix.FAGetValue().Trim());
                }
                else {
                    Support.AreEqual("ABCDE", FastDriver.FileHomepage.FileNumSufix.FAGetValue().Trim());
                }

             

                Reports.TestStep = "Create Order with different TOO and EOO.";
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText("123");
                FastDriver.FileHomepage.BussinessPartyFind.Click();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Pull Program type based on Given data";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount.FASetText("5,000.00" + FAKeys.Tab);
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("5,000.00" + FAKeys.Tab);
                FastDriver.QuickFileEntry.SearchType.FASelectItemBySendingKeys("++View More...");

                FastDriver.SearchTypeDialogDlg.WaitForScreenToLoad();
                Reports.TestStep = "Selecting first Search type from Table and getting its Value.";

                FastDriver.SearchTypeDialogDlg.SearchTypeTable.PerformTableAction(1, 1, TableAction.Click);
                string SelectedSearchType = FastDriver.SearchTypeDialogDlg.SearchTypeTable.PerformTableAction(1, 2, TableAction.GetText).Message.Trim();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Support.AreEqual(SelectedSearchType, FastDriver.QuickFileEntry.SearchType.FAGetSelectedItem().Trim(), "Verify Search type is selected");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("AZ");
                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("APACHE");


                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);

                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                switch (FastDriver.FileHomepage.ProgramType.FAGetSelectedItem()) {
                    case "GAPCOVERAGE_Program":
                        Support.AreEqual("GAPCOVERAGE_Program", FastDriver.FileHomepage.ProgramType.FAGetSelectedItem().Trim(), "Verify Program type is selected");
                        break;
                    case "PT_DO_NOT_DELETE":
                        Support.AreEqual("PT_DO_NOT_DELETE", FastDriver.FileHomepage.ProgramType.FAGetSelectedItem().Trim(), "Verify Program type is selected");
                        break;
                    default:
                        Support.AreEqual("", FastDriver.FileHomepage.ProgramType.FAGetSelectedItem().Trim(), "Verify Program type is selected");
                        break;
                }
              

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5516: Use File Number Prefix and Suffix from TOO && FM5518: Populate File Number Prefix and Suffix Values from New EOO.")]
        public void FMUC0023_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM5516: Use File Number Prefix and Suffix from TOO && FM5518: Populate File Number Prefix and Suffix Values from New EOO.";

                #region FM5516: Use File Number Prefix and Suffix from TOO
                Reports.TestStep = "FM5516: Use File Number Prefix and Suffix from TOO.";
                Reports.StatusUpdate("FM5516: Use File Number Prefix and Suffix from TOO.", true);


                #region Login
                _IISLOGIN();
                #endregion

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Playback.Wait(5000);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Create Title Order to verify Filenum Prefix and suffix.";

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("AZ");
                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("APACHE");

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(false);

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);

                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Filenum Prefix and suffix is that of TOO only when Escrow office does not have any Offices in ADM.";

                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.FileHomepage.FileNumPrefix.FAGetValue().Trim(), @"JVRP|HGFD").ToString(),"Verifying FileNumPrefix");

                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.FileHomepage.FileNumSufix.FAGetValue().Trim(), @"JVRS|ZXCV").ToString(), "Verifying FileNumSufix");

                #endregion

                #region FM5518: Populate File Number Prefix and Suffix Values from New EOO
                Reports.TestStep = "FM5518: Populate File Number Prefix and Suffix Values from New EOO.";
                Reports.StatusUpdate("FM5518: Populate File Number Prefix and Suffix Values from New EOO.", true);

                Reports.TestStep = "Click on Escrow and select different EOO.";
                FastDriver.FileHomepage.Escrow.FASetCheckbox(true);

                FastDriver.FileHomepage.EscrowOwningOfficeOffice.FASelectItem("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878 (1487)");
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Filenum Prefix and suffix.";

                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.FileHomepage.FileNumPrefix.FAGetValue().Trim(), @"QAPF|QAFDS").ToString(), "Verifying FileNumPrefix");
                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.FileHomepage.FileNumSufix.FAGetValue().Trim(), @"QASF|ABCDE").ToString(), "Verifying FileNumSufix");
       
                #endregion

                #region FM5519  : Change File Number Prefix and Suffix Values from EOO to TOO Values
                Reports.TestStep = "FM5519  : Change File Number Prefix and Suffix Values from EOO to TOO Values.";
                Reports.StatusUpdate("FM5519  : Change File Number Prefix and Suffix Values from EOO to TOO Values.", true);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Filenum Prefix and suffix is that of TOO.";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.FileHomepage.FileNumPrefix.FAGetValue().Trim(), @"JVRP|HGFD").ToString(), "Verifying FileNumPrefix");
                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.FileHomepage.FileNumSufix.FAGetValue().Trim(), @"JVRS|ZXCV").ToString(), "Verifying FileNumSufix");

                #endregion



            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5514: Update File Number Prefix and Suffix.")]
        public void FMUC0023_REG0011()
        {
            try
            {
                Reports.TestDescription = "FM5514: Update File Number Prefix and Suffix.";

                string RandomFileNumber = Support.RandomString("AANNNAAA");

                #region Login
                _IISLOGIN();
                #endregion

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create order with Manual file number.";

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(false);

                FastDriver.QuickFileEntry.FileNumPrefix.FASetText("HAF");
                FastDriver.QuickFileEntry.FileNum.FASetText(RandomFileNumber);
                FastDriver.QuickFileEntry.FileNumSufix.FASetText("HAF");

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("ALAMEDA");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Filenum.";

                Support.AreEqual("HAF", FastDriver.FileHomepage.FileNumPrefix.FAGetValue().Trim());
                Support.AreEqual("HAF", FastDriver.FileHomepage.FileNumSufix.FAGetValue().Trim());
                Support.AreEqual(RandomFileNumber, FastDriver.FileHomepage.FileNum.FAGetValue().Trim());

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Filenum.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("HAF", FastDriver.FileHomepage.FileNumPrefix.FAGetValue().Trim());
                Support.AreEqual("HAF", FastDriver.FileHomepage.FileNumSufix.FAGetValue().Trim());
                Support.AreEqual(RandomFileNumber, FastDriver.FileHomepage.FileNum.FAGetValue().Trim());



            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5499_001: Require Zero Current Available Funds for EOO Change(Deposit).")]
        public void FMUC0023_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM5499_001: Require Zero Current Available Funds for EOO Change(Deposit).";

                string RandomFileNumber = Support.RandomString("AANNNAAA");

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion

                #region Deposit a Cash
                Reports.TestStep = "Deposit a Cash.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00f;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();

                Reports.TestStep = "Verify error message when escrow is removed.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("Service File: Current Available Funds is not $0.00. You cannot change the Escrow Owning Office or remove Escrow Service Type.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());

                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5499_002: Require Zero Current Available Funds for EOO Change(File status).")]
        public void FMUC0023_REG0013()
        {
            try
            {
                Reports.TestDescription = "FM5499_002: Require Zero Current Available Funds for EOO Change(File status).";

                string RandomFileNumber = Support.RandomString("AANNNAAA");

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion

                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Open in error.";
                FastDriver.TermsDatesStatus.Open();

                Reports.TestStep = "Updating the Status date.";
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString());
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().Trim());
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open In Error");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Click on ChangeO/O when file status is not open [US#686119 - TC#775244]:- System shall not allow changing owing office if file status is other than Open]";

                Support.AreEqual("File status should be Open in order to change the Owning Office.", FastDriver.WebDriver.HandleDialogMessage());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5499_003: Require Zero Current Available Funds for EOO Change(Disbursement)(not able to recognize both warning together).")]
        public void FMUC0023_REG0014()
        {
            try
            {
                Reports.TestDescription = "FM5499_003: Require Zero Current Available Funds for EOO Change(Disbursement)(not able to recognize both warning together).";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion

                #region Create a Fee
                Reports.TestStep = "Create a Fee.";

                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.00");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Deposit a Cash
                Reports.TestStep = "Deposit a Cash.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00f;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                Reports.TestStep = "Verify pending fee transfer.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);

                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to TDS screen and Change filestatusto open.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open");
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit amount.";
                FastDriver.DepositReceiptHistory.Open();
                Support.AreEqual("Sanity Deposit In Escrow", FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction("Amount", "10.00", "Description", TableAction.GetText).Message.Trim());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();

                Reports.TestStep = "Verify error message when escrow is removed.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.IsDisplayed().ToString());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5501: Change to Previous Escrow Owning Office.")]
        public void FMUC0023_REG0015()
        {
            try
            {
                Reports.TestDescription = "FM5501: Change to Previous Escrow Owning Office.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Own office has changed.";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual("JVR Office PR: STEST Off: 1234 (2379)", FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetSelectedItem().Trim());

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "To change the escrow own office back to Automation Region.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878 (1487)");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.DialogBottomFrame.ClickYes();
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Escrow Own office is Automation Office.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878 (1487)", FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetSelectedItem().Trim());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5505_001: Change Title Owning Office(File status).")]
        public void FMUC0023_REG0016()
        {
            try
            {
                Reports.TestDescription = "FM5505_001: Change Title Owning Office(File status).";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion

                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Open in error.";
                FastDriver.TermsDatesStatus.Open();

                Reports.TestStep = "Updating the Status date.";
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().Trim());

                FastDriver.TermsDatesStatus.Status.FASelectItem("Open In Error");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Click on ChangeO/O when file status is not open.";
                Support.AreEqual("File status should be Open in order to change the Owning Office.", FastDriver.WebDriver.HandleDialogMessage());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5505_002: Change Title Owning Office(Disbursement)(not able to recognize both warning together).")]
        public void FMUC0023_REG0017()
        {
            try
            {
                Reports.TestDescription = "FM5505_002: Change Title Owning Office(Disbursement)(not able to recognize both warning together).";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion

                #region Deposit a Cash
                Reports.TestStep = "Deposit a Cash.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00f;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Create a Fee
                Reports.TestStep = "Create a Fee.";

                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.00");
                FastDriver.BottomFrame.Done();

                #endregion

                Reports.TestStep = "Verify pending fee transfer.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);

                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Closed");

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to TDS screen and Change filestatusto open.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open");
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit amount.";
                FastDriver.DepositReceiptHistory.Open();
                Support.AreEqual("Sanity Deposit In Escrow", FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction("Amount", "10.00", "Description", TableAction.GetText).Message.Trim());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();

                Reports.TestStep = "Verify error message when Title is removed.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Contains("Service File: File has issued fee disbursements. You cannot change the Owning Office or remove Service Type.").ToString(), "Verify Service File: File has issued fee disbursements. You cannot change the Owning Office or remove Service Type. error is shown");


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5506: Change to Previous Title Owning Office.")]
        public void FMUC0023_REG0018()
        {
            try
            {
                Reports.TestDescription = "FM5506: Change to Previous Title Owning Office.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion


                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Title Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Title Own office is JVR Office.";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual("JVR Office PR: STEST Off: 1234 (2379)", FastDriver.FileHomepage.TitleOwningOfficeOffice.FAGetSelectedItem().Trim());

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "To change the title own office back to Automation Region.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878 (1487)");

                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Validate Title Own office is Automation Office.";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878 (1487)", FastDriver.FileHomepage.TitleOwningOfficeOffice.FAGetSelectedItem().Trim());



            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5507: Replace File Underwriter with new TOO Underwriter.")]
        public void FMUC0023_REG0019()
        {
            try
            {
                Reports.TestDescription = "FM5507: Replace File Underwriter with new TOO Underwriter.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion


                Reports.TestStep = "Validate Title Own office Underwriter.";
                FastDriver.FileHomepage.Open();

                Support.AreEqual("First American Title Insurance Company", FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FAGetSelectedItem().Trim());

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Title Own Office to Automation Office Test PR: STEST Off: 9879 (2578).";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("Automation Office Test PR: STEST Off: 9879 (2578)");

                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();

                Reports.TestStep = "Validate Underwriter is changed when the title office is changed.";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual("New Underwriter", FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FAGetSelectedItem().Trim());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5508: Require One File Service Type.")]
        public void FMUC0023_REG0020()
        {
            try
            {
                Reports.TestDescription = "FM5508: Require One File Service Type.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion


                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Verify that Escrow and Title checkbox are enabled.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.IsSelected().ToString(), "Verify Escrow is checked");
                Support.AreEqual(true.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.Title.IsSelected().ToString(), "Verify Title is checked");

                Reports.TestStep = "Remove Title Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                Playback.Wait(5000);

                Reports.TestStep = "Verify that Escrow and Sub escrow is disabled.";
                Support.AreEqual(true.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.Title.IsEnabled().ToString(), "Verify Title is enabled");
                Support.AreEqual(false.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.IsEnabled().ToString(), "Verify Escrow is not enabled");
                Support.AreEqual(false.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.IsEnabled().ToString(), "Verify SubEscrow is not enabled");

                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Create Title Order to verify Filenum Prefix and suffix.";

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(false);

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");

                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");


                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate Title is disabled.";
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.Title.IsEnabled().ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5511_FM5510: Create Service Removed Event.")]
        public void FMUC0023_REG0021()
        {
            try
            {
                Reports.TestDescription = "FM5511_FM5510: Create Service Removed Event.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion


                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);

                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the Escrow Service removed message.";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", "Escrow Service was removed", "Comments", TableAction.Click);

                Reports.TestStep = "Validate the source for Program type override";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "File Homepage", "Source", TableAction.Click);


                Reports.TestStep = "Verifying for Esrow  Service removed";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Service Removed]", "Event", TableAction.Click);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5512: Remove File Underwriter with Title Service.")]
        public void FMUC0023_REG0022()
        {
            try
            {
                Reports.TestDescription = "FM5512: Remove File Underwriter with Title Service.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file and navigate to the created file";
                var FileData = _CreateBasicFile();

                #endregion

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Title Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);

                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Underwriter is removed on removal of title service.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.IsDisplayed().ToString());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM6074_FM6078_FM6079_ER9: Remove Sub Escrow Service.")]
        public void FMUC0023_REG0023()
        {
            try
            {
                Reports.TestDescription = "FM6074_FM6078_FM6079_ER9: Remove Sub Escrow Service.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic Title SubEscrow File and navigate to the created file";

                var FileData = _CreateBasicTitleSubEscrowFile();

                #endregion

                #region Deposit a Cash on behalf of Buyer
                Reports.TestStep = "Deposit a Cash on behalf of Buyer.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();

                FastDriver.DepositInEscrow.Amount.FASetText(DepositData.Amount.ToString());
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(DepositData.TypeofFunds);
                FastDriver.DepositInEscrow.Representing.FASelectItem(DepositData.Representing);
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(DepositData.ReceivedFrom);
                FastDriver.DepositInEscrow.Description.FASetText(DepositData.Description);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);

                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify error message when sub escrow is removed.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("Service File: Current Available Funds is not $0.00. You cannot change the Title Owning Office or remove Sub Escrow Service Type.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());

                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit amount.";
                FastDriver.DepositReceiptHistory.Open();

                Support.AreEqual("Sanity Deposit In Escrow", FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction("Amount", "10.00", "Description", TableAction.GetText).Message.Trim(), "Verify Deposit Activity Table contains Sanity Deposit In Escrow");
                FastDriver.DepositReceiptHistory.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("cancelling the deposit");
                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);

                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to Deposit in Escrow for a title only file..";
                FastDriver.DepositOutsideEscrow.Open();
                FastDriver.LeftNavigation.ClickDepositInEscrow();

                Reports.TestStep = "Click on Deposit in Escrow for a title only file.";
                Support.AreEqual("File must have 'Escrow' or 'Sub Escrow' Service Type in order to record a deposit.", FastDriver.WebDriver.HandleDialogMessage());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM6075_FM6077: Remove Sub Escrow Service to Convert File Charges/Credits to.")]
        public void FMUC0023_REG0024()
        {
            try
            {
                Reports.TestDescription = "FM6075_FM6077: Remove Sub Escrow Service to Convert File Charges/Credits to.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic Escrow SubEscrow File and navigate to the created file";
                var FileData = _CreateBasicEscrowSubEscrowFile();

                #endregion

                Reports.TestStep = "To verify HUD-1 link doesn't exist for a sub escrow file.";
                FastDriver.LeftNavigation.Navigate<LeftNavigation>("Home>Order Entry>Escrow Closing");
                Support.AreEqual(false.ToString(), FastDriver.LeftNavigation.HUD1Statement.IsDisplayed().ToString());

                #region Create a Fee
                Reports.TestStep = "Enter first fee in Title and escrow.";

                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                #endregion

                Reports.TestStep = "Validate File balance summary Funds Due for a Sub Escrow file.";
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.FAGetText().Contains("4.98").ToString());

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);

                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<LeftNavigation>("Home>Order Entry>Escrow Closing");

                if (AutoConfig.FormType.ToUpper() == "CD")
                {
                    Reports.TestStep = "To verify HUD-1 link doesn't exist for a non sub escrow file.";
                    Support.AreEqual(false.ToString(), FastDriver.LeftNavigation.HUD1Statement.IsDisplayed().ToString());
                }
                else
                {
                    Reports.TestStep = "To verify HUD-1 link exists for a non sub escrow file.";
                    Support.AreEqual(true.ToString(), FastDriver.LeftNavigation.HUD1Statement.IsDisplayed().ToString());
                }

                Reports.TestStep = "Validate File balance summary Funds Due after remove Sub Escrow.";
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.FAGetText().Contains("1.99").ToString(), "Verify Projected Table Contains 1.99");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.FAGetText().Contains("2.99").ToString(), "Verify Projected Table Contains 2.99");


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM6081: Prevent Removal of Title Service from Sub Escrow File.")]
        public void FMUC0023_REG0025()
        {
            try
            {
                Reports.TestDescription = "FM6081: Prevent Removal of Title Service from Sub Escrow File.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic Title SubEscrow File and navigate to the created file";
                var FileData = _CreateBasicTitleSubEscrowFile();

                #endregion

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Verify that Title checkbox is disabled for Title/Sub escrow file.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.Title.IsEnabled().ToString());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM6082: Prevent Removal of Escrow Service from Sub Escrow File.")]
        public void FMUC0023_REG0026()
        {
            try
            {
                Reports.TestDescription = "FM6082: Prevent Removal of Escrow Service from Sub Escrow File.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic Title SubEscrow File and navigate to the created file";

                var FileData = _CreateBasicTitleSubEscrowFile();

                #endregion

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Verify that Escrow checkbox is disabled for Escrow/Sub escrow file.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.IsEnabled().ToString());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM8022_FM8021: Change Trans Type to Refi/Loan: No Seller Charges Issued.")]
        public void FMUC0023_REG0027()
        {
            try
            {
                Reports.TestDescription = "FM8022_FM8021: Change Trans Type to Refi/Loan: No Seller Charges Issued.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic Title SubEscrow File and navigate to the created file";

                var FileData = _CreateBasicTitleSubEscrowFile();

                #endregion

                #region Create a Fee
                Reports.TestStep = "Create a Fee.";

                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                #endregion

                Reports.TestStep = "Change the Transaction type to Construction Disbursement.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Construction Disbursement");

                Reports.TestStep = "Change the transaction type to Construction Disbursement. Click on Cancel.";
                Support.AreEqual("The sale price and all seller charges and credits will be removed, Continue?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));

                Reports.TestStep = "Change the Transaction type to Equity Loan .";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Equity Loan");

                Reports.TestStep = "Change the transaction type to Equity Loan. Click on Cancel.";
                Support.AreEqual("The sale price and all seller charges and credits will be removed, Continue?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));

                Reports.TestStep = "Chang the Transaction type to Refinance.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("R");

                Reports.TestStep = "Change the transaction type to Refinance. Click on OK.";
                Support.AreEqual("The sale price and all seller charges and credits will be removed, Continue?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Wait and Click on Save";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate seller charge does not exists in a Refinance file.";
                FastDriver.FileFees.Open();
                Support.AreEqual(false.ToString(), FastDriver.FileFees.Sellercharge.IsDisplayed().ToString());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM8031: Change Trans Type to Refi/Loan: Seller Charges Issued.")]
        public void FMUC0023_REG0028()
        {
            try
            {
                Reports.TestDescription = "FM8031: Change Trans Type to Refi/Loan: Seller Charges Issued.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic file";

                var FileData = _CreateBasicFile();

                #endregion

                #region Deposit a Cash
                Reports.TestStep = "Deposit a cash.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Create a Fee
                Reports.TestStep = "Create a Fee.";

                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                #endregion

                Reports.TestStep = "Verify pending fee transfer.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);

                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Change the Transaction type to Construction Disbursement.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Construction Disbursement");

                Reports.TestStep = "Issue fee and change transaction type Refinance.";
                Support.AreEqual("File has issued seller charges.Void or cancel these disbursements and then you can change the Transaction Type.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Change the Transaction type to Equity Loan .";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Equity Loan");

                Reports.TestStep = "Issue fee and change transaction type Refinance.";
                Support.AreEqual("File has issued seller charges.Void or cancel these disbursements and then you can change the Transaction Type.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Change the Transaction type to Refinance.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("R");

                Reports.TestStep = "Issue fee and change transaction type Refinance.";
                Support.AreEqual("File has issued seller charges.Void or cancel these disbursements and then you can change the Transaction Type.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Wait and Click on Save";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM4770_FM4771_FM4771_FM7069: Add/Remove Production Offices.")]
        public void FMUC0023_REG0029()
        {
            try
            {
                Reports.TestDescription = "FM4770_FM4771_FM4771_FM7069: Add/Remove Production Offices.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic file";

                var FileData = _CreateBasicFile();

                #endregion

                Reports.TestStep = "Chang exist information on production office section.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveOwningOff.FAClick();

                Reports.TestStep = "Select different region.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Region.FASelectItem("QA-Canada");
                Playback.Wait(5000);
                FastDriver.OfficeSelectionDlg.WaitCreation(FastDriver.OfficeSelectionDlg.Office1);

                FastDriver.OfficeSelectionDlg.Office1.GiveFocus();
                FastDriver.OfficeSelectionDlg.Office1.FASendKeys(FAKeys.Space);

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate that the Production office added from another region.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TitleProdOfficeTable.PerformTableAction("Office Name", "QA-Canada Test Region -- QA-Canada (2162)", "Office Name", TableAction.Click);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Verifying for Production office added-Event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Production Office Added]", "Event", TableAction.Click);

                Reports.TestStep = "Verifying for Production office added-Comment";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", "Production Office Added: QA-Canada Test Region -- QA-Canada (2162)", "Comments", TableAction.Click);

                Reports.TestStep = "Verify the Event Log for File created(Source)";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "FAST Application", "Source", TableAction.Click);

                Reports.TestStep = "Verify the Event Log for File created(User)";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("User", AutoConfig.UserName.ToUpper(), "User", TableAction.Click);

                Reports.TestStep = "Change exist information on production office section.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveOwningOff.FAClick();

                Reports.TestStep = "Select different region and uncheck the office.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Region.FASelectItem("QA-Canada");
                Playback.Wait(5000);
                FastDriver.OfficeSelectionDlg.WaitCreation(FastDriver.OfficeSelectionDlg.Office1);

                bool WasOfficeDeleted = FastDriver.OfficeSelectionDlg.Office1.IsSelected();
                FastDriver.OfficeSelectionDlg.Office1.GiveFocus();
                FastDriver.OfficeSelectionDlg.Office1.FASendKeys(FAKeys.Space);

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Save();

                if (!WasOfficeDeleted)
                {
                    Reports.TestStep = "Verifying for Production office Status-Event";
                    FastDriver.EventTrackingLog.Open();
                    FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Production Office Added]", "Event", TableAction.Click);

                    FastDriver.FileHomepage.Open();
                    FastDriver.FileHomepage.AddRemoveOwningOff.FAClick();

                    Reports.TestStep = "Select different region and uncheck the office.";

                    Reports.TestStep = "Select different region.";
                    FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                    FastDriver.OfficeSelectionDlg.Region.FASelectItem("QA-Canada");
                    FastDriver.OfficeSelectionDlg.Office1.FASetCheckbox(false);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                    FastDriver.BottomFrame.Save();

                    Reports.TestStep = "Verifying for Production office removed-Event";
                    FastDriver.EventTrackingLog.Open();
                    FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Production Office Deleted]", "Event", TableAction.Click);

                    Reports.TestStep = "Verifying for Production office removed-Comment";
                    FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", "Production Office Deleted: QA-Canada Test Region -- QA-Canada (2162)", "Comments", TableAction.Click);

                    Reports.TestStep = "Verify the Event Log for File created(Source)";
                    FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "FAST Application", "Source", TableAction.Click);

                    Reports.TestStep = "Verify the Event Log for File created(User)";
                    FastDriver.EventTrackingLog.EventTable.PerformTableAction("User", AutoConfig.UserName.ToUpper(), "User", TableAction.Click);

                }


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM6779: Default Production Offices from Office Setup.")]
        public void FMUC0023_REG0030()
        {
            try
            {
                Reports.TestDescription = "FM6779: Default Production Offices from Office Setup.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file";

                var FileData = _CreateBasicFile();

                #endregion

                Reports.TestStep = "Validate that the Production office added from office set up.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.EscrowProdOfficeTable.PerformTableAction("Office Name", "QA Automation Office - DO NOT TOUCH (1487)", "Office Name", TableAction.Click);
                FastDriver.FileHomepage.TitleProdOfficeTable.PerformTableAction("Office Name", "QA Automation Office - DO NOT TOUCH (1487)", "Office Name", TableAction.Click);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM6780_FM6781_FM6788_FM6789_ER13: Add Production Offices to the file based on Task office.")]
        public void FMUC0023_REG0031()
        {
            try
            {
                Reports.TestDescription = "FM6780_FM6781_FM6788_FM6789_ER13: Add Production Offices to the file based on Task office.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create file";

                var FileData = _CreateBasicFile();

                #endregion

                Reports.TestStep = "Validate that the Production office is added to FHP from File Workflow.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.EscrowProdOfficeTable.PerformTableAction("Office Name", "QA Automation Office - DO NOT TOUCH (1487)", "Office Name", TableAction.Click);
                FastDriver.FileHomepage.TitleProdOfficeTable.PerformTableAction("Office Name", "QA Automation Office - DO NOT TOUCH (1487)", "Office Name", TableAction.Click);

                Reports.TestStep = "Tast assignment to the office from the file workflow";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Process.PerformTableAction(4, "1", 7, TableAction.Click);

                Reports.TestStep = "Select the Task Office.";
                Playback.Wait(5000);
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.PerformTableAction("Office", "QA SANDPOINTE OFFICE", "Office", TableAction.Click);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Process.PerformTableAction(4, "1", 1, TableAction.Click);

                Reports.TestStep = "Change exist information on production office section.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveEscOff.FAClick();

                Reports.TestStep = "Select QA Automation Region and uncheck the office.";
                Playback.Wait(5000);
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                FastDriver.OfficeSelectionDlg.Region.FASelectItem("QA SANDPOINTE REGION");
                Playback.Wait(5000);

                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", "QA SANDPOINTE OFFICE", "Sel", TableAction.Off);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Wait and Click on Save";
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "save Changes without Bus Party.";
                Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Validate the message on removal of Production office added via Workflow.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.Errormessage.IsDisplayed().ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("BR_FM4842_001: ADM Set up for Sales Rep.")]
        public void FMUC0023_REG0032()
        {
            try
            {
                Reports.TestDescription = "BR_FM4842_001: ADM Set up for Sales Rep.";

                #region Login
                _ADMLOGIN();
                #endregion

                #region Search a GAB in Address Book and click on Edit button
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";

                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.SearchAddressBook("HUDFLINSR1");
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "HUDFLINSR1", 2, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();


                #endregion

                Reports.TestStep = "Set the sales rep1 and sales rep2.";

                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.PrimaryContact.FASelectItem("");
                FastDriver.BusPartyOrgSetUp.SalesRep1.FASelectItem("QA03 FAST");
                FastDriver.BusPartyOrgSetUp.SalesRep2.FASelectItem("QA03 FAST");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.SearchAddressBook("HUDASLNDR1");
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "HUDASLNDR1", 2, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Set Primary contact to Contact, Assumption Lender 1.";
                FastDriver.BusPartyOrgSetUp.PrimaryContact.FASelectItem("Contact, Assumption Lender 1");

                Reports.TestStep = "Click on View/Add Contact.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();

                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.ContactList.PerformTableAction(3, "Contact", 3, TableAction.Click);
                FastDriver.BusPartyContactsList.Edit.FAClick();

                Reports.TestStep = "To set sales rep for Contact, Assumption Lender 1.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();

                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem("Jeella Venkateswara Rao");
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem("Jeella Venkateswara Rao");

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.SearchAddressBook("HUDASLNDR2");
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "HUDASLNDR2", 2, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Click on View/Add Contact.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();

                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.ContactList.PerformTableAction(3, "Contact", 3, TableAction.Click);
                FastDriver.BusPartyContactsList.Edit.FAClick();

                Reports.TestStep = "To set sales rep1 for Contact, Assumption Lender 2.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();

                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem("QA02 FAST");
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem("");

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM4842_FM4844_FM4832_FM4833_FM5130_FM4845: Sales Rep Display Forma.")]
        public void FMUC0023_REG0033()
        {
            try
            {
                Reports.TestDescription = "FM4842_FM4844_FM4832_FM4833_FM5130_FM4845: Sales Rep Display Format.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Create Title Order to verify Filenum Prefix and suffix.";

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FASelectItem("QA05, FAST");
                FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FASelectItem("QA08, FAST");

                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYSalesRep1.FASelectItem("QA05, FAST");
                FastDriver.QuickFileEntry.DirectedBYSalesRep2.FASelectItem("QA05, FAST");

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");

                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.NewLenderInformationSalesRep1.FASelectItem("QA05, FAST");
                FastDriver.QuickFileEntry.NewLenderInformationSalesRep2.FASelectItem("QA05, FAST");

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep1.FASelectItem("QA05, FAST");
                FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep2.FASelectItem("QA05, FAST");



                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }


                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad(); ;

                #endregion

                Reports.TestStep = "Validate the sales rep for Business parties.";

                Support.AreEqual("QA05, FAST", FastDriver.FileHomepage.BusinessPartySalesRep1.FAGetSelectedItem().Trim());
                Support.AreEqual("QA08, FAST", FastDriver.FileHomepage.BusinessPartySalesRep2.FAGetSelectedItem().Trim());
                Support.AreEqual("QA05, FAST", FastDriver.FileHomepage.DirectedBySalesRep1.FAGetSelectedItem().Trim());
                Support.AreEqual("QA05, FAST", FastDriver.FileHomepage.DirectedBySalesRep2.FAGetSelectedItem().Trim());
                Support.AreEqual("QA05, FAST", FastDriver.FileHomepage.BusinessPartyLenderSalesRep1.FAGetSelectedItem().Trim());
                Support.AreEqual("QA05, FAST", FastDriver.FileHomepage.BusinessPartyLenderSalesRep2.FAGetSelectedItem().Trim());
                Support.AreEqual("QA05, FAST", FastDriver.FileHomepage.AssociateBusinessPartySalesRep1.FAGetSelectedItem().Trim());
                Support.AreEqual("QA05, FAST", FastDriver.FileHomepage.AssociateBusinessPartySalesRep2.FAGetSelectedItem().Trim());



            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM4836_FM4837_FM4839_FM4840_FM4841_FM4887: Populate Primary Contact's Sales Reps.")]
        public void FMUC0023_REG0034()
        {
            try
            {
                Reports.TestDescription = "FM4836_FM4837_FM4839_FM4840_FM4841_FM4887: Populate Primary Contact's Sales Reps.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Validate the default value for sales rep is populated on selection of Bus Party.";

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
               
                Support.AreEqual(true.ToString(),Regex.IsMatch(FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim(), @"|B, Raghu|QA03, FAST").ToString(), "Verifying BusinessSourceSalesRep1");
                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim(), @"|QA03, FAST").ToString(), "Verifying BusinessSourceSalesRep2");

                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                if (FastDriver.QuickFileEntry.DirectedBYSalesRep1.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.QuickFileEntry.DirectedBYSalesRep1.FAGetSelectedIndex().ToString(), "DirectedBYSalesRep1 Selected Item Index");
                }
                else {
                    Support.AreEqual("1", FastDriver.QuickFileEntry.DirectedBYSalesRep1.FAGetSelectedIndex().ToString(), "DirectedBYSalesRep1 Selected Item Index");

                }

                if (FastDriver.QuickFileEntry.DirectedBYSalesRep2.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.QuickFileEntry.DirectedBYSalesRep2.FAGetSelectedIndex().ToString(), "DirectedBYSalesRep2 Selected Item Index");
                }
                else {
                    Support.AreEqual("2", FastDriver.QuickFileEntry.DirectedBYSalesRep2.FAGetSelectedIndex().ToString(), "DirectedBYSalesRep2 Selected Item Index");

                }


                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("AZ");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();

                Support.AreEqual("Jeella, Venkateswara Rao", FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep1.FAGetSelectedItem().Trim(), "AssociatedBusinessPartySalesRep1 Selected Item");
                Support.AreEqual("Jeella, Venkateswara Rao", FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep2.FAGetSelectedItem().Trim(), "AssociatedBusinessPartySalesRep2 Selected Item");


                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }


                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad(); ;

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM4838_FM5222: Display Selected Contact's Sales Rep.")]
        public void FMUC0023_REG0035()
        {
            try
            {
                Reports.TestDescription = "FM4838_FM5222: Display Selected Contact's Sales Rep.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Bus party contact has Sales Rep1 and no Sales Rep 2, Directed By has Sales Rep 2 and no Sales Rep 1.";

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDASLNDR2");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.BusinessSourceAttention.FASelectItem("Contact, Assumption Lender 2");

                Support.AreEqual("QA02, FAST", FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim());
                Support.AreEqual("0", FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedIndex().ToString());

                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDASLNDR3");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYAttention.FASelectItem("Contact, Assumption Lender 3");

                Support.AreEqual("0", FastDriver.QuickFileEntry.DirectedBYSalesRep1.FAGetSelectedIndex().ToString(), "DirectedBYSalesRep1 Selected Item Index");
                FastDriver.QuickFileEntry.DirectedBYSalesRep2.FASelectItem("QA03, FAST");

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }


                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad(); ;

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM4843 : Default blank Sales Rep for Ad Hoc entry.")]
        public void FMUC0023_REG0036()
        {
            try
            {
                #region DataSetup
                String[] RegionalAccess = { "Regional Administrator",  "Corporate Administrator" };
                String[] OfficeAccess = { "Office Administrator", "IT - all" };
                String[] EmployeeTypes = { "Escrow Officer", "Title Officer" };

                #endregion

                Reports.TestDescription = "FM4843 : Default blank Sales Rep for Ad Hoc entry.";

                Reports.TestStep = "Login to ADM site.";
                _ADMLOGIN();

                _AddAccessRights(AutoConfig.UserName, RegionalAccess: RegionalAccess, OfficeAccess: OfficeAccess, RegionLevel: true);
                _AddEmployeeTypes(AutoConfig.UserName, EmployeeTypes: EmployeeTypes, RegionLevel: false);

                #region Login
                Reports.TestStep = @"Check for the role assigned for the fastts\fastqa07 employee in ADM side";
                _IISLOGIN();
                #endregion

                #region Create Basic File

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Click on Find button in QFE Business party.";

                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter GAB code and click on Find button.";

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("Test");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                Playback.Wait(10000);

                Reports.TestStep = "Click on New GAB button.";
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();

                Reports.TestStep = "Creates a New GAB Request.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();

                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem("Corporate");
                FastDriver.GABEntryRequestDlg.Name1.FASetText("Name 1 TFS 10678");
                FastDriver.GABEntryRequestDlg.Name2.FASetText("Name 2 TFS 10678");
                FastDriver.GABEntryRequestDlg.LocDescription.FASetText("Loc Descscription");
                FastDriver.GABEntryRequestDlg.TaxIDNumber.FASetText("1111111111");
                FastDriver.GABEntryRequestDlg.BusOrgComments.FASetText("Bus Org Comments");
                FastDriver.GABEntryRequestDlg.EntryInstructions.FASetText("Entity Instruction");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText("1 First American Way");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText("Santa Ana");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem("CA");
                FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText("92707");
                FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText("Orange");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate the sales rep and title/Escrow officer for adhoc bus org.";

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual("0", FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedIndex().ToString(), "BusinessSourceSalesRep1 selectem item index");
                Support.AreEqual("0", FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedIndex().ToString(), "BusinessSourceSalesRep2 selectem item index");

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
                string ReverseUserID = AutoConfig.UserName.Split('\\')[1].Substring(4, 4) + ", " + AutoConfig.UserName.Split('\\')[1].Substring(0, 4);

                Support.AreEqual(ReverseUserID.ToUpper(), FastDriver.QuickFileEntry.TitleOwningOfficeOfficer.FAGetSelectedItem(), "TitleOwningOfficeOfficer Is Reversed UserID");
                Support.AreEqual(ReverseUserID.ToUpper(), FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FAGetSelectedItem().Trim(), "EscrowOwningOfficeOfficer Is Reversed UserID");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5131: Default Sales Rep for Adhoc Attention.")]
        public void FMUC0023_REG0037()
        {
            try
            {
                Reports.TestDescription = "FM5131: Default Sales Rep for Adhoc Attention.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Validate the default value fro sales rep is populated on selection of Bus Party.";

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.BusinessSourceEditName.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSourceNameEdit.FASetText("Adhoc Contact");

                string SelectedBusinessSourceSalesRep1 = FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim();

                Support.AreEqual(true.ToString(), (FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim() == "Jeella, Venkateswara Rao" || FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim() == string.Empty).ToString(), "BusinessSourceSalesRep1 is Jeella, Venkateswara Rao or Empty");
                Support.AreEqual(true.ToString(), (FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedItem().Trim() == "Jeella, Venkateswara Rao" || FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim() == string.Empty).ToString(), "BusinessSourceSalesRep2 is Jeella, Venkateswara Rao or Empty");

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.TransactionType.FASelectItemByIndex(12);

                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM4802: Maintain Sales Rep.")]
        public void FMUC0023_REG0038()
        {
            try
            {
                Reports.TestDescription = "FM4802: Maintain Sales Rep.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Validate the default value fro sales rep is populated on selection of Bus Party.";

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.BusinessSourceEditName.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSourceNameEdit.FASetText("Adhoc Contact");

                string SelectedBusinessSourceSalesRep1 = FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim();

                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim(), @"|B, Raghu|QA03, FAST").ToString(), "Verifying BusinessSourceSalesRep1");
                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim(), @"|QA03, FAST").ToString(), "Verifying BusinessSourceSalesRep2");

                Reports.TestStep = "Modify the sales rep and validate changes made to sales rep does not affect GAB.";
                FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FASelectItem("QA08, FAST");
                FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FASelectItem("QA08, FAST");

                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim(), @"|B, Raghu|QA03, FAST").ToString(), "Verifying BusinessSourceSalesRep1");
                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim(), @"|QA03, FAST").ToString(), "Verifying BusinessSourceSalesRep2");

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");

                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5138_FM5132: Business Segment values.")]
        public void FMUC0023_REG0039()
        {
            try
            {
                Reports.TestDescription = "FM5138_FM5132: Business Segment values.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic File.";
                _CreateBasicFile();
                #endregion

                Reports.TestStep = "Validate the Business segment values.";
                FastDriver.FileHomepage.Open();
                Support.AreEqual(@"Residential Commercial New Home Subdivision Time Share Default-Residential Default-Commercial", FastDriver.FileHomepage.BusinessSegment.FAGetText().Trim());

                Reports.TestStep = "Change Business segment.";
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Subdivision");
                FastDriver.BottomFrame.Save();

                FastDriver.FileHomepage.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5134_FM5135_FM5136: Modify Product.")]
        public void FMUC0023_REG0040()
        {
            try
            {
                Reports.TestDescription = "FM5134_FM5135_FM5136: Modify Product.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic File.";
                _CreateBasicFile();
                #endregion

                Reports.TestStep = "Select Product Abstract.";
                FastDriver.FileHomepage.AddFileProduct("Abstract");

                Reports.TestStep = "Select Product Agency File Scanning.";
                FastDriver.FileHomepage.AddFileProduct("Agency File Scanning");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the products added.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, "Abstract", 2, TableAction.Click);
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, "Agency File Scanning", 2, TableAction.Click);

                Reports.TestStep = "Uncheck the ALTA Expanded (Eagle Loan) Policy Product.";
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, "*ALTA Expanded (Eagle Loan) Policy", 1, TableAction.Off);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the ALTA Expanded (Eagle Loan) Policy Product is removed.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.ProductSummaryTable.FAGetText().Contains("ALTA Expanded (Eagle Loan) Policy").ToString(), "ProductSummaryTable does not contain ALTA Expanded (Eagle Loan) Policy");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5142_00: Employee Saved with the File (Role= Title Officer) && FM5142_01: Employee Saved with the File (File).")]
        public void FMUC0023_REG0041()
        {
            try
            {
                #region DataSetup
                String[] EmployeeTypes = { "Title Officer" };
                #endregion

                Reports.TestDescription = "FM5142_00: Employee Saved with the File (Role= Title Officer) && FM5142_01: Employee Saved with the File (File).";

                #region FM5142_00: Employee Saved with the File (Role= Title Officer)
                Reports.TestStep = "FM5142_00: Employee Saved with the File (Role= Title Officer).";
                Reports.StatusUpdate("FM5142_00: Employee Saved with the File (Role= Title Officer).", true);

                Reports.TestStep = "Login to Admin.";
                _ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search an employee and click on Edit.";
                _AddEmployeeTypes(AutoConfig.UserName, EmployeeTypes: EmployeeTypes, RegionLevel: true);

                #endregion

                #region FM5142_01: Employee Saved with the File (File)

                Reports.TestStep = "FM5142_01: Employee Saved with the File (File).";
                Reports.StatusUpdate("FM5142_01: Employee Saved with the File (File).", true);

                #region Login
                Reports.TestStep = @"Login to IIS";
                _IISLOGIN();
                #endregion

                #region Create Basic File

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Click on Find button in QFE Business party.";
                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Wait and Click on Done";
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM5142_02: Employee Saved with the File (Role= Escrow Officer) && Setup Employee && FM5142_03_FM2210: Employee Saved with the File (File).")]
        public void FMUC0023_REG0043()
        {
            try
            {

                #region DataSetup
                String[] EmployeeTypes = { "Escrow Officer" };
                #endregion

                Reports.TestDescription = "FM5142_02: Employee Saved with the File (Role= Escrow Officer) && Setup Employee && FM5142_03_FM2210: Employee Saved with the File (File).";

                #region FM5142_02: Employee Saved with the File (Role= Escrow Officer)
                Reports.TestStep = "FM5142_02: Employee Saved with the File (Role= Escrow Officer).";
                Reports.StatusUpdate("FM5142_02: Employee Saved with the File (Role= Escrow Officer).", true);

                #region Login and Create File
                Reports.TestStep = @"Login to IIS and create file before changing the user's Employee Type";
                _IISLOGIN();


                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();


                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                string FileNumber = FastDriver.FileHomepage.FileNum.FAGetValue();
                string TitleOfficer = FastDriver.FileHomepage.TitleOwningOfficeOfficer.FAGetSelectedItem().Trim();

                #endregion

                Reports.TestStep = "Login to Admin.";
                _ADMLOGIN();

                Reports.TestStep = "Search an employee and click on Edit.";
                _AddEmployeeTypes(AutoConfig.UserName, EmployeeTypes: EmployeeTypes, RegionLevel: true);

                #endregion

                #region Setup For Emloyee Setup
                Reports.TestStep = "Setup For Emloyee Setup.";
                Reports.StatusUpdate("Setup For Emloyee Setup.", true);

                Reports.TestStep = "Search an employee and click on Edit && Select multiple Employee Types.";
                String[] EmployeeTypesSetup = { "Escrow Assistant", "Escrow Officer", "Sales Rep", "Title Assistant", "Title Officer" };

                _AddEmployeeTypes(AutoConfig.UserName, EmployeeTypes: EmployeeTypesSetup, RegionLevel: true);


                #endregion

                #region FM5142_03_FM2210: Employee Saved with the File (File)
                Reports.TestStep = "FM5142_03_FM2210: Employee Saved with the File (File).";
                Reports.StatusUpdate("FM5142_03_FM2210: Employee Saved with the File (File).", true);


                #region Login
                Reports.TestStep = @"Login to IIS";
                _IISLOGIN();
                #endregion

                Reports.TestStep = "Enter file number and Click on Find .";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Validate the  Title Officer.";
                FastDriver.FileHomepage.Open();

                Support.AreEqual(TitleOfficer, FastDriver.FileHomepage.TitleOwningOfficeOfficer.FAGetSelectedItem().Trim());

                Reports.TestStep = "Change Title own officer to blank value.";
                FastDriver.FileHomepage.TitleOwningOfficeOfficer.FASelectItem("");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Change Title own officer.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TitleOwningOfficeOfficer.FASelectItem(TitleOfficer);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM2210_FM5143: Remove Employee.")]
        public void FMUC0023_REG0045()
        {
            try
            {
                Reports.TestDescription = "FM2210_FM5143: Remove Employee.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Basic File
                Reports.TestStep = "Create Basic File.";
                _CreateBasicFile();
                #endregion

                Reports.TestStep = "Go to File Homepage.";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Change Title own officer to blank value.";
                FastDriver.FileHomepage.TitleOwningOfficeOfficer.FASelectItem("");
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Change Title own officer.";
                FastDriver.FileHomepage.Open();
                string ReverseUserID = AutoConfig.UserName.Split('\\')[1].Substring(4, 4) + ", " + AutoConfig.UserName.Split('\\')[1].Substring(0, 4);
                FastDriver.FileHomepage.TitleOwningOfficeOfficer.FASelectItem(ReverseUserID.ToUpper());
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("BR_FM9709_FM9708_FM9710: Filtering File's Program Type dropdown list.")]
        public void FMUC0023_REG0046()
        {
            try
            {
                Reports.TestDescription = "BR_FM9709_FM9708_FM9710: Filtering File's Program Type dropdown list.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Click on skip button to go to QFE
                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Validate the program type,serach type product hierarchy.";

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                Support.AreEqual("", FastDriver.QuickFileEntry.ProgramType.FAGetSelectedItem().Trim());

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                FastDriver.ProductListDlg.WaitScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Homeowners (Eagle Owner) Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                string SearchTypeSelected = FastDriver.QuickFileEntry.SearchType.FAGetSelectedItem().Trim();
                string comparedWith = SearchTypeSelected != "06-Property Report" ? SearchTypeSelected : string.Empty;

                Support.AreEqual(comparedWith, SearchTypeSelected);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("230,000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                Reports.TestStep = "Validate when there are multiple search types products.";
                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                FastDriver.ProductListDlg.WaitScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "Abstract", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Support.AreEqual(@"No Search Type" + comparedWith + "++View More...", FastDriver.QuickFileEntry.SearchType.FAGetText().Trim());

                Reports.TestStep = "Wait and Click on Done";
                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Navigate to File Home page and change the business Source click ok and check Programme typr check Box and click Done";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Change Title own officer to blank value.";
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText("HUDAUT02");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.ProgramTypeOverride.FASetCheckbox(true);

                FastDriver.FileHomepage.ProductsTable.PerformTableAction(2, "Abstract", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate the event for Program type override";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Program Type Override]", "Event", TableAction.Click);

                Reports.TestStep = "Validate the source for Program type override";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "File Homepage", "Source", TableAction.Click);

                Reports.TestStep = "Validate the comments for Program type override";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", "Program Type Override: Program", "Comments", TableAction.Click);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM9712_FM9713_FM9714_FM9699_FM10516_FM10517_FM9699 && FM9716: Disabling editing Program Type.")]
        public void FMUC0023_REG0047()
        {
            try
            {

                Reports.TestDescription = "FM9712_FM9713_FM9714_FM9699_FM10516_FM10517_FM9699 && FM9716: Disabling editing Program Type";

                #region FM9712_FM9713_FM9714_FM9699_FM10516_FM10517_FM9699
                Reports.TestStep = "FM9712_FM9713_FM9714_FM9699_FM10516_FM10517_FM9699";
                Reports.StatusUpdate("FM9712_FM9713_FM9714_FM9699_FM10516_FM10517_FM9699", true);


                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create Basic File.";
                var FileData = _CreateBasicFile();

                #endregion

                Reports.TestStep = "Select the View More from program type from dialog.";
                FastDriver.FileHomepage.Open();

                FastDriver.FileHomepage.ProgramType.FASelectItemBySendingKeys(0, true);//Select ++View

                FastDriver.ProgramTypesDlg.WaitForScreenToLoad();
                FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction(2, "ALL_BADJTRAY", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate the products *ALTA Expanded (Eagle Loan) Policy and Search type.";
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, "*ALTA Expanded (Eagle Loan) Policy", 2, TableAction.Click);

                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                #region FM9716: Disabling editing Program Type
                Reports.TestStep = "FM9716: Disabling editing Program Type";
                Reports.StatusUpdate("FM9716: Disabling editing Program Type", true);


                #region Deposit a Cash
                Reports.TestStep = "Deposit a cash.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Add a Fee
                Reports.TestStep = "Add a Fee.";

                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "20.00");
                FastDriver.BottomFrame.Done();

                #endregion

                Reports.TestStep = "Click on Fee Transfer Button.";

                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                              
                
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Validate the Program type is disabled.";
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.ProgramType.IsEnabled().ToString());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM12635: Display Program Type in Program Type field - manual file creation.")]
        public void FMUC0023_REG0049()
        {
            try
            {

                Reports.TestDescription = "FM12635: Display Program Type in Program Type field - manual file creation.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Order and validate the program type as per the Bus Org and Transaction Type combination
                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Create Order and validate the program type as per the Bus Org and Transaction Type combination.";

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDASLNDR3");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Accommodation");
                Support.AreEqual("0", FastDriver.QuickFileEntry.ProgramType.FAGetSelectedIndex().ToString(), "Verifying ProgramType selected index is 0");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("ALAMEDA");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();


                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Program type dropdown values.";

                Support.AreEqual("No Program Type ++View More...", FastDriver.FileHomepage.ProgramType.FAGetText().Trim());

                #endregion

                Reports.TestStep = "Create Order with selected Program Type.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDASLNDR3");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Bulk Sale");
                Support.AreEqual("", FastDriver.QuickFileEntry.ProgramType.FAGetSelectedItem(), "Verifying ProgramType");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("ALAMEDA");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();

                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Check Program Type Override checkbox.";

                FastDriver.FileHomepage.ProgramTypeOverride.FASetCheckbox(true);

                FastDriver.FileHomepage.BusSrceName.FAClick();
                FastDriver.BottomFrame.Save();


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("SetupForProgrammeType && FM10065: Prevent Change Owning Office for IBAs")]
        public void FMUC0023_REG0050()
        {
            try
            {

                Reports.TestDescription = "SetupForProgrammeType && FM10065: Prevent Change Owning Office for IBAs";

                #region SetupForProgrammeType
                Reports.TestStep = "SetupForProgrammeType";
                Reports.StatusUpdate("SetupForProgrammeType", true);

                _ADMLOGIN();
                //FastDriver.SecuritySelectRegionOffice.Open();
                //FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.Open();

                FastDriver.AddressBookSearch.SearchAddressBook("HUDASLNDR3");
                FastDriver.AddressBookSearch.EditAddress("HUDASLNDR3");

                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Click on Add/Remove button.";

                string BusPartyOrgSetupName = FastDriver.BusPartyOrgSetUp.Name1.FAGetValue().Trim();
                FastDriver.LeftNavigation.Navigate<ProgramTypes>(BusPartyOrgSetupName + ">Program Type");

                FastDriver.ProgramTypes.WaitForScreenToLoad();
                FastDriver.ProgramTypes.AddRemove.FAClick();

                //Tge ProgramTypes Dialog Title changes on ADM
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad(windowName: "Program Types");

                Reports.TestStep = "Clear the Programme Type.";

                FastDriver.ProgramTypesDlg.Clear.FAClick();
                //FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction(1, 1, TableAction.On);
                //string DefaultProgramType = FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction(1, 2, TableAction.GetText).Message;

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.ProgramTypes.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.AddressBookSearch.WaitForScreenToLoad();

                #endregion

                #region FM10065: Prevent Change Owning Office for IBAs
                Reports.TestStep = "FM10065: Prevent Change Owning Office for IBAs";
                Reports.StatusUpdate("FM10065: Prevent Change Owning Office for IBAs", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create Basic File.";
                var FileData = _CreateBasicFile();

                #endregion

                #region Deposit a Cash
                Reports.TestStep = "Deposit a cash.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.InterestBearingAccounts.Open();

                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();

                string BeneficiayName = "Beneficiary TFS_104161 " + Support.RandomString("AAA");
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText(BeneficiayName);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();


                Reports.TestStep = "Select the IBA bank and product type";
                FastDriver.InterestBearingAccounts.IBABank.FAClick();

                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.IBABanks.FASelectItem("NewBank");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                Reports.TestStep = "Enter the Transaction Amount and saving.";

                FastDriver.InterestBearingAccounts.Transactions.FAClick();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();

                Reports.TestStep = "Verify error message when escrow is removed for IBA [US#686119 - TC#774073: System shall not allow changing owing office if file has Open IBA]";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("Service File: You cannot Change the Owning Office or Remove a service type when the file contains IBA(s).", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());

                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM9828_001: Add/Remove Business Programs(add) && FM9817: Add Business Organization to File Homepage && FM9828_002: Add/Remove Business Programs(remove) && FM9828_003: Add/Remove Business Programs(verify file side).")]
        public void FMUC0023_REG0051()
        {
            try
            {
                String FileNumber = "";
                Reports.TestDescription = "FM9828_001: Add/Remove Business Programs(add) && FM9817: Add Business Organization to File Homepag && FM9828_002: Add/Remove Business Programs(remove) && FM9828_003: Add/Remove Business Programs(verify file side).";

                #region FM9828_001: Add/Remove Business Programs(add)
                Reports.TestStep = "FM9828_001: Add/Remove Business Programs(add)";
                Reports.StatusUpdate("FM9828_001: Add/Remove Business Programs(add)", true);


                _ADMLOGIN();

                Reports.TestStep = "Search for a gab code(Pre-condition).";

                FastDriver.AddressBookSearch.Open();

                FastDriver.AddressBookSearch.SearchAddressBook("HUDFLINSR1");
                FastDriver.AddressBookSearch.EditAddress("HUDFLINSR1");

                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Click on Add/Remove Bus Programs.";

                FastDriver.BusPartyOrgSetUp.BusinessProgramAddRemove.FAClick();

                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();

                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, "Strategic Markets", 1, TableAction.On);
                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, "VIP", 1, TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();

                Reports.TestStep = "To create new business party contact for the Bus Org.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();

                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";

                FastDriver.BusPartyContactsList.WaitForScreenToLoad();

                FastDriver.BusPartyContactsList.ContactList.PerformTableAction(3, "Contact", 3, TableAction.Click);
                FastDriver.BusPartyContactsList.Edit.FAClick();

                Reports.TestStep = "To change sales rep2.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();

                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.ContactList.PerformTableAction(3, "Contact", 3, TableAction.Click);
                FastDriver.BusPartyContactsList.Edit.FAClick();

                Reports.TestStep = "click on add/remove button.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.BusProgramAddRemove.FAClick();

                Reports.TestStep = "Select Business Program.";
                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();
                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, "VIP", 1, TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.AddressBookSearch.WaitForScreenToLoad();

                #endregion

                #region FM9817: Add Business Organization to File Homepage.

                Reports.TestStep = "FM9817: Add Business Organization to File Homepage.";
                Reports.StatusUpdate("FM9817: Add Business Organization to File Homepage.", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create Order
                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDATASTL1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Bulk Sale");
                Support.AreEqual("0", FastDriver.QuickFileEntry.ProgramType.FAGetSelectedIndex().ToString(), "Verifying ProgramType selected index is 0");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("ALAMEDA");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();


                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                #region Add Directed By in the file .
                Reports.TestStep = "Add Directed By in the file .";

                FileNumber = FastDriver.FileHomepage.FileNum.FAGetValue().Trim();

                FastDriver.FileHomepage.DirectedByGABcode.FASetText("HUDFLINSR1");
                FastDriver.FileHomepage.DirectedByName.FASetText("");
                FastDriver.FileHomepage.DirectedByFind.FAClick();

                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Business programs added to file-1.";
                FastDriver.FileHomepage.BusinessPrograms.FAClick();

                FastDriver.FileHomepage.AddRemoveBusPrograms.FAClick();

                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();

                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, "Strategic Markets", 1, TableAction.On);
                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, "VIP", 1, TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.BusinessPrograms.PerformTableAction(1, "Strategic Markets", 1, TableAction.Click);

                Reports.TestStep = "Validate the Business programs added to file-2.";
                FastDriver.FileHomepage.BusinessPrograms.PerformTableAction(1, "VIP", 1, TableAction.Click);

                #endregion

                #endregion

                #region FM9828_002: Add/Remove Business Programs(remove).

                Reports.TestStep = "FM9828_002: Add/Remove Business Programs(remove).";
                Reports.StatusUpdate("FM9828_002: Add/Remove Business Programs(remove).", true);

                _ADMLOGIN();

                Reports.TestStep = "Search for a gab code(Pre-condition).";

                FastDriver.AddressBookSearch.Open();

                FastDriver.AddressBookSearch.SearchAddressBook("HUDFLINSR1");
                FastDriver.AddressBookSearch.EditAddress("HUDFLINSR1");

                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Click on Add/Remove Bus Programs.";

                FastDriver.BusPartyOrgSetUp.BusinessProgramAddRemove.FAClick();

                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();

                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, "Strategic Markets", 1, TableAction.Off);

                Reports.TestStep = "Click on Done in Dialog Box.";

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();

                Reports.TestStep = "To create new business party contact for the Bus Org.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();

                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";

                FastDriver.BusPartyContactsList.WaitForScreenToLoad();

                FastDriver.BusPartyContactsList.ContactList.PerformTableAction(3, "Contact", 3, TableAction.Click);
                FastDriver.BusPartyContactsList.Edit.FAClick();

                Reports.TestStep = "To change sales rep2.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();

                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.ContactList.PerformTableAction(3, "Contact", 3, TableAction.Click);
                FastDriver.BusPartyContactsList.Edit.FAClick();

                Reports.TestStep = "click on add/remove button.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.BusProgramAddRemove.FAClick();

                Reports.TestStep = "Remove Business Program.";
                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();
                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, "VIP", 1, TableAction.Off);

                Reports.TestStep = "Click on Done in Dialog Box.";

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait and Click on Done.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.AddressBookSearch.WaitForScreenToLoad();

                #endregion

                #region FM9828_003: Add/Remove Business Programs(verify file side).

                Reports.TestStep = "FM9828_003: Add/Remove Business Programs(verify file side).";
                Reports.StatusUpdate("FM9828_003: Add/Remove Business Programs(verify file side).", true);

                Reports.TestStep = "Login to IIS.";
                _IISLOGIN();

                Reports.TestStep = "Navigate to File.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Validate the Business programs added to file-1.";
                FastDriver.FileHomepage.Open();

                FastDriver.FileHomepage.BusinessPrograms.PerformTableAction(1, "Strategic Markets", 1, TableAction.Click);

                Reports.TestStep = "Validate the Business programs added to file-2.";
                FastDriver.FileHomepage.BusinessPrograms.PerformTableAction(1, "VIP", 1, TableAction.Click);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM10523_001_FM10524: Allow FACC Calculation for Commercial Rates(State=OH).")]
        public void FMUC0023_REG0055()
        {
            try
            {
                Reports.TestDescription = "FM10523_001_FM10524: Allow FACC Calculation for Commercial Rates(State=OH).";

                #region Login
                _IISLOGIN();
                #endregion

                #region Click on skip button to go to QFE
                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Validate the program type,serach type product hierarchy.";

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");



                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("OH");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Verify All Fees,TitleRate,Endorsement and Recording fees is enabled";

                FastDriver.FileFees.Open();
                Support.AreEqual(true.ToString(), FastDriver.FileFees.AllFees.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingFees.IsEnabled().ToString());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM10523_002: Allow FACC Calculation for Commercial Rates(State=NM).")]
        public void FMUC0023_REG0056()
        {
            try
            {
                Reports.TestDescription = "FM10523_002: Allow FACC Calculation for Commercial Rates(State=NM).";

                #region Login
                _IISLOGIN();
                #endregion

                #region Click on skip button to go to QFE
                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Validate the program type,serach type product hierarchy.";

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("NM");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Verify All Fees,TitleRate,Endorsement and Recording fees is enabled";

                FastDriver.FileFees.Open();
                Support.AreEqual(true.ToString(), FastDriver.FileFees.AllFees.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingFees.IsEnabled().ToString());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM10523_003: Allow FACC Calculation for Commercial Rates(State=NY).")]
        public void FMUC0023_REG0057()
        {
            try
            {
                Reports.TestDescription = "FM10523_003: Allow FACC Calculation for Commercial Rates(State=NY).";

                #region Login
                _IISLOGIN();
                #endregion

                #region Click on skip button to go to QFE
                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Validate the program type,serach type product hierarchy.";

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("NY");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Verify All Fees,TitleRate,Endorsement and Recording fees is enabled";

                FastDriver.FileFees.Open();
                Support.AreEqual(true.ToString(), FastDriver.FileFees.AllFees.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingFees.IsEnabled().ToString());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM10523_004: Allow FACC Calculation for Commercial Rates(State=TX).")]
        public void FMUC0023_REG0058()
        {
            try
            {
                Reports.TestDescription = "FM10523_003: Allow FACC Calculation for Commercial Rates(State=TX).";

                #region Login
                _IISLOGIN();
                #endregion

                #region Click on skip button to go to QFE
                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Validate the program type,serach type product hierarchy.";

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("TX");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Verify All Fees,TitleRate,Endorsement and Recording fees is enabled";

                FastDriver.FileFees.Open();
                Support.AreEqual(true.ToString(), FastDriver.FileFees.AllFees.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingFees.IsEnabled().ToString());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM10524: Prevent FACC Calculation for Commercial Rates.")]
        public void FMUC0023_REG0059()
        {
            try
            {
                Reports.TestDescription = "FM10524: Prevent FACC Calculation for Commercial Rates.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Click on skip button to go to QFE
                Reports.TestStep = "Create Order with state as CA and Business Segment = Commercial.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Verify All Fees,TitleRate,Endorsement are disabled and Recording fees is enabled";

                FastDriver.FileFees.Open();
                Support.AreEqual(false.ToString(), FastDriver.FileFees.AllFees.IsEnabled().ToString());
                Support.AreEqual(false.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(false.ToString(), FastDriver.FileFees.TitleRates.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingFees.IsEnabled().ToString());

                Reports.TestStep = "Verify the Subject to calculation fee is present in Title Tab";

                if (!FastDriver.FileFees.TitleandescrowTable.FAGetText().Contains("1064_Title_Lender_Policy"))
                {
                    FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("1064_Title_Lender_Policy");
                }
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "1064_Title_Lender_Policy", 1, TableAction.On);

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "1064_Title_Lender_Policy", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "1064_Title_Lender_Policy", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM10521_001: Automatic Removal of Calculated Fees (change of product).")]
        public void FMUC0023_REG0060()
        {
            try
            {
                Reports.TestDescription = "FM10521_001: Automatic Removal of Calculated Fees (change of product).";


                Reports.TestStep = "Checking for the Fee Set up for the Eagle Lender Policy - 1 fee";

                #region ADMIN Login
                _ADMLOGIN();
                #endregion

                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);


                FastDriver.FeeSetup.CheckSubjectToCalculationFee("Eagle Lender Policy - 1", "Title - Lenders Policy", "CA - All", true);
                FastDriver.FeeSetup.CheckSubjectToCalculationFee("Record Deed", "Recording Fee - Deed", "CA - All", true);

                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Create File
                var File = _CreateBasicFile();
                #endregion

                Reports.TestStep = "Add new Loan.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();

                Reports.TestStep = "Add Endorsement Fee.";
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();

                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction(2, "[ALTA 3-06] Zoning - unimproved land", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("3");

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.Next.FAClick();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAnswersTable);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select View More option.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Eagle Lender Policy - 1");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.ClickOnFeeResultCheckbox(0);

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select View More option for the last fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(FastDriver.CalculateFees.SummaryTable.GetRowCount(), 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select mortgage fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem(@"Recording Fee - Deed");
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Record Deed");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Descriptions For the Fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");

                int SummaryTableRowCount = FastDriver.CalculateFees.SummaryTable.GetRowCount();

                if (SummaryTableRowCount >= 3)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 4, TableAction.SelectItemByIndex, "1");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 5, TableAction.SelectItem, "Seller");
                }

                if (SummaryTableRowCount >= 4)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(4, 5, TableAction.SelectItem, "Seller");
                }

                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.FileHomepage.AddFileProduct("*ALTA Homeowners (Eagle Owner) Policy");

                Reports.TestStep = "Chang the Transaction type to Construction Disbursement .";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Construction");

                Reports.TestStep = "Validate: Cancel without save changes?.";
                Support.AreEqual("Changing the Transaction Type will result in removal of all calculated Recording and Transfer Tax fees. Do you wish to continue?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the Title Fee, Endorsement is removed and Recording fee exists.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                Support.AreEqual(true.ToString(), FastDriver.CalculateFees.Fee1.IsDisplayed().ToString(), "Verify  Recording fee exists");
                Support.AreEqual(false.ToString(), FastDriver.CalculateFees.Fee2.IsDisplayed().ToString(), "Verify Title Fee doesnt exist");
                Support.AreEqual(false.ToString(), FastDriver.CalculateFees.Fee3.IsDisplayed().ToString(), "Verify Endorsement doesnt exist");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("Expected_Failure in Fee Validation : FM10521_002: Automatic Removal of Calculated Fees (100%Buyer,100%Seller).")]
        public void FMUC0023_REG0061()
        {
            try
            {
                Reports.TestDescription = "Expected_Failure in Fee Validation : FM10521_002: Automatic Removal of Calculated Fees (100%Buyer,100%Seller).";


                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Create File
                var File = _CreateBasicFile();
                #endregion

                Reports.TestStep = "Add new Loan.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();

                Reports.TestStep = "Add Endorsement Fee.";
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();

                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction(2, "[ALTA 3-06] Zoning - unimproved land", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("3");

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.Next.FAClick();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAnswersTable);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select View More option.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Eagle Lender Policy - 1");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.ClickOnFeeResultCheckbox(0);

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select View More option for the last fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(FastDriver.CalculateFees.SummaryTable.GetRowCount(), 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select mortgage fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem(@"Recording Fee - Deed");
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Record Deed");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Descriptions For the Fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");

                int SummaryTableRowCount = FastDriver.CalculateFees.SummaryTable.GetRowCount();

                if (SummaryTableRowCount >= 3)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 4, TableAction.SelectItemByIndex, "1");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 5, TableAction.SelectItem, "Seller");
                }

                if (SummaryTableRowCount >= 4)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(4, 5, TableAction.SelectItem, "Seller");
                }

                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.LeftNavigation.ClickHome();

                Reports.TestStep = "Chang the Transaction type to Construction Disbursement .";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Construction Disbursement");

                Reports.TestStep = "Change transaction type associated with calculated policy.";
                Support.AreEqual("Changing the Transaction Type will result in removal of all calculated Recording and Transfer Tax fees. Do you wish to continue?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the Title Fee, Endorsement is removed and Recording fee exists.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary").SwitchToContentFrame();

                Support.AreEqual(false.ToString(), FastDriver.CalculateFees.Fee1.IsDisplayed().ToString(), "Verify  Recording fee doesnt exists");
                Support.AreEqual(false.ToString(), FastDriver.CalculateFees.Fee2.IsDisplayed().ToString(), "Verify Title Fee doesnt exist");
                Support.AreEqual(false.ToString(), FastDriver.CalculateFees.Fee3.IsDisplayed().ToString(), "Verify Endorsement doesnt exist");

                Reports.TestStep = "Validate seller charge does not exists in a Refinance file.";
                FastDriver.FileFees.Open();
                Support.AreEqual(false.ToString(), FastDriver.FileFees.Sellercharge.IsDisplayed().ToString());


                //Decripcated due to:


                /**
                   FM10521  Automatic Removal of Calculated Fees                       
                    6.2 1064 - FAST Fee Interface to FACC
                    The system shall automatically remove calculated Title Fee & Endorsement amounts if products are deselected.  
                    The system shall not remove Recording Fees and Transfer Tax calculations.
                    If products are added after calculated rates are returned, the system shall not remove any calculated fees.
                    The system shall automatically remove calculated Recording & Transfer Tax amounts if Transaction Type is changed. 
                    The system shall not remove Title Fee & Endoresment calculations.
                    If the Transaction Type is changed resulting in the removal of Seller charges from the file, the system shall function as follows:
	                    1. Automatically remove any Seller amount charges and fees when 100% of the amount is charged to the Seller 
	                    2. Automatically remove any Seller split amount charges (% or $) and charge 100% of the amount to the Borrower for that fee.
	                    3. Retain all Borrower amount charges and fees when 100% of the amount is charged to the Buyer.

                    The system shall automatically remove calculated Title Fee & Endorsement amounts if an authorized FACC Underwriter is changed to an unauthorized FACC Underwriter.  
                    The system shall not remove Recording Fees and Transfer Tax calculations.

                When Transaction Type is changed to Construction Disbursement Product type is updated.

                **/
                //Reports.TestStep = "Validate the entire amount is buyer charge";
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction(4, "435.00", 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM10521_003: Automatic Removal of Calculated Fees (50%Seller 50%Buyer).")]
        public void FMUC0023_REG0062()
        {
            try
            {
                Reports.TestDescription = "FM10521_003: Automatic Removal of Calculated Fees (50%Seller 50%Buyer).";


                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Create File
                var File = _CreateBasicFile();
                #endregion

                Reports.TestStep = "Add new Loan.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();

                Reports.TestStep = "Add Endorsement Fee.";
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();

                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction(2, "[ALTA 3-06] Zoning - unimproved land", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("3");

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.Next.FAClick();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAnswersTable);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select View More option.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Eagle Lender Policy - 1");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.ClickOnFeeResultCheckbox(0);

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select View More option for the last fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(FastDriver.CalculateFees.SummaryTable.GetRowCount(), 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select mortgage fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem(@"Recording Fee - Deed");
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Record Deed");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Descriptions For the Fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");

                int SummaryTableRowCount = FastDriver.CalculateFees.SummaryTable.GetRowCount();

                if (SummaryTableRowCount >= 3)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 4, TableAction.SelectItemByIndex, "1");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 5, TableAction.SelectItem, "Seller");
                }

                if (SummaryTableRowCount >= 4)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(4, 5, TableAction.SelectItem, "Seller");
                }

                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Split the amount between seller and buyer.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SummarySplitAmount.FASetText("100.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.LeftNavigation.ClickHome();

                Reports.TestStep = "Chang the Transaction type to Construction Disbursement .";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Construction Disbursement");

                Reports.TestStep = "Change transaction type associated with calculated policy.";

                Support.AreEqual("Changing the Transaction Type will result in removal of all calculated Recording and Transfer Tax fees. Do you wish to continue?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();


                Reports.TestStep = "Validate seller charge does not exists in a Refinance file.";
                FastDriver.FileFees.Open();
                Support.AreEqual(false.ToString(), FastDriver.FileFees.Sellercharge.IsDisplayed().ToString());

                Reports.TestStep = "Validate the entire amount is buyer charge";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(4, "435.00", 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #region FMUC0023_REG0063
        [TestMethod]
        [Description("Expected_Failure in Fee Validation : FM10522: Automatic Removal of Manually Entered Fee Amounts.")]
        public void FMUC0023_REG0063()
        {
            try
            {
                Reports.TestDescription = "Expected_Failure in Fee Validation : FM10522: Automatic Removal of Manually Entered Fee Amounts.";

                #region Login
                _ADMLOGIN();
                #endregion

                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                string TitleFeeName = "ALTA Ext Loan Policy 1056.06 (6-17-06) - 1";
                FastDriver.FeeSetup.CheckSubjectToCalculationFee(TitleFeeName, "Title - Lenders Policy", "CA - All", true);

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create Order with an unauthorized underwriter.";
                _CreateBasicFile();
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("New Underwriter");
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Add a Title and Escrow Fee to file";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleFeeName, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleFeeName, 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleFeeName, 7, TableAction.SetText, "2.99");

                Reports.TestStep = "Add a Recording and Tax Fee to file";
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 5, TableAction.SetText, "2.99");
                string RecordingFeeName = FastDriver.FileFees.RecordingTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to File Homepage and change Underwriter to 'First American Title Insurance Company'";
                string expectedMessage = @"Changing the Underwriter will result in removal of all Title and Endorsement fees. You must obtain calculated rates for Title and Endorsement fees. Existing Underwriter/Agent premium splits will be recalculated based on the new Underwriter's premium split percentage. If you have previously edited Underwriter/Agent Details, please review to ensure the recalculated amounts are correct. Continue?";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("First");
                string actualMessage = FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(expectedMessage, actualMessage);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Fee Entry screen, validate title fee is removed.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                if (FastDriver.FileFees.TitleandescrowTable.FAGetText().Contains(TitleFeeName))
                {
                    Support.AreEqual(false.ToString(), FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleFeeName, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.CssSelector, "input[type=\"checkbox\"").IsSelected().ToString(), true);
                }
                else {
                    Support.AreEqual(false.ToString(), FastDriver.FileFees.TitleandescrowTable.FAGetText().Contains(TitleFeeName).ToString());
                }

                Reports.TestStep = "Navigate to Recording and Tax screen, validate recording fee remains the same.";
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);
                Support.AreEqual("1.99", FastDriver.FileFees.RecordingTable.PerformTableAction(2, RecordingFeeName, 4, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("2.99", FastDriver.FileFees.RecordingTable.PerformTableAction(2, RecordingFeeName, 5, TableAction.GetInputValue).Message.Clean());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0064
        [TestMethod]
        [Description("FM12627: Reference number removal on change of FBP.")]
        public void FMUC0023_REG0064()
        {
            try
            {
                Reports.TestDescription = "FM12627: Reference number removal on change of FBP.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create Order with business source reference number";
                _CreateBasicFile();
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyReference.FASetText("123456");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Change Business Source, validate warning message";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText("HUDATASTL3");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();

                Reports.TestStep = "Click OK to retain the reference number";
                string expMessage = "Changing the Business Party will remove \"Reference\"/\"Loan\" Number. Do you want to retain the \"Reference\"/\"Loan\" Number?";
                Support.AreEqual(expMessage, FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("123456", FastDriver.FileHomepage.BusinessPartyReference.FAGetValue());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Change Business Source, Click Cancel to remove reference number";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20, true); // Update title officer
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20, true); // Update escrow officer
                FastDriver.WebDriver.HandleDialogMessage(false, false, 20, true); // remove reference #
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.FileHomepage.BusinessPartyReference.FAGetValue());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0065
        [TestMethod]
        [Description("FM13571_001: Changing File Owning Office for transmitted Service Fees(title file).")]
        public void FMUC0023_REG0065()
        {
            try
            {
                Reports.TestDescription = "FM13571_001: Changing File Owning Office for transmitted Service Fees(title file).";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a title only file";
                _CreateBasicTitleFile();

                Reports.TestStep = "Navigate to Service Fees screen, add new service fee";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Select a payee from the Payee Search dialog";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payee Search", true, 20);
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction(2, "QA Automation Office - DO NOT TOUCH", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter service fee amount, click Transfer";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "100.00" + FAKeys.Tab);
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 1, TableAction.Click);
                FastDriver.ServiceFee.Transfer.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to File Homepage, click Change O/O button";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                Reports.TestStep = "Change the Title Owning Office";
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes(); // Do you want to assign those same Workflow Tasks to the new Title owning office?

                Reports.TestStep = "Validate warning message that owning title owning office can't be changed or removed";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                string expMessage = "Service File :File has issued fee disbursements. You cannot change the Owning Office or remove Service Type.";
                Support.AreEqual(expMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.ErrorMessagePane.FAGetText().Clean());
                FastDriver.BottomFrame.Cancel();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0066
        [TestMethod]
        [Description("FM13571_002: Changing File Owning Office for transmitted Service Fees(title sub escrow file).")]
        public void FMUC0023_REG0066()
        {
            try
            {
                Reports.TestDescription = "FM13571_002: Changing File Owning Office for transmitted Service Fees(title sub escrow file).";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a title & sub-escrow file";
                _CreateBasicTitleSubEscrowFile();

                Reports.TestStep = "Navigate to Service Fees screen, add new service fee";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Select a payee from the Payee Search dialog";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payee Search", true, 20);
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction(2, "QA Automation Office - DO NOT TOUCH", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter service fee amount, click Transfer";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "100.00" + FAKeys.Tab);
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 1, TableAction.Click);
                FastDriver.ServiceFee.Transfer.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to File Homepage, click Change O/O button";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                Reports.TestStep = "Change the Title Owning Office";
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes(); // Do you want to assign those same Workflow Tasks to the new Title owning office?

                Reports.TestStep = "Validate warning message that owning title owning office can't be changed or removed";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                string expMessage = "Service File :File has issued fee disbursements. You cannot change the Owning Office or remove Service Type.";
                Support.AreEqual(expMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.ErrorMessagePane.FAGetText().Clean());
                FastDriver.BottomFrame.Cancel();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0067
        [TestMethod]
        [Description("FM13571_003: Changing File Owning Office for transmitted Service Fees(title escrow file).")]
        public void FMUC0023_REG0067()
        {
            try
            {
                Reports.TestDescription = "FM13571_003: Changing File Owning Office for transmitted Service Fees(title escrow file).";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a title & sub-escrow file";
                _CreateBasicEscrowSubEscrowFile();

                Reports.TestStep = "Navigate to Service Fees screen, add new service fee";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Select a payee from the Payee Search dialog";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payee Search", true, 20);
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction(2, "QA Automation Office - DO NOT TOUCH", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter service fee amount, click Transfer";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "100.00" + FAKeys.Tab);
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 1, TableAction.Click);
                FastDriver.ServiceFee.Transfer.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to File Homepage, click Change O/O button";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                Reports.TestStep = "Change the Title Owning Office";
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes(); // Do you want to assign those same Workflow Tasks to the new Title owning office?

                Reports.TestStep = "Validate warning message that owning title owning office can't be changed or removed";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                string expMessage = "Service File :File has issued fee disbursements. You cannot change the Owning Office or remove Service Type.";
                Support.AreEqual(expMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.ErrorMessagePane.FAGetText().Clean());
                FastDriver.BottomFrame.Cancel();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0068
        [TestMethod]
        [Description("FM13573: Remove Service Fees when Owning Office is edited or changed.")]
        public void FMUC0023_REG0068()
        {
            try
            {
                Reports.TestDescription = "FM13573: Remove Service Fees when Owning Office is edited or changed.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a title & escrow file";
                _CreateBasicFile();

                Reports.TestStep = "Navigate to Service Fees screen, add new service fee";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Select a payee from the Payee Search dialog";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payee Search", true, 20);
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction(2, "QA Automation Office - DO NOT TOUCH", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter service fee amount, do not click Transfer";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "100.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);

                Reports.TestStep = "Navigate to File Homepage, click Change O/O button";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                Reports.TestStep = "Change the Title Owning Office";
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes(); // Do you want to assign those same Workflow Tasks to the new Title owning office?
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Service Fees screen, validate pending service fee is removed";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ServiceFee.Table.GetRowCount().ToString()); // One is the header row

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0069
        [TestMethod]
        [Description("Expected Failure in Index Validation :BR_FM5339_002: Assign Employees by Role (Verify in IIS).")]
        public void FMUC0023_REG0069()
        {
            // This test case combines REG0069 & REG0070
            try
            {
                Reports.TestDescription = "Expected Failure in Index Validation :BR_FM5339_002: Assign Employees by Role (Verify in IIS).";

                #region Login
                _ADMLOGIN();
                #endregion

                Reports.TestStep = "Assign Employees by Role (Set up in ADM).";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText("HUDWDINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Enter Title and escrow Officer for Bus Party.";
                FastDriver.BusPartyOrgSetUp.TitleOfficer.FASelectItemBySendingKeys("Nishanth Pandith");
                FastDriver.BusPartyOrgSetUp.EscrowOfficer.FASelectItemBySendingKeys("Nishanth Pandith");

                Reports.TestStep = "Edit contact";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.ContactList.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.BusPartyContactsList.Edit.FAClick();

                Reports.TestStep = "Enter Title and escrow Officer for Bus Party.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.TitleOfficer.FASelectItemBySendingKeys("Venkateswara Jeella");
                FastDriver.BusPartyContactSetup.EscrowOfficer.FASelectItemBySendingKeys("Venkateswara Jeella");
                FastDriver.BottomFrame.Done();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                //Start test case FMUC0023_REG0070
                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic file.";
                _CreateBasicFile();

                Reports.TestStep = "Navigate to File Homepage and change the Business Source GAB code";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText("HUDWDINSR1");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "validate the Title/Escrow Officer/Assistant is populated based on Bus Org.";
                Support.AreEqual("Pandith, Nishanth", FastDriver.FileHomepage.EscrowOwningOfficeOfficer.FAGetSelectedItem());
                Support.AreEqual("Pandith, Nishanth", FastDriver.FileHomepage.TitleOwningOfficeOfficer.FAGetSelectedItem());

                Reports.TestStep = "Select Attention and validate the Title/Escrow Officer/Assistant r is populated based on Bus Org attention.";
                FastDriver.FileHomepage.BusinessPartyAttention.FASelectItemBySendingKeys("Contact, Wind Insurance 1");
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("Jeella, Venkateswara", FastDriver.FileHomepage.EscrowOwningOfficeOfficer.FAGetSelectedItem());
                Support.AreEqual("Jeella, Venkateswara", FastDriver.FileHomepage.TitleOwningOfficeOfficer.FAGetSelectedItem());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Change owning office and validate the Title/Escrow Officer/Assistant is blank by default.";
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItemByIndex(2);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad(); // screen reload
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes(); // Do you want to assign those same Workflow Tasks to the new Title owning office?
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.FileHomepage.EscrowOwningOfficeOfficer.FAGetSelectedItem(), "Escrow Officer");
                Support.AreEqual(string.Empty, FastDriver.FileHomepage.EscrowOwningOfficeAssistant.FAGetSelectedItem(), "Escrow Officer Assistant");
                Support.AreEqual(string.Empty, FastDriver.FileHomepage.TitleOwningOfficeOfficer.FAGetSelectedItem(), "Title Officer");
                Support.AreEqual(string.Empty, FastDriver.FileHomepage.TitleOwningOfficeAssistant.FAGetSelectedItem(), "Title Officer Assistant");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0070
        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0069")]
        public void FMUC0023_REG0070()
        {
            // This test case combines REG0069 & REG0070
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0069";
                Reports.TestStep = "See test case FMUC0023_REG0069.";
                Reports.StatusUpdate("See test case FMUC0023_REG0069.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0071
        [TestMethod]
        [Description("BR_FM5144: File Workflow Not Affected.")]
        public void FMUC0023_REG0071()
        {
            try
            {
                Reports.TestDescription = "BR_FM5144: File Workflow Not Affected.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic file.";
                _CreateBasicFile();

                Reports.TestStep = "Verify the File Work Flow screen is loaded and the best match process template is displayed.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                string processName1 = FastDriver.FileWorkflow.ProcessName.FAGetText();

                Reports.TestStep = "Navigate to File Homepage and change Transaction type to Bulk Sale";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Bulk Sale");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to File Workflow screen, validate process remain the same.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                Support.AreEqual(processName1, FastDriver.FileWorkflow.ProcessName.FAGetText());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0072
        [TestMethod]
        [Description("BR_FM6560: Change Owning Office.; FM5139_FM5137_FM3179: Default Service Type.")]
        public void FMUC0023_REG0072()
        {
            try
            {
                Reports.TestDescription = "BR_FM6560: Change Owning Office.; FM5139_FM5137_FM3179: Default Service Type.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Sellers[0].SSN = "111-11-1111";
                fileRequest.File.Sellers[0].LastName1099S = "1099S";
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, set order received date/time";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.OrderRecievedDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.OrderRecievedTime.FASetText("09:00 AM PST" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Sellers screen, set 1099-S Classification";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItemBySendingKeys("1099-S" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to 1099-S screen, create a new 1099-S";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("200,000.00" + FAKeys.Tab);
                FastDriver._1099S.ActiveReadyForExtract.FASetCheckbox(true);
                FastDriver._1099S.ActiveAddress.FASetText("2 First American Way" + FAKeys.Tab);
                FastDriver._1099S.ActiveCity.FASetText("Santa Ana" + FAKeys.Tab);
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("CA");
                FastDriver._1099S.ActiveZip.FASetText("92704" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver._1099S.WaitForScreenToLoad();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes(); // Do you want to assign those same Workflow Tasks to the new Title owning office?

                Reports.TestStep = "Verify the 1099S error.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                string expMessage = "Service File: File has 1099-S records. You cannot change Owning Office to an office that does not have a 1099-S Activity Date in Office Setup";
                Support.AreEqual(expMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.ErrorMessagePane.FAGetText().Clean());

                // Start test case FMUC0023_REG0073: BR_FM6561_001: Prevent Removal of Escrow Service.
                Reports.TestStep = "FMUC0023_REG0073: Remove Escrow service type, validate error message";
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                expMessage = "Service File: File has 1099-S records. You cannot remove Escrow Service Type.";
                Support.AreEqual(expMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.ErrorMessagePane.FAGetText().Clean());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(); // Click OK on Exit without saving changes dialog
                FastDriver.FileHomepage.WaitForScreenToLoad();

                // Start test case FMUC0023_REG0074: BR_FM6561_002: Prevent Removal of Escrow Service.
                Reports.TestStep = "FMUC0023_REG0074: BR_FM6561_002: Prevent Removal of Escrow Service.";
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.FileHomepage.Title.IsSelected().ToString(), true);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0073
        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0072")]
        public void FMUC0023_REG0073()
        {
            try
            {
                // This test case combines with FMUC0023_REG0072
                try
                {
                    Reports.TestDescription = "This test case has been combined with FMUC0023_REG0072";
                    Reports.TestStep = "See test case FMUC0023_REG0072.";
                    Reports.StatusUpdate("See test case FMUC0023_REG0072.", true);
                }
                catch (Exception ex)
                {
                    FailTest(GetExceptionInfo(ex));
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0074
        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0072")]
        public void FMUC0023_REG0074()
        {
            try
            {
                // This test case combines with FMUC0023_REG0072
                try
                {
                    Reports.TestDescription = "This test case has been combined with FMUC0023_REG0072";
                    Reports.TestStep = "See test case FMUC0023_REG0072.";
                    Reports.StatusUpdate("See test case FMUC0023_REG0072.", true);
                }
                catch (Exception ex)
                {
                    FailTest(GetExceptionInfo(ex));
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0075
        [TestMethod]
        [Description("BR_FM8010: Create Underwriter Changed event.")]
        public void FMUC0023_REG0075()
        {
            try
            {
                Reports.TestDescription = "BR_FM8010: Create Underwriter Changed event.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create basic order";
                _CreateBasicFile();

                Reports.TestStep = "Change under writer to 'New Underwriter'";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("newunderwriter");
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                string changedValue = FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FAGetSelectedItem();

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Event Tracking log, validate change under writer event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                string expMessage = "File Underwriter changed from <First American Title Insurance Company>to<" + changedValue + ">";
                Support.AreEqual(expMessage, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Underwriter Changed]", 5, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0076
        [TestMethod]
        [Description("BR_FM6069_FM6076: Remove Existing Offset / Proration Amounts.")]
        public void FMUC0023_REG0076()
        {
            try
            {
                Reports.TestDescription = "BR_FM6069_FM6076: Remove Existing Offset / Proration Amounts.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create as Escrow only file";
                _CreateBasicEscrowFile();

                Reports.TestStep = "Enter Details for Utility.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText("UTILITY");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.UtilityDetail.ProrationAmount.FASetText("50.00" + FAKeys.Tab);
                FastDriver.UtilityDetail.FromDate.FASetText("07-17-2013" + FAKeys.Tab);
                FastDriver.UtilityDetail.ToDate.FASetText("07-17-2014" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create offset adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("50.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Homepage, add sub escrow to file";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.SubEscrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate the Proration section is disabled for Subescrow file.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.UtilityDetail.CreditSeller.IsEnabled().ToString(), true);
                Support.AreEqual("False", FastDriver.UtilityDetail.ProrationAmount.IsEnabled().ToString(), true);
                Support.AreEqual("False", FastDriver.UtilityDetail.FromDate.IsEnabled().ToString(), true);
                Support.AreEqual("False", FastDriver.UtilityDetail.ToDate.IsEnabled().ToString(), true);

                Reports.TestStep = "Navigate to File Homepage, Remove sub escrow";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate data is not restored on Utility screen";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.UtilityDetail.CreditSeller.IsSelected().ToString(), true);
                Support.AreEqual(string.Empty, FastDriver.UtilityDetail.ProrationAmount.FAGetValue(), true);
                Support.AreEqual(string.Empty, FastDriver.UtilityDetail.FromDate.FAGetValue(), true);
                Support.AreEqual(string.Empty, FastDriver.UtilityDetail.ToDate.FAGetValue(), true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0077
        [TestMethod]
        [Description("BR_FM6070_FM6071_FM6073: Convert Buyer/Seller Charges/Credits to File Charges/Credits.")]
        public void FMUC0023_REG0077()
        {
            try
            {
                double buyerCharge = 1.99;
                double sellerCharge = 2.99;
                double buyerTaxes = 0;
                double sellerTaxes = 0;

                Reports.TestDescription = "BR_FM6070_FM6071_FM6073: Convert Buyer/Seller Charges/Credits to File Charges/Credits.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create as basic title only file";
                _CreateBasicTitleFile();

                Reports.TestStep = "Add a Title and Escrow Fee to file";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                string TitleFeeName = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 4, TableAction.SetText, buyerCharge.ToString("F2"));
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 7, TableAction.SetText, sellerCharge.ToString("F2"));
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                buyerTaxes = double.Parse(FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Trim());
                sellerTaxes = double.Parse(FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 8, TableAction.GetInputValue).Message.Trim());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate File balance summary after Entering Fee.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("Buyer's Funds Due:", FastDriver.EscrowFileBalanceSummary.BuyerFundsDueLabel.FAGetText().Clean());
                Support.AreEqual((buyerCharge + buyerTaxes).ToString("F2"), FastDriver.EscrowFileBalanceSummary.BuyerFundsDueAmount.FAGetText().Clean());

                Reports.TestStep = "Navigate to File Homepage screen, add Sub Escrow to the file";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.SubEscrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to File Balance Summary, validate buyer's charge has changed to file's charge.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("Funds Due", FastDriver.EscrowFileBalanceSummary.BuyerFundsDueLabel.FAGetText().Clean());
                Support.AreEqual((buyerCharge + buyerTaxes + sellerCharge + sellerTaxes).ToString("F2"), FastDriver.EscrowFileBalanceSummary.BuyerFundsDueAmount.FAGetText().Clean());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0078
        [TestMethod]
        [Description("BR_FM6072: Change Deposit Crediting to 'Other'.")]
        public void FMUC0023_REG0078()
        {
            try
            {
                Reports.TestDescription = "BR_FM6072: Change Deposit Crediting to 'Other'.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create as basic Escrow only file";
                _CreateBasicEscrowFile();

                Reports.TestStep = "Navigate to Deposit In Escrow screeen.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a cash deposit.";
                var deposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.PrintDlg.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);

                Reports.TestStep = "Navigate to File Homepage screen, add Sub Escrow to the file";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.SubEscrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Deposit/Receipt History screen, click View Details button";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, "1,000.00", 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.FAClick();

                Reports.TestStep = "Validate the 'For Credit to:' has been changed to 'Other'";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.DepositInEscrow.CredittoOther.IsSelected().ToString(), true);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0079
        [TestMethod]
        [Description("BR_FM5513: Maintain Non-Default Transfer Tax and Recording Payees.")]
        public void FMUC0023_REG0079()
        {
            try
            {
                Reports.TestDescription = "BR_FM5513: Maintain Non-Default Transfer Tax and Recording Payees.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create as basic Title & Escrow file";
                _CreateBasicFile();

                Reports.TestStep = "Navigate to Fee Entry screen, add Recodring and Tax fee";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 5, TableAction.SetText, "2.99");
                string RecordingFeeName = FastDriver.FileFees.RecordingTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.FileFees.PayRecordingTax.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad();
                FastDriver.RecordFeeTransferTaxDisb.New.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.GABcode.FASetText("247");
                FastDriver.RecordFeeTransferTaxDisb.Find.FAClick();
                string payeeName = FastDriver.RecordFeeTransferTaxDisb.NameLabel.FAGetText().Clean();
                FastDriver.RecordFeeTransferTaxDisb.All.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to File Homepage, click Change O/O button";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                Reports.TestStep = "Change the Title Owning Office";
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes(); // Do you want to assign those same Workflow Tasks to the new Title owning office?
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Fee Entry screen, click on Recording and Tax tab";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);

                Reports.TestStep = "Validate the system shall preserve the payee.";
                FastDriver.FileFees.PayRecordingTax.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad();
                Support.AreEqual(payeeName, FastDriver.RecordFeeTransferTaxDisb.NameLabel.FAGetText().Clean());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0080
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [Description("BR_FM13337a_13337b_13337c: Prevent Change of Owning Office.")]
        public void FMUC0023_REG0080()
        {
            try
            {
                Reports.TestDescription = "BR_FM13337a_13337b_13337c: Prevent Change of Owning Office.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create as basic Title & Escrow file";
                _CreateBasicFile();

                Reports.TestStep = "Add wire instruction to Doc Rep";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad().Upload.FAClick();
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FADoubleClick();

                Playback.Wait(500);
                FastDriver.OpenImageDlg.UploadImage(filePath);
                Playback.Wait(500);

                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);

                Reports.TestStep = "Navigate to Deposit In Escrow screeen.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a cash deposit.";
                var deposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.PrintDlg.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);

                Reports.TestStep = "Navigate to Home Warranty screen, add a charge";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HW1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("7.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen, select the pending charge, click Edit";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "7.99", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Change fee from Check to Wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys("Wire");
                FastDriver.EditDisbursement.Add.FAClick();
                FastDriver.SelectWireInstructionsDlg.SelectWireInstruction();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.WaitCreation(FastDriver.EditDisbursement.ReceivingBankABANumber);
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disbure the wire";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "7.99", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Homepage, validate Change O/O button is disabled [US#686119 - TC#774074: System shall disable Change O/O button when wire is disburse in file]";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.FileHomepage.ChangeOO.IsEnabled().ToString(), true);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0081
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [Description("BR_FM13575: FACC Endorsements when Business Segment is changed.")]
        public void FMUC0023_REG0081()
        {
            try
            {
                Reports.TestDescription = "BR_FM13575: FACC Endorsements when Business Segment is changed.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create as Commercial file";
                _CreateCommercialFile();

                Reports.TestStep = "Calculate Recording Fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesRecordingDocument);
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItemBySendingKeys("deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("3" + FAKeys.Tab);

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAdd);
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Create charge for buyer with Deed";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItemByIndex(1);
                FastDriver.CalculateFees.SummaryChargeTo.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryFastFeeDescription2.FASelectItemByIndex(1); ;
                FastDriver.CalculateFees.SummaryChargeTo2.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryFastFeeDescription3.FASelectItemByIndex(1); ;
                FastDriver.CalculateFees.SummaryChargeTo3.FASelectItem("Buyer");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Homepage, change Business Segment to 'Residential'";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Fee Entry screen | Recording and Tax tab";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);

                Reports.TestStep = "Open Payment Details dialog, validate Fee description is enabled and Additional Description is enabled";
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.Description.IsEnabled().ToString(), true);
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.AdditionalDescription.IsEnabled().ToString(), true);
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("Additional Description");
                FastDriver.DialogBottomFrame.ClickDone();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0082
        [TestMethod]
        [Description("FM14913: Link to Infodex on the Title(Blue) Bar")]
        public void FMUC0023_REG0082()
        {
            try
            {
                Reports.TestDescription = "FM14913: Link to Infodex on the Title(Blue) Bar";
                Reports.TestStep = "Can't test this scenario in test region, only available in Southeast region.";
                Reports.StatusUpdate("Can't test this scenario in test region, only available in Southeast region.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region FMUC0023_REG0083
        [TestMethod]
        [Description("FM14913: Link to Infodex on the Title(Blue) Bar")]
        public void FMUC0023_REG0083()
        {
            try
            {
                Reports.TestDescription = "FM14913: Link to Infodex on the Title(Blue) Bar";
                Reports.TestStep = "Can't test this scenario in test region, only available in Southeast region.";
                Reports.StatusUpdate("Can't test this scenario in test region, only available in Southeast region.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region FMUC0023_REG0085
        [TestMethod]
        [Description("FM4387: Order Source.")]
        public void FMUC0023_REG0085()
        {
            //Combine test case FMUC0023_REG0085 & FMUC0023_REG0086 & FMUC0023_REG0087
            try
            {
                Reports.TestDescription = "FM4387: Order Source.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with order source = 'WINTRACK'";
                _CreateBasicFileWithSpecifiedOrderSource("WINTRACK");

                Reports.TestStep = "Navigate to File Homepage screen, validate order source = 'WINTRACK'";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.OrderSourceInfoExpandIcon.FAClick();
                FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.OrderSource);
                Support.AreEqual("WINTRACK", FastDriver.FileHomepage.OrderSource.FAGetText().Clean());
                //Start test case FMUC0023_REG0086
                Support.AreEqual("123456789", FastDriver.FileHomepage.ExternalFileNo.FAGetText().Clean());

                //Start test case FMUC0023_REG0085
                Reports.TestStep = "Validate order source icon is displayed on the FAST title bar";
                FastDriver.FileHomepage.SwitchToTitleFrame();
                Support.AreEqual("Wintrack", FastDriver.FileHomepage.OrderSourceIconOnTitleBar.FAGetAttribute("title"));

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0086
        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0084")]
        public void FMUC0023_REG0086()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0085";
                Reports.TestStep = "See test case FMUC0023_REG0085.";
                Reports.StatusUpdate("See test case FMUC0023_REG0085.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region FMUC0023_REG0087
        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0085")]
        public void FMUC0023_REG0087()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0085";
                Reports.TestStep = "See test case FMUC0023_REG0085.";
                Reports.StatusUpdate("See test case FMUC0023_REG0085.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0088
        [TestMethod]
        [Description("FM13818: Order Originator of File Homepage.")]
        public void FMUC0023_REG0088()
        {
            try
            {
                try
                {
                    Reports.TestDescription = "FM13818: Order Originator of File Homepage.";
                    Reports.TestStep = "Will implement this test case when this method is added to WCF service (ETA mid 2016)";
                    Reports.StatusUpdate("Will implement this test case when this method is added to WCF service (ETA mid 2016)", true);
                }
                catch (Exception ex)
                {
                    FailTest(GetExceptionInfo(ex));
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0089
        [TestMethod]
        [Description("FM13819: Display Order Originator icon on FAST Title Bar.")]
        public void FMUC0023_REG0089()
        {
            try
            {
                Reports.TestDescription = "FM13819: Display Order Originator icon on FAST Title Bar.";
                Reports.TestStep = "Will implement this test case when this method is added to WCF service (ETA mid 2016)";
                Reports.StatusUpdate("Will implement this test case when this method is added to WCF service (ETA mid 2016)", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region FMUC0023_REG0090
        [TestMethod]
        [Description("FM6782: Sort Order for Production Offices and Production Centers.")]
        public void FMUC0023_REG0090()
        {
            try
            {
                Reports.TestDescription = "FM6782: Sort Order for Production Offices and Production Centers.";

                Reports.TestStep = "Log in ADM site.";
                _ADMLOGIN();

                Reports.TestStep = "Navigate to Office Setup screen, obtain Escrow and Title production offices";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                string escrowProOffice1 = FastDriver.OfficeSetupOffice.EscrowOfficeTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean().Trim();
                string escrowProOffice2 = FastDriver.OfficeSetupOffice.EscrowOfficeTable.PerformTableAction(3, 1, TableAction.GetText).Message.Clean().Trim();
                string titleProOffice1 = FastDriver.OfficeSetupOffice.TitleOfficeTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean().Trim();
                string titleProOffice2 = FastDriver.OfficeSetupOffice.TitleOfficeTable.PerformTableAction(3, 1, TableAction.GetText).Message.Clean().Trim();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic file";
                _CreateBasicFile();

                Reports.TestStep = "Navigate to File Homepage screen, validate the order of Escrow & Title production offices";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(escrowProOffice1, getProdOfficeName(FastDriver.FileHomepage.EscrowProdOfficeTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean()));
                Support.AreEqual(escrowProOffice2, getProdOfficeName(FastDriver.FileHomepage.EscrowProdOfficeTable.PerformTableAction(3, 1, TableAction.GetText).Message.Clean()));
                Support.AreEqual(titleProOffice1, getProdOfficeName(FastDriver.FileHomepage.TitleProdOfficeTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean()));
                Support.AreEqual(titleProOffice2, getProdOfficeName(FastDriver.FileHomepage.TitleProdOfficeTable.PerformTableAction(3, 1, TableAction.GetText).Message.Clean()));

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0091
        [TestMethod]
        [Description("FM8115: Enable Manual Publishing to Agent First.")]
        public void FMUC0023_REG0091()
        {
            try
            {
                Reports.TestDescription = "FM8115: Enable Manual Publishing to Agent First.";

                Reports.TestStep = "Log in ADM site.";
                _ADMLOGIN();

                Reports.TestStep = "Navigate to Office Setup screen, search for GAB 'HUDWDINSR1', click Edit";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText("HUDWDINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Click View/Add Contact, and select the first contact, double click";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                string contactFirstName = FastDriver.BusPartyContactsList.ContactList.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                string contactLastName = FastDriver.BusPartyContactsList.ContactList.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                FastDriver.BusPartyContactsList.ContactList.PerformTableAction(2, 1, TableAction.DoubleClick);

                Reports.TestStep = "Click External Customer, check the AGENTFIRST checkbox";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.ExternalCustomer.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("External Customer", true, 20);
                FastDriver.ExternalCustomerDlg.WaitForScreenToLoad();
                FastDriver.ExternalCustomerDlg.AgentFirst.FASetCheckbox(true);

                Reports.TestStep = "Click Done, Done, Done to close out";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic file using GAB 'HUDWDINSR1'";
                _CreateBasicFileWithSpecifiedGAB("HUDWDINSR1");

                Reports.TestStep = "Navigate to File Homepage screen, select contact from Attention dropdown list | Business Source";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyAttention.FASelectItemBySendingKeys(contactLastName + ", " + contactFirstName);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate Publish File button is displayed on File Homepage screen";
                Support.AreEqual("True", FastDriver.FileHomepage.PublishFile.IsDisplayed().ToString(), true);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0092
        [TestMethod]
        [Description("FM9715: Non-Validation of Program Type components after File Creation.")]
        public void FMUC0023_REG0092()
        {
            try
            {
                Reports.TestDescription = "FM9715: Non-Validation of Program Type components after File Creation.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic file";
                _CreateBasicFile();

                Reports.TestStep = "Navigate to File Homepage screen, select '++View More...' from Program Type";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProgramType.FASelectItemBySendingKeys("++View More...");
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad();

                Reports.TestStep = "Select 'Program' name";
                FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction(2, "Program", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ProgramType.FASelectItemBySendingKeys("Program");
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ProductsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate file save with selected Program Type";
                Support.AreEqual("Program", FastDriver.FileHomepage.ProgramType.FAGetSelectedItem(), true);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0093
        [TestMethod]
        [Description("FM12637: Display PT in Program Type field - File created via interface.")]
        public void FMUC0023_REG0093()
        {
            try
            {
                Reports.TestDescription = "FM12637: Display PT in Program Type field - File created via interface.";

                Reports.TestStep = "Log in ADM site.";
                _ADMLOGIN();

                Reports.TestStep = "Navigate to Office Setup screen, search for GAB '1256', click Edit";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText("1256");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(2, 1, TableAction.DoubleClick);
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                string GABName = FastDriver.BusPartyOrgSetUp.Name1.FAGetValue().Clean();

                Reports.TestStep = "Navigate to Program Type screen, clear exsiting program type";
                FastDriver.LeftNavigation.Navigate<ProgramTypes>(GABName + ">Program Type").WaitForScreenToLoad();
                FastDriver.ProgramTypes.AddRemove.FAClick();
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad("Program Types");
                FastDriver.ProgramTypesDlg.Clear.FAClick();

                Reports.TestStep = "Select the first two program names";
                string programName = "Program";
                FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction(2, programName, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.ProgramTypes.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with GAB='1256'";
                _CreateBasicFileWithSpecifiedGAB("1256");

                Reports.TestStep = "Navigate to File Homepage screen, validate program names";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                string PTOptions = FastDriver.FileHomepage.ProgramType.FAGetAllTextFromSelect();
                Support.AreEqual("True", PTOptions.Contains(programName).ToString(), true);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0094
        [TestMethod]
        [Description("FM9818: Update History for EM flag conversion.")]
        public void FMUC0023_REG0094()
        {
            try
            {
                Reports.TestDescription = "FM9818: Update History for EM flag conversion.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order";
                _CreateBasicFile();

                Reports.TestStep = "Navigate to File Homepage screen, get the first business program name";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                string programName = FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Remove the first program name";
                FastDriver.FileHomepage.AddRemoveBusPrograms.FAClick();
                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();
                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, programName, 1, TableAction.Off);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Open Business Program History screen, validate the removed event.";
                FastDriver.FileHomepage.History.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Business Program History", true, 20);
                FastDriver.BusinessProgramsHistoryDlg.WaitForScreenToLoad();
                Support.AreEqual(programName, FastDriver.BusinessProgramsHistoryDlg.BusinessProgramsHistory.PerformTableAction(1, "Removed", 5, TableAction.GetText).Message.Clean(), true);
                FastDriver.DialogBottomFrame.ClickDone();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0095
        [TestMethod]
        [Description("FM4772: Reassign Active Tasks.")]
        public void FMUC0023_REG0095()
        {
            try
            {
                Reports.TestDescription = "FM9818: Update History for EM flag conversion.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order";
                _CreateBasicFile();

                Reports.TestStep = "Navigate to File Workflow screen, assign user to first task";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad(FastDriver.FileWorkflow.CollapseAll);
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);

                Reports.TestStep = "Assign to an employee.";
                FastDriver.FileWorkflow.ProcessActiveTable(4, "1", 11, TableAction.Click);
                FastDriver.FileWorkflow.SelAssgTo.FASelectItemBySendingKeys("*");

                Reports.TestStep = "Click Apply.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to File Homepage screen, remove Escrow service";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to File Workflow screen, validate the task is unassigned";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad(FastDriver.FileWorkflow.CollapseAll);
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                Support.AreEqual(string.Empty, FastDriver.FileWorkflow.SelAssgTo.FAGetSelectedItem());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0096
        [TestMethod]
        [Description("FM5133: Cannot update 'Business Segment' field when Property Type value TBD.")]
        public void FMUC0023_REG0096()
        {
            try
            {
                Reports.TestDescription = "FM5133: Cannot update 'Business Segment' field when Property Type value TBD.";
                Reports.TestStep = "Can't test this scenario. The 'TBD' value under Property Type only occur during data conversion of the Salse Rep enhancement.";
                Reports.StatusUpdate("Can't test this scenario. The 'TBD' value under Property Type only occur during data conversion of the Salse Rep enhancement.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0097
        [TestMethod]
        [Description("FM6562: Correct a 1099-S Record After Changing Owning Office.")]
        public void FMUC0023_REG0097()
        {
            try
            {
                Reports.TestDescription = "FM6562: Correct a 1099-S Record After Changing Owning Office.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Sellers[0].SSN = "111-11-1111";
                fileRequest.File.Sellers[0].LastName1099S = "1099S";
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, set order received date/time";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.OrderRecievedDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.OrderRecievedTime.FASetText("09:00 AM PST" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Sellers screen, set 1099-S Classification";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItemBySendingKeys("1099-S" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to 1099-S screen, create a new 1099-S";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("200,000.00" + FAKeys.Tab);
                FastDriver._1099S.ActiveReadyForExtract.FASetCheckbox(true);
                FastDriver._1099S.ActiveAddress.FASetText("2 First American Way" + FAKeys.Tab);
                FastDriver._1099S.ActiveCity.FASetText("Santa Ana" + FAKeys.Tab);
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("CA");
                FastDriver._1099S.ActiveZip.FASetText("92704" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver._1099S.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to File Homepage screen, change Escrow owning office [US#686119 - TC#744137: System shall not allow changing owing office if file has 1099-S record]";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                string expMessage = "Service File: File has 1099-S records. You cannot change Owning Office to an office that does not have a 1099-S Activity Date in Office Setup";
                Support.AreEqual(expMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.ErrorMessagePane.FAGetText().Clean());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0098
        [TestMethod]
        [Description("FM13337b_FM13337c: Prevent Change of Owning Office.")]
        public void FMUC0023_REG0098()
        {
            try
            {
                Reports.TestDescription = "FM13337b_FM13337c: Prevent Change of Owning Office.";
                Reports.TestStep = "Covered in test case FMUC0023_REG0080";
                Reports.StatusUpdate("Covered in test case FMUC0023_REG0080", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0099
        [TestMethod]
        [Description("FM13338: Allow Change of Owning Office.")]
        public void FMUC0023_REG0099()
        {
            try
            {
                Reports.TestDescription = "FM13338: Allow Change of Owning Office.";
                Reports.TestStep = "Can't automate this BR because it requires wire be confirmed by WireLink.";
                Reports.StatusUpdate("Can't automate this BR because it requires wire be confirmed by WireLink.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0100
        [TestMethod]
        [Description("FM5503_FM5504: Remove/Replace Default Transfer Tax and Recording Payees.")]
        public void FMUC0023_REG0100()
        {
            try
            {
                Reports.TestDescription = "FM5503_FM5504: Remove/Replace Default Transfer Tax and Recording Payees.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order";
                _CreateBasicFile();

                Reports.TestStep = "Add a Recording and Tax Fee to file";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 5, TableAction.SetText, "2.99");
                string RecordingFeeName = FastDriver.FileFees.RecordingTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to File Homepage screen, change Escrow owning office";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItemByIndex(2);
                string escrowOfficeName = FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FAGetSelectedItem().Clean().Split(':')[0];
                escrowOfficeName = escrowOfficeName.Substring(0, escrowOfficeName.Length - 3);
                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();

                Reports.TestStep = "Navigate to Fee Entry screen, click on Recording and Tax tab";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);

                Reports.TestStep = "Validate default payee on Payment Details dialog";
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, RecordingFeeName, 3, TableAction.Click);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                Support.AreEqual(escrowOfficeName, FastDriver.PaymentDetailsDlg.PayTo.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0101
        [TestMethod]
        [Description("FM5139_FM5137_FM3179: Default Service Type.")]
        public void FMUC0023_REG0101()
        {
            try
            {
                Reports.TestDescription = "FM5139_FM5137_FM3179: Default Service Type.";
                Reports.TestStep = "Covered by test case FMUC0023_REG0072";
                Reports.StatusUpdate("Covered by test case FMUC0023_REG0072", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region FMUC0023_REG0104
        [TestMethod]
        [Description("ER4: User is attempting to save without indicating a Product.")]
        public void FMUC0023_REG0104()
        {
            try
            {
                Reports.TestDescription = "ER4: User is attempting to save without indicating a Product.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Navigate to Quick File Entry screen, click Skip Search.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                Reports.TestStep = "Enter file details information.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, "*ALTA Expanded (Eagle Loan) Policy", 1, TableAction.Off);
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Product Type is required", FastDriver.WebDriver.HandleDialogMessage());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0105
        [TestMethod]
        [Description("ER6_ER7: User updates the file and navigates off the File Homepage screen without indicating the data is to be saved.")]
        public void FMUC0023_REG0105()
        {
            try
            {
                Reports.TestDescription = "ER6_ER7: User updates the file and navigates off the File Homepage screen without indicating the data is to be saved.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order";
                _CreateBasicFile();

                Reports.TestStep = "Navigate to File Homepage screen, change business segment";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessSegment.FASelectItemBySendingKeys("Subdivision");

                Reports.TestStep = "Navigate away from File Homepage without saving, validate error message";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home");
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true));
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0106
        [TestMethod]
        [Description("ER8: User tries to save a Title Service type order with a blank Title Underwriter field.")]
        public void FMUC0023_REG0106()
        {
            try
            {
                Reports.TestDescription = "ER8: User tries to save a Title Service type order with a blank Title Underwriter field.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Navigate to Quick File Entry screen, click Skip Search.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                Reports.TestStep = "Try to create a Title file without Title Underwriter";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Underwriter is required", FastDriver.WebDriver.HandleDialogMessage(false, true, 20, true));

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0107
        [TestMethod]
        [Description("ER15: User modifies the file on the File Home Page and clicks on Reset.")]
        public void FMUC0023_REG0107()
        {
            try
            {
                Reports.TestDescription = "ER15: User modifies the file on the File Home Page and clicks on Reset.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order";
                _CreateBasicFile();

                Reports.TestStep = "Navigate to File Homepage screen, change business segment";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessSegment.FASelectItemBySendingKeys("Subdivision");

                Reports.TestStep = "Click Reset button, validate warning message";
                FastDriver.BottomFrame.Reset();
                Support.AreEqual("All modified information will be erased for this order. Do you wish to cancel this entry?", FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true).Clean());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0108
        [TestMethod]
        [Description("ER25: User tries to change a Business Party which has a Reference number specified against it.")]
        public void FMUC0023_REG0108()
        {
            try
            {
                Reports.TestDescription = "ER25: User tries to change a Business Party which has a Reference number specified against it.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a file with reference number on business source";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceReference.FASetText("12345");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Homepage, change business source GAB";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number. Do you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true).Clean());
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0109
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [Description("ER18_FM10520: The user attempts to change an authorized FACC Underwriter after a Fee(s) has been calculated.")]
        public void FMUC0023_REG0109()
        {
            try
            {
                Reports.TestDescription = "ER18_FM10520: The user attempts to change an authorized FACC Underwriter after a Fee(s) has been calculated.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create as Commercial file";
                _CreateCommercialFile();

                Reports.TestStep = "Calculate Recording Fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesRecordingDocument);
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItemBySendingKeys("deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("3" + FAKeys.Tab);

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAdd);
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Create charge for buyer with Deed";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItemByIndex(1);
                FastDriver.CalculateFees.SummaryChargeTo.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryFastFeeDescription2.FASelectItemByIndex(1); ;
                FastDriver.CalculateFees.SummaryChargeTo2.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryFastFeeDescription3.FASelectItemByIndex(1); ;
                FastDriver.CalculateFees.SummaryChargeTo3.FASelectItem("Buyer");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Homepage, change Title Underwriter";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("New Underwriter");
                string expMessage = @"Existing Underwriter/Agent premium splits will be recalculated based on the new Underwriter's premium split percentage. If you have previously edited Underwriter/Agent Details, please review to ensure the recalculated amounts are correct. Continue?";
                Support.AreEqual(expMessage, FastDriver.WebDriver.HandleDialogMessage(true, false, 10, true).Clean());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region FMUC0023_REG0110
        [TestMethod]
        [Description("ER19_FM10520: The user attempts to change an unauthorized FACC Underwriter after a Fee(s) have been manually entered.")]
        public void FMUC0023_REG0110()
        {
            try
            {
                Reports.TestDescription = "ER19_FM10520: The user attempts to change an unauthorized FACC Underwriter after a Fee(s) have been manually entered.";

                Reports.TestStep = "Log into FAST application.";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order";
                _CreateBasicFile();

                Reports.TestStep = "Add a Recording and Tax Fee to file";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to File Homepage screen, change title underwriter to an unauthorized FACC underwriter";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("New Underwriter");

                Reports.TestStep = "Validate warning message";
                string expMessage = @"Existing Underwriter/Agent premium splits will be recalculated based on the new Underwriter's premium split percentage. If you have previously edited Underwriter/Agent Details, please review to ensure the recalculated amounts are correct. Continue?";
                Support.AreEqual(expMessage, FastDriver.WebDriver.HandleDialogMessage(true, false, 10, true).Clean());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        [TestMethod]
        [Description("ER20: The user attempts to change the Product information after a Fee has been calculated.")]
        public void FMUC0023_REG0111()
        {
            //This test case has been combined with FMUC0023_REG0112
            try
            {
                Reports.TestDescription = "ER20: The user attempts to change the Product information after a Fee has been calculated.";

                #region ER20: The user attempts to change the Product information after a Fee has been calculated.

                Reports.TestStep = "ER20: The user attempts to change the Product information after a Fee has been calculated.";
                Reports.StatusUpdate("ER20: The user attempts to change the Product information after a Fee has been calculated.", true);

                #region Login To ISS
                Reports.TestStep = " Login To ISS.";
                _IISLOGIN();
                #endregion

                #region create file
                _CreateBasicFile();
                #endregion

                Reports.TestStep = "Select HUD and enter charges.";
                FastDriver.NewLoan.Open();

                FastDriver.NewLoan.FindGABCode("HUDFLINSR1");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500.00");
                FastDriver.BottomFrame.Done();

                #region Deposit a Cash on behalf of Buyer
                Reports.TestStep = "Deposit a cash for 8000$.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 8000;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();

                Reports.TestStep = "Add Endorsement Fee.";
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();

                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction(2, "[ALTA 3-06] Zoning - unimproved land", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("3");

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.Next.FAClick();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAnswersTable);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select View More option.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Eagle Lender Policy - 1");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.ClickOnFeeResultCheckbox(0);

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select View More option for the last fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                var selectElement = FastDriver.CalculateFees.SummaryTable.PerformTableAction(FastDriver.CalculateFees.SummaryTable.GetRowCount(), 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "select");
                selectElement.FASelectItemByIndex(selectElement.FAGetDropdownOptions().Count - 1);

                Reports.TestStep = "Select mortgage fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem(@"Recording Fee - Deed");
                //Record Deed for CD and 1064_Recording_Fee_Deed for HUD
                string selectedFee = AutoConfig.FormType == "CD" ? "Record Deed" : "1064_Recording_Fee_Deed";
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(selectedFee);
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(2, selectedFee, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Descriptions For the Fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                int SummaryTableRowCount = FastDriver.CalculateFees.SummaryTable.GetRowCount();

                if (SummaryTableRowCount >= 3)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 4, TableAction.SelectItemByIndex, "1");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 5, TableAction.SelectItem, "Seller");
                }

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(SummaryTableRowCount, 5, TableAction.SelectItem, "Seller");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.FileHomepage.AddFileProduct("*ALTA Homeowners (Eagle Owner) Policy");

                Reports.TestStep = "Deselect the second product.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ProductCheckbox(0).FASetCheckbox(false);
                Support.AreEqual(@"This Product is associated with one or more fee(s) that have calculated rate(s). All Title and Endorsement fees associated with this product will be removed. Do you wish to continue?", FastDriver.WebDriver.HandleDialogMessage().Replace("\n", string.Empty).Replace("\r", string.Empty));

                Reports.TestStep = "Wait and Click on Save";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the TitleFee and Endorsement is removed.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                Support.AreEqual(true.ToString(), (FastDriver.CalculateFees.SummaryTable.GetRowCount() == 2).ToString(), " Calucalted fees Summary Table only has 1 fee");

                #endregion

                #region ER21: The user attempts to change the Transaction Type after a Fee has been calculated
                Reports.TestStep = "ER21: The user attempts to change the Transaction Type after a Fee has been calculated.";
                Reports.StatusUpdate("ER21: The user attempts to change the Transaction Type after a Fee has been calculated.", true);

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Chang the Transaction type when FACC fees exists in file.";
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Bulk Sale");

                Reports.TestStep = "Change transaction type associated with calculated policy.";
                Support.AreEqual(@"Changing the Transaction Type will result in removal of all calculated Recording and Transfer Tax fees. Do you wish to continue?", FastDriver.WebDriver.HandleDialogMessage().Replace("\n", string.Empty).Replace("\r", string.Empty));

                Reports.TestStep = "Wait and Click on Save";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the Recording fees is removed.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FastDriver.CalculateFees.SwitchToContentFrame();

                Support.AreEqual(false.ToString(), FastDriver.CalculateFees.SummaryTable.IsDisplayed().ToString(), "Calulated fees summary table does not have any fee");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0111")]
        public void FMUC0023_REG0112()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0111";
                Reports.TestStep = "See test case FMUC0023_REG0111.";
                Reports.StatusUpdate("See test case FMUC0023_REG0111.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("ER22_FM10519: The user attempts to change the Product after a fee has been issued && ER23_FM10519: The user attempts to change the Transaction Type after a fee has been issued && EER24_FM10519: The user attempts to change the Underwriter after a fee has been issued.")]
        public void FMUC0023_REG0113()
        {
            //This test case has been combined with FMUC0023_REG0114 and FMUC0023_REG0115

            try
            {
                Reports.TestDescription = "ER22_FM10519: The user attempts to change the Product after a fee has been issued && ER23_FM10519: The user attempts to change the Transaction Type after a fee has been issued && EER24_FM10519: The user attempts to change the Underwriter after a fee has been issued.";

                #region ER22_FM10519: The user attempts to change the Product after a fee has been issued.

                Reports.TestStep = "ER22_FM10519: The user attempts to change the Product after a fee has been issued.";
                Reports.StatusUpdate("ER22_FM10519: The user attempts to change the Product after a fee has been issued.", true);

                #region Login To ISS
                Reports.TestStep = " Login To ISS.";
                _IISLOGIN();
                #endregion

                #region create file
                _CreateBasicFile();
                #endregion

                Reports.TestStep = "Select HUD and enter charges.";
                FastDriver.NewLoan.Open();

                FastDriver.NewLoan.FindGABCode("HUDFLINSR1");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500.00");
                FastDriver.BottomFrame.Done();

                #region Deposit a Cash on behalf of Buyer
                Reports.TestStep = "Deposit a cash for 8000$.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 8000;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();

                Reports.TestStep = "Add Endorsement Fee.";
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();

                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction(2, "[ALTA 3-06] Zoning - unimproved land", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("2");

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.Next.FAClick();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAnswersTable);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select View More option.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Eagle Lender Policy - 1");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.ClickOnFeeResultCheckbox(0);

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select View More option for the last fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(FastDriver.CalculateFees.SummaryTable.GetRowCount(), 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select mortgage fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem(@"Recording Fee - Deed");
                //Record Deed for CD and 1064_Recording_Fee_Deed for HUD
                string selectedFee = AutoConfig.FormType == "CD" ? "Record Deed" : "1064_Recording_Fee_Deed";
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(selectedFee);
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(2, selectedFee, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Descriptions For the Fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                int SummaryTableRowCount = FastDriver.CalculateFees.SummaryTable.GetRowCount();

                if (SummaryTableRowCount >= 3)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 4, TableAction.SelectItemByIndex, "1");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 5, TableAction.SelectItem, "Seller");
                }

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(SummaryTableRowCount, 5, TableAction.SelectItem, "Seller");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Fee Transfer Button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(5000);

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Deselect the product and do not save.";
                FastDriver.FileHomepage.ProductCheckbox(0).FASetCheckbox(false);
                Support.AreEqual("Product is associated with a fee that has been disbursed. Product Information cannot be  modified. Cancel Issued Disbursements before proceeding with changes.", FastDriver.WebDriver.HandleDialogMessage().Replace("\n", string.Empty).Replace("\r", string.Empty));
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                #region ER23_FM10519: The user attempts to change the Transaction Type after a fee has been issued.
                Reports.TestStep = "ER23_FM10519: The user attempts to change the Transaction Type after a fee has been issued.";
                Reports.StatusUpdate("ER23_FM10519: The user attempts to change the Transaction Type after a fee has been issued.", true);

                Reports.TestStep = "Chang the Transaction type when FACC fees exists in file.";
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Bulk");

                Reports.TestStep = "Change transaction type associated with issued calculated policy.";
                Support.AreEqual("Transaction Type is associated with a fee that has been disbursed. Transaction Type  Information cannot be modified. Cancel Issued Disbursements before proceeding with changes", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Replace("\n", string.Empty).Replace("\r", string.Empty));
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                #region EER24_FM10519: The user attempts to change the Underwriter after a fee has been issued
                Reports.TestStep = "ER24_FM10519: The user attempts to change the Underwriter after a fee has been issued.";
                Reports.StatusUpdate("ER24_FM10519: The user attempts to change the Underwriter after a fee has been issued.", true);

                Reports.TestStep = "Change UW associated with issued calculated policy.";
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("New Underwriter");

                Reports.TestStep = "Change transaction type associated with issued calculated policy.";
                Support.AreEqual("Underwriter is associated with a fee that has been disbursed. Underwriter Information cannot be modified.Cancel Issued Disbursements before proceeding with changes.", FastDriver.WebDriver.HandleDialogMessage().Replace("\n", string.Empty).Replace("\r", string.Empty));

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0113")]
        public void FMUC0023_REG0114()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0113";
                Reports.TestStep = "See test case FMUC0023_REG0113.";
                Reports.StatusUpdate("See test case FMUC0023_REG0113.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0113")]
        public void FMUC0023_REG0115()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0113";
                Reports.TestStep = "See test case FMUC0023_REG0113.";
                Reports.StatusUpdate("See test case FMUC0023_REG0113.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("ER26_FM13572: User changes the Service Type when Transmitted Service Fees exist.")]
        public void FMUC0023_REG0116()
        {
            try
            {
                Reports.TestDescription = "ER26_FM13572: User changes the Service Type when Transmitted Service Fees exist.";

                #region Login To ISS
                Reports.TestStep = " Login To ISS.";
                _IISLOGIN();
                #endregion

                #region create file
                _CreateBasicFile();
                #endregion

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.ServiceFee.Open();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Select a payee from payee search";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00");

                Reports.TestStep = "Click on Transfer button";
                FastDriver.ServiceFee.Transfer.FAClick();

                #region Remove Escrow
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify error message when Title is removed.";

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("Service File: File has issued fee disbursements. You cannot change the Owning Office or remove Service Type.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("ER27_FM13574: User attempts to change the Business Segment from Non-Commercial to Commercial and the calculated FACC Endorsement fees on the File are not issued && ER28_FM13574_FM13576: User attempts to change the Business Segment from Non-Commercial to Commercial, calculated FACC Endorsement fees on the File are issued and Additional Description exists")]
        public void FMUC0023_REG0117()
        {
            //This test case has been combined with FMUC0023_REG0118
            try
            {
                Reports.TestDescription = "ER27_FM13574: User attempts to change the Business Segment from Non-Commercial to Commercial and the calculated FACC Endorsement fees on the File are not issued &&  ER28_FM13574_FM13576: User attempts to change the Business Segment from Non-Commercial to Commercial, calculated FACC Endorsement fees on the File are issued and Additional Description exists.";

                #region ER27_FM13574: User attempts to change the Business Segment from Non-Commercial to Commercial and the calculated FACC Endorsement fees on the File are not issued.
                Reports.TestStep = "ER27_FM13574: User attempts to change the Business Segment from Non-Commercial to Commercial and the calculated FACC Endorsement fees on the File are not issued.";
                Reports.StatusUpdate("ER27_FM13574: User attempts to change the Business Segment from Non-Commercial to Commercial and the calculated FACC Endorsement fees on the File are not issued.", true);

                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create File";

                _CreateBasicFile();

                #endregion

                Reports.TestStep = "Select HUD and enter charges.";
                FastDriver.NewLoan.Open();

                FastDriver.NewLoan.FindGABCode("HUDFLINSR1");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();

                Reports.TestStep = "Add Endorsement Fee.";
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();

                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction(2, "[ALTA 3-06] Zoning - unimproved land", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("2");

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.Next.FAClick();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAnswersTable);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select View More option.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Eagle Lender Policy - 1");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.ClickOnFeeResultCheckbox(0);

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select View More option for the last fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SelectViewMore(FastDriver.CalculateFees.SummaryTable.PerformTableAction(FastDriver.CalculateFees.SummaryTable.GetRowCount(), 4, TableAction.GetCell).Element);

                Reports.TestStep = "Select mortgage fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem(@"Recording Fee - Deed");
                //Record Deed for CD and 1064_Recording_Fee_Deed for HUD
                string selectedFee = AutoConfig.FormType == "CD" ? "Record Deed" : "1064_Recording_Fee_Deed";
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(selectedFee);
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitForScreenToLoad();

                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(2, selectedFee, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Descriptions For the Fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                int SummaryTableRowCount = FastDriver.CalculateFees.SummaryTable.GetRowCount();

                if (SummaryTableRowCount >= 3)
                {
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 4, TableAction.SelectItemByIndex, "1");
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 5, TableAction.SelectItem, "Seller");
                }

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(SummaryTableRowCount, 5, TableAction.SelectItem, "Seller");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "click on Payment Details button.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 3, TableAction.Click);

                Reports.TestStep = "Enter Additional Description.";
                FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.FeePaymentDetailsDlg.AdditionalDescription.FASetText("AdditionalDescription");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Change Business segment to commercial.";
                FastDriver.FileHomepage.BusinessSegment.FASelectItemBySendingKeys("Commercial");
                Support.AreEqual(@"Changing the Business Segment to Commercial will remove Additional Description of the FACC Endorsement Fees. Do you wish to continue?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "click on Payment Details button.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 3, TableAction.Click);

                Reports.TestStep = "Validate the Additional Description is disabled.";
                FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.FeePaymentDetailsDlg.AdditionalDescription.IsEnabled().ToString());

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region ER28_FM13574_FM13576: User attempts to change the Business Segment from Non-Commercial to Commercial, calculated FACC Endorsement fees on the File are issued and Additional Description exists

                Reports.TestStep = "ER28_FM13574_FM13576: User attempts to change the Business Segment from Non-Commercial to Commercial, calculated FACC Endorsement fees on the File are issued and Additional Description exists.";
                Reports.StatusUpdate("ER28_FM13574_FM13576: User attempts to change the Business Segment from Non-Commercial to Commercial, calculated FACC Endorsement fees on the File are issued and Additional Description exists", true);

                Reports.TestStep = "Override amount for Endorsement.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                FastDriver.CalculateFees.SummaryOverrideReason.FASelectItem("Prepaid Credit");
                FastDriver.CalculateFees.SummaryOverrideAmount.FASetText("100.00");
                FastDriver.BottomFrame.Done();


                #region Deposit a Cash on behalf of Buyer
                Reports.TestStep = "Deposit a cash for 8000$..";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 8000;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                Reports.TestStep = "Click on Fee Transfer Button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(5000);

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Change Business segment to commercial.";
                FastDriver.FileHomepage.BusinessSegment.FASelectItemBySendingKeys("Commercial");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Void Button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();

                Reports.TestStep = "Deposit Summary.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Reason to void the Deposit");
                FastDriver.VoidDlg.OK.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Change Business segment to commercial.";
                FastDriver.FileHomepage.BusinessSegment.FASelectItemBySendingKeys("Commercial");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "click on Payment Details button.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 3, TableAction.Click);

                Reports.TestStep = "Validate the Additional Description is disabled.";
                FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.FeePaymentDetailsDlg.AdditionalDescription.IsEnabled().ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0117")]
        public void FMUC0023_REG0118()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0117";
                Reports.TestStep = "See test case FMUC0023_REG0117.";
                Reports.StatusUpdate("See test case FMUC0023_REG0117.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("ER29: User changes or removes a Product after editing Underwriter/Agent Details in Fee Entry with Edit $ selected and Split $ entered on the Underwriter/Agent Details dialog.")]
        public void FMUC0023_REG0119()
        {
            try
            {
                Reports.TestDescription = "ER29: User changes or removes a Product after editing Underwriter/Agent Details in Fee Entry with Edit $ selected and Split $ entered on the Underwriter/Agent Details dialog.";

                if (AutoConfig.FormType == "CD")
                    throw new NoSuchFormTypeAllowed();

                Reports.TestStep = "Log in to Admin.";
                _ADMLOGIN();

                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                FastDriver.FeeSetup.CheckSubjectToCalculationFee("New Home Rate (Title Only)", "Title - Owners Policy", "All", false);

                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create File";

                _CreateBasicFile();

                #endregion

                Reports.TestStep = "Check the Edit Name Checkbox.";
                FastDriver.FileHomepage.AddFileProduct("Agency File Scanning");

                #region Create a Fee
                Reports.TestStep = "Enter first fee in Title and escrow.";

                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                #endregion

                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.UnderwriterAgentDetail.FAClick();

                Reports.TestStep = "Enter Edit Split$ amount.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                FastDriver.UnderwriterAgentDetailDlg.UnderwriterEditAmt.FASetCheckbox(true);

                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitAmt.FASetText("2.00");
                FastDriver.UnderwriterAgentDetailDlg.Agent1EditAmt.FASetCheckbox(true);
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitAmt.FASetText("2.98");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Deselect the product and do not save.";

                FastDriver.FileHomepage.ProductsTable.PerformTableAction(2, "Agency File Scanning", 1, TableAction.Off);
                Support.AreEqual("Changing the premium fee will remove Underwriter and Agent premium splits. Continue?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Validate the first product is unchecked.";
                FastDriver.BottomFrame.Save();

                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.ProductsTable.FAGetText().Contains("Agency File Scanning").ToString());

                Reports.TestStep = "Click on Underwriter Agent Dialog.";
                FastDriver.FileFees.Open();

                FastDriver.FileFees.UnderwriterAgentDetail.FAClick();

                Reports.TestStep = "Validate the split $ amount remains same.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("24" + FAKeys.Tab);

                Support.AreEqual("1.20", FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitAmt.FAGetValue());

                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("76" + FAKeys.Tab);

                Support.AreEqual("3.78", FastDriver.UnderwriterAgentDetailDlg.Agent1SplitAmt.FAGetValue());

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Filehomepage to navigate away.";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Chang products.";
                FastDriver.FileHomepage.AddFileProduct("Agency File Scanning");

                Reports.TestStep = "Deselect the product and do not save.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ProductsTable.PerformTableAction(2, "Agency File Scanning", 1, TableAction.Off);

                Reports.TestStep = "Validate the first product is unchecked.";
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.ProductCheckbox(0).IsSelected().ToString());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Underwriter Agent Dialog.";
                FastDriver.FileFees.Open();

                FastDriver.FileFees.UnderwriterAgentDetail.FAClick();

                Reports.TestStep = "Validate the split $ is removed.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("24" + FAKeys.Tab);


                Support.AreEqual(false.ToString(), FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitAmt.IsEnabled().ToString(), "Verify UnderwriterSplitAmt is enabled");
                Support.AreEqual(false.ToString(), FastDriver.UnderwriterAgentDetailDlg.Agent1SplitAmt.IsEnabled().ToString(), "Verify Agent1SplitAmt is enabled");
                Support.AreEqual("76.0000", FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FAGetValue(), "Verify Agent1SplitPercent");

            }
            catch (NoSuchFormTypeAllowed)
            {
                Reports.TestStep = "This Test case scenario is not related to Files with Form Type = CD.";
                Reports.StatusUpdate("This Test case scenario is not related to Files with Form Type = CD.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("ER11: When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name && ER12: When the user enters an invalid e-Mail address && ER16_ER17_FM9711: If the user changes the Program Type")]
        public void FMUC0023_REG0120()
        {
            //This test case has been combined with FMUC0023_REG0121 and FMUC0023_REG0122
            try
            {
                Reports.TestDescription = "ER11: When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name && ER12: When the user enters an invalid e-Mail address && ER16_ER17_FM9711: If the user changes the Program Type.";

                #region ER11: When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name
                Reports.TestStep = "ER11: When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name.";
                Reports.StatusUpdate("ER11: When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name.", true);

                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create File";

                _CreateBasicFile();

                #endregion

                Reports.TestStep = "Check the Edit Name Checkbox.";
                FastDriver.FileHomepage.Open();

                FastDriver.FileHomepage.BusinessPartyEdit.FASetCheckbox(true);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.BusSrceName.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.";
                Support.AreEqual(@"Name Field is required when Edit Name Checkbox is selected", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region ER12: When the user enters an invalid e-Mail address
                Reports.TestStep = "ER12: When the user enters an invalid e-Mail address";
                Reports.StatusUpdate("ER12: When the user enters an invalid e-Mail address.", true);

                Reports.TestStep = "Check the Edit Checkbox.";

                FastDriver.FileHomepage.BusinessPartyEditCont.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessPartyEmailAddress.FASetText("xxxx" + FAKeys.Tab);

                Reports.TestStep = "Validate the tooltip for invalid email.";
                Support.AreEqual("Email address is invalid.\r\nValid Examples:\r\n\txyz@abc.com\r\n\txyz@abc.com.uk\r\n\txyz_123@abc.com\r\n\txyz-12.wuv@abc.cnn.edu.uk", FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetAttribute("title"));

                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region ER16_ER17_FM9711: If the user changes the Program Type
                Reports.TestStep = "ER16_ER17_FM9711: If the user changes the Program Type.";
                Reports.StatusUpdate("ER16_ER17_FM9711: If the user changes the Program Type.", true);

                #region Select the program type from dialog.
                Reports.TestStep = "Select the program type from dialog.";
                FastDriver.FileHomepage.ProgramType.FASelectItemBySendingKeys("++View More...");

                Reports.TestStep = "Select a program type.";
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad();
                FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction("Program Name", "PT_DO_NOT_DELETE", "Sel", TableAction.On);

                FastDriver.DialogBottomFrame.ClickDone();

                #endregion

                Reports.TestStep = "Select the value from program type from dialog.";

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.ProgramType.FASelectItemBySendingKeys("PT_DO_NOT_DELETE");
                Reports.TestStep = "Check for the message text before changing the program type";
                Support.AreEqual(@"Would you like to update the file Product and Search Type?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0069")]
        public void FMUC0023_REG0121()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0120";
                Reports.TestStep = "See test case FMUC0023_REG0120.";
                Reports.StatusUpdate("See test case FMUC0023_REG0120.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0120")]
        public void FMUC0023_REG0122()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0120";
                Reports.TestStep = "See test case FMUC0023_REG0120.";
                Reports.StatusUpdate("See test case FMUC0023_REG0120.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM14660_FM14663_FD_ProjectFile: Create order and validate that it is routed to my NCS and project flag cannot be unchecked.")]
        public void FMUC0023_REG0123()
        {
            try
            {
                Reports.TestDescription = "FM14660_FM14663_FD_ProjectFile: Create order and validate that it is routed to my NCS and project flag cannot be unchecked";

                #region Login To ISS
                Reports.TestStep = " Login To ISS.";
                _IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Sandpointe Region Office Level
                Reports.TestStep = "Navigate to Sandpointe Region Office Level.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();

                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("191");

                #endregion

                Reports.TestStep = "Validate the presence of Project file check box in QA Sandpointe region and create a basic file";

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("ALAMEDA");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.ProjectFile.FASetCheckbox(true);

                FastDriver.BottomFrame.Done();
                Playback.Wait(30000);   // wait so the log is updated
          
                Reports.TestStep = "Navigate to Event tracking log";
                FastDriver.EventTrackingLog.Open();

                Reports.TestStep = "Validate the event for Project file";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();

                Support.AreEqual("[Project File]", FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Project File]", "Event", TableAction.GetText).Message, "Event Log");
                Support.AreEqual(true.ToString(), FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Application Order successfully routed to myFAST NCS").ToString(), "Event table contains: Application Order successfully routed to myFAST NCS");

                Reports.TestStep = "Validate that the Project File checkbox is disbled and cannot be unflagged";
                FastDriver.FileHomepage.Open();
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.ProjectFile.IsEnabled().ToString());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM14661_FD_ProjectFile:Route orders to myFAST NCS after order creation.")]
        public void FMUC0023_REG0124()
        {
            try
            {

                Reports.TestDescription = "FM14661_FD_ProjectFile:Route orders to myFAST NCS after order creation";

                #region Login To IIS
                Reports.TestStep = " Login To IIS.";
                _IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Create File
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.HomePage.WaitForHomeScreen();
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Validate the program type,serach type product hierarchy.";

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("NM");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();

                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Validate that Project file check box is unchecked and can be selected";
                FastDriver.FileHomepage.Open();

                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.ProjectFile.IsSelected().ToString());
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Event tracking log";
                FastDriver.EventTrackingLog.Open();

                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();

                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Project File]", "Event", TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Application Order successfully routed to myFAST NCS").ToString(), "Event table contains: Application Order successfully routed to myFAST NCS");

                //Added the below step to verify the defect-807296
                Reports.TestStep = "Verify whether the project work bench tree view link is available.";
                try
                {
                    FastDriver.ProjectWorkBench.Open();
                    Reports.StatusUpdate("Project work bench link is existing in tree view navigation.", true);
                }
                catch(NullReferenceException)
                {
                    Reports.StatusUpdate("Project work bench link does not exist in tree view navigation.", true);
                }
                //

                Reports.TestStep = "Validate that the Project File checkbox is disbled and cannot be unflagged";
                FastDriver.FileHomepage.Open();
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.ProjectFile.IsEnabled().ToString());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FD_001: Field Definitions In Tab Order.")]
        public void FMUC0023_REG0125()
        {
            try
            {

                Reports.TestDescription = "FD_001: Field Definitions In Tab Order.";


                #region Login To ISS
                Reports.TestStep = " Login To ISS.";
                _IISLOGIN();
                #endregion

                Reports.TestStep = "Click on skip button to go to QFE.";

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Create Title Order to verify Filenum Prefix and suffix.";

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("AZ");
                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("APACHE");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Field Validation for FHP";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.BusinessPartyAddtionalRole.IsEnabled().ToString());
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.DirectedByAddtionalRole.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.ChangeOO.IsEnabled().ToString());
                Support.AreEqual("Residential Commercial New Home Subdivision Time Share Default-Residential Default-Commercial", FastDriver.FileHomepage.BusinessSegment.FAGetText());

                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.FileHomepage.FileNumPrefix.FAGetValue().Trim(), @"JVRP|QAPF|HGFD").ToString(), "Verifying FileNumPrefix");
                Support.AreEqual(true.ToString(), Regex.IsMatch(FastDriver.FileHomepage.FileNumSufix.FAGetValue().Trim(), @"JVRS|QASF|ZXCV").ToString(), "Verifying FileNumSufix");

                Support.AreEqual("Accommodation Bulk Sale Construction Disbursement Construction Finance Equity Loan Foreclosure Limited Escrow Mtg Mod w/Endorsement Mtg Mod w/Increased Liability Refinance REO Sale w/Mortgage REO Sale/Cash Sale w/Construction Loan Sale w/Mortgage Sale/Cash Sale/Exchange Search Package Second Mortgage Settlement Statement Only Short Sale w/Mortgage Short Sale/Cash", FastDriver.FileHomepage.TransactionType.FAGetText());

                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.UseAsMasterFile.IsSelected().ToString());

                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.ProgramType.IsDisplayed().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.ProgramTypeOverride.IsDisplayed().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.EscrowOwningOfficeAddress.IsDisplayed().ToString());
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.TitleOwningOfficeAddress.IsDisplayed().ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM14662:Not all orders to be routed to myFAST NCS")]
        public void FMUC0023_REG0126()
        {
            try
            {
                Reports.TestDescription = "FM14662:Not all orders to be routed to myFAST NCS";

                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Validate the presence of Project file check box in QA Sandpointe region and create a basic file";

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.CreateStandardFile();

                #endregion

                Reports.TestStep = "Validate that Event for project file is not created";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(false.ToString(), FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Order successfully routed to myFAST NCS.").ToString());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FD:Order source.")]
        public void FMUC0023_REG0127()
        {
            try
            {
                Reports.TestDescription = "FD:Order source";

                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Validate the presence of Project file check box in QA Sandpointe region and create a basic file";

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.CreateStandardFile();

                #endregion

                Reports.TestStep = "Validate the presence of order source";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.OrderSourceExpand.FAClick();
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.OrderSource.IsDisplayed().ToString());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("EW13:The user removes one or more production office(s) when one or more office(s) being removed  is/are assigned to task(s) that are not in Final Status.")]
        public void FMUC0023_REG0128()
        {
            try
            {
                Reports.TestDescription = "EW13:The user removes one or more production office(s) when one or more office(s) being removed  is/are assigned to task(s) that are not in Final Status.";

                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Change the current Office to QA Automation Office1 - DO NOT TOUCH"
                Reports.TestStep = "Change the current Office to QA Automation Office1 - DO NOT TOUCH";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();

                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("191");

                #endregion


                #region Create File
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.HomePage.WaitForHomeScreen();
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Validate the program type,serach type product hierarchy.";

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00" + FAKeys.Tab);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("NM");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.BottomFrame.Done();

                Playback.Wait(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Change existing information on production office section.";
                FastDriver.FileHomepage.AddRemoveOwningOff.FAClick();

                Reports.TestStep = "QA Automation Office1 - DO NOT TOUCH";
                Playback.Wait(5000);
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                FastDriver.OfficeSelectionDlg.Region.FASelectItem(AutoConfig.SelectedRegionName);
                Playback.Wait(5000);

                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Sel", TableAction.On);

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM14665:Failure in routing Orders to myFAST NCS.")]
        public void FMUC0023_REG0128_PH()
        {
            try
            {
                Reports.TestDescription = "FM14665:Failure in routing Orders to myFAST NCS";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY.", false);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("EW13:The user removes one or more production office(s) when one or more office(s) being removed  is/are assigned to task(s) that are not in Final Statuse.")]
        public void FMUC0023_REG0129()
        {
            try
            {
                Reports.TestDescription = "EW13:The user removes one or more production office(s) when one or more office(s) being removed  is/are assigned to task(s) that are not in Final Status.";

                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Change the current Office to QA Automation Office1 - DO NOT TOUCH"
                Reports.TestStep = "Change the current Office to QA Automation Office1 - DO NOT TOUCH";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();

                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.OfficesTable.PerformTableAction("BUID", AutoConfig.SelectedOfficeBUID, "Office Name", TableAction.Click);
                Reports.TestStep = "Wait and Click on Done";

                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create File
                var File = _CreateBasicFile();
                #endregion

                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Click on Task Office button.";
                FastDriver.FileWorkflow.Process.PerformTableAction(4, "1", 7, TableAction.Click);
                Reports.TestStep = "Select the Task Office.";

                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.PerformTableAction("Office", "JVR Office", "Office", TableAction.Click);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Process.PerformTableAction(4, "1", 1, TableAction.On);

                Reports.TestStep = "Change exist information on title production office section.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveOwningOff.FAClick();

                Reports.TestStep = "QA Automation Office1 - DO NOT TOUCH";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                FastDriver.OfficeSelectionDlg.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", "JVR Office", "Sel", TableAction.Off);

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Wait and Click on Save";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "save Changes without Bus Party.";
                Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Validate the error message that appears if we remove the office which is associated to fileworkflow";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.Errormessage.FAGetText().Contains("The following production office(s) cannot be removed from the file because tasks are assigned to the office(s).").ToString(), "Verify FileHomePage errors contains:The following production office(s) cannot be removed from the file because tasks are assigned to the office(s).");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM14276:Prevent Change Owning Office")]
        public void FMUC0023_REG0130()
        {
            try
            {
                Reports.TestDescription = "FM14276:Prevent Change Owning Office";

                Reports.TestStep = "Log in to Admin.";
                _ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);


                FastDriver.FeeSetup.CheckSubjectToCalculationFee("New Home Rate (Title Only)", "Title - Owners Policy", "All", false);

                #region IIS Login
                _IISLOGIN();
                #endregion

                #region Create File
                var File = _CreateBasicFile();
                #endregion

                #region Create a Fee
                Reports.TestStep = "Create a Fee.";

                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                #endregion

                Reports.TestStep = "Add a homeowner association instance directly.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.FindGABCode("247");

                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");
                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("4.00");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FASetText("2.00");
                FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.FASetText("4.50");
                FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.FASetText("2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-16-2012");

                FastDriver.HomeownerAssociation.LienPayoffBuyerCharge.FASetText("1.50");
                FastDriver.HomeownerAssociation.LienPayoffSellerCredit.FASetText("2.50");

                Reports.TestStep = "To edit a check in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBankAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Beneficiary Note 1");
                FastDriver.BottomFrame.Save();

                #region Change Escrow Own Office
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change the Escrow Owning Office to an office which has no bank";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("Office Without Bank PR: STEST Off: 1111 (2642)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();


                Reports.TestStep = "Verify the error message for no bank [US#686119 - TC#775241: System shall not allow changing owing office if office does not have disbursement account]";
                FastDriver.DialogBottomFrame.ClickYes();

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("Service File: The owning office cannot be changed because the new office you selected does not have a disbursement account.", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Trim());

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("Create order from WCF source as MYNCS && FD:MyNCS")]
        public void FMUC0023_REG0131()
        {
            try
            {

                Reports.TestDescription = @"Create order from WCF source as MYNCS && FD:MyNCS";

                #region  Create order from WCF source as MYNCS

                Reports.TestStep = "Create order from WCF source as MYNCS.";
                Reports.StatusUpdate("Create order from WCF source as MYNCS", true);

                #region Login To ISS
                Reports.TestStep = " Login To ISS.";
                _IISLOGIN();
                #endregion

                _CreateBasicFile(Source: "myFASTNCS");

                #endregion

                #region FD:MyNCS

                Reports.TestStep = "FD:MyNCS";
                Reports.StatusUpdate("FD:MyNCS", true);

                Reports.TestStep = "UnCheck the *Texas Mortgagee Policy (T2) when there is AN policy number associated";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveProducts.FAClick();

                FastDriver.ProductListDlg.WaitScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*Texas Mortgagee Policy (T2)", 1, TableAction.Off);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the event where source as MYNCS";
                FastDriver.EventTrackingLog.Open();

                FastDriver.EventTrackingLog.EventTable.PerformTableAction("User", "myFAST NCS", "User", TableAction.Click);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "myFAST NCS", "Source", TableAction.Click);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("This test case has been combined with FMUC0023_REG0131")]
        public void FMUC0023_REG0132()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0023_REG0131";
                Reports.TestStep = "See test case FMUC0023_REG0131.";
                Reports.StatusUpdate("See test case FMUC0023_REG0131.", true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }


        //SRT
        [TestMethod]
        [Description("FM14660_FM14663_FD_ProjectFile: Create a Project File and validate that Change O/O button is enabled for Project File")]
        public void FMUC0023_REG0133()
        {
            try
            {
                Reports.TestDescription = "FM14660_FM14663_FD_ProjectFile: Create a Project File and validate that Change O/O button is enabled for Project File";

                Reports.TestStep = "Log in ADM site and set 'QA Test Office PR: QAREGION Off: 456 (6045)' Project File Checkbox.";
                _ADMLOGIN();

                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>QAREGION>Offices>456").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.WebDriver.Quit();


                #region Login To ISS
                Reports.TestStep = " Login To ISS.";
                _IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Sandpointe Region Office Level
                Reports.TestStep = "Navigate to Sandpointe Region Office Level.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();

                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("191");

                #endregion

                Reports.TestStep = "Validate the presence of Project file check box in QA Sandpointe region and create a basic file";

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("ALAMEDA");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");


                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.ProjectFile.FASetCheckbox(true);

                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);


                Reports.TestStep = "Validate that the Change O/O Button is enabled [US#686119 - TC#780043: System shall enable the Change O/O button once the Business segment change to Commercial]";
                FastDriver.FileHomepage.Open();
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.ChangeOO.IsEnabled().ToString());

                #region Click on Change OO button and Change Escrow Own Office
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Test Office PR: QAREGION Off: 456 (6045)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Verify The Warning Message On Changing Escrow Own Office and Change the EscrowOwning Office";
                String VerifyMessage = "Workflow Tasks are currently assigned to the removed Escrow owning office. Do you want to assign those same Workflow Tasks to the new Escrow owning office?";
                Support.AreEqual(VerifyMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.HandlingWarningmsg(VerifyMessage, "Yes"));

                Playback.Wait(1000);
                #endregion

                // Added the below section to cover the defect-847246
                #region Login to ADM side and uncheck the project file checkbox for the office.
                Reports.TestStep = "Log in ADM site and uncheck 'QA Test Office PR: QAREGION Off: 456 (6045)' Project File Checkbox.";
                _ADMLOGIN();

                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>QAREGION>Offices>456").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.ProjectFile.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.WebDriver.Quit();
                #endregion

                #region Login To ISS
                Reports.TestStep = " Login To ISS.";
                _IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Sandpointe Region Office Level
                Reports.TestStep = "Navigate to Sandpointe Region Office Level.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();

                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("191");

                #endregion #region Login To ISS

                #region create a new normal basic file.
                Reports.TestStep = "Create a new normal basic file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("ALAMEDA");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");


                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.ProjectFile.FASetCheckbox(false);

                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);

                #endregion 

                #region Navigate to the File Side and open the same file and change the escrow office.
                Reports.TestStep = "Navigate to the File Side and open the same file and change the escrow office.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ClickChangeOO();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Test Office PR: QAREGION Off: 456 (6045)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Verify The Warning Message On Changing Escrow Own Office and Change the EscrowOwning Office [US#686119 - TC#776354: System shall not allow changing owing office if new office does not have Project file check at ADM side]";
                if(FastDriver.WebDriver.WaitForAlertToExist(15))
                {
                    string errorMesg = FastDriver.WebDriver.HandleDialogMessage();
                    Reports.StatusUpdate("FAST should not throw the project file error for non project file.", errorMesg.Contains("The new owning office does not process Project files."));
                }
                Support.AreEqual(VerifyMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.HandlingWarningmsg(VerifyMessage, "No"));
                
                #endregion
                //
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [Description("FM14660_FM14663_FD_ProjectFile: Create a Project File, Disburse Some Amount On that File and validate that Change O/O button is enabled for Project File, however it should not allow to Change")]
        public void FMUC0023_REG0134()
        {
            try
            {
                Reports.TestDescription = "FM14660_FM14663_FD_ProjectFile: reate a Project File, Disburse Some Amount On that File and validate that Change O/O button is enabled for Project File, however it should not allow to Change";

                #region Login To ISS
                Reports.TestStep = " Login To ISS.";
                _IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                Reports.TestStep = "Set default check printer";
                FastDriver.PrinterConfiguration.Open();
                FastDriver.PrinterConfiguration.SetDefaultPrinter(); 

                #region Navigate to Sandpointe Region Office Level
                Reports.TestStep = "Navigate to Sandpointe Region Office Level.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();

                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("191");

                #endregion

                Reports.TestStep = "Validate the presence of Project file check box in QA Sandpointe region and create a basic file";

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("ALAMEDA");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");


                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.ProjectFile.FASetCheckbox(true);

                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);

                Reports.TestStep = "Navigate to Home Warranty screen, add a charge";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HW1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("7.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen, select the pending charge, click Edit";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "7.99", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();

                FastDriver.PrintDlg.WaitForScreenToLoad();
                //FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();

                Reports.TestStep = "Provide the OverDraft Reason for Loss and Comment";
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                FastDriver.WebDriver.WaitForDeliveryWindow();

                Reports.TestStep = "Validate that the Change O/O Button is enabled";
                FastDriver.FileHomepage.Open();
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.ChangeOO.IsEnabled().ToString());

                #region Click on Change OO button and Change Escrow Own Office
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Test Office PR: QAREGION Off: 456 (6045)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Verify The Warning Message On Changing Escrow Own Office and Change the EscrowOwning Office";
                String VerifyMessage = "Workflow Tasks are currently assigned to the removed Escrow owning office. Do you want to assign those same Workflow Tasks to the new Escrow owning office?";
                Support.AreEqual(VerifyMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.HandlingWarningmsg(VerifyMessage, "Yes"));

                Reports.TestStep = "Verify The Error Message due to Disbursement through the Escrow Owning Office and Change the EscrowOwning Office";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                String VerifyErrorMessage = "Service File: Current Available Funds is not $0.00. You cannot change the Escrow Owning Office or remove Escrow Service Type.";
                Support.AreEqual(VerifyErrorMessage, FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().ToString().Trim());
                Playback.Wait(5000);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        

        #endregion

        [TestMethod]
        [Description("501469: Verify that, the word 'calculated' is added to warning message on changing underwriter with Title and Endorsement FACC fees.")]
        public void FMUC0023_REG0135()
        {
            try
            {
                Reports.TestDescription = "501469: Verify that, the word 'calculated' is added to warning message on changing underwriter with Title and Endorsement FACC fees.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion

                #region
                Reports.TestStep = "Add new Loan.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500.00");
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                Playback.Wait(100);
                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.JSClick();
                Playback.Wait(5000);
                FastDriver.CalculateFees.Next.FAClick();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItem("ALTA Ext Loan Policy 1056.06 (6-17-06) - 1");
                FastDriver.CalculateFees.SummaryChargeTo.FASelectItem("Buyer");
                FastDriver.BottomFrame.Done();
               
                Reports.TestStep = "verify the error message";

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItem("New Underwriter");
                Playback.Wait(5000);
                alert();
                Playback.Wait(5000);                                                                            //static wait
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                FastDriver.WebDriver.SwitchTo().Frame(FastDriver.WebDriver.FAFindElement(ByLocator.Id,"FAFDialog_0_iframe"));
               string error= FastDriver.WebDriver.FAFindElement(ByLocator.Id,"spnMessage").Text.ToString();
               FastDriver.WebDriver.FAFindElement(ByLocator.Id, "btnYes").FAClick();
               Support.AreEqual("Changing the Underwriter will result in removal of all calculated Title and Endorsement fees.  Continue?", error);
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #region FMUC0023_REG0136: TC824133 A drop-down selection list of 'UW Employee' is added to the Title Owning Office section of File Homepage and to show in File Summary screens
        [TestMethod]
        public void FMUC0023_REG0136()
        {
            try
            {
                Reports.TestDescription = "TC824133 A drop-down selection list of 'UW Employee' is added to the Title Owning Office section of File Homepage and to show in File Summary screens";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Check and setup on UW Employee type on ADM side
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa06";


                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa06");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA06]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa07";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa07");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA07]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Create a FAST file via Home | Order Entry | Quick File Entry";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Enter a GAB and Required info in the Service area";
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                Reports.TestStep = "Verify that UW Employee default to Blank";
                FastDriver.QuickFileEntry.UW_Employee.IsVisible();
                Support.AreEqual(true, FastDriver.QuickFileEntry.UW_Employee.FAGetSelectedItem().Contains(""), "Default to Blank");

                //Reports.TestStep = "Select an UW Employee";
                //FastDriver.QuickFileEntry.UW_Employee.FASelectItem("User, Super");

                Reports.TestStep = "Enter a FULL Property Address: Street address, City, State, Zip, County";
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("123 Testing Ave");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92630");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");

                Reports.TestStep = "Click Done to create file";
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to Event/Tracking Log screen and verify file created.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Opened]"), "File Created");

                Reports.TestStep = "Navigate to File Homepage screen and verify UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem(), "Verify NO UW Employee got selected");

                Reports.TestStep = "Navigate to File Summary screen and verify UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                Support.AreEqual(" ", FastDriver.FileSummary.TittleOO_UWEmployee.FAGetText(), "Verify No UW Employee");

                Reports.TestStep = "Navigate to File Homepage screen and select USER1 UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FASelectItem("QA07, FAST");
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to File Summary screen and verify USER1 UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileSummary.TittleOO_UWEmployee.FAGetText().Contains("FAST QA07"), "Verify USER1 UW Employee");

                Reports.TestStep = "Navigate to File Homepage screen and verify USER1 UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem().Contains("QA07, FAST"), "Verify USER1 UW Employee");

                Reports.TestStep = "Change USER1 UW Employee to USER2 UW Employee.";
                FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FASelectItem("QA06, FAST");
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();


                Reports.TestStep = "Navigate to File Summary screen and verify USER2 UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileSummary.TittleOO_UWEmployee.FAGetText().Contains("FAST QA06"), "Verify USER1 UW Employee");

                Reports.TestStep = "Navigate to File Homepage screen and verify USER2 UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem().Contains("QA06, FAST"), "Verify USER1 UW Employee");

            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        #endregion

        #region FMUC0023_REG0137: TC824137 'View More...'Search Functionality for UW Employee Drop-Down by FirstName and Last Name should return user from other region if possible
        [TestMethod]
        public void FMUC0023_REG0137()
        {
            try
            {
                Reports.TestDescription = "TC824137 'View More...'Search Functionality for UW Employee Drop-Down by FirstName and Last Name should return user from other region if possible";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Check and setup on UW Employee type on ADM side
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Performing Empployee Search for SuperUser as Login";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(credentials.UserName);
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA07]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa06";


                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa06");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA06]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa07";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa07");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA07]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Create a FAST file via Home | Order Entry | Quick File Entry";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Enter a GAB and Required info in the Service area";
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                Reports.TestStep = "Verify that UW Employee default to Blank";
                FastDriver.QuickFileEntry.UW_Employee.IsVisible();
                Support.AreEqual(true, FastDriver.QuickFileEntry.UW_Employee.FAGetSelectedItem().Contains(""), "Default to Blank");

                Reports.TestStep = "Perform a 'View More...'Search Functionality for UW Employee Drop-Down";
                FastDriver.QuickFileEntry.UW_Employee.FASelectItem("View More...");
                FastDriver.UW_EmployeeSearchDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify elements on the UW Employee Search Dialog";
                Support.AreEqual(false, FastDriver.DialogBottomFrame.btnDone.IsEnabled(), "Done button is disabled");
                //Support.AreEqual(true, FastDriver.DialogBottomFrame.btnCancel.IsEnabled(), "Cancel button is enabled");
                Support.AreEqual(true, FastDriver.UW_EmployeeSearchDlg.FindNow.IsEnabled(), "FindNow button is enabled");
                Support.AreEqual(true, FastDriver.UW_EmployeeSearchDlg.NewSearch.IsEnabled(), "NewSearch button is enabled");
                Support.AreEqual(string.Empty, FastDriver.UW_EmployeeSearchDlg.FirstName.FAGetText(), "FistName txtbox is emplty");
                Support.AreEqual(string.Empty, FastDriver.UW_EmployeeSearchDlg.LastName.FAGetText(), "LastName txtbox is emplty");
               // Support.AreEqual(true, FastDriver.UW_EmployeeSearchDlg.SearchResultTable.GetRowCount() == 1, "UW Search Result Table is empty");

                Reports.TestStep = "Perform a search with FirstName = Test, LastName = Test";
                FastDriver.UW_EmployeeSearchDlg.FirstName.FASetText(string.Empty);
                FastDriver.UW_EmployeeSearchDlg.LastName.FASetText(string.Empty);
                FastDriver.UW_EmployeeSearchDlg.FindNow.FAClick();
                FastDriver.UW_EmployeeSearchDlg.WaitForScreenToLoad();
                //Support.AreEqual(true, FastDriver.UW_EmployeeSearchDlg.SearchResultTable.GetRowCount() == 2, "Found that user");

                Reports.TestStep = "Select that UW Employee";
                FastDriver.UW_EmployeeSearchDlg.SearchResultTable.PerformTableAction(2, 1, TableAction.On);
                string userFN = FastDriver.UW_EmployeeSearchDlg.SearchResultTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                string userLN = FastDriver.UW_EmployeeSearchDlg.SearchResultTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Enter a FULL Property Address: Street address, City, State, Zip, County";
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("123 Testing Ave");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92630");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");

                Reports.TestStep = "Click Done to create file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Event/Tracking Log screen and verify file created.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Opened]"), "File Created");

                Reports.TestStep = "Navigate to File Homepage screen and verify UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem().Contains(userLN + ", " + userFN), "Verify UW Employee");

                Reports.TestStep = "Navigate to File Summary screen and verify UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileSummary.TittleOO_UWEmployee.FAGetText().Contains(userFN + " " + userLN), "Verify UW Employee");

            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        #endregion

        #region FMUC0023_REG0138: TC824142 'View More...'Search Functionality for UW Employee Drop-Down should return ALL or NONE user from other region if possible
        [TestMethod]
        public void FMUC0023_REG0138()
        {
            try
            {
                Reports.TestDescription = "TC824142 'View More...'Search Functionality for UW Employee Drop-Down should return ALL or NONE user from other region if possible";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Check and setup on UW Employee type on ADM side
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa06";


                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa06");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA06]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa07";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa07");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA07]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Create a FAST file via Home | Order Entry | Quick File Entry";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Enter a GAB and Required info in the Service area";
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                Reports.TestStep = "Verify that UW Employee default to Blank";
                FastDriver.QuickFileEntry.UW_Employee.IsVisible();
                Support.AreEqual(true, FastDriver.QuickFileEntry.UW_Employee.FAGetSelectedItem().Contains(""), "Default to Blank");

                Reports.TestStep = "Perform a 'View More...'Search Functionality for UW Employee Drop-Down";
                FastDriver.QuickFileEntry.UW_Employee.FASelectItem("View More...");
                FastDriver.UW_EmployeeSearchDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify elements on the UW Employee Search Dialog";
                Support.AreEqual(false, FastDriver.DialogBottomFrame.btnDone.IsEnabled(), "Done button is disabled");
                Support.AreEqual(true, FastDriver.UW_EmployeeSearchDlg.FindNow.IsEnabled(), "FindNow button is enabled");
                Support.AreEqual(true, FastDriver.UW_EmployeeSearchDlg.NewSearch.IsEnabled(), "NewSearch button is enabled");
                Support.AreEqual(string.Empty, FastDriver.UW_EmployeeSearchDlg.FirstName.FAGetText(), "FistName txtbox is emplty");
                Support.AreEqual(string.Empty, FastDriver.UW_EmployeeSearchDlg.LastName.FAGetText(), "LastName txtbox is emplty");
                Support.AreEqual(false, FastDriver.UW_EmployeeSearchDlg.SearchResultTable.IsVisible(), "UW Search Result Table is empty");

                Reports.TestStep = "Perform a ALL search with blank firstname and lastname should return ALL";
                FastDriver.UW_EmployeeSearchDlg.FindNow.FAClick();
                FastDriver.UW_EmployeeSearchDlg.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.UW_EmployeeSearchDlg.SearchResultTable.GetRowCount() >= 2, "Found ALL user");

                Reports.TestStep = "Click Cancel and UW Employee Search Dialog should be close back to Fast ";
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Verify no user UW Employee Search Dialog got selected";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.QuickFileEntry.UW_Employee.FAGetSelectedItem(), "No user UW Employee Search Dialog got selected");


                Reports.TestStep = "Perform a 'View More...'Search Functionality for UW Employee Drop-Down";
                FastDriver.QuickFileEntry.UW_Employee.FASelectItem("View More...");
                FastDriver.UW_EmployeeSearchDlg.WaitForScreenToLoad();

                Reports.TestStep = "Perform a search with inavlid user and return ZERO";
                FastDriver.UW_EmployeeSearchDlg.FirstName.FASetText("!@#");
                FastDriver.UW_EmployeeSearchDlg.LastName.FASetText("%^&");
                FastDriver.UW_EmployeeSearchDlg.FindNow.FAClick();
                FastDriver.UW_EmployeeSearchDlg.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.UW_EmployeeSearchDlg.SearchResultTable.IsVisible(), "UW Search Result Table is empty");

                Reports.TestStep = "Perform a ALL search with *";
                FastDriver.UW_EmployeeSearchDlg.FirstName.FASetText("*");
                FastDriver.UW_EmployeeSearchDlg.LastName.FASetText("*");
                FastDriver.UW_EmployeeSearchDlg.FindNow.FAClick();
                FastDriver.UW_EmployeeSearchDlg.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.UW_EmployeeSearchDlg.SearchResultTable.GetRowCount() >= 2, "Found that user");

                Reports.TestStep = "Perform a ALL search with blank firstname and lastname should return ALL";
                FastDriver.UW_EmployeeSearchDlg.FindNow.FAClick();
                FastDriver.UW_EmployeeSearchDlg.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.UW_EmployeeSearchDlg.SearchResultTable.GetRowCount() >= 2, "Found that user");

                Reports.TestStep = "Select that UW Employee";
                FastDriver.UW_EmployeeSearchDlg.SearchResultTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Enter a FULL Property Address: Street address, City, State, Zip, County";
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("123 Testing Ave");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92630");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");

                Reports.TestStep = "Click Done to create file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Event/Tracking Log screen and verify file created.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Opened]"), "File Created");


            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        #endregion

        [TestMethod]
        public void FMUC0023_REG0139()
        {
            try
            {
                Reports.TestDescription = "FMUC0023_REG0139: US#686119 - TC#755240: System shall remove the split payee fee on changing owing office for Sub-Escrow file";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Services[0] = null;
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project, Commercial, Escrow, and Sub-Escrow file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.SubEscrow.FASetCheckbox(true);
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20, true);

                Reports.TestStep = "Add a fee to the file";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 7, TableAction.SetText, "20.00");
                string feeName = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20, true);

                Reports.TestStep = "Navigate to Split Fees/Assign State Screen. Select 2 Payee name. (E.g. Smythe & Lee and Continental Mortgage Corporation)";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FABResultsTable.PerformTableAction(2, 1, TableAction.On);
                string payeeName = FastDriver.PayeeSearchDlg.FABResultsTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.SplitFeeDisbursements.SpliFeeImage(0).FAClick();
                Playback.Wait(2000);
                FastDriver.SplitFeeDisbursements.Payee.FASelectItemBySendingKeys(payeeName);
                FastDriver.SplitFeeDisbursements.SplitPercentage.FASetText("50");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change Escrow Owning Office to another office that processes project file";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click Yes on the warning message";
                FastDriver.ChangeOwningOfficeRemoveServiceType.HandlingWarningmsg("", "Yes");
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to the Split Fee Disbursements screen, validte the split fee has been removed";
                FastDriver.SplitFeeDisbursements.Open();
                Support.AreEqual("1", FastDriver.SplitFeeDisbursements.PayeesSummary.GetRowCount(true).ToString(), "Only one row on Payees table (NOT include the header row)");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }

        }

        [TestMethod]
        public void FMUC0023_REG0140()
        {
            try
            {
                Reports.TestDescription = "FMUC0023_REG0140: US#686119: System shall not throw any error on changing owning office of Project file when site files are associated";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FormType.CD;

                var deposit = new DepositParameters()
                {
                    Amount = 10000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD, Project, Commercial file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20, true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench screen, create a site file";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteMenuOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20, true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.CopyAllAddresses);
                FastDriver.ProjectWorkBench.CopyAllAddresses.FASetCheckbox(true);
                string siteFileNumber = fileNum + FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, fileNum, 2, TableAction.GetInputValue).Message.Clean();
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20, true);

                Reports.TestStep = "Navigate to the site file";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.TopFrame.SearchFileByFileNumber(siteFileNumber);

                Reports.TestStep = "Make deposit to the site file";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Navigate to Home Warranty screen, add a charge";
                FastDriver.HomeWarrantyDetail.Open();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HW1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("7.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait for the SDN search to complete";
                FastDriver.SDNTrackingSummary.Open();
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(30);

                Reports.TestStep = "Disburse the check";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SelectPrinter();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 200);

                Reports.TestStep = "Navigate to the project file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Change Escrow Owning Office to another office that processes project file";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click Yes on the warning message";
                FastDriver.ChangeOwningOfficeRemoveServiceType.HandlingWarningmsg("", "Yes");
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to the site file";
                FastDriver.TopFrame.SearchFileByFileNumber(siteFileNumber);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Escrow Owing Office remains unchanged";
                Support.AreEqual("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878 (1487)", FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetSelectedItem().Clean(), "Escrow Owing Office remains unchanged");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }

        }

        [TestMethod]
        public void FMUC0023_REG0141()
        {
            try
            {
                Reports.TestDescription = "FMUC0023_REG0141: US#686119 - TC#784934: System shall associate newly associated owning office to all the file workflow task";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FormType.CD;
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD, Project, Commercial file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20, true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Workflow screen, start a task";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.ClickCompleteTaskCheckboxForTask("AUTO_DONOTTOUCH_Template Setup Maintenan", "ADEC-ITI-BILL-FULL");
                FastDriver.FileWorkflow.ClickApply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20, true);

                Reports.TestStep = "Change Escrow Owning Office to another office that processes project file";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click Yes on the warning message";
                FastDriver.ChangeOwningOfficeRemoveServiceType.HandlingWarningmsg("", "Yes");
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to File Workflow screen, validate the task office remains unchanged for the completed task";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("QA Automation Office -", FastDriver.FileWorkflow.GetAssignedOffice("AUTO_DONOTTOUCH_Template Setup Maintenan", "ADEC-ITI-BILL-FULL"), "Assigned Office remains unchanged");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }

        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 814502:REQ0909373 - NCS - Hide Select Office Names in FAST Office Selection Screens-File Homepage
        //TestCase                                : 849190
        //Appended By/ Created By                 : Sheetal Gothi
        [TestMethod]
        public void FMUC0023_REG0142()
        {

            string OfficeCode1 = "0";
            try
            {

                Reports.TestDescription = "Verify system is not displaying  Hidden offices which are marked Hidden in Change OO screen.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                #region Create a new office in ADM side.

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select an Office and Click on New.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                //string office = FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it and verify office is marked as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();
                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                        FastDriver.BottomFrame.Done();
                    }
                    else
                    {
                        FastDriver.BottomFrame.Done();
                    }
                }
                else if (!FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Test Automation Office"))
                {
                    this.CreateNewOffice();

                    Reports.TestStep = "Verify if office is not created then create or just mark the office as Hidden.";
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                    Reports.TestStep = "Mark the office as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for office";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    FastDriver.BottomFrame.Done();
                }
                #endregion Create a new office in ADM side.

                #region File data setup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Products = new FASTWCFHelpers.FastFileService.Product[]
                {
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 884,
                    },
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 886,
                    }
                };
                #endregion File data setup

                #region create file

                Reports.TestStep = "Log into FAST application.";
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");

                Reports.TestStep = "Create File using web service.";
                //FastDriver.TopFrame.SearchFileByFileNumber("40342");
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
                #endregion create file

                #region Navigate to Change OO
                Reports.TestStep = "Verify the Hidden office not exist in Change OO list.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                Reports.TestStep = "Check Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                string[] AllEscrowOffices = FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under Escrow owning office.");
                string[] AllTitleOffices = FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Title = false;
                foreach (string office in AllTitleOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Title = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Title, "Verify the Hidden Office should not be present under title owning office.");

                FastDriver.BottomFrame.Done();

                #endregion Navigate to Change OO

                #endregion UI
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 814502:REQ0909373 - NCS - Hide Select Office Names in FAST Office Selection Screens-File Homepage
        //TestCase                                : 849191
        //Appended By/ Created By                 : Sheetal Gothi
        [TestMethod]
        public void FMUC0023_REG0143()
        {
            string OfficeCode1 = "0";
            try
            {
                Reports.TestDescription = "Verify system is not displaying  Hidden offices which are marked Hidden in Change OO screen for Project file and Site files.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                #region Create a new office in ADM side.

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select an Office and Click on New.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                //string office = FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it and verify office is marked as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();
                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                        FastDriver.BottomFrame.Done();
                    }
                    else
                    {
                        FastDriver.BottomFrame.Done();
                    }
                }
                else if (!FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Test Automation Office"))
                {
                    this.CreateNewOffice();

                    Reports.TestStep = "Verify if office is not created then create or just mark the office as Hidden.";
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                    Reports.TestStep = "Mark the office as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for office";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    FastDriver.BottomFrame.Done();
                }
                #endregion Create a new office in ADM side.

                #region File data setup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Products = new FASTWCFHelpers.FastFileService.Product[]
                {
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 884,
                    },
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 886,
                    }
                };
                #endregion File data setup

                #region create file

                Reports.TestStep = "Log into FAST application.";
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");

                Reports.TestStep = "Create Project File.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyCity.FASelectItemBySendingKeys("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASelectItemBySendingKeys("ALAMEDA");

                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.ProjectFile.FASetCheckbox(true);

                FastDriver.BottomFrame.Done();

                #endregion Create File

                #region Create Site file
                Reports.TestStep = "Navigate to Project Workbench screen";
                FastDriver.ProjectWorkBench.Open();
                ClickOnCreateSiteFilesLink();
                FastDriver.ProjectWorkBench.SwitchToContentFrame();
                FastDriver.ProjectWorkBench.WaitCreation(FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Verify the Add icon for existance";
                Support.AreEqual("True", FastDriver.ProjectWorkBench.AddButton.Exists().ToString());

                Reports.TestStep = "Validate whether the Add icon is enabled";
                Support.AreEqual("True", FastDriver.ProjectWorkBench.AddButton.Enabled.ToString());

                Reports.TestStep = "Verify the Country field and enter details in blank address line";
                Support.AreEqual("USA", FastDriver.ProjectWorkBench.ddlCountries.FAGetSelectedItem());
                FastDriver.ProjectWorkBench.State.FASelectItem("CA");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("First American Way");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Santa Ana");
                FastDriver.ProjectWorkBench.nameZip.FASetText("92708");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Orange");

                Reports.TestStep = "Click on Create icon";
                FastDriver.ProjectWorkBench.Create.FAClick();

                Reports.TestStep = "Verify the message displayed in red for successful creation of site file";
                Support.AreEqual("True", FastDriver.ProjectWorkBench.ErrorMessage.Exists().ToString());
                int counter = 0;
                while (FastDriver.ProjectWorkBench.ErrorMessage.Text.Equals(""))
                {
                    Playback.Wait(300);
                    counter = counter++;
                    if (counter > 25)
                    {
                        Keyboard.SendKeys("%c");
                        counter = 0;
                    }
                }
                Support.AreEqual("True", FastDriver.ProjectWorkBench.ErrorMessage.Text.Contains("1 File(s) successfully created.").ToString());

                Reports.TestStep = "Load the site file via File search";
                FastDriver.TopFrame.SwitchToTopFrame();
                string CustomFileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.TopFrame.SwitchToContentFrame();
                string CustomSiteFileNum = CustomFileNum + FastDriver.ProjectWorkBench.SiteFileNum.FAGetValue();
                #endregion Create Site file

                #region Navigate to Change OO
                Reports.TestStep = "Verify the Hidden office not exist in Change OO list.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                Reports.TestStep = "Check Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                string[] AllEscrowOffices = FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');
                //var OfficeCode1 = "1507";
                bool isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under Escrow owning office for project file.");

                string[] AllTitleOffices = FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');
                bool isPresent_Title = false;
                foreach (string office in AllTitleOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Title = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Title, "Verify the Hidden Office should not be present under title owning office for project file.");
                FastDriver.BottomFrame.Done();

                #endregion Verify the Hidden office is not exists for Project file.

                #region Open the site file

                Reports.TestStep = "Navigate to File Search Screen and Enter Custom site file number and Click on Find Now.";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search").WaitCreation(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.Numbers.FASetText(CustomSiteFileNum);
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(6000);
                // 
                // 
                Reports.TestStep = "Verifying for Specific Custom site file number";

                FastDriver.FileHomepage.WaitForScreenToLoad(FastDriver.FileHomepage.FileNum);
                Support.AreEqual(CustomSiteFileNum, FastDriver.FileHomepage.FileNum.FAGetValue());

                #endregion Open the Site file

                #region Navigate to Change OO
                Reports.TestStep = "Verify the Hidden office not exist in Change OO list.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                Reports.TestStep = "Check Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                AllEscrowOffices = FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');

                isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under Escrow owning office for site file.");

                AllTitleOffices = FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');
                isPresent_Title = false;
                foreach (string office in AllTitleOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Title = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Title, "Verify the Hidden Office should not be present under title owning office for site file.");
                FastDriver.BottomFrame.Done();

                #endregion   #region Navigate to Change OO
                #endregion UI
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 814502:REQ0909373 - NCS - Hide Select Office Names in FAST Office Selection Screens-File Homepage
        //TestCase                                : 849192
        //Appended By/ Created By                 : Sheetal Gothi
        [TestMethod]
        public void FMUC0023_REG0144()
        {
            string OfficeCode1 = "0";
            try
            {
                Reports.TestDescription = "Verify system displays blank when user tries to create file in Hidden offices.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                #region Create a new office in ADM side.

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select an Office and Click on New.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                //string office = FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it and verify office is marked as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();
                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                        FastDriver.BottomFrame.Done();
                    }
                    else
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);
                        FastDriver.BottomFrame.Done();
                    }
                }
                else if (!FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Test Automation Office"))
                {
                    this.CreateNewOffice();

                    /*Reports.TestStep = "Verify if office is not created then create or just mark the office as Hidden.";
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                    Reports.TestStep = "Mark the office as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for office";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);*/

                    FastDriver.BottomFrame.Done();
                }
                #endregion Create a new office in ADM side.

                #region File data setup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Products = new FASTWCFHelpers.FastFileService.Product[]
                {
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 884,
                    },
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 886,
                    }
                };
                #endregion File data setup

                #region create file
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");

                Reports.TestStep = "Create basic Title File.";
                var filenNo = _CreateBasicTitleFile();

                #endregion Create File

                #region Mark the office as Hidden
                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select an Office and Mark as Hidden.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();

                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", OfficeCode1, "Office Code", TableAction.Click);
                string OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", OfficeCode1, "BUID", TableAction.GetText).Message.ToString();

                //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();

                Reports.TestStep = "Set the Hidden flag status as true for office";
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion Mark the office as Hidden

                #region Search and open the same Title File
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);


                Reports.TestStep = "Verify the default state of the fields.";
                FastDriver.FileSearch.VerifyTheStateOfFields();

                Reports.TestStep = "Enter the file number.";
                FastDriver.FileSearch.SetFileNumber(filenNo.FileNumber);
                Reports.TestStep = "Click the Find Now button.";
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(20000);
                #endregion Search and open the same Title File

                #region Navigate to Service section and add Escrow service
                Reports.TestStep = "Verify since logged in office is marked as Hidden the Escrow office drop should be blank.";
                FastDriver.FileHomepage.Open();
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                Reports.TestStep = "Check Escrow Office drop down for blank value.";
                if (FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Title Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Title owning office");
                }
                //string EscrowOffice = FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetValue().ToString();
                string[] AllEscrowOffices = FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }
                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under Escrow Owning office.");
                Playback.Wait(3000);
                FastDriver.FileHomepage.EscrowOwningOfficeOffice.FASelectItemBySendingKeys("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                #endregion Navigate to Service section and add Escrow service

                #endregion UI
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 808635:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Production Office selection Window-FHP
        //TestCase                                : 860796
        //Appended By/ Created By                 : Sheetal Gothi
        [TestMethod]
        public void FMUC0023_REG0145()
        {
            string OfficeBuid = "";
            try
            {
                Reports.TestDescription = "Verify system displays Active and Hidden values for Escrow and Title Owning office window.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration


                #region File data setup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Products = new FASTWCFHelpers.FastFileService.Product[]
                {
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 884,
                    },
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 886,
        }
                };
                #endregion File data setup

                #region Read BUID from ADM
                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select an Office and Click on New.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and read the BUID.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                //string office = FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText();
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                FastDriver.BottomFrame.Done();

                #endregion Read BUID from ADM

                #region create file
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                //string OfficeBuid = "13587";
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");
                //FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                Reports.TestStep = "Create basic Title File.";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion create file

                #region Verify Display status on production office section.
                Reports.TestStep = "Change exist information on production office section.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveOwningOff.FAClick();

                Reports.TestStep = "Select status from Display drop down.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Support.AreEqual("Active", FastDriver.OfficeSelectionDlg.Display.FAGetSelectedItem().ToString(), "Active value selected by default in Title Production office selection window");

                Support.AreEqual("Active|Hidden", FastDriver.OfficeSelectionDlg.Display.FAGetAllTextFromSelect());
                //Support.AreEqual("0", FastDriver.OfficeSelectionDlg.Display.FASelectItemBySendingKeys("Avtive & Hidden"), "Active and Hidden displayed in Display drop down");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Save();
                #endregion Verify Display status on production office section.

                #endregion UI Iteration
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 808635:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Production Office selection Window-FHP
        //TestCase                                : 860798
        //Appended By/ Created By                 : Sheetal Gothi
        [TestMethod]
        public void FMUC0023_REG0146()
        {
            string OfficeCode1 = "0";
            string OfficeBuid = "0";
            try
            {
                Reports.TestDescription = "Verify system displays Active and Hidden offices in Production office window.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                #region Create a new office in ADM side.

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select an Office and Click on New.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                //string office = FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it and verify office is marked as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();
                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                    {
                        FastDriver.BottomFrame.Done();
                    }
                    else
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);
                        FastDriver.BottomFrame.Done();
                    }
                }
                else if (!FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Test Automation Office"))
                {
                    this.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    Reports.TestStep = "Select an office and read BUID of it.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.BottomFrame.Done();
                }
                #endregion Create a new office in ADM side.

                #region File data setup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Products = new FASTWCFHelpers.FastFileService.Product[]
                {
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 884,
                    },
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 886,
                    }
                };
                #endregion File data setup

                #region create file
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");
                //FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                Reports.TestStep = "Create basic Title File.";
                OrderDetailsResponse File = _CreateBasicFile();
                #endregion create file

                #region Select office from Production office dialog
                Reports.TestStep = "Select Active office from production office section for Title Office.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveEscOff.FAClick();

                Reports.TestStep = "Select status from Display drop down.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Display.FASelectItemBySendingKeys("Active");
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", "JVR Office", "Sel", TableAction.On);
                Playback.Wait(2000);
                FastDriver.OfficeSelectionDlg.Display.FASelectItemBySendingKeys("Hidden");
                Playback.Wait(2000);
                FastDriver.OfficeSelectionDlg.OfficesSelectTable.PerformTableAction("Office Name", "JVR Office", "Office Name", TableAction.GetText);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate that the Production office added from office set up.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.EscrowProdOfficeTable.PerformTableAction("Office Name", "JVR Office (2379)", "Office Name", TableAction.Click);
                //FastDriver.FileHomepage.TitleProdOfficeTable.PerformTableAction("Office Name", "QA Automation Office - DO NOT TOUCH (1487)", "Office Name", TableAction.Click);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion Select office from Production office dialog

                #region Mark the office as Hidden
                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select an Office and Mark as Hidden.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Reports.TestStep = "Select an office and edit it.";

                FastDriver.OfficeSummary.WaitForScreenToLoad();

                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", OfficeCode1, "Office Code", TableAction.Click);
                //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();

                Reports.TestStep = "Set the Hidden flag status as true for office";
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                }
                else
                {

                    FastDriver.BottomFrame.Done();
                }
                Playback.Wait(3000);
                #endregion Mark the office as Hidden

                #region Login to same file and Add Hidden Production office as escrow office
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                Reports.TestStep = "Navigate to File Search Screen and Enter Custom site file number and Click on Find Now.";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search").WaitCreation(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.Numbers.FASetText(File.FileNumber);
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(6000);

                Reports.TestStep = "Select Active office from production office section for Title Office.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveEscOff.FAClick();

                Reports.TestStep = "Select status from Display drop down.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Display.FASelectItemBySendingKeys("Hidden");
                Playback.Wait(2000);
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", "SRT Test Automation Office", "Sel", TableAction.On);
                Playback.Wait(2000);
                FastDriver.OfficeSelectionDlg.Display.FASelectItemBySendingKeys("Active");
                Playback.Wait(2000);
                FastDriver.OfficeSelectionDlg.OfficesSelectTable.PerformTableAction("Office Name", "SRT Test Automation Office", "Office Name", TableAction.GetText);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate that the Production office added from office set up.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.EscrowProdOfficeTable.PerformTableAction("Office Name", "SRT Test Automation Office " + "(" + OfficeBuid + ")", "Office Name", TableAction.Click);
                //FastDriver.FileHomepage.TitleProdOfficeTable.PerformTableAction("Office Name", "QA Automation Office - DO NOT TOUCH (1487)", "Office Name", TableAction.Click);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();


                #endregion Login to same file and Add Hidden Production office as escrow office


                #endregion UI Iteration
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Team 1
        //Iteration                               : r09
        //UserStory                               : US#862294 : REQ0899471 - Change the label on the FAST Menu bar from TRIDHelp to TeachMe and change URL for landing page
        //TestCase                                : 
        //Appended By/ Created By                 : Osama Faruqi
        [TestMethod]
        public void FMUC0023_REG0147()
        {
            try
            {
                Reports.TestDescription = "Verify the Label TeachMe on the Fast Menue Bar and the URL for the landing page";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region IIS Interaction
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Verify the Teach me Label";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.TeachMe.FAClick();
                FastDriver.TopFrame.TeachMe.Exists();
                FastDriver.WebDriver.SwitchToWindowByUrl("https://registration.firstam.com/EA/FAST/TeachMe/Page/index.html");
                Reports.TestStep = "Verify the URL";
                string url = FastDriver.WebDriver.Url.ToString();
                string comapare = url.Contains("https://registration.firstam.com/EA/FAST/TeachMe/Page/index.html").ToString();
                Support.AreEqual("True", comapare);
                #endregion IIS Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


         [TestMethod]
        public void FMUC0023_REG0148()
        {
            try
            {
                Reports.TestDescription = "[US#706808] - INC2291108 - Agency - [Bug] FastWeb orders are changing the Policy Issued field";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST ADM application";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Office Setup screen, set Policy Issued By = Agent Issued Policy";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.PolicyIssuedBy.FASelectItem("Agent Issued Policy");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST IIS application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a WinTrack Order";
                int fileID = (int) _CreateBasicFileWithSpecifiedOrderSource("WINTRACK").FileID;

                Reports.TestStep = "Navigate to File Homepage screen, validate Policy Issued By = Agent Issued Policy";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.PolicyIssuedBy.ScrollIntoView();
                Support.AreEqual("Agent Issued Policy", FastDriver.FileHomepage.PolicyIssuedBy.FAGetSelectedItem(), "Policy Issued By");

                Reports.TestStep = "Invoke GetOrderDetails, validate PolicyIssuedBy node = Agent Issued Policy";
                Support.AreEqual("Agent Issued Policy", FileService.GetOrderDetails(fileID).Services[0].PolicyIssuedBy, "PolicyIssuedBy");
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST ADM application";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Office Setup screen, set Policy Issued By = Underwriter Issued Policy";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.PolicyIssuedBy.FASelectItem("Underwriter Issued Policy");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST IIS application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a LA.COM Order";
                fileID = (int)_CreateBasicFileWithSpecifiedOrderSource("LA.COM").FileID;

                Reports.TestStep = "Navigate to File Homepage screen, validate Policy Issued By = Underwriter Issued Policy";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.PolicyIssuedBy.ScrollIntoView();
                Support.AreEqual("Underwriter Issued Policy", FastDriver.FileHomepage.PolicyIssuedBy.FAGetSelectedItem(), "Underwriter Issued Policy");

                Reports.TestStep = "Invoke GetOrderDetails, validate PolicyIssuedBy node = Underwriter Issued Policy";
                Support.AreEqual("Underwriter Issued Policy", FileService.GetOrderDetails(fileID).Services[0].PolicyIssuedBy, "PolicyIssuedBy");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        
        #region PRIVATE METHODS

        private string getProdOfficeName(string inValue)
        {
            if (inValue.Contains("--"))
                inValue = inValue.Split('-')[0].Trim();
            else
                inValue = inValue.Split('(')[0].Trim();

            return inValue;
        }
        private string alert(bool clickAcceptButton = true)
        {
            string alertText = null;
            string WinDlg = "[TITLE:Message from webpage;CLASS:#32770]";
            if (AutoItX.WinExists(WinDlg) != 0)
            {
                AutoItX.WinActivate(WinDlg);
                alertText = AutoItX.ControlGetText(WinDlg, "", "[CLASS:Static; INSTANCE:2]");
                if (!clickAcceptButton)
                    AutoItX.Send("{SPACE}");    // to switch from default button

                AutoItX.Send("{ENTER}");
                Reports.UpdateDebugLog("AutoIt", "Alert", "Handle Dialog*", "", "", alertText, Reports.Result(true), "");
            }
            return alertText;
        }
        private OrderDetailsResponse _CreateBasicFile(string Source = "FAST")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.Source = Source;

            customizableFileRequest.File.Properties = new Property[]
            {
                new Property()
                {
                    PropertyAddress = new PhysicalAddress[]
                    {
                        new PhysicalAddress()
                        {
                            State = "CA",
                            City = "ALBANY",
                            County = "ALAMEDA",
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        }
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                }
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;
        }

        private OrderDetailsResponse _CreateBasicFileWithSpecifiedOrderSource(string orderSource = "WINTRACK")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.Source = orderSource;

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;
        }

        private OrderDetailsResponse _CreateBasicFileWithSpecifiedOrderSourceAndGAB(string orderSource = "WINTRACK", string GABCode = "1256")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.Source = orderSource;
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.File.Properties = new Property[]
            {
                new Property()
                {
                    PropertyAddress = new PhysicalAddress[]
                    {
                        new PhysicalAddress()
                        {
                            State = "CA",
                            City = "SANTA ANA",
                            County = "ORANGE",
                            Zip = "92707",
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        }
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                }
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;
        }

        private OrderDetailsResponse _CreateCommercialFile()
        {

            var customizableFileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;
        }

        private OrderDetailsResponse _CreateBasicFileWithSpecifiedGAB(string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;
        }

        private OrderDetailsResponse _CreateBasicTitleSubEscrowFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.Services = new Service[]
                    {
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "TO"
                        },
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "SEO"
                        }
                    };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;

        }

        private OrderDetailsResponse _CreateBasicTitleFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.Services = new Service[]
                    {
                       new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "TO"
                        }
                    };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;

        }

        private OrderDetailsResponse _CreateBasicEscrowFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.Services = new Service[]
                    {
                       new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;

        }

        private OrderDetailsResponse _CreateBasicEscrowSubEscrowFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.Services = new Service[]
                    {
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        },
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "SEO"
                        }
                    };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;

        }

        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }

        private void _AddAccessRights(string UserName, string[] RegionalAccess = null, string[] OfficeAccess = null, bool RegionLevel = false)
        {
            Reports.TestStep = "Check and add the access rights for: " + UserName + " employee in ADM side";

            if (RegionLevel)
            {
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
            }

            Reports.TestStep = "Enter userid and search.";
            FastDriver.EmployeeSecurity.Open();
            FastDriver.EmployeeSecurity.SearchAndSelectEmployee(AutoConfig.UserName);
            FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();

            if (RegionalAccess != null)
            {
                Reports.TestStep = "Click open the Region and select roles.";

                FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedRegionBUID, 2, TableAction.Click);
                FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();

                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
                foreach (string RoleName in RegionalAccess)
                {
                    FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", RoleName, "Select", TableAction.On);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
            }

            if (OfficeAccess != null)
            {
                Reports.TestStep = "Click open the office level and select roles";

                int ExpandButtonRow = FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedRegionBUID, 1, TableAction.Click).CurrentRow;
                FastDriver.BusinessUnitRoleAssignment.ExpandButton(ExpandButtonRow + 1).FAClick();

                FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedOfficeBUID, 2, TableAction.Click);
                FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();
                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();

                foreach (string RoleName in OfficeAccess)
                {
                    FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", RoleName, "Select", TableAction.On);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
            }

            FastDriver.BottomFrame.Done();

            if (FastDriver.TrackChangeHistoryDialog.IsPresent())
            {
                FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
                FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();
            }

        }

        private void _AddEmployeeTypes(string UserName, string[] EmployeeTypes = null, bool RegionLevel = false)
        {
            Reports.TestStep = "Check and add the Employee Types for: " + UserName + " employee in ADM side";
            UserName = UserName.ToUpper();

            if (RegionLevel)
            {
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
            }

            if (EmployeeTypes != null)
            {

                Reports.TestStep = "Navigate to Employee Search, Edit the Employee and add the employee type(s).";

                EmployeeSearchParameters EmployeeData = new EmployeeSearchParameters();
                EmployeeData.LoginName = UserName;
                FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.SearchEmployee(EmployeeData).EditEmployee(EmployeeData.LoginName);

                FastDriver.EmployeeSetup.WaitForScreenToLoad();

                foreach (string EmployeeType in EmployeeTypes)
                {
                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem(EmployeeType);
                }

                FastDriver.BottomFrame.Done();
                FastDriver.EmployeeSearch.WaitForScreenToLoad();

            }


        }

        public void ClickOnCreateSiteFilesLink()
        {
            Actions action = new Actions(FastDriver.WebDriver);
            IWebElement Grid = FastDriver.WebDriver.FindElement(By.CssSelector("#tabs_Menu_Img"));
            action.MoveToElement(Grid).Perform();
            IWebElement NewCreateUpdateTab = FastDriver.WebDriver.FindElement(By.CssSelector(".FAF-tabs-navigation li a[data-content='cPTWBCU']"));
            action.MoveToElement(NewCreateUpdateTab).Perform();
            IWebElement CreateUpdateCreateSiteFiles = FastDriver.WebDriver.FindElement(By.CssSelector("#scPTWBCSF"));
            action.Click(CreateUpdateCreateSiteFiles).Perform();
        }

        private void CreateNewOffice()
        {
            FastDriver.OfficeSummary.New.FAClick();

            Reports.TestStep = "Enter details to newly created office.";
            FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
            Random random = new Random();
            string OfficeCode1 = random.Next(999, 10000).ToString();
            FastDriver.OfficeSetupOffice.OfficeCode.FASetText(OfficeCode1);
            FastDriver.OfficeSetupOffice.FederalTaxID.FASetText("567891234");
            FastDriver.OfficeSetupOffice.OfficeName.FASetText("SRT Test Automation Office");
            FastDriver.OfficeSetupOffice.OfficeCompanyName1.FASetText("SRT DO Not Touch Automation Office");
            FastDriver.OfficeSetupOffice.OfficeComments.FASetText("Creating a new Office");
            FastDriver.OfficeSetupOffice.OfficeLogoFile1.FASetText("Test");
            FastDriver.OfficeSetupOffice.OfficeSystemLogoFile.FASetText("Automation Test");
            FastDriver.OfficeSetupOffice.BusinessSegment.FASelectItem("Commercial");
            FastDriver.OfficeSetupOffice.Can_be_Inter_Regional_Production_office.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.FeeTransmittalType.FASelectItem("Fee Transfer");
            FastDriver.OfficeSetupOffice.TimeZone.FASelectItem("Mountain Time");
            FastDriver.OfficeSetupOffice.DivisionProductionCenter.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.NPSProductionOffice.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.StatisticalReportingOffice.FASelectItem("Agency");
            FastDriver.OfficeSetupOffice.ProductionSystem.FASelectItem("FAST deployed");
            FastDriver.OfficeSetupOffice.FileNumberSchemaPrefix.FASetText("EWS");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator1.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator2.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSuffix.FASetText("ADC");
            FastDriver.OfficeSetupOffice.DocumentNumberSchemaInvoicePrefix.FASetText("100");
            FastDriver.OfficeSetupOffice.FastStatCode.FASetText("12345");
            FastDriver.OfficeSetupOffice.CorporateParent.FASelectItemBySendingKeys("First American (FA)");
            FastDriver.OfficeSetupOffice.UnderwritersMenu.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwritersNew.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwriterName1.FASelectItem("New Underwriter");
            FastDriver.OfficeSetupUnderwriters.PremiumPercentage.FASetText("10");
            FastDriver.OfficeSetupUnderwriters.UseAsDefaultUnderwriter.FASetCheckbox(true);

            FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
            FastDriver.OfficeSetupBankAccounts.BankAccountSummaryNew.FAClick();
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName.FASelectItemBySendingKeys("Automation Bank - Automation Testing");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1.FASetText("232345");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_AccountDescription.FASetText("SRT AUTOMATION BANK");
            FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDeposit.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Bank Name", "Automation Bank - Automation Testing", "Bank Name", TableAction.Click);

            FastDriver.BottomFrame.Done();


        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

public class NoSuchFormTypeAllowed : Exception
{
    public NoSuchFormTypeAllowed() : base() { }
    public NoSuchFormTypeAllowed(string message) : base(message) { }

}