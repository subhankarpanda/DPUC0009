﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;


namespace FileManagement
{
    [CodedUITest]
    public class FMUC0122_FAST_Title_Bar : MasterTestClass
    {
        #region BAT

        [TestMethod]
        public void FMUC0122_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "View 1st Order Source Icon on Title Bar";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a FastWeb File.";
                CreateFile("WINTRACK");

                Reports.TestStep = "Navigate to FileHomepage screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Verify whether the System displays the integration partner’s unique icon on the title bar preceded by the label ‘1st’.";
                FastDriver.TitleFrame.WaitForScreenToLoad();
                if (FastDriver.TitleFrame.WintrackIcon.Exists())
                {
                    Support.AreEqual(true, FastDriver.TitleFrame.FirstOrderSourceIcon.Displayed, "System displays the primary order source icon on the title bar.");
                    Support.AreEqual(true, FastDriver.TitleFrame.WintrackIcon.Displayed, "System displays the integration partner's unique icon on the title bar.");
                }
                else
                {
                    Reports.StatusUpdate("First order and integration partner unique icon is not being displayed. ", false);
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0122_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "View 1st Order Source Icon on Title Bar";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file with Order Source = Wintrack";
                var File1 = CreateFile();
                var File = CreateFile("WINTRACK");

                Reports.TestStep = "Update second order source";
                UpdateSecondOrderSource(File, "LVIS", 38);

                Reports.TestStep = "Refresh the page by Navigating to FileHomepage screen.";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.TopFrame.SearchFileByFileNumber(File1.FileNumber);
                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                    FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                    return FastDriver.TitleFrame.WaitForScreenToLoad().LVISIcon.Exists();
                }, timeout: 120, idleInterval: 5);

                Reports.TestStep = "Verify whether the System displays the integration partner’s unique icon on the title bar preceded by the label ‘1st’.";
                FastDriver.TitleFrame.WaitForScreenToLoad();
                if (FastDriver.TitleFrame.WintrackIcon.Exists() && FastDriver.TitleFrame.LVISIcon.Exists())
                {
                    Support.AreEqual(true, FastDriver.TitleFrame.FirstOrderSourceIcon.Displayed, "System displays the primary order source icon on the title bar.");
                    Support.AreEqual(true, FastDriver.TitleFrame.WintrackIcon.Displayed, "System displays WINTRACK unique icon on the title bar.");
                    Support.AreEqual(true, FastDriver.TitleFrame.SecondOrderSourceIcon.Displayed, "System displays the Second order source icon on the title bar.");
                    Support.AreEqual(true, FastDriver.TitleFrame.LVISIcon.Displayed, "System displays LVIS unique icon on the title bar.");
                }
                else
                {
                    Reports.StatusUpdate("First and/or Second order source integration partner unique icon is not being displayed. ", false);
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0122_BAT0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FAST File Title Bar - Workpane Specific Buttons / Icons";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Wintrack Order";
                CreateFile("WINTRACK");

                Reports.TestStep = "Navigate to FileHomepage and verify the Wintrack icon.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.TitleFrame.WaitForScreenToLoad();
                if (FastDriver.TitleFrame.WintrackIcon.Exists())
                {
                    Support.AreEqual(true, FastDriver.TitleFrame.WintrackIcon.Displayed, "System displays WINTRACK unique icon on the title bar.");
                }
                else
                {
                    Reports.StatusUpdate("Witnrack unique icon is not being displayed. ", false);
                }

                Reports.TestStep = "Create a LVIS Order";
                CreateFile("LVIS");

                Reports.TestStep = "Navigate to FileHomepage and verify the LVIS icon.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.TitleFrame.WaitForScreenToLoad();
                if (FastDriver.TitleFrame.LVISIcon.Exists())
                {
                    Support.AreEqual(true, FastDriver.TitleFrame.LVISIcon.Displayed, "System displays LVIS unique icon on the title bar.");
                }
                else
                {
                    Reports.StatusUpdate("Witnrack unique icon is not being displayed. ", false);
                }

                Reports.TestStep = "Create a LA.COM Order";
                CreateFile("LA.COM");

                Reports.TestStep = "Navigate to FileHomepage and verify the LA.COM icon.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.TitleFrame.WaitForScreenToLoad();
                if (FastDriver.TitleFrame.LACOMIcon.Exists())
                {
                    Support.AreEqual(true, FastDriver.TitleFrame.LACOMIcon.Displayed, "System displays LA.COM unique icon on the title bar.");
                }
                else
                {
                    Reports.StatusUpdate("Witnrack unique icon is not being displayed. ", false);
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0122_BAT0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FAST File Title Bar - Field Definitions in Tab Order";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Custom File";
                var file1 = CreateFile();

                Reports.TestStep = "Navigate to FileHomepage screen";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Verify whether First icon and Second Order icon are not present on the title bar";
                FastDriver.TitleFrame.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.TitleFrame.FirstOrderSourceNumber.Displayed, "Verify whether the First Order Icon is not displayed.");
                Support.AreEqual(false, FastDriver.TitleFrame.SecondOrderSourceNumber.Displayed, "Verify whether the First Order Icon is not displayed.");

                Reports.TestStep = "Create a WINTRACK Order";
                var file = CreateFile("WINTRACK");

                Reports.TestStep = "Update second order source with LVIS";
                UpdateSecondOrderSource(file, "LVIS", 38);

                Reports.TestStep = "Navigate to FileHomepage screen";
                FastDriver.TopFrame.SearchFileByFileNumber(file1.FileNumber);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Verify whether First icon and Second Order icon are not present on the title bar";
                FastDriver.TitleFrame.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.TitleFrame.FirstOrderSourceNumber.Displayed, "Verify whether the First Order Icon is displayed.");
                Support.AreEqual(true, FastDriver.TitleFrame.SecondOrderSourceNumber.Displayed, "Verify whether the First Order Icon is displayed.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region REG

        [TestMethod]
        public void FMUC0122_REG0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "US 473136:  Integration Partner Icon in Title Bar to Support for 2nd Order Source";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file with Order Source = Wintrack";
                var file1 = CreateFile();
                var file = CreateFile("WINTRACK");

                Reports.TestStep = "Update second order source";
                UpdateSecondOrderSource(file, "LVIS", 38);

                Reports.TestStep = "Refresh the page by Navigating to FileHomepage screen.";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.TopFrame.SearchFileByFileNumber(file1.FileNumber);
                    FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);
                    FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                    return FastDriver.TitleFrame.WaitForScreenToLoad().LVISIcon.Exists();
                }, timeout: 120, idleInterval: 5);

                Reports.TestStep = "Verify whether the System displays the integration partner’s unique icon on the title bar preceded by the label ‘1st’.";
                FastDriver.TitleFrame.WaitForScreenToLoad();
                if (FastDriver.TitleFrame.WintrackIcon.Exists() && FastDriver.TitleFrame.LVISIcon.Exists())
                {
                    Support.AreEqual(@"1st Order Source", FastDriver.TitleFrame.FirstOrderSourceIcon.FAGetAttribute("title").Clean());
                    Support.AreEqual(@"2nd Order Source", FastDriver.TitleFrame.SecondOrderSourceIcon.FAGetAttribute("title").Clean());
                    Support.AreEqual(true, FastDriver.TitleFrame.WintrackIcon.Displayed, "System displays WINTRACK unique icon on the title bar.");
                    Support.AreEqual(true, FastDriver.TitleFrame.LVISIcon.Displayed, "System displays LVIS unique icon on the title bar.");
                }
                else
                {
                    Reports.StatusUpdate("First and/or Second order source integration partner unique icons are not being displayed. ", false);
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0122_REG0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "US 515787: LA.com Icon displays in Title Bar when Primary Order Source";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file with Order Source = LA.COM";
                var file = CreateFile("LA.COM");

                Reports.TestStep = "Refresh the page by Navigating to FileHomepage screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Verify whether the System displays the integration partner’s unique icon on the title bar preceded by the label ‘1st’.";
                FastDriver.TitleFrame.WaitForScreenToLoad();
                if (FastDriver.TitleFrame.LACOMIcon.Exists() && FastDriver.TitleFrame.FirstOrderSourceNumber.Exists())
                {
                    Support.AreEqual(true, FastDriver.TitleFrame.FirstOrderSourceNumber.Displayed, "Verify whether the 1st Order Source icon is displayed.");
                    Support.AreEqual(true, FastDriver.TitleFrame.LACOMIcon.Displayed, "System displays LA.COM unique icon on the title bar.");
                }
                else
                {
                    Reports.StatusUpdate("1st Order Source icon and/or LA.COM integration partner unique icon is not being displayed. ", false);
                }


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0122_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "When Primary Order is La.com and secondary order is Wintrack the title bar will include the LA.com icon with a prefix of 1st followed by the Wintrack icon with a prefix of 2nd.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file with Order Source = LA.COM";
                var file1 = CreateFile();
                var file = CreateFile("LA.COM");

                Reports.TestStep = "Update second order source = WINTRACK";
                UpdateSecondOrderSource(file, "WINTRACK", 10);

                Reports.TestStep = "Refresh the page by Navigating to FileHomepage screen.";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.TopFrame.SearchFileByFileNumber(file1.FileNumber);
                    FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);
                    FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                    return FastDriver.TitleFrame.WaitForScreenToLoad().WintrackIcon.Exists();
                }, timeout: 120, idleInterval: 5);

                Reports.TestStep = "Verify whether the System displays the integration partner’s unique icon on the title bar preceded by the label ‘1st’.";
                FastDriver.TitleFrame.WaitForScreenToLoad();
                if (FastDriver.TitleFrame.LACOMIcon.Exists() && FastDriver.TitleFrame.WintrackIcon.Exists())
                {
                    Support.AreEqual(@"1st Order Source", FastDriver.TitleFrame.FirstOrderSourceIcon.FAGetAttribute("title").Clean());
                    Support.AreEqual(true, FastDriver.TitleFrame.LACOMIcon.Displayed, "System displays LA.COM unique icon on the title bar.");
                    Support.AreEqual(@"2nd Order Source", FastDriver.TitleFrame.SecondOrderSourceIcon.FAGetAttribute("title").Clean());
                    Support.AreEqual(true, FastDriver.TitleFrame.WintrackIcon.Displayed, "System displays WINTRACK unique icon on the title bar.");
                }
                else
                {
                    Reports.StatusUpdate("First and/or Second order source integration partner unique icons are not being displayed. ", false);
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0122_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "When Primary Order is La.com and secondary order is LVIS the title bar will include the LA.com icon with a prefix of 1st followed by the LVIS icon with a prefix of 2nd.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file with Order Source = LA.COM";
                var file1 = CreateFile();
                var file = CreateFile("LA.COM");

                Reports.TestStep = "Update second order source = LVIS";
                UpdateSecondOrderSource(file, "LVIS", 38);

                Reports.TestStep = "Refresh the page by Navigating to FileHomepage screen.";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.TopFrame.SearchFileByFileNumber(file1.FileNumber);
                    FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);
                    FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                    return FastDriver.TitleFrame.WaitForScreenToLoad().LVISIcon.Exists();
                }, timeout: 120, idleInterval: 5);

                Reports.TestStep = "Verify whether the System displays the integration partner’s unique icon on the title bar preceded by the label ‘1st’.";
                FastDriver.TitleFrame.WaitForScreenToLoad();
                if (FastDriver.TitleFrame.LACOMIcon.Exists() && FastDriver.TitleFrame.LVISIcon.Exists())
                {
                    Support.AreEqual(@"1st Order Source", FastDriver.TitleFrame.FirstOrderSourceIcon.FAGetAttribute("title").Clean());
                    Support.AreEqual(true, FastDriver.TitleFrame.LACOMIcon.Displayed, "System displays LA.COM unique icon on the title bar.");
                    Support.AreEqual(@"2nd Order Source", FastDriver.TitleFrame.SecondOrderSourceIcon.FAGetAttribute("title").Clean());
                    Support.AreEqual(true, FastDriver.TitleFrame.LVISIcon.Displayed, "System displays LVIS unique icon on the title bar.");
                }
                else
                {
                    Reports.StatusUpdate("First and/or Second order source integration partner unique icons are not being displayed. ", false);
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Custom Class Method

        private FASTWCFHelpers.FastFileService.OrderDetailsResponse CreateFile(string source = "FAST")
        {
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = RequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "";
            fileRequest.File.Properties[0].PropertyAddress[0].City = "";
            fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
            fileRequest.File.Properties[0].PropertyAddress[0].County = "";
            fileRequest.File.Properties[0].PropertyAddress[0].Zip = "";
            fileRequest.File.NewLoan = null;
            fileRequest.File.Buyers[0].Type = "Individual";
            fileRequest.File.Buyers[0].Name = "BuyerFirst";
            fileRequest.File.Buyers[0].LastName = "BuyerLast";
            fileRequest.File.Sellers[0].Type = "Individual";
            fileRequest.File.Sellers[0].Name = "SellerFirst";
            fileRequest.File.Sellers[0].LastName = "SellerLast";
            fileRequest.Source = source;
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;
        }

        private void UpdateSecondOrderSource(FASTWCFHelpers.FastFileService.OrderDetailsResponse file, string source = "WINTRACK", int secondSourceAppID = 10)
        {
            var updateSecoundSource = new FASTWCFHelpers.FastFileService.UpdateSecondOrderSourceRequest();
            updateSecoundSource.FileID = file.FileID;
            updateSecoundSource.SecondExternalFileNum = "123456789";
            updateSecoundSource.SecondSourceApplID = secondSourceAppID;
            updateSecoundSource.SecondSourceApplQueueName = @"DIRECT=OS:SERVER\Private$\UpdateStatus";
            updateSecoundSource.Source = source;
            FileService.UpdateSecondOrderSource(updateSecoundSource);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}