﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.Common;
using System.Linq;
using System.Collections.Generic;

namespace FileManagement
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class FMUC0110 : MasterTestClass
    {

        #region BAT
        [TestMethod]
        public void FMUC0110_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_001: To create a Search Vendor for a File.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);
                AddSearchVendorAndProblemLog("254");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        


        [TestMethod]
        public void FMUC0110_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF_001: To modify a Search Vendor in a File.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);

                AddSearchVendorAndProblemLog("254");

                Reports.TestStep = "Click Edit button.";
                FastDriver.SearchVendorSummary.Edit.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Reports.TestStep = "Modify the Search Vendor in the file.";
                FastDriver.SearchVendor.GABcode.FASetText(@"257");

                FastDriver.SearchVendor.Find.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 12);
                Playback.Wait(5000);

                Reports.TestStep = "Click Done button.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that search vendor is modified.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "First Of America Bank", 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }



        [TestMethod]
        public void FMUC0110_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF_002: Add Problem Log(s) for a Search Vendor.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);

                AddSearchVendorAndProblemLog("254");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }


        [TestMethod]
        public void FMUC0110_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF_003: To remove Problem Log(s) for a Search Vendor.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);

                AddSearchVendorAndProblemLog("254", false);

                FastDriver.SearchVendor.WaitForScreenToLoad();

                var problemLogCount = FastDriver.SearchVendor.ProblemLogTable.GetRowCount();
                Reports.StatusUpdate("Is the number of rows in the Problem Log table equal to 1 ?", problemLogCount == 1);


                Reports.TestStep = "Again click Add/Remove button in Problem Log section to remove an entry of the problem log.";
                FastDriver.SearchVendor.ProblemLogAddRemove.FAClick();


                Reports.TestStep = "Deselect the first problem log.";
                FastDriver.ProblemListDlg.WaitForScreenToLoad();


                if (GetElementInsideCell(@"./span/span/input", row:2, col:1).IsSelected())
                {
                    FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, 1, TableAction.Click);
                }

                Reports.TestStep = "Click on Done in dialog box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate that the particular entry in the Problem Log is removed.";
                FastDriver.SearchVendor.WaitForScreenToLoad();

                problemLogCount = FastDriver.SearchVendor.ProblemLogTable.GetRowCount();
                Reports.StatusUpdate("Is the number of rows in the Problem Log table is equal to 0 ? Actual entries in Problem Log :"+problemLogCount, problemLogCount == 0);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }


        [TestMethod]
        public void FMUC0110_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF_004: To add multiple Instances of a Search Vendor in a file.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);
                AddSearchVendorAndProblemLog("254");

                Reports.TestStep = "Click New button on Search Vendor Summary page.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.New.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();


                Reports.TestStep = "Modify the Search Vendor in the file.";
                FastDriver.SearchVendor.GABcode.FASetText(@"257");

                FastDriver.SearchVendor.Find.FAClick();

                //this is to handle the Reference association/disassociation pop-up, in case it appears.
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 12);

                Playback.Wait(1000);

                Reports.TestStep = "Click Done button.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that a new search vendor is added.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "First Of America Bank", 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion


        #region Regression

        [TestMethod]
        public void FMUC0110_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM13044_FM13045_FM13046_FM13048_FM13053_EWC_FD: Adding Vendor from GAB and FAB,Display Grade of Vendor, Entering Confirmation Date ,Production Process and Cost.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);

                Reports.TestStep = "Navigate to Search Vendor.";
                FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();

                Reports.StatusUpdate("Is Find button displayed ?", FastDriver.SearchVendor.Find.IsVisible());
                Reports.StatusUpdate("Is Check Details displayed ?", FastDriver.SearchVendor.CheckDetails.IsVisible());

                FastDriver.SearchVendor.Find.FAClick();

                Reports.TestStep = "Validate the Address Book Search dialog is opened.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();

                Reports.StatusUpdate("Is NewGAB displayed ?", FastDriver.AddressBookSearchDlg.NewGAB.IsVisible());
                Reports.StatusUpdate("Is Clear button enabled ?", FastDriver.AddressBookSearchDlg.Clear.IsEnabled());

                Reports.StatusUpdate("Is EntityType displayed ?", FastDriver.AddressBookSearchDlg.EntityType.IsVisible());

                Reports.StatusUpdate("Is EntityName displayed ?", FastDriver.AddressBookSearchDlg.EntityName.IsVisible());
                Reports.StatusUpdate("Is IDCode displayed ?", FastDriver.AddressBookSearchDlg.IDCode.IsVisible());
                Reports.StatusUpdate("Is City displayed ?", FastDriver.AddressBookSearchDlg.City.IsVisible());

                Reports.StatusUpdate("Is County displayed ?", FastDriver.AddressBookSearchDlg.County.IsVisible());

                Reports.StatusUpdate("Is State displayed ?", FastDriver.AddressBookSearchDlg.State.IsVisible());

                Reports.StatusUpdate("Is ContactFirstName displayed ?", FastDriver.AddressBookSearchDlg.ContactFirstName.IsVisible());

                Reports.StatusUpdate("Is Find enabled ?", FastDriver.AddressBookSearchDlg.Find.IsEnabled());


                Reports.TestStep = "Select Business ID radio button from the File Address Book.";

                if (!FastDriver.AddressBookSearchDlg.FileaddressBookRadio.IsSelected())
                    FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FAClick();

                if (!FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.IsSelected())
                    FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.FAClick();

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the field values of Search Vendor Confirmation Date, Production Process and Cost on Search Vendor page.";
                FastDriver.SearchVendor.WaitForScreenToLoad();


                Support.AreEqual("", FastDriver.SearchVendor.VenderDetailsConfirmDate.FAGetValue());
                Support.AreEqual("0", FastDriver.SearchVendor.VenderDetailsProductionProcess.FAGetSelectedIndex().ToString());
                Support.AreEqual(@"", FastDriver.SearchVendor.VenderDetailsProductionProcess.FAGetSelectedItem().ToString());
                Support.AreEqual("0.00", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue());

                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Verify screen for second instance upon clicking New Button.";
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Reports.TestStep = "Create the first instance taking ID from GAB.";
                FastDriver.SearchVendor.GABcode.FASetText(@"1592GAB");

                FastDriver.SearchVendor.Find.FAClick();

                Reports.TestStep = "Verify the GRADE for the search Vendor and Search Vendor Confirmation Date, Production Process ,Cost.";
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Support.AreEqual(@"Vendor Grade : Preferred", FastDriver.SearchVendor.VendorGrade.FAGetText());
                Support.AreEqual("", FastDriver.SearchVendor.VenderDetailsConfirmDate.FAGetValue());
                Support.AreEqual("0", FastDriver.SearchVendor.VenderDetailsProductionProcess.FAGetSelectedIndex().ToString());
                Support.AreEqual("0.00", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue());

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create second instance of the Vendor.";
                AddSearchVendorAndProblemLog(GABCode: "HUDFLINSR1", navigateToSummaryThruDone: true, SearchVendorPageNeedsToLoad: false);

                Reports.TestStep = "Navigate to Search Vendor Summary page.";
                FastDriver.LeftNavigation.Navigate<SearchVendorSummary>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();

                Reports.TestStep = "Verify the first instance of the Search Vendor has been created.";
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "1592 GAB For Sanity", 2, TableAction.Click);

                Reports.TestStep = "Verify the second instance  has been created.";
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }


        [TestMethod]
        public void FMUC0110_REG0002()
        {
            string problemLogAdded = "";
            try
            {
                Reports.TestDescription = "FM13050_FM13051_FM13052_FD: Selection and removal of Search Vendor Problem,Comments-Date,User and Comments Verification.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);


                Reports.TestStep = "Navigate to Search Vendor.";
                FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();

                Reports.TestStep = "Create second instance taking ID from GAB.";
                FastDriver.SearchVendor.GABcode.FASetText(@"1592GAB");

                FastDriver.SearchVendor.Find.FAClick();

                Reports.TestStep = "Verify the GRADE for the search Vendor and Search Vendor Confirmation Date, Production Process ,Cost.";
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Support.AreEqual(@"Vendor Grade : Preferred", FastDriver.SearchVendor.VendorGrade.FAGetText());
                Support.AreEqual("", FastDriver.SearchVendor.VenderDetailsConfirmDate.FAGetValue());
                Support.AreEqual("0", FastDriver.SearchVendor.VenderDetailsProductionProcess.FAGetSelectedIndex().ToString());
                Support.AreEqual("0.00", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue());

                Reports.TestStep = "Click on Add Remove Button on Search Vendor Problem Log section.";
                FastDriver.SearchVendor.ProblemLogAddRemove.FAClick();

                Reports.TestStep = "Select the first problem log.";
                FastDriver.ProblemListDlg.WaitForScreenToLoad();

                if (!FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, 1, TableAction.GetCell).Element.IsSelected())
                {
                    FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, 1, TableAction.Click);
                    problemLogAdded = FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, 2, TableAction.GetText).Message;
                }

                Reports.TestStep = "Click on Done in dialog box.";
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.SearchVendor.WaitForScreenToLoad();

                var message = FastDriver.WebDriver.HandleDialogMessage();
                if (message != "No dialog present")
                {
                    Reports.StatusUpdate("Is this an expected Alert ?", true);

                }

                Reports.TestStep = "Verify the Problem log.";
                FastDriver.SearchVendor.WaitForScreenToLoad();
                //FastDriver.SearchVendor.ProblemLogTable.PerformTableAction(2, "Vendor - Incomplete Search", 2, TableAction.Click);
                FastDriver.SearchVendor.ProblemLogTable.PerformTableAction(2, problemLogAdded, 2, TableAction.Click);

                Reports.TestStep = "Verfy the count of the Problem Log entry is equal to 1.";
                var problemLogCount = FastDriver.SearchVendor.ProblemLogTable.GetRowCount();
                Reports.StatusUpdate("Is the number of rows in the Problem Log table equal to 1 ?", problemLogCount == 1);

                Reports.TestStep = "Again click Add/Remove button in Problem Log section to remove an entry of the problem log.";
                FastDriver.SearchVendor.ProblemLogAddRemove.FAClick();

                Reports.TestStep = "Deselect the first problemlog.";
                FastDriver.ProblemListDlg.WaitForScreenToLoad();
                //var tt = FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, "Vendor - Incomplete Search", 1, TableAction.GetCell).Element.FindElement(By.XPath("./span/span/input")).FAGetAttribute("checked");

                if (FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, problemLogAdded, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.XPath,"./span/span/input").FAGetAttribute("checked")=="true")
                {
                    FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, 1, TableAction.Click);
                }

                Reports.TestStep = "Click on Done in dialog box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Reports.TestStep = "Validate that the Problem Log entry has been removed.";
                problemLogCount = FastDriver.SearchVendor.ProblemLogTable.GetRowCount();
                Reports.StatusUpdate("Is the number of rows in the Problem Log table equal to 0 ?", problemLogCount == 0);

                Reports.TestStep = "Verify the GRADE for the search Vendor and Search Vendor Confirmation Date, Production Process ,Cost.";
                Support.AreEqual(@"Vendor Grade : Preferred", FastDriver.SearchVendor.VendorGrade.FAGetText());
                Support.AreEqual("", FastDriver.SearchVendor.VenderDetailsConfirmDate.FAGetValue());
                Support.AreEqual("0", FastDriver.SearchVendor.VenderDetailsProductionProcess.FAGetSelectedIndex().ToString());
                Support.AreEqual("0.00", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue());

                Reports.TestStep = "Enter comments in comments section.";
                var userComments = @"Comments for the search vendor 1234567890. Comments for the search vendor 1234567890. Comments for the search vendor 1234567890. Comments for the search vendor 1234567890. Comments for the search vendor 1234567890. Comments for the search vendor 1234567890.";
                FastDriver.SearchVendor.Comments.FASetText(userComments);

                Support.AreEqual(@"Comments for the search vendor 1234567890. Comments for the search vendor 1234567890. Comments for the search vendor 1234567890. Comments for the search vendor 1234567890. Comments for the search vendor 1234567890. Comments for the search vendor 1234567890.", FastDriver.SearchVendor.Comments.FAGetValue());

                Reports.TestStep = "Click Comments Save button";
                FastDriver.SearchVendor.CommentsSave.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Reports.TestStep = "Click Done button.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the first instance of the Search Vendor has been created.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "1592 GAB For Sanity", 2, TableAction.Click);

                Reports.TestStep = "Navigate to Search Vendor Summary page and verify the instance just created.";
                FastDriver.LeftNavigation.Navigate<SearchVendorSummary>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "1592 GAB For Sanity", 2, TableAction.Click);

                FastDriver.SearchVendorSummary.Edit.FAClick();

                Reports.TestStep = "Verify for the comments date.";
                FastDriver.SearchVendor.WaitForScreenToLoad();

                var dateValue1 = DateTime.Now.ToString("MM/dd/yyyy").Replace("/", "-");

                Reports.TestStep = "Validated the comments date in the Comments table.";
                var actual_CommentsDate = FastDriver.SearchVendor.CommentsTable.PerformTableAction(1, dateValue1, 1, TableAction.GetText).Message;
                Support.AreEqual(dateValue1, actual_CommentsDate);
                Reports.TestStep = "Validated the user ID in the Comments table.";
                FastDriver.SearchVendor.CommentsTable.PerformTableAction(2, AutoConfig.UserName.ToUpper(), 2, TableAction.Click);
                Reports.TestStep = "Validated the comments in the Comments table.";
                FastDriver.SearchVendor.CommentsTable.PerformTableAction(3, userComments, 3, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }



        [TestMethod]
        public void FMUC0110_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM13049_FM13046: The system shall not create disbursements or file imbalance on addition of a search vendor cost.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);

                Reports.TestStep = "Navigate to Search Vendor.";
                FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();

                Reports.TestStep = "Create the first instance taking ID from GAB.";
                FastDriver.SearchVendor.GABcode.FASetText(@"1592GAB");

                FastDriver.SearchVendor.Find.FAClick();

                Reports.TestStep = "Verify the GRADE for the search Vendor and Search Vendor Confirmation Date, Production Process ,Cost.";
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Support.AreEqual(@"Vendor Grade : Preferred", FastDriver.SearchVendor.VendorGrade.FAGetText());
                Support.AreEqual("", FastDriver.SearchVendor.VenderDetailsConfirmDate.FAGetValue());
                Support.AreEqual("0", FastDriver.SearchVendor.VenderDetailsProductionProcess.FAGetSelectedIndex().ToString());
                Support.AreEqual("0.00", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue());

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Edit button on Search Vendor Summary page.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "1592 GAB For Sanity", 2, TableAction.Click);
                FastDriver.SearchVendorSummary.Edit.FAClick();

                Reports.TestStep = "Enter cost for search Vendor.";
                FastDriver.SearchVendor.WaitForScreenToLoad();
                var dateValue1 = DateTime.Now.ToString("MM/dd/yyyy").Replace("/", "-");

                FastDriver.SearchVendor.VenderDetailsConfirmDate.FASetText(dateValue1);
                FastDriver.SearchVendor.VenderDetailsProductionProcess.FASelectItem(@"Amend");
                FastDriver.SearchVendor.VenderDetailsCost.FASetText(@"500.01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disb. Summary screen and verify the row count. Verify that Vendor Cost will not effect the file balance.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                var disbursementsCnt = FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount();
                for (int i = 1; i <= disbursementsCnt; i++)
                {
                    var amt = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(i, 7, TableAction.GetText).Message;
                    var payee = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(i, 8, TableAction.GetText).Message;

                    if(amt == "500.01" && payee == "1592 GAB For Sanity")
                    {
                        Reports.StatusUpdate("DEFECT AGAINST [BR = FM13049] : Search Vendor Cost has been added up to Active Disbursement Summary !", false);
                    }
                }
                Support.AreEqual("1", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString());
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }



        [TestMethod]
        public void FMUC0110_REG0004()
        {
            try
            {
                Reports.TestDescription = "FIELD_DEFINITION: Verifying the Hot Keys and Error Warming Conditions.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);

                Reports.TestStep = "Navigate to Search Vendor.";
                FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();

                Reports.TestStep = "Create the first instance taking ID from GAB.";
                FastDriver.SearchVendor.GABcode.FASetText(@"1592GAB");

                FastDriver.SearchVendor.Find.FAClick();

                Reports.TestStep = "Verify the GRADE for the search Vendor and Search Vendor Confirmation Date, Production Process ,Cost.";
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Edit button on Search Vendor Summary page.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "1592 GAB For Sanity", 2, TableAction.Click);
                var vendorSummaryCount = FastDriver.SearchVendorSummary.SearchVendorSummaryTable.GetRowCount();
                FastDriver.SearchVendorSummary.Edit.FAClick();

                Reports.TestStep = "Enter cost for search Vendor.";
                FastDriver.SearchVendor.WaitForScreenToLoad();
                FastDriver.SearchVendor.GABcode.FASetText(@"247");
                FastDriver.SearchVendor.Find.FAClick();

                Reports.TestStep = "Verify that Reset button is working as intended.";
                Keyboard.SendKeys("^R");

                Reports.TestStep = "Cancel without saving changes.";
                var alertText = FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                Support.AreEqual(@"Cancel without saving changes?", alertText);

                FastDriver.SearchVendor.WaitForScreenToLoad();
                Support.AreEqual(@"Vendor Grade : Preferred", FastDriver.SearchVendor.VendorGrade.FAGetText());

                Reports.TestStep = "Verify the function of Delete button.Click Cancel once the prompt appears.";
                FastDriver.BottomFrame.Delete();

                Reports.TestStep = "All information will be removed for this Search Vendor. Continue?.";
                alertText = FastDriver.WebDriver.HandleDialogMessage(true, false, 10);
                Support.AreEqual(@"All information will be removed for this Search Vendor.  Continue?", alertText);

                FastDriver.SearchVendor.WaitForScreenToLoad();
                Support.AreEqual(@"Vendor Grade : Preferred", FastDriver.SearchVendor.VendorGrade.FAGetText());

                Reports.TestStep = "Verify the function of Delete button.Click OK once the prompt appears.";
                FastDriver.BottomFrame.Delete();

                Reports.TestStep = "All information will be removed for this Search Vendor. Continue?.";
                alertText = FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                Support.AreEqual(@"All information will be removed for this Search Vendor.  Continue?", alertText);
                
                Reports.TestStep = "Navigate to Search Vendor.";
                FastDriver.LeftNavigation.Navigate<SearchVendorSummary>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();

                Reports.TestStep = "Verify that Search Vendor Instance is deleted.";
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, " Available", 2, TableAction.Click);
                Reports.StatusUpdate("Vendor Summary row count == " + vendorSummaryCount + "?", vendorSummaryCount == FastDriver.SearchVendorSummary.SearchVendorSummaryTable.GetRowCount());

                Reports.TestStep = "Verify hot key Alt+E.";
                //Keyboard.SendKeys("%{E}");
                PressHotKeys("%{E}", FastDriver.SearchVendor.GABcode);

                Reports.TestStep = "Update the vendor and verify the screen behavior while pressing ALT+Delete.";
                FastDriver.SearchVendor.WaitForScreenToLoad();

                FastDriver.SearchVendor.GABcode.FASetText(@"247");

                FastDriver.SearchVendor.Find.FAClick();

                Keyboard.SendKeys("^{DELETE}");

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 10);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                
                
                Reports.TestStep = "Verify that hot Key ALT+N is working as intended.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Lenders Advantage", 2, TableAction.Click);

                PressHotKeys("%{N}", FastDriver.SearchVendor.GABcode);

                Reports.TestStep = "Verify Search Vendor page is loaded.";
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Reports.TestStep = "Press hot key CTRL+Q and click Cancel once the prompt appears.";
                Keyboard.SendKeys("^Q");
                FastDriver.WebDriver.HandleDialogMessage(true, false, 10);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Verify the behavior of hot Key ALT+R.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Lenders Advantage", 2, TableAction.Click);
                Keyboard.SendKeys("%R");


                Reports.TestStep = "Verify an alert with 'All information will be removed for this Search Vendor. Continue?' has appeared.";
                alertText = FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                VerifyTheAlertMessage(alertText);

                 //Reports.StatusUpdate("Verify the alert contains the text : 'All information will be removed for this Search Vendor. Continue?'", alertText.Contains("All information will be removed for this Search Vendor. Continue?"));
                //Support.AreEqual(@"All information will be removed for this Search Vendor. Continue?", alertText);
                                   

                Reports.TestStep = "Verify that Search Vendor instance is deleted.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, " Available", 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }



        [TestMethod]
        public void FMUC0110_REG0006()
        {
            try
            {
                Reports.TestDescription = "SVFV_1: Verify the button properties.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);


                Reports.TestStep = "Navigate to Search Vendor.";
                FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();


                Reports.TestStep = "Verify the button properties.";
                Reports.StatusUpdate("Is Find button enabled ?", FastDriver.SearchVendor.Find.IsEnabled());
                Support.AreEqual("text", FastDriver.SearchVendor.VenderDetailsConfirmDate.FAGetAttribute("type").Trim().ToLower());
                Support.AreEqual("select", FastDriver.SearchVendor.VenderDetailsProductionProcess.TagName);
                Support.AreEqual("text", FastDriver.SearchVendor.VenderDetailsCost.FAGetAttribute("type").Trim().ToLower());
                Reports.StatusUpdate("Is Save button in Comments section enabled ?", FastDriver.SearchVendor.CommentsSave.IsEnabled());
                Support.AreEqual("textarea", FastDriver.SearchVendor.Comments.FATagName().ToLower());
                Reports.StatusUpdate("Is Add/Remove button in Problem Log section enabled ?", FastDriver.SearchVendor.ProblemLogAddRemove.IsEnabled());

                FastDriver.BottomFrame.Done();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }



        [TestMethod]
        public void FMUC0110_REG0007()
        {
            try
            {
                Reports.TestDescription = "SVFV_2: Field validation of Vendor Details.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);


                Reports.TestStep = "Navigate to Search Vendor.";
                FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();


                Reports.TestStep = "Enter invalid date.";
                FastDriver.SearchVendor.GABcode.FASetText(@"247");
                FastDriver.SearchVendor.Find.FAClick();


                FastDriver.SearchVendor.VenderDetailsConfirmDate.FASetText(@"13-32-2016");

                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Verify the Date field.";
                Support.AreEqual(@"??-??-????", FastDriver.SearchVendor.VenderDetailsConfirmDate.FAGetValue());

                Reports.TestStep = "Enter the valid date.";
                FastDriver.SearchVendor.VenderDetailsConfirmDate.FASetText(DateTime.Now.ToString("MM/dd/yyyy"));
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Verify the Date field.";
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.SearchVendor.VenderDetailsConfirmDate.FAGetValue());
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Validate Cost with Lower boundary.";
                FastDriver.SearchVendor.VenderDetailsCost.Clear();
                //FastDriver.SearchVendor.VenderDetailsCost.FAClick();
                /*FastDriver.SearchVendor.VenderDetailsCost.FASetText(OpenQA.Selenium.Keys.End);
                FastDriver.SearchVendor.VenderDetailsCost.FASetText(OpenQA.Selenium.Keys.Backspace);
                Playback.Wait(1000);
                FastDriver.SearchVendor.VenderDetailsCost.FASetText(OpenQA.Selenium.Keys.Backspace);
                Playback.Wait(1000);
                FastDriver.SearchVendor.VenderDetailsCost.FASetText(OpenQA.Selenium.Keys.Backspace);
                Playback.Wait(1000);*/
               
                FastDriver.SearchVendor.VenderDetailsCost.FASetText("200.01");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual(@"200.01", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue());


                Reports.TestStep = "Validate Cost with exact value.";
                FastDriver.SearchVendor.VenderDetailsCost.FASetText("1.00");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual(@"1.00", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue());


                Reports.TestStep = "Validate Cost with upper boundary value.";
                FastDriver.SearchVendor.VenderDetailsCost.FASetText("123456789012.22");
                Keyboard.SendKeys("{TAB}");
                //Support.AreEqual(@"123456789012.22", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue());
//              Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Verify the Cost field.";
                Support.AreEqual(@"?", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue());
                

                Reports.TestStep = "Handle the alert indicating the invalid data.";
                //FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home");
                FastDriver.SearchVendor.Find.FAClick();

                var alertText = FastDriver.WebDriver.HandleDialogMessage(true, true, 3);
                FastDriver.WebDriver.HandleDialogMessage(true, false, 3);

                Support.AreEqual(@"Please correct invalid data entered.", alertText);
                FastDriver.SearchVendor.WaitForScreenToLoad();
                FastDriver.SearchVendor.VenderDetailsCost.FASetText("1.00");
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }




        [TestMethod]
        public void FMUC0110_REG0008()
        {
            try
            {
                Reports.TestDescription = "SVFV_3: Verify the Search Vendor Summary screen.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);

                //AddSearchVendorAndProblemLog("HUDFLINSR1");

                AddSearchVendorAndProblemLog(GABCode: "HUDFLINSR1");


                Reports.TestStep = "Navigate to Search Vendor Summary screen.";
                FastDriver.LeftNavigation.Navigate<SearchVendorSummary>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();

                //FastDriver.SearchVendorSummary.New.FAClick();
                //FastDriver.SearchVendor.WaitForScreenToLoad();


                Reports.StatusUpdate("Is New button enabled ?", FastDriver.SearchVendorSummary.New.IsEnabled());
                Reports.StatusUpdate("Is Edit button disabled ?", !FastDriver.SearchVendorSummary.Edit.IsEnabled());
                Reports.StatusUpdate("Is Remove button disabled ?", !FastDriver.SearchVendorSummary.Remove.IsEnabled());



                Reports.TestStep = "Click on New Button.";
                FastDriver.SearchVendorSummary.New.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Reports.TestStep = "Enter a GAB.";
                FastDriver.SearchVendor.GABcode.FASetText(@"247");
                FastDriver.SearchVendor.Find.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Edit and Delete button property now.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Lenders Advantage", 2, TableAction.Click);
                Reports.StatusUpdate("Is New button enabled ?", FastDriver.SearchVendorSummary.New.IsEnabled());
                Reports.StatusUpdate("Is Edit button enabled ?", FastDriver.SearchVendorSummary.Edit.IsEnabled());
                Reports.StatusUpdate("Is Remove button enabled ?", FastDriver.SearchVendorSummary.Remove.IsEnabled());
                var vendorSummaryCount = FastDriver.SearchVendorSummary.SearchVendorSummaryTable.GetRowCount();
                
                Reports.TestStep = "Verify if user is able to Remove the Search Vendor instance upon clicking Remove button.";
                FastDriver.SearchVendorSummary.Remove.FAClick();

                Reports.TestStep = "Check if 'All information will be removed for this Search Vendor. Continue?' message is displayed.";
                var alertText = FastDriver.WebDriver.HandleDialogMessage(true, false, 10);
                Support.AreEqual(@"All information will be removed for this Search Vendor.  Continue?", alertText);

                Reports.TestStep = "Remove one instance and verify that instance is deleted.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);
                Reports.StatusUpdate("Vendor Summary row count == " + vendorSummaryCount + "?", vendorSummaryCount == FastDriver.SearchVendorSummary.SearchVendorSummaryTable.GetRowCount());
                //FastDriver.SearchVendor.WaitForScreenToLoad();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }



        [TestMethod]
        public void FMUC0110_REG0009()
        {
            try
            {
                Reports.TestDescription = "SVFV_4: Verify the Field validation in Search Vendor Summary screen.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);

                //AddSearchVendorAndProblemLog("Hudflinsr1");


                Reports.TestStep = "Navigate to Search Vendor.";
                FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();

                //FastDriver.SearchVendor.GABcode.FASetText(@"254");
                FastDriver.SearchVendor.GABcode.FASetText("Hudflinsr1");

                FastDriver.SearchVendor.Find.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();

                FastDriver.SearchVendor.VenderDetailsConfirmDate.FASetText(DateTime.Now.ToDateString());

                FastDriver.SearchVendor.VenderDetailsProductionProcess.FASelectItem(@"Date Down");

                FastDriver.SearchVendor.VenderDetailsCost.FASetText(@"20");

                FastDriver.SearchVendor.Comments.FASetText(@"Testsearchvendor");


                FastDriver.SearchVendor.CommentsSave.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();

                
                Reports.TestStep = "Click on Done button.";
                FastDriver.BottomFrame.Done();
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                
                Reports.TestStep = "Click on Edit button.";

                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);

                FastDriver.SearchVendorSummary.Edit.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();

                Reports.TestStep = "Edit the Business phone.";

                if(!FastDriver.SearchVendor.Edit.IsSelected())
                {
                    FastDriver.SearchVendor.Edit.FAClick();
                }

                Reports.TestStep = "Validate Business Phone with Upper boundary.";
                FastDriver.SearchVendor.BusinessPhone.FASetText(@"34567891234");
                Keyboard.SendKeys("{TAB}");
                FastDriver.SearchVendor.BusinessFax.FASetText(@"23455677888");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Validate Business Phone with Upper boundary.";
                Support.AreEqual(@"(345)678-9123", FastDriver.SearchVendor.BusinessPhone.FAGetValue());
                Support.AreEqual(@"(234)556-7788", FastDriver.SearchVendor.BusinessFax.FAGetValue());

                Reports.TestStep = "Validate Business Phone with Lower boundary.";
                FastDriver.SearchVendor.BusinessPhone.FASetText(@"123");
                FastDriver.SearchVendor.BusinessFax.FASetText(@"123");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Validate Business Phone with Lower boundary.";
                Support.AreEqual(@"(???)???-????", FastDriver.SearchVendor.BusinessPhone.FAGetValue());
                Support.AreEqual(@"(???)???-????", FastDriver.SearchVendor.BusinessFax.FAGetValue());

                Reports.TestStep = "Handle the alert indicating the invalid data.";
                FastDriver.SearchVendor.WaitForScreenToLoad();
                FastDriver.SearchVendor.Find.FAClick();
                //FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home");

                var alertText = FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.WebDriver.HandleDialogMessage(true, false, 10);
                Support.AreEqual(@"Please correct invalid data entered.", alertText);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }


        #endregion

        #region Private Methods

        private void LoginToIIS(bool IsSecondUserToUse = false)
        {
            #region data setup
            //string credentials = ""
            Credentials credentials;
            if (IsSecondUserToUse)
            {
                credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
            }
            else
            {
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            }
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            catch (Exception ex)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test ! Error :" + ex.Message);
            }
        }


        private bool VerifyTheAlertMessage(string alertText)
        {
            try
            {
                bool mismatches = false;
                List<string> lst = new List<string>()
                {
                    "All","information","will","be","removed","for","this","Search","Vendor.","", "Continue?"
                };
                var actStmt = alertText.Split(' ').ToList();
                for (int i = 0; i <= lst.Count - 1; i++)
                {
                    if (lst[i] != actStmt[i])
                    {
                        mismatches = true;
                        Reports.StatusUpdate("The alert message is not as expected. Expected :" + lst[i] + "  Actual :" + actStmt[i], false);
                    }
                }

                if (!mismatches)
                {
                    Reports.StatusUpdate("An alert with the message 'All information will be removed for this Search Vendor. Continue?' has been successfully handled !", true);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        private bool PressHotKeys(string hotKey, OpenQA.Selenium.IWebElement element=null)
        {
            int timeTick = 0;
            bool result = false;

            while (!result || timeTick <= 50)
            {
                try
                {
                    Keyboard.SendKeys(hotKey);
                    if (element == null)
                        return true;
                    Playback.Wait(5000);
                    timeTick = timeTick + 5;
                    if (element.IsVisible() && element != null)
                    {
                        result = true;
                        break;
                    }
                    continue;
                }
                catch
                {
                    result = false;
                    continue;
                }
            }
            return result;
        }

        private OpenQA.Selenium.IWebElement GetElementInsideCell(string innerElementXPathValue, int row, int col)
        {
            return FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(row, col, TableAction.GetCell).Element.FAFindElement(ByLocator.XPath,innerElementXPathValue);
        }

        #region File Creation

        private CreateFileRequest BuildCreateFileRequest()
        {
            var x = new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,

                #region File
                File = new File()
                {

                    SalesPriceAmount = 5000,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "COMMERCIAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,



                    BusinessParties = new FileBusinessParty[] 
                    { 
                        
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            AdditionalRole = new FASTWCFHelpers.FastFileService.AdditionalRoleList(){ eAddtionalRole = AdditionalRoleType.SellersAttorney },
                            RoleTypeObjectCD = "BUSSOURCE",
                                
                            
                        },

                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DirectedBy",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersBroker
                            },
                        },

                    /*    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "AssociatedBusinessParty",
                    
                        },

                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NewLenderInformation",
                        }*/
                    },


                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            
                            Taxes = new Taxes[]
                            {
                                new Taxes()
                                {
                                     APN = "Prop1APN1",
                                },
                                new Taxes()
                                {
                                     APN = "9845012345",
                                }
                            },
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                    
                                } 
                            } 
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1SpouLastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2SpouLastname"
                        }
                    },


                    /*  NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                      {
                          LoanNumber = "WCF_DefaultLoanNumber",
                          NewLoanAmount = 5000.00m,
                          LiabilityAmount = 5000.00m,
                          BenMortgageeTextID = 0,
                          FileBusinessParty = new FileBusinessParty
                          {
                              Name = "Nhat Nguyen",
                              AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                          },
                          LoanTypeCdID = 0,
                          FundDate = DateTime.Today
                      },*/

                    FileNotes = new FileNote[] 
                    { 
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
                #endregion
            };


            return x;
        }


        private string CreateFile(bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = BuildCreateFileRequest1();
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch
            {
                return "";
            }
            return fileNumber;
        }





        //private string CreateFile(bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        //{
        //    string fileNumber = "";
        //    try
        //    {
        //        Reports.TestStep = "Create File using web service.";
        //        FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
        //        fileRequest = BuildCreateFileRequest();
        //        fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
        //        FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        //    }
        //    catch
        //    {
        //        return "";
        //    }
        //    return fileNumber;
        //}


        private CreateFileRequest BuildCreateFileRequest1()
        {
            var x = new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,

                #region File
                File = new File()
                {
                    SalesPriceAmount = 5000,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "COMMERCIAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,


                    BusinessParties = new FileBusinessParty[] 
                    { 
                        
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                    },


                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            
                            Taxes = new Taxes[]
                            {
                                new Taxes()
                                {
                                     APN = "Prop1APN1",
                                },
                                new Taxes()
                                {
                                     APN = "9845012345",
                                }
                            },
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                    
                                } 
                            } 
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1SpouLastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2SpouLastname"
                        }
                    },


                    /*  NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                      {
                          LoanNumber = "WCF_DefaultLoanNumber",
                          NewLoanAmount = 5000.00m,
                          LiabilityAmount = 5000.00m,
                          BenMortgageeTextID = 0,
                          FileBusinessParty = new FileBusinessParty
                          {
                              Name = "Nhat Nguyen",
                              AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                          },
                          LoanTypeCdID = 0,
                          FundDate = DateTime.Today
                      },*/

                    FileNotes = new FileNote[] 
                    { 
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
                #endregion
            };


            return x;
        }


        #endregion


        private void AddSearchVendorAndProblemLog(string GABCode, bool navigateToSummaryThruDone = true, bool SearchVendorPageNeedsToLoad = true)
        {
            if (SearchVendorPageNeedsToLoad)
            {
                Reports.TestStep = "Navigate to Search Vendor.";
                FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();
            }
            else
            {
                Reports.TestStep = "Click New button on Search Vendor Summary page to load Search Vendor page.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.New.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();
            }

            //FastDriver.SearchVendor.GABcode.FASetText(@"254");
            FastDriver.SearchVendor.GABcode.FASetText(GABCode);

            FastDriver.SearchVendor.Find.FAClick();
            Playback.Wait(2000);

            FastDriver.SearchVendor.VenderDetailsConfirmDate.FASetText(DateTime.Now.ToDateString());

            FastDriver.SearchVendor.VenderDetailsProductionProcess.FASelectItem(@"Amend");

            FastDriver.SearchVendor.VenderDetailsCost.FASetText(@"40");

            FastDriver.SearchVendor.Comments.FASetText(@"Testsearchvendor");



            FastDriver.SearchVendor.ProblemLogAddRemove.FAClick();


            Reports.TestStep = "Select the first problem log.";
            FastDriver.ProblemListDlg.WaitForScreenToLoad();

            if (!FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, 1, TableAction.GetCell).Element.IsSelected())
            {
                FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, 1, TableAction.Click);
            }

            Reports.TestStep = "Click on Done in dialog box.";
            FastDriver.DialogBottomFrame.ClickDone();

            FastDriver.SearchVendor.WaitForScreenToLoad();
            FastDriver.SearchVendor.CommentsSave.FAClick();

            var message = FastDriver.WebDriver.HandleDialogMessage();
            if (message != "No dialog present")
            {
                Reports.StatusUpdate("Is this an expected Alert ?", true);

            }


            if (navigateToSummaryThruDone)
            {

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that search vendor is added.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();

                if (GABCode == "254")
                {
                    FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Ctx Mortgage Company", 2, TableAction.Click);
                }
                else if (GABCode == "HUDFLINSR1")
                {
                    FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
                }
            }
        }

        #endregion







        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
