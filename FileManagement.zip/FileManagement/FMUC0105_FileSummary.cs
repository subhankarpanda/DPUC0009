﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using System.Runtime.Serialization;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0105_File_Summary : MasterTestClass
    {

        #region BAT

        #region FMUC0105_BAT0001
        [TestMethod]
        public void FMUC0105_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Access File Summary Screen from Nav Tree.";
               
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to File summary screen.";
                FastDriver.LeftNavigation.Navigate<FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();

                Reports.TestStep = "Validate the Basic File Details.";
                Support.AreEqual(File.FileNumber, FastDriver.FileSummary.FileNumber.FAGetText());
                Support.AreEqual("Open", FastDriver.FileSummary.Status.FAGetText());
                Support.AreEqual("FAST", FastDriver.FileSummary.OrderSource.FAGetText());
                Support.AreEqual("123456789", FastDriver.FileSummary.ExternalNumber.FAGetText());
                Support.AreEqual("J305 JJEJAMQ JJEJAMQ ALBANY CA 92707", FastDriver.FileSummary.PropertyAdd.FAGetText().Clean());
                Support.AreEqual("Title/Escrow", FastDriver.FileSummary.ServiceType.FAGetText());
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileSummary.TranType.FAGetText());
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.FileSummary.OpeningDate.FAGetText());
                Support.AreEqual("ALAMEDA", FastDriver.FileSummary.County.FAGetText());
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.LoanAmount.FAGetText());
                Support.AreEqual("Residential", FastDriver.FileSummary.BuSegment.FAGetText());
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.SalesPrice.FAGetText());

                Reports.TestStep = "Validate the Business Parties screen";
                FastDriver.FileSummary.BusinessParties.FAClick();
                FastDriver.FileSummary.WaitForBusPartiesScreenToLoad();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Business Source", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "New Lender", 3, TableAction.GetText).Message.Clean(), true);

                Reports.TestStep = "Validate the Loan/Disbursement screen";
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();
                Support.AreEqual("0.00", FastDriver.FileSummary.NetTotalDeposits.FAGetText());
                Support.AreEqual("5,000.00", FastDriver.FileSummary.Loanamt.FAGetText());
                Support.AreEqual("$ 5,000.00", FastDriver.FileSummary.SellerNetCheck.FAGetText());
                Support.AreEqual("Lenders Advantage", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(1, "1", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(1, "1", 4, TableAction.GetText).Message.Clean(), true);
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0105_BAT0002
        [TestMethod]
        public void FMUC0105_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_01: Access File Summary screen from FAST VIEW.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(5000); //Wait 5 seconds for file to show up on search results

                Reports.TestStep = "Perform file search from FAST View screen";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FastView.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 20);
                FastDriver.FASTView.WaitForScreenToLoad();
                FastDriver.FASTView.FileNumber.FASetText(File.FileNumber.Substring(0, (File.FileNumber.Length - 1)) + "*");
                FastDriver.FASTView.FromDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.FASTView.ToDate.FASetText(DateTime.Now.ToDateString());
                Playback.Wait(500);
                FastDriver.FASTView.FindNow.FAClick();
                Playback.Wait(500);
                try
                {
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 20);
                    FastDriver.FileSearch.SwitchToFastViewContentFrame();
                    FastDriver.FileSearch.WaitCreation(FastDriver.FileSearch.SearchResultTable);
                    FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, File.FileNumber, 1, TableAction.Click);
                }
                catch (Exception ex)
                {
                    Reports.TestStep = "Perform search second time.";
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 20);
                    FastDriver.FASTView.WaitForScreenToLoad();
                    Playback.Wait(5000); //Wait 5 seconds for file to show up on search results
                    FastDriver.FileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 20);
                    FastDriver.FileSearch.SwitchToFastViewContentFrame();
                    FastDriver.FileSearch.WaitCreation(FastDriver.FileSearch.SearchResultTable);
                    FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, File.FileNumber, 1, TableAction.Click);
                }

                FastDriver.FileSearch.Select.FAClick();
                FastDriver.FileSearch.SwitchToFastViewContentFrame();
                FastDriver.FileSearch.WaitCreation(FastDriver.FileSearch.FindNow);
                //FastDriver.FileSearch.WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.SendControlShift("i");

                Reports.TestStep = "Validate the Basic File Details from File Summary screen";
                FastDriver.FileSummary.WaitForFastViewScreenToLoad();
                Support.AreEqual(File.FileNumber, FastDriver.FileSummary.FileNumber.FAGetText());
                Support.AreEqual("Open", FastDriver.FileSummary.Status.FAGetText());
                Support.AreEqual("FAST", FastDriver.FileSummary.OrderSource.FAGetText());
                Support.AreEqual("123456789", FastDriver.FileSummary.ExternalNumber.FAGetText());
                Support.AreEqual("J305 JJEJAMQ JJEJAMQ ALBANY CA 92707", FastDriver.FileSummary.PropertyAdd.FAGetText().Clean());
                Support.AreEqual("Title/Escrow", FastDriver.FileSummary.ServiceType.FAGetText());
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileSummary.TranType.FAGetText());
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.FileSummary.OpeningDate.FAGetText());
                Support.AreEqual("ALAMEDA", FastDriver.FileSummary.County.FAGetText());
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.LoanAmount.FAGetText());
                Support.AreEqual("Residential", FastDriver.FileSummary.BuSegment.FAGetText());
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.SalesPrice.FAGetText());

                Reports.TestStep = "Validate the Business Parties screen";
                FastDriver.FileSummary.BusinessParties.FAClick();
                FastDriver.FileSummary.WaitForFastViewBusPartiesScreenToLoad();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Business Source", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "New Lender", 3, TableAction.GetText).Message.Clean(), true);

                Reports.TestStep = "Validate the Loan/Disbursement screen";
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForFastViewLoanDisScreenToLoad();
                Support.AreEqual("0.00", FastDriver.FileSummary.NetTotalDeposits.FAGetText());
                Support.AreEqual("5,000.00", FastDriver.FileSummary.Loanamt.FAGetText());
                Support.AreEqual("$ 5,000.00", FastDriver.FileSummary.SellerNetCheck.FAGetText());
                Support.AreEqual("Lenders Advantage", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(1, "1", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(1, "1", 4, TableAction.GetText).Message.Clean(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0105_BAT0003
        [TestMethod]
        public void FMUC0105_BAT0003()
        {
            try
            {
                Reports.TestDescription = "Main Course:  Access File Summary screen from My FAST Today";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to My Fast Today screen and launch File Summary";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.WaitForTaskTableToLoad();
                string fileNum = FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(2, 4, TableAction.GetText).Message;
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.MyFASTToday.FileInfo.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("File Summary", true, 20);
                FastDriver.FileSummary.WaitForMyFastTodayScreenToLoad();
                Support.AreEqual(fileNum, FastDriver.FileSummary.FileNumber.FAGetText());
                FastDriver.DialogBottomFrame.ClickDone();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0105_BAT0004
        [TestMethod]
        public void FMUC0105_BAT0004()
        {
            try
            {
                Reports.TestDescription = "Main Course:  Access File Summary screen from Quick File Entry screen";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                string addrLine1 = Support.RandomString("AAAAAAAANZ");
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = addrLine1;
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(10000); //Wait for file to show up in search result

                Reports.TestStep = "Navigate to Quick File Entry screen and launch File Summary";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText(addrLine1);
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("Santa Ana");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.PropertyCounty.FASetText("Orange");
                FastDriver.DuplicateFileSearch.FindNow.FAClick();
                try
                {
                    FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearchResults.SearchResults.PerformTableAction(1, File.FileNumber, 1, TableAction.DoubleClick);
                }catch(Exception)
                {
                    Reports.TestStep = "File not show up in search result, try again.";
                    Playback.Wait(10000);
                    FastDriver.WebDriver.HandleDialogMessage(true, false, 20);
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText(addrLine1);
                    FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("Santa Ana");
                    FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                    FastDriver.DuplicateFileSearch.PropertyCounty.FASetText("Orange");
                    FastDriver.DuplicateFileSearch.FindNow.FAClick();
                    FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearchResults.SearchResults.PerformTableAction(1, File.FileNumber, 1, TableAction.DoubleClick);
                }

                Reports.TestStep = "Validate file Basic Details information";
                FastDriver.WebDriver.WaitForWindowAndSwitch("File Summary", true, 20);
                FastDriver.FileSummary.WaitForMyFastTodayScreenToLoad();
                Support.AreEqual(File.FileNumber, FastDriver.FileSummary.FileNumber.FAGetText());
                FastDriver.DialogBottomFrame.ClickDone();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion BAT

        #region REG

        #region FMUC0105_REG0001
        [TestMethod]
        public void FMUC0105_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM9208_FM9209_FM9210_FM9212_FM9829: Display All File Business Parties.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Create File
                Reports.TestStep = "Create a new file with multiple file business parties";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[] 
                    { 
                        new FileBusinessParty() 
                        { 
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),    
                            RoleTypeObjectCD = "BUSSOURCE", 
                            CustomerReferenceNumber = "1234567890", 
                            AdditionalRole = new AdditionalRoleList() { eAddtionalRole = AdditionalRoleType.NewLender } 
                        }, 

                        new FileBusinessParty() 
                        { 
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),   
                            RoleTypeObjectCD = "DirectedBy" 
                        }, 

                        new FileBusinessParty() 
                        { 
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),  
                            RoleTypeObjectCD = "ASSOTDPTY" 
                        } 
                    }; 
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(10000); // Wait for File Summary screen to get populated
                #endregion Create File

                Reports.TestStep = "Navigate to File Homepage screen, select Attention for Business Source, Directed By, and Associated Business Party";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.BusinessPartyAttention.FASelectItemByIndex(1);
                FastDriver.FileHomepage.DirectedBycomboAttention.FASelectItemByIndex(1);
                FastDriver.FileHomepage.AssociateBusinessPartyAttention.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Navigate to File summary screen.";
                FastDriver.LeftNavigation.Navigate<FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();

                Reports.TestStep = "Validate FM9210  Display All File Business Parties";
                FastDriver.FileSummary.BusinessParties.FAClick();
                FastDriver.FileSummary.WaitForBusPartiesScreenToLoad();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Business Source", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Fire Insurance 1 business street 1 Fire Insurance 1 business street 2 Fire Insurance 1 business city NY 74081-6545", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Business Source", 5, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("busparty@\r\nregression.com", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Business Source", 8, TableAction.GetText).Message, true);
                Support.AreEqual("(631)315-4841", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Business Source", 9, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("(745)451-0848", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Business Source", 10, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("(962)105-4485", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Business Source", 11, TableAction.GetText).Message.Clean(), true);

                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Associated Party", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Fire Insurance 1 business street 1 Fire Insurance 1 business street 2 Fire Insurance 1 business city NY 74081-6545", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Associated Party", 5, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("busparty@\r\nregression.com", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Associated Party", 8, TableAction.GetText).Message, true);
                Support.AreEqual("(631)315-4841", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Associated Party", 9, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("(745)451-0848", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Associated Party", 10, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("(962)105-4485", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Associated Party", 11, TableAction.GetText).Message.Clean(), true);

                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Directed By", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Fire Insurance 1 business street 1 Fire Insurance 1 business street 2 Fire Insurance 1 business city NY 74081-6545", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Directed By", 5, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("busparty@\r\nregression.com", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Directed By", 8, TableAction.GetText).Message, true);
                Support.AreEqual("(631)315-4841", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Directed By", 9, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("(745)451-0848", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Directed By", 10, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("(962)105-4485", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "Directed By", 11, TableAction.GetText).Message.Clean(), true);

                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "New Lender", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Fire Insurance 1 business street 1 Fire Insurance 1 business street 2 Fire Insurance 1 business city NY 74081-6545", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "New Lender", 5, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("busparty@\r\nregression.com", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "New Lender", 8, TableAction.GetText).Message, true);
                Support.AreEqual("(631)315-4841", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "New Lender", 9, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("(745)451-0848", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "New Lender", 10, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("(962)105-4485", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(2, "New Lender", 11, TableAction.GetText).Message.Clean(), true);

                Reports.TestStep = "Validate FM9212  Order File Business Parties by Role";
                Support.AreEqual("Associated Business Party Contact", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Associated Party", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "2", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Business Source", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "3", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Business Source Contact", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "4", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Buyer", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "5", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Directed By", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "6", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Directed By Contact", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "7", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Escrow Officer", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "8", 2, TableAction.GetText).Message.Clean(), true);

                Reports.TestStep = "Navigate to Buyers screen and enter exchange company information";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("HUDFLINSR1");
                FastDriver.ExchangeCompany.Find.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Sellers screen and enter exchange company information";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("HUDFLINSR1");
                FastDriver.ExchangeCompany.Find.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate FM9829  Show Exchange Company for Buyer/Seller";
                FastDriver.LeftNavigation.Navigate<FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                FastDriver.FileSummary.BusinessParties.FAClick();
                FastDriver.FileSummary.WaitForBusPartiesScreenToLoad();
                Support.AreEqual("Exchange Company for BuyerName BuyerLastName", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "9", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Exchange Company for SellerName SellerLastName", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction(1, "10", 2, TableAction.GetText).Message.Clean(), true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0105_REG0002
        [TestMethod]
        public void FMUC0105_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM9213  New Loan Display";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with two loan instances";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.NewLoan.NewLoanAmount = (decimal)100000.00;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan screen and add a second loan instance.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("200000.00" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("200000.00" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("HUDFLINSR1" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Loan/Disbursement screen. If the file has more than one New Loan, each new loan's details shall be displayed separately on the Loans / Disbursements tab (one below the other)";
                FastDriver.LeftNavigation.Navigate<FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();
                Support.AreEqual("$100,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(1, "1", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("$200,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(1, "2", 4, TableAction.GetText).Message.Clean(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0105_REG0003
        [TestMethod]
        public void FMUC0105_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM9215  Sub escrow service changes";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a new file with Escorw and Sub Escrow services.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.Services = new Service[]
                {
                    new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "EO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "SEO"
                        }
                };
                fileRequest.File.NewLoan.NewLoanAmount = (decimal)100000.00;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion create file

                Reports.TestStep = "Validate If service type is also sub escrow then in Loan/Disbursement tab, the section of Buyer / Seller will be named as 'Outside Escrow Company Amounts'.";
                FastDriver.LeftNavigation.Navigate<FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();
                Support.AreEqual("Outside Escrow Company", FastDriver.FileSummary.BuyerSellerLabel.FAGetText(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0105_REG0004
        [TestMethod]
        public void FMUC0105_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM9216  Transaction type changes";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a new Refinance file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.NewLoan.NewLoanAmount = (decimal)100000.00;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion create file

                Reports.TestStep = "Validate If transaction type is 'Refinance' or 'Equity Loan' or 'Construction Disbursement' then in Loan/Disbursement tab, the section of Buyer / Seller will be named as 'Borrower Amounts'";
                FastDriver.LeftNavigation.Navigate<FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();
                Support.AreEqual("Borrower", FastDriver.FileSummary.BuyerSellerLabel.FAGetText(), true);
                Support.AreEqual("$ 100,000.00", FastDriver.FileSummary.BuyerNetCheck.FAGetText(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0105_REG0005
        [TestMethod]
        public void FMUC0105_REG0005()
        {
            try
            {
                Reports.TestDescription = "Validate Payoff Loan instance";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a new Refinance file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.NewLoan.NewLoanAmount = (decimal)100000.00;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion create file

                Reports.TestStep = "Add an Payoff Loan instance.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("HUDFLINSR1");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.LenderReference.FASetText("1234567890" + FAKeys.Tab);
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("200000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to File Summary screen and validate Payoff Loan instance.";
                FastDriver.LeftNavigation.Navigate<FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1", FastDriver.FileSummary.PayOffLoanTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("1234567890", FastDriver.FileSummary.PayOffLoanTable.PerformTableAction(1, "1", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("$200,000.00", FastDriver.FileSummary.PayOffLoanTable.PerformTableAction(1, "1", 4, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("$0.00", FastDriver.FileSummary.PayOffLoanTable.PerformTableAction(1, "1", 5, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("$200,000.00", FastDriver.FileSummary.PayOffLoanTable.PerformTableAction(1, "1", 6, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("$200,000.00", FastDriver.FileSummary.PayOffLoanTable.PerformTableAction(1, "1", 7, TableAction.GetText).Message.Clean(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0105_REG0006
        [TestMethod]
        public void FMUC0105_REG0006()
        {
            try
            {
                Reports.TestDescription = "US213016_Verify that, the OEC amounts are read only (if service type:sub escrow) in Loan/Disbursement tab of File Summary";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var BuyerDeposit = new DepositParameters()
                {
                    Amount = 300.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer",
                    Comments = "Test Deposit"
                };
                var SellerDeposit = new DepositParameters()
                {
                    Amount = 400.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Seller",
                    Payor = "Seller",
                    Comments = "Test Deposit"
                };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Validate The Net Total Disbursements, Outside Escrow Company Amounts (Funds Held After Close, Funds Due, Net Check , New Loan Recap, Lender Name,Loan Amounts and Projected Loan Funding)
                Reports.TestStep = "Navigate to File Summary | Loan /Disbursement Tab.";
                FastDriver.FileSummary.Open();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();

                Reports.TestStep = " Validate The Net Total Disbursements, Outside Escrow Company Amounts";
                Support.AreEqual("5,000.00", FastDriver.FileSummary.NetTotalDisbursements.FAGetText().ToString().Trim(), true);
                Support.AreEqual("0.00", FastDriver.FileSummary.NetTotalDeposits.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 5,000.00", FastDriver.FileSummary.SellerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 3, TableAction.GetText).Message.ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString().Trim(), true);
                #endregion

                #region Validate The Net Total Disbursements, Outside Escrow Company Amounts after entering Buyer / Seller charge in OEC screen.
                Reports.TestStep = "Navigate to OEC Screen, Enter GAB.";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("247");

                Reports.TestStep = "Enter the Buyer Charge and Seller Charge.";
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: "Test Description", buyerCharge: 100, sellerCharge: 200);

                Reports.TestStep = "Navigate to File Summary | Loan /Disbursement Tab.";
                FastDriver.FileSummary.Open();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();

                Reports.TestStep = " Validate The Net Total Disbursements, Outside Escrow Company Amounts";
                Support.AreEqual("5,100.00", FastDriver.FileSummary.NetTotalDisbursements.FAGetText().ToString().Trim(), true);
                Support.AreEqual("0.00", FastDriver.FileSummary.NetTotalDeposits.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 100.00", FastDriver.FileSummary.BuyerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 4,800.00", FastDriver.FileSummary.SellerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 3, TableAction.GetText).Message.ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString().Trim(), true);
                #endregion

                #region Validate The Net Total Disbursements, Outside Escrow Company Amounts after entering Buyer / Seller charge in Holds Funds screen.
                Reports.TestStep = "Navigate to Hold Funds Screen.";
                FastDriver.HoldFunds.Open();

                Reports.TestStep = "Enter the Buyer Charge or Seller Charge.";
                FastDriver.HoldFunds.RadbtnBuyer.FASetCheckbox(true);
                FastDriver.HoldFunds.BuyerCharge.FASetText("300");

                Reports.TestStep = "Navigate to File Summary | Loan /Disbursement Tab.";
                FastDriver.FileSummary.Open();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();

                Reports.TestStep = " Validate The Net Total Disbursements, Outside Escrow Company Amounts";
                Support.AreEqual("5,100.00", FastDriver.FileSummary.NetTotalDisbursements.FAGetText().ToString().Trim(), true);
                Support.AreEqual("0.00", FastDriver.FileSummary.NetTotalDeposits.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 300.00", FastDriver.FileSummary.BuyerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 400.00", FastDriver.FileSummary.BuyerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 4,800.00", FastDriver.FileSummary.SellerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 3, TableAction.GetText).Message.ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString().Trim(), true);
                #endregion

                #region Validate The Net Total Disbursements, Outside Escrow Company Amounts after entering Buyer (Charge and Credit) and Seller (Charge and Credit) for any 1 of charges in Payoff Loan Charges section
                Reports.TestStep = "Navigate to PayOff Loan Screen, Enter GAB.";
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.FindGABCode("247");

                Reports.TestStep = "Enter the Buyer Charge and Seller Charge.";
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FASetText("Test Description");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FASetText("400");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit.FASetText("500");
                FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FASetText("600");
                FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit.FASetText("700");

                Reports.TestStep = "Navigate to File Summary | Loan /Disbursement Tab.";
                FastDriver.FileSummary.Open();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();

                Reports.TestStep = " Validate The Net Total Disbursements, Outside Escrow Company Amounts";
                Support.AreEqual("5,200.00", FastDriver.FileSummary.NetTotalDisbursements.FAGetText().ToString().Trim(), true);
                Support.AreEqual("0.00", FastDriver.FileSummary.NetTotalDeposits.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 300.00", FastDriver.FileSummary.BuyerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 300.00", FastDriver.FileSummary.BuyerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 4,900.00", FastDriver.FileSummary.SellerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 3, TableAction.GetText).Message.ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString().Trim(), true);
                Support.AreEqual("$0.00", FastDriver.FileSummary.PayOffLoanPrincipalBalance.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$0.00", FastDriver.FileSummary.PayOffLoanTotalCharges.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$-200.00", FastDriver.FileSummary.PayOffLoanPayoffAmount.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$-200.00", FastDriver.FileSummary.PayOffLoanCheckAmount.FAGetText().ToString().Trim(), true);
                #endregion

                #region Validate The Net Total Disbursements, Outside Escrow Company Amounts after entering Enter the Buyer or Seller amount in Deposit In Escrow screen
                Reports.TestStep = "Navigate to Deposit in Escrow.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Deposit Buyer Charge.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(BuyerDeposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Deposit Seller Charge.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(SellerDeposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);


                Reports.TestStep = "Navigate to File Summary | Loan /Disbursement Tab.";
                FastDriver.FileSummary.Open();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();

                Reports.TestStep = " Validate The Net Total Disbursements, Outside Escrow Company Amounts";
                Support.AreEqual("5,600.00", FastDriver.FileSummary.NetTotalDisbursements.FAGetText().ToString().Trim(), true);
                Support.AreEqual("700.00", FastDriver.FileSummary.NetTotalDeposits.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 300.00", FastDriver.FileSummary.BuyerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 5,300.00", FastDriver.FileSummary.SellerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 3, TableAction.GetText).Message.ToString().Trim(), true);
                Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString().Trim(), true);
                Support.AreEqual("$0.00", FastDriver.FileSummary.PayOffLoanPrincipalBalance.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$0.00", FastDriver.FileSummary.PayOffLoanTotalCharges.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$-200.00", FastDriver.FileSummary.PayOffLoanPayoffAmount.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$-200.00", FastDriver.FileSummary.PayOffLoanCheckAmount.FAGetText().ToString().Trim(), true);
                #endregion

                #region Validate The Net Total Disbursements, Outside Escrow Company Amounts after entering Buyer (Charge and Credit) and Seller (Charge and Credit) for any 1 of charges in Origination Charges section
                Reports.TestStep = "Navigate to New Loan Screen, Enter GAB.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("247");

                Reports.TestStep = "Enter the Buyer (Charge and Credit) and Seller (Charge and Credit) for any 1 of Origination charges";
                FastDriver.NewLoan.ClickChargesTab();
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.LoanChargesOriginationChargeTable, chargeDescription: "", buyerCharge: 200);
                else
                    FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.LoanChargesOriginationChargeTable, chargeDescription: "", buyerCharge: 200, sellerCharge: 300);

                Reports.TestStep = "Navigate to File Summary | Loan /Disbursement Tab.";
                FastDriver.FileSummary.Open();
                FastDriver.FileSummary.LoanDisbursement.FAClick();
                FastDriver.FileSummary.WaitForLoanDisScreenToLoad();

                Reports.TestStep = " Validate The Net Total Disbursements, Outside Escrow Company Amounts";
                if (AutoConfig.FormType == "HUD")
                {
                    Support.AreEqual("5,600.00", FastDriver.FileSummary.NetTotalDisbursements.FAGetText().ToString().Trim(), true);
                    Support.AreEqual("$ 5,300.00", FastDriver.FileSummary.SellerNetCheck.FAGetText().ToString().Trim(), true);
                    Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 3, TableAction.GetText).Message.ToString().Trim(), true);
                    Support.AreEqual("$4,800.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString().Trim(), true);
                }
                else
                {
                    Support.AreEqual("5,300.00", FastDriver.FileSummary.NetTotalDisbursements.FAGetText().ToString().Trim(), true);
                    Support.AreEqual("$ 5,000.00", FastDriver.FileSummary.SellerNetCheck.FAGetText().ToString().Trim(), true);
                    Support.AreEqual("$5,000.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 3, TableAction.GetText).Message.ToString().Trim(), true);
                    Support.AreEqual("$4,500.00", FastDriver.FileSummary.NewLoanRecapTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString().Trim(), true);
                }
                Support.AreEqual("700.00", FastDriver.FileSummary.NetTotalDeposits.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 300.00", FastDriver.FileSummary.BuyerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 200.00", FastDriver.FileSummary.BuyerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.BuyerNetCheck.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsHeld.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$ 0.00", FastDriver.FileSummary.SellerFundsDue.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$0.00", FastDriver.FileSummary.PayOffLoanPrincipalBalance.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$0.00", FastDriver.FileSummary.PayOffLoanTotalCharges.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$-200.00", FastDriver.FileSummary.PayOffLoanPayoffAmount.FAGetText().ToString().Trim(), true);
                Support.AreEqual("$-200.00", FastDriver.FileSummary.PayOffLoanCheckAmount.FAGetText().ToString().Trim(), true);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion REG

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}