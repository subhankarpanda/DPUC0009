﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0079 : MasterTestClass
    {
        public FMUC0079()
        {

        }

        #region BAT
        [TestMethod]
        public void FMUC0079_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_0001: Create a new file.";

                #region DataSetup
                BuyerParameters Buyers = new BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    Husband1FirstName = "Buyer2Firstname",
                    Husband2LastName = "Buyer2Lastname",
                    HusbandSpouseFirstName = "Buyer2SpouseName",
                    HusbandSpouseLastName = "Buyer2Lastname"
                };

                BuyerParameters Sellers = new BuyerParameters()
                {
                    First = "Seller1FirstName",
                    Middle = "",
                    Last = "Seller1Lastname",
                    SSN = "987-65-4321",
                    Husband1FirstName = "Seller2Firstname",
                    Husband2LastName = "Seller2Lastname",
                    HusbandSpouseFirstName = "Seller2SpouseName",
                    HusbandSpouseLastName = "Seller2Lastname"
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Move to the Buyers link and verify the buyer details are same as added in QFE.
                Reports.TestStep = "Navigate to the Buyers link to get the buyer summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Select the buyer type individual from the buyer summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();

                Reports.TestStep = "Validate the details entered in the QFE in buyer detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ViewEdit();
                Support.AreEqual("Individual", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(Buyers.First, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue());
                Support.AreEqual(Buyers.Last, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());
                Support.AreEqual(Buyers.SSN, FastDriver.BuyerSellerSetup.txtSSN.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the buyer type Husband/Wife from the buyer summary table.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Husband/Wife", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();

                Reports.TestStep = "Validate the details entered in the QFE in buyer detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("Husband/Wife", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(Buyers.Husband1FirstName, FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.Husband1MiddleName.FAGetValue());
                Support.AreEqual(Buyers.Husband2LastName, FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.HusbandSpous1SSN.FAGetValue());

                Support.AreEqual(Buyers.HusbandSpouseFirstName, FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FAGetValue());
                Support.AreEqual(Buyers.HusbandSpouseLastName, FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Sellers link and verify the seller details are same as added in QFE.
                Reports.TestStep = "Navigate to the Buyers link to get the buyer summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Select the buyer type individual from the buyer summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();

                Reports.TestStep = "Validate the details entered in the QFE in buyer detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ViewEdit();
                Support.AreEqual("Individual", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(Sellers.First, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue());
                Support.AreEqual(Sellers.Last, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());
                Support.AreEqual(Sellers.SSN, FastDriver.BuyerSellerSetup.txtSSN.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the buyer type Husband/Wife from the buyer summary table.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Husband/Wife", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();

                Reports.TestStep = "Validate the details entered in the QFE in buyer detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("Husband/Wife", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(Sellers.Husband1FirstName, FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.Husband1MiddleName.FAGetValue());
                Support.AreEqual(Sellers.Husband2LastName, FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.HusbandSpous1SSN.FAGetValue());

                Support.AreEqual(Sellers.HusbandSpouseFirstName, FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FAGetValue());
                Support.AreEqual(Sellers.HusbandSpouseLastName, FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue());
                Support.AreEqual("", FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_BAT0001 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0079_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF_0002: Create a Buyer instance of type Individual.";

                #region DataSetup
                BuyerParameters individualBuyer = new BuyerParameters()
                {
                    BuyerType="Individual",
                    First = "IndiBuyerFirstName",
                    Middle = "IndiBuyerMiddleName",
                    Last = "IndiBuyerLastName",
                    Suffix = "Indsf",
                    SSN = "123-45-6789"
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateFileWithBasicDetails();
                #endregion

                #region Move to the Buyers/Seller setup to create buyer of individual type.
                Reports.TestStep = "Navigate to the Buyers link.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Create Buyer of type Individual.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(individualBuyer.BuyerType);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(individualBuyer);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Buyer/seller sumamry page and select the buyer of individual type.
                Reports.TestStep = "Navigate to the Buyers link to get the buyer summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Select the buyer type individual from the buyer summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                #endregion

                #region Validate the values for the individual buyer type entered at the time of creation.
                Reports.TestStep = "Validate the details entered in the QFE in buyer detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ViewEdit();
                Support.AreEqual(individualBuyer.BuyerType, FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(individualBuyer.First, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
                Support.AreEqual(individualBuyer.Middle, FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue());
                Support.AreEqual(individualBuyer.Last, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());
                Support.AreEqual(individualBuyer.SSN, FastDriver.BuyerSellerSetup.txtSSN.FAGetValue());
                Support.AreEqual(individualBuyer.Suffix, FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_BAT0002 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0079_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF1_0001: Create a Buyer instance of type Husband/Wife.";
                #region DataSetup
                BuyerParameters husWifeBuyer = new BuyerParameters()
                {
                    BuyerType="Husband/Wife",
                    Husband1FirstName = "HusbandBFirstName1",
                    Husband1MiddleName="HusbandBMiddleName1",
                    Husband2LastName = "HusbandBLastName",
                    HusbandSuffix = "sfx1",
                    HusbandSpouse1SSN = "123-45-6789",

                    HusbandSpouseFirstName = "HusSpouseBfirstName",
                    HusbandSpouseMiddleName = "HusSpouseBMidleName",
                    HusbandSpouseLastName = "HusbandBLastName",
                    HusbandSpouseSuffix = "sfx2",
                    HusbandSpouse2SSN = "213-21-4321"
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateFileWithBasicDetails();
                #endregion

                #region Move to the Buyers/Seller setup to create buyer of husband/wife type.
                Reports.TestStep = "Navigate to the Buyers link.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Create Buyer of type Husband/Wife.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(husWifeBuyer.BuyerType);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(husWifeBuyer);
                #endregion

                #region Add the Exchnage details for this buyer.
                Reports.TestStep = "Add exchange details for this buyer.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("EXCH01");
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Buyer/seller sumamry page and select the buyer of Husband/Wife type.
                Reports.TestStep = "Navigate to the Buyers link to get the buyer summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Select the buyer type Husband/Wife from the buyer summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, husWifeBuyer.BuyerType, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                #endregion

                #region Validate the values for the Husband/Wife buyer type entered at the time of creation.
                Reports.TestStep = "Validate the details entered in the QFE in buyer detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnHusSpos1SsnVieEdt.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnHusSpos2SsnVieEdt.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(husWifeBuyer.BuyerType, FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(husWifeBuyer.Husband1FirstName, FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue());
                Support.AreEqual(husWifeBuyer.Husband1MiddleName, FastDriver.BuyerSellerSetup.Husband1MiddleName.FAGetValue());
                Support.AreEqual(husWifeBuyer.Husband2LastName, FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue());
                Support.AreEqual(husWifeBuyer.HusbandSpouse1SSN, FastDriver.BuyerSellerSetup.HusbandSpous1SSN.FAGetValue());
                Support.AreEqual(husWifeBuyer.HusbandSuffix, FastDriver.BuyerSellerSetup.Husband1suffix.FAGetValue());

                Support.AreEqual(husWifeBuyer.HusbandSpouseFirstName, FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue());
                Support.AreEqual(husWifeBuyer.HusbandSpouseMiddleName, FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FAGetValue());
                Support.AreEqual(husWifeBuyer.HusbandSpouseLastName, FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue());
                Support.AreEqual(husWifeBuyer.HusbandSpouse2SSN, FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FAGetValue());
                Support.AreEqual(husWifeBuyer.HusbandSpouseSuffix, FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_BAT0003 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0079_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF2_0001: Create a Buyer instance of type Trust/Estate.";

                #region DataSetup
                BuyerParameters trustBuyer = new BuyerParameters()
                {
                    BuyerType="Trust/Estate",
                    TrusteeShortNameTwo="TrustEstateName",
                    TrustDated="01-11-2014",
                    TrustNumber="21314151",
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateFileWithBasicDetails();
                #endregion

                #region Move to the Buyers/Seller setup to create buyer of Trust/Estate type.
                Reports.TestStep = "Navigate to the Buyers link.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Create Buyer of type Trust/Estate.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(trustBuyer.BuyerType);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(trustBuyer);
                #endregion

                #region Add the Exchnage details for this buyer.
                Reports.TestStep = "Add exchange details for this buyer.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("EXCH01");
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Buyer/seller sumamry page and select the buyer of Trust/Estate type.
                Reports.TestStep = "Navigate to the Buyers link to get the buyer summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Select the buyer type Trust/Estate from the buyer summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, trustBuyer.BuyerType, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                #endregion

                #region Validate the values for the Husband/Wife buyer type entered at the time of creation.
                Reports.TestStep = "Validate the details entered in the QFE in buyer detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(trustBuyer.BuyerType, FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(trustBuyer.TrusteeShortNameTwo, FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue());
                Support.AreEqual(trustBuyer.TrustDated, FastDriver.BuyerSellerSetup.TrustDated.FAGetValue());
                Support.AreEqual(trustBuyer.TrustNumber, FastDriver.BuyerSellerSetup.TrustNumber.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_BAT0004 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0079_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF3_0001: Create a Buyer instance of type Business Entity.";
                #region DataSetup
                BuyerParameters businessBuyer = new BuyerParameters()
                {
                    BuyerType="Business Entity",
                    BusinessEntityShortname="BusinessEntityShortName",
                    BusinessEntitySsn="244-56-7842",
                    EntityType="Business Trust",
                    StateofIncorp="California"
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateFileWithBasicDetails();
                #endregion

                #region Move to the Buyers/Seller setup to create buyer of Business Entity type.
                Reports.TestStep = "Navigate to the Buyers link.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Create Buyer of type Business Entity.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(businessBuyer.BuyerType);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(businessBuyer);
                #endregion

                #region Add the Exchnage details for this buyer.
                Reports.TestStep = "Add exchange details for this buyer.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("EXCH01");
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Buyer/seller sumamry page and select the buyer of Business Entity type.
                Reports.TestStep = "Navigate to the Buyers link to get the buyer summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Select the buyer type Business Entity from the buyer summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "BusinessEntity", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                #endregion

                #region Validate the values for the Husband/Wife buyer type entered at the time of creation.
                Reports.TestStep = "Validate the details entered in the QFE in buyer detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BusinessEntityViewEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(businessBuyer.BuyerType, FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(businessBuyer.BusinessEntityShortname, FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAGetValue());
                Support.AreEqual(businessBuyer.BusinessEntityShortname, FastDriver.BuyerSellerSetup.BusinessEntityName.FAGetValue());
                Support.AreEqual(businessBuyer.BusinessEntitySsn, FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue());
                Support.AreEqual(businessBuyer.EntityType, FastDriver.BuyerSellerSetup.EntityType.FAGetSelectedItem());
                Support.AreEqual(businessBuyer.StateofIncorp, FastDriver.BuyerSellerSetup.StateofIncorp.FAGetSelectedItem());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_BAT0005 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0079_BAT0006()
        {
            try
            {
                Reports.TestDescription = "MF_0003: Create a Seller instance of type Individual.";

                #region DataSetup
                BuyerParameters individualSeller = new BuyerParameters()
                {
                    BuyerType = "Individual",
                    First = "IndiSellerFirstName",
                    Middle = "IndiSellerMiddleName",
                    Last = "IndiSellerLastName",
                    Suffix = "Indsf",
                    SSN = "423-45-6789"
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateFileWithBasicDetails();
                #endregion

                #region Move to the Buyers/Seller setup to create seller of individual type.
                Reports.TestStep = "Navigate to the Sellers link.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Create seller of type Individual.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(individualSeller.BuyerType);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(individualSeller);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Buyer/seller sumamry page and select the seller of individual type.
                Reports.TestStep = "Navigate to the Buyers link to get the seller summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Select the buyer type individual from the seller summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, individualSeller.BuyerType, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                #endregion

                #region Validate the values for the individual seller type entered at the time of creation.
                Reports.TestStep = "Validate the details entered in the QFE in seller detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ViewEdit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(individualSeller.BuyerType, FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(individualSeller.First, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
                Support.AreEqual(individualSeller.Middle, FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue());
                Support.AreEqual(individualSeller.Last, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());
                Support.AreEqual(individualSeller.SSN, FastDriver.BuyerSellerSetup.txtSSN.FAGetValue());
                Support.AreEqual(individualSeller.Suffix, FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_BAT0006 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0079_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF1_0002: Create a Seller instance of type Husband/Wife.";
                #region DataSetup
                BuyerParameters husWifeSeller = new BuyerParameters()
                {
                    BuyerType = "Husband/Wife",
                    Husband1FirstName = "HusbandSFirstName1",
                    Husband1MiddleName = "HusbandSMiddleName1",
                    Husband2LastName = "HusbandSLastName",
                    HusbandSuffix = "sfx1",
                    HusbandSpouse1SSN = "123-45-6789",

                    HusbandSpouseFirstName = "HusSpouseSfirstName",
                    HusbandSpouseMiddleName = "HusSpouseSMidleName",
                    HusbandSpouseLastName = "HusbandSLastName",
                    HusbandSpouseSuffix = "sfx2",
                    HusbandSpouse2SSN = "213-21-4321"
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateFileWithBasicDetails();
                #endregion

                #region Move to the Buyers/Seller setup to create Seller of husband/wife type.
                Reports.TestStep = "Navigate to the Sellers link.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Create Seller of type Husband/Wife.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(husWifeSeller.BuyerType);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(husWifeSeller);
                #endregion

                #region Add the Exchnage details for this Seller.
                Reports.TestStep = "Add exchange details for this Seller.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("EXCH01");
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Buyer/seller sumamry page and select the Seller of Husband/Wife type.
                Reports.TestStep = "Navigate to the Sellers link to get the Seller summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Select the buyer type Husband/Wife from the Seller summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, husWifeSeller.BuyerType, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                #endregion

                #region Validate the values for the Husband/Wife Seller type entered at the time of creation.
                Reports.TestStep = "Validate the details entered in the QFE in Seller detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnHusSpos1SsnVieEdt.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnHusSpos2SsnVieEdt.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(husWifeSeller.BuyerType, FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(husWifeSeller.Husband1FirstName, FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue());
                Support.AreEqual(husWifeSeller.Husband1MiddleName, FastDriver.BuyerSellerSetup.Husband1MiddleName.FAGetValue());
                Support.AreEqual(husWifeSeller.Husband2LastName, FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue());
                Support.AreEqual(husWifeSeller.HusbandSpouse1SSN, FastDriver.BuyerSellerSetup.HusbandSpous1SSN.FAGetValue());
                Support.AreEqual(husWifeSeller.HusbandSuffix, FastDriver.BuyerSellerSetup.Husband1suffix.FAGetValue());

                Support.AreEqual(husWifeSeller.HusbandSpouseFirstName, FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue());
                Support.AreEqual(husWifeSeller.HusbandSpouseMiddleName, FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FAGetValue());
                Support.AreEqual(husWifeSeller.HusbandSpouseLastName, FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue());
                Support.AreEqual(husWifeSeller.HusbandSpouse2SSN, FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FAGetValue());
                Support.AreEqual(husWifeSeller.HusbandSpouseSuffix, FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_BAT0007 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0079_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF2_0003: Create a Seller instance of type Trust/Estate.";

                #region DataSetup
                BuyerParameters trustSeller = new BuyerParameters()
                {
                    BuyerType = "Trust/Estate",
                    TrusteeShortNameTwo = "TrustEstateNameSeller",
                    TrustDated = "01-11-2014",
                    TrustNumber = "21314151",
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateFileWithBasicDetails();
                #endregion

                #region Move to the Buyers/Seller setup to create Seller of Trust/Estate type.
                Reports.TestStep = "Navigate to the Sellers link.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Create Seller of type Trust/Estate.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(trustSeller.BuyerType);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(trustSeller);
                #endregion

                #region Add the Exchnage details for this Seller.
                Reports.TestStep = "Add exchange details for this Seller.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("EXCH01");
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Buyer/seller sumamry page and select the Seller of Trust/Estate type.
                Reports.TestStep = "Navigate to the Sellers link to get the Seller summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Select the Seller type Trust/Estate from the Seller summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, trustSeller.BuyerType, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                #endregion

                #region Validate the values for the Husband/Wife Seller type entered at the time of creation.
                Reports.TestStep = "Validate the details entered in the QFE in Seller detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(trustSeller.BuyerType, FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(trustSeller.TrusteeShortNameTwo, FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue());
                Support.AreEqual(trustSeller.TrusteeShortNameTwo, FastDriver.BuyerSellerSetup.TrusteeName.FAGetValue());
                Support.AreEqual(trustSeller.TrustDated, FastDriver.BuyerSellerSetup.TrustDated.FAGetValue());
                Support.AreEqual(trustSeller.TrustNumber, FastDriver.BuyerSellerSetup.TrustNumber.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_BAT0008 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0079_BAT0009()
        {
            try
            {
                #region DataSetup
                Reports.TestDescription = "AF3_0004: Create a Seller instance of type Business Entity.";
                BuyerParameters businessSeller = new BuyerParameters()
                {
                    BuyerType = "Business Entity",
                    BusinessEntityShortname = "BusinessEntitySShortName",
                    BusinessTin=false,
                    BusinessEntitySsn = "244-56-7842",
                    EntityType = "Business Trust",
                    StateofIncorp = "California"
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateFileWithBasicDetails();
                #endregion

                #region Move to the Buyers/Seller setup to create Seller of Business Entity type.
                Reports.TestStep = "Navigate to the Sellers link.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Create Seller of type Business Entity.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(businessSeller.BuyerType);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(businessSeller);
                #endregion

                #region Add the Exchnage details for this Seller.
                Reports.TestStep = "Add exchange details for this Seller.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("EXCH01");
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Buyer/seller sumamry page and select the Seller of Business Entity type.
                Reports.TestStep = "Navigate to the Sellers link to get the Seller summary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Select the Seller type Business Entity from the Seller summary table.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "BusinessEntity", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                #endregion

                #region Validate the values for the Husband/Wife Seller type entered at the time of creation.
                Reports.TestStep = "Validate the details entered in the QFE in Seller detail screen.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BusinessEntityViewEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(businessSeller.BuyerType, FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(businessSeller.BusinessEntityShortname, FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAGetValue());
                Support.AreEqual(businessSeller.BusinessEntityShortname, FastDriver.BuyerSellerSetup.BusinessEntityName.FAGetValue());
                Support.AreEqual(businessSeller.BusinessEntitySsn, FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue());
                Support.AreEqual(businessSeller.EntityType, FastDriver.BuyerSellerSetup.EntityType.FAGetSelectedItem());
                Support.AreEqual(businessSeller.StateofIncorp, FastDriver.BuyerSellerSetup.StateofIncorp.FAGetSelectedItem());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_BAT0009 failed because: " + ex.Message);
            }
        }

        #endregion

        #region REG
        [TestMethod]
        public void FMUC0079_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM3009: Transfer Info to Buyer/Seller.";
                Reports.StatusUpdate("This BR is already covered in the BAT001 script.",true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0079_REG0001 failed because: " + ex.Message);
            }
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// This method logins to File side.
        /// </summary>
        /// <param name="UserName"> username string for login</param>
        /// <param name="Password">password for the corresponding username for login.</param>
        private void IISLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Login into the IIS Side.";
            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        /// <summary>
        /// This method creates a basic file with all details filled in QFE.
        /// </summary>
        private void CreateBasicFile()
        {
            Reports.TestStep = "Create a new file.";
            CreateFileRequest fileRequest = new CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            fileRequest.File.TransactionTypeObjectCD = "SALE";
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
            Support.AreEqual("true", FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.ChangeOO, continueOnFailure: true).ToString(), true);
        }

        /// <summary>
        /// This webservice method creats the file with the basic details only i.e BUID, transaction type,business segment and state.
        /// </summary>
        /// <returns></returns>
        private CreateFileRequest GetDefaultFileCreated()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None
                            }
                        } 
                    },
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    } 
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                } 
                            } 
                        } 
                    },
                }
            };
            #endregion
        }

        /// <summary>
        /// This method creates a basic file with all the mandetory details filled in QFE.
        /// </summary>
        private void CreateFileWithBasicDetails()
        {
            Reports.TestStep = "Create a new file.";
            CreateFileRequest fileRequest = new CreateFileRequest();
            fileRequest = this.GetDefaultFileCreated();
            fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            fileRequest.File.TransactionTypeObjectCD = "SALE";
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
            Support.AreEqual("true", FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.ChangeOO, continueOnFailure: true).ToString(), true);
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}