﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.Common;
using System.Linq;
using FASTWCFHelpers.FastFileService;
using System.Diagnostics;
using Microsoft.Win32;
using System.Threading;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0003_Start_File_from_another_File : MasterTestClass
    {
        #region BAT

        [TestMethod]
        public void FMUC0003_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_FM6859 : Copy information from Starter/Base file to an open file,Group Miscellaneous Disbursements Information";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                var FileNum1 = File.FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDATASTL1");
                FastDriver.MiscDisbursementDetail.Description.FASetText(@"Disbursemen2" + FAKeys.Tab);

                //Payment details
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                if (!AutoConfig.UseCDFormType)
                    this.FillPaymentDetailsDialog(BuyerCharge: 50.00, BuyerPaidByOtherMethod: "POC", SellerCharge: 50.00, handleMessage: true, isCD: false);
                else
                    this.FillPaymentDetailsDialog(BuyerCharge: 50.00, BuyerPaidByOther: 50.00, BuyerPaidByOtherMethod: "POC", SellerCharge: 50.00, PaidbySellerAtClosing: 50.00, handleMessage: true);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Support.AreEqual(@"Check Amount: $ 50.00", FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual(@"Disbursemen2", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Check Amount: $ 50.00", FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "FM6864_Enter charges to Payoff loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"247", WaitForGabCodeLabel: false);
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"200" + FAKeys.Tab);
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.LoanChargesTable, "Principal Balance", buyerCharge: 100.00, sellerCharge: 100.00);

                //Payoff Loan charges section
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", editDescription: @"Payoff Loan Charges Description", buyerCharge: 50.00, buyerCredit: 50.00, sellerCharge: 50.00, sellerCredit: 50.00);

                //Payoff Loan Parties tab
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickPartiesTab().WaitForScreeToLoan();
                FastDriver.PayoffLoanParites.TrustorMortgagor.FASetText(@"Seller1Firstname Seller1Lastname and Seller2Firstname Seller2Lastname and Seller2Spouse Seller2Lastname" + FAKeys.Tab);
                FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FASetText(@"Lenders Advantage, A Division Of First American Title Ins." + FAKeys.Tab);
                FastDriver.PayoffLoanParites.FindGABCode(@"223", WaitForGabCodeLabel: false);

                //Recording tab
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickRecordingTab().WaitForScreeToLoan();
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FASetText(DateTime.Today.AddDays(2).ToDateString());
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FASetText(DateTime.Today.AddDays(2).ToDateString());
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FASetText("24" + FAKeys.Tab);
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FASetText("Book1" + FAKeys.Tab);
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FASetText("Page1" + FAKeys.Tab);

                Reports.TestStep = "Validate charges entered";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                Support.AreEqual(@"200.00", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().Clean());
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().Clean());

                //create a FAST Order
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify fields in Filehomepage for Basic File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1 + FAKeys.Tab);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "FM6859_Validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual(@"Disbursemen2", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Check Amount: $ 50.00", FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "Validate Payoffloan screen is loaded";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_FM6859_FM6864 : Search for the Starter File";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                var FileNum1 = File.FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDATASTL1");
                FastDriver.MiscDisbursementDetail.Description.FASetText(@"Disbursemen2" + FAKeys.Tab);
                //Payment details
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                if (!AutoConfig.UseCDFormType)
                    this.FillPaymentDetailsDialog(BuyerCharge: 50.00, BuyerPaidByOtherMethod: "POC", SellerCharge: 50.00, handleMessage: true, isCD: false);
                else
                    this.FillPaymentDetailsDialog(BuyerCharge: 50.00, BuyerPaidByOther: 50.00, BuyerPaidByOtherMethod: "POC", SellerCharge: 50.00, PaidbySellerAtClosing: 50.00, handleMessage: true);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"247", WaitForGabCodeLabel: false);
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"200" + FAKeys.Tab);
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.LoanChargesTable, "Principal Balance", buyerCharge: 100.00, sellerCharge: 100.00);
                //Payoff Loan charges section
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", editDescription: @"Payoff Loan Charges Description", buyerCharge: 50.00, buyerCredit: 50.00, sellerCharge: 50.00, sellerCredit: 50.00);
                //Payoff Loan Parties tab
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickPartiesTab().WaitForScreeToLoan();
                FastDriver.PayoffLoanParites.TrustorMortgagor.FASetText(@"Seller1Firstname Seller1Lastname and Seller2Firstname Seller2Lastname and Seller2Spouse Seller2Lastname" + FAKeys.Tab);
                FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FASetText(@"Lenders Advantage, A Division Of First American Title Ins." + FAKeys.Tab);
                FastDriver.PayoffLoanParites.FindGABCode(@"223", WaitForGabCodeLabel: false);
                //Recording tab
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickRecordingTab().WaitForScreeToLoan();
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FASetText(DateTime.Today.AddDays(2).ToDateString());
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FASetText(DateTime.Today.AddDays(2).ToDateString());
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FASetText("24" + FAKeys.Tab);
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FASetText("Book1" + FAKeys.Tab);
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FASetText("Page1" + FAKeys.Tab);
                //create a FAST Order
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1 + FAKeys.Tab);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                //Create Order
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Verify File
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());

                Reports.TestStep = "Navigate to starter ref screen and click on file search.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.FileSearch.FAClick();

                Reports.TestStep = "Enter file number.";
                FastDriver.FileSearch.WaitForWindowToLoad(FastDriver.FileSearch.Numbers, 60);
                FastDriver.FileSearch.Numbers.FASetText(FileNum1 + FAKeys.Tab);

                Reports.TestStep = "Click on Find button after enter file number.";
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify for file no entered in file search screen and select all items radio button.";
                FastDriver.StarterReference.WaitForScreenToLoad(FastDriver.StarterReference.StarterFileNumber);
                Support.AreEqual(FileNum1, FastDriver.StarterReference.StarterFileNumber.FAGetValue().Clean());
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.IsVisible().ToString(), "ChangeOO button exist.");
                value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Clean());
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean());
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Clean());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Seller1FirstName", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Clean());

                Reports.TestStep = "FM6859_Validates a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual(@"HUDATASTL1", FastDriver.MiscDisbursementDetail.IDCode.FAGetText().Clean());
                Support.AreEqual(@"Attorney As Title 1 for HUD Test Name 1", FastDriver.MiscDisbursementDetail.Name1.FAGetText().Clean());
                Support.AreEqual(@"(505)419-4851", FastDriver.MiscDisbursementDetail.BusinessPhone.FAGetValue().Clean());
                Support.AreEqual(@"912", FastDriver.MiscDisbursementDetail.BusinessPhoneExtension.FAGetValue().Clean());
                Support.AreEqual(@"(810)741-0884", FastDriver.MiscDisbursementDetail.BusinessFax.FAGetValue().Clean());
                Support.AreEqual(@"(936)581-1810", FastDriver.MiscDisbursementDetail.CellPhone.FAGetValue().Clean());
                if(FastDriver.MiscDisbursementDetail.EmailAddress.FAGetValue().Clean().Contains("ugnuxssp"))
                {
                    Support.AreEqual(@"ugnuxssp@Title.1", FastDriver.MiscDisbursementDetail.EmailAddress.FAGetValue().Clean());//Original email: vnhdsvpb
                }

                //Charges
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());

                Reports.TestStep = "FM6864_Validates Payoff";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                Support.AreEqual(@"247", FastDriver.PayoffLoanDetails.GABcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().Clean());
                Support.AreEqual(@"Institutional", FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem());
                Support.AreEqual(@"(616)451-2290", FastDriver.PayoffLoanDetails.LenderBusPhone.FAGetValue());
                Support.AreEqual(@"(616)451-2290", FastDriver.PayoffLoanDetails.LenderBusFax.FAGetValue());
                Support.AreEqual(@"(616)451-2290", FastDriver.PayoffLoanDetails.LenderCellPhone.FAGetValue());
                Support.AreEqual(@"(616)451-2290", FastDriver.PayoffLoanDetails.LenderPager.FAGetValue());
                if (FastDriver.PayoffLoanDetails.LenderEmailAddress.FAGetValue().Clean().Contains("test"))
                {
                    Support.AreEqual(@"test@test.com", FastDriver.PayoffLoanDetails.LenderEmailAddress.FAGetValue());
                }

                //Charges tab
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().Clean());

                //Payoff Loan charges section
                Support.AreEqual(@"Payoff Loan Charges Description", FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit.FAGetValue().Clean());

                //Payoff Loan Parties tab
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickPartiesTab().WaitForScreeToLoan();
                Support.AreEqual(@"Seller1Firstname Seller1Lastname and Seller2Firstname Seller2Lastname and Seller2Spouse Seller2Lastname",
                    FastDriver.PayoffLoanParites.TrustorMortgagor.FAGetValue().Clean());
                Support.AreEqual(@"Lenders Advantage, A Division Of First American Title Ins.",
                    FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FAGetValue().Clean());

                //GAB
                Support.AreEqual(@"223", FastDriver.PayoffLoanParites.TrusteeGABcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"Associated Great Northern Mortgage Co.", FastDriver.PayoffLoanParites.TrusteeNameLabel.FAGetText().Clean());
                Support.AreEqual(@"430 Touhy Avenue", FastDriver.PayoffLoanParites.TrusteeAddressLabel.FAGetText().Clean());
                Support.AreEqual(@"(847)290-1100", FastDriver.PayoffLoanParites.TrusteeBusPhone.FAGetValue().Clean());
                if (FastDriver.PayoffLoanParites.TrusteeEmailAddress.FAGetValue().Clean().Contains("emwqr"))
                {
                    Support.AreEqual(@"emwqr@aol.com", FastDriver.PayoffLoanParites.TrusteeEmailAddress.FAGetValue().Clean());//Original email: amzuv
                }

                //Recording tab
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickRecordingTab().WaitForScreeToLoan();
                Support.AreEqual(DateTime.Today.AddDays(2).ToDateString(), FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FAGetValue().Clean());
                Support.AreEqual(DateTime.Today.AddDays(2).ToDateString(), FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FAGetValue().Clean());
                Support.AreEqual(@"24", FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FAGetValue().Clean());
                Support.AreEqual(@"Book1", FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FAGetValue().Clean());
                Support.AreEqual(@"Page1", FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FAGetValue().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF2_EWC5: Replace data in target file with copied information, Verifies search Starter file with wildcard string";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                var FileNum1 = File.FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDATASTL1");
                FastDriver.MiscDisbursementDetail.Description.FASetText(@"Disbursemen2" + FAKeys.Tab);
                //Payment details
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                if (!AutoConfig.UseCDFormType)
                    this.FillPaymentDetailsDialog(BuyerCharge: 50.00, BuyerPaidByOtherMethod: "CHK", SellerCharge: 50.00, handleMessage: true, isCD: false);
                else
                    this.FillPaymentDetailsDialog(BuyerCharge: 50.00, BuyerPaidAtClosing: 50.00, SellerCharge: 50.00, PaidbySellerAtClosing: 50.00, handleMessage: true);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"247", WaitForGabCodeLabel: false);
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"200" + FAKeys.Tab);
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.LoanChargesTable, "Principal Balance", buyerCharge: 100.00, sellerCharge: 100.00);
                //Payoff Loan charges section
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", editDescription: @"Payoff Loan Charges Description", buyerCharge: 50.00, buyerCredit: 50.00, sellerCharge: 50.00, sellerCredit: 50.00);
                //Payoff Loan Parties tab
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickPartiesTab().WaitForScreeToLoan();
                FastDriver.PayoffLoanParites.TrustorMortgagor.FASetText(@"Seller1Firstname Seller1Lastname and Seller2Firstname Seller2Lastname and Seller2Spouse Seller2Lastname" + FAKeys.Tab);
                FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FASetText(@"Lenders Advantage, A Division Of First American Title Ins." + FAKeys.Tab);
                FastDriver.PayoffLoanParites.FindGABCode(@"223", WaitForGabCodeLabel: false);
                //Recording tab
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickRecordingTab().WaitForScreeToLoan();
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FASetText(DateTime.Today.AddDays(2).ToDateString());
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FASetText(DateTime.Today.AddDays(2).ToDateString());
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FASetText("24" + FAKeys.Tab);
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FASetText("Book1" + FAKeys.Tab);
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FASetText("Page1" + FAKeys.Tab);
                //create a FAST Order
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1 + FAKeys.Tab);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                //Create Order
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.FileSearch.FAClick();
                FastDriver.FileSearch.WaitForWindowToLoad(FastDriver.FileSearch.Numbers, 60);
                FastDriver.FileSearch.Numbers.FASetText(FileNum1 + FAKeys.Tab);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad(FastDriver.StarterReference.StarterFileNumber);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Create Order";
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                var FileNum2 = File.FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Disbursemen2", buyerCharge: 50.00, sellerCharge: 50.00);
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "Edit the Instance.";
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Disbursemen2", buyerCharge: 100.00, sellerCharge: 100.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Edited the Instance.";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "User enters a wildcard string for the file number, clicks Copy Now button, and the system returns a search result of multiple matching file numbers.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("32*" + FAKeys.Tab);
                FastDriver.StarterReference.FindNow.FAClick();

                Reports.TestStep = "verify for file search dialog.";
                FastDriver.WebDriver.HandleDialogMessage(false, true, timeout: 200);
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", true, 150);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.WebDriver.HandleDialogMessage(false, true, timeout: 60);
                FastDriver.FileNumberSearchSelectionDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^Q");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 5);

                Reports.TestStep = "Select the Buyer items for copy.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1 + FAKeys.Tab);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Copy same data from starter ref file.";
                Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage(true, false, 20).Clean());

                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual(@"Disbursemen2", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Check Amount: $ 200.00", FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1 + FAKeys.Tab);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual(@"Disbursemen2", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText().Clean());

                #endregion

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF3_AF5: Copy Documents, Copy Selected Data Group(s)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                var FileNum1 = File.FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add the Accomm Sign-Customer Buyer Escrow Instruction Document to Document Repository screen.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys(@"Escrow Instruction");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"Accomm Signing-Customer Buyer");

                Reports.TestStep = "validate the data entered in Adhoc Documents.";
                Support.AreEqual(@"Both", FastDriver.AdHocDocuments.Source.FAGetSelectedItem());
                Support.AreEqual(@"Escrow Instruction", FastDriver.AdHocDocuments.TemplateType.FAGetSelectedItem());
                Support.AreEqual(@"Accomm Signing-Customer Buyer", FastDriver.AdHocDocuments.TemplateDescription.FAGetValue());
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "Accomm Signing-Customer Buyer", "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(5000);

                Reports.TestStep = "Select the Accomm Sign-Customer Buyer document for Delivery.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "Accomm Signing-Customer Buyer", "Name", TableAction.Click);

                Reports.TestStep = "Create Basic Order";
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify fields in Filehomepage for Basic File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());

                Reports.TestStep = "select the list of items to copy including Documents.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1 + FAKeys.Tab);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                FastDriver.StarterReference.Products.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.Notes.FASetCheckbox(true);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

                Reports.TestStep = "Copy documents.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                Support.AreEqual(FileNum1, FastDriver.CopyDocuments.FromFileNumber.FAGetValue().Clean());
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Copy same data from starter ref file.";
                Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());

                value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Clean());
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean());
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Clean());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Seller1FirstName", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Clean());

                Reports.TestStep = "Select the Accomm Sign-Customer Buyer document for Delivery.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "Accomm Signing-Customer Buyer", "Name", TableAction.Click);

                #endregion

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF4: Wildcard Starter File Search";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Save File Number";
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "Create Basic Order";
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen and search for a master file with Wild Card.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1.Substring(0, 4) + "*" + FAKeys.Tab);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                FastDriver.StarterReference.Products.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.Notes.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Select the File Number to use from the results list.";
                Support.AreEqual(@"Select the File Number to use from the results list.", FastDriver.WebDriver.HandleDialogMessage(true, true, 60).Clean());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Select the File no from the search results.";
                while (true)
                {
                    FastDriver.StarterReference.WaitForScreenToLoad();
                    if (!FastDriver.StarterReference.SearchResultsTable.FAGetText().Clean().Contains(FileNum1))
                    {
                        FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                        FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1.Substring(0, 4) + "*" + FAKeys.Tab);
                        FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                        FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                        FastDriver.StarterReference.Products.FASetCheckbox(true);
                        FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
                        FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                        FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                        FastDriver.StarterReference.Notes.FASetCheckbox(true);
                        FastDriver.StarterReference.CopyNow.FAClick();
                        Support.AreEqual(@"Select the File Number to use from the results list.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean());
                        FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                    }
                    else
                    {
                        FastDriver.StarterReference.SearchResultsTable.PerformTableAction("File No.", FileNum1, "File No.", TableAction.Click);
                        break;

                    }
                }

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Copy same data from starter ref file.";
                Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify File properties in File Homepage";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());

                value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Clean());
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean());
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Clean());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Seller1FirstName", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Clean());

                #endregion

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion

        #region REG

        [TestMethod]
        public void FMUC0003_REG0001_02_03()
        {
            try
            {
                Reports.TestDescription = "BR_FM1903_MasterFileCreation:";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                CreateMasterFileREG0001(VerifyFileExistence("REG01-F1"));

                #endregion

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0002()
        {
            Reports.TestDescription = "MasterFileCreation_TDS_PTI: MasterFileCreation";

            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            #endregion

            #region GUI Interaction
            try
            {
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0001.", true);

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }

            #endregion

        }

        [TestMethod]
        public void FMUC0003_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM6863_MasterFileDetails_NL: MasterFileCreation";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region GUI Interaction
                try
                {
                    Reports.TestStep = "Log into FAST application.";
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                    Reports.StatusUpdate("This TC was merged with FMUC0003_REG0001.", true);

                }
                catch (Exception e)
                {
                    FailTest(e.Message);
                }

                #endregion

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0004_05()
        {
            try
            {
                Reports.TestDescription = "BR_FM6830_FM6865_MasterFileDetails_AL_REB_OEC_AttB_AttS: MasterFileCreation";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                CreateMasterFileREG0004(VerifyFileExistence("REG04-F1"));

                #endregion

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0005()
        {
            try
            {
                Reports.TestDescription = "MasterFileDetails_OTC_SV_FF: MasterFileCreation";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0004.", true);

                #endregion

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\ImageHaving12Pages.tif")]
        public void FMUC0003_REG0006_07_08_09_10_11()
        {
            try
            {
                Reports.TestDescription = "BR - FM6846_FM6831_FM6855_MasterFileDetails_AdjOff_AdjMisc_HOA_HW: MasterFileCreation";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                CreateMasterFileREG0006(VerifyFileExistence("REG06-F1"));

                #endregion

            }
            catch (Exception ex)
            {
                SetDisplayPDFinBrowser_OFF();
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0007()
        {
            try
            {
                Reports.TestDescription = "MasterFileDetails_InsRep: MasterFileCreation";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0006.", true); ;

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0008()
        {
            try
            {
                Reports.TestDescription = "MasterFileDetails_Insurance_LD_MD_Uti_DIE: MasterFileCreation";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0006.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0009()
        {
            try
            {
                Reports.TestDescription = "MasterFileDetails_HF: MasterFileCreation";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0006.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0010()
        {
            try
            {
                Reports.TestDescription = "MasterFileDetails_DocRep: MasterFileCreation";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0006.", true);

                #endregion

            }
            catch (Exception ex)
            {
                SetDisplayPDFinBrowser_OFF();
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0011()
        {
            try
            {
                Reports.TestDescription = "MasterFileDetails_DocRep_1: MasterFileCreation";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0006.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0012()
        {
            try
            {
                Reports.TestDescription = "BR_728_729_730_745_731_734_6824_742_743_6831_1903_735_737_738_1912_6832_6852: 1:Starter/Reference 2:Warn Overwrite Existing Data 3:Use Starter File Globally 4:Use One Starter File at a Time 5:Multiple Starter Reference C";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                CreateMasterFilesREG0012(VerifyFileExistence("REG12-F1"));

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0013()
        {
            try
            {
                Reports.TestDescription = "10093_10529_10530_739_4787_733_1908_6838_6837_6917_6973_EWCBO_2: 1:Prevent Copying from a Pending File, 2:Prevent Starter/Ref Copy When Target File has Calculated Fees, 3:Allow Starter/Ref Copy When Target File has Calcu";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                if (!VerifyFileExistence("REG12-F1"))
                    CreateMasterFilesREG0012(false);

                CreateMasterFilesREG0013(VerifyFileExistence("REG13-F1", FileStatus.Pending));

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0014()
        {
            try
            {
                Reports.TestDescription = "6825_6826_6827_FM6828_6829_6917_EWC_8_9_10_11_12: 1:Target File Restriction, 2:Target File Disbursements, 3:Target File Invoices - Copy All Option, 4:Target File Invoices-Business Source, 5:Buyer/Seller, 6:Sett., Group,";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                if (!VerifyFileExistence("REG12-F1"))
                    CreateMasterFilesREG0012(false);

                if (!VerifyFileExistence("REG13-F1", FileStatus.Pending))
                    CreateMasterFilesREG0013(false);

                CreateMasterFilesREG0014(VerifyFileExistence("REG14-F1"));

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0015()
        {
            try
            {
                Reports.TestDescription = "6854_6855_6858_6860_6861_6868_6835: 1:Home Owners Association, 2:Home Warranty Information, 3:Group Lease Information, 4:Survey Information, 5:Utility Information, 6:Outside Escrow Company Information, 7:Copying Charges.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                Reports.TestStep = "Create a file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select all file items and documents From REG0006_FileNum1.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

                Reports.TestStep = "Copy documents.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Validate a newly added homeowner association instance directly.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                Support.AreEqual(@"10.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue().Clean());
                value = FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"MONTH", value);
                Support.AreEqual(@"4.00", FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"2.00", FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"4.50", FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"2.50", FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.FAGetValue().Clean());

                Reports.TestStep = "verify Create an Lease Instance.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                value = FastDriver.LeaseDetail.ChargeDescription.FAGetValue().Clean();
                if (value.Contains("Rent"))
                {
                    Support.AreEqual(@"Rent/Lease Payment Due", value);
                }
                else
                {
                    Support.AreEqual(@"Charge Description", value);
                }

                Support.AreEqual(@"11.00", FastDriver.LeaseDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.LeaseDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "verify an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                Support.AreEqual(@"200.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());

                Reports.TestStep = "Navigate to Utility Screen.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();

                Reports.TestStep = "Validate Data for a new Instance.";
                Support.AreEqual(@"Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().Clean());//Original expected value: Utility Charge. It's being set as Utilities in EVAL04
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to OEC screen";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();

                Reports.TestStep = "validate a OEC Instance.";
                Support.AreEqual(@"OECChargeDescription1", FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0016()
        {
            try
            {
                Reports.TestDescription = "13578: 1:Prevent copy to Target File with Transmitted Service Fees";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                if (!VerifyFileExistence("REG12-F1"))
                    CreateMasterFilesREG0012(false);

                if (!VerifyFileExistence("REG13-F1", status: FileStatus.Pending))
                    CreateMasterFilesREG0013(false);

                Reports.TestStep = "Create a File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Select a payee from payee search";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad(FastDriver.ServiceFee.ServiceFeeAmount);
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText(@"999.00");

                Reports.TestStep = "Click on Transfer button";
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Select all file items From master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "verify for TARGET FILE has VALID DISBURSEMENTS - Process Aborted.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.StarterReference.ErrMessage.FAGetText().Clean().Contains("Error: TARGET FILE has VALID DISBURSEMENTS").ToString(), "Verify whether text \"Error: TARGET FILE has VALID DISBURSEMENTS\" is present.");

                Reports.TestStep = "Click Ok button";
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0017()
        {
            try
            {
                Reports.TestDescription = "10546_10547_10547_10548_1661_EWCBO_3_4: 1:Prevent copying from HUD file to Legacy file, 2:Prevent copying from Legacy file to HUD file, 3:Allow copy if HUD Type is same, 4:Maintain Data Integrity when Copying Data Group,";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                if (!VerifyFileExistence("REG12-F1"))
                    CreateMasterFilesREG0012(false);

                if (!VerifyFileExistence("REG13-F1", status: FileStatus.Pending))
                    CreateMasterFilesREG0013(false);

                Reports.TestStep = "Create a basic file.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a second basic order.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select HUD Type as Legacy on New Loan screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                if (AutoConfig.UseCDFormType)
                    FastDriver.NewLoan.LoanDetailsHUDType_HUD.FASetCheckbox(true);
                else
                    FastDriver.NewLoan.FormType_CD.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(timeout: 20);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Cannot copy from HUD file to Legacy file.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Error: Cannot copy from CD file to HUD file", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.Numbers.FASetText("REG13-F2");

                Reports.TestStep = "Click on Find button after enter file number.";
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Select Legacy file as a master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2" + FAKeys.Tab);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Cannot copy from Legacy file to Hud file.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                Reports.TestStep = "Click on skip button to go to QFE.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select HUD Type as Legacy on New Loan screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsHUDType_HUD.FASetCheckbox(true);

                Reports.TestStep = "Select Legacy file as a master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(timeout: 20);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Create a basic file.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(timeout: 20);

                Reports.TestStep = "Verify Master file check box is unchecked if Master file is copied to target file.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.FileHomepage.UseAsMasterFile.Selected.ToString(), "Verify whether 'UseAsMasterFile' checkbox is checked.");
                FastDriver.BottomFrame.Save();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0018()
        {
            try
            {
                Reports.TestDescription = "870_4288_6916_6921_6919_6922_0_EWC_4_6: 1:Prevent Base File as Target  , 2:Prevent Master File as Target , 3:Prevent Starter/Ref Copy When Target File has 1099-S Records  ,4:Prevent Copy of Same File Number  , 5:Prevent";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                if (!VerifyFileExistence("REG12-F1"))
                    CreateMasterFilesREG0012(false);

                if (!VerifyFileExistence("REG13-F1", status: FileStatus.Pending))
                    CreateMasterFilesREG0013(false);

                Reports.TestStep = "Create a basic file.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0018_FileNum1 = File.FileNumber;

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(REG0018_FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Starter File cannot be the same as Target File.";
                Support.AreEqual(@"Starter File cannot be the same as Target File.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Change File as Master File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.UseAsMasterFile.FASetCheckbox(true);
                Keyboard.SendKeys("^S");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "select the list of items from the Mater file to copy.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                FastDriver.StarterReference.Products.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
                FastDriver.StarterReference.Notes.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Can not copy to a File that has been designated as a Master File.";//add the error message
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Can not copy to a File that has been designated as a Master File.", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                Reports.TestStep = "Create detailed File";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify Master file check box is unchecked if Master file is copied to target file.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.FileHomepage.UseAsMasterFile.Selected.ToString(), "Verify whether the 'UseAsMasterFile' checkbox is unchecked.");
                Keyboard.SendKeys("^S");

                Reports.TestStep = "Navigate to TDS screen and Enter Sales price and TAB.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Clean();
                var cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();
                if (!cDate.Equals(value))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Open", value);
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText(@"45464" + FAKeys.Tab);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true, timeout: 10);

                Reports.TestStep = "Navigate to TDS screen and Enter Settlement Date.";
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Open", value);
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(@"07-12-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to 10099-S screen and Create Ad-Hoc.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.AdHoc.FAClick();
                FastDriver._1099S.GrossProceedDollor.FASetText(@"45,464.00");

                Reports.TestStep = "Create 1099s record.";
                FastDriver._1099S.SSNTIN.FASetText(@"1213456966");
                FastDriver._1099S.ActiveFirstName.FASetText(@"FirstName");
                FastDriver._1099S.ActiveLastName.FASetText(@"LastName");
                FastDriver._1099S.ActiveAddress.FASetText(@"address1");
                FastDriver._1099S.ActiveCity.FASetText(@"Santa ana");
                FastDriver._1099S.ActivecboState.FASelectItem(@"CA");
                FastDriver._1099S.ActiveZip.FASetText(@"92070");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Select all file items From master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "You cannot copy to a Target File that has 1099-S records.";
                Support.AreEqual(@"You cannot copy to a Target File that has 1099-S records.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0019()
        {
            try
            {
                Reports.TestDescription = "10957_10958_10959_1660: 1:Copy Property info through Starter/Ref for Finalized Policies, 2:Property Address/Legal/Tax Information - All File Items,3:Property Address/Legal/Tax Information - Select File Items, 4:Mutually";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                if (!VerifyFileExistence("REG12-F1"))
                    CreateMasterFilesREG0012(false);

                if (!VerifyFileExistence("REG13-F1", status: FileStatus.Pending))
                    CreateMasterFilesREG0013(false);

                Reports.TestStep = "Create a File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                CreateDocument("Title Reports", "Automation Test Title Report", "Automation Test Title Report");

                Reports.TestStep = "Select the Title Report Document and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Title Reports", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Title report.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
                Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.EffectiveDate.FASetText(@"06-20-2012");
                FastDriver.DocumentInfo.Save.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Verify Document Information for Title report.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
                Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
                Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.EffectiveDate.FAGetValue().Clean());

                Reports.TestStep = "Create a second document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                CreateDocument("Owner Policy", "ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", "ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", multipleDocs: true);

                Reports.TestStep = "Select the Owner Policy and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Owner Policy.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
                Support.AreEqual(@"ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(@"06-20-2012");
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Verify Document Information for Owner Policy.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
                Support.AreEqual(@"ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerEffectiveDate);
                Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FAGetValue().Clean());

                Reports.TestStep = "Select the Owner Policy and Click on Edit for finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(2000);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad(FastDriver.DocumentPreparationMenu.Expand1);
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                value = FastDriver.WebDriver.HandleDialogMessage(timeout: 120);
                if (value == "Policy Number/Guarantee Number is required to finalize the document.")
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Info.FAClick();
                    FastDriver.DocumentRepository.WaitForElementToLoad(FastDriver.DocumentRepository.Save);
                    //Fixed Policy number issue : 16 Feb 2015
                    if (FastDriver.DocumentRepository.CheckPolicyNo.Exists())
                    {
                        if (!FastDriver.DocumentRepository.CheckPolicyNo.Selected)
                            FastDriver.DocumentRepository.CheckPolicyNo.FASetCheckbox(true);
                        if (FastDriver.DocumentRepository.AssignNum.Enabled)
                            FastDriver.DocumentRepository.AssignNum.FAClick();
                    }
                    else
                    {
                        FastDriver.DocumentRepository.PolicyNumber.FASetText(@"FILE1235");
                    }
                    FastDriver.DocumentRepository.Save.FAClick();
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Playback.Wait(2000);
                    FastDriver.DocumentPreparationMenu.WaitForScreenToLoad(FastDriver.DocumentPreparationMenu.menuDocument);
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    try
                    {
                        FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                    }
                    catch (Exception)
                    {
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                        FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                        FastDriver.DocumentRepository.Edit.FAClick();
                        Playback.Wait(2000);
                        FastDriver.DocumentPreparationMenu.WaitForScreenToLoad(FastDriver.DocumentPreparationMenu.menuDocument);
                        FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("%o");
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("z");
                        FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                    }
                }
                if (value.Contains("Dialog not present"))
                {
                    FinalizeDocument();
                }

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);

                Reports.TestStep = "Select all file items From master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Target File has finalized policies - Process aborted.";
                Support.AreEqual(@"Target File has finalized policies - Process aborted.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Select Property for copy Items For Starter File.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Finalized Policies are associated with Properties in the target file. Property Address/Legal/Tax Information cannot be copied.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Select Buyer Data along with Make Buyers as sellers.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "You should not make buyer(s) as seller(s) while copy buyer(s) or seller(s).";
                Support.AreEqual(@"You should not make buyer(s) as seller(s) while copying buyer(s) or seller(s).", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Select Seller Data along with Make Buyers as sellers.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "You should not make buyer(s) as seller(s) while copy buyer(s) or seller(s).";
                Support.AreEqual(@"You should not make buyer(s) as seller(s) while copying buyer(s) or seller(s).", FastDriver.WebDriver.HandleDialogMessage().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0020()
        {
            try
            {
                Reports.TestDescription = "6856_6859_6862: 1:Inspection/Repair Information, 2:Group Miscellaneous Disbursements Information, 3:Terms/Dates/status Information";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                if (!VerifyFileExistence("REG12-F1"))
                    CreateMasterFilesREG0012(false);

                if (!VerifyFileExistence("REG13-F1", status: FileStatus.Pending))
                    CreateMasterFilesREG0013(false);

                Reports.TestStep = "Create a basic file.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var TempFile = File.FileNumber;

                Reports.TestStep = "Enter Masterfile";
                FastDriver.TopFrame.SearchFileByFileNumber("REG13-F2");

                Reports.TestStep = "Enter Pest details";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.FindGAB(@"247", WaitForGabCodeLabel: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Reference.FASetText(@"Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText(@"5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText(@"07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText(@"12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText(@"10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText(@"04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText(@"03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText(@"PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText(@"55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText(@"66.66");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creates a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode(@"HUDMISCDB2");
                FastDriver.MiscDisbursementDetail.Description.FASetText(@"Disbursemen2" + FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText(@"50.00");
                FastDriver.MiscDisbursementDetail.SellerCharge.FASetText(@"50.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enters second file number";
                FastDriver.TopFrame.SearchFileByFileNumber(TempFile);

                Reports.TestStep = "Select all file items From master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "verify for copied instance from Starter File.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                Support.AreEqual(@"Reference1", FastDriver.InspectionRepairPest.Reference.FAGetValue().Clean());
                Support.AreEqual(@"5", FastDriver.InspectionRepairPest.WithinDays.FAGetValue().Clean());
                Support.AreEqual(@"07-10-2012", FastDriver.InspectionRepairPest.OrderDate.FAGetValue().Clean());
                Support.AreEqual(@"12-10-2012", FastDriver.InspectionRepairPest.DueDate.FAGetValue().Clean());
                Support.AreEqual(@"10-10-2012", FastDriver.InspectionRepairPest.FollowUpDate.FAGetValue().Clean());
                Support.AreEqual(@"04-10-2013", FastDriver.InspectionRepairPest.CompleteDate.FAGetValue().Clean());
                Support.AreEqual(@"03-10-2013", FastDriver.InspectionRepairPest.ReportDate.FAGetValue().Clean());
                Support.AreEqual(@"PESTDESCRIPTION1", FastDriver.InspectionRepairPest.description.FAGetValue().Clean());
                Support.AreEqual(@"55.55", FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"66.66", FastDriver.InspectionRepairPest.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual(@"Disbursemen2", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify for Estimated day to close in TDS copied from starter file.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                var cDate = string.Empty;
                value = FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Clean();
                //02-17-2015
                cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();
                //02-17-2015
                if (!cDate.Equals(value))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }
                Support.AreEqual(@"", FastDriver.TermsDatesStatus.EstimattedDaysToClose.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0021()
        {
            try
            {
                Reports.TestDescription = "6830: 1:Service Type in Starter and Target Files";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                if (!VerifyFileExistence("REG12-F1"))
                    CreateMasterFilesREG0012(false);

                if (!VerifyFileExistence("REG13-F1", status: FileStatus.Pending))
                    CreateMasterFilesREG0013(false);

                if (!VerifyFileExistence("REG14-F1"))
                    CreateMasterFilesREG0014(false);

                Reports.TestStep = "Create a basic File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create Title Only Order";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile(title: true, escrow: false, subEscrow: false, buyer: false, seller: false);

                Reports.TestStep = "Change the Owning Office";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG14-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify service types selected in file home page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.FileHomepage.Title.Selected.ToString(), "Verify whether the Title checkbox is checked.");
                Support.AreEqual(@"False", FastDriver.FileHomepage.Escrow.Selected.ToString(), "Verify whether the Escrow checkbox is checked.");
                Support.AreEqual(@"False", FastDriver.FileHomepage.SubEscrow.Selected.ToString(), "Verify whether the SubEscrow checkbox is checked.");
                Keyboard.SendKeys("^S");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0022()
        {
            try
            {
                Reports.TestDescription = "10549_9853: 1:Allow copy  2:All source File Images would be available";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                int count = 0;
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                Reports.TestStep = "Create a basic File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0022_FileNum1 = File.FileNumber;

                Reports.TestStep = "Select HUD Type as Legacy on New Loan screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsHUDType_HUD.FASetCheckbox(true);

                Reports.TestStep = "Select Business Source, Products, Property Address/Legal/Tax Information, Buyers Data, Sellers Data, Notes and Documents from starter file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                FastDriver.StarterReference.Products.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.Notes.FASetCheckbox(true);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

                Reports.TestStep = "Copy documents.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Copy same data from starter ref file.";
                Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "verify for all the documents copied to document repository.";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    return FastDriver.DocumentRepository.EstimatedSettlementStatement.Exists() && FastDriver.DocumentRepository.UKENDORTElement.Exists();
                });
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "UK ENDOR T", 4, TableAction.Click);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "INST-Estimated Settlement Statement", 4, TableAction.Click);
                Support.AreEqual(@"False", FastDriver.DocumentRepository.LenderPolicyElement.Exists().ToString(), "Verify whether 'Lender Policy' document doesn't exist.");
                Support.AreEqual(@"False", FastDriver.DocumentRepository.OwnerPolicyElement.Exists().ToString(), "Verify whether 'Owner Policy' document doesn't exists.");
                FastDriver.DocumentRepository.AccommSigning_CustomerBuyer.FAClick();
                FastDriver.DocumentRepository.AccommSigning_CustomerSeller.FAClick();
                FastDriver.DocumentRepository.AutomationTestTitleReport.FAClick();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0023()
        {
            try
            {
                Reports.TestDescription = "736_1909_9846_1_9849_6839_9848_6845_6840_6846_6847_6848_EWCBO_1: 1:Property Tax Legal Group  2:All or Specific Documents, 3:Multiple Reference of Copied Image, 4:Display Image Document as an Icon,5:Document Status in the";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                Reports.TestStep = "Create a basic File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0023_FileNum1 = File.FileNumber;

                Reports.TestStep = "Select Property for copy Items For Starter File.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Copy same data from starter ref file.";
                Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Navigate to property tax info and change a address.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText(@"MIDWAY");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText(@"BELL");
                FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//select[@id='tabPTI_tabGnrl_GEN_ucPhyAddr_cboState']/option[text() = 'TX']").FAClick();
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value != "")
                    Support.AreEqual(@"Changing State will result in the removal or replacements of the ST License ID", value);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText(@"HILL");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "select the copy Document from master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

                Reports.TestStep = "Copy documents.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

                Reports.TestStep = "Done us Shortcut Keys.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "verify for accomm signature buyer and seller doc.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.AccommSigning_CustomerBuyer.FAClick();
                FastDriver.DocumentRepository.AccommSigning_CustomerSeller.FAClick();

                Reports.TestStep = "select the copy Document from master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

                Reports.TestStep = "Copy documents.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Images already exist in target file.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify for starter ref completed event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Starter Ref Copy Documents Completed]", "Event", TableAction.Click);

                Reports.TestStep = "Verify for starter ref completed event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Starter Ref Copy Images Completed]", "Event", TableAction.Click);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0024()
        {
            try
            {
                Reports.TestDescription = "6853_6857_6865_6864: 1:Data copied as part of  Settlement Information Group, 2:Group Insurance Information, 3:Assumption Loan Information , 4:Payoff Loan Information";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                Reports.TestStep = "Create a basic File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0024_FileNum1 = File.FileNumber;

                Reports.TestStep = "Select Settlement item to copy from starter file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "verify data copied from Starter File.";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                Support.AreNotEqual(@"250.00", FastDriver.OutsideTitleCompanyDetail.FundsDepositedEdit.FAGetValue().Clean());
                value = FastDriver.OutsideTitleCompanyDetail.TypeSelect.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Attorney", value);
                Support.AreEqual(@"", FastDriver.OutsideTitleCompanyDetail.TitleServiceBuyerCharge1.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.OutsideTitleCompanyDetail.TitleServiceSellerCharge1.FAGetValue().Clean());

                Reports.TestStep = "Verify that data is not copied from starter file.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                if (AutoConfig.UseCDFormType)
                {
                    Support.AreNotEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                    Support.AreNotEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
                }
                else
                {
                    Support.AreNotEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                    Support.AreNotEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean());
                    Support.AreNotEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean());
                    Support.AreNotEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "validate hold funds copied for starter file.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>("Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                Support.AreNotEqual(@"Reason For First Hold Fund Instance.", FastDriver.HoldFunds.Reason.FAGetValue().Clean());
                Support.AreNotEqual(@"8", FastDriver.HoldFunds.ReleaseinDays.FAGetValue().Clean());
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                Support.AreNotEqual(@"10.00", FastDriver.HoldFunds.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                Reports.TestStep = "verify the values copied from starter file.";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreNotEqual(@"2.49", FastDriver.ProrationDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreNotEqual(@"2.49", FastDriver.ProrationDetail.SellerCredit.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                Reports.TestStep = "Select the already created Fire Insurance from Summary to delete.";
                FastDriver.InsuranceSummary.Fire.FAClick();

                Reports.TestStep = "Click on Edit Insurance Summary.";
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "validate values copied from starter file.";
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.InsuranceFire.FireBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"200.55", FastDriver.InsuranceFire.FireSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.InsuranceFire.FireCreditSeller.Selected.ToString(), "Verify whether the 'Credit Seller' checkbox is checked.");
                Support.AreNotEqual(@"50.00", FastDriver.InsuranceFire.FireAmount.FAGetValue().Clean());
                Support.AreNotEqual(@"10-08-2010", FastDriver.InsuranceFire.FireFromDate.FAGetValue().Clean());
                Support.AreNotEqual(@"10-08-2012", FastDriver.InsuranceFire.FireToDate.FAGetValue().Clean());
                Support.AreNotEqual(@"100.14", FastDriver.InsuranceFire.FireBuyerCharge1.FAGetValue().Clean());
                Support.AreNotEqual(@"100.14", FastDriver.InsuranceFire.FireSellerCredit1.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter an instance for starter file with all details in all Tabs.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                Support.AreEqual(@"300.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Clean());
                Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanDetails.InterestPaidto.FAGetValue().Clean());
                Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanDetails.NextPaymentDue.FAGetValue().Clean());
                Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanDetails.NotedDate.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Clean());
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                if (!FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.IsReadOnly())
                    Support.AreEqual(@"300.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Clean());
                Support.AreNotEqual(@"5.000000", FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FAGetValue().Clean());
                Support.AreNotEqual(@"06-10-2010", FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FAGetValue().Clean());
                value = FastDriver.AssumptionLoanCharges.InterestProrationBasedonDays.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"365", value);
                Support.AreNotEqual(@"07-10-2011", FastDriver.AssumptionLoanCharges.InterestProrationToDate.FAGetValue().Clean());
                Support.AreNotEqual(@"1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FAGetValue().Clean());
                Support.AreNotEqual(@"1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FAGetValue().Clean());
                FastDriver.AssumptionLoanCharges.clickPartiesTab().WaitForScreeToLoan();
                Support.AreEqual(@"Beneficiary Mortgagee One", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue().Clean());
                Support.AreEqual(@"Assignee Mortgagee One", FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FAGetValue().Clean());
                FastDriver.AssumptionLoanParties.clickRecordingTab().WaitForScreeToLoan();
                Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanRecording.TrustDeedDate.FAGetValue().Clean());
                Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanRecording.RecordingDate.FAGetValue().Clean());
                Support.AreEqual(@"Instrument", FastDriver.AssumptionLoanRecording.Instrument.FAGetValue().Clean());
                Support.AreEqual(@"Book", FastDriver.AssumptionLoanRecording.Book.FAGetValue().Clean());
                Support.AreEqual(@"Page", FastDriver.AssumptionLoanRecording.Page.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "verify Payoff loan instance copied from starter file.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                value = FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Institutional", value);
                Support.AreNotEqual(@"200.00", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().Clean());
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().Clean());
                Support.AreNotEqual(@"10.000000", FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FAGetValue().Clean());
                Support.AreNotEqual(@"09-17-2012", FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FAGetValue().Clean());
                Support.AreNotEqual(@"09-21-2012", FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FAGetValue().Clean());
                if (AutoConfig.UseCDFormType)
                    Support.AreNotEqual(@"40.00", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue().Clean());
                else
                    Support.AreNotEqual(@"50.00", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue().Clean());
                FastDriver.PayoffLoanCharges.ClickPartiesTab().WaitForScreeToLoan();
                Support.AreEqual(@"True", FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FAGetText().Clean().Contains("Lenders Advantage, A Division Of First American Title Ins.").ToString(),
                    "Verify whether the Mortgage Beneficiary contains text 'Lenders Advantage, A Division Of First American Title Ins.'.");
                FastDriver.PayoffLoanParites.ClickRecordingTab().WaitForScreeToLoan();
                Support.AreEqual(@"09-13-2012", FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FAGetValue().Clean());
                Support.AreEqual(@"09-13-2012", FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FAGetValue().Clean());
                Support.AreEqual(@"12345", FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FAGetValue().Clean());
                Support.AreEqual(@"3", FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FAGetValue().Clean());
                Support.AreEqual(@"2", FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0025()
        {
            try
            {
                Reports.TestDescription = "6821_6822_778_732_6973: 1:Notification of a Failed Copy Function , 2:Roll back the data in the Target file ,3:Use Starter/Ref on Found File, 4:Starter File Status, 5:Check File Owning Region";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0025_FileNum1 = File.FileNumber;

                Reports.TestStep = "Create a detailed Order";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0025_FileNum2 = File.FileNumber;

                Reports.TestStep = "Selecting Buyer and seller.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(REG0025_FileNum1);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "The source file does not have data for the selected fields.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"The source file does not have Buyer(s) data for the selected field(s).", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                Reports.TestStep = "Verify data copied from master file.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.IsVisible().ToString(), "ChangeOO button exist.");
                value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Clean());
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean());
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Clean());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Seller1FirstName", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Clean());

                Reports.TestStep = "Navigate to Starter ref screen Select Business Source and search for a master file with Wild Card.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                var StarterFileNumber = REG0025_FileNum1.Substring(0, REG0025_FileNum1.Length - 1) + "*";
                FastDriver.StarterReference.StarterFileNumber.FASetText(StarterFileNumber + FAKeys.Tab);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Select the File Number to use from the results list.";
                FastDriver.WebDriver.HandleDialogMessage(true, true, timeout: 60);

                Reports.TestStep = "Select the File no from the search results.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    return FastDriver.StarterReference.SearchResultsTable.IsVisible();
                }, timeout: 60, idleInterval: 10);
                FastDriver.StarterReference.WaitForScreenToLoad(FastDriver.StarterReference.SearchResultsTable);
                try
                {
                    FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(i => i.FAGetText().Clean().Contains(REG0025_FileNum1) && i.Displayed).FAClick();
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Unable to find File Num. Error message: " + e.Message, false);
                }

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Open in error.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Clean();
                var cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();
                if (!cDate.Equals(value))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Open", value);
                FastDriver.TermsDatesStatus.Status.FASelectItem(@"Open In Error");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to TDS screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Clean();
                cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();
                if (!cDate.Equals(value))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }

                Reports.TestStep = "Verify data copied from master file and get the file No.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Clean());
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean());
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Clean());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Seller1FirstName", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Clean());

                Reports.TestStep = "Creating Basic Order - 3rd file";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0025_FileNum3 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(REG0025_FileNum2);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Closed.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Clean();
                cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();
                if (!cDate.Equals(value))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Open", value);
                FastDriver.TermsDatesStatus.Status.FASelectItem(@"Closed");
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(@"08-15-1986");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to TDS screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Clean();
                cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();
                if (!cDate.Equals(value))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }

                Reports.TestStep = "Creating Basic Order - File 4";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0025_FileNum4 = File.FileNumber;

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(REG0025_FileNum2);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify data copied from master file";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\ImageHaving12Pages.tif")]
        public void FMUC0003_REG0026()
        {
            try
            {
                Reports.TestDescription = "6637_6638_9852_13175_6918: 1:Exclude Property Address Link to Seller/Buyer, 2:Break Link from Property Address to Seller/Buyer Addresses, 3:Restrict Copy of Secured Images, 4:Restrict Copy of Removed Documents and Images";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                if (!VerifyFileExistence("REG12-F1"))
                    CreateMasterFilesREG0012(false);

                if (!VerifyFileExistence("REG13-F1", status: FileStatus.Pending))
                    CreateMasterFilesREG0013(false);

                Reports.TestStep = "Click on skip button to go to QFE.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine2 = "";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine3 = "";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0026_FileNum1 = File.FileNumber;

                Reports.TestStep = "Select Buyer Seller from master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify data copied from Starter File.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.CurrentSetToProperty.Selected.ToString(), "Verify whether the 'CurrentSetToProperty' element is unchecked.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.CurrentSetToOther.Selected.ToString(), "Verify whether the 'CurrentSetToOther' element is checked.");
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"USA", value);
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.ForwardngSetToProperty.Selected.ToString(), "Verify whether the 'ForwardngSetToProperty' element is unchecked.");
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.ForwardingSetToCurrent.Selected.ToString(), "Verify whether the 'ForwardingSetToCurrent' element is unchecked.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingSetToOther.Selected.ToString(), "Verify whether the 'ForwardingSetToOther' element is unchecked.");
                Support.AreEqual(@"J305", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue().Clean());

                Reports.TestStep = "Verify data copied from Starter File is editable.";
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet1.Enabled.ToString(), "Verify whether the 'ForwardingStreet1' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet2.Enabled.ToString(), "Verify whether the 'ForwardingStreet2' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet3.Enabled.ToString(), "Verify whether the 'ForwardingStreet3' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet4.Enabled.ToString(), "Verify whether the 'ForwardingStreet4' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingCity.Enabled.ToString(), "Verify whether the 'ForwardingCity' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingState.Enabled.ToString(), "Verify whether the 'ForwardingState' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingCounty.Enabled.ToString(), "Verify whether the 'ForwardingCounty' element is Enabled.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select all file items From master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify data copied from Starter File.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.CurrentSetToProperty.Selected.ToString(), "Verify whether the 'CurrentSetToProperty' element is unchecked.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.CurrentSetToOther.Selected.ToString(), "Verify whether the 'CurrentSetToOther' element is checked.");
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"USA", value);
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.ForwardngSetToProperty.Selected.ToString(), "Verify whether the 'ForwardngSetToProperty' element is unchecked.");
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.ForwardingSetToCurrent.Selected.ToString(), "Verify whether the 'ForwardingSetToCurrent' element is unchecked.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingSetToOther.Selected.ToString(), "Verify whether the 'ForwardingSetToOther' element is unchecked.");
                Support.AreEqual(@"J305", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue().Clean());

                Reports.TestStep = "Verify data copied from Starter File is editable.";
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet1.Enabled.ToString(), "Verify whether the 'ForwardingStreet1' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet2.Enabled.ToString(), "Verify whether the 'ForwardingStreet2' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet3.Enabled.ToString(), "Verify whether the 'ForwardingStreet3' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet4.Enabled.ToString(), "Verify whether the 'ForwardingStreet4' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingCity.Enabled.ToString(), "Verify whether the 'ForwardingCity' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingState.Enabled.ToString(), "Verify whether the 'ForwardingState' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingCounty.Enabled.ToString(), "Verify whether the 'ForwardingCounty' element is Enabled.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Property for copy Items For Starter File.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Copy same data from starter ref file.";
                Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify data copied from Starter File.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.CurrentSetToProperty.Selected.ToString(), "Verify whether the 'CurrentSetToProperty' element is unchecked.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.CurrentSetToOther.Selected.ToString(), "Verify whether the 'CurrentSetToOther' element is checked.");
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"USA", value);
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.ForwardngSetToProperty.Selected.ToString(), "Verify whether the 'ForwardngSetToProperty' element is unchecked.");
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.ForwardingSetToCurrent.Selected.ToString(), "Verify whether the 'ForwardingSetToCurrent' element is unchecked.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingSetToOther.Selected.ToString(), "Verify whether the 'ForwardingSetToOther' element is unchecked.");
                Support.AreEqual(@"J305", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue().Clean());

                Reports.TestStep = "Verify data copied from Starter File is editable.";
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet1.Enabled.ToString(), "Verify whether the 'ForwardingStreet1' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet2.Enabled.ToString(), "Verify whether the 'ForwardingStreet2' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet3.Enabled.ToString(), "Verify whether the 'ForwardingStreet3' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingStreet4.Enabled.ToString(), "Verify whether the 'ForwardingStreet4' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingCity.Enabled.ToString(), "Verify whether the 'ForwardingCity' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingState.Enabled.ToString(), "Verify whether the 'ForwardingState' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingCounty.Enabled.ToString(), "Verify whether the 'ForwardingCounty' element is Enabled.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad();
                if (FastDriver.DocumentRepository.Scan.Exists())
                    FastDriver.DocumentRepository.Scan.FAClick();
                else
                    FastDriver.DocumentRepository.Scan_DocsTab.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.Open.FAClick();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\ImageHaving12Pages.tif");
                //FastDriver.OpenImageDlg.OpenImage(@"C:\TFS2\FASTSelenium_MainINT\DocPrep\bin\Debug\Common\Support" + @"\ImageHaving12Pages.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);
                Keyboard.SendKeys("{ENTER}");
                Playback.Wait(1000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Miscellaneous", "", "Miscellaneous", imageTrigger: "AFFIX INV", docName_: "Miscellaneous");
                Playback.Wait(1000);
                Keyboard.SendKeys("{ENTER}");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    return FastDriver.DocumentRepository.Miscellaneous.IsDisplayed();
                }, timeout: 60, idleInterval: 10);
                FastDriver.DocumentRepository.Miscellaneous.FAClick();
                FastDriver.DocumentRepository.EditnameButton.FAClick();

                Reports.TestStep = "Rename the Document Name.";
                FastDriver.RenameDocDlg.WaitForScreenToLoad();
                FastDriver.RenameDocDlg.EditDocName.FASetText(@"SEC-Miscellaneous");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Create a Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "UK ENDOR T", "Uk ENDOR T", multipleDocs: true);

                Reports.TestStep = "Select the Endorsement Document and Click on Remove to Delete It.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "UK ENDOR T", 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    if (FastDriver.DocumentRepository.DocumentsTable.GetRowCount() >= 1)
                    {
                        FastDriver.DocumentRepository.endorsementGuaranteeElement.FAClick();
                        FastDriver.DocumentRepository.Remove.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                        FastDriver.DocumentRepository.WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    }
                    return FastDriver.DocumentRepository.DocumentsTable.GetRowCount() == 0;
                }, timeout: 60, idleInterval: 10);

                Reports.TestStep = "Create a basic File.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0026_FileNum2 = File.FileNumber;

                Reports.TestStep = "select the Documents item to copy.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

                Reports.TestStep = "NegVerify for the Documents if it is Secure Doc or Deleted Docs.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.CopyDocuments.SelectAll.Enabled.ToString(), "Verify whether SelectAll element is Enabled.");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0027()
        {
            try
            {
                Reports.TestDescription = "6869_6849_6850_6851: 1:Assign Charges to HUD-1 Line Number Information, 2:Data copied as part of  Buyer(s)  Data Group, 3:Data copied as part of  Seller(s) Data Group, 5:Data copied as part of Makes the Buyer(s) as the S";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                Reports.TestStep = "Create a basic File";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0027_FileNum1 = File.FileNumber;

                Reports.TestStep = "Select all file items From master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG01-F1");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "To verify the HUD line number Copied from starter file.";
                    FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                    FastDriver.AssignChargestoHUD1LineNumbers.Expand104Section.FAClick();
                    Support.AreEqual(@"104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess104textbox.FAGetText().Clean());
                    Support.AreEqual(@"104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess105textbox.FAGetText().Clean());
                }

                Reports.TestStep = "Enter the required Buyer data in starter file that need to be copied to target file.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                value = FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Buyer1Firstname", FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean());
                FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText(@"9999");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText(@"812-35-4844");
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem(@"a married man");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem(@"as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText(@"Additional Vesting");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(@"Misc Ref1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(@"Misc Ref2");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(@"J305");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(@"JJEJAMQ");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(@"JJEJAMQ");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText(@"ALBANY");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem(@"CA");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText(@"ALAMEDA");
                value = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"USA", value);
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.ForwardngSetToProperty.Selected.ToString(), "Verify whether 'ForwardngSetToProperty' element is unchecked.");
                Support.AreEqual(@"False", FastDriver.BuyerSellerSetup.ForwardingSetToCurrent.Selected.ToString(), "Verify whether 'ForwardingSetToCurrent' element is unchecked.");
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingSetToOther.Selected.ToString(), "Verify whether 'ForwardingSetToOther' element is checked.");
                Support.AreEqual(@"J305", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue().Clean());
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem(@"Home Phone");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText(@"(812)354-8440");
                FastDriver.BuyerSellerSetup.CurrentExtension.FASetText(@"3333");
                FastDriver.BuyerSellerSetup.CurrentPhoneComments.FASetText(@"Phone Comments");
                FastDriver.BuyerSellerSetup.ForwardingPhoneType.FASelectItem(@"Home Phone");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the required Seller data in starter file that need to be copied to target file.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

                value = FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Seller1Firstname", FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller1Lastname", FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean());
                FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText(@"9999");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText(@"812-35-4844");
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem(@"a married man");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem(@"as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText(@"Additional Vesting");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(@"Misc Ref1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(@"Misc Ref2");
                Support.AreEqual(@"J305", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Clean());

                value = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"USA", value);
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingSetToOther.Selected.ToString(), "Verify whether 'ForwardingSetToOther' element is checked.");
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(@"J305");
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(@"JJEJAMQ");
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(@"JJEJAMQ");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText(@"ALBANY");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem(@"CA");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText(@"ALAMEDA");
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem(@"Home Phone");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText(@"(812)354-8440");
                FastDriver.BuyerSellerSetup.CurrentExtension.FASetText(@"3333");
                FastDriver.BuyerSellerSetup.CurrentPhoneComments.FASetText(@"Phone Comments");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Save the File as 'FileNum1'";
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "Create a single File";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Selecting Buyer and seller.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify data for buyer copied from starter file.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                value = FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Buyer1Firstname", FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean());
                Support.AreEqual(@"9999", FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.MaritalStatus.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"a married man", value);
                value = FastDriver.BuyerSellerSetup.Vesting.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"as community property", value);
                Support.AreEqual(@"Additional Vesting", FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue().Clean());
                Support.AreEqual(@"Misc Ref1", FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue().Clean());
                Support.AreEqual(@"Misc Ref2", FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue().Clean());
                Support.AreEqual(@"J305", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"USA", value);
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingSetToOther.Selected.ToString(), "Verify whether 'ForwardingSetToOther' element is unchecked.");
                Support.AreEqual(@"J305", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Home Phone", value);
                Support.AreEqual(@"(812)354-8440", FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FAGetValue().Clean());
                Support.AreEqual(@"3333", FastDriver.BuyerSellerSetup.CurrentExtension.FAGetValue().Clean());
                Support.AreEqual(@"Phone Comments", FastDriver.BuyerSellerSetup.CurrentPhoneComments.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify data for Seller copied from starter file.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                value = FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Seller1Firstname", FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller1Lastname", FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean());
                Support.AreEqual(@"9999", FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.MaritalStatus.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"a married man", value);
                value = FastDriver.BuyerSellerSetup.Vesting.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"as community property", value);
                Support.AreEqual(@"Additional Vesting", FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue().Clean());
                Support.AreEqual(@"Misc Ref1", FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue().Clean());
                Support.AreEqual(@"Misc Ref2", FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue().Clean());
                Support.AreEqual(@"J305", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"USA", value);
                Support.AreEqual(@"True", FastDriver.BuyerSellerSetup.ForwardingSetToOther.Selected.ToString(), "Verify whether 'ForwardingSetToOther' element is unchecked.");
                Support.AreEqual(@"J305", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue().Clean());
                value = FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Home Phone", value);
                Support.AreEqual(@"(812)354-8440", FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FAGetValue().Clean());
                Support.AreEqual(@"3333", FastDriver.BuyerSellerSetup.CurrentExtension.FAGetValue().Clean());
                Support.AreEqual(@"Phone Comments", FastDriver.BuyerSellerSetup.CurrentPhoneComments.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify vest data for buyer copied from starter file.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                value = FastDriver.BuyerVesting.Names.FAGetText().Clean();
                Support.AreEqual(@"True", value.Contains("Buyer1Firstname Buyer1Lastname, 9999, a married man and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname").ToString(),
                    "Verify whether the Names element contains 'Buyer1Firstname Buyer1Lastname, 9999, a married man and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname'.");
                Support.AreEqual(@"Buyer1Firstname Buyer1Lastname, 9999, a married man as community property, Additional Vesting and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname",
                    FastDriver.BuyerVesting.CompleteVesting.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify vest data for Seller copied from starter file.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                value = FastDriver.BuyerVesting.Names.FAGetText().Clean();
                Support.AreEqual(@"True", value.Contains("Seller1Firstname Seller1Lastname, 9999, a married man and Seller2Firstname Seller2Lastname and Seller2SpouseName Seller2Lastname").ToString(),
                    "Verify whether the Names element contains 'Seller1Firstname Seller1Lastname, 9999, a married man and Seller2Firstname Seller2Lastname and Seller2SpouseName Seller2Lastname'.");
                Support.AreEqual(@"Seller1Firstname Seller1Lastname, 9999, a married man as community property, Additional Vesting and Seller2Firstname Seller2Lastname and Seller2SpouseName Seller2Lastname",
                    FastDriver.BuyerVesting.CompleteVesting.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select make buyer as seller from starter file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on overwrite option for copying of file information and documents";
                Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify vest data for buyer copied from starter file when buyer as seller.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                value = FastDriver.BuyerVesting.Names.FAGetText().Clean();
                Support.AreEqual(@"True", value.Contains("Buyer1Firstname Buyer1Lastname, 9999, a married man and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname").ToString(),
                    "Verify whether the Names element contains 'Buyer1Firstname Buyer1Lastname, 9999, a married man and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname'.");
                Support.AreEqual(@"Buyer1Firstname Buyer1Lastname, 9999, a married man as community property, Additional Vesting and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname",
                    FastDriver.BuyerVesting.CompleteVesting.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0028()
        {
            try
            {
                Reports.TestDescription = "6138_9851_6919_6920_6922_1_6866_6867: 1:Copy Data from Edited GAB Contact Information, 2:Copy a referenced image link, 3:Prevent Copy of Created 1099-S Records, 4:Prevent 1099-S Modification in Starter File, 5:Verify 109";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                if (!VerifyFileExistence("REG04-F1"))
                    CreateMasterFileREG0004(false);

                if (!VerifyFileExistence("REG06-F1"))
                    CreateMasterFileREG0006(false);

                Reports.TestStep = "Create a basic File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var REG0028_FileNum1 = File.FileNumber;

                Reports.TestStep = "Edit file business party contact information in starter file.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyEditCont.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessPartyBusPhone.FASetText(@"(999)999-9999");
                FastDriver.FileHomepage.BusinessPartyBusPhoneExtension.FASetText(@"9999");
                FastDriver.FileHomepage.BusinessPartyBusFax.FASetText(@"(999)999-9999");
                FastDriver.FileHomepage.BusinessPartyCellPhone.FASetText(@"(999)999-9999");
                FastDriver.FileHomepage.BusinessPartyPager.FASetText(@"(999)999-9999");
                FastDriver.FileHomepage.BusinessPartyEmailAddress.FASetText(@"test@test.com" + FAKeys.Tab);
                Playback.Wait(500);
                Keyboard.SendKeys("^S");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Create a basic File.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen and select Business source from items to copy.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify for edited gab contacts in target file.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"(745)451-0848", FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"(631)315-4841", FastDriver.FileHomepage.BusinessPartyBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(962)105-4485", FastDriver.FileHomepage.BusinessPartyCellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(982)541-5845", FastDriver.FileHomepage.BusinessPartyPager.FAGetValue().Clean());
                Support.AreEqual(@"busparty@regression.com", FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "verify Default option is Select File Items.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.StarterReference.SelectFileItems.Selected.ToString(), "Verify whether the 'SelectFileItems' element is selected.");

                Reports.TestStep = "select the copy Document from master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

                Reports.TestStep = "Copy documents.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Select the Accomm Sign-Customer Buyer document for Delivery.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Accomm Signing-Customer Buyer", 4, TableAction.Click);

                Reports.TestStep = "Verify for scanned Document.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "INST-Estimated Settlement Statement", 4, TableAction.Click);

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.FileHomepage.FileNum.FAGetValue().Clean();

                Reports.TestStep = "Create a basic File.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var basicFile = File.FileNumber;

                Reports.TestStep = "verify Default option is Select File Items.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.StarterReference.SelectFileItems.Selected.ToString(), "Verify whether the 'SelectFileItems' element is selected.");

                Reports.TestStep = "select the items to copy including Documents.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

                Reports.TestStep = "Copy documents.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Select the Accomm Sign-Customer Buyer document for Delivery.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Accomm Signing-Customer Buyer", 4, TableAction.Click);

                Reports.TestStep = "Verify for scanned Document.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "INST-Estimated Settlement Statement", 4, TableAction.Click);

                Reports.TestStep = "Navigate to TDS screen and Enter Sales price and TAB.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                var cDate = string.Empty;
                value = FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Clean();
                //02-17-2015
                cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();
                //02-17-2015
                if (!cDate.Equals(value))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Open", value);
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText(@"45464" + FAKeys.Tab);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to TDS screen and Enter Settlement Date.";
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Open", value);
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(@"07-12-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to 10099-S screen and Create Ad-Hoc.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.AdHoc.FAClick();
                FastDriver._1099S.WaitForScreenToLoad(FastDriver._1099S.GrossProceedDollor);
                FastDriver._1099S.GrossProceedDollor.FASetText(@"45,464.00");

                Reports.TestStep = "Create 1099s record.";
                FastDriver._1099S.SSNTIN.FASetText(@"1213456966");
                FastDriver._1099S.ActiveFirstName.FASetText(@"FirstName");
                FastDriver._1099S.ActiveLastName.FASetText(@"LastName");
                FastDriver._1099S.ActiveAddress.FASetText(@"address1");
                FastDriver._1099S.ActiveCity.FASetText(@"Santa ana");
                FastDriver._1099S.ActivecboState.FASelectItem(@"CA");
                FastDriver._1099S.ActiveZip.FASetText(@"92070");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Create a basic File.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(basicFile);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Negverify for 1099s record in target file.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                Support.AreNotEqual(@"1213456966", FastDriver._1099S.SSNTIN.FAGetValue().Clean());
                Support.AreNotEqual(@"FirstName", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean());
                Support.AreNotEqual(@"LastName", FastDriver._1099S.ActiveLastName.FAGetValue().Clean());
                Support.AreNotEqual(@"address1", FastDriver._1099S.ActiveAddress.FAGetValue().Clean());
                Support.AreNotEqual(@"Santa ana", FastDriver._1099S.ActiveCity.FAGetValue().Clean());
                value = FastDriver._1099S.ActivecboState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreNotEqual(@"CA", value);
                Support.AreNotEqual(@"92070", FastDriver._1099S.ActiveZip.FAGetValue().Clean());

                Reports.TestStep = "Select all file items From master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Enter REB Broker disbursement.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB(@"247", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"200");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();
                FastDriver.RealEstateBrokerAgent.FindDisbursementGAB(@"255", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"100");

                Reports.TestStep = "To reset the real estate broker info.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(@"220" + FAKeys.Tab);
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(timeout: 20);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0029()
        {
            try
            {
                Reports.TestDescription = "6863: 1:New Loan information";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                Reports.TestStep = "Create a basic File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Sellers = null;
                fileRequest.File.Buyers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select all file items From master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG01-F1");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Enter adhoc charge.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", buyerCharge: 11.12, sellerCharge: 12.11);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Flood Certification", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Tax Service", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "adhoccharge1", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.verifyEmptyLine("adhoccharge1", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "adhoccharge2", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.verifyEmptyLine("adhoccharge2", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "adhoccharge3", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.verifyEmptyLine("adhoccharge3", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "adhoccharge4", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.verifyEmptyLine("adhoccharge4", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "adhoccharge5", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.verifyEmptyLine("adhoccharge5", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "adhoccharge6", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.verifyEmptyLine("adhoccharge6", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "adhoccharge7", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.verifyEmptyLine("adhoccharge7", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "adhoccharge8", buyerCharge: 11.11, sellerCharge: 12.11);
                FastDriver.NewLoan.verifyEmptyLine("adhoccharge8", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "adhoccharge9", buyerCharge: 11.11, sellerCharge: 12.11);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0030()
        {
            try
            {
                Reports.TestDescription = "EWC_1_2_3: 1:�Starter file number not found.�  2:�Can only copy to a file in Open Status.�  3:�Please select/enter a starter file number first.�   OK";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!VerifyFileExistence("REG01-F1"))
                    CreateMasterFileREG0001(false);

                Reports.TestStep = "Create a basic File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "use shortcut key for copy now without having file no.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                Keyboard.SendKeys("%C");

                Reports.TestStep = "Please select/enter a starter file number first.";
                Support.AreEqual(@"Please select/enter a starter file number first.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "use shortcut key for file search.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                Keyboard.SendKeys("%S");

                Reports.TestStep = "Verify for load of file search screen.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.FileHomepage.FileNum.FAGetValue().Clean();

                Reports.TestStep = "Navigate to Starter ref screen and Click on find to search for a file with wild card entry.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FileNum1 = FileNum1.Substring(0, 3);
                FileNum1 = String.Concat(FileNum1, "*");
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                Keyboard.SendKeys("%F");

                Reports.TestStep = "verify for file search dialog.";
                FastDriver.FileNumberSearchSelectionDlg.WaitForScreenToLoad(timeout: 60);
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.FileNumberSearchSelectionDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Enter Invalid starter file no.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(@"XCHD");
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Starter file number not found.";
                Support.AreEqual(@"Starter file number not found.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Create a basic File.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Open in error.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                var cDate = string.Empty;
                value = FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Clean();
                //02-17-2015
                cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();
                //02-17-2015
                if (!cDate.Equals(value))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Open", value);
                FastDriver.TermsDatesStatus.Status.FASelectItem(@"Open In Error");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select all file items From master file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG01-F1");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "can only copy to a file in open status.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Can only copy to a File in Open Status.", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0031()
        {
            try
            {
                Reports.TestDescription = "FD_EWC14_15: 1:Cannot copy document while a pending Copy Doc request exists for the same starter file and target file.   2:�Cannot copy document while a pending Copy Doc request exists for the same starter file and targe";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.IsVisible().ToString(), "ChangeOO button exist.");
                var value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Sale w/Mortgage", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Single Family Residence", value);
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Clean());
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean());
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Clean());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
                value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"CA", value);
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Individual", value);
                Support.AreEqual(@"Seller1FirstName", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean());
                value = FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Husband/Wife", value);
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0032()
        {
            try
            {
                Reports.TestDescription = "13422_EWCBO_7_8_9_10: 1:Starter Ref behavior for Project/Site/ Normal file combinations 2: �Cannot copy from Project file to a Non Project file�, 3:�Cannot copy from Non Project/ Site file to a Project file�, 4:Cannot co";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton().WaitForScreenToLoad();

                Reports.TestStep = "Create Project File Order.";
                FastDriver.QuickFileEntry.CreateDetailedFile(projectFile: true, useAsMasterFile: true, buyer: false, seller: false);

                Reports.TestStep = "Save the Project File as 'FileNum1'";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                var FileNum1 = FastDriver.FileHomepage.FileNum.FAGetValue().Clean();

                Reports.TestStep = "Create a Project File order.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile(projectFile: true, useAsMasterFile: true, buyer: false, seller: false);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Can not copy to a File that has been designated as a Master File.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Can not copy to a File that has been designated as a Master File.", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                Reports.TestStep = "Create a Basic File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Sellers = null;
                fileRequest.File.Buyers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Cannot copy from project file to non project file.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Error: Cannot copy from Project file to a Non Project file.", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                Reports.TestStep = "Save the actual File as 'FileNum1'";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FileNum1 = FastDriver.FileHomepage.FileNum.FAGetValue().Clean();

                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton().WaitForScreenToLoad();

                Reports.TestStep = "Create Project File Order.";
                FastDriver.QuickFileEntry.CreateDetailedFile(projectFile: true, useAsMasterFile: true, buyer: false, seller: false);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Cannot copy from project file to non project file.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Can not copy to a File that has been designated as a Master File.", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                Reports.TestStep = "Save the actual File as 'FileNum1'";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FileNum1 = FastDriver.FileHomepage.FileNum.FAGetValue().Clean();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0033_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder_ForSetofBusinessRules: (Holder_6823_1911_10550_6833_6834_1662_6836_6975_9847_6976_6842_6843_6844_10094_10095_10096_13469_13887_9845_9846_9850_1661_6922)1:Multiple Users copying from the same Starter File Simu";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);



                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0034()
        {
            try
            {
                Reports.TestDescription = "730_1: 1:Use Starter File Globally";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Click on Starter ref link.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.StarterRef.FAClick();

                Reports.TestStep = "verify for load of starter file screen.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.StarterReference.CopyNow.Exists().ToString(), "Verify whether the 'CopyNow' element exists.");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0035()
        {
            try
            {
                Reports.TestDescription = "FM734:Copy 'All File Items'.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "Enter sales price, Liability amount and Est days to close and save the values";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText(@"9,000.00");
                FastDriver.TermsDatesStatus.LiabilityAmount.FAClick();

                Reports.TestStep = "Verify for the message after change the sales price.";
                Support.AreEqual(@"Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "validate to recalculate the real estate broker commission after change the sales price in TDS screen.";
                Support.AreEqual(@"Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter the Est date and save";
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText(@"8,000.00");
                if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday")
                    value = "10";
                else
                    value = "7";
                string EstimattedDaysToClose = value;
                FastDriver.TermsDatesStatus.EstimattedDaysToClose.FASetText(EstimattedDaysToClose);
                FastDriver.TermsDatesStatus.LiabilityAmount.FAClick();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Create a basic Order.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "validate in TDS that sales price, liability amount and Est days to close";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(@"9,000.00", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue().Clean());
                Support.AreEqual(@"8,000.00", FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue().Clean());
                Support.AreEqual(EstimattedDaysToClose, FastDriver.TermsDatesStatus.EstimattedDaysToClose.FAGetValue().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0036()
        {
            try
            {
                Reports.TestDescription = "Restrict Copy of Removed Documents and Images";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "UK ENDOR T", "UK ENDOR T");
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                CreateDocument("Escrow Instruction", "Accomm Signing-Customer Seller", "Accomm Signing-Customer Seller", multipleDocs: true);

                Reports.TestStep = "Select the Endorsement Document and Click on Remove to Delete It.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "UK ENDOR T", 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Create a second Order";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Validate that the removed doc is not appearing";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                Support.AreNotEqual(@"Endorsement/Guarantee", FastDriver.CopyDocuments.DocListTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0037()
        {
            try
            {
                Reports.TestDescription = "Copy utility and survey information from source to target file and validate";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "Create an instance";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode(@"247", WaitForGabCodeLabel: false);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", buyerCharge: 10.00, sellerCharge: 10.00, editDescription: "Starter description");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual(@"Check Amount: $ 20.00", FastDriver.SurveyDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "Create a new instance";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities", buyerCharge: 10.00, sellerCharge: 10.00, editDescription: @"Starter ref descrp");
                FastDriver.UtilityDetail.ProrationAmount.FASetText(@"12.00");
                FastDriver.UtilityDetail.ProrationBuyerCharge.FASetText(@"10.00");
                FastDriver.UtilityDetail.ProrationSellerCharge.FASetText(@"10.00" + FAKeys.TabAway);
                Support.AreEqual(@"Check Amount: $ 20.00", FastDriver.UtilityDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "Create Basic Order.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Validate the datas after copying from starter ref";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                Support.AreEqual(@"Starter description", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Check Amount: $ 20.00", FastDriver.SurveyDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "Valiadate the datas after copying from source file";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                Support.AreEqual(@"Starter ref descrp", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().Clean());
                Support.AreNotEqual(@"10.00", FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue().Clean());
                Support.AreNotEqual(@"10.00", FastDriver.UtilityDetail.ProrationSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Check Amount: $ 20.00", FastDriver.UtilityDetail.CheckAmount.FAGetText().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0038_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "FM6866 : Real Estate Broker/Agent Information copied to file.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Get File No. From File Home Page.";
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "Itemization of Buyer credit and seller credit for Sellers (Listing) Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether the 'CreditSellerEarnestMoneyinexcesscheckbox' is uncheked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether the 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());

                Reports.TestStep = "Enter Buyer Selling REB Info in Source file.";
                FastDriver.RealEstateBrokerAgent.FindGAB(@"HUDFLINSR1", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText(@"10.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"500.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountDescription.FASetText(@"Commission Paid at Settlement");
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FASetText(@"General Excise Tax" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText(@"10.00");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText(@"10.00");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();
                FastDriver.RealEstateBrokerAgent.FindDisbursementGAB(@"247", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"13.00");
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit to Buyer Seller" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Click();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText(@"12.00");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText(@"12.00");
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText(@"Poc Description");
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText(@"POC Desc" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.Click();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText(@"12.00");
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());

                Reports.TestStep = "Verify the Information copied from Source file to target file for Seller listing Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"10.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                Support.AreEqual(@"Commission Paid at Settlement", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"General Excise Tax", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$ 13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction(2, "Lenders Advantage", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual(@"13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.FASetCheckbox(true);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"Credit to Buyer Seller", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"POC Desc", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"483.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a detailed Order.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify the Information copied from Source file to target file for Seller listing Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                Support.AreEqual(@"10.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                Support.AreEqual(@"Commission Paid at Settlement", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"General Excise Tax", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$ 13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction(2, "Lenders Advantage", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual(@"13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.FASetCheckbox(true);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"Credit to Buyer Seller", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"POC Desc", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"483.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0039_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "FM6866 : Real Estate Broker/Agent Information copied to file.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Get File No. From File Home Page.";
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Itemization of Buyer credit and seller credit for Buyers (Selling) Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "New", 4, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());

                Reports.TestStep = "Enter Buyer Selling REB Info in Source file.";
                FastDriver.RealEstateBrokerAgent.FindGAB(@"HUDFLINSR1", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText(@"10.00" + FAKeys.Tab);
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountDescription.FASetText(@"Commission Paid at Settlement");
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FASetText(@"General Excise Tax");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.Click();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText(@"10.00");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText(@"10.00");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();
                FastDriver.RealEstateBrokerAgent.FindDisbursementGAB(@"247", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"13.00");
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                if (!FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit to Buyer Seller");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Click();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText(@"12.00");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText(@"12.00");
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText(@"Poc Description");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.Click();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText(@"12.00");
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the Information copied from Source file to target file for Buyer selling Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                Support.AreEqual(@"10.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                Support.AreEqual(@"Commission Paid at Settlement", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"General Excise Tax", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$ 13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction(2, "Lenders Advantage", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual(@"13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"Credit to Buyer Seller", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"Poc Description", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"483.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create detailed Order.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify the Information copied from Source file to target file for Buyer selling Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                Support.AreEqual(@"10.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                Support.AreEqual(@"Commission Paid at Settlement", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"General Excise Tax", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$ 13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction(2, "Lenders Advantage", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual(@"13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                if (!FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"Credit to Buyer Seller", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue().Clean());
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"Poc Description", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"483.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0040_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "`";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create detailed Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Itemization of Buyer credit and seller credit for New other real Estate Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());

                Reports.TestStep = "Enter Buyer Selling REB Info in Source file.";
                FastDriver.RealEstateBrokerAgent.FindGAB(@"HUDFLINSR1", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText(@"10.00" + FAKeys.Tab);
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountDescription.FASetText(@"Commission Paid at Settlement");
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FASetText(@"General Excise Tax");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.Click();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText(@"10.00");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText(@"10.00");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();
                FastDriver.RealEstateBrokerAgent.FindDisbursementGAB(@"247", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"13.00");
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                if (!FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit to Buyer Seller");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Click();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText(@"12.00");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText(@"12.00");
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText(@"Poc Description");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.Click();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText(@"12.00");
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());

                Reports.TestStep = "Verify the Information copied from Source file to target file for Other Real Estate Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                Support.AreEqual(@"10.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                Support.AreEqual(@"Commission Paid at Settlement", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"General Excise Tax", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$ 13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction(2, "Lenders Advantage", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual(@"13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                Support.AreEqual(@"Credit to Buyer Seller", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue().Clean());
                Support.AreEqual(@"Poc Description", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                Support.AreEqual(@"483.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create detailed Order.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify the Information copied from Source file to target file for Other Real Estate Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                Support.AreEqual(@"10.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                Support.AreEqual(@"Commission Paid at Settlement", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"General Excise Tax", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$ 13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction(2, "Lenders Advantage", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual(@"13.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                if (!FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"Credit to Buyer Seller", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue().Clean());
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"Poc Description", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean());
                Support.AreEqual(@"483.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                Support.AreEqual(@"500.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0041_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "FM6834 : Exclude Items from Settlement Information Copy.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                Reports.TestStep = "Create basic Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create instance for Buyers (Selling) Broker and verify the Credit Seller Earnest Money in excess of Commission amount is ZERO when earnet money is not present in file.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB(@"HUDFLINSR1", waitForElementDisplayed: false);
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Earnest Money amount and Earnest money and Buyer Broker.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"30.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem(@"Buyer's Broker");
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetText().Clean());
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"30.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify when earnest money is greater than commision amout Credit Seller Earnest Money in excess of Commission check Box will be checked and the difference amount will be displayed in text Box for Buyer selling broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().Clean());
                Support.AreEqual(@"True", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is checked.");
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"-30.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().Clean());

                Reports.TestStep = "Enter Commision amount and verify the earnest amount excess.";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10.00" + FAKeys.Tab);
                Support.AreEqual(@"True", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is checked.");
                Support.AreEqual(@"20.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create detailed Order.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select Settlement item to copy from starter file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify that system will not copy the Credit Seller Earnest Money in excess of Commission (Buyer and Seller Real Estate Broker).";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"0.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());

                Reports.TestStep = "Verify that system will not copy the Earnest Amount to the target file.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem(@"Buyer's Broker");
                Support.AreEqual(@"True", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue().Clean().Contains("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2").ToString(),
                    "Verify whether 'EarnerstMoneyName_1' contains 'Flood Insurance 1 for HUD Testing Name 1' text.");
                Support.AreEqual(@"0.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0042_43_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "FM6834 : Exclude Items from Settlement Information Copy.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "create offset adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                if (AutoConfig.UseCDFormType)
                    FastDriver.AdjustmentOffset.UpdateCharge(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 50.00, sellerCredit: 50.00);
                else
                    FastDriver.AdjustmentOffset.UpdateCharge(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 50.00, buyerCredit: 50.00, sellerCharge: 50.00, sellerCredit: 50.00);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "create offset adjustment.";
                if (AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
                }
                else
                {
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
                }

                Reports.TestStep = "Create Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                if (AutoConfig.UseCDFormType)
                    FastDriver.AdjustmentMisc.UpdateCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Buyer Deposit Directly to Seller", buyerCredit: 50.00, sellerCharge: 50.00);
                else
                    FastDriver.AdjustmentMisc.UpdateCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Buyer Deposit Directly to Seller", buyerCredit: 50.00, sellerCredit: 50.00);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Verify Misc Adjustment Instance.";
                if (AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentMisc.BuyerCredit.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentMisc.SellerCharge.FAGetValue().Clean());
                }
                else
                {
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentMisc.BuyerCredit.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentMisc.SellerCredit.FAGetValue().Clean());
                }

                Reports.TestStep = "Create new OTC instance.";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.FindGAB(@"814");
                FastDriver.OutsideTitleCompanyDetail.DipStatusCode.FASelectItem(@"0-Best Evidence");
                FastDriver.OutsideTitleCompanyDetail.FundsDepositedEdit.FASetText(@"250.00" + FAKeys.Tab);
                FastDriver.OutsideTitleCompanyDetail.TypeSelect.FASelectItem(@"Attorney");
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, "Title - Title Examination", buyerCharge: 10.00, sellerCharge: 20.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>("Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText(@"Reason For First Hold Fund Instance.");
                if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday")
                    value = "10";
                else
                    value = "7";
                FastDriver.HoldFunds.ReleaseinDays.FASetText(value + FAKeys.Tab);

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText(@"10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.WaitForScreenToLoad(FastDriver.HoldFunds.HoldFundBusPartyGABcode);
                FastDriver.HoldFunds.FindGABCode(@"HOLDFUNDS");
                FastDriver.HoldFunds.UpdateCharge(FastDriver.HoldFunds.HoldFundChargesTable, "Ad Hoc Entry", sellerCharge: 4.00, editDescription: "Hold Fund Desc");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify for charges.";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual(@"Reason For First Hold Fund Instance.", FastDriver.HoldFunds.Reason.FAGetValue().Clean());
                string Date1 = DateTime.Now.ToDateString();
                string Date2 = DateTime.Today.AddDays(-1).ToDateString();
                value = FastDriver.HoldFunds.Date.FAGetValue().Clean();
                if (value.Contains(Date1))
                {
                    Support.AreEqual(Date1, value);
                }
                else
                {
                    Support.AreEqual(Date2, value);
                }
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction("Name", "holdfund name 1", "Name", TableAction.Click);
                Support.AreEqual(@"", FastDriver.HoldFunds.HoldFundBuyerCharge1.FAGetValue().Clean());

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                Reports.TestStep = "Verify Formula for 365 Day format - Per Year.";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.ProrationDetail.DayofClosePaidbySeller.FASetCheckbox(false);
                FastDriver.ProrationDetail.Amount.FASetText(@"10.00");
                FastDriver.ProrationDetail.FromDate.FASetText(@"04-02-2012");
                FastDriver.ProrationDetail.fromInclusive.FASetCheckbox(true);
                FastDriver.ProrationDetail.Per.FASelectItem(@"YEAR");
                FastDriver.ProrationDetail.ToDate.FASetText(@"07-02-2012" + FAKeys.Tab);
                Support.AreEqual(@"2.49", FastDriver.ProrationDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"2.49", FastDriver.ProrationDetail.SellerCredit.FAGetValue().Clean());

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText(@"10.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(@"Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem(@"Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText(@"Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(@"Buyer");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Enter charges to New loan Funding Date,Signing Date,Rescission Period Begins.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText(@"03/16/2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText(@"08/03/2012");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText(@"12/12/2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText(@"2" + FAKeys.Tab);
                Support.AreEqual(@"12-14-2012", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the information entered.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                value = FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Small Loan", value);
                Support.AreEqual(@"03-16-2011", FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue().Clean());
                Support.AreEqual(@"08-03-2012", FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue().Clean());
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                Support.AreEqual(@"12-12-2012", FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue().Clean());
                Support.AreEqual(@"2", FastDriver.NewLoan.LoanDetailsDays.FAGetValue().Clean());
                Support.AreEqual(@"12-14-2012", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                #region TC FMUC0003_REG0043

                Reports.TestStep = "Create detailed Order.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Select Settlement item to copy from starter file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify that system will not copy the Funding Date,Signing Date,Rescission Period Begins when we copy from Startrer Ref.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                value = FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Small Loan", value);
                Support.AreEqual(@"", FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.NewLoan.LoanDetailsFundsReceived.Selected.ToString(), "Verify whether 'LoanDetailsFundsReceived' is unchecked.");
                Support.AreEqual(@"", FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.NewLoan.LoanDetailsDays.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that system will not copy charges when copy from starter ref.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                if (AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
                }
                else
                {
                    Support.AreEqual(@"", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean());
                    Support.AreEqual(@"", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
                }

                Reports.TestStep = "Verify that system will not copy charges when copy from starter ref.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>("Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                Support.AreEqual(@"", FastDriver.HoldFunds.Reason.FAGetValue().Clean());
                value = DateTime.Now.ToDateString();
                Date1 = value;
                Date2 = DateTime.Today.AddDays(-1).ToDateString();
                value = FastDriver.HoldFunds.Date.FAGetValue().Clean();
                if (value.Contains(Date1))
                {
                    Support.AreEqual(Date1, value);
                }
                else
                {
                    Support.AreEqual(Date2, value);
                }
                Support.AreEqual(@"", FastDriver.HoldFunds.ReleaseinDays.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.HoldFunds.DateDaysOn.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.HoldFunds.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.HoldFunds.SellerCharge.FAGetValue().Clean());

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                Reports.TestStep = "Verify that system will not copy charges when copy from starter ref.";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString(), "Verify whether 'CreditSeller' is unchecked.");
                Support.AreEqual(@"False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString(), "Verify whether 'DayofClosePaidbySeller' is unchecked.");
                Support.AreEqual(@"", FastDriver.ProrationDetail.Amount.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ProrationDetail.FromDate.FAGetValue().Clean());
                Support.AreEqual(@"True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString(), "Verify whether 'fromInclusive' is checked.");
                Support.AreEqual(@"False", FastDriver.ProrationDetail.fromProrate.Selected.ToString(), "Verify whether 'fromProrate' is unchecked.");
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"YEAR", value);
                Support.AreEqual(@"", FastDriver.ProrationDetail.ToDate.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ProrationDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ProrationDetail.BuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ProrationDetail.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ProrationDetail.SellerCredit.FAGetValue().Clean());

                Reports.TestStep = "Verify rowcount : Verify that system will not copy the Disbursement data when we copy from Starter ref.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual(@"2", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Verify the numbers of rows of the Disbursements table (visible ones).");

                Reports.TestStep = "Verify that system will not copy the deposit when we copy file using starter ref.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"0.00", FastDriver.DepositInEscrow.BuyerDeposits.FAGetText().Clean(), "Verify if the Buyer Deposits value is $ 0.00");

                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0043_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "FM6834 : Exclude Items from Settlement Information Copy.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0042.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0044_45_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "MasterFileCreation:";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.FileHomepage.FileNum.FAGetValue().Clean();

                Reports.TestStep = "Create instance for Buyers (Selling) Broker and verify the Credit Seller Earnest Money in excess of Commission amount is ZERO when earnet money is not present in file.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB(@"HUDFLINSR1", waitForElementDisplayed: false);
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Earnest Money amount and Earnest money and Buyer Broker.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"30.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItemByIndex(1);
                Keyboard.SendKeys("{TAB}");
                value = FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue().Clean();
                Support.AreEqual(@"True", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue().Clean().Contains("Flood Insurance 1 for HUD Testing Name 1").ToString(),
                    "Verify whether the 'EarnerstMoneyName_1' contains text: 'Flood Insurance 1 for HUD Testing Name 1'");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"30.00");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Verify when earnest money is greater than commision amout Credit Seller Earnest Money in excess of Commission check Box will be checked and the difference amount will be displayed in text Box for Buyer selling broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().Clean());
                Support.AreEqual(@"True", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is checked.");
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.Selected.ToString(), "Verify whether 'CreditBuyerSellingBrokerCheckBox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().Clean());
                Support.AreEqual(@"-30.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Clean());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().Clean());

                Reports.TestStep = "Enter Commision amount and verify the earnest amount excess.";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10.00" + FAKeys.Tab);
                Support.AreEqual(@"True", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is checked.");
                Support.AreEqual(@"20.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                #region Test Case FMUC0003_REG0045

                Reports.TestStep = "Create a detailed Order.";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify that system will not copy the Credit Seller Earnest Money in excess of Commission (Buyer and Seller Real Estate Broker).";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                Support.AreEqual(@"0.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Selected.ToString(), "Verify whether 'CreditSellerEarnestMoneyinexcesscheckbox' is unchecked.");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().Clean());

                Reports.TestStep = "Verify that system will not copy the Earnest Amount to the target file.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem(@"Buyer's Broker");
                Support.AreEqual(@"True", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue().Clean().Contains("Flood Insurance 1 for HUD Testing Name 1").ToString(),
                    "Verify whether 'EarnerstMoneyName_1' contains text: 'Flood Insurance 1 for HUD Testing Name 1'");
                Support.AreEqual(@"0.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue().Clean());
                FastDriver.BottomFrame.Save();

                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0045_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "FM6836 : Exclude from Copy 'All File Items'.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0044.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0046_47_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "FM6836 : Exclude from Copy 'All File Items'.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Save the File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.FileHomepage.FileNum.FAGetValue().Clean();

                Reports.TestStep = "create offset adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                    FastDriver.AdjustmentOffset.UpdateCharge(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 50.00, buyerCredit: 50.00, sellerCharge: 50.00, sellerCredit: 50.00);
                else
                    FastDriver.AdjustmentOffset.UpdateCharge(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 50.00, sellerCredit: 50.00);

                Reports.TestStep = "validate offset adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
                }
                else
                {
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                if (!FastDriver.AdjustmentMisc.SellerCredit.IsReadOnly())
                    FastDriver.AdjustmentMisc.UpdateCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Buyer Deposit Directly to Seller", buyerCredit: 50.00, sellerCredit: 50.00);
                else
                    FastDriver.AdjustmentMisc.UpdateCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Buyer Deposit Directly to Seller", buyerCredit: 50.00);

                Reports.TestStep = "Validates Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                    Support.AreEqual(@"50.00", FastDriver.AdjustmentMisc.SellerCredit.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.AdjustmentMisc.BuyerCredit.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create new OTC instance.";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.FindGAB(@"814");
                FastDriver.OutsideTitleCompanyDetail.DipStatusCode.FASelectItem(@"0-Best Evidence");
                FastDriver.OutsideTitleCompanyDetail.FundsDepositedEdit.FASetText(@"250.00");
                FastDriver.OutsideTitleCompanyDetail.TypeSelect.FASelectItem(@"Attorney");
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, "Title - Title Examination", buyerCharge: 10.00, sellerCharge: 20.00);
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual(@"$ 30.00", FastDriver.OutsideTitleCompanyDetail.TotalCharges.FAGetText().Clean());
                Support.AreEqual(@"$ 250.00", FastDriver.OutsideTitleCompanyDetail.FundsDeposited.FAGetText().Clean());
                Support.AreEqual(@"$ 220.00", FastDriver.OutsideTitleCompanyDetail.FundsDue.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>("Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText(@"Reason For First Hold Fund Instance.");
                string ReleaseinDays = "";
                if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday")
                    ReleaseinDays = "9";
                else
                    ReleaseinDays = "7";
                FastDriver.HoldFunds.ReleaseinDays.FASetText(ReleaseinDays + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText(@"10.00" + FAKeys.Tab);
                Support.AreEqual(@"10.00", FastDriver.HoldFunds.SellerRemaining.FAGetText().Clean());
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.WaitForScreenToLoad(FastDriver.HoldFunds.GABName);
                FastDriver.HoldFunds.FindGABCode(@"HOLDFUNDS");
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText(@"Hold Fund Desc");
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText(@"4.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify for charges.";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                value = FastDriver.HoldFunds.Reason.FAGetValue().Clean();
                value = DateTime.Now.ToDateString();
                string Date1 = value;
                string Date2 = DateTime.Today.AddDays(-1).ToDateString();
                value = FastDriver.HoldFunds.Date.FAGetValue().Clean();
                if (value.Contains(Date1))
                {
                    Support.AreEqual(Date1, value);
                }
                else
                {
                    Support.AreEqual(Date2, value);
                }
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction("Name", "holdfund name 1", "Name", TableAction.Click);
                Support.AreEqual(@"", FastDriver.HoldFunds.HoldFundBuyerCharge1.FAGetValue().Clean());

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                Reports.TestStep = "Enter Description and Charges.";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.ProrationDetail.Amount.FASetText(@"10.00");
                FastDriver.ProrationDetail.FromDate.FASetText(@"04-02-2012");
                FastDriver.ProrationDetail.BasedOn.FASelectItem(@"365");
                FastDriver.ProrationDetail.Per.FASelectItem(@"YEAR");
                FastDriver.ProrationDetail.ToDate.FASetText(@"07-02-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Formula for 365 Day format - Per Year.";
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString(), "Verify whether 'CreditSeller' is checked.");
                Support.AreEqual(@"False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString(), "Verify whether 'DayofClosePaidbySeller' is unchecked.");
                Support.AreEqual(@"10.00", FastDriver.ProrationDetail.Amount.FAGetValue().Clean());
                Support.AreEqual(@"04-02-2012", FastDriver.ProrationDetail.FromDate.FAGetValue().Clean());
                Support.AreEqual(@"True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString(), "Verify whether 'fromInclusive' is checked.");
                Support.AreEqual(@"False", FastDriver.ProrationDetail.fromProrate.Selected.ToString(), "Verify whether 'fromProrate' is unchecked.");
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"YEAR", value);
                Support.AreEqual(@"07-02-2012", FastDriver.ProrationDetail.ToDate.FAGetValue().Clean());
                Support.AreEqual(@"2.49", FastDriver.ProrationDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"2.49", FastDriver.ProrationDetail.SellerCredit.FAGetValue().Clean());

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("10.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText(@"Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Enter charges to New loan Funding Date,Signing Date,Rescission Period Begins.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000000" + FAKeys.Tab);
                Keyboard.SendKeys("{ENTER}");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText(@"03/16/2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText(@"08/03/2012");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText(@"12/12/2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText(@"2" + FAKeys.Tab);
                Support.AreEqual(@"12-14-2012", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the information entered.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                value = FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Small Loan", value);
                Support.AreEqual(@"03-16-2011", FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue().Clean());
                Support.AreEqual(@"08-03-2012", FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue().Clean());
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                Support.AreEqual(@"12-12-2012", FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue().Clean());
                Support.AreEqual(@"2", FastDriver.NewLoan.LoanDetailsDays.FAGetValue().Clean());
                Support.AreEqual(@"12-14-2012", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the first fee.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);

                Reports.TestStep = "Set on final button in Invoice screen.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.InvoiceFees.Final.Enabled.ToString(), "Verify whether 'Final' is enabled.");
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Validate Final Status.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 1, TableAction.Click);
                FastDriver.InvoiceFees.History.FAClick();

                Reports.TestStep = "Create instance with charges.";
                FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();
                FastDriver.SearchVendor.FindGAB(@"247");
                FastDriver.BottomFrame.Done();
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Lenders Advantage", 2, TableAction.Click);
                FastDriver.SearchVendorSummary.Edit.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                string VenderDetailsConfirmDate_cdate = value;
                FastDriver.SearchVendor.VenderDetailsConfirmDate.FASetText(VenderDetailsConfirmDate_cdate);
                FastDriver.SearchVendor.VenderDetailsProductionProcess.FASelectItem(@"Amend");
                FastDriver.SearchVendor.VenderDetailsCost.FASetText(@"500.01");
                FastDriver.SearchVendor.Comments.SendKeys(@"Comments for the search vendor");
                Support.AreEqual(@"Comments for the search vendor", FastDriver.SearchVendor.Comments.FAGetValue().Clean());
                FastDriver.SearchVendor.CommentsSave.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Edit button.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Lenders Advantage", 3, TableAction.Click);
                FastDriver.SearchVendorSummary.Edit.FAClick();

                Reports.TestStep = "verify instance with charges.";
                FastDriver.SearchVendor.WaitForScreenToLoad();
                value = FastDriver.SearchVendor.VenderDetailsProductionProcess.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Amend", value);
                Support.AreEqual(@"500.01", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                #region Test Case FMUC0003_REG0047

                Reports.TestStep = "Verify system will not copy the search Vendor info to target file.";
                FastDriver.LeftNavigation.Navigate<SearchVendorSummary>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();
                FastDriver.SearchVendorSummary.New.FAClick();
                FastDriver.SearchVendor.WaitForScreenToLoad();
                Support.AreEqual(@"", FastDriver.SearchVendor.VenderDetailsConfirmDate.FAGetValue().Clean());
                value = FastDriver.SearchVendor.VenderDetailsProductionProcess.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"", value);
                Support.AreEqual(@"0.00", FastDriver.SearchVendor.VenderDetailsCost.FAGetValue().Clean());

                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0047_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "FM6836 : Exclude from Copy 'All File Items'.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0046.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0048_Prad_8_3_FD()
        {
            try
            {
                Reports.TestDescription = "FM14595 : Prevent Copy of all items When Target File has AgentNet Policy Numbers";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                FMUC0003_REG00048A_PreRequisite(credentials, true);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Get and save file number.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();

                Reports.TestStep = "P-2243 Select a Product";
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(@"246");
                FastDriver.QuickFileEntry.BusinessSourceReference.FASetText(@"1234");
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem(@"New Lender");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.QuickFileEntry.UnselectAllCheckboxFromProductTable();
                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();

                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductListDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Extended Loan Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "P-2243 Create an Agent File";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"260000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText(@"5000");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"1 First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"santa ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText(@"90027");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"Orange");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem(@"Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText(@"BuyrFname1");
                FastDriver.QuickFileEntry.Buyer1MiddleName.FASetText(@"M");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText(@"BuyrLname1");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem(@"Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText(@"SelrFname1");
                FastDriver.QuickFileEntry.Seller1MiddleName.FASetText(@"M");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText(@"SelrLname1");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the buttons in RPN screen";
                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number");
                Playback.Wait(20000);//Explicit wait due view slowness
                FastDriver.RequestPolicyNumber.WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem(@"First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                Support.AreEqual(@"False", FastDriver.RequestPolicyNumber.RequestNumber.Enabled.ToString(), "Verify whether 'Request Number' button is Disabled.");
                Support.AreEqual(@"False", FastDriver.RequestPolicyNumber.VoidNumber.Enabled.ToString(), "Verify whether 'Void Number' button is Disabled.");
                Support.AreEqual(@"False", FastDriver.RequestPolicyNumber.AddProduct.Enabled.ToString(), "Verify whether 'Add Product' button is Disabled.");

                Reports.TestStep = "Highlight the row with FAST product associated to AgentNet product and request for the policy number";
                FastDriver.RequestPolicyNumber.PolicyName.FAClick();
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.RequestPolicyNumber.WaitForScreenToLoad();
                string PolicyNumbers_Pol_Num = FastDriver.RequestPolicyNumber.PolicyNumbers.FAGetText();

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Validate: Error(s) occurred. See Message pane.";
                Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Verify Starter/Ref when there is a An policy number in the file";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Target file has AgentNet Products/Policy Numbers - process aborted", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0049_Prad_8_3_FD()
        {
            try
            {
                Reports.TestDescription = "FM14595 : Prevent Copy of Products and Property When Target File has AgentNet Policy Numbers";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Get and save file number.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();

                Reports.TestStep = "P-2243 Select a Product";
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(@"246");
                FastDriver.QuickFileEntry.BusinessSourceReference.FASetText(@"1234");
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem(@"New Lender");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.QuickFileEntry.UnselectAllCheckboxFromProductTable();
                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();

                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductSelectionDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductSelectionDlg.Table.PerformTableAction(2, "*ALTA Extended Loan Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "P-2243 Create an Agent File";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"260000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText(@"5000");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"1 First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"santa ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText(@"90027");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"Orange");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem(@"Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText(@"BuyrFname1");
                FastDriver.QuickFileEntry.Buyer1MiddleName.FASetText(@"M");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText(@"BuyrLname1");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem(@"Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText(@"SelrFname1");
                FastDriver.QuickFileEntry.Seller1MiddleName.FASetText(@"M");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText(@"SelrLname1");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the buttons in RPN screen";
                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number").WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem(@"First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                //Support.AreEqual(@"False", FastDriver.RequestPolicyNumber.RequestNumber.Enabled.ToString(), "Verify whether 'Request Number' button is Disabled.");
                //Support.AreEqual(@"False", FastDriver.RequestPolicyNumber.VoidNumber.Enabled.ToString(), "Verify whether 'Void Number' button is Disabled.");
                //Support.AreEqual(@"False", FastDriver.RequestPolicyNumber.AddProduct.Enabled.ToString(), "Verify whether 'Add Product' button is Disabled.");

                Reports.TestStep = "Highlight the row with FAST product associated to AgentNet product and request for the policy number";
                FastDriver.RequestPolicyNumber.PolicyName.FAClick();
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                //PolicyNumbers_Pol_Num = FastDriver.RequestPolicyNumber.PolicyNumbers.FAGetText().Clean();

                Reports.TestStep = "Select Products, Property Address/Legal/Tax Information";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.Products.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Validate: Error(s) occurred. See Message pane.";
                Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage().Clean().Clean());

                Reports.TestStep = "Verify Starter/Ref when there is a An policy number in the file";
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Target file has AgentNet Products/Policy Numbers - process aborted", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0050_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "FM14594 : Allow copy of Business Source, Buyer(s) Data, Seller(s) Data, Make the Buyer(s) as the Seller(s), File Notes, Settlement Information when there is AN policy Number";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Get and save file number.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.FileHomepage.FileNum.FAGetValue().Clean();

                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();

                Reports.TestStep = "P-2243 Select a Product";
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(@"246");
                FastDriver.QuickFileEntry.BusinessSourceReference.FASetText(@"1234");
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem(@"New Lender");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.QuickFileEntry.UnselectAllCheckboxFromProductTable();
                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();

                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductSelectionDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductSelectionDlg.Table.PerformTableAction(2, "*ALTA Extended Loan Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "P-2243 Create an Agent File";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"260000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText(@"5000");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"1 First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"santa ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText(@"90027");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"Orange");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem(@"Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText(@"BuyrFname1");
                FastDriver.QuickFileEntry.Buyer1MiddleName.FASetText(@"M");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText(@"BuyrLname1");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem(@"Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText(@"SelrFname1");
                FastDriver.QuickFileEntry.Seller1MiddleName.FASetText(@"M");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText(@"SelrLname1");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the buttons in RPN screen";
                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number").WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem(@"First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                Support.AreEqual(@"False", FastDriver.RequestPolicyNumber.RequestNumber.Enabled.ToString(), "Verify whether 'Request Number' button is Disabled.");
                Support.AreEqual(@"False", FastDriver.RequestPolicyNumber.VoidNumber.Enabled.ToString(), "Verify whether 'Void Number' button is Disabled.");
                Support.AreEqual(@"False", FastDriver.RequestPolicyNumber.AddProduct.Enabled.ToString(), "Verify whether 'Add Product' button is Disabled.");

                Reports.TestStep = "Highlight the row with FAST product associated to AgentNet product and request for the policy number";
                FastDriver.RequestPolicyNumber.PolicyName.FAClick();
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                //PolicyNumbers_Pol_Num = FastDriver.RequestPolicyNumber.PolicyNumbers.FAGetText().Clean();

                Reports.TestStep = "Select Buyer,Seller ,Business Source,File Notes , Settlement Information";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.Notes.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Click on overwrite option for copying of file information and documents";
                Support.AreEqual(@"True", FastDriver.WebDriver.HandleDialogMessage().Clean().Contains("Previously entered data will be overwritten, do you want to continue?").ToString(),
                    "Verify whether the Dlg contains text: 'Previously entered data will be overwritten, do you want to continue?'");


                FMUC0003_REG00048A_PreRequisite(credentials, false);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0051()
        {
            try
            {
                Reports.TestDescription = "EWC7_FM737_FM738_FM739_FM735_FM6832_FM736 : Selects a data group to copy from the Starter file and that data group does not exist on the Starter file, but it already exists on the Target file and, Buyer(s) Info Group. Make Buyer as Seller Group";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Login in FAST.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creating an Order/File with Buyer";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(@"HUDFLINSR1");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(@"HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount.FASetText(@"5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText(@"5000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"ALAMEDA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText(@"92707");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(@"247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText(@"HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem(@"EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Adding 2nd product - Abstract";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.AddRemoveProducts.FAClick();
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductSelectionDlg.Checkbox1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Keyboard.SendKeys("^S");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Change the file into HUD";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.HUD.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Captures the file number";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Creates 2nd order without Buyer and Seller";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(@"248");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(@"HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Multi Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"2ndFileLot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"2ndFileBlock1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"2ndFileUnit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN2");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845019999");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"BUTTE");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(@"247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText(@"HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem(@"EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
                FastDriver.BottomFrame.Done();
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Changes the second file into HUD";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.HUD.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Copying the file into another file with Data Group=Buyers";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.BuyersData.FASetCheckbox(false);

                Reports.TestStep = "Verifies the newly added Buyer's details";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "2", "No", TableAction.Click);

                Reports.TestStep = "Copying the file into another file with Data Group=Sellers";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.SellersData.FASetCheckbox(false);

                Reports.TestStep = "Verifies the newly added Sellers' details";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "2", "No", TableAction.Click);

                Reports.TestStep = "Verifies HUD1 header address.";
                FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>(@"Home>Order Entry>Escrow Closing>HUD-1 Statement").WaitForScreenToLoad();
                value = FastDriver.HUD1PrintOptions.AddressOfSeller.FAGetValue().Clean();
                Support.AreEqual(@"True", value.Contains("J305").ToString(), "Verify whether the 'Address of Seller' contains 'J305'.");
                Support.AreEqual(@"True", value.Contains("JJEJAMQ").ToString(), "Verify whether the 'Address of Seller' contains 'JJEJAMQ'.");
                Support.AreEqual(@"True", value.Contains("ALBANY").ToString(), "Verify whether the 'Address of Seller' contains 'ALBANY'.");
                Support.AreEqual(@"True", value.Contains("CA").ToString(), "Verify whether the 'Address of Seller' contains 'CA'.");

                value = FastDriver.HUD1PrintOptions.PropLocation.FAGetValue().Clean();
                Support.AreEqual(@"True", value.Contains("J305").ToString(), "Verify whether the 'Address of Seller' contains 'J305'.");
                Support.AreEqual(@"True", value.Contains("JJEJAMQ").ToString(), "Verify whether the 'Address of Seller' contains 'JJEJAMQ'.");
                Support.AreEqual(@"True", value.Contains("ALBANY").ToString(), "Verify whether the 'Address of Seller' contains 'ALBANY'.");
                Support.AreEqual(@"True", value.Contains("CA").ToString(), "Verify whether the 'Address of Seller' contains 'CA'.");
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Deletes the existing Sellers' details to start the scenario - Make Buyer as Seller Group";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "2", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Copies MaketheBuyersastheSellers data group";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(false);

                Reports.TestStep = "Validates the copying of MaketheBuyersastheSellers data group";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Name", "Buyer1Firstname Buyer1Lastname", "Name", TableAction.Click);
                Debug.Print(FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean());
                Support.AreEqual(@"True", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean().Contains("Buyer2Firstname").ToString(),
                    "Verify whether text 'Buyer2Firstname' in the column Name of the second row.");

                Reports.TestStep = "Copying Business Source data group, PropertyAddressLegalTaxInformation";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(false);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(false);

                Reports.TestStep = "Validating the copied Business Source data group";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.FileHomepage.BusinessPartyIDCodeField.FAGetText().Clean().Contains("HUDFLINSR1").ToString(),
                    "Verify whether 'BusinessPartyIDCodeField' contains text: 'HUDFLINSR1'.");

                Reports.TestStep = "Entering the First file number in the File Number text box to create a New GAB.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum1);

                Reports.TestStep = "Enter a Ad Hoc Gab and click on Find Button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.IDCode.FASetText(@"247");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);

                Reports.TestStep = "Clicking on New GAB button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();

                Reports.TestStep = "Add a Ad Hoc Contact.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad(FastDriver.GABEntryRequestDlg.BuyerSellerType);
                FastDriver.GABEntryRequestDlg.BuyerSellerType.FASelectItem(@"Business Entity");
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem(@"Lender");
                FastDriver.GABEntryRequestDlg.Name1.FASetText(@"Malli Mastanbabu");
                FastDriver.GABEntryRequestDlg.BusinessPhoneNumber.FASetText(@"7587857412");
                FastDriver.GABEntryRequestDlg.BusinessPhoneExtension.FASetText(@"155");
                FastDriver.GABEntryRequestDlg.EmailNumber.FASetText(@"t@te.com");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText(@"455");
                FastDriver.GABEntryRequestDlg.MailingAddressLine2.FASetText(@"1st Main");
                FastDriver.GABEntryRequestDlg.MailingAddressLine3.FASetText(@"16 Cross");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText(@"MIDWAY");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem(@"TX");
                FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText(@"96015");
                FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText(@"HILL");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);

                Reports.TestStep = "Validates the default details in FHP";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string NewGAB = FastDriver.FileHomepage.BusinessPartyIDCodeField.FAGetText().Clean();
                Support.AreEqual(@"True", NewGAB.Contains("AD").ToString(), "Verify whether 'NewGAB' contains text: 'AD'.");
                Support.AreEqual(@"(758)785-7412", FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"155", FastDriver.FileHomepage.BusinessPartyBusPhoneExtension.FAGetValue().Clean());
                Support.AreEqual(@"t@te.com", FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering the Second file number in the File Number text box to copy the NewGAB from 1st file";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum2);

                Reports.TestStep = "Copying the file into another file with Data Group=Business Source";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                FastDriver.StarterReference.Products.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();

                Reports.TestStep = "Validating the copied new GAB on the file home page";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                value = FastDriver.FileHomepage.BusinessPartyIDCodeField.FAGetText().Clean();
                Support.AreEqual(@"True", value.Substring(0, 2).Contains(NewGAB.Substring(0, 2)).ToString(), "Verify whether 'BusinessPartyIDCode' contains the first 2 characters of " + NewGAB);
                Support.AreEqual(@"(758)785-7412", FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"155", FastDriver.FileHomepage.BusinessPartyBusPhoneExtension.FAGetValue().Clean());
                Support.AreEqual(@"t@te.com", FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue().Clean());

                Reports.TestStep = "Validating the copied product data";
                FastDriver.FileHomepage.ProductsTable.PerformTableAction("Product Name", "Abstract", "Product Name", TableAction.Click);

                Reports.TestStep = "Validating the copied Property tax data group";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual(@"J305", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Clean());
                Support.AreEqual(@"JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Clean());
                Support.AreEqual(@"ALBANY", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Clean());
                Support.AreEqual(@"CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem());
                Support.AreEqual(@"ALAMEDA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Clean());
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Support.AreEqual(@"J305", FastDriver.PropertyTaxInfoLegalDesciption.Name.FAGetValue().Clean());
                Support.AreEqual(@"Lot1", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue().Clean());
                Support.AreEqual(@"Block1", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue().Clean());
                Support.AreEqual(@"Unit1", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue().Clean());
                FastDriver.PropertyTaxInfoLegalDesciption.ClickTaxTab().WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable1.PerformTableAction("Tax No/APN", "9845012345", "Tax No/APN", TableAction.Click);
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    return FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.Displayed;
                }, timeout: 20, idleInterval: 10);
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable1.PerformTableAction("Tax No/APN", "Prop1APN1", "Tax No/APN", TableAction.Click);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0052()
        {
            try
            {
                Reports.TestDescription = "EWC9_EWC10_EWC11_EWC13_EWC14_EWC15_FM730 : User has selected Business Source group and the Target File has one or more invoices associated to the Business Source with invoice status ESTIMATED, ESTIMATED ADJUSTED, FINAL, FINAL ADJUSTED, CANCELESTI OR CANCELFINL. User has selected Buyer, Seller or Make the Buyer as the Seller groups and the Target File has one or more invoices associated with the Buyer/Seller with invoice status ESTIMATED, ESTIMATED ADJUSTED, FINAL, FINAL ADJUSTED, and CANCELESTI OR CANCELFINL. User selected Settelement Info group";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creates Order with Buyer and Seller";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile(directedGab: "HUDLEASE03");

                Reports.TestStep = "Create Document.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                CreateDocument("Endorsement/Guarantee", "Bus Source", "Bus Source");

                Reports.TestStep = "Captures the first file number";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create Order without Buyers/Sellers.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile(directedGab: "HUDLEASE03", buyer: false, seller: false);

                Reports.TestStep = "Generating Invoice by adding Fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "22.22");

                Reports.TestStep = "Add the second fee in Fee Entry.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "33.33");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Makes Invoice status as Estimated";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.Estimate.FAClick();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction("Status", "ESTIMATED", "Status", TableAction.Click);

                Reports.TestStep = "Copying the second file number";
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Copying the file into another file with Data Group=Business Source";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Validtates that the copying throws error popup which is expected behaviour.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.BusinessSource.FASetCheckbox(false);

                Reports.TestStep = "Cancelling the Invoice to select - 'Make the Buyer as the Seller'";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.Cancel.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction("Status", "CANCELESTI", "Status", TableAction.Click);

                Reports.TestStep = "Use Starter File Globally. Validate the Starter/Ref link on the TopFrame blue nav bar";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.StarterRef.FAClick();
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.StarterReference.StarterFileNumber.Exists().ToString(), "Verify whether the 'StarterReference' field exists.");

                Reports.TestStep = "User has selected Buyer, Seller or Make the Buyer as the Seller groups and the Target File has one or more invoices associated with the Buyer/Seller with invoice status ESTIMATED, ESTIMATED ADJUSTED, FINAL, FINAL ADJUSTED, and CANCELESTI OR CANCELFINL.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Validtates that the copying was finished without errors";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "User has selected Settlement Info group and the Target File has one or more invoices associated with the File.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(false);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(false);

                Reports.TestStep = "User selects both “Seller(s) Data” and “Make the Buyer(s) as the Seller(s)”,or User selects both “Buyer(s) Data” and “Make the Buyer(s) as the Sellers(s)”,and clicks Copy Now button.";
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validtates that the copying was finished without errors after selecting Settlement Info Group";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.SellersData.FASetCheckbox(false);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(false);

                Reports.TestStep = "Selecting Copy Doc option while another Copy Doc process was just being started";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum);
                FastDriver.StarterReference.CopyDocument.FAClick();
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum);
                FastDriver.StarterReference.CopyDocument.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Selecting Copy Doc option while another Copy Doc process is still pending";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum);
                FastDriver.StarterReference.CopyDocument.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum);
                FastDriver.StarterReference.CopyDocument.FAClick();
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0053()
        {
            try
            {
                Reports.TestDescription = "EWC16_EWC17_FM10549_FD_EWC1_EWC5_EWC6_FM732_FM743_FM10957 : By selecting a File Item, user tries to copy Property Address/Legal/Tax Information from a source file to target file which has Finalized Policies associated to Property states on file.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creates First Order with Buyer and Seller which is HUD";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(@"HUDFLINSR1");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(@"HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount.FASetText(@"5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText(@"5000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"ALAMEDA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText(@"92707");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(@"247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText(@"HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem(@"EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering File Fees with HUD Form for the First Order";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "22.22");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Captures the first file number which is HUD";
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Creates Second Order with Buyer and Seller which is Legacy";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(@"HUDFLINSR1");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(@"HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount.FASetText(@"5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText(@"5000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"ALAMEDA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText(@"92707");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(@"247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText(@"HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem(@"EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering File Fees with Legacy Form for the Second Order";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.HUD.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "Escrow Fee", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "Escrow Fee", "Buyer Charge", TableAction.SetText, "5.44");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "Escrow Fee", "Seller Charge", TableAction.SetText, "5.44");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Captures the second file number";
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Copying the Makethebuyersas the sellers data group from HUD to Legacy";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);

                Reports.TestStep = "Validating on Buyers screen for 1st file";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Name", "Buyer1Firstname Buyer1Lastname", "Name", TableAction.Click);

                Reports.TestStep = "Entering the First file number in the File Number text box which is on the File Home page.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum1);

                Reports.TestStep = "Copying the Make the buyers as the sellers data group from Legacy to HUD";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum2);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);

                Reports.TestStep = "Validating on Sellers screen for the 2nd file ";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Name", "Buyer1Firstname Buyer1Lastname", "Name", TableAction.Click);

                Reports.TestStep = "Entering back the Second file number on the file home page";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum2);

                Reports.TestStep = "FM10957_A prerequisite_Creates a New Loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode(@"247");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM10957_Validates the loan charge entered.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                value = FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Small Loan", value);
                Support.AreEqual(@"300,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().Clean());

                Reports.TestStep = "Adding the Title Reports policy";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad();
                CreateDocument("Title Reports", "Automation Test Title Report", "Automation Test Title Report", multipleDocs: true);

                Reports.TestStep = "Clicks on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Title Reports", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Title report.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
                Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.EffectiveDate.FASetText(@"06-20-2012");
                FastDriver.DocumentInfo.Save.FAClick();

                Reports.TestStep = "Select the Title Reports Policy and Click on Edit for finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Title Reports", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(3000);

                Reports.TestStep = "Finalize Document.";
                try
                {
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(element: FastDriver.DocPrepTextEditorDlg.Note);
                    FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized" + FAKeys.Tab);
                }
                catch (Exception)
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Title Reports", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                    FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Playback.Wait(3000);
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(element: FastDriver.DocPrepTextEditorDlg.Note);
                    FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized" + FAKeys.Tab);
                }

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Adding Owner policy and Finalize - Clicking on Add button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                CreateDocument("Owner Policy", "ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", "ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", multipleDocs: true);

                Reports.TestStep = "Selects the Owner Policy and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Owner Policy.";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Support.AreEqual(@"ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Selects the Owner Policy for finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(3000);
                value = FastDriver.WebDriver.HandleDialogMessage();
                if (value.Contains("Policy Number/Guarantee Number is required to finalize the document"))
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Info.FAClick();
                    FastDriver.DocumentInfo.WaitForScreenToLoad();
                    Support.AreEqual(@"ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                    if (FastDriver.DocumentInfo.AutoNumber.Exists())
                    {
                        if (!FastDriver.DocumentInfo.AutoNumber.Selected)
                            FastDriver.DocumentInfo.AutoNumber.FASetCheckbox(true);
                        if (FastDriver.DocumentInfo.AssignNum.Enabled)
                            FastDriver.DocumentInfo.AssignNum.FAClick();
                        Playback.Wait(2000);
                        FastDriver.DocumentInfo.WaitForScreenToLoad();
                    }
                    if (FastDriver.DocumentInfo.PolicyNum.Exists())
                        FastDriver.DocumentInfo.PolicyNum.FASetText(@"2135");
                    FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                    FastDriver.BottomFrame.Done();
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Playback.Wait(5000);
                    FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                    FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Playback.Wait(3000);
                }

                Reports.TestStep = "Finalize Document.";
                try
                {
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(element: FastDriver.DocPrepTextEditorDlg.Note);
                    FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized" + FAKeys.Tab);
                }
                catch (Exception)
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Playback.Wait(5000);
                    FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Playback.Wait(3000);
                    value = FastDriver.WebDriver.HandleDialogMessage();
                    if (value.Contains("Policy Number/Guarantee Number is required to finalize the document"))
                    {
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                        FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                        FastDriver.DocumentRepository.Info.FAClick();
                        FastDriver.DocumentInfo.WaitForScreenToLoad();
                        Support.AreEqual(@"ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                        if (FastDriver.DocumentInfo.AutoNumber.Exists())
                        {
                            if (!FastDriver.DocumentInfo.AutoNumber.Selected)
                                FastDriver.DocumentInfo.AutoNumber.FASetCheckbox(true);
                            if (FastDriver.DocumentInfo.AssignNum.Enabled)
                                FastDriver.DocumentInfo.AssignNum.FAClick();
                            Playback.Wait(2000);
                            FastDriver.DocumentInfo.WaitForScreenToLoad();
                        }
                        if (FastDriver.DocumentInfo.PolicyNum.Exists())
                            FastDriver.DocumentInfo.PolicyNum.FASetText(@"2135");
                        FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                        FastDriver.BottomFrame.Done();
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                        FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                        FastDriver.DocumentRepository.Edit.FAClick();
                        Playback.Wait(5000);
                        FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                        FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                        Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("%o");
                        Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("z");
                        Playback.Wait(3000);
                        FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(element: FastDriver.DocPrepTextEditorDlg.Note);
                        FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized" + FAKeys.Tab);
                    }
                }

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "FM10957_Add the Lender Policy Document to Document Repository screen.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                CreateDocument("Lender Policy", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", multipleDocs: true);

                Reports.TestStep = "Select the Lender Policy and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Lender Policy.";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Support.AreEqual(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(@"06-20-2012");
                FastDriver.DocumentInfo.LenderCheckBox.FASetCheckbox(true);
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Verify Document Information for Lender Policy.";
                FastDriver.DocumentInfo.WaitForScreenToLoad();
                Support.AreEqual(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FAGetValue().Clean());

                Reports.TestStep = "Select the Lender Policy and Click on Edit for finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(3000);
                value = FastDriver.WebDriver.HandleDialogMessage(timeout: 20);
                if(value.Contains("Policy Number/Guarantee Number is required"))
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Info.FAClick();
                    FastDriver.DocumentInfo.WaitForScreenToLoad();
                    if (FastDriver.DocumentInfo.AutoNumber.Exists())
                    {
                        if (!FastDriver.DocumentInfo.AutoNumber.Selected)
                            FastDriver.DocumentInfo.AutoNumber.FASetCheckbox(true);
                        if (FastDriver.DocumentInfo.AssignNum.Enabled)
                            FastDriver.DocumentInfo.AssignNum.FAClick();
                        Playback.Wait(2000);
                        FastDriver.DocumentInfo.WaitForScreenToLoad();
                    }
                    if (FastDriver.DocumentInfo.PolicyNum.Exists() && FastDriver.DocumentInfo.PolicyNum.Displayed)
                        FastDriver.DocumentInfo.PolicyNum.FASetText(@"2135");
                    FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                    FastDriver.DocumentInfo.WaitForScreenToLoad();
                    FastDriver.BottomFrame.Done();
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Playback.Wait(5000);
                    FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Playback.Wait(3000);
                }

                Reports.TestStep = "Finalize Document.";
                try
                {
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(element: FastDriver.DocPrepTextEditorDlg.Note);
                    FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized" + FAKeys.Tab);
                }
                catch (Exception)
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Playback.Wait(5000);
                    FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                    FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Playback.Wait(3000);
                    value = FastDriver.WebDriver.HandleDialogMessage();
                    if(value.Contains("Policy Number/Guarantee"))
                    {
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                        FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                        FastDriver.DocumentRepository.Info.FAClick();
                        FastDriver.DocumentInfo.WaitForScreenToLoad();
                        if (FastDriver.DocumentInfo.AutoNumber.Exists())
                        {
                            if (!FastDriver.DocumentInfo.AutoNumber.Selected)
                                FastDriver.DocumentInfo.AutoNumber.FASetCheckbox(true);
                            if (FastDriver.DocumentInfo.AssignNum.Enabled)
                                FastDriver.DocumentInfo.AssignNum.FAClick();
                            Playback.Wait(2000);
                            FastDriver.DocumentInfo.WaitForScreenToLoad();
                        }
                        if (FastDriver.DocumentInfo.PolicyNum.Exists() && FastDriver.DocumentInfo.PolicyNum.Displayed)
                            FastDriver.DocumentInfo.PolicyNum.FASetText(@"2135");
                        FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                        FastDriver.DocumentInfo.WaitForScreenToLoad();
                        FastDriver.BottomFrame.Done();
                        FastDriver.WebDriver.WaitForActionToComplete(() =>
                        {
                            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                            FastDriver.DocumentRepository.Edit.FAClick();
                            Playback.Wait(5000);
                            FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                            FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                            Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                            Keyboard.SendKeys("%o");
                            Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                            Keyboard.SendKeys("z");
                            Playback.Wait(3000);
                            try
                            {
                                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                                return true;
                            }
                            catch (Exception)
                            {
                                return false;
                            }
                        }, timeout: 400, idleInterval: 10);
                    }
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(element: FastDriver.DocPrepTextEditorDlg.Note);
                    FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized" + FAKeys.Tab);
                }
                
                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "FM10957_Copy Property Address/Legal/Tax Information from a source file to target file which has Finalized Policies associated to Property states on file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(false);

                Reports.TestStep = "Selecting all File Items, copying information from a source file to target file which has Finalized Policies.";
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);

                Reports.TestStep = "Validating Workpane Specific Buttons / Icons (Starter Reference Screen)";
                Support.AreEqual(@"True", FastDriver.StarterReference.FindNow.Displayed.ToString(), "Verify whether 'FindNow' button is displayed.");
                Support.AreEqual(@"True", FastDriver.StarterReference.FileSearch.Displayed.ToString(), "Verify whether 'FileSearch' button is displayed.");
                Support.AreEqual(@"True", FastDriver.StarterReference.CopyNow.Displayed.ToString(), "Verify whether 'CopyNow' button is displayed.");

                Reports.TestStep = "Field Definitions In Tab Order (Starter Reference Screen)";
                Support.AreEqual(@"True", FastDriver.StarterReference.StarterFileNumber.Enabled.ToString(), "Verify whether 'StarterFileNumber' is enabled.");
                FastDriver.StarterReference.StarterFileNumber.FASetText(@"");
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.StarterReference.FindNow.Enabled.ToString(), "Verify whether 'FindNow' button is enabled.");
                Support.AreEqual(@"True", FastDriver.StarterReference.FileSearch.Enabled.ToString(), "Verify whether 'FileSearch' button is enabled.");
                Support.AreEqual(@"True", FastDriver.StarterReference.CopyNow.Enabled.ToString(), "Verify whether 'CopyNow' button is enabled.");
                FastDriver.StarterReference.StarterFileNumber.FASetText(@"@@@@@@@@@@@@");
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(@"welcome&@");
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(@"aaaaaaazzz");
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                Support.AreEqual(@"False", FastDriver.StarterReference.SelectFileItems.Selected.ToString(), "Verify whether 'SelectFileItems' element is unchecked");
                Support.AreEqual(@"True", FastDriver.StarterReference.AllFileItems.Selected.ToString(), "Verify whether 'AllFileItems' element is checked");
                Support.AreEqual(@"True", FastDriver.StarterReference.CopyDocument.Enabled.ToString(), "Verify whether 'CopyDocument' element is enabled.");
                Support.AreEqual(@"False", FastDriver.StarterReference.CopyDocument.Selected.ToString(), "Verify whether 'CopyDocument' element is unchecked");

                Reports.TestStep = "Validating Framework Specific Buttons / Icons on the - Copy Documents Screen. Framework Specific Buttons / Icons (Copy Documents Screen)";
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);

                Reports.TestStep = "User tries to copy “Settlement Information” from HUD File to Legacy file.";
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Entering the First file number in the File Number text box which is on the File Home page.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum1);

                Reports.TestStep = "User tries to copy “Settlement Information” from Legacy File (2nd file) to HUD file (1st file).";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum2);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(false);

                Reports.TestStep = "Changing the file from Legacy to HUD - To start the scenario 'Starter File Status' ";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum2);
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "Escrow Fee", "Sel", TableAction.Click);
                if (FastDriver.FileFees.CD.Selected)
                    FastDriver.FileFees.HUD.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Title Reports Policy and Click on Edit to de-finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Title Reports", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(3000);

                Reports.TestStep = "De-Finalize Title Reports Policy.";
                try
                {
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(windowName: "Unfinalize Document", element: FastDriver.DocPrepTextEditorDlg.Note);
                }
                catch (Exception)
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Title Reports", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Playback.Wait(5000);
                    FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                    FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Playback.Wait(3000);
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(element: FastDriver.DocPrepTextEditorDlg.Note);
                }
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "De-Finalizing Owners Policy.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(3000);
                try
                {
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(windowName: "Unfinalize Document", element: FastDriver.DocPrepTextEditorDlg.Note);
                }
                catch (Exception)
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Playback.Wait(5000);
                    FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
                    FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Playback.Wait(3000);
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad(windowName: "Unfinalize Document", element: FastDriver.DocPrepTextEditorDlg.Note);
                }
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering the first file number on the Top Frame";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum1);

                Reports.TestStep = "Changing the file status as Cancelled";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToString("MM/dd/yyyy").ToString());
                FastDriver.TermsDatesStatus.Status.FASelectItem(@"Cancelled");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Entering the Second file number in the File Number text box on the Top Frame";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum2);

                Reports.TestStep = "Entering the First file number in the File Number text box on the Starter/Ref page";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);

                Reports.TestStep = "Changing the Second file status as Closed";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.Status.FASelectItem(@"Closed");
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.AddDays(1).ToDateString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering the First file number on the Starter/Ref page for Closed Target file scenario";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0054()
        {
            try
            {
                Reports.TestDescription = "BR : FM6830 - Service Type in Starter and Target Files";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creates First Order with Buyer and Seller which is HUD";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile();

                Reports.TestStep = "Captures the first file number";
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Clicks on the ChangeOO button";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Changes the 1st File's service type as Escrow";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.FileHomepage.Title.Selected.ToString(), "Verify whether 'Title' checkbox is unchecked");

                Reports.TestStep = "Creates Second Order with Buyer and Seller.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile();

                Reports.TestStep = "Captures the Second file number";
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Clicks on the ChangeOO button";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Changes the 2nd File's service type as Title";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.FileHomepage.Escrow.Selected.ToString(), "Verify whether 'Escrow' checkbox is unchecked");

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\GeneralForm.doc")]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void FMUC0003_REG0055_56_57()
        {
            try
            {
                Reports.TestDescription = "FM734_FM9852_FM13175_FM6839_FM9853_FM6840 : Copy 'All File Items', Exclude from Copy 'All File Items', Restrict Copy of Secured Images, Restrict Copy of Removed Documents and Images, Document Status in the Target File";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                int count = 0;
                #endregion

                #region UI Interaction
                Reports.TestStep = "Log into Fast ADM application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Processsing Region Setup";
                FastDriver.LeftNavigation.Navigate<ProcessingRegionSetup>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST").WaitForScreenToLoad();

                Reports.TestStep = "Check Upload Word or Excel checkbox.";
                FastDriver.ProcessingRegionSetup.UploadWordExcel.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProcessingRegionSetup.UploadWordExcel.IsSelected(), "Validating upload excer or word checkbox is selected");
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                SetDisplayPDFinBrowser_ON();

                Reports.TestStep = "Creates HUD - First Order with Buyer and Seller";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile();

                Reports.TestStep = "Captures the First file number";
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigating to Document Repo page and clicking on Upload the SEC-Settlement";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse image.";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad(FastDriver.UploadDocumentDlg.DocumentFile);
                value = Reports.DEPLOYDIR + "\\LoadTestImage 513k.tif";
                //value = @"C:\TFS2\FASTSelenium_MainINT\DocPrep\bin\Debug\Common\Support\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(value);

                Reports.TestStep = "Uploading image.";
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                Reports.TestStep = "Saves the Image.";
                FastDriver.SaveDocument.WaitForScreenToLoad();
                FastDriver.SaveDocument.DocumentType.FASelectItem(@"Exchange : Secured");
                FastDriver.SaveDocument.DocumentName.FASelectItem(@"SEC-Settlement");
                FastDriver.SaveDocument.AdditionalInfo.FASetText(@"Secured Image" + FAKeys.Tab);
                FastDriver.SaveDocument.OK.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                Playback.Wait(5000);//we need to explicity wait for the system to refresh upload process

                Reports.TestStep = "Validating the attached security image.";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                    if (FastDriver.DocumentRepository.DocumentsTable.Exists())
                        return FastDriver.DocumentRepository.DocumentsTable.Text.Contains("Secured Image");
                    else
                        return false;
                }, timeout: 60, idleInterval: 10);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "SEC-Settlement Secured Image", 4, TableAction.Click);

                Reports.TestStep = "Adding 2nd product - Abstract";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.AddRemoveProducts.FAClick();
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductSelectionDlg.Checkbox1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigating to Document Repo page and clicking on Upload for INST-GFE";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse Document.";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                value = Reports.DEPLOYDIR + "\\GeneralForm.doc";
                //value = @"C:\TFS2\FASTSelenium_MainINT\DocPrep\bin\Debug\Common\Support\GeneralForm.doc";
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(value);

                Reports.TestStep = "Uploading Document.";
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                Reports.TestStep = "Saves the Document.";
                FastDriver.SaveDocument.WaitForScreenToLoad();
                FastDriver.SaveDocument.DocumentType.FASelectItem(@"Escrow: Misc");
                FastDriver.SaveDocument.DocumentName.FASelectItem(@"INST-GFE");
                FastDriver.SaveDocument.OK.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                Playback.Wait(5000);//we need to explicity wait for the system to refresh upload process

                Reports.TestStep = "Validating the attached Misc doc.";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    return FastDriver.DocumentRepository.DocumentsTable.Text.Contains("INST-GFE");
                });
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "INST-GFE", 4, TableAction.Click);

                Reports.TestStep = "Creates 2nd order without Buyer and Seller";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Default-Residential");
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(!AutoConfig.UseCDFormType);
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Multi Family Residence");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"BUTTE");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Captures the Second file number";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Creates a New Loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode(@"247");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validates the loan charge entered.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                value = FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Small Loan", value);
                Support.AreEqual(@"300,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().Clean());

                Reports.TestStep = "Navigates to Starter ref screen & selecting Copy Doc";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

                Reports.TestStep = "Copy documents.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

                Reports.TestStep = "Clicks on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Validating the Products on the file home page in Target file";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProductsTable.PerformTableAction("Product Name", "Abstract", "Product Name", TableAction.Click);
                Support.AreEqual(@"Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().Clean());
                Support.AreEqual(@"(711)111-1111", FastDriver.FileHomepage.DirectedByBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"(744)444-4444", FastDriver.FileHomepage.DirectedByCellPhone.FAGetValue().Clean());

                Reports.TestStep = "Validating Loan details";
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesNewLoanAmnt.FAGetValue().Clean());
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesNewLoanLiability.FAGetValue().Clean());

                Reports.TestStep = "Validating Associated Business Party details";
                Support.AreEqual(@"HUDASLNDR1", FastDriver.FileHomepage.AssociateBusinessPartyIDcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"Assumption Lender 1 for HUD Test Name 1", FastDriver.FileHomepage.AssociateBusinessPartyNameLabel.FAGetText().Clean());
                Support.AreEqual(@"(196)846-8464", FastDriver.FileHomepage.AssociateBusinessPartyBusPhone.FAGetValue().Clean());

                Reports.TestStep = "Navigating to Document Repo page and clicking on Upload the SEC-Settlement";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(@"Active", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Escrow: Misc", 9, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validating that the secured image should not be copied";
                try
                {
                    if (FastDriver.DocumentRepository.SecuredImage.Exists())
                        Reports.StatusUpdate("The secured image SEC-Settlement Secured Image was copied into Target file", false);
                    else
                        Reports.StatusUpdate("The secured image SEC-Settlement Secured Image was not copied into Target file", true);
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("The secured image SEC-Settlement Secured Image was not copied into Target file", true);
                }

                Reports.TestStep = "Validating that the Search Results file should be copied";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    try
                    {
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                        return FastDriver.DocumentRepository.SearchResult.Exists();
                    }
                    catch
                    {
                        return false;
                    }

                }, timeout: 500, idleInterval: 20);

                //try
                //{
                //    if (FastDriver.DocumentRepository.SearchResult.Exists())
                //        Reports.StatusUpdate("The Search Results file was copied into Target file", true);
                //    else
                //        Reports.StatusUpdate("The Search Results file was not copied into Target file", false);
                //}
                //catch (Exception)
                //{
                //    Reports.StatusUpdate("The Search Results file was not copied into Target file", false);
                //}

                #region FMUC0003_REG0056

                Reports.TestStep = "Entering the first file number on the File home page";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum1);

                Reports.TestStep = "Navigating to Document Repo page and clicking on Upload";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse image.";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                value = Reports.DEPLOYDIR + "\\LoadTestImage 513k.tif";
                //value = @"C:\TFS2\FASTSelenium_MainINT\DocPrep\bin\Debug\Common\Support\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(value);

                Reports.TestStep = "Uploading image.";
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                Reports.TestStep = "Saves the Image.";
                FastDriver.SaveDocumentDlg.SaveDocument("Title: Search Package", "SP-Prior", "");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(5000);//we need to explicity wait for the system to refresh upload process

                Reports.TestStep = "Removing the SP-Prior Document";
                while (true)
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    if (FastDriver.DocumentRepository.SP_Prior.Exists())
                        break;
                }
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "SP-Prior", 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Upload for Final Closing Instructions DOC";
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.Upload);
                FastDriver.DocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse Final Closing Instructions Document.";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(Reports.DEPLOYDIR + "\\GeneralForm.doc");
                //FastDriver.UploadDocumentDlg.DocumentFile.FASetText(@"C:\TFS2\FASTSelenium_MainINT\DocPrep\bin\Debug\Common\Support\GeneralForm.doc");

                Reports.TestStep = "Uploading Document Final Closing Instructions Document";
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                Reports.TestStep = "Saves the Final Closing Instructions Document.";
                FastDriver.SaveDocumentDlg.SaveDocument("Escrow: Signed Instructions", "Final Closing Instructions", "");
                Playback.Wait(5000);//we need to explicity wait for the system to refresh upload process

                Reports.TestStep = "Validating the attached Final Closing Instructions doc";
                while (true)
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    if (FastDriver.DocumentRepository.FinalClosingInstructions.Exists())
                        break;
                }
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Escrow: Signed Instruc...", 6, TableAction.Click);
                if (FastDriver.DocumentRepository.FinalClosingInstructions.Exists())
                    Reports.StatusUpdate("The Final Closing Instructions was uploaded", true);
                else
                    Reports.StatusUpdate("The Final Closing Instructions was not uploaded", false);

                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.ClickWorkQTab();
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(clickRetain: true);

                Reports.TestStep = "Select Queue.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"ManualUpload");
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(clickRetain: true);
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                int UnpdCount = int.Parse(FastDriver.WorkQueueTop.UnpdCount.FAGetText().Clean());

                Reports.TestStep = "Click on Upload.";
                value = FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"ManualUpload", value);
                FastDriver.WorkQueueTop.Upload.FAClick();

                Reports.TestStep = "Upload Doc To Work Queue.";
                FastDriver.UploadFileToQueueDlg.WaitForScreenToLoad();
                FastDriver.UploadFileToQueueDlg.imageFilePath.FASetText(Reports.DEPLOYDIR + @"\EMAIL_Offshore_Pdf.pdf");
                //FastDriver.UploadFileToQueueDlg.imageFilePath.FASetText(@"C:\TFS2\FASTSelenium_MainINT\DocPrep\bin\Debug\Common\Support\EMAIL_Offshore_Pdf.pdf");
                FastDriver.UploadFileToQueueDlg.Upload.FAClick();

                Reports.TestStep = "Click on WorkN link.";
                FastDriver.TopFrame.ClickWorkNTab();
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(clickRetain: true);

                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.ClickWorkQTab();
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(clickRetain: true);

                Reports.TestStep = "Verify Value on Work Queue Screen.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                int UnpdCount2 = int.Parse(FastDriver.WorkQueueTop.UnpdCount.FAGetText().Clean());
                Support.AreEqual((UnpdCount + 1).ToString(), UnpdCount2.ToString(), "Upload is not successful. The Count is not matching.");

                Reports.TestStep = "Click on Attach.";
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"ManualUpload");
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(clickRetain: true);
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.Attach.FAClick();

                Reports.TestStep = "Attach the file to workqueue.";
                FastDriver.AttachMessageDlg.WaitForScreenToLoad();
                FastDriver.AttachMessageDlg.Region.FASelectItem(@"QA Automation Region - DO NOT TOUCH");
                FastDriver.AttachMessageDlg.FileNo.FASetText(FileNum1);
                FastDriver.AttachMessageDlg.DocumentType.FASelectItem(@"Escrow: Closing Statements");
                FastDriver.AttachMessageDlg.DocumentName.FASelectItem(@"Miscellaneous");
                FastDriver.AttachMessageDlg.WQTriggerNames.FASelectItem(@"ATTY SCANNED");
                FastDriver.AttachMessageDlg.PageNumbersRange.FASetText(@"1");
                FastDriver.AttachMessageDlg.Comments.FASetText(@"Comments for Attachment.");
                FastDriver.AttachMessageDlg.Done.FAClick();

                Reports.TestStep = "Click on Ok Button.";
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("out of range"))
                {
                    FastDriver.AttachMessageDlg.WaitForScreenToLoad();
                    FastDriver.AttachMessageDlg.PageNumbersRange.FASetText(@"0");
                    FastDriver.AttachMessageDlg.Done.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                
                Reports.TestStep = "Click on WorkN link.";
                FastDriver.TopFrame.ClickWorkNTab();

                Reports.TestStep = "Navigate to Doc rep.";
                FastDriver.WebDriver.WaitForActionToComplete(() => 
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    return FastDriver.DocumentRepository.DocumentsTable.Text.Contains("Escrow: Closing Statem...");
                }, timeout: 120, idleInterval: 10);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Escrow: Closing Statem...", 6, TableAction.Click);

                Reports.TestStep = "Entering the Second file number on the File home page";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum2);

                Reports.TestStep = "Copy Docs from source file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.DocListTable.PerformTableAction("Name", "Miscellaneous", "Sel", TableAction.On);
                FastDriver.CopyDocuments.DocListTable.PerformTableAction("Name", "Final Closing Instructions", "Sel", TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verification on the Miscellaneous (WQ) attachment on the Document Repo screen";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                try
                {
                    if (FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(p => p.Text == "Escrow: Closing Statem...").Exists())
                        Reports.StatusUpdate("The WQ attachment copied into Target file", true);
                    else
                        Reports.StatusUpdate("The WQ attachment was not copied into Target file", false);
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("The WQ attachment was not copied into Target file", false);
                }

                Reports.TestStep = "Validating that the deleted SP-Prior document was not copied into Target file";
                try
                {
                    if (!FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(p => p.Text == "SP-Prior").Exists())
                        Reports.StatusUpdate("SP-Prior Document was copied", false);
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("SP-Prior Document was not copied", true);
                }

                Reports.TestStep = "Validating that the Final Closing Instructions was copied into Target file with Active status";
                Support.AreEqual(@"Active", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Final Closing Instructions", 9, TableAction.GetText).Message.Clean());

                // Display of Image Documents
                Reports.TestStep = "Validating that the sequence of documents order was copied from source to target.";
                FastDriver.DocumentRepository.validateSequenceOfDocuments();

                #endregion

                #region FMUC0003_REG0057

                Reports.TestStep = "FM4787_Validations of  ID Code,Name,Address,Contact info (phone, fax, email, etc, Attention),Reference,Additional Role,Sales Rep.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"HUDASLNDR1", FastDriver.FileHomepage.AssociateBusinessPartyIDcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"Assumption Lender 1 for HUD Test Name 1", FastDriver.FileHomepage.AssociateBusinessPartyNameLabel.FAGetText().Clean());
                Support.AreEqual(@"Payoff Lender 3 business street 1, Payoff Lender 3 business street 2", FastDriver.FileHomepage.AssociateBusinessPartyAddressLabel.FAGetText().Clean());
                Support.AreEqual(@"(196)846-8464", FastDriver.FileHomepage.AssociateBusinessPartyBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"(478)161-6105", FastDriver.FileHomepage.AssociateBusinessPartyBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(741)646-5411", FastDriver.FileHomepage.AssociateBusinessPartyCellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(197)841-6416", FastDriver.FileHomepage.AssociateBusinessPartyPager.FAGetValue().Clean());
                if (FastDriver.FileHomepage.AssociateBusinessPartyEmailAddress.FAGetValue().Clean().Contains("kdvpgqgzuu"))
                {
                    Support.AreEqual(@"kdvpgqgzuu@Lender.com", FastDriver.FileHomepage.AssociateBusinessPartyEmailAddress.FAGetValue().Clean());//original dsubwsbkjw@Lender.com
                }
                if(FastDriver.FileHomepage.AssociateBusinessPartyAttention.FAGetSelectedItem() == "Contact, Assumption Lender 1")
                {
                    Support.AreEqual(@"Contact, Assumption Lender 1", FastDriver.FileHomepage.AssociateBusinessPartyAttention.FAGetSelectedItem().Clean());
                }
                if(FastDriver.FileHomepage.AssociateBusinessPartySalesRep1.FAGetSelectedItem() == "Jeella, Venkateswara Rao")
                {
                    Support.AreEqual(@"Jeella, Venkateswara Rao", FastDriver.FileHomepage.AssociateBusinessPartySalesRep1.FAGetSelectedItem().Clean());
                }
                if(FastDriver.FileHomepage.AssociateBusinessPartySalesRep2.FAGetSelectedItem() == "Jeella, Venkateswara Rao")
                {
                    Support.AreEqual(@"Jeella, Venkateswara Rao", FastDriver.FileHomepage.AssociateBusinessPartySalesRep2.FAGetSelectedItem().Clean());

                }
                value = FastDriver.FileHomepage.AssociateBusinessPartyReference.FAGetValue().Clean();
                if (value.Length > 2)
                    Support.AreEqual("True", value.Contains("to be retrieved from the application").ToString(), "Verify whether 'AssociateBusinessPartyReference' contains text: 'to be retrieved from the application'.");
                value = FastDriver.FileHomepage.AssociateBusinessPartyAddtionalRole.FAGetValue().Clean();
                if (value.Length > 2)
                    Support.AreEqual("True", value.Contains("to be retrieved from the application").ToString(), "Verify whether 'AssociateBusinessPartyAddtionalRole' contains text: 'to be retrieved from the application'.");

                Reports.TestStep = "Entering first file number to modify values.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum1);

                Reports.TestStep = "FM6848_Modify the Properties/Tax Info page";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();

                Reports.TestStep = "FM6848_Validations of  Property Tax Info General screen";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.PropertyTaxInfoGeneral.SeqNo.FAGetText().Clean());
                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().Clean());
                Support.AreEqual("Condominium", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetSelectedItem().Clean());
                try
                {
                    if (FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(p => p.Text == "J305 JJEJAMQ JJEJAMQ").Exists())
                        Reports.StatusUpdate("The record with value - J305 J305 JJEJAMQ - was found", true);
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("The record with value - J305 J305 JJEJAMQ - was not found", false);
                }
                Support.AreEqual(@"ALBANY", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Clean());
                Support.AreEqual(@"CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Clean());
                Support.AreEqual(@"ALAMEDA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Clean());
                Support.AreEqual(@"USA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCountry.FAGetSelectedItem().Clean());
                FastDriver.PropertyTaxInfoGeneral.GeneralComments.FASetText(@"General Comments");

                Reports.TestStep = "FM6848 - Clicking on Legal Desc. tab to enter the Legal Info.";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "FM6848_Entering data on the LegalDescriptiontab.";
                Support.AreEqual("1", FastDriver.PropertyTaxInfoLegalDesciption.LegalSeqNo.FAGetText().Clean());
                Support.AreEqual("J305", FastDriver.PropertyTaxInfoLegalDesciption.Name.FAGetValue().Clean());
                Support.AreEqual("Condominium", FastDriver.PropertyTaxInfoLegalDesciption.PropertyType.FAGetSelectedItem().Clean());
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText(@"LotOne");
                FastDriver.PropertyTaxInfoLegalDesciption.Block.FASetText(@"BlockOne");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText(@"UnitOne");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText(@"TractOne");
                FastDriver.PropertyTaxInfoLegalDesciption.Fee.FASetText(@"1000");
                FastDriver.PropertyTaxInfoLegalDesciption.Building.FASetText(@"B1");
                FastDriver.PropertyTaxInfoLegalDesciption.Book.FASetText(@"Book1");
                FastDriver.PropertyTaxInfoLegalDesciption.Page.FASetText(@"PageOne");
                FastDriver.PropertyTaxInfoLegalDesciption.Section.FASetText(@"124");
                FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FASetText(@"New Township");
                FastDriver.PropertyTaxInfoLegalDesciption.Range.FASetText(@"Range 1");
                FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FASetText(@"Parcel One");
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASetText(@"A-34");
                FastDriver.PropertyTaxInfoLegalDesciption.Phase.FASetText(@"Phase One");
                FastDriver.PropertyTaxInfoLegalDesciption.GovtLotNo.FASetText(@"GovtLot1");
                FastDriver.PropertyTaxInfoLegalDesciption.Borough.FASetText(@"Borough One");
                FastDriver.PropertyTaxInfoLegalDesciption.Province.FASetText(@"New Province");
                FastDriver.PropertyTaxInfoLegalDesciption.CountyParish.FASetText(@"CA");
                FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FASelectItem(@"Fee Simple");
                FastDriver.PropertyTaxInfoLegalDesciption.RecordingBook.FASetText(@"RecordBook1");
                FastDriver.PropertyTaxInfoLegalDesciption.RecordingPage.FASetText(@"RecordingP");
                FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapNo.FASetText(@"RecordingMap1");
                FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapDate.FASetText(DateTime.Today.AddDays(1).ToDateString());
                FastDriver.PropertyTaxInfoLegalDesciption.AbbreviatedLegalDescriptionCountyPhrase.FASelectItemByIndex(1);
                FastDriver.PropertyTaxInfoLegalDesciption.CompleteLegalDescriptionComments.FASetText(@"Abbreviated and Complete legal Description.");
                var countyPhrase = FastDriver.PropertyTaxInfoLegalDesciption.AbbreviatedLegalDescriptionCountyPhrase.FAGetSelectedItem();
                FastDriver.PropertyTaxInfoLegalDesciption.AbbrLegalDesciptionAttachedLegalReference.FASetCheckbox(true);

                Reports.TestStep = "FM6848_Clicking on the Tax tab and entering data.";
                FastDriver.PropertyTaxInfoLegalDesciption.ClickTaxTab().WaitForScreenToLoad();

                Reports.TestStep = "Clicking on the row on the Tax tab.";
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(p => p.Text == "Prop1APN1").Click();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                Support.AreEqual(@"Prop1APN1", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FAGetValue().Clean());
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText(@"2015");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.FASetText(@"19768");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo1.FASetText(@"55");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus1.FASelectItem(@"ARREARS");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate1.FASetText(DateTime.Today.AddDays(1).ToDateString());
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASetText(@"100");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInterest1.FASetText(@"50");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPenality1.FASetText(@"50");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxpartialPaymentAmount1.FASetText(@"40");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxAssesmentDate1.FASetText(DateTime.Today.AddDays(1).ToDateString());
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue1.FASetText(@"1000");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue1.FASetText(@"100");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue1.FASetText(@"100");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner1.FASetText(@"100");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther11.FASetText(@"100");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.FASetText(@"100");
                FastDriver.PropertyTaxInfoAnnualTax.GenerateTaxCheck.FASetCheckbox(true);

                Reports.TestStep = "Clicking on Supplemental tab which is under Tax main tab to enter data";
                FastDriver.PropertyTaxInfoAnnualTax.SupplementalTaxTab.FAClick();
                FastDriver.PropertyTaxInfoSupplementalTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxSuppleNo.FASetText(@"2215");
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxMiscNo.FASetText(@"2213");
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxVolume1.FASetText(@"87");
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxStatus1.FASelectItem(@"ARREARS");
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxDueDate1.FASetText(DateTime.Today.AddDays(3).ToDateString());
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxInstallmentAmount1.FASetText(@"1000");
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxInterest1.FASetText(@"50");
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxPenality1.FASetText(@"50");
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxpartialPaymentAmount1.FASetText(@"100");
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxDelinquentDate1.FASetText(DateTime.Today.AddDays(3).ToDateString());
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxPaymentGoodThroughDate1.FASetText(DateTime.Today.AddDays(3).ToDateString());
                FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxCertificateOfPurchase1.FASetText(DateTime.Today.AddDays(2).ToDateString());
                FastDriver.PropertyTaxInfoSupplementalTax.GenerateTaxCheck.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering the Second file number in the File Number text box which is on the File Home page.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum2);

                Reports.TestStep = "Copying Source file data.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "FM6848_Validations starts...Clicking on Edit button";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();

                Reports.TestStep = "FM6848_Validations on General Info tab";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual(@"General Comments", FastDriver.PropertyTaxInfoGeneral.GeneralComments.FAGetValue().Clean());
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Support.AreEqual(@"1", FastDriver.PropertyTaxInfoLegalDesciption.LegalSeqNo.FAGetText().Clean());
                Support.AreEqual(@"J305", FastDriver.PropertyTaxInfoLegalDesciption.Name.FAGetValue().Clean());
                Support.AreEqual(@"Condominium", FastDriver.PropertyTaxInfoLegalDesciption.PropertyType.FAGetSelectedItem().Clean());
                Support.AreEqual(@"LotOne", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue().Clean());
                Support.AreEqual(@"BlockOne", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue().Clean());
                Support.AreEqual(@"UnitOne", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue().Clean());
                Support.AreEqual(@"TractOne", FastDriver.PropertyTaxInfoLegalDesciption.Tract.FAGetValue().Clean());
                Support.AreEqual(@"1000", FastDriver.PropertyTaxInfoLegalDesciption.Fee.FAGetValue().Clean());
                Support.AreEqual(@"B1", FastDriver.PropertyTaxInfoLegalDesciption.Building.FAGetValue().Clean());
                Support.AreEqual(@"Book1", FastDriver.PropertyTaxInfoLegalDesciption.Book.FAGetValue().Clean());
                Support.AreEqual(@"PageOne", FastDriver.PropertyTaxInfoLegalDesciption.Page.FAGetValue().Clean());
                Support.AreEqual(@"124", FastDriver.PropertyTaxInfoLegalDesciption.Section.FAGetValue().Clean());
                Support.AreEqual(@"New Township", FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FAGetValue().Clean());
                Support.AreEqual(@"Range 1", FastDriver.PropertyTaxInfoLegalDesciption.Range.FAGetValue().Clean());
                Support.AreEqual(@"Parcel One", FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FAGetValue().Clean());
                Support.AreEqual(@"A-34", FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FAGetValue().Clean());
                Support.AreEqual(@"Phase One", FastDriver.PropertyTaxInfoLegalDesciption.Phase.FAGetValue().Clean());
                Support.AreEqual(@"GovtLot1", FastDriver.PropertyTaxInfoLegalDesciption.GovtLotNo.FAGetValue().Clean());
                Support.AreEqual(@"Borough One", FastDriver.PropertyTaxInfoLegalDesciption.Borough.FAGetValue().Clean());
                Support.AreEqual(@"New Province", FastDriver.PropertyTaxInfoLegalDesciption.Province.FAGetValue().Clean());
                Support.AreEqual(@"CA", FastDriver.PropertyTaxInfoLegalDesciption.CountyParish.FAGetValue().Clean());
                Support.AreEqual(@"Fee Simple", FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FAGetSelectedItem().Clean());
                Support.AreEqual(@"RecordBook1", FastDriver.PropertyTaxInfoLegalDesciption.RecordingBook.FAGetValue().Clean());
                Support.AreEqual(@"RecordingP", FastDriver.PropertyTaxInfoLegalDesciption.RecordingPage.FAGetValue().Clean());
                Support.AreEqual(@"RecordingMap1", FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapNo.FAGetValue().Clean());
                Support.AreEqual(DateTime.Today.AddDays(1).ToDateString().ToString(), FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapDate.FAGetValue().Clean());
                Support.AreEqual(countyPhrase, FastDriver.PropertyTaxInfoLegalDesciption.AbbreviatedLegalDescriptionCountyPhrase.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Abbreviated and Complete legal Description.", FastDriver.PropertyTaxInfoLegalDesciption.CompleteLegalDescriptionComments.FAGetValue().Clean());
                Support.AreEqual(@"True", FastDriver.PropertyTaxInfoLegalDesciption.AbbrLegalDesciptionAttachedLegalReference.Selected.ToString(), "Verify whether the 'AbbrLegalDesciptionAttachedLegalReference' checkbox is checked.");

                Reports.TestStep = "FM6848_Validations on Property tab";
                FastDriver.PropertyTaxInfoLegalDesciption.ClickTaxTab().WaitForScreenToLoad();

                Reports.TestStep = "Clicking on the row on the Tax tab.";
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(p => p.Text == "Prop1APN1").Click();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                Support.AreEqual(@"2015", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FAGetValue().Clean());
                Support.AreEqual(@"19768", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.FAGetValue().Clean());
                Support.AreEqual(DateTime.Today.AddDays(1).ToString("MM/dd/yyyy").ToString(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxAssesmentDate1.FAGetValue().Clean());
                Support.AreEqual(@"1,000.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue1.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue1.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue1.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner1.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther11.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.FAGetValue().Clean());

                Reports.TestStep = "FM6848_Clicking on the Supplemental tab for validations";
                FastDriver.PropertyTaxInfoAnnualTax.SupplementalTaxTab.FAClick();
                FastDriver.PropertyTaxInfoSupplementalTax.WaitForScreenToLoad();
                Support.AreEqual(@"2213", FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxMiscNo.FAGetValue().Clean());
                Support.AreEqual(@"87", FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxVolume1.FAGetValue().Clean());
                Support.AreEqual(@"ARREARS", FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxStatus1.FAGetSelectedItem().Clean());
                Support.AreEqual(DateTime.Today.AddDays(3).ToString("MM/dd/yyyy").ToString(), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxDueDate1.FAGetValue().Clean());
                Support.AreEqual(DateTime.Today.AddDays(3).ToString("MM/dd/yyyy").ToString(), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxDelinquentDate1.FAGetValue().Clean());
                Support.AreEqual(DateTime.Today.AddDays(3).ToString("MM/dd/yyyy").ToString(), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxPaymentGoodThroughDate1.FAGetValue().Clean());
                Support.AreEqual(DateTime.Today.AddDays(2).ToDateString().ToString(), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxCertificateOfPurchase1.FAGetValue().Clean());
                SetDisplayPDFinBrowser_OFF();

                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                SetDisplayPDFinBrowser_OFF();
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0056()
        {
            try
            {
                Reports.TestDescription = "BR FM9853_FM13175_FM9848 - Validation for WQ Up load, Removed documents copy functionality, Order of Image Docs.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0055", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0057()
        {
            try
            {
                Reports.TestDescription = "BR : FM4787_FM6848 - File Business Party, Data copied as part of Property Address/Legal/Tax Info group";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0055.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0058()
        {
            try
            {
                Reports.TestDescription = "FM6849_FM6850_FM6851_FM6852_FM6853 - Data copied as part of  Buyer(s)  Data Group, Data copied as part of  Seller(s) Data Group,Data copied as part of Makes the Buyer(s) as the Seller(s) group, Notes group and Settlement Information group.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a detailed File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "BR_FM6849_Entering Buyer details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText(@"MiddleName");
                FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText(@"Mrs");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText(@"298374983");
                FastDriver.BuyerSellerSetup.AKA();

                Reports.TestStep = "BR_FM6849_Clicking on New button on AKA Names page";
                FastDriver.AKANames.WaitForScreenToLoad();
                FastDriver.AKANames.AKANew.FAClick();
                FastDriver.AKANames.AKA.FASetText(@"AKA Name1");
                FastDriver.AKANames.UsedatSigning.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "BR_FM6849_Entering Sellers details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText(@"MiddleName");
                FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText(@"Mrs");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText(@"298374983");
                FastDriver.BuyerSellerSetup.AKA();

                Reports.TestStep = "FM6850-Clicking on New button on AKA Names page";
                FastDriver.AKANames.WaitForScreenToLoad();
                FastDriver.AKANames.AKANew.FAClick();
                FastDriver.AKANames.AKA.FASetText(@"AKA Name1");
                FastDriver.AKANames.UsedatSigning.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6853_Entering the New Home Rate Eagle Owner Fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "1.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a second order.";
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "FM6849_FM6850_FM6851_FM6852_FM6853_Copying Source file data on Starter/Ref page.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);

                Reports.TestStep = "Clicks on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.SellersData.FASetCheckbox(false);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(false);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(false);

                Reports.TestStep = "FM6849_Validations on Buyers screen";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(@"Individual", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem().Clean());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean());
                Support.AreEqual(@"MiddleName", FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean());
                Support.AreEqual(@"Mrs", FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue().Clean());
                FastDriver.BuyerSellerSetup.btnViewEdit.FAClick();
                Support.AreEqual(@"298-37-4983", FastDriver.BuyerSellerSetup.txtSSN.FAGetValue().Clean());

                Reports.TestStep = "FM6849_Validations on AKA screen";
                FastDriver.BuyerSellerSetup.AKA();
                FastDriver.AKANames.WaitForScreenToLoad();
                Support.AreEqual(@"AKA Name1", FastDriver.AKANames.AKA.FAGetValue().Clean());
                Support.AreEqual(@"True", FastDriver.AKANames.UsedatSigning.Selected.ToString(), "Verify whether 'UsedatSigning' checkbox is checked.");
                FastDriver.BottomFrame.Done();
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6849_Validations on Sellers screen";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(@"Individual", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(@"Seller1FirstName", FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean());
                Support.AreEqual(@"MiddleName", FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue().Clean());
                Support.AreEqual(@"Seller1Lastname", FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean());
                Support.AreEqual(@"Mrs", FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue().Clean());
                FastDriver.BuyerSellerSetup.btnViewEdit.FAClick();
                Support.AreEqual(@"298-37-4983", FastDriver.BuyerSellerSetup.txtSSN.FAGetValue().Clean());

                Reports.TestStep = "FM6849_Validations on AKA screen";
                FastDriver.BuyerSellerSetup.AKA();
                FastDriver.AKANames.WaitForScreenToLoad();
                Support.AreEqual(@"AKA Name1", FastDriver.AKANames.AKA.FAGetValue().Clean());
                Support.AreEqual(@"True", FastDriver.AKANames.UsedatSigning.Selected.ToString(), "Verify whether 'UsedatSigning' checkbox is checked.");
                FastDriver.BottomFrame.Done();
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6851_Clears the Sellers data";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "FM6851-Copying Source file data as - Make the Buyer as Seller.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);
                FastDriver.StarterReference.Notes.FASetCheckbox(true);

                Reports.TestStep = "FM6851-Clicks on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "FM6851_Validations on Sellers screen";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(@"Individual", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean());
                Support.AreEqual(@"MiddleName", FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean());
                Support.AreEqual(@"Mrs", FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue().Clean());
                FastDriver.BuyerSellerSetup.ViewEdit();
                Support.AreEqual(@"298-37-4983", FastDriver.BuyerSellerSetup.txtSSN.FAGetValue().Clean());

                Reports.TestStep = "FM6849_Validations on AKA screen";
                FastDriver.BuyerSellerSetup.AKA();
                FastDriver.AKANames.WaitForScreenToLoad();
                Support.AreEqual(@"AKA Name1", FastDriver.AKANames.AKA.FAGetValue().Clean());
                Support.AreEqual(@"True", FastDriver.AKANames.UsedatSigning.Selected.ToString(), "Verify whether 'UsedatSigning' checkbox is checked.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6852_Notes verification";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual(@"Notes Data including - * # Specialcharacter :) !", FastDriver.FileNotes.FileNotesGrid.FAGetText().Clean());
                /*
                 * Business Rules changed on this scenario, we are not copying Settlement Info as per QA.
                Reports.TestStep = "FM6853_Settle Statement verification";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                var v = FastDriver.ViewSettlementStatement.SummaryTable.FAGetText().Clean();
                Support.AreEqual(@"True", FastDriver.ViewSettlementStatement.SummaryTable.FAGetText().Clean().Contains("New Home Rate Eagle Lender Policy-1 to QA Automation Office - DO NOT TOUCH 1.99").ToString(),
                    "Verify whether table 'SummaryTable' contains text: 'New Home Rate Eagle Lender Policy-1 to QA Automation Office - DO NOT TOUCH 1.99'");
                Support.AreEqual(@"False", FastDriver.ViewSettlementStatement.SummaryTable.FAGetText().Clean().Contains("Cash ( To) (X From) Seller  1.99").ToString(),
                    "Verify whether table 'SummaryTable' not contains text: 'Cash ( To) (X From) Seller  1.99'");
                Support.AreEqual(@"False", FastDriver.ViewSettlementStatement.SummaryTable.FAGetText().Clean().Contains("1.991.991.991.99").ToString(),
                    "Verify whether table 'SummaryTable' not contains text: '1.991.991.991.99'");
                */
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0059()
        {
            try
            {
                Reports.TestDescription = "BR : FM6852_FM6853_FM6854_FM6858_FM6860_FM6861_Data copied as part of  Notes Group, Data copied as part of  Settlement Information Group, Add Howeowners Association";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create First Order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var FileNum1 = File.FileNumber;
                //Reports.TestStep = "Entering first file number to modify values.";
                //FastDriver.TopFrame.SearchFileByFileNumber(FileNum1);

                Reports.TestStep = "FM6854_Add a homeowner association instance directly.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode(@"247", WaitForGabCodeLabel: false);
                FastDriver.HomeownerAssociation.AmountDues.FASetText(@"10.00");
                FastDriver.HomeownerAssociation.PerDiem.FASelectItem(@"MONTH");
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", buyerCharge: 4.00, sellerCharge: 2.00);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", buyerCharge: 4.50, sellerCharge: 2.50);
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText(@"10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText(@"07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText(@"08-17-2012");
                FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText(@"1.50");
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText(@"2.50");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6855_Set an instance of Home warranty details.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode(@"HW1");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "FM6855_Enter payment details for HomeWarrantyDetail.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText(@"Sanity-Home Warranty");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"3.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"3.99");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText(@"Sanity-Home Warranty");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"3.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"3.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"3.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"3.99");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Click on payment details.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Validates payment details for HomeWarrantyDetail.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean());

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "FM6858_Create an Lease Instance.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode(@"HUDLEASE02");
                FastDriver.LeaseDetail.LeaseAmount.FASetText(@"100");
                FastDriver.LeaseDetail.Per.FASelectItem(@"Month");
                FastDriver.LeaseDetail.For.FASetText(@"10");
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due", buyerCharge: 11.00, sellerCharge: 12.00, editDescription: "Charge Description");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6860_Set an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode(@"247", WaitForGabCodeLabel: false);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", buyerCharge: 100, sellerCharge: 100);
                FastDriver.SurveyDetail.SurveyDetails.FASetText(@"Test Survey Details 1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText(@"50");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText(@"20");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText(@"20");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6861_Enter Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"HUDUTLCMP1");
                FastDriver.UtilityDetail.PaymentDetails.FAClick();

                Reports.TestStep = "FM6861_Enters Payment details on the dialog box.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText(@"Payment details desc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"1.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"1.99");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem(@"FEE");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem(@"FEE");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"1.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"1.99");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.ProrationAmount.FASetText(@"10");
                FastDriver.UtilityDetail.FromDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.ToDate.FASetText(DateTime.Today.AddDays(4).ToDateString());
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                while (true)
                {
                    Playback.Wait(500);
                    FastDriver.UtilityDetail.ProrationDescription.FireEvent("onfocus");
                    FastDriver.UtilityDetail.ProrationDescription.Click();
                    Playback.Wait(500);
                    Keyboard.SendKeys("");
                    Playback.Wait(500);
                    Keyboard.SendKeys("Proration Description");
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);

                    if (FastDriver.UtilityDetail.ProrationDescription.FAGetValue().Clean() == "Proration Description")
                        break;
                }
                FastDriver.UtilityDetail.ProrationDescription.Click();
                FastDriver.UtilityDetail.ProrationBuyerCharge.FASetText(@"10");
                FastDriver.UtilityDetail.ProrationBuyerCredit.FASetText(@"10");
                FastDriver.UtilityDetail.ProrationSellerCharge.FASetText(@"10");
                FastDriver.UtilityDetail.ProrationSellerCredit.FASetText(@"10");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create second order.";
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var FileNum2 = File.FileNumber;
                //Reports.TestStep = "Entering the Second file number in the File Number text box which is on the File Home page.";
                //FastDriver.TopFrame.SearchFileByFileNumber(FileNum2);

                Reports.TestStep = "Copying Source file data on Starter/Ref page.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Clicks on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "FM6854_Verify homeowner association details";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                Support.AreEqual(@"247", FastDriver.HomeownerAssociation.IDCodeText.FAGetText().Clean());
                Support.AreEqual(@"Lenders Advantage", FastDriver.HomeownerAssociation.HOA_LenderName.FAGetText().Clean());
                Support.AreEqual(@"A Division Of First American Title Ins.", FastDriver.HomeownerAssociation.HOA_LenderName1.FAGetText().Clean());
                Support.AreEqual(@"Check Amount: $ 7.00", FastDriver.HomeownerAssociation.ManagementCompanyCheckAmount.FAGetText().Clean());
                if (FastDriver.HomeownerAssociation.BusPhone.FAGetValue().Contains("(616)451-2290"))
                {
                    Support.AreEqual(@"(616)451-2290", FastDriver.HomeownerAssociation.BusPhone.FAGetValue().Clean());
                }
                Support.AreEqual(@"(616)451-2290", FastDriver.HomeownerAssociation.BusFax.FAGetValue().Clean());
                Support.AreEqual(@"(616)451-2290", FastDriver.HomeownerAssociation.CellPhone.FAGetValue().Clean());
                if (FastDriver.HomeownerAssociation.EmailAddress.FAGetValue().Contains("test@test.com"))
                {
                    Support.AreEqual(@"test@test.com", FastDriver.HomeownerAssociation.EmailAddress.FAGetValue().Clean());
                }
                Support.AreEqual(@"10.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.HomeownerAssociation.ProrationBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.HomeownerAssociation.ProrationSellerCredit.FAGetValue().Clean());
                Support.AreEqual(@"MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());
                Support.AreEqual(@"4.00", FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"2.00", FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"4.50", FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"2.50", FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.FAGetValue().Clean());

                Reports.TestStep = "FM6858_Validating the Lease details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                Support.AreEqual(@"HUDLEASE02", FastDriver.LeaseDetail.IDCodeLebel.FAGetText().Clean());
                Support.AreEqual(@"Lease 2 for HUD Testing Name 1", FastDriver.LeaseDetail.LeaseInformationName.FAGetText().Clean());
                Support.AreEqual(@"Lease 1 for HUD business street 1, Lease 1 for HUD business street 2", FastDriver.LeaseDetail.AddressLabelOne.FAGetText().Clean());
                Support.AreEqual(@"(782)145-0547", FastDriver.LeaseDetail.BusPhone.FAGetValue().Clean());
                Support.AreEqual(@"964", FastDriver.LeaseDetail.BusPhoneExtension.FAGetValue().Clean());
                Support.AreEqual(@"(780)111-5847", FastDriver.LeaseDetail.BusFax.FAGetValue().Clean());
                Support.AreEqual(@"(781)245-6394", FastDriver.LeaseDetail.CellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(987)201-7454", FastDriver.LeaseDetail.Pager.FAGetValue().Clean());
                if (FastDriver.LeaseDetail.EmailAddress.FAGetValue().Contains("rykxp"))
                {
                    Support.AreEqual(@"rykxp@2.HUD", FastDriver.LeaseDetail.EmailAddress.FAGetValue().Clean());//cuvkv@2.HUD original value
                }
                Support.AreEqual(@"100.00", FastDriver.LeaseDetail.LeaseAmount.FAGetValue().Clean());
                Support.AreEqual(@"Month", FastDriver.LeaseDetail.Per.FAGetSelectedItem());
                Support.AreEqual(@"10", FastDriver.LeaseDetail.For.FAGetValue().Clean());
                Support.AreEqual(@"Charge Description", FastDriver.LeaseDetail.ChargeDescription.FAGetValue().Clean());
                Support.AreEqual(@"11.00", FastDriver.LeaseDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"12.00", FastDriver.LeaseDetail.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Check Amount: $ 23.00", FastDriver.LeaseDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "FM6860_Validates the Survey Details";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                Support.AreEqual(@"247", FastDriver.SurveyDetail.IDcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"Lenders Advantage", FastDriver.SurveyDetail.Survey_LenderName.FAGetText().Clean());
                Support.AreEqual(@"A Division Of First American Title Ins.", FastDriver.SurveyDetail.Survey_LenderName1.FAGetText().Clean());
                Support.AreEqual(@"15441 94Th Avenue", FastDriver.SurveyDetail.AddressLabelOne.FAGetText().Clean());
                Support.AreEqual(@"Orland Park, IL, 60462, USA", FastDriver.SurveyDetail.AddressLabelTwo.FAGetText().Clean());
                Support.AreEqual(@"100.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Test Survey Details 1", FastDriver.SurveyDetail.SurveyDetails.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FAGetValue().Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"20.00", FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"20.00", FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"Check Amount: $ 240.00", FastDriver.SurveyDetail.CheckAmount.FAGetText().Clean());
                }
                Support.AreEqual(@"Check Amount: $ 200.00", FastDriver.SurveyDetail.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "FM6861_Validates Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                Support.AreEqual(@"HUDUTLCMP1", FastDriver.UtilityDetail.GABCodeLevel.FAGetText().Clean());
                Support.AreEqual(@"Utility Company 1 for HUD Test Name 1", FastDriver.UtilityDetail.Utility_LenderName.FAGetText().Clean());
                Support.AreEqual(@"(854)494-9486", FastDriver.UtilityDetail.BusPhone.FAGetValue().Clean());
                Support.AreEqual(@"745", FastDriver.UtilityDetail.BusPhoneExtension.FAGetValue().Clean());
                Support.AreEqual(@"(922)694-5646", FastDriver.UtilityDetail.BusFax.FAGetValue().Clean());
                Support.AreEqual(@"(965)415-6841", FastDriver.UtilityDetail.CellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(978)416-1169", FastDriver.UtilityDetail.Pager.FAGetValue().Clean());
                if (FastDriver.UtilityDetail.EmailAddress.FAGetValue().Clean().Contains("xuguqhc"))
                {
                    Support.AreEqual(@"xuguqhc@Company.1", FastDriver.UtilityDetail.EmailAddress.FAGetValue().Clean());//kmgmhqf@Company.1
                }
                FastDriver.UtilityDetail.PaymentDetails.FAClick();

                Reports.TestStep = "FM6861_Validates Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(@"Utility Company 1 for HUD Test Name 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().Clean());
                Support.AreEqual(@"Payment details desc.", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Clean());
                Support.AreEqual(@"$1.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$1.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"FEE", FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FAGetSelectedItem().Clean());
                    Support.AreEqual(@"FEE", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FAGetSelectedItem().Clean());
                }
                else
                {
                    Support.AreEqual(@"$1.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Clean());
                    Support.AreEqual(@"$1.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Clean());
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual(@"", FastDriver.UtilityDetail.ProrationAmount.FAGetValue().Clean());
                Support.AreEqual(@"Utilities", FastDriver.UtilityDetail.ProrationDescription.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue().Clean(), "Verifying whether the 'ProrationBuyerCharge' amount was not copied.");
                Support.AreEqual(@"", FastDriver.UtilityDetail.ProrationBuyerCredit.FAGetValue().Clean(), "Verifying whether the 'ProrationBuyerCredit' amount was not copied.");
                Support.AreEqual(@"", FastDriver.UtilityDetail.ProrationSellerCharge.FAGetValue().Clean(), "Verifying whether the 'ProrationSellerCharge' amount was not copied.");
                Support.AreEqual(@"", FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue().Clean(), "Verifying whether the 'ProrationSellerCredit' amount was not copied.");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0060()
        {
            try
            {
                Reports.TestDescription = "BR : FM6856_FM6857_FM6859_FM6862_FM14689_Inspection/Repair Information,Group Insurance Information,Group Miscellaneous Disbursements Information";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first order.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "FM6856_Enters details on inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Name.FASetText(@"Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.InspectionRepairPest.Attention.FASelectItem(@"Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText(@"Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText(@"5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText(@"07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText(@"12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText(@"10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText(@"04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText(@"03-10-2013");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "FM6856_Enters Payment details on the dialog box.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText(@"PESTDESCRIPTION1.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"55.55");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"66.66");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem(@"POC-S");
                    FastDriver.PaymentDetailsDlg.GFEType.FASelectItem(@"6");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(@"55.55");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(@"66.66");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GFEAmount.FASetText(@"11.11");
                Support.AreEqual(@"Check Amount: $ 0.00", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6857_Enter details on the Fire Insurance page";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();

                Reports.TestStep = "FM6857_Click on Edit Insurance Summary.";
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "FM6857_Creates an instance of Fire Insurance.";
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireName.FASetText(@"Insurance CompanyName 1");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.UpdateCharge(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                FastDriver.InsuranceFire.FireGFE11.FASetText(@"100.00");
                FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(true);
                //Underwrite section
                FastDriver.InsuranceFire.FindUnderwriterGAB(@"STARTTRU");
                //Inusrance details
                FastDriver.InsuranceFire.FirePremium.FASetText(@"100");
                if (!AutoConfig.UseCDFormType)
                    FastDriver.InsuranceFire.FireImpound.FASetCheckbox(true);
                FastDriver.InsuranceFire.FiretextTerm.FASetText(@"4");
                FastDriver.InsuranceFire.FireoptYears.FASetCheckbox(true);
                //Proration  section
                FastDriver.InsuranceFire.FireAmount.FASetText(@"50.00");
                FastDriver.InsuranceFire.FireFromDate.FASetText(@"10-08-2010");
                FastDriver.InsuranceFire.FireToDate.FASetText(@"10-08-2012");
                FastDriver.InsuranceFire.FireBuyerCharge1.FASetText(@"100.14");
                FastDriver.InsuranceFire.FireBuyerCredit1.FASetText(@"200.30");
                FastDriver.InsuranceFire.FireSellerCharge1.FASetText(@"100.14");
                FastDriver.InsuranceFire.FireSellerCredit1.FASetText(@"200.50");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6862_FM14689_Enters TDS details.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText(@"100000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.Click();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText(@"100000");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday")
                    value = (Convert.ToInt32("7") + 3).ToString();
                else
                    value = "7".ToString();
                string TempDays = value;
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToString("MM/dd/yyyy"));
                FastDriver.TermsDatesStatus.EstimattedDaysToClose.FASetText(value + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.WebDriver.HandleDialogMessage(true, false, timeout: 10);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                //Est Settle Date
                if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday")
                    value = (Convert.ToInt32("7") + 3).ToString();
                else
                    value = "7".ToString();
                var TempDate = DateTime.Today.AddDays(Int32.Parse(value));
                FastDriver.TermsDatesStatus.EstimattedSettlementDate.FASetText(DateTime.Today.AddDays(Int32.Parse(value)).ToDateString() + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                // for Weekend warning message.
                if (TempDate.ToString("dddd") == "Saturday" || TempDate.ToString("dddd") == "Sunday")
                {
                    FastDriver.WeekendWarning.WaitForScreenToLoad();
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                FastDriver.WebDriver.HandleDialogMessage(false, true, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create second Order.";
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var FileNum2 = File.FileNumber;

                Reports.TestStep = "Copying Source file data on Starter/Ref page.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

                Reports.TestStep = "Clicks on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "FM6856_Validates details on the inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                Support.AreEqual(@"HUDPEST001", FastDriver.InspectionRepairPest.LabelIDCode.FAGetText().Clean());
                Support.AreEqual(@"Pest 1 for HUD Testing Name 1", FastDriver.InspectionRepairPest.INSP_Pest_LenderName.FAGetText().Clean());
                Support.AreEqual(@"Contact, Pest 1 for HUD", FastDriver.InspectionRepairPest.Attention.FAGetSelectedItem().Clean());
                Support.AreEqual(@"Reference1", FastDriver.InspectionRepairPest.Reference.FAGetValue().Clean());
                Support.AreEqual(@"5", FastDriver.InspectionRepairPest.WithinDays.FAGetValue().Clean());
                Support.AreEqual(@"07-10-2012", FastDriver.InspectionRepairPest.OrderDate.FAGetValue().Clean());
                Support.AreEqual(@"12-10-2012", FastDriver.InspectionRepairPest.DueDate.FAGetValue().Clean());
                Support.AreEqual(@"10-10-2012", FastDriver.InspectionRepairPest.FollowUpDate.FAGetValue().Clean());
                Support.AreEqual(@"04-10-2013", FastDriver.InspectionRepairPest.CompleteDate.FAGetValue().Clean());
                Support.AreEqual(@"03-10-2013", FastDriver.InspectionRepairPest.ReportDate.FAGetValue().Clean());
                Support.AreEqual(@"11.11", FastDriver.InspectionRepairPest.GFEAmount.FAGetValue().Clean());
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "FM6856_Validates Payment details on the dialog box.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(@"PESTDESCRIPTION1.", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Clean());
                Support.AreEqual(@"$55.55", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$66.66", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"POC-B", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FAGetSelectedItem().Clean());
                    Support.AreEqual(@"POC-S", FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FAGetSelectedItem().Clean());
                    Support.AreEqual(@"6", FastDriver.PaymentDetailsDlg.GFEType.FAGetSelectedItem().Clean());
                }
                else
                {
                    Support.AreEqual(@"$55.55", FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Clean());
                    Support.AreEqual(@"$66.66", FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue().Clean());
                    Support.AreEqual(@"POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Clean());
                    Support.AreEqual(@"POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Clean());
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "FFM6857_Validates for Insurance data";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(p => p.Text == "TrusteeName 1").FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                Support.AreEqual(@"STARTINCO", FastDriver.InsuranceFire.FireGABLabel.FAGetText().Clean());
                Support.AreEqual(@"Insurance CompanyName 1", FastDriver.InsuranceFire.FireAgentNameLabel.FAGetText().Clean());
                Support.AreEqual(@"Ins Comp Address Line 1, Ins Comp Address Line 2", FastDriver.InsuranceFire.FireAgentAddressLabel.FAGetText().Clean());
                //Underwriter
                Support.AreEqual(@"STARTTRU", FastDriver.InsuranceFire.FireUnderwriterIDCodeLabel.FAGetText().Clean());
                Support.AreEqual(@"TrusteeName 1", FastDriver.InsuranceFire.FireUnderwriterNameLabel.FAGetText().Clean());
                Support.AreEqual(@"Trustee Address Line 1, Trustee Address Line 2", FastDriver.InsuranceFire.FireUnderwriterAddressLabel.FAGetText().Clean());
                //Contact Details - Issue check to
                Support.AreEqual(@"True", FastDriver.InsuranceFire.FireIssuecheck2.Selected.ToString(), "Verify whether 'FireIssuecheck2' checkbox is checked.");
                //Insurance Details section
                Support.AreEqual(@"100.00", FastDriver.InsuranceFire.FirePremium.FAGetValue().Clean());
                if (!AutoConfig.UseCDFormType)
                    Support.AreEqual(@"True", FastDriver.InsuranceFire.FireImpound.Selected.ToString(), "Verify whether 'FireImpound' checkbox is checked.");
                Support.AreEqual(@"4", FastDriver.InsuranceFire.FiretextTerm.FAGetValue().Clean());
                Support.AreEqual(@"True", FastDriver.InsuranceFire.FireoptYears.Selected.ToString(), "Verify whether 'FireoptYears' checkbox is checked.");
                //Insurance Charges section
                Support.AreEqual(@"100.00", FastDriver.InsuranceFire.FireBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"200.55", FastDriver.InsuranceFire.FireSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.InsuranceFire.FireGFE11.FAGetValue().Clean());
                //Proration  section
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireAmount.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireFromDate.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireToDate.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireBuyerCharge1.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireBuyerCredit1.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireSellerCharge1.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireSellerCredit1.FAGetValue().Clean());
                Support.AreEqual(@"Check Amount: $ 300.55", FastDriver.InsuranceFire.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "FM6862_Validates TDS details.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(@"100,000.00", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue().Clean());
                Support.AreEqual(@"100,000.00", FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue().Clean());
                Support.AreEqual(TempDays, FastDriver.TermsDatesStatus.EstimattedDaysToClose.FAGetValue().Clean());
                Support.AreEqual(TempDays, FastDriver.TermsDatesStatus.EstimattedDaysToClose.FAGetValue().Clean());
                value = FastDriver.TermsDatesStatus.EstimattedSettlementDate.FAGetValue().Clean().Replace('-', '/');
                Support.AreEqual(TempDate.ToString("MM/dd/yyyy"), value, "Verify whether the 'EstimattedSettlementDate' date is the same that was set before copying the file.");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0061_61A()
        {
            try
            {
                Reports.TestDescription = "FM10096_FM10094_FM14594_FM1662 - Creates 2 files - Do not copy Delivery Instructions,Retain delivery Instructions for the role,Allow Copy When Target File has AgentNet Policy Numbers,Copy only existing Data Groups";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creates First Order with Buyer and Seller";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile(newLoanGAB: "246");

                Reports.TestStep = "Captures the First file number";
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "FM14487_FM14616_Creates a Buyer instance which is present in SDN Hit List for the First File";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(@"bin");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(@"laden");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigates to SDN Tracking Summary screen.";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.LeftNavigation.Navigate<SDNTrackingSummary>(@"Home>Order Entry>SDN Tracking Summary").WaitForScreenToLoad();
                    return FastDriver.SDNTrackingSummary.SDNHitTable.Text.Contains("laden");
                }, timeout: 60, idleInterval: 10);
                FastDriver.SDNTrackingSummary.SDNHitTable.PerformTableAction(2, "bin laden", 2, TableAction.Click);

                Reports.TestStep = "Navigate to Document Repository screen.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);

                Reports.TestStep = "Verify a document is generated in Document Repository for the SDN Hit List name.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "SDN Result", 6, TableAction.Click);

                Reports.TestStep = "FM10094_Creating Delivery instruction on DR page for the first file.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.FAClick();

                Reports.TestStep = "Entering values on the Deliver Instr dialog window.";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage.FASelectItem(@"Branch");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPrelimReport.FASelectItem(@"Courier");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectCopies0cboCCRs.FASelectItem(@"Email");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPlottedEasement.FASelectItem(@"Fax");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectExceptions.FASelectItem(@"Mail");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM13887_Creates a New loan for the first file";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode(@"247");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem(@"Purchase");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM13887_Enter QC Closing Gab Code and Verify QC Closing TAB.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "Verify whether 'QCClosingTab' is enabled.");
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.BottomFrame.Done();

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Select Combined only on HUD-1 Statement page.";
                    FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>(@"Home>Order Entry>Escrow Closing>HUD-1 Statement").WaitForScreenToLoad();
                    FastDriver.HUD1PrintOptions.Combined.FASetCheckbox(true);

                    Reports.TestStep = "Perform Imagedoc delivery.";
                    FastDriver.HUD1PrintOptions.Method.FASelectItem("Imagedoc");
                    FastDriver.HUD1PrintOptions.Deliver.FAClick();
                    FastDriver.ImageDocDlg.WaitForScreenToLoad();
                    FastDriver.ImageDocDlg.AddQCClosingReport.FASetCheckbox(true);
                    FastDriver.ImageDocDlg.ImageDoc.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(false, true);
                    FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                    Reports.TestStep = "FM13887_Validates that image doc delivery is performed";
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Imaged Document", 6, TableAction.Click);
                }

                Reports.TestStep = "Creates 2nd order without Buyer and Seller";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(@"HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Default-Residential");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Multi Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"2ndFileLot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"2ndFileBlock1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"2ndFileUnit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN2");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845019999");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"BUTTE");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("246");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Captures the Second file number";
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "FM10096_Creating Delivery instruction on DR page for the second file.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.FAClick();

                Reports.TestStep = "Entering values on the Deliver Instr dialog window.";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.DirectedBy.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage1.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport1.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs1.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement1.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions1.FASetText(@"3");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage1.FASelectItem(@"Branch");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPrelimReport1.FASelectItem(@"Courier");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectCopies0cboCCRs1.FASelectItem(@"Email");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPlottedEasement1.FASelectItem(@"Fax");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectExceptions1.FASelectItem(@"Mail");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Copy all except Business Source to validate Delivery Instructions";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.Products.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
                FastDriver.StarterReference.PropertyTitleProductionTab.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.Notes.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "FM10096_FM10094_Validates values on the Deliver Instr dialog window on the Second file.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DistributionAndDeliveryInstructions.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage.FAGetSelectedItem());
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.SelectPrelimReport.FAGetSelectedItem());
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.SelectCopies0cboCCRs.FAGetSelectedItem());
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.SelectPlottedEasement.FAGetSelectedItem());
                Support.AreEqual(@"", FastDriver.ViewDeliveryInstrucionsDlg.SelectExceptions.FAGetSelectedItem());
                //Validating the data was not wiped out      
                Support.AreEqual(@"3", FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage1.FAGetValue().Clean());
                Support.AreEqual(@"3", FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport1.FAGetValue().Clean());
                Support.AreEqual(@"3", FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs1.FAGetValue().Clean());
                Support.AreEqual(@"3", FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement1.FAGetValue().Clean());
                Support.AreEqual(@"3", FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions1.FAGetValue().Clean());
                Support.AreEqual(@"Branch", FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage1.FAGetSelectedItem());
                Support.AreEqual(@"Courier", FastDriver.ViewDeliveryInstrucionsDlg.SelectPrelimReport1.FAGetSelectedItem());
                Support.AreEqual(@"Email", FastDriver.ViewDeliveryInstrucionsDlg.SelectCopies0cboCCRs1.FAGetSelectedItem());
                Support.AreEqual(@"Fax", FastDriver.ViewDeliveryInstrucionsDlg.SelectPlottedEasement1.FAGetSelectedItem());
                Support.AreEqual(@"Mail", FastDriver.ViewDeliveryInstrucionsDlg.SelectExceptions1.FAGetSelectedItem());
                if(FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage5.FAGetValue() != "")
                {
                    FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage5.Click();
                    FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage5.FASetText(@"" + FAKeys.Tab);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Copying Source file data on Starter/Ref page.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.CopyDocument.FAClick();

                Reports.TestStep = "Copy documents.";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                var value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("Error(s)"))
                {
                    Reports.StatusUpdate("All file items not copied due to errors. Refer to the errro message.", false);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "FM13887_Validates that QC@Closing Data is not copied to the Target file";
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Imaged Document", 6, TableAction.Click);
                }

                #region FMUC0003_REG0061_A

                Reports.TestStep = "FM14616_FM14487_Navigates to Document Repository screen and Verify the SDN document is not copied.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                if (FastDriver.DocumentRepository.BinLaden.Exists())
                    Reports.StatusUpdate("SDN document was copied - TFS Bug 600820.", false);
                else
                    Reports.StatusUpdate("SDN document was not copied.", true);

                Reports.TestStep = "Navigates to SDN Tracking Summary screen.";
                FastDriver.LeftNavigation.Navigate<SDNTrackingSummary>(@"Home>Order Entry>SDN Tracking Summary").WaitForScreenToLoad();
                if (FastDriver.DocumentRepository.BinLaden.Exists())
                    Reports.StatusUpdate("SDN document was copied - TFS Bug 600820.", false);
                else
                    Reports.StatusUpdate("SDN document was not copied.", true);

                Reports.TestStep = "FM10096_Verify the DirectedBy GAB data was cleared.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"DIRECTEDBY", FastDriver.FileHomepage.DirectedByIDCodeLabel.FAGetText().Clean());
                Support.AreEqual(@"Name 1 For Directed By", FastDriver.FileHomepage.DirectedByNameLabel.FAGetText().Clean());

                Reports.TestStep = "FM14594_Creates a New Loan and and AgentNet policy number.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.AddRemoveProducts.FAClick();

                Reports.TestStep = "FM14594_Selects a Loan Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductSelectionDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductSelectionDlg.Table.PerformTableAction(2, "*ALTA Extended Loan Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Keyboard.SendKeys("^S");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"500.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText(@"500.00");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText(@"123456");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry").SwitchToLeftNavigationPane();
                try
                {
                    if (FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//a[.='Request Policy Number']").Exists())
                        FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//a[.='Request Policy Number']").FAClick();
                    FastDriver.RequestPolicyNumber.WaitForScreenToLoad();
                }
                catch (Exception)
                {
                    FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                    FastDriver.SecuritySelectRegionOffice.Open();
                    FastDriver.SecuritySelectRegionOffice.EnterBUID(@"1486");

                    Reports.TestStep = "Selects an Office and Click on New.";
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem(@"Active");
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction(2, "7878", 2, TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Checking for the Request Policy number Checkbox.";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.ANPolicyNumber.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                    FastDriver.TopFrame.SearchFileByFileNumber(FileNum2);
                    FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number");
                    Playback.Wait(20000);//We have to explicity wait due view slowness
                    FastDriver.RequestPolicyNumber.WaitForScreenToLoad();
                }
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem(@"First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(i => i.Text == "*ALTA Extended Loan Policy").FAClick();
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();

                Reports.TestStep = "Creating Tilte Reports document in REG0061 starts.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                CreateDocument("Title Reports", "Automation Test Title Report", "Automation Test Title Report", multipleDocs: true);

                Reports.TestStep = "Select the Title Report Document and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Title Reports", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Title report.";
                Playback.Wait(2000);
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
                Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.EffectiveDate.FASetText(@"06-20-2012");
                FastDriver.DocumentInfo.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentInfo.WaitForWindowToLoad();
                Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
                Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.EffectiveDate.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Lender Policy document in REG0061 starts.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                CreateDocument("Lender Policy", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", multipleDocs: true);
                if (FastDriver.TitleReportSelection.TitleReportSelectionScreenExists())
                {
                    FastDriver.TitleReportSelection.WaitForScreenToLoad();
                    FastDriver.TitleReportSelection.TableRow1.FAClick();
                    FastDriver.TitleReportSelection.Select.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                }
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Click on Policy number button.";
                Playback.Wait(2000);
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
                if (FastDriver.DocumentInfo.AssignNum.IsEnabled())
                    FastDriver.DocumentInfo.AssignNum.FAClick();
                else if (FastDriver.DocumentInfo.PolicyNum.IsEnabled())
                    FastDriver.DocumentInfo.PolicyNum.FASetText(Support.RandomNumber(10000).ToString());
                FastDriver.DocumentInfo.policywotitlereporteffectiveDate.FASetText(DateTime.Now.ToUniversalTime().AddHours(-8).AddMonths(-8).ToString("MM/dd/yyyy"));
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Finalize doc.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(2000);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad(FastDriver.DocumentPreparationMenu.Expand1);

                Reports.TestStep = "Press ALT o+z to Select Finalize link";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    return FastDriver.DocumentPreparationMenu.IsFinalizeDocumentDialogPresent();
                }, timeout: 120, idleInterval: 5);
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "FM14594_Copy the Buyers,Sellers,Notes,SettlementInfo and Make the Buyers as Sellers.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.Notes.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("Error(s)"))
                    FailTest(@"All file items not copied due to errors. Refer to the errro message.");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.BuyersData.FASetCheckbox(false);
                FastDriver.StarterReference.SellersData.FASetCheckbox(false);
                FastDriver.StarterReference.Notes.FASetCheckbox(false);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(false);
                FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("Error(s)"))
                    FailTest(@"All file items not copied due to errors. Refer to the errro message.");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0061_A()
        {
            try
            {
                Reports.TestDescription = "FM14616_FM14487_Navigates to Document Repository screen and Verify the SDN document is not copied.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0061.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0062_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder_For test cases (Holder_FM6975_Copy Documents from Archived File, FM9847_Copy Image Document from a archived file, FM6976_De-Archive Files Before Copying Documents From Archived File,FM6844_Copy Document Failure,FM6823_Multiple Users copying from the same Starter File Simultaneously";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //your test case code here

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0063()
        {
            try
            {
                Reports.TestDescription = "FM9850_FM6843_FM6842_FM10550_FM13469 : Copy all  versions of a image,Duplicate Copy Document Request,Copy Document - Asynchronous Process, Copy GFE Data";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creates First Order with Buyer and Seller";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Captures the 1st file number";
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "Enter Zip and other details on Property Tax";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralTab.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText(@"Santaana");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText(@"Orange");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText(@"92703");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM9850_Adds Title Reports for the First file number";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                CreateDocument("Title Reports", "Automation Test Title Report", "Automation Test Title Report");

                Reports.TestStep = "FM9850_Enters fees for the first file.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "22.22");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "FM10550_Enters values for the Split LSP on the Source File";
                FastDriver.FileFees.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.FileFees.TitleServices_LenderTitleInsGFEAmount.FASetText(@"10.00");
                    FastDriver.FileFees.SplitLSP.FAClick();
                    FastDriver.SplitGFE4LenderSelectedProvider.WaitForScreenToLoad();
                    FastDriver.SplitGFE4LenderSelectedProvider.FeeEntryTitleServicesGFE4BreakdownAmount.FASetText(@"5.00");
                    FastDriver.SplitGFE4LenderSelectedProvider.OTCTitleServicesGFE4BreakdownAmount.FASetText(@"5.00");

                }
                else
                {
                    FastDriver.FileFees.LenderAdjustmentAmount.FASetText(@"10.00");
                    FastDriver.FileFees.BSSplitButton.FAClick();
                    FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                    FastDriver.BuyerSellerSplitDlg.BuyerCharge.FASetText(@"5.00");
                    FastDriver.BuyerSellerSplitDlg.SellerCharge.FASetText(@"5.00");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "FM13469 _Creates a New loan for the first file";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode(@"247");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText(@"123456");
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItem("L247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "FM13469_Creates a Closing Protection Letter for the source file.";
                FastDriver.LeftNavigation.Navigate<ClosingProtectionLetter>(@"Home>Order Entry>Closing Protection Letter").WaitForScreenToLoad();
                FastDriver.ClosingProtectionLetter.Office.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.ClosingProtectionLetter.BuyerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.SellerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.LenderTable.PerformTableAction(4, "L247", 1, TableAction.Click);
                FastDriver.ClosingProtectionLetter.LenderDetailsAddressLine1.FASetText(@"address1");
                FastDriver.ClosingProtectionLetter.LenderDetailsCity.FASetText(@"albany");
                FastDriver.ClosingProtectionLetter.LenderDetailsState.FASelectItem(@"CA");
                FastDriver.ClosingProtectionLetter.LenderDetailsZipCode.FASetText(@"97020");
                if (FastDriver.ClosingProtectionLetter.LenderDetailsPhone.FAGetValue().Contains("(616)4512290"))
                {
                    Support.AreEqual(@"(616)4512290", FastDriver.ClosingProtectionLetter.LenderDetailsPhone.FAGetValue().Clean());
                }
                FastDriver.ClosingProtectionLetter.LenderDetailsEmail.FASetText(@"abc@firstam.com");
                Support.AreEqual(@"(616)4512290", FastDriver.ClosingProtectionLetter.LenderDetailsFax.FAGetValue().Clean());
                FastDriver.ClosingProtectionLetter.SubmitCPLRequest.FAClick();
                Playback.Wait(30000);
                Keyboard.SendKeys("%F4");
                Playback.Wait(1000);
                Keyboard.SendKeys("%F4");
                Playback.Wait(1000);

                Reports.TestStep = "FM13469_Verifies on DR page";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Closing Protection Letter - LENDER", 4, TableAction.Click);

                Reports.TestStep = "FM9850_File balance summary and creates ImageDoc version 1.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.Method(@"Imagedoc");
                FastDriver.EscrowFileBalanceSummary.Deliver();

                Reports.TestStep = "Clicks on Imagedoc button.";
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "FM9850_Creates ImageDoc 2nd time to generate 2 version";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.Method(@"Imagedoc");
                FastDriver.EscrowFileBalanceSummary.Deliver();
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "FM9850_Navigates to DR screen to validate the versions on the source file.";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    return FastDriver.DocumentRepository.ExpandIcon.Exists();
                }, timeout: 60, idleInterval: 10);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(@"True", FastDriver.DocumentRepository.ExpandIcon.Exists().ToString(), "Verify whether 'ExpandIcon' icon exist.");

                Reports.TestStep = "Creates 2nd order without Buyer and Seller";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(@"HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(!AutoConfig.UseCDFormType);
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Default-Residential");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Multi Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"2ndFileLot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"2ndFileBlock1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"2ndFileUnit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN2");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845019999");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"BUTTE");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Captures the 2nd file number";
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "FM9850_Copy All file items to verify all versions of the image were copied.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("Error(s)"))
                    FailTest("All file items not copied due to errors. Refer to the errro message.");

                Reports.TestStep = "Copy Docs and All File Items from source file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "FM9850_Navigates to DR screen to validate the versions on the target file.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(@"True", FastDriver.DocumentRepository.ExpandIcon.Exists().ToString(), "Verify whether 'ExpandIcon' exists.");

                Reports.TestStep = "FM6842_Copy Document - Asynchronous Process  - Verifies in the EventLog page";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                int FileOne = Int32.Parse(FileNum1);
                int FileTwo = Int32.Parse(FileNum2);
                string NewStr = "Starter Ref File Item Copy from \"" + FileOne + "\" to \"" + FileTwo + "\", CopyAll Completed. Copy Doc request was submitted.";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", NewStr, "Source", TableAction.Click);
                //
                //
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FileOne = Int32.Parse(FileNum1);
                FileTwo = Int32.Parse(FileNum2);
                NewStr = "Starter Ref Copy Doc from \"" + FileOne + "\" to \"" + FileTwo + "\" completed.";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", NewStr, "Source", TableAction.Click);

                Reports.TestStep = "Second time Copy Docs and All File Items from source file.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value != "" && value != null)
                {
                    if (value.Contains("image(s) already exists"))
                        Reports.StatusUpdate("All file items not copied due to another Copy process is going on. This is expected behaviour", true);
                    else
                        Reports.StatusUpdate("All File items were copied though another Copy process is going on. This is not the expected behaviour", false);
                }

                Reports.TestStep = "FM10550_Verifies values for the Split LSP on the Target File";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"$10.00", FastDriver.FileFees.TitleServices_LenderTitleInsGFEAmount.FAGetValue().Clean());
                    //FastDriver.FileFees.SplitLSP.FAClick();
                    //FastDriver.SplitGFE4LenderSelectedProvider.WaitForScreenToLoad();
                    //Support.AreEqual(@"5.00", FastDriver.SplitGFE4LenderSelectedProvider.FeeEntryTitleServicesGFE4BreakdownAmount.FAGetValue().Clean());
                    //Support.AreEqual(@"5.00", FastDriver.SplitGFE4LenderSelectedProvider.OTCTitleServicesGFE4BreakdownAmount.FAGetValue().Clean());
                }
                else
                {
                    Support.AreEqual(@"$0.00", FastDriver.FileFees.LenderAdjustmentAmount.FAGetValue().Clean());
                    //FastDriver.FileFees.BSSplitButton.FAClick();
                    //FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                    //Support.AreEqual(@"9.00", FastDriver.BuyerSellerSplitDlg.BuyerCharge.FAGetValue().Clean());
                    //Support.AreEqual(@"5.00", FastDriver.BuyerSellerSplitDlg.SellerCharge.FAGetValue().Clean());
                }
                //FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "FM13469_Verifies on DR page on the Target file";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                if (FastDriver.DocumentRepository.ClosingProtectionLetterDoc.Exists())
                    Reports.StatusUpdate("Closing Protection Letter - LENDER - document copied", false);
                else
                    Reports.StatusUpdate("Closing Protection Letter - LENDER - document copied", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0064()
        {
            try
            {
                Reports.TestDescription = "FM6973_Checks File Owning Region";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creates First Order with Buyer and Seller with corpfastqaCD user";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(!AutoConfig.UseCDFormType);
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(AutoConfig.UseCDFormType);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("5000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.BottomFrame.Done();

                //FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                //fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                //FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Captures the 1st file number";
                //var FileNum1 = File.FileNumber;
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Login with FasttsFastqa07 user";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);

                Reports.TestStep = "Creates Second Order with Buyer and Seller with FasttsFastqa07  user";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Captures the 2nd file number";
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Copy Docs and All File Items from source file to verify the Owning Officess copy";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                var value = FastDriver.WebDriver.HandleDialogMessage();
                if (value.Contains("Error(s) occured.") || value.Contains("Starter file number not found"))
                {
                    Reports.StatusUpdate("Verification of File Owning Region Check was success", true);
                }
                else
                {
                    Reports.StatusUpdate("Verification of File Owning Region Check was success", false);
                }

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0065_65A_65B_65C_65D()
        {
            try
            {
                Reports.TestDescription = "FM1911_Settlement Info Data Group - Attorney Buyer,Seller,Assumption Loan,Homeowner Association,Homeowner Warraty,Inspection Pest,Repair,Others";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var TrustDeedDate = DateTime.Today.AddDays(2).ToDateString();
                var RecordingDate = DateTime.Today.AddDays(2).ToDateString();
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creates First Order with Buyer and Seller";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Captures the 1st file number";
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "Creates Attorney Buyer";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.FindGABcode(@"HUDBUYATT1", waitForGabCodeLabel: false);
                FastDriver.AttorneyDetail.Type.FASelectItem(@"Attorney- Primary");
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", buyerCharge: 50.00, sellerCharge: 50.00);

                Reports.TestStep = "Creates Seller Attorney";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.FindGABcode(@"ATTBUY3", waitForGabCodeLabel: false);
                FastDriver.AttorneyDetail.Type.FASelectItem(@"Attorney- Primary");
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", buyerCharge: 10.1, sellerCharge: 20.2);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enters Assumption Loan.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode(@"HUDASLNDR1", WaitForGabCodeLabel: false);
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText(@"300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText(@"06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText(@"06-04-2012");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText(@"06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText(@"500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText(@"200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem(@"Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem(@"Month");
                FastDriver.BottomFrame.Done();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateCharge(FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesTable, "Unpaid Principal Balance", buyerCredit: 500.00, sellerCharge: 10.00, editDescription: @"Changed Description");
                // Parties tab                
                FastDriver.AssumptionLoanCharges.clickPartiesTab().WaitForScreeToLoan();
                FastDriver.AssumptionLoanParties.FindGABCode(@"HUDASLNDR1");
                //Recording tab
                FastDriver.AssumptionLoanParties.clickRecordingTab().WaitForScreeToLoan();
                FastDriver.AssumptionLoanRecording.Recording.FAClick();
                FastDriver.AssumptionLoanRecording.TrustDeedDate.FASetText(@"08-22-2012");
                FastDriver.AssumptionLoanRecording.RecordingDate.FASetText(@"08-22-2012");
                FastDriver.AssumptionLoanRecording.Instrument.FASetText(@"Instrument");
                FastDriver.AssumptionLoanRecording.Book.FASetText(@"Book");
                FastDriver.AssumptionLoanRecording.Page.FASetText(@"page");

                Reports.TestStep = "Adds a Homeowner Association instance.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode(@"247", WaitForGabCodeLabel: false);
                FastDriver.HomeownerAssociation.AmountDues.FASetText(@"10.00");
                FastDriver.HomeownerAssociation.PerDiem.FASelectItem(@"MONTH");
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", buyerCharge: 4.00, sellerCharge: 2.00);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", buyerCharge: 4.50, sellerCharge: 2.50);
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText(@"10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText(@"07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText(@"08-17-2012");
                FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText(@"1.50");
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText(@"2.50");

                Reports.TestStep = "Set an instance of Home warranty details.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode(@"HW1");
                FastDriver.HomeWarrantyDetail.PolicyCharge.FASetText(@"10.00");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.HomeWarrantyDetail.paidSeller.FASetText(@"2.00");
                    FastDriver.HomeWarrantyDetail.PaidBuyer.FASetText(@"2.00");
                }
                FastDriver.HomeWarrantyDetail.Amount.FASetText(@"2.00");
                FastDriver.HomeWarrantyDetail.FromDate.FASetText(DateTime.Today.AddDays(1).ToDateString() + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.ToDate.FASetText(DateTime.Today.AddDays(2).ToDateString() + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.InclusiveFrom.FASetCheckbox(true);
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.InclusiveTo.FASetCheckbox(true);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "", buyerCharge: 10, sellerCharge: 10, editDescription: @"Early Coverage Charge Description");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText(@"Sanity-Home Warranty");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"3.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"3.99");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"3.99");
                    FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText(@"3.99");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Creates an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Name.FASetText(@"Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.InspectionRepairPest.Attention.FASelectItem(@"Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText(@"Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText(@"5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText(@"07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText(@"12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText(@"10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText(@"04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText(@"03-10-2013");
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection", buyerCharge: 55.55, sellerCharge: 66.66, editDescription: "PESTDESCRIPTION1");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual(@"Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Clean());

                Reports.TestStep = "Create an instance of inspection Repair Septic.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();
                FastDriver.InspectionRepairSeptic.Name.FASetText(@"Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairSeptic.Find.FAClick();
                FastDriver.InspectionRepairSeptic.Attention.FASelectItem(@"Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairSeptic.Reference.FASetText(@"Reference1");
                FastDriver.InspectionRepairSeptic.WithinDays.FASetText(@"5");
                FastDriver.InspectionRepairSeptic.OrderDate.FASetText(@"07-10-2012");
                FastDriver.InspectionRepairSeptic.DueDate.FASetText(@"12-10-2012");
                FastDriver.InspectionRepairSeptic.FollowUpDate.FASetText(@"10-10-2012");
                FastDriver.InspectionRepairSeptic.CompleteDate.FASetText(@"04-10-2013");
                FastDriver.InspectionRepairSeptic.ReportDate.FASetText(@"03-10-2013");
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, "Septic Inspection", buyerCharge: 55.55, sellerCharge: 66.66, editDescription: "SEPTICInspectionDESCRIPTION1");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual(@"Check Amount: $ 122.21", FastDriver.InspectionRepairSeptic.CheckAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create an instance of inspection Repair Other.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.Name.FASetText(@"Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairOther.Find.FAClick();
                FastDriver.InspectionRepairOther.Attention.FASelectItem(@"Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairOther.Reference.FASetText(@"Reference1");
                FastDriver.InspectionRepairOther.WithinDays.FASetText(@"5");
                FastDriver.InspectionRepairOther.OrderDate.FASetText(@"07-10-2012");
                FastDriver.InspectionRepairOther.DueDate.FASetText(@"12-10-2012");
                FastDriver.InspectionRepairOther.FollowUpDate.FASetText(@"10-10-2012");
                FastDriver.InspectionRepairOther.CompleteDate.FASetText(@"04-10-2013");
                FastDriver.InspectionRepairOther.ReportDate.FASetText(@"03-10-2013");
                FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, "Other Inspection", buyerCharge: 55.55, sellerCharge: 66.66, editDescription: "OTHERInspectionDESCRIPTION1");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual(@"Check Amount: $ 122.21", FastDriver.InspectionRepairOther.CheckAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                #region FMUC0003_REG0065_A

                Reports.TestStep = "Enters details on the Fire Insurance page";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireName.FASetText(@"Insurance CompanyName 1");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.UpdateCharge(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                FastDriver.InsuranceFire.FireGFE11.FASetText(@"100.00");
                FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(true);
                //Underwrite section
                FastDriver.InsuranceFire.FindUnderwriterGAB(@"STARTTRU");
                //Inusrance details
                FastDriver.InsuranceFire.FirePremium.FASetText(@"100");
                if (!AutoConfig.UseCDFormType)
                    FastDriver.InsuranceFire.FireImpound.FASetCheckbox(true);
                FastDriver.InsuranceFire.FiretextTerm.FASetText(@"4");
                FastDriver.InsuranceFire.FireoptYears.FASetCheckbox(true);
                //Proration  section
                FastDriver.InsuranceFire.FireAmount.FASetText(@"50.00");
                FastDriver.InsuranceFire.FireFromDate.FASetText(@"10-08-2010");
                FastDriver.InsuranceFire.FireToDate.FASetText(@"10-08-2012");
                FastDriver.InsuranceFire.FireBuyerCharge1.FASetText(@"100.14");
                FastDriver.InsuranceFire.FireBuyerCredit1.FASetText(@"200.30");
                FastDriver.InsuranceFire.FireSellerCharge1.FASetText(@"100.14");
                FastDriver.InsuranceFire.FireSellerCredit1.FASetText(@"200.50");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enters Flood Insurance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();

                Reports.TestStep = "Click on Edit Insurance Summary.";
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                FastDriver.Insuranceflood.FloodName.FASetText(@"Insurance CompanyName 1");
                FastDriver.Insuranceflood.FloodFind.FAClick();
                FastDriver.Insuranceflood.UpdateCharge(FastDriver.Insuranceflood.FloodChargesTable, "Flood Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creates an instance of Earthquake Insurance";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                FastDriver.InsuranceEarth.EarthName.FASetText(@"Ronald M. Hankin");
                FastDriver.InsuranceEarth.EarthFind.FAClick();
                FastDriver.InsuranceEarth.UpdateCharge(FastDriver.InsuranceEarth.EarthChargesTable, "Earthquake Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creates the Wind Insurance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                FastDriver.InsuranceWind.WindName.FASetText(@"Accubanc Mortgage Corporation");
                FastDriver.InsuranceWind.WindFind.FAClick();
                FastDriver.InsuranceWind.FindUnderwriterGAB(@"247");
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText(@"100.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create an instance of Other Insurance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherName.FASetText(@"Good House Hunter Co.");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                FastDriver.InsuranceOther.OthertextReference.FASetText(@"ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText(@"Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText(@"UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText(@"10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText(@"5");
                FastDriver.InsuranceOther.UpdateCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, editDescription: @"Insurance Premium Description");
                FastDriver.InsuranceOther.OtherGFE11.FASetText(@"25.00");
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText(@"555.00");
                FastDriver.InsuranceOther.OtherFromDate.FASetText(@"07-19-2012");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherToDate.FASetText(@"07-19-2013");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    Playback.Wait(500);
                    FastDriver.UtilityDetail.ProrationDescription.FireEvent("onfocus");
                    FastDriver.UtilityDetail.ProrationDescription.Click();
                    Playback.Wait(500);
                    Keyboard.SendKeys("");
                    Playback.Wait(500);
                    this.SlowSetText("Proration Description");
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);
                    return FastDriver.UtilityDetail.ProrationDescription.FAGetValue().Clean() == "Proration Description";
                }, timeout: 120, idleInterval: 5);
                Support.AreEqual(@"Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "New Lease details";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode(@"Lease");
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.ChargeTable, "Rent/Lease Payment Due", buyerCharge: 10.00, sellerCharge: 10.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creates a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode(@"HUDATASTL1");
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscellaneousDisbursementBuyerSellerChargesTable, "", editDescription: "Disbursemen2");
                //Payment details
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"50.00");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"50.00");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem(@"POC");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(@"50.00");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"50.00");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem(@"POC");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Support.AreEqual(@"Check Amount: $ 50.00", FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creates a New loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode(@"247");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456");

                Reports.TestStep = "Loan Charges Tab GFE 3";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge);
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FASetText(@"10");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FASetText(@"10");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesGFEAmount.FASetText(@"10");

                Reports.TestStep = "Loan Charges Tab GFE 6";
                if (!FastDriver.NewLoan.LenderCreditsTable.Displayed)
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCharge.FASetText(@"10");
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_SellerCharge.FASetText(@"10");
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_GFEAmount.FASetText(@"10");
                }
                else
                {
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCredit.FASetText(@"10");
                    if (!FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_SellerCredit.IsReadOnly())
                        FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_SellerCredit.FASetText(@"10");
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_GFEAmount.FASetText(@"10");
                }

                Reports.TestStep = "Loan Charges Tab GFE 7";
                if (!FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.Displayed)
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderBuyerCharge.FASetText(@"10");
                if (!AutoConfig.UseCDFormType)
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText(@"10");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247", WaitForGabCodeLabel: false);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", buyerCharge: 200);

                Reports.TestStep = "Create a new Utility Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"HUDUTLCMP1");
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities", buyerCharge: 50.00, sellerCharge: 50.00, editDescription: "Utility Charge");
                FastDriver.BottomFrame.Done();

                #endregion

                #region FMUC0003_REG0065_B

                Reports.TestStep = "Enter charges to Payoff loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"247", WaitForGabCodeLabel: false);
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"200");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.LoanChargesTable, "Principal Balance", buyerCharge: 100, sellerCharge: 100);
                //Payoff Loan charges section
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 50, sellerCharge: 50,
                    buyerCredit: 50, sellerCredit: 50, editDescription: @"Payoff Loan Charges Description");
                //Payoff Loan Parties tab
                FastDriver.PayoffLoanCharges.ClickPartiesTab().WaitForScreeToLoan();
                FastDriver.PayoffLoanParites.TrustorMortgagor.FASetText(@"Seller1Firstname Seller1Lastname and Seller2Firstname Seller2Lastname and Seller2Spouse Seller2Lastname");
                FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FASetText(@"Lenders Advantage, A Division Of First American Title Ins.");
                FastDriver.PayoffLoanParites.FindGABCode(@"223", WaitForGabCodeLabel: false);
                //Recording tab
                FastDriver.PayoffLoanParites.ClickRecordingTab().WaitForScreeToLoan();
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FASetText(TrustDeedDate);
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FASetText(RecordingDate);
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FASetText(@"24");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FASetText(@"Book1");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FASetText(@"Page1");

                Reports.TestStep = "Enters REB Broker disbursement.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB(@"247", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"200");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();
                FastDriver.RealEstateBrokerAgent.FindDisbursementGAB(@"255", waitForElementDisplayed: false);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"100");
                //Commission paid at settlement
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText(@"50.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@"50.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                //REB Charges
                if (!FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, "", buyerCharge: 50, sellerCharge: 50, editDescription: @"REB Charges Desc");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Outside Escrow Company details.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB(@"HUDOUTESC1", false);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription1", buyerCharge: 50, sellerCharge: 50);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creates 2nd order without Buyer and Seller";
                Reports.TestStep = "Creates Second Order with Buyer and Seller with FasttsFastqa07  user";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(@"HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Default-Residential");
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(!AutoConfig.UseCDFormType);
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Multi Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"2ndFileLot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"2ndFileBlock1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"2ndFileUnit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN2");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845019999");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"BUTTE");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Captures the 2nd file number";
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                #endregion

                #region FMUC0003_REG0065_C

                Reports.TestStep = "Attorney Buyer";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
                Support.AreEqual(@"HUDBUYATT1", FastDriver.AttorneyDetail.GABcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"50.00", FastDriver.AttorneyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.AttorneyDetail.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Attorney- Primary", FastDriver.AttorneyDetail.Type.FAGetSelectedItem().Clean());

                Reports.TestStep = "Attorney Seller";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                Support.AreEqual(@"ATTBUY3", FastDriver.AttorneyDetail.GABcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"10.10", FastDriver.AttorneyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"20.20", FastDriver.AttorneyDetail.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Attorney- Primary", FastDriver.AttorneyDetail.Type.FAGetSelectedItem().Clean());

                Reports.TestStep = "Assumption Loan - Details tab";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                Support.AreEqual(@"HUDASLNDR1", FastDriver.AssumptionLoanDetails.GABcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"10.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Clean());
                Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanDetails.InterestPaidto.FAGetValue().Clean());
                Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanDetails.NextPaymentDue.FAGetValue().Clean());
                Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanDetails.NotedDate.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Clean());
                Support.AreEqual(@"200.00", FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue().Clean());
                Support.AreEqual(@"Interest only", FastDriver.AssumptionLoanDetails.PaymentType.FAGetSelectedItem().Clean());
                Support.AreEqual(@"Month", FastDriver.AssumptionLoanDetails.PaymentPer.FAGetSelectedItem().Clean());

                Reports.TestStep = "Assumption Loan - Validates charges in Charges Tab.";
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                Support.AreEqual(@"Changed Description", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FAGetValue().Clean());
                //Support.AreEqual(@"500.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.FAGetValue().Clean());

                Reports.TestStep = "Assumption Loan - Record Tab Verification.";
                FastDriver.AssumptionLoanParties.SwitchToContentFrame();
                FastDriver.AssumptionLoanParties.clickRecordingTab().WaitForScreeToLoan();
                Support.AreEqual(@"08-22-2012", FastDriver.AssumptionLoanRecording.TrustDeedDate.FAGetValue().Clean());
                Support.AreEqual(@"08-22-2012", FastDriver.AssumptionLoanRecording.RecordingDate.FAGetValue().Clean());
                Support.AreEqual(@"Instrument", FastDriver.AssumptionLoanRecording.Instrument.FAGetValue().Clean());
                Support.AreEqual(@"Book", FastDriver.AssumptionLoanRecording.Book.FAGetValue().Clean());
                Support.AreEqual(@"page", FastDriver.AssumptionLoanRecording.Page.FAGetValue().Clean());

                Reports.TestStep = "Verifies the Homeowner Association instance.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                Support.AreEqual(@"247", FastDriver.HomeownerAssociation.IDCodeText.FAGetText().Clean());
                Support.AreEqual(@"10.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue().Clean());
                Support.AreEqual(@"MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem().Clean());
                //Association Charges
                Support.AreEqual(@"4.00", FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"2.00", FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FAGetValue().Clean());
                //Management Charges
                Support.AreEqual(@"4.50", FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"2.50", FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.FAGetValue().Clean());
                //Pro ration
                Support.AreEqual(@"", FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.HomeownerAssociation.FromDate.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.HomeownerAssociation.ToDate.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.HomeownerAssociation.ProrationBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.HomeownerAssociation.ProrationSellerCredit.FAGetValue().Clean());

                Reports.TestStep = "Verifies Home Warranty page";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                Support.AreEqual(@"HW1", FastDriver.HomeWarrantyDetail.IDCodeText.FAGetText().Clean());
                Support.AreEqual(@"HW name 1", FastDriver.HomeWarrantyDetail.GABname.FAGetText().Clean());
                Support.AreEqual(@"10.00", FastDriver.HomeWarrantyDetail.PolicyCharge.FAGetValue().Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"2.00", FastDriver.HomeWarrantyDetail.paidSeller.FAGetValue().Clean());
                    Support.AreEqual(@"2.00", FastDriver.HomeWarrantyDetail.PaidBuyer.FAGetValue().Clean());
                }

                Support.AreEqual(@"2.00", FastDriver.HomeWarrantyDetail.Amount.FAGetValue().Clean());
                Support.AreEqual(DateTime.Today.AddDays(1).ToDateString().ToString(), FastDriver.HomeWarrantyDetail.FromDate.FAGetValue().Clean());
                Support.AreEqual(DateTime.Today.AddDays(2).ToDateString().ToString(), FastDriver.HomeWarrantyDetail.ToDate.FAGetValue().Clean());
                Support.AreEqual(@"True", FastDriver.HomeWarrantyDetail.InclusiveFrom.Selected.ToString(), "Verify whether 'InclusiveFrom' checkbox is checked.");
                Support.AreEqual(@"True", FastDriver.HomeWarrantyDetail.InclusiveTo.Selected.ToString(), "Verify whether 'InclusiveTo' checkbox is checked.");
                Support.AreEqual(@"Early Coverage Charge Description", FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Sanity-Home Warranty", FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FAGetValue().Clean());
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Verifies Inspection Repair/Pest";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                Support.AreEqual(@"Pest 1 for HUD Testing Name 1", FastDriver.InspectionRepairPest.INSP_Pest_LenderName.FAGetText().Clean());
                Support.AreEqual(@"Contact, Pest 1 for HUD", FastDriver.InspectionRepairPest.Attention.FAGetSelectedItem().Clean());
                Support.AreEqual(@"Reference1", FastDriver.InspectionRepairPest.Reference.FAGetValue().Clean());
                Support.AreEqual(@"5", FastDriver.InspectionRepairPest.WithinDays.FAGetValue().Clean());
                Support.AreEqual(@"07-10-2012", FastDriver.InspectionRepairPest.OrderDate.FAGetValue().Clean());
                Support.AreEqual(@"12-10-2012", FastDriver.InspectionRepairPest.DueDate.FAGetValue().Clean());
                Support.AreEqual(@"10-10-2012", FastDriver.InspectionRepairPest.FollowUpDate.FAGetValue().Clean());
                Support.AreEqual(@"04-10-2013", FastDriver.InspectionRepairPest.CompleteDate.FAGetValue().Clean());
                Support.AreEqual(@"03-10-2013", FastDriver.InspectionRepairPest.ReportDate.FAGetValue().Clean());
                Support.AreEqual(@"PESTDESCRIPTION1", FastDriver.InspectionRepairPest.description.FAGetValue().Clean());
                Support.AreEqual(@"55.55", FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"66.66", FastDriver.InspectionRepairPest.SellerCharge.FAGetValue().Clean());

                Reports.TestStep = "Verifies the instance of Inspection Repair Septic.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();
                Support.AreEqual(@"HUDPEST001", FastDriver.InspectionRepairSeptic.GABcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"Contact, Pest 1 for HUD", FastDriver.InspectionRepairSeptic.Attention.FAGetSelectedItem().Clean());
                Support.AreEqual(@"Reference1", FastDriver.InspectionRepairSeptic.Reference.FAGetValue().Clean());
                Support.AreEqual(@"5", FastDriver.InspectionRepairSeptic.WithinDays.FAGetValue().Clean());
                Support.AreEqual(@"07-10-2012", FastDriver.InspectionRepairSeptic.OrderDate.FAGetValue().Clean());
                Support.AreEqual(@"12-10-2012", FastDriver.InspectionRepairSeptic.DueDate.FAGetValue().Clean());
                Support.AreEqual(@"10-10-2012", FastDriver.InspectionRepairSeptic.FollowUpDate.FAGetValue().Clean());
                Support.AreEqual(@"04-10-2013", FastDriver.InspectionRepairSeptic.CompleteDate.FAGetValue().Clean());
                Support.AreEqual(@"03-10-2013", FastDriver.InspectionRepairSeptic.ReportDate.FAGetValue().Clean());
                Support.AreEqual(@"SEPTICInspectionDESCRIPTION1", FastDriver.InspectionRepairSeptic.description.FAGetValue().Clean());
                Support.AreEqual(@"55.55", FastDriver.InspectionRepairSeptic.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"66.66", FastDriver.InspectionRepairSeptic.SellerCharge.FAGetValue().Clean());

                #endregion

                #region FMUC0003_REG0065_D

                Reports.TestStep = "Verifies an instance of inspection Repair Others.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                Support.AreEqual(@"Pest 1 for HUD Testing Name 1", FastDriver.InspectionRepairOther.INSP_Others_LenderName.FAGetText().Clean());
                Support.AreEqual(@"Reference1", FastDriver.InspectionRepairOther.Reference.FAGetValue().Clean());
                Support.AreEqual(@"5", FastDriver.InspectionRepairOther.WithinDays.FAGetValue().Clean());
                Support.AreEqual(@"07-10-2012", FastDriver.InspectionRepairOther.OrderDate.FAGetValue().Clean());
                Support.AreEqual(@"12-10-2012", FastDriver.InspectionRepairOther.DueDate.FAGetValue().Clean());
                Support.AreEqual(@"10-10-2012", FastDriver.InspectionRepairOther.FollowUpDate.FAGetValue().Clean());
                Support.AreEqual(@"04-10-2013", FastDriver.InspectionRepairOther.CompleteDate.FAGetValue().Clean());
                Support.AreEqual(@"03-10-2013", FastDriver.InspectionRepairOther.ReportDate.FAGetValue().Clean());
                Support.AreEqual(@"OTHERInspectionDESCRIPTION1", FastDriver.InspectionRepairOther.description.FAGetValue().Clean());
                Support.AreEqual(@"55.55", FastDriver.InspectionRepairOther.buyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"66.66", FastDriver.InspectionRepairOther.sellerCharge.FAGetValue().Clean());

                Reports.TestStep = "Verifies the Fire Insurance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.TrusteeName1.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.InsuranceFire.FireBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"200.55", FastDriver.InsuranceFire.FireSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireAmount.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireFromDate.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireToDate.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireBuyerCharge1.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceFire.FireSellerCredit1.FAGetValue().Clean());

                Reports.TestStep = "Verifies Flood Insurance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.InsuranceCompanyName1.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                Support.AreEqual(@"Insurance CompanyName 1", FastDriver.Insuranceflood.NameLabel.FAGetText().Clean());
                Support.AreEqual(@"100.00", FastDriver.Insuranceflood.FloodBuyercharge.FAGetValue().Clean());
                Support.AreEqual(@"200.55", FastDriver.Insuranceflood.FloodSellerCharge.FAGetValue().Clean());

                Reports.TestStep = "Verifies an instance of Earthquake Insurance";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.RonaldHankin.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.InsuranceEarth.EarthBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"200.55", FastDriver.InsuranceEarth.EarthSellerCharge.FAGetValue().Clean());

                Reports.TestStep = "Verifies Wind Insurance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.LendersAdvantage.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.InsuranceWind.WindBuyerCharge.FAGetValue().Clean());

                Reports.TestStep = "Verifies Other Insurance";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.InsuranceCompany.FAClick();
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual(@"ReferenceINS1", FastDriver.InsuranceOther.OthertextReference.FAGetValue().Clean());
                Support.AreEqual(@"UWREFERENCE1", FastDriver.InsuranceOther.OtherReferenceUnderwriter.FAGetValue().Clean());
                Support.AreEqual(@"10,500.00", FastDriver.InsuranceOther.OthertextPremium.FAGetValue().Clean());
                Support.AreEqual(@"5", FastDriver.InsuranceOther.OthertextTerm.FAGetValue().Clean());
                Support.AreEqual(@"Insurance Premium Description", FastDriver.InsuranceOther.OtherInsuranceChargeDescription.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.InsuranceOther.OtherBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"200.55", FastDriver.InsuranceOther.OtherSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"25.00", FastDriver.InsuranceOther.OtherGFE11.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.InsuranceOther.OtherCreditSeller.Selected.ToString(), "Verify whether 'OtherCreditSeller' checkbox is unchecked.");
                Support.AreEqual(@"False", FastDriver.InsuranceOther.OtherDayofClose.Selected.ToString(), "Verify whether 'OtherDayofClose' checkbox is unchecked.");
                Support.AreEqual(@"", FastDriver.InsuranceOther.OtherAmount.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.InsuranceOther.OtherFromDate.FAGetValue().Clean());
                Support.AreEqual(@"True", FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString(), "Verify whether 'OtherfromInclusive' checkbox is checked.");
                Support.AreEqual(@"", FastDriver.InsuranceOther.OtherToDate.FAGetValue().Clean());
                Support.AreEqual(@"False", FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString(), "Verify whether 'OthertoInclusive' checkbox is checked.");

                Reports.TestStep = "verify Lease Instance.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                Support.AreEqual(@"Rent/Lease Payment Due", FastDriver.LeaseDetail.ChargeDescription.FAGetValue().Clean());
                Support.AreEqual(@"LEASE", FastDriver.LeaseDetail.IDCodeLebel.FAGetText().Clean());
                Support.AreEqual(@"10.00", FastDriver.LeaseDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.LeaseDetail.SellerCharge.FAGetValue().Clean());

                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual(@"Disbursemen2", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual(@"HUDATASTL1", FastDriver.MiscDisbursementDetail.IDCode.FAGetText().Clean());
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(@"$50.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"$50.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"POC", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FAGetSelectedItem().Clean());
                }
                else
                {
                    Support.AreEqual(@"$50.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Clean());
                    Support.AreEqual(@"$50.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Clean());
                    Support.AreEqual(@"POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Clean());
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Validates Utility Screen.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                Support.AreEqual(@"Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().Clean());

                Reports.TestStep = "Validate the loan entered.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                Support.AreEqual(@"247", FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText().Clean());
                var value = FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem().Clean();
                if (value == null)
                    value = "";
                Support.AreEqual(@"Small Loan", value);
                Support.AreEqual(@"300,000,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().Clean());
                //Loan Charges tab
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge);
                Support.AreEqual(@"10.00", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesGFEAmount.FAGetValue().Clean());
                //GFE 6
                if (!FastDriver.NewLoan.LenderCreditsTable.Displayed)
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"10.00", FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"10.00", FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_SellerCharge.FAGetValue().Clean());
                    Support.AreEqual(@"10.00", FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_GFEAmount.FAGetValue().Clean());
                }
                else
                {
                    Support.AreEqual(@"10.00", FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCredit.FAGetValue().Clean());
                    if (!FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_SellerCredit.IsReadOnly())
                        Support.AreEqual(@"10.00", FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_SellerCredit.FAGetValue().Clean());
                    Support.AreEqual(@"10.00", FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_GFEAmount.FAGetValue().Clean());
                }

                Reports.TestStep = "verify an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                Support.AreEqual(@"247", FastDriver.SurveyDetail.IDcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"200.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());

                Reports.TestStep = "Validates Payoff loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                Support.AreEqual(@"247", FastDriver.PayoffLoanDetails.GABcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"$200.00", FastDriver.PayoffLoanDetails.PrincipalBalanceAmt.FAGetText().Clean());
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"Payoff Loan Charges Description", FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit.FAGetValue().Clean());
                //Parties tab
                FastDriver.PayoffLoanCharges.ClickPartiesTab().WaitForScreeToLoan();
                Support.AreEqual(@"223", FastDriver.PayoffLoanParites.TrusteeGABcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"Seller1Firstname Seller1Lastname and Seller2Firstname Seller2Lastname and Seller2Spouse Seller2Lastname", FastDriver.PayoffLoanParites.TrustorMortgagor.FAGetValue().Clean());
                Support.AreEqual(@"Lenders Advantage, A Division Of First American Title Ins.", FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FAGetValue().Clean());
                //Recording tab
                FastDriver.PayoffLoanParites.ClickRecordingTab().WaitForScreeToLoan();
                Support.AreEqual(TrustDeedDate, FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FAGetValue().Clean());
                Support.AreEqual(RecordingDate, FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FAGetValue().Clean());
                Support.AreEqual(@"24", FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FAGetValue().Clean());
                Support.AreEqual(@"Book1", FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FAGetValue().Clean());
                Support.AreEqual(@"Page1", FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FAGetValue().Clean());

                Reports.TestStep = "Validates REB Broker disbursement.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.LendersAdvantage.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                Support.AreEqual(@"247", FastDriver.RealEstateBrokerAgent.IDCode.FAGetText().Clean());
                Support.AreEqual(@"255", FastDriver.RealEstateBrokerAgent.BrokerDisbursementGABCodeLabel.FAGetText().Clean());
                Support.AreEqual(@"100.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"REB Charges Desc", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().Clean());

                Reports.TestStep = "Outside Escrow Company details.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                Support.AreEqual(@"HUDOUTESC1", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText().Clean());
                Support.AreEqual(@"OECChargeDescription1", FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());

                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0065_A()
        {
            try
            {
                Reports.TestDescription = "FM1911_Settlement Info Data Group - Insurance Fire, Wind, Earthquake, New Loan,New Lease,Misc Disbursements,Utilities.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0065.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0065_B()
        {
            try
            {
                Reports.TestDescription = "FM1911_Settlement Info Data Group - Payoff,REB Broker,OEC";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0065.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0065_C()
        {
            try
            {
                Reports.TestDescription = "FM1911 - Validations - Attorney Buyer,Seller,Assumption Loan,Homeowner Association,Home Warraty,Inspection Pest,Repair Septic";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC003_REG0065.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0065_D()
        {
            try
            {
                Reports.TestDescription = "FM1911 - Validations - Inspection REpair Others, Insurance Fire,Wind,Earthquake, New Loan,New Lease,Misc Disbursements,Utilities,Assumption Load,Payoff,REB Broker,OEC";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.StatusUpdate("This TC was merged with FMUC0003_REG0065.", true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0066()
        {
            try
            {
                Reports.TestDescription = "FM6835_Copying Charges";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creates First Order with Buyer and Seller";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Captures the 1st file number";
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "New Lease details";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode(@"Lease");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText(@"Rent/Lease Payment Due");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"13.00");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"13.00");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem(@"POC-B");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"13.00");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(@"13.00");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(@"POC-L");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deposits Cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText(@"100.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(@"Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem(@"Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText(@"Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(@"Buyer");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Clicks on Print button. Where amount is 13.00";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "13.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItem(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verifies on Lease screen for the issued image/icon";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.LeaseDetail.VerifyImageExists(@"ico_checkissued.gif").ToString(), "Verify whether img 'checkissued' exists.");

                Reports.TestStep = "Creates Second Order with Buyer and Seller";
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Captures the 2nd file number";
                var FileNum2 = File.FileNumber;

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Validating the Lease has Pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                var value = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "13.00", "Status", TableAction.GetText).Message.Clean();
                if (value == "Pending")
                    Reports.StatusUpdate("Lease related Charge Amount 13.00 was found as Pending status", true);
                else
                    Reports.StatusUpdate("Lease related Charge Amount 13.00 was not found as Pending status", false);
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                    Support.AreEqual(@"POC-B", FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FAGetSelectedItem());
                else
                    Support.AreEqual(@"POC-L", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0003_REG0067()
        {
            try
            {
                Reports.TestDescription = "Login - FM6922_FM13422 - Verify 1099-S Records on Target File, Starter Ref behavior for Project/Site/ Normal file combinations";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Creates First Order with Buyer and Seller";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Captures the 1st file number";
                var FileNum1 = File.FileNumber;

                Reports.TestStep = "FM6922_Creates the 2nd file as Project File";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(@"HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.ProjectFile.FASetCheckbox(true);
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(!AutoConfig.UseCDFormType);
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Default-Residential");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Multi Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"2ndFileLot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"2ndFileBlock1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"2ndFileUnit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN2");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845019999");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"BUTTE");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Captures the Second file number";
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Verifies whether or not the error message is generated.";
                var value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("Error(s)"))
                {
                    Reports.StatusUpdate("As expected, Normal File was not copied into Project File", true);
                }
                else if (value.Contains("overwritten"))
                {
                    Reports.StatusUpdate("Did not get the expected error popup.", false);
                }
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Error: Cannot copy from Non Project/Site file to a Project/Site file.", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                Reports.TestStep = "FM13422_Creates  the 2nd file as Master File";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(@"HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.UseAsMasterFile.FASetCheckbox(true);
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(!AutoConfig.UseCDFormType);
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Default-Residential");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Multi Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"2ndFileLot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"2ndFileBlock1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"2ndFileUnit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN2");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845019999");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"2ndFileJ305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"2ndFileJJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"BUTTE");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Starter ref screen & copy all.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FileNum1);
                FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();

                Reports.TestStep = "Verifies whether or not the error message is generated.";
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("Error(s)"))
                {
                    Reports.StatusUpdate("As expected, Normal File was not copied into Project File", true);
                }
                else if (value.Contains("overwritten"))
                {
                    Reports.StatusUpdate("Did not get the expected error popup.", false);
                }
                FastDriver.StarterReference.WaitForScreenToLoad();
                Support.AreEqual(@"Can not copy to a File that has been designated as a Master File.", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Custom Class Methods

        private bool VerifyFileExistence(string FileNo, FileStatus status = FileStatus.Open)
        {
            FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
            FastDriver.FileSearch.Numbers.FASetText(FileNo);
            FastDriver.FileSearch.Country.FASelectItem("USA");
            if (status == FileStatus.Pending)
            {
                FastDriver.FileSearch.PendingOrderSearch.FAClick();
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
            }
            Thread.Sleep(5000);
            FastDriver.FileSearch.FindNow.FAClick();
            Thread.Sleep(10000);
            var value = FastDriver.WebDriver.HandleDialogMessage(false, true, timeout: 60).Clean();
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
            if (value == "No match found.")
                return false;
            else
                return true;

        }

        private void CreateMasterFileREG0001(bool isExist)
        {
            #region data setup

            var value = "";

            #endregion

            Reports.TestStep = "Create Order";
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
            //FastDriver.QuickFileEntry.CreateDetailedFile(FileName: isExist ? Support.RandomString("AAAZZZFRR") : "REG01-F1");
            if (!isExist)
                FastDriver.QuickFileEntry.CreateDetailedFile(FileName: "REG01-F1");
            else
                FastDriver.TopFrame.SearchFileByFileNumber("REG01-F1");

            Reports.TestStep = "Select Data Groups to Copy. Validating all data groups availability";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            Support.AreEqual(@"True", FastDriver.StarterReference.SelectFileItems.Displayed.ToString(), "'Select File Items' checkbox is present.");
            Support.AreEqual(@"True", FastDriver.StarterReference.BusinessSource.Displayed.ToString(), "'Business Source' checkbox is present.");
            Support.AreEqual(@"True", FastDriver.StarterReference.Products.Displayed.ToString(), "'Products' checkbox is present.");
            Support.AreEqual(@"True", FastDriver.StarterReference.PropertyAddressLegalTaxInformation.Displayed.ToString(), "'Property Address Legal Tax Info' checkbox is present.");
            Support.AreEqual(@"True", FastDriver.StarterReference.BuyersData.Displayed.ToString(), "'Buyers Data' checkbox is present.");
            Support.AreEqual(@"True", FastDriver.StarterReference.SellersData.Displayed.ToString(), "'Sellers Data' checkbox is present.");
            Support.AreEqual(@"True", FastDriver.StarterReference.MaketheBuyersastheSellers.Displayed.ToString(), "'Make Buyer as the Seller' checkbox is present.");
            Support.AreEqual(@"True", FastDriver.StarterReference.Notes.Displayed.ToString(), "'Notes' checkbox is present.");
            Support.AreEqual(@"True", FastDriver.StarterReference.SettlementInformation.Displayed.ToString(), "'Settlement Information' checkbox is present.");

            #region FMUC0003_REG0002

            Reports.TestStep = "Enter Estimated days to close.";
            FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
            if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday")
                value = (7 + 3).ToString();
            else
                value = "7";
            FastDriver.TermsDatesStatus.EstimattedDaysToClose.FASetText(value + FAKeys.Tab);

            Reports.TestStep = "Click on Cancel button.";
            FastDriver.WebDriver.HandleDialogMessage(false, false, 10);

            Reports.TestStep = "Click on Cancel button.";
            FastDriver.WebDriver.HandleDialogMessage(true, false, 10);

            Reports.TestStep = "Click on Done.";
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Add Tax Information.";
            FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
            FastDriver.PropertiesSummary.Edit.FAClick();
            Playback.Wait(2000);
            FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad(FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName);
            FastDriver.PropertyTaxInfoGeneral.GeneralTab.FAClick();
            FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad().GeneralComments.FASetText(@"This Property Belongs To FAI" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();
            Playback.Wait(2000);
            FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
            FastDriver.PropertyTaxInfoLegalDesciption.Phase.FASetText(@"Phase1" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoLegalDesciption.GovtLotNo.FASetText(@"GovtLot" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoLegalDesciption.RecordingBook.FASetText(@"First" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoLegalDesciption.RecordingPage.FASetText(@"First" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapNo.FASetText(@"First" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoLegalDesciption.AbbrLegalDesciptionComments.FASetText(@"Abbreviated Legal Description" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoLegalDesciption.CompleteLegalDescriptionComments.FASetText(@"Complete Legal Description" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoLegalDesciption.ClickTaxTab();
            Playback.Wait(2000);
            FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
            FastDriver.PropertyTaxInfoAnnualTax.Summarytable1.PerformTableAction("TaxYear", "2006-2007", "TaxYear", TableAction.Click);
            Playback.Wait(250);
            FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
            Support.AreEqual(@"9845012345", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FAGetValue().Clean());
            Support.AreEqual(@"2006-2007", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FAGetValue().Clean());
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus1.FASelectItem(@"PAYABLE");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASetText(@"500" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPenality1.FASetText(@"500.00" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxpartialPaymentAmount1.FASetText(@"500.00" + FAKeys.Tab);
            Support.AreEqual(@"500.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxBalanceDue1.FAGetValue().Clean());
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue1.FASetText(@"500.00" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue1.FASetText(@"500.00" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue1.FASetText(@"500.00" + FAKeys.Tab);
            Support.AreEqual(@"1,000.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxNetValue1.FAGetValue().Clean());
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner1.FASetText(@"500.00" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther11.FASetText(@"500.00" + FAKeys.Tab);
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.FASetText(@"500.00" + FAKeys.Tab);
            FastDriver.BottomFrame.Save();

            #endregion

            #region FMUC0003_REG0003

            Reports.TestStep = "Enter charges to New loan.";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
            FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000000" + FAKeys.Tab);
            Keyboard.SendKeys("{ENTER}");
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.FindGABCode(@"247");

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage(true, true, 30);
            FastDriver.NewLoan.WaitForScreenToLoad().ClickRecapTab().WaitForRecapToLoad();

            Reports.TestStep = "Validate the loan charge entered.";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
            value = FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Small Loan", value);
            Support.AreEqual(@"300,000,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().Clean());

            Reports.TestStep = "Create Payoff loan instance with details in all tabs for starter file.";
            FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
            FastDriver.PayoffLoanDetails.FindGABCode(@"247", WaitForGabCodeLabel: false);
            value = FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Institutional", value);
            FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"200.00" + FAKeys.Tab);
            FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
            FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.LoanChargesTable, "", buyerCharge: 100.00, sellerCharge: 100.00);
            FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItem(@"Fixed Rate");
            FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FASetText(@"10.000000" + FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
            FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"09-17-2012");
            FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"09-21-2012" + FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
            Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue().Clean());
            FastDriver.PayoffLoanDetails.SwitchToContentFrame();
            FastDriver.PayoffLoanDetails.ClickRecordingTab().WaitForScreeToLoan();
            FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FASetText(@"09-13-2012");
            FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FASetText(@"09-13-2012");
            FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FASetText(@"12345");
            FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FASetText(@"3");
            FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FASetText(@"2");
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Validate charges entered";
            FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
            Support.AreEqual(@"200.00", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().Clean());
            FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
            Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"100.00", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().Clean());

            #endregion

            #region FMUC0003_REG0004

            //Reports.TestStep = "Save the file.";
            //var FileNum1 = FastDriver.TopFrame.GetFileNumber();
            //REG0001_FileNum1 = FastDriver.TopFrame.GetFileNumber();

            Reports.TestStep = "FM6865_Enter an instance for the Starter file with all details in all Tabs.";
            FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
            FastDriver.AssumptionLoanDetails.FindGABCode(@"HUDASLNDR1", WaitForGabCodeLabel: false);
            FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
            FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText(@"300.00" + FAKeys.Tab);
            FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText(@"06-04-2012");
            FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText(@"06-04-2012");
            FastDriver.AssumptionLoanDetails.NotedDate.FASetText(@"06-04-2012");
            FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText(@"500.00");
            FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText(@"50.00");
            FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem(@"Interest only");
            FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem(@"Month");
            FastDriver.AssumptionLoanDetails.MaturityDate.FASetText(DateTime.Now.ToUniversalTime().AddHours(-8).AddDays(5).ToDateString());
            FastDriver.AssumptionLoanDetails.LateCharge.FASetCheckbox(true);
            FastDriver.AssumptionLoanDetails.LateChargePercentage.FASetText(@"2");
            FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText(@"30");
            //Charges tab
            FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
            FastDriver.AssumptionLoanCharges.UpdateCharge(FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesTable, "Unpaid Principal Balance", buyerCredit: 300.00);
            if (FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.IsReadOnly())
                FastDriver.AssumptionLoanCharges.UpdateCharge(FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesTable, "Unpaid Principal Balance", sellerCharge: 300.00);
            if (FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCharge.Enabled)
                FastDriver.AssumptionLoanCharges.UpdateCharge(FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesTable, "Unpaid Principal Balance", buyerCharge: 300.00);
            //Prorate
            FastDriver.AssumptionLoanCharges.InterestProrationInterestType.FASelectItem(@"Fixed Rate");
            FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText(@"5.000000");
            FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FASetText(@"06-10-2010" + FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            FastDriver.AssumptionLoanCharges.UpdateCharge(FastDriver.AssumptionLoanCharges.InterestProrationTable, "", buyerCharge: 100.00, sellerCredit: 100.00);
            value = FastDriver.AssumptionLoanCharges.InterestProrationBasedonDays.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"365", value);
            FastDriver.AssumptionLoanCharges.InterestProrationToDate.FASetText(@"07-10-2011" + FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            Support.AreEqual(@"Assumption Loan Interest Proration", FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.FAGetValue().Clean());
            Support.AreEqual(@"1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FAGetValue().Clean());
            Support.AreEqual(@"1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FAGetValue().Clean());
            FastDriver.AssumptionLoanCharges.UpdateCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "", buyerCharge: 10.00, buyerCredit: 10.00, sellerCredit: 10.00, sellerCharge: 10.00);
            FastDriver.WebDriver.HandleDialogMessage();
            //Parties tab
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad().clickPartiesTab().WaitForScreeToLoan();
            //Support.AreEqual(@"True", (FastDriver.AssumptionLoanParties.TrustMortgagor.FAGetValue().Clean().Length > 2).ToString(), "'Trustor-Mortgagor (Borrower of Record)' Length is greater than 2" + " -> " + FastDriver.AssumptionLoanParties.TrustMortgagor.FAGetValue().Clean().Length.ToString());
            FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FASetText(@"Beneficiary Mortgagee One");
            FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FASetText(@"Assignee Mortgagee One");
            FastDriver.AssumptionLoanParties.FindGABCode(@"247");
            FastDriver.AssumptionLoanParties.clickRecordingTab().WaitForScreeToLoan();
            FastDriver.AssumptionLoanRecording.TrustDeedDate.FASetText(@"06-04-2012");
            FastDriver.AssumptionLoanRecording.RecordingDate.FASetText(@"06-04-2012");
            FastDriver.AssumptionLoanRecording.Instrument.FASetText(@"Instrument");
            FastDriver.AssumptionLoanRecording.Book.FASetText(@"Book");
            FastDriver.AssumptionLoanRecording.Page.FASetText(@"Page");
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Validate the charges entered.";
            FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
            Support.AreEqual(@"300.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Clean());
            Support.AreEqual(@"500.00", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Clean());
            FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
            Support.AreEqual(@"300.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Clean());
            //  Validates enabled or disabled
            if (!FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.IsReadOnly())
                Support.AreEqual(@"300.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.FAGetValue().Clean());

            Reports.TestStep = "Create an instance and enter only Commission amount.";
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            FastDriver.RealEstateBrokerAgent.FindGAB(@"HUDOTHRBR1", waitForElementDisplayed: false);
            FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"400" + FAKeys.Tab);

            Reports.TestStep = "FM6868_Creates a OEC Instance.";
            FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
            FastDriver.OutsideEscrowCompanyDetail.FindGAB(@"HUDOUTESC1", waitForValue: false);
            FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription1", buyerCharge: 50.00, sellerCharge: 50.00);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "FM6868_Validates a OEC Instance.";
            FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
            Support.AreEqual(@"HUDOUTESC1", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText().Clean());
            Support.AreEqual(@"Outside Escrow 1 for HUD Test Name 1", FastDriver.OutsideEscrowCompanyDetail.BusinessPartyNameField.FAGetText().Clean());
            Support.AreEqual(@"Buyer's Broker 1 business street 1, Buyer's Broker 1 business street 2", FastDriver.OutsideEscrowCompanyDetail.GABAddressLabel.FAGetText().Clean());
            Support.AreEqual(@"OECChargeDescription1", FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
            Support.AreEqual(@"True", (FastDriver.OutsideEscrowCompanyDetail.OECError.FAGetText().Clean().Length < 1).ToString(), "No error message present.");
            Support.AreEqual(@"Check Amount: $ 100.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.FAGetText().Clean());
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Create the Attorney.";
            FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
            FastDriver.AttorneyDetail.FindGABcode(@"HUDBUYATT1", waitForGabCodeLabel: false);
            FastDriver.AttorneyDetail.Type.FASelectItem(@"Attorney- Primary");
            FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", buyerCharge: 50.00, sellerCharge: 50.00);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Create Seller Attorney with Valid Data, Click on Done.";
            FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
            FastDriver.AttorneyDetail.FindGABcode(@"ATTBUY3", waitForGabCodeLabel: false);
            FastDriver.AttorneyDetail.Type.FASelectItem(@"Attorney- Primary");
            FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", buyerCharge: 10.1, sellerCharge: 20.2);
            FastDriver.BottomFrame.Done();

            #endregion
        }

        private void CreateMasterFileREG0004(bool isExist)
        {
            #region Data Setup

            var value = "";
            var maturityDate = DateTime.Now.ToUniversalTime().AddHours(-8).AddDays(5).ToDateString();

            #endregion

            Reports.TestStep = "Creates the Second Order with Buyer and Seller";
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
            //FastDriver.QuickFileEntry.CreateDetailedFile(FileName: isExist ? Support.RandomString("AAAZZZFRR") : "REG04-F1");
            if (!isExist)
                FastDriver.QuickFileEntry.CreateDetailedFile(FileName: "REG04-F1");
            else
                FastDriver.TopFrame.SearchFileByFileNumber("REG04-F1");

            Reports.TestStep = "Captures the second file number";
            var REG0004_FileNum1 = FastDriver.TopFrame.GetFileNumber();

            Reports.TestStep = "Copy Docs from source file.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG01-F1");
            FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
            Playback.Wait(2000);
            FastDriver.CopyDocuments.WaitForScreenToLoad();
            FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
            FastDriver.BottomFrame.Done();
            value = FastDriver.WebDriver.HandleDialogMessage(timeout: 20);
            if (value.Contains("Following image(s)"))
            {
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
            }
            Playback.Wait(2000);

            Reports.TestStep = "Copy File Items from source file.";
            FastDriver.StarterReference.WaitForScreenToLoad();
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "FM6865_Validation on the Details tab.";
            FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
            Support.AreEqual(@"Assumption", FastDriver.AssumptionLoanDetails.DetailsLoanType.FAGetSelectedItem());
            Support.AreEqual(@"HUDASLNDR1", FastDriver.AssumptionLoanDetails.GABcodeLabel.FAGetText().Clean());
            Support.AreEqual(@"Assumption Lender 1 for HUD Test Name 1", FastDriver.AssumptionLoanDetails.GABcodeName.FAGetText().Clean());
            Support.AreEqual(@"300.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Clean());
            Support.AreEqual(@"500.00", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Clean());
            Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanDetails.InterestPaidto.FAGetValue().Clean());
            Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanDetails.NextPaymentDue.FAGetValue().Clean());
            Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanDetails.NotedDate.FAGetValue().Clean());
            Support.AreEqual(@"500.00", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue().Clean());
            Support.AreEqual(@"Interest only", FastDriver.AssumptionLoanDetails.PaymentType.FAGetSelectedItem());
            Support.AreEqual(@"Month", FastDriver.AssumptionLoanDetails.PaymentPer.FAGetSelectedItem());
            if (maturityDate != FastDriver.AssumptionLoanDetails.MaturityDate.FAGetValue())
            {
                FastDriver.TopFrame.SearchFileByFileNumber("REG01-F1");
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime calculatedDate = Convert.ToDateTime(FastDriver.TermsDatesStatus.OpenDate.FAGetText().Clean());
                FastDriver.TopFrame.SearchFileByFileNumber(REG0004_FileNum1);
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                if (calculatedDate.AddDays(5).ToDateString() == FastDriver.AssumptionLoanDetails.MaturityDate.FAGetValue())
                    Support.AreEqual(calculatedDate.AddDays(5).ToDateString(), FastDriver.AssumptionLoanDetails.MaturityDate.FAGetValue().Clean(), "Check for 'Maturity Date' value.");
            }
            else
            {
                Support.AreEqual(maturityDate, FastDriver.AssumptionLoanDetails.MaturityDate.FAGetValue().Clean(), "Check for 'Maturity Date' value.");
            }
            Support.AreEqual(@"True", FastDriver.AssumptionLoanDetails.LateCharge.Selected.ToString(), "Verify if 'Late Charge' checkbox is checked.");
            Support.AreEqual(@"2.0000", FastDriver.AssumptionLoanDetails.LateChargePercentage.FAGetValue().Clean());
            Support.AreEqual(@"30", FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FAGetValue().Clean());

            //Charges tab
            Reports.TestStep = "Validations on the Charges tab.";
            FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            value = FastDriver.AssumptionLoanCharges.InterestProrationBasedonDays.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"365", value);
            Support.AreEqual(@"", FastDriver.AssumptionLoanCharges.InterestProrationToDate.FAGetValue().Clean());
            Support.AreEqual(@"Assumption Loan Interest Proration", FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.FAGetValue().Clean());
            Support.AreEqual(@"", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FAGetValue().Clean());
            Support.AreEqual(@"", FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FAGetValue().Clean());
            Support.AreEqual(@"", FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.FAGetValue().Clean());

            //Parties tab
            FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            FastDriver.AssumptionLoanParties.WaitForScreeToLoan();
            //Support.AreEqual(@"True", (FastDriver.AssumptionLoanParties.TrustMortgagor.FAGetValue().Clean().Length > 0).ToString(), "Value for Trustor-Mortgagor field.");
            Support.AreEqual(@"Beneficiary Mortgagee One", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue().Clean());
            Support.AreEqual(@"Assignee Mortgagee One", FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FAGetValue().Clean());
            Support.AreEqual(@"247", FastDriver.AssumptionLoanParties.TrusteeGABcodeLabel.FAGetText().Clean());

            //Recording tab
            FastDriver.AssumptionLoanParties.RecordingTab.FAClick();
            FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();
            Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanRecording.TrustDeedDate.FAGetValue().Clean());
            Support.AreEqual(@"06-04-2012", FastDriver.AssumptionLoanRecording.RecordingDate.FAGetValue().Clean());
            Support.AreEqual(@"Instrument", FastDriver.AssumptionLoanRecording.Instrument.FAGetValue().Clean());
            Support.AreEqual(@"Book", FastDriver.AssumptionLoanRecording.Book.FAGetValue().Clean());
            Support.AreEqual(@"Page", FastDriver.AssumptionLoanRecording.Page.FAGetValue().Clean());

            Reports.TestStep = "validating a OEC Instance.";
            FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
            Support.AreEqual(@"OECChargeDescription1", FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Validates Seller Attorney";
            FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
            Support.AreEqual(@"ATTBUY3", FastDriver.AttorneyDetail.GABcodeLabel.FAGetText().Clean());
            Support.AreEqual(@"10.10", FastDriver.AttorneyDetail.BuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"20.20", FastDriver.AttorneyDetail.SellerCharge.FAGetValue().Clean());

            Reports.TestStep = "Validates Buyer Attorney";
            FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
            Support.AreEqual(@"HUDBUYATT1", FastDriver.AttorneyDetail.GABcodeLabel.FAGetText().Clean());
            Support.AreEqual(@"Attorney- Primary", FastDriver.AttorneyDetail.Type.FAGetSelectedItem());
            Support.AreEqual(@"50.00", FastDriver.AttorneyDetail.BuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.AttorneyDetail.SellerCharge.FAGetValue().Clean());

            #region FMUC0003_REG0005

            Reports.TestStep = "Create new OTC instance.";
            FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
            FastDriver.OutsideTitleCompanyDetail.FindGAB(@"814");
            FastDriver.OutsideTitleCompanyDetail.DipStatusCode.FASelectItem(@"0-Best Evidence");
            FastDriver.OutsideTitleCompanyDetail.FundsDepositedEdit.FASetText(@"250.00" + FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
            FastDriver.OutsideTitleCompanyDetail.TypeSelect.FASelectItem(@"Attorney");
            FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, "Title - Title Examination", buyerCharge: 10.00, sellerCharge: 20.00);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
            Support.AreEqual(@"$ 220.00", FastDriver.OutsideTitleCompanyDetail.FundsDue.FAGetText().Clean());
            Support.AreEqual(@"$ 30.00", FastDriver.OutsideTitleCompanyDetail.TotalCharges.FAGetText().Clean());
            Support.AreEqual(@"$ 250.00", FastDriver.OutsideTitleCompanyDetail.FundsDeposited.FAGetText().Clean());
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Verify new OTC instance.";
            FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
            value = FastDriver.OutsideTitleCompanyDetail.DipStatusCode.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"0-Best Evidence", value);
            Support.AreEqual(@"250.00", FastDriver.OutsideTitleCompanyDetail.FundsDepositedEdit.FAGetValue().Clean());
            value = FastDriver.OutsideTitleCompanyDetail.TypeSelect.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Attorney", value);
            Support.AreEqual(@"10.00", FastDriver.OutsideTitleCompanyDetail.TitleServiceBuyerCharge1.FAGetValue().Clean());
            Support.AreEqual(@"20.00", FastDriver.OutsideTitleCompanyDetail.TitleServiceSellerCharge1.FAGetValue().Clean());
            Support.AreEqual(@"$ 220.00", FastDriver.OutsideTitleCompanyDetail.FundsDue.FAGetText().Clean());
            Support.AreEqual(@"$ 30.00", FastDriver.OutsideTitleCompanyDetail.TotalCharges.FAGetText().Clean());
            Support.AreEqual(@"$ 250.00", FastDriver.OutsideTitleCompanyDetail.FundsDeposited.FAGetText().Clean());
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Navigate to Search vendor & Enter GAB.";
            FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();
            FastDriver.SearchVendor.FindGAB(@"247");
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Enter second fee in Title and escrow.";
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "1.99");
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "2.99");
            FastDriver.BottomFrame.Done();

            #endregion

            #region FMUC0003_REG0006

            Reports.TestStep = "Creates offset adjustment.";
            FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
            if (!AutoConfig.UseCDFormType)
                FastDriver.AdjustmentOffset.UpdateCharge(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 50.00, buyerCredit: 50.00, sellerCharge: 50.00, sellerCredit: 50.00);
            else
                FastDriver.AdjustmentOffset.UpdateCharge(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 50.00, sellerCredit: 50.00);

            Reports.TestStep = "validate offset adjustment.";
            FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
            if (!AutoConfig.UseCDFormType)
            {
                Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
            }
            else
            {
                Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual(@"50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean());
            }
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Create Misc Adjustment Instance.";
            FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
            if (!FastDriver.AdjustmentMisc.SellerCredit.IsReadOnly())
                FastDriver.AdjustmentMisc.UpdateCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Buyer Deposit Directly to Seller", buyerCredit: 50.00, sellerCredit: 50.00);
            else
                FastDriver.AdjustmentMisc.UpdateCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Buyer Deposit Directly to Seller", buyerCredit: 50.00);

            Reports.TestStep = "Validates Misc Adjustment Instance.";
            FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
            if (!AutoConfig.UseCDFormType)
                Support.AreEqual(@"50.00", FastDriver.AdjustmentMisc.SellerCredit.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.AdjustmentMisc.BuyerCredit.FAGetValue().Clean());
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Add a homeowner association instance directly.";
            FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
            FastDriver.HomeownerAssociation.FindGABCode(@"247", WaitForGabCodeLabel: false);
            FastDriver.HomeownerAssociation.AmountDues.FASetText(@"10.00");
            FastDriver.HomeownerAssociation.PerDiem.FASelectItem(@"MONTH");
            FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", buyerCharge: 4.00, sellerCharge: 2.00);
            FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", buyerCharge: 4.50, sellerCharge: 2.50);
            FastDriver.HomeownerAssociation.ProrationAmount.FASetText(@"10.00");
            FastDriver.HomeownerAssociation.FromDate.FASetText(@"07-16-2012");
            FastDriver.HomeownerAssociation.ToDate.FASetText(@"08-17-2012");
            if (!FastDriver.HomeownerAssociation.HOALienPayOffTable.Displayed)
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
            //FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.ProrationTable, "Association Dues", buyerCharge: 1.50, sellerCredit: 2.50);
            FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText(@"1.50");
            FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText(@"2.50");

            Reports.TestStep = "Set an instance of Home warranty details.";
            FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
            FastDriver.HomeWarrantyDetail.FindGABCode(@"HW1");
            if (!AutoConfig.UseCDFormType)
            {
                FastDriver.HomeWarrantyDetail.PolicyCharge.FASetText(@"10.00");
                FastDriver.HomeWarrantyDetail.paidSeller.FASetText(@"2.00");
                FastDriver.HomeWarrantyDetail.PaidBuyer.FASetText(@"2.00");
            }
            FastDriver.HomeWarrantyDetail.Amount.FASetText(@"2.00" + FAKeys.Tab);
            FastDriver.HomeWarrantyDetail.FromDate.FASetText(DateTime.Today.AddDays(1).ToDateString());
            FastDriver.HomeWarrantyDetail.ToDate.FASetText(DateTime.Today.AddDays(2).ToDateString());
            FastDriver.HomeWarrantyDetail.InclusiveFrom.FASetCheckbox(true);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
            FastDriver.HomeWarrantyDetail.InclusiveTo.FASetCheckbox(true);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
            FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.FASetText(@"Early Coverage Charge Description");
            FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "", buyerCharge: 10.00, sellerCharge: 10.00);
            FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            if (!AutoConfig.UseCDFormType)
            {
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(description: "Sanity-Home Warranty", buyerCharge: "3.99", sellerCharge: "3.99");
            }
            else
            {
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"3.99");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"3.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"3.99");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"3.99");
            }

            Reports.TestStep = "Click on Done in Dialog Box.";
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.HandleDialogMessage();

            Reports.TestStep = "Click on payment details.";
            FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
            FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

            Reports.TestStep = "Validates payment details for HomeWarrantyDetail.";
            Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean());

            Reports.TestStep = "Click on Done in Dialog Box.";
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

            #endregion
        }

        private void CreateMasterFileREG0006(bool isExist)
        {
            #region Data Setup

            var ReleaseinDays = "";
            var value = "";
            var EarlyCoverageFromDate = DateTime.Today.AddDays(1).ToDateString();
            var EarlyCoverageToDate = DateTime.Today.AddDays(2).ToDateString();

            #endregion

            Reports.TestStep = "Creates the Second Order with Buyer and Seller";
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad().ClickSkipSearchButton().WaitForScreenToLoad();
            //FastDriver.QuickFileEntry.CreateDetailedFile(FileName: isExist ? Support.RandomString("AAAZZZFRR") : "REG06-F1");
            if (!isExist)
                FastDriver.QuickFileEntry.CreateDetailedFile(FileName: "REG06-F1");
            else
                FastDriver.TopFrame.SearchFileByFileNumber("REG06-F1");
            var REG0006_FileNum1 = FastDriver.TopFrame.GetFileNumber();

            Reports.TestStep = "Check for finalized Policies.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            if (FastDriver.DocumentRepository.LenderPolicy.Exists())
            {
                if (FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 9, TableAction.GetText).Message.Contains("Finalized"))
                {
                    FastDriver.DocumentRepository.LenderPolicy.FAClick();
                    FastDriver.DocumentRepository.Edit.FAClick();
                    FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    try
                    {
                        FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                    }
                    catch (Exception)
                    {
                        FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                        FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("%o");
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("z");
                        FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                    }
                    FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Unfinalized");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                FastDriver.DocumentRepository.LenderPolicy.FAClick();
                FastDriver.DocumentRepository.Remove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            }
            if (FastDriver.DocumentRepository.OwnerPolicyElement.Exists())
            {
                if (FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 9, TableAction.GetText).Message.Contains("Finalized"))
                {
                    FastDriver.DocumentRepository.OwnerPolicyElement.FAClick();
                    FastDriver.DocumentRepository.Edit.FAClick();
                    FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    try
                    {
                        FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                    }
                    catch (Exception)
                    {
                        FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                        FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("%o");
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("z");
                        FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                    }
                    FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Unfinalized");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                FastDriver.DocumentRepository.OwnerPolicyElement.FAClick();
                FastDriver.DocumentRepository.Remove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            }
            if (FastDriver.DocumentRepository.EndorsementGuaranteeElement.Exists())
            {
                if (FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Endorsement/Guarantee", 9, TableAction.GetText).Message.Contains("Finalized"))
                {
                    FastDriver.DocumentRepository.EndorsementGuaranteeElement.FAClick();
                    FastDriver.DocumentRepository.Edit.FAClick();
                    FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    try
                    {
                        FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                    }
                    catch (Exception)
                    {
                        FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                        FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("%o");
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("z");
                        FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                    }
                    FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Unfinalized");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                FastDriver.DocumentRepository.EndorsementGuaranteeElement.FAClick();
                FastDriver.DocumentRepository.Remove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            }

            Reports.TestStep = "Copy Documents from Starter file.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG04-F1" + FAKeys.Tab);
            FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
            Playback.Wait(2000);
            FastDriver.CopyDocuments.WaitForScreenToLoad();
            if (FastDriver.CopyDocuments.SelectAll.Enabled)
            {
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
            }

            Reports.TestStep = "Click on Done.";
            FastDriver.BottomFrame.Done();
            value = FastDriver.WebDriver.HandleDialogMessage(timeout: 20);
            if (value.Contains("Following image(s)"))
            {
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                if (FastDriver.DocumentRepository.LenderPolicy.Exists())
                {
                    if (FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 9, TableAction.GetText).Message.Contains("Finalized"))
                    {
                        FastDriver.DocumentRepository.LenderPolicy.FAClick();
                        FastDriver.DocumentRepository.Edit.FAClick();
                        FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("%o");
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("z");
                        try
                        {
                            FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                        }
                        catch (Exception)
                        {
                            FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                            FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                            Keyboard.SendKeys("%o");
                            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                            Keyboard.SendKeys("z");
                            FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                        }
                        FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Unfinalized");
                        FastDriver.DialogBottomFrame.ClickDone();
                        FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    }
                    FastDriver.DocumentRepository.LenderPolicy.FAClick();
                    FastDriver.DocumentRepository.Remove.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                if (FastDriver.DocumentRepository.OwnerPolicyElement.Exists())
                {
                    if (FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 9, TableAction.GetText).Message.Contains("Finalized"))
                    {
                        FastDriver.DocumentRepository.OwnerPolicyElement.FAClick();
                        FastDriver.DocumentRepository.Edit.FAClick();
                        FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("%o");
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("z");
                        try
                        {
                            FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                        }
                        catch (Exception)
                        {
                            FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                            FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                            Keyboard.SendKeys("%o");
                            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                            Keyboard.SendKeys("z");
                            FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                        }
                        FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Unfinalized");
                        FastDriver.DialogBottomFrame.ClickDone();
                        FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    }
                    FastDriver.DocumentRepository.OwnerPolicyElement.FAClick();
                    FastDriver.DocumentRepository.Remove.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                if (FastDriver.DocumentRepository.AccommSigning_CustomerBuyer.Exists())
                {
                    FastDriver.DocumentRepository.AccommSigning_CustomerBuyer.FAClick();
                    FastDriver.DocumentRepository.Remove.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                if (FastDriver.DocumentRepository.AccommSigning_CustomerSeller.Exists())
                {
                    FastDriver.DocumentRepository.AccommSigning_CustomerSeller.FAClick();
                    FastDriver.DocumentRepository.Remove.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                if (FastDriver.DocumentRepository.EndorsementGuaranteeElement.Exists())
                {
                    if (FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Endorsement/Guarantee", 9, TableAction.GetText).Message.Contains("Finalized"))
                    {
                        FastDriver.DocumentRepository.EndorsementGuaranteeElement.FAClick();
                        FastDriver.DocumentRepository.Edit.FAClick();
                        FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("%o");
                        Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                        Keyboard.SendKeys("z");
                        try
                        {
                            FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                        }
                        catch (Exception)
                        {
                            FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                            FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                            Keyboard.SendKeys("%o");
                            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                            Keyboard.SendKeys("z");
                            FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                        }
                        FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Unfinalized");
                        FastDriver.DialogBottomFrame.ClickDone();
                        FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                        FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                    }
                    FastDriver.DocumentRepository.EndorsementGuaranteeElement.FAClick();
                    FastDriver.DocumentRepository.Remove.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                if (FastDriver.DocumentRepository.EstimatedSettlementStatement.Exists())
                {
                    FastDriver.DocumentRepository.EstimatedSettlementStatement.FAClick();
                    FastDriver.DocumentRepository.Remove.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                if (FastDriver.DocumentRepository.AutomationTestTitleReport.Exists())
                {
                    FastDriver.DocumentRepository.AutomationTestTitleReport.FAClick();
                    FastDriver.DocumentRepository.Remove.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                }
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText("REG04-F1" + FAKeys.Tab);
            }
            Playback.Wait(2000);

            Reports.TestStep = "Copies All File Items from Starter file.";
            FastDriver.StarterReference.WaitForScreenToLoad();
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Validates the homeowner association instance on the new file.";
            FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
            Support.AreEqual(@"247", FastDriver.HomeownerAssociation.IDCodeText.FAGetText().Clean());
            Support.AreEqual(@"10.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue().Clean());
            Support.AreEqual(@"MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());
            Support.AreEqual(@"4.00", FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"2.00", FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FAGetValue().Clean());
            Support.AreEqual(@"4.50", FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"2.50", FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.FAGetValue().Clean());

            Reports.TestStep = "Clicks on payment details on the new file.";
            FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
            FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

            Reports.TestStep = "Validates payment details for HomeWarrantyDetail for the new file.";
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean());

            Reports.TestStep = "Click on Done in Dialog Box.";
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

            Reports.TestStep = "Copying all items on Starter screen except -'Make the Buyer(s) as the Seller(s)' ";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG04-F1" + FAKeys.Tab);
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
            FastDriver.StarterReference.Products.FASetCheckbox(true);
            FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
            FastDriver.StarterReference.PropertyTitleProductionTab.FASetCheckbox(true);
            FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
            FastDriver.StarterReference.SellersData.FASetCheckbox(true);
            FastDriver.StarterReference.Notes.FASetCheckbox(true);
            FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();

            Reports.TestStep = "Verifies in the EventLog page";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
            Support.AreEqual("Starter Ref File Item Copy from \"REG04-F1\" to \"" + REG0006_FileNum1 + "\", CopyBusinessSource, CopyProductTypes, CopyPropertyInfo, CopyBuyerData, CopySellerData, CopyNotes, CopySettlementData, CopyTitleProduction Completed.",
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Starter Ref File Item Copy Completed]", 5, TableAction.GetText).Message.Clean());

            Reports.TestStep = "Copying 'Make the Buyer(s) as the Seller(s)' from Starter file";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG04-F1" + FAKeys.Tab);
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Verifies in the EventLog page for Make the Buyer(s) as the Seller(s).";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
            Support.AreEqual("Starter Ref File Item Copy from \"REG04-F1\" to \"" + REG0006_FileNum1 + "\", MakeBuyersSellers Completed.",
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Starter Ref File Item Copy Completed]", 5, TableAction.GetText).Message.Clean());

            Reports.TestStep = "Copying All Items on Starter screen";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG04-F1" + FAKeys.Tab);
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Verifies in the EventLog page whether or not All Itmes were copied.";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
            Support.AreEqual("Starter Ref File Item Copy from \"REG04-F1\" to \"" + REG0006_FileNum1 + "\", CopyAll Completed.", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Starter Ref File Item Copy Completed]", 5, TableAction.GetText).Message.Clean());

            Reports.TestStep = "FM6855 - Verifies Home Warranty page";
            FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
            Support.AreEqual(@"HW1", FastDriver.HomeWarrantyDetail.IDCodeText.FAGetText().Clean());
            Support.AreEqual(@"HW name 1", FastDriver.HomeWarrantyDetail.GABname.FAGetText().Clean());
            Support.AreEqual(@"AD1 Mailing Address Line1, AD1 Mailing Address Line2", FastDriver.HomeWarrantyDetail.GABAddress.FAGetText().Clean());
            Support.AreEqual(@"(245)121-2121", FastDriver.HomeWarrantyDetail.BusPhone.FAGetValue().Clean());
            Support.AreEqual(@"(245)121-2122", FastDriver.HomeWarrantyDetail.BusFax.FAGetValue().Clean());
            Support.AreEqual(@"(245)121-2124", FastDriver.HomeWarrantyDetail.CellPhone.FAGetValue().Clean());
            Support.AreEqual(@"(245)121-1223", FastDriver.HomeWarrantyDetail.Pager.FAGetValue().Clean());
            if (FastDriver.HomeWarrantyDetail.EmailAddress.FAGetValue().Clean().Contains("eaexvmdeuc"))
            {
                Support.AreEqual(@"xqkmqabehp@email.com", FastDriver.HomeWarrantyDetail.EmailAddress.FAGetValue().Clean());//original ebyupuqguj
            }
            if (!AutoConfig.UseCDFormType)
            {
                Support.AreEqual(@"10.00", FastDriver.HomeWarrantyDetail.PolicyCharge.FAGetValue().Clean());
                Support.AreEqual(@"2.00", FastDriver.HomeWarrantyDetail.paidSeller.FAGetValue().Clean());
                Support.AreEqual(@"2.00", FastDriver.HomeWarrantyDetail.PaidBuyer.FAGetValue().Clean());
            }
            Support.AreEqual(@"2.00", FastDriver.HomeWarrantyDetail.Amount.FAGetValue().Clean());
            if (EarlyCoverageFromDate != FastDriver.HomeWarrantyDetail.FromDate.FAGetValue().Clean() || EarlyCoverageToDate != FastDriver.HomeWarrantyDetail.ToDate.FAGetValue().Clean())
            {
                Support.AreEqual(FastDriver.HomeWarrantyDetail.FromDate.FAGetValue().Clean(), FastDriver.HomeWarrantyDetail.FromDate.FAGetValue().Clean());
                Support.AreEqual(FastDriver.HomeWarrantyDetail.ToDate.FAGetValue().Clean(), FastDriver.HomeWarrantyDetail.ToDate.FAGetValue().Clean());
            }
            else
            {
                Support.AreEqual(DateTime.Today.AddDays(1).ToDateString(), FastDriver.HomeWarrantyDetail.FromDate.FAGetValue().Clean());
                Support.AreEqual(DateTime.Today.AddDays(2).ToDateString(), FastDriver.HomeWarrantyDetail.ToDate.FAGetValue().Clean());
            }
            Support.AreEqual(@"True", FastDriver.HomeWarrantyDetail.InclusiveFrom.Selected.ToString(), "Verify if the Inclusive From checkbox is checked.");
            Support.AreEqual(@"True", FastDriver.HomeWarrantyDetail.InclusiveTo.Selected.ToString(), "Verify if the Inclusive To checkbox is checked.");
            Support.AreEqual(@"Early Coverage Charge Description", FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.FAGetValue().Clean());
            Support.AreEqual(@"10.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue().Clean(), "Verify if the Early Coverage Buyer Charge field is empty.");
            Support.AreEqual(@"10.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue().Clean());
            Support.AreEqual(@"Home Warranty", FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FAGetValue().Clean());
            Support.AreEqual(@"Early Coverage Charge Description", FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.FAGetValue().Clean());
            if (!AutoConfig.UseCDFormType)
            {
                Support.AreEqual(@"Check Amount :$31.98", FastDriver.HomeWarrantyDetail.CheckAmount.FAGetText().Clean());
            }
            else
            {
                Support.AreEqual(@"Check Amount :$27.98", FastDriver.HomeWarrantyDetail.CheckAmount.FAGetText().Clean());
            }

            Reports.TestStep = "FM6855 - Verifies Payment Details dialog";
            FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"$3.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean());

            Reports.TestStep = "Click on Done in Dialog Box.";
            FastDriver.DialogBottomFrame.ClickDone();

            #region FMUC0003_REG0007

            Reports.TestStep = "Create an instance of inspection Repair Pest.";
            FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
            FastDriver.InspectionRepairPest.Name.FASetText(@"Pest 1 for HUD Testing Name 1" + FAKeys.Tab);
            FastDriver.InspectionRepairPest.Find.FAClick();
            FastDriver.InspectionRepairPest.Attention.FASelectItem(@"Contact, Pest 1 for HUD");
            FastDriver.InspectionRepairPest.Reference.FASetText(@"Reference1");
            FastDriver.InspectionRepairPest.WithinDays.FASetText(@"5");
            FastDriver.InspectionRepairPest.OrderDate.FASetText(@"07-10-2012");
            FastDriver.InspectionRepairPest.DueDate.FASetText(@"12-10-2012");
            FastDriver.InspectionRepairPest.FollowUpDate.FASetText(@"10-10-2012");
            FastDriver.InspectionRepairPest.CompleteDate.FASetText(@"04-10-2013");
            FastDriver.InspectionRepairPest.ReportDate.FASetText(@"03-10-2013");
            FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection", buyerCharge: 55.55, sellerCharge: 66.66, editDescription: @"PESTDESCRIPTION1");
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Support.AreEqual(@"Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Clean());
            FastDriver.BottomFrame.Done();

            #endregion

            #region FMUC0003_REG0008

            Reports.TestStep = "Select the Fire Insurance from Summary.";
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
            FastDriver.InsuranceSummary.Fire.FAClick();

            Reports.TestStep = "Click on Edit Insurance Summary.";
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();

            Reports.TestStep = "Create an instance of Fire Insurance.";
            FastDriver.InsuranceFire.WaitForScreenToLoad();
            FastDriver.InsuranceFire.FireName.FASetText(@"Insurance CompanyName 1" + FAKeys.Tab);
            FastDriver.InsuranceFire.FireFind.FAClick();
            FastDriver.InsuranceFire.UpdateCharge(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
            FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(true);
            FastDriver.InsuranceFire.FireAmount.FASetText(@"50.00");
            FastDriver.InsuranceFire.FireFromDate.FASetText(@"10-08-2010");
            FastDriver.InsuranceFire.FireToDate.FASetText(@"10-08-2012");
            FastDriver.InsuranceFire.FireBuyerCharge1.FASetText(@"100.14");
            FastDriver.InsuranceFire.FireSellerCredit1.FASetText(@"100.14");
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Create an Lease Instance.";
            FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
            FastDriver.LeaseDetail.FindGABcode(@"HUDLEASE02");
            FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.ChargeTable, "Rent/Lease Payment Due", buyerCharge: 11.00, sellerCharge: 12.00, editDescription: @"Charge Description");
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Support.AreEqual(@"Check Amount: $ 23.00", FastDriver.LeaseDetail.CheckAmount.FAGetText().Clean());
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
            FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
            FastDriver.MiscDisbursementDetail.FindGABcode(@"HUDMISCDB1");
            FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscellaneousDisbursementBuyerSellerChargesTable, "Disbursemen2", buyerCharge: 50.00, sellerCharge: 50.00);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Support.AreEqual(@"Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText().Clean());

            Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
            FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
            Support.AreEqual(@"Disbursemen2", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());
            Support.AreEqual(@"Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText().Clean());
            FastDriver.BottomFrame.New();

            Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
            FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
            FastDriver.SurveyDetail.FindGABCode(@"247", WaitForGabCodeLabel: false);
            FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", buyerCharge: 200.00);

            Reports.TestStep = "Create a new Utility Instance.";
            FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
            FastDriver.UtilityDetail.FindGABcode(@"HUDUTLCMP1");
            FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities", buyerCharge: 50.00, sellerCharge: 50.00, editDescription: @"Utility Charge");
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);

            Reports.TestStep = "Validate Data for a new Instance.";
            Support.AreEqual(@"Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().Clean());
            Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().Clean());
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "New Deposite In Escrow.";
            FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
            FastDriver.DepositInEscrow.Amount.FASetText(@"10.00");
            FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(@"Cash");
            FastDriver.DepositInEscrow.Representing.FASelectItem(@"Additional Closing Costs");
            FastDriver.DepositInEscrow.Description.FASetText(@"Sanity Deposit In Escrow");
            FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(@"Buyer");
            FastDriver.BottomFrame.Save();
            FastDriver.WebDriver.HandleDialogMessage(true, false);

            #endregion

            #region FMUC0003_REG0009

            Reports.TestStep = "Enter Data on Hold Fund Screen.";
            FastDriver.LeftNavigation.Navigate<HoldFunds>("Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
            FastDriver.HoldFunds.Reason.FASetText(@"Reason For First Hold Fund Instance.");
            if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday")
                ReleaseinDays = "9";
            else
                ReleaseinDays = "7";
            FastDriver.HoldFunds.ReleaseinDays.FASetText(ReleaseinDays + FAKeys.Tab);

            Reports.TestStep = "Click on Done.";
            FastDriver.BottomFrame.Done();
            FastDriver.WebDriver.HandleDialogMessage();

            Reports.TestStep = "Enter Data on Hold Fund Screen.";
            FastDriver.HoldFunds.WaitForScreenToLoad();
            FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
            FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
            FastDriver.HoldFunds.SellerCharge.FASetText(@"10.00" + FAKeys.Tab);
            Reports.StatusUpdate("Verify whether SellerRemaining value is equal or less than the actual value entered.", Int32.Parse(FastDriver.HoldFunds.SellerRemaining.FAGetText().Replace(".00", "").Clean()) <= 10.00);
            FastDriver.HoldFunds.New.FAClick();
            FastDriver.HoldFunds.WaitForScreenToLoad(FastDriver.HoldFunds.GABName);
            FastDriver.HoldFunds.FindGABCode(@"HOLDFUNDS");
            FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText(@"Hold Fund Desc");
            FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText(@"4.00");
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Click on Edit on Proration Tax screen.";
            FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
            FastDriver.ProrationTax.Tax1.FAClick();
            FastDriver.ProrationTax.Edit.FAClick();

            Reports.TestStep = "Enter Description and Charges.";
            FastDriver.ProrationDetail.WaitForScreenToLoad();
            FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
            FastDriver.ProrationDetail.Amount.FASetText(@"10.00");
            FastDriver.ProrationDetail.FromDate.FASetText(@"04-02-2012");
            FastDriver.ProrationDetail.BasedOn.FASelectItem(@"365");
            FastDriver.ProrationDetail.Per.FASelectItem(@"YEAR");
            FastDriver.ProrationDetail.ToDate.FASetText(@"07-02-2012");
            FastDriver.BottomFrame.Done();

            #endregion

            #region FMUC0003_REG0010

            SetDisplayPDFinBrowser_ON();

            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            this.CreateDocument("Escrow Instruction", "Accomm Signing-Customer Buyer", "Accomm Signing-Customer Buyer", multipleDocs: true);

            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            this.CreateDocument("Escrow Instruction", "Accomm Signing-Customer Seller", "Accomm Signing-Customer Seller", multipleDocs: true);

            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            CreateDocument("Endorsement/Guarantee", "UK ENDOR T", "Uk ENDOR T", multipleDocs: true);

            Reports.TestStep = "Select the Endorsement Document and Click on Edit for finalize.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "UK ENDOR T", 4, TableAction.Click);
            FastDriver.DocumentRepository.Edit.FAClick();
            FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%o");
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("z");
            try
            {
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");
            }
            catch (Exception)
            {
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "UK ENDOR T", 4, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");
            }

            Reports.TestStep = "Verify Finalized Document Data.";
            Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);

            Reports.TestStep = "Create a document";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            CreateDocument("Title Reports", "Automation Test Title Report", "Automation Test Title Report", multipleDocs: true);

            Reports.TestStep = "Select the Title Report Document and Click on Info Tab.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Automation Test Title Report", 4, TableAction.Click);
            FastDriver.DocumentRepository.Info.FAClick();
            Playback.Wait(2000);

            Reports.TestStep = "Enter Document Information for Title report.";
            FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
            Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
            FastDriver.DocumentInfo.EffectiveDate.FASetText(@"06-20-2012");
            FastDriver.DocumentInfo.Save.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

            Reports.TestStep = "Verify Document Information for Title report.";
            FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
            Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
            Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.EffectiveDate.FAGetValue().Clean());

            Reports.TestStep = "Click on Add Button.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.AddDocRep.FAClick();

            Reports.TestStep = "Add the Lender Policy Document to Document Repository screen.";
            FastDriver.AdHocDocuments.WaitForScreenToLoad();
            FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
            FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Lender Policy");
            FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH" + FAKeys.Tab);

            Reports.TestStep = "validate the data entered in Adhoc Documents.";
            value = FastDriver.AdHocDocuments.Source.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Both", value);
            value = FastDriver.AdHocDocuments.TemplateType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Lender Policy", value);
            Support.AreEqual(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.AdHocDocuments.TemplateDescription.FAGetValue().Clean());
            FastDriver.AdHocDocuments.FindNow.FAClick();
            FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
            FastDriver.AdHocDocuments.CreateSave.FAClick();
            Playback.Wait(5000);
            if (FastDriver.TitleReportSelection.TitleReportSelectionScreenExists())
            {
                FastDriver.TitleReportSelection.WaitForScreenToLoad();
                FastDriver.TitleReportSelection.TableRow1.FAClick();
                FastDriver.TitleReportSelection.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            }

            Reports.TestStep = "Select the Lender Policy and Click on Info Tab.";
            FastDriver.WebDriver.WaitForActionToComplete(() => {
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                return FastDriver.DocumentRepository.LenderPolicy.Exists();
            });
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
            FastDriver.DocumentRepository.Info.FAClick();
            Playback.Wait(2000);

            Reports.TestStep = "Enter Document Information for Lender Policy.";
            FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
            Support.AreEqual(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
            FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(@"06-20-2012");
            FastDriver.DocumentInfo.LenderCheckBox.FASetCheckbox(true);
            FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

            Reports.TestStep = "Verify Document Information for Lender Policy.";
            FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
            Support.AreEqual(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
            Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FAGetValue().Clean());

            Reports.TestStep = "Select the Lender Policy and Click on Edit for finalize.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
            FastDriver.DocumentRepository.Edit.FAClick();
            Playback.Wait(3000);
            FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%o");
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("z");
            Playback.Wait(1000);
            value = FastDriver.WebDriver.HandleDialogMessage();
            if (!value.Contains("Dialog not present"))
            {
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                Playback.Wait(2000);
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
                if (FastDriver.DocumentInfo.AutoNumber.Exists())
                {
                    FastDriver.DocumentInfo.AutoNumber.FASetCheckbox(true);
                    if (FastDriver.DocumentInfo.AssignNum.Enabled)
                        FastDriver.DocumentInfo.AssignNum.FAClick();
                }
                else
                {
                    FastDriver.DocumentInfo.PolicyNum.FASetText("FILE1235");
                }
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.SearchResults.FAClick();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Lender Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
            }

            Reports.TestStep = "Finalize Document.";
            FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
            FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized" + FAKeys.Tab);

            Reports.TestStep = "Verify Finalized Document Data.";
            Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

            Reports.TestStep = "Click on Add Button.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.AddDocRep.FAClick();

            Reports.TestStep = "Add the Owner Policy Document to Document Repository screen.";
            FastDriver.AdHocDocuments.WaitForScreenToLoad();
            FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
            FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Owner Policy");
            FastDriver.AdHocDocuments.TemplateDescription.FASetText(@"ALTERNATE FLOW 2 - QTP - DO NOT TOUCH" + FAKeys.Tab);

            Reports.TestStep = "validate the data entered in Adhoc Documents.";
            value = FastDriver.AdHocDocuments.Source.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Both", value);
            value = FastDriver.AdHocDocuments.TemplateType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Owner Policy", value);
            Support.AreEqual(@"ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", FastDriver.AdHocDocuments.TemplateDescription.FAGetValue().Clean());
            FastDriver.AdHocDocuments.FindNow.FAClick();
            FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", "ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", "Description", TableAction.Click);
            FastDriver.AdHocDocuments.CreateSave.FAClick();
            Playback.Wait(5000);

            Reports.TestStep = "Select the Owner Policy and Click on Info Tab.";
            FastDriver.WebDriver.WaitForActionToComplete(() => {
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                return FastDriver.DocumentRepository.OwnerPolicyElement.Exists();
            });
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
            FastDriver.DocumentRepository.Info.FAClick();
            Playback.Wait(2000);

            Reports.TestStep = "Enter Document Information for Owner Policy.";
            FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
            Support.AreEqual(@"ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
            FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(@"06-20-2012" + FAKeys.Tab);
            FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();

            Reports.TestStep = "Verify Document Information for Owner Policy.";
            FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
            Support.AreEqual(@"ALTERNATE FLOW 2 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
            Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FAGetValue().Clean());

            Reports.TestStep = "Select the Owner Policy and Click on Edit for finalize.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
            FastDriver.DocumentRepository.Edit.FAClick();
            Playback.Wait(3000);
            FastDriver.DocumentPreparationMenu.SwitchToContentFrame();
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%o");
            Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("z");
            Playback.Wait(1000);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
            FastDriver.DocumentRepository.Info.FAClick();
            Playback.Wait(2000);
            FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
            FastDriver.DocumentInfo.SwitchToContentFrame();
            if (FastDriver.DocumentInfo.AutoNumber.Exists())
            {
                FastDriver.DocumentInfo.AutoNumber.FASetCheckbox(true);
                if (FastDriver.DocumentInfo.AssignNum.Enabled)
                    FastDriver.DocumentInfo.AssignNum.FAClick();
            }
            else
            {
                FastDriver.DocumentInfo.PolicyNum.FASetText("FILE1235");
            }
            FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
            //FastDriver.DocumentRepository.SearchResults.FAClick();
            FastDriver.DocumentRepository.Edit.FAClick();
            Playback.Wait(4000);
            FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
            FastDriver.DocumentPreparationMenu.Phrase1.FAClick();
            Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%o");
            Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("z");

            Reports.TestStep = "Finalize Document.";
            try
            {
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized" + FAKeys.Tab);

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Owner Policy", 6, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(1000);
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized" + FAKeys.Tab);

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
            }

            #endregion

            #region FMUC0003_REG0011

            Reports.TestStep = "Click on Scan button for scan.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.Scan_DocsTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

            Reports.TestStep = "Click on Open Button.";
            FastDriver.ImagingWorkBench.WaitForWindowToLoad();
            FastDriver.ImagingWorkBench.Open.FAClick();
            FastDriver.ImagingWorkBench.ClickOpen();
            FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\ImageHaving12Pages.tif");
            //FastDriver.OpenImageDlg.OpenImage(@"C:\TFS2\FASTSelenium_FeatINT\DocPrep\bin\Debug\Common\Support" + @"\ImageHaving12Pages.tif");
            FastDriver.BottomFrame.Done();
            Playback.Wait(1000);
            Keyboard.SendKeys("{ENTER}");
            FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "", imageTrigger: "AFFIX INV");
            Playback.Wait(1000);
            Keyboard.SendKeys("{ENTER}");
            FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

            Reports.TestStep = "Verify for scanned Document.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "INST-Estimated Settlement Statement", 4, TableAction.Click);

            Reports.TestStep = "Select the Accomm Sign-Customer Buyer document for Delivery.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            if (FastDriver.DocumentRepository.AccommSigng_CustomerBuyerElement.Exists())
                FastDriver.DocumentRepository.AccommSigng_CustomerBuyerElement.FAClick();
            else
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Accomm Signing-Customer Buyer", 4, TableAction.Click);

            Reports.TestStep = "Perform Image Doc Delivery.";
            FastDriver.DocumentRepository.SelectDeliveryMethod("IMAGEDOC").ClickDeliver();

            Reports.TestStep = "Click on Imagedoc button.";
            FastDriver.ImageDocDlg.WaitForScreenToLoad();
            FastDriver.ImageDocDlg.ImageDoc.FAClick();
            FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

            SetDisplayPDFinBrowser_OFF();

            #endregion

        }

        private void CreateMasterFilesREG0012(bool isExist)
        {
            Reports.TestStep = "Create a File and named as 'REG0012_FileNum1'";
            if (!isExist)
            {
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.AutoNumberIndicator = false;
                fileRequest.File.FileNumber = "REG12-F1";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            }
            else
            {
                FastDriver.TopFrame.SearchFileByFileNumber("REG12-F1");
            }

            var REG0012_FileNum1 = FastDriver.TopFrame.GetFileNumber();

            Reports.TestStep = "Copy from File REG0006_FileNum1";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1" + FAKeys.Tab);
            FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

            Reports.TestStep = "Copy documents from File REG0006_FileNum1";
            FastDriver.CopyDocuments.WaitForScreenToLoad();
            FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
            FastDriver.BottomFrame.Done();
            var value = FastDriver.WebDriver.HandleDialogMessage();
            if (value.Contains("Following image(s)"))
            {
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
            }
            FastDriver.StarterReference.WaitForScreenToLoad();
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Create a File and named as 'REG0012_FileNum2'";
            if (!VerifyFileExistence("REG12-F2"))
            {
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.AutoNumberIndicator = false;
                fileRequest.File.FileNumber = "REG12-F2";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            }
            else
                FastDriver.TopFrame.SearchFileByFileNumber("REG12-F2");

            var REG0012_FileNum2 = FastDriver.TopFrame.GetFileNumber();

            Reports.TestStep = "select the list of items and documents from REG0012_FileNum1 to copy.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText(REG0012_FileNum1 + FAKeys.Tab);
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
            FastDriver.StarterReference.Products.FASetCheckbox(true);
            FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
            FastDriver.StarterReference.Notes.FASetCheckbox(true);

            Reports.TestStep = "Copy the documents first.";
            FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);

            Reports.TestStep = "Copy documents.";
            FastDriver.CopyDocuments.WaitForScreenToLoad();
            FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

            Reports.TestStep = "Click on Done.";
            FastDriver.BottomFrame.Done();
            value = FastDriver.WebDriver.HandleDialogMessage();
            if (value.Contains("Following image(s)"))
            {
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
            }

            Reports.TestStep = "Click on copy now button for documents";
            FastDriver.StarterReference.WaitForScreenToLoad();
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Selecting Buyer and seller.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText(REG0012_FileNum1 + FAKeys.Tab);
            FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
            FastDriver.StarterReference.SellersData.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "select the list of items from the Mater file to copy.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText(REG0012_FileNum1 + FAKeys.Tab);
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
            FastDriver.StarterReference.Products.FASetCheckbox(true);
            FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
            FastDriver.StarterReference.Notes.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();

            Reports.TestStep = "Copy same data from starter ref file.";
            Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText(REG0012_FileNum1 + FAKeys.Tab);
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Select Business Source and settlement Information.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText(REG0012_FileNum1 + FAKeys.Tab);
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
            FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Select File Notes from master file.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText(REG0012_FileNum1 + FAKeys.Tab);
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.Notes.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Validate That New Note added from QFE.";
            FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
            FastDriver.FileNotes.Table.PerformTableAction("Note", "Notes Data including - * # Specialcharacter :) !", "Note", TableAction.Click);

            Reports.TestStep = "Verify data copied from master file and get the file No.";
            FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
            value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Sale w/Mortgage", value);
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Condominium", value);
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
            Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
            value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"CA", value);
            Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());

            value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Sale w/Mortgage", value);
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Condominium", value);
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
            Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Clean());
            Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean());
            Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Clean());
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
            Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean());
            Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean());
            Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
            value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"CA", value);
            Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Individual", value);
            Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Husband/Wife", value);
            Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Individual", value);
            Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Husband/Wife", value);
            Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Clean());
            Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Clean());
            Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Clean());

            Reports.TestStep = "Verify for starter ref completed event";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
            FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Starter Ref File Item Copy Completed]", "Event", TableAction.Click);

            Reports.TestStep = "Verify data copied from master file and get the file No.";
            FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
            value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Sale w/Mortgage", value);
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Condominium", value);
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
            Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
            value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"CA", value);
            Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());

            value = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Sale w/Mortgage", value);
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.PropertyType.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Condominium", value);
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
            Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Clean());
            Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean());
            Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Clean());
            Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean());
            Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean());
            Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean());
            Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean());
            value = FastDriver.FileHomepage.PropertyState.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"CA", value);
            Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Individual", value);
            Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Husband/Wife", value);
            Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Individual", value);
            Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Husband/Wife", value);
            Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Clean());
            Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Clean());
            Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Clean());
        }

        private void CreateMasterFilesREG0013(bool isExist)
        {
            Reports.TestStep = "Create a Pending file-Details Tab.";
            if (!isExist)
            {
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAutoNumber.FASetCheckbox(false);
                FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FASetText("REG13-F1");
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem(@"No Program Type");
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsAddRemoveother.FAClick();

                Reports.TestStep = "Select No product issued";
                FastDriver.LenderPoliciesDlg.WaitForScreenToLoad();
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, timeoutSeconds: 10);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.OthersTable);
                FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem(@"Title Agent");
                FastDriver.NewFileEntry.DetailsSearchType.FASelectItem(@"No Search Type");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItemBySendingKeys(@"Husband/Wife");
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText(@"Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText(@"Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText(@"Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsAddNewSeller.Click(); ;
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItemBySendingKeys(@"Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText(@"Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText(@"Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText(@"Seller2SpouseName");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText(@"1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText(@"PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText(@"PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText(@"PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem(@"Orange");
                FastDriver.NewFileEntry.DetailsSalePrice.FASetText(@"600,000.00");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText(@"250,000.00");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText(@"150,000.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
            }
            FastDriver.TopFrame.SearchFileByFileNumber("REG13-F1");

            Reports.TestStep = "Get the NFE file no.";
            FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();
            var REG0013_FileNum1 = FastDriver.TopFrame.GetFileNumber();

            Reports.TestStep = "Click on skip button to go to QFE.";
            if (!VerifyFileExistence("REG13-F2"))
            {
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.AutoNumberIndicator = false;
                fileRequest.File.FileNumber = "REG13-F2";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            }
            else
                FastDriver.TopFrame.SearchFileByFileNumber("REG13-F2");
            var REG0013_FileNum2 = FastDriver.TopFrame.GetFileNumber(); ;

            Reports.TestStep = "Navigate to Starter ref screen & selecting all items radio button.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText(REG0013_FileNum1 + FAKeys.Tab);
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();

            Reports.TestStep = "Cannot copy from pending file.";
            Support.AreEqual(@"Cannot copy data from a Pending File.", FastDriver.WebDriver.HandleDialogMessage().Clean());

            Reports.TestStep = "In Fee entry screen Select All fee checkbox & Click on Calculate Fees button.";
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
            FastDriver.FileFees.AllFees.FASetCheckbox(true);
            FastDriver.FileFees.CalculateFees.FAClick();

            Reports.TestStep = "Calculate Recording Fee.";
            FastDriver.CalculateFees.WaitForScreenToLoad();
            FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem(@"Mortgage");
            FastDriver.CalculateFees.RecordingFeesPages.FASetText(@"3");
            FastDriver.CalculateFees.RecordingFeesConsiderationAmount.FASetText(@"500.00");

            Reports.TestStep = "Click on Add to Add Recording Fee.";
            FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

            Reports.TestStep = "Click on Next Button.";
            FastDriver.CalculateFees.Next.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
            Playback.Wait(250);

            Reports.TestStep = "Click on Next Button.";
            FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.Next);
            FastDriver.CalculateFees.Next.FAClick();
            Playback.Wait(3000);

            Reports.TestStep = "Create charge for buyer.";
            FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.SummaryFastFeeDescription);
            if (FastDriver.CalculateFees.SummaryFastFeeDescription.FAGetText().Contains("1064_Recording_Fee_Deed"))
            {
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItem(@"1064_Recording_Fee_Deed");
            }
            else
            {
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItemBySendingKeys("+");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Add Fee Dialog");
                FastDriver.FileFeesDlg.SwitchToDialogContentFrame();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem(@"Recording Fee - Deed");
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(@"Record Quit Claim Deed");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable);
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction("Description", "Record Quit Claim Deed", "Sel", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                //Hack: handle this error message ReferenceError:'m_SelectedfastFee' is undefined when runs script
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryChargeTo);
            }
            FastDriver.CalculateFees.SummaryChargeTo.FASelectItem(@"Buyer");
            FastDriver.BottomFrame.Done();
            var value = FastDriver.WebDriver.HandleDialogMessage();
            if (value.Contains("Please complete all required fields"))
            {
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
            }

            Reports.TestStep = "Select Products ,settlement and Property Information.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG12-F1" + FAKeys.Tab);
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.Products.FASetCheckbox(true);
            FastDriver.StarterReference.SettlementInformation.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();

            Reports.TestStep = "Target File has FACC Fees - Process Aborted.";
            Support.AreEqual(@"Target File has FACC Fees - Process Aborted.", FastDriver.WebDriver.HandleDialogMessage().Clean());

            Reports.TestStep = "Select all file items From master file.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1" + FAKeys.Tab);
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();

            Reports.TestStep = "Target File has FACC Fees - Process Aborted.";
            Support.AreEqual(@"Target File has FACC Fees - Process Aborted.", FastDriver.WebDriver.HandleDialogMessage().Clean());

            Reports.TestStep = "Select Buyer Seller from master file.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1" + FAKeys.Tab);
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.BusinessSource.FASetCheckbox(true);
            FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
            FastDriver.StarterReference.SellersData.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();

            Reports.TestStep = "Copy same data from starter ref file.";
            Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Select Buyer as seller from master file.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1" + FAKeys.Tab);
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.MaketheBuyersastheSellers.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();

            Reports.TestStep = "Copy same data from starter ref file.";
            Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Verify buyer as seller in target file.";
            FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
            Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.IsVisible().ToString(), "ChangeOO button exist.");
            value = FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Individual", value);
            Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Husband/Wife", value);
            Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Individual", value);
            Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean());
            value = FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem();
            if (value == null)
                value = "";
            Support.AreEqual(@"Husband/Wife", value);
            Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Clean());
            Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Clean());

            Reports.TestStep = "verify Default option is Select File Items.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            Support.AreEqual(@"True", FastDriver.StarterReference.SelectFileItems.Selected.ToString(), "'Select File Items' checkbox is checked.");

            Reports.TestStep = "Entering the REG0013_FileNum2 number in the File Number text box.";
            FastDriver.TopFrame.SearchFileByFileNumber(REG0013_FileNum2);

            Reports.TestStep = "Copy all the file items from REG0006_FileNum1";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1" + FAKeys.Tab);
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
            FastDriver.CopyDocuments.WaitForScreenToLoad();
            FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

            Reports.TestStep = "Click on Done.";
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.WaitForScreenToLoad().CopyNow.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Removing FastSearch Doc.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
            FastDriver.WebDriver.WaitForActionToComplete(() => {
                if (!FastDriver.DocumentRepository.DocumentsTable.Exists())
                {
                    return true;
                }
                if (FastDriver.DocumentRepository.SearchResult.Exists())
                {
                    FastDriver.DocumentRepository.SearchResult.FAClick();
                    FastDriver.DocumentRepository.Remove.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                    FastDriver.DocumentRepository.WaitForScreenToLoad();
                }

                return FastDriver.DocumentRepository.SearchResult.Exists();
            });

        }

        private void CreateMasterFilesREG0014(bool isExist)
        {

            Reports.TestStep = "Create a File and save it as 'REG0014_FileNum1'";
            if (!isExist)
            {
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.AutoNumberIndicator = false;
                fileRequest.File.FileNumber = "REG14-F1";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            }
            else
                FastDriver.TopFrame.SearchFileByFileNumber("REG14-F1");
            var REG0014_FileNum1 = FastDriver.TopFrame.GetFileNumber();

            Reports.TestStep = "Set an instance of the Lease Details with charge and Lease Amount and Reference No.";
            FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
            FastDriver.LeaseDetail.FindGABcode(@"HUDLEASE03");
            var value = FastDriver.WebDriver.HandleDialogMessage();
            if (!value.Contains("A check has been issued"))
            {
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.Reference.FASetText(@"9585655");
                FastDriver.LeaseDetail.LeaseAmount.FASetText(@"500.00");
                FastDriver.LeaseDetail.Per.FASelectItem(@"Month");
                FastDriver.LeaseDetail.For.FASetText(@"10");
                FastDriver.LeaseDetail.ChargeDescription.FASetText(@"#");
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, @"#", buyerCharge: 20, sellerCharge: 20);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual(@"Check Amount: $ 40.00", FastDriver.LeaseDetail.CheckAmount.FAGetText().Clean());
            }

            Reports.TestStep = "Print All Checks.";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
            if (!FastDriver.ActiveDisbursementSummary.Issued.Exists())
            {
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad(FastDriver.PrintChecks.Deliver);
                FastDriver.PrintChecks.Deliver.FAClick();

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItem(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();

                Reports.TestStep = "Click OK on Overdraftdialog.";
                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.WaitForDeliveryWindow();
                }
                if (FastDriver.PasswordConfirmationDlg.IsOverDraftReasonDialogPresent())
                    FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                if (FastDriver.PasswordConfirmationDlg.IsPasswordConfirmationDialogPresent())
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
            }

            Reports.TestStep = "Select all file items From master file.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2");
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();

            Reports.TestStep = "Click on Ok button.";
            value = FastDriver.WebDriver.HandleDialogMessage();
            if(!value.Contains("Error(s) occured"))
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "verify for TARGET FILE has VALID DISBURSEMENTS - Process Aborted.";
            FastDriver.StarterReference.WaitForScreenToLoad();
            Support.AreEqual(@"Error: TARGET FILE has VALID DISBURSEMENTS - Process Aborted", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

            Reports.TestStep = "Create a new File and save it as 'REG0014_FileNum2'";
            if (!VerifyFileExistence("REG14-F2"))
            {
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = this.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.AutoNumberIndicator = false;
                fileRequest.File.FileNumber = "REG14-F2";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            }
            else
                FastDriver.TopFrame.SearchFileByFileNumber("REG14-F2");
            var REG0014_FileNum2 = FastDriver.TopFrame.GetFileNumber();

            Reports.TestStep = "Enter first fee in Title and escrow.";
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
            if (FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.GetInputValue).Message.Clean() != "1.99")
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99");
            if (FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.GetInputValue).Message.Clean() != "2.99")
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99");
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Set on final button in Invoice screen.";
            FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
            if (FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean() != "FINAL")
            {
                Support.AreEqual(@"True", FastDriver.InvoiceFees.Final.Enabled.ToString(), "Verify whether the Final element is enabled.");
                FastDriver.InvoiceFees.Final.FAClick();
            }

            Reports.TestStep = "Select all file items From master file.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG13-F2" + FAKeys.Tab);
            FastDriver.StarterReference.AllFileItems.FASetCheckbox(true);

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.CopyNow.FAClick();

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "verify for TARGET FILE has Final or Adj Invoices.";
            FastDriver.StarterReference.WaitForScreenToLoad();
            Support.AreEqual(@"Delete Error: TARGET FILE has VALID INVOICES - Process Aborted", FastDriver.StarterReference.ErrMessage.FAGetText().Clean());

            Reports.TestStep = "select the Property and notes including Documents.";
            FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
            FastDriver.StarterReference.StarterFileNumber.FASetText("REG06-F1");
            FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
            FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
            FastDriver.StarterReference.Notes.FASetCheckbox(true);
            FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
            FastDriver.WebDriver.HandleDialogMessage();

            Reports.TestStep = "Copy documents.";
            FastDriver.CopyDocuments.WaitForScreenToLoad();
            FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);

            Reports.TestStep = "Click on Done.";
            FastDriver.BottomFrame.Done();
            value = FastDriver.WebDriver.HandleDialogMessage();
            if (value.Contains("Following image(s) already exists"))
            {
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
            }

            Reports.TestStep = "Click on copy now button.";
            FastDriver.StarterReference.WaitForScreenToLoad();
            FastDriver.StarterReference.CopyNow.FAClick();

            Reports.TestStep = "Click on overwrite option for copying of file information and documents";
            Support.AreEqual(@"Previously entered data will be overwritten, do you want to continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            Reports.TestStep = "Select the Accomm Sign-Customer Buyer document for Delivery.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
            FastDriver.DocumentRepository.AccommSigning_CustomerBuyer.FAClick();

            Reports.TestStep = "Navigate to Home Warranty screen.";
            FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

            Reports.TestStep = "Click on payment details.";
            FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

            Reports.TestStep = "Click on Done in Dialog Box.";
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
            FastDriver.LeftNavigation.ClickHome();
            FastDriver.WebDriver.HandleDialogMessage(false, true);
            FastDriver.WebDriver.HandleDialogMessage();

        }

        private void FillPaymentDetailsDialog(double? BuyerCharge = null, double? SellerPaymentMethod = null, string BuyerPaidByOtherMethod = null, double? BuyerPaidAtClosing = null, double? BuyerPaidBeforeClosing = null, double? BuyerPaidByOther = null, double? SellerCharge = null, double? PaidbySellerAtClosing = null, double? PaidbySellerBeforeClosing = null, double? PaidbySellerOthers = null, double? sellerCredit = null, string SellerPaidbyOthersPaymentMethod = "", string description = "", bool? useDefault = null, string payeeName = "", string SellerCreditPaymentMethod = "", bool? handleMessage = null, bool isCD = true)
        {

            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 30);
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

            if (isCD)
            {
                if (BuyerCharge.HasValue)
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(BuyerCharge.ToString());

                if (BuyerPaidByOtherMethod != null && BuyerPaidByOtherMethod != "")
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem(BuyerPaidByOtherMethod);

                if (BuyerPaidAtClosing.HasValue)
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(BuyerPaidAtClosing.ToString());

                if (BuyerPaidBeforeClosing.HasValue)
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText(BuyerPaidBeforeClosing.ToString());

                if (BuyerPaidByOther.HasValue)
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(BuyerPaidByOther.ToString());

                if (SellerCharge.HasValue)
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(SellerCharge.ToString());

                if (PaidbySellerAtClosing.HasValue)
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(PaidbySellerAtClosing.ToString());

                if (PaidbySellerBeforeClosing.HasValue)
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(PaidbySellerBeforeClosing.ToString());

                if (PaidbySellerOthers.HasValue)
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(PaidbySellerOthers.ToString());

                if (sellerCredit.HasValue)
                    FastDriver.PaymentDetailsDlg.SellerCredit.FASetText(sellerCredit.ToString());

                if (!SellerPaidbyOthersPaymentMethod.Equals(""))
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(SellerPaidbyOthersPaymentMethod);

                if (!SellerCreditPaymentMethod.Equals(""))
                    FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem(SellerCreditPaymentMethod);

                if (!description.Equals(""))
                    FastDriver.PaymentDetailsDlg.Description.FASetText(description);

                if (useDefault.HasValue)
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(useDefault);

                if (payeeName.Equals("EMPTY"))
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");

                else if (!payeeName.Equals(""))
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText(payeeName);
            }
            else
            {
                if (BuyerCharge.HasValue)
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(BuyerCharge.ToString());

                if (BuyerPaidByOtherMethod != null)
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem(BuyerPaidByOtherMethod);

                if (SellerCharge.HasValue)
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(SellerCharge.ToString());

                if (SellerPaymentMethod.HasValue)
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASetText(SellerPaymentMethod.ToString());
            }
            //closes the dialog window and switches back to the Fast window;
            FastDriver.PaymentDetailsNewLoanDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.btnDone.FAClick();
            Playback.Wait(500);
            if (handleMessage == true)
                FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.PaymentDetailsDlg.SwitchToContentFrame();


        }

        private void CreateStandardFile(string businessGab = "HUDFLINSR1", string directedGab = "DirectedBYGABcode", string assocBusGab = "HUDASLNDR1", bool subEscrow = false, bool useAsMasterFile = false, bool buyer = false, bool seller = false)
        {

            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(businessGab);
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(directedGab);
            FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();
            FastDriver.QuickFileEntry.UseAsMasterFile.FASetCheckbox(useAsMasterFile);
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(!AutoConfig.UseCDFormType);
            FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(AutoConfig.UseCDFormType);
            FastDriver.QuickFileEntry.SubEscrow.FASetCheckbox(subEscrow);
            //FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000" + FAKeys.Tab);
            FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount.FASetText("3000.00");
            //FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("2000.00");
            FastDriver.QuickFileEntry.TermsDatesNewLoanLiability.FASetText("2000.00");
            FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
            FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
            FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
            FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
            FastDriver.QuickFileEntry.PropertyInformationTRact.FASetText("Tract");
            FastDriver.QuickFileEntry.PropertyInformationBuilding.FASetText("Building");
            FastDriver.QuickFileEntry.PropertyInformationBook.FASetText("Book");
            FastDriver.QuickFileEntry.PropertyInformationPage.FASetText("Page");
            FastDriver.QuickFileEntry.PropertyInformationSection.FASetText("section");
            FastDriver.QuickFileEntry.PropertyInformationTownShip.FASetText("Township");
            FastDriver.QuickFileEntry.PropertyInformationRange.FASetText("Range");
            FastDriver.QuickFileEntry.PropertyInformationParcel.FASetText("Parcel");
            FastDriver.QuickFileEntry.PropertyInformationSubdivisionCondominium.FASetText("Subdivision1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
            FastDriver.QuickFileEntry.PropertyPropTaxYear2.FASetText("2006-2007");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
            if (buyer)
            {
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
            }
            if (seller)
            {
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
            }
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText(assocBusGab);
            FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
            FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
            FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
            Playback.Wait(1000);

            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }
        }

        private CreateFileRequest GetDetailedCreateFileDefaultRequest()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    SalesPriceAmount = 5000.00m,
                    LiabilityAmount = 3000.00m,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[]
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    },
                    Services = new Service[]
                    {
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO"
                        },
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            Tract = "Tract",
                            Building = "Building",
                            Book = "Book",
                            Page = "Page",
                            Section = "section",
                            Township = "Township",
                            Range = "Range",
                            Parcel = "Parcel",
                            Condominium = "Subdivision1",
                            PropertyTypeObjectCD = "SF",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Country = "USA"
                                }
                            },
                            Taxes = new FASTWCFHelpers.FastFileService.Taxes[]
                            {
                                new FASTWCFHelpers.FastFileService.Taxes()
                                {
                                    TaxID = "Prop1APN1",
                                    GenTaxCheck = false,
                                    TotalInstallmentTax = 500

                                },
                                new FASTWCFHelpers.FastFileService.Taxes()
                                {
                                    TaxID = "9845012345",
                                    TaxYear = "2006-2007",
                                    GenTaxCheck = false,
                                    TotalInstallmentTax = 0
                                }
                            }
                        }
                    },
                    Buyers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },
                        new BuyerSeller()
                        {
                            Type = "Husband and Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1Lastname",
                        },
                        new BuyerSeller()
                        {
                            Type = "Husband and Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2Lastname"
                        }
                    },
                    NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                    {
                        LoanNumber = "WCF_DefaultLoanNumber",
                        NewLoanAmount = 5000.00m,
                        LiabilityAmount = 5000.00m,
                        BenMortgageeTextID = 0,
                        FileBusinessParty = new FileBusinessParty
                        {
                            Name = "Nhat Nguyen",
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        },
                        LoanTypeCdID = 0,
                        FundDate = DateTime.Today
                    },
                    FileNotes = new FileNote[]
                    {
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
            };
            #endregion
        }

        private void CreateDocument(string templateType, string templateName, string templateDescription, string state = "CA", bool multipleDocs = false)
        {

            FastDriver.DocumentRepository.SwitchToContentFrame();
            if (!multipleDocs)
                FastDriver.DocumentRepository.Add.FAClick();
            else
                FastDriver.DocumentRepository.AddDocRep.FAClick();
            Reports.TestStep = "Add Document to Document Repository screen.";
            FastDriver.AdHocDocuments.WaitForScreenToLoad();
            FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
            FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys(templateType);
            FastDriver.AdHocDocuments.TemplateDescription.FASetText(templateDescription);
            if (state != null)
                FastDriver.AdHocDocuments.State.FASelectItem(state);

            Reports.TestStep = "validate the data entered in Adhoc Documents.";
            Support.value = FastDriver.AdHocDocuments.Source.FAGetSelectedItem();
            if (Support.value == null)
                Support.value = "";
            Support.AreEqual(@"Both", Support.value);
            Support.value = FastDriver.AdHocDocuments.TemplateType.FAGetSelectedItem(); ;
            if (Support.value == null)
                Support.value = "";
            Support.AreEqual(templateType, Support.value);
            Support.AreEqual(templateDescription, FastDriver.AdHocDocuments.TemplateDescription.FAGetValue().Clean());
            FastDriver.AdHocDocuments.FindNow.FAClick();
            FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", templateName, "Description", TableAction.Click);
            FastDriver.AdHocDocuments.CreateSave.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            Playback.Wait(5000);

        }

        private void FMUC0003_REG00048A_PreRequisite(Credentials credentials, bool chked)
        {
            try
            {
                Reports.TestDescription = "It is a preRequisite for REG0048, 49 and 50";
                try
                {
                    FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                    Reports.TestStep = "Navigate to Offices";
                    FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                    if (FastDriver.OfficeSetupOffice.ANPolicyNumber.Exists())
                        FastDriver.OfficeSetupOffice.ANPolicyNumber.FASetCheckbox(chked);
                    FastDriver.BottomFrame.Done();

                }

                catch (Exception ex)
                {
                    FailTest(ex.Message);
                }
            }

            catch (Exception ex)
            { FailTest(ex.Message); }

        }
        
        private void SetDisplayPDFinBrowser_ON()
        {
            //Turn ON 'Display PDF in brower' for Adobe Arobat Reader X
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bBrowserIntegration", "1", RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bAllowByteRangeRequests", "1", RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bBrowserDisplayInReadMode", "1", RegistryValueKind.DWord);

            //Turn ON 'Display PDF in brower' for Adobe Arobat Reader XI
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bBrowserIntegration", "1", RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bAllowByteRangeRequests", "1", RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bBrowserDisplayInReadMode", "1", RegistryValueKind.DWord);
        }

        private void SetDisplayPDFinBrowser_OFF()
        {
            //Turn OFF 'Display PDF in brower' for Adobe Arobat Reader X
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bBrowserIntegration", "0", RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bAllowByteRangeRequests", "0", RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bBrowserDisplayInReadMode", "0", RegistryValueKind.DWord);

            //Turn OFF 'Display PDF in brower' for Adobe Arobat Reader XI
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bBrowserIntegration", "0", RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bAllowByteRangeRequests", "0", RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bBrowserDisplayInReadMode", "0", RegistryValueKind.DWord);
        }
                
        private void SlowSetText(string textToSet)
        {
            char[] arrayOfChar = textToSet.ToCharArray();
            foreach (char c in arrayOfChar)
            {
                Keyboard.SendKeys(c.ToString());
                Playback.Wait(250);
            }

        }

        private void FinalizeDocument()
        {
            FastDriver.WebDriver.WaitForActionToComplete(() => {
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad(FastDriver.DocumentPreparationMenu.menuDocument);
                FastDriver.DocumentPreparationMenu.Expand1.FAClick();
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(1000);
                try
                {
                    FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }, timeout: 1000, idleInterval: 10);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
