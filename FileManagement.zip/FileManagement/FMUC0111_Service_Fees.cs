﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using FASTSelenium.PageObjects;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0111 : MasterTestClass
    {
        #region BAT

        #region Test FMUC0111_BAT0001

        [TestMethod]
        public void FMUC0111_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_01: Service Fee.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Validate the radio Button and set office.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);

                Reports.TestStep = "Select Office from Payee Search Dialog.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.TableinpayeeSearch.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);//FASTLibrary.FASTLibrary.OfficeInUse_1
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_BAT0001

        #region Test FMUC0111_BAT0002

        [TestMethod]
        public void FMUC0111_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_01: View Payee Details and Remove Service Fees.";

                ////Copy BAT1

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Validate the radio Button and set office.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);

                Reports.TestStep = "Select Office from Payee Search Dialog.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.TableinpayeeSearch.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);//FASTLibrary.FASTLibrary.OfficeInUse_1
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                ////

                Reports.TestStep = "Validate Buttons in the screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Cancel.IsEnabled().ToString().ToLower(), "Cancel.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferDetaiLs.IsEnabled().ToString().ToLower(), "TransferDetaiLs.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Highlight the required row";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(5, AutoConfig.SelectedOfficeName, 5, TableAction.Click);

                Reports.TestStep = "Validate 'New', 'Remove', 'Transfer', 'Transfer All' and 'Payee Details' buttons";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Click on payee details";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.PayeeDetails.FAClick();

                Reports.TestStep = "Validate the page.";
                FastDriver.PayeeDetailsDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Remove button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Remove.FAClick();

                Reports.TestStep = "Validate No Record are present in table";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("0", (FastDriver.ServiceFee.Table.GetRowCount() - 1).ToString(), "Verify RowCount");
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_BAT0002

        #region Test FMUC0111_BAT0003

        [TestMethod]
        public void FMUC0111_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF2_01: Transfer Service Fees, View Transfer Details, Generate Service Fee Transfer Report.";

                ////Copy BAT1

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Validate the radio Button and set office.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);

                Reports.TestStep = "Select Office from Payee Search Dialog.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.TableinpayeeSearch.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);//FASTLibrary.FASTLibrary.OfficeInUse_1
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                ////

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Validate the radio Button and set office.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad("Payee Search", FastDriver.AddressBookSearchDlg.rbFileProductionOfficesinPS);

                Support.AreEqual("true", FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.IsDisplayed().ToString().ToLower());
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);
                Support.AreEqual("true", FastDriver.AddressBookSearchDlg.rbFileProductionOfficesinPS.IsDisplayed().ToString().ToLower(), "Is rbFileProductionOfficesinPS Displayed");

                Reports.TestStep = "Select Office from Payee Search Dialog.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbFileProductionOfficesinPS.FASetCheckbox(true);
                Playback.Wait(5000);
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.TableinpayeeSearch.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate Buttons in the screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Cancel.IsEnabled().ToString().ToLower(), "Cancel.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferDetaiLs.IsEnabled().ToString().ToLower(), "TransferDetaiLs.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Highlight the required row";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(5, AutoConfig.SelectedOfficeName, 5, TableAction.Click);

                Reports.TestStep = "Validate 'New', 'Remove', 'Transfer', 'Transfer All' and 'Payee Details' buttons";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Click on Transfer button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Validating the 1st Service Fee is getting Transmitted.";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("Transmitted", FastDriver.ServiceFee.Table.PerformTableAction(4, "999.00", 1, TableAction.GetText).Message);

                Reports.TestStep = "Validate Date of Issue";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                //Support.AreEqual(DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy").Replace("/", "-"),FastDriver.ServiceFee.Table.PerformTableAction(4,"999.00",3,TableAction.GetText).Message);
                //Support.AreEqual(DateTime.Today.ToString("MM/dd/yyyy").Replace("/", "-"), FastDriver.ServiceFee.Table.PerformTableAction(4, "999.00", 3, TableAction.GetText).Message);
                Support.AreEqual(DateTime.Now.ToPST().ToDateString(), FastDriver.ServiceFee.Table.PerformTableAction(4, "999.00", 3, TableAction.GetText).Message);

                Reports.TestStep = "Click on Transfer details button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.TransferDetaiLs.FAClick();

                Reports.TestStep = "Select Preview and deliver.";
                FastDriver.TransferDetailsDlg.WaitForScreenToLoad();

                FastDriver.TransferDetailsDlg.cboMethod.FASelectItem("Preview");
                FastDriver.TransferDetailsDlg.Deliver.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_BAT0003

        #region Test FMUC0111_BAT0004

        [TestMethod]
        public void FMUC0111_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF3_01: Cancel Service Fees.";
                //// copy bat3
                //// copy BAT1

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Validate the radio Button and set office.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);

                Reports.TestStep = "Select Office from Payee Search Dialog.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.TableinpayeeSearch.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);//FASTLibrary.FASTLibrary.OfficeInUse_1
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                ////

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Validate the radio Button and set office.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();

                Support.AreEqual("true", FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.IsDisplayed().ToString().ToLower());
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);
                Support.AreEqual("true", FastDriver.AddressBookSearchDlg.rbFileProductionOfficesinPS.IsDisplayed().ToString().ToLower(), "Is rbFileProductionOfficesinPS Displayed");

                Reports.TestStep = "Select Office from Payee Search Dialog.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);
                FastDriver.AddressBookSearchDlg.TableinpayeeSearch.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                //Reports.TestStep = "Enter Service Fees";
                //FastDriver.ServiceFee.WaitForScreenToLoad();
                //FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate Buttons in the screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Cancel.IsEnabled().ToString().ToLower(), "Cancel.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferDetaiLs.IsEnabled().ToString().ToLower(), "TransferDetaiLs.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Highlight the required row";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(5, AutoConfig.SelectedOfficeName, 5, TableAction.Click);

                Reports.TestStep = "Validate 'New', 'Remove', 'Transfer', 'Transfer All' and 'Payee Details' buttons";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Click on Transfer button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Click on Transfer details button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.TransferDetaiLs.FAClick();

                Reports.TestStep = "Select Preview and deliver.";
                FastDriver.TransferDetailsDlg.WaitForScreenToLoad();
                FastDriver.TransferDetailsDlg.cboMethod.FASelectItem("Preview");
                FastDriver.TransferDetailsDlg.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.TransferDetailsDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                ////

                Reports.TestStep = "Validate Buttons in the screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Cancel.IsEnabled().ToString().ToLower(), "Cancel.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferDetaiLs.IsEnabled().ToString().ToLower(), "TransferDetaiLs.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Highlight the required row";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(5, AutoConfig.SelectedOfficeName, 5, TableAction.Click);

                Reports.TestStep = "Validate 'New', 'Remove', 'Transfer', 'Transfer All' and 'Payee Details' buttons";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("true", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Click on Cancel button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Cancel.FAClick();

                Reports.TestStep = "Enter the details.";
                FastDriver.CancelDlg.WaitForScreenToLoad();
                FastDriver.CancelDlg.Reason.FASetText("Test");
                FastDriver.CancelDlg.OK.FAClick();

                Reports.TestStep = "Validate Cancelation";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ServiceFee.Table.PerformTableAction(4, "999.00", 1, TableAction.GetText).Message);
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_BAT0004

        #endregion BAT

        #region REG

        #region Test FMUC0111_REG0001

        [TestMethod]
        public void FMUC0111_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM13608: Create Service Fee Transaction.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and Validate buttons in service fees screen on first page load";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Cancel.IsEnabled().ToString().ToLower(), "Cancel.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferDetaiLs.IsEnabled().ToString().ToLower(), "TransferDetaiLs.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FASetCheckbox(true);
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Sel", TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate Record is added in table";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("1", (FastDriver.ServiceFee.Table.GetRowCount() - 1).ToString(), "Verify RowCount");
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0001

        #region Test FMUC0111_REG0002

        [TestMethod]
        public void FMUC0111_REG0002()
        {
            try
            {
                Reports.TestDescription = "1) FM13609: Enter Service Fee $ amount and click on Payee Details and verify the Status.  2) Validate Pending fees in Disbursement screen";

                ////copy reg1

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and Validate buttons in service fees screen on first page load";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Cancel.IsEnabled().ToString().ToLower(), "Cancel.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferDetaiLs.IsEnabled().ToString().ToLower(), "TransferDetaiLs.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FASetCheckbox(true);
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Sel", TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                ////

                Reports.TestStep = "Enter Service Fees and click on Payee Details";
                FastDriver.ServiceFee.WaitForScreenToLoad();

                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "12.00");
                FastDriver.ServiceFee.PayeeDetails.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate the Pending status of the service fee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                //FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ServiceFee.Table.PerformTableAction("Service Fee Payee", AutoConfig.SelectedOfficeName, "Status", TableAction.GetText).Message);

                Reports.TestStep = "Validate the message when user navigates away when there is pending sevice fee.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Pending Service Fee Transfers exist. Do you wish to navigate away from this page?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Validate Pending service fee can be seen in Active Disbursement summary";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.ServiceFeeTable.PerformTableAction("Status", "Pending", "Status", TableAction.Click);

                Reports.TestStep = "Validate Service fee can be transmitted along with the File Fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                Reports.TestStep = "Add a fee in Fee Entry.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", @"New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", @"New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "22.22");
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Handle Password/OverDraft Confirmation Dialog.";
                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Cancel in Print Dialog.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Service fee got transmitted along with the File Fees";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                Support.AreEqual("12.00", FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 4, TableAction.GetText).Message);
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 4, TableAction.Click);

                FastDriver.ServiceFee.Cancel.FAClick();
                FastDriver.CancelDlg.WaitForScreenToLoad();

                FastDriver.CancelDlg.Reason.FASetText("Test reason");
                FastDriver.CancelDlg.OK.FAClick();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0002

        #region Test FMUC0111_REG0003

        [TestMethod]
        public void FMUC0111_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM13609_1: Enter Service Fee $ amount and click on Transfer and verify the Status.";

                ////copy reg2
                ////copy reg1

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and Validate buttons in service fees screen on first page load";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Cancel.IsEnabled().ToString().ToLower(), "Cancel.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferDetaiLs.IsEnabled().ToString().ToLower(), "TransferDetaiLs.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FASetCheckbox(true);
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Sel", TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                ////

                Reports.TestStep = "Enter Service Fees and click on Payee Details";
                FastDriver.ServiceFee.WaitForScreenToLoad();

                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "12.00");
                FastDriver.ServiceFee.PayeeDetails.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate the Pending status of the service fee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                //FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ServiceFee.Table.PerformTableAction("Service Fee Payee", AutoConfig.SelectedOfficeName, "Status", TableAction.GetText).Message);

                Reports.TestStep = "Validate the message when user navigates away when there is pending sevice fee.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Pending Service Fee Transfers exist. Do you wish to navigate away from this page?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Validate Pending service fee can be seen in Active Disbursement summary";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.ServiceFeeTable.PerformTableAction("Status", "Pending", "Status", TableAction.Click);

                Reports.TestStep = "Validate Service fee can be transmitted along with the File Fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                Reports.TestStep = "Add a fee in Fee Entry.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", @"New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", @"New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "22.22");
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Handle Password/OverDraft Confirmation Dialog.";
                FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Cancel in Print Dialog.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Service fee got transmitted along with the File Fees";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                Support.AreEqual("12.00", FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 4, TableAction.GetText).Message);
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 4, TableAction.Click);

                FastDriver.ServiceFee.Cancel.FAClick();
                FastDriver.CancelDlg.WaitForScreenToLoad();

                FastDriver.CancelDlg.Reason.FASetText("Test reason");
                FastDriver.CancelDlg.OK.FAClick();
                ////

                Reports.TestStep = "Click on Remove Button";
                FastDriver.ServiceFee.WaitForScreenToLoad();

                FastDriver.ServiceFee.Table.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ServiceFee.Remove.FAClick();

                Reports.TestStep = "Click on New button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FASetCheckbox(true);
                FastDriver.PayeeSearchDlg.PayeeName_2.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees and click on Transfer";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "72.50");
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Validate the status of the Remove button when the service fee in transmitted status is selected";
                FastDriver.ServiceFee.Table.PerformTableAction("Status", "Transmitted", "Status", TableAction.Click);
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");

                Reports.TestStep = "Validate the Service Fee in the fee recap and service fee recap section";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual(@"$72.50", FastDriver.ServiceFee.TotalServiceFees.FAGetText(), "TotalServiceFees.FAGetText");
                FastDriver.ServiceFee.Table.PerformTableAction("Status", "Transmitted", "Status", TableAction.Click);
                FastDriver.ServiceFee.TransferDetaiLs.FAClick();

                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.ServiceFeeDetailsDlg.Amount.FAGetText().Contains("72.50").ToString().ToLower(), "Amount Contains 72.50");
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0003

        #region Test FMUC0111_REG0004

        [TestMethod]
        public void FMUC0111_REG0004()
        {
            try
            {
                Reports.TestDescription = "Perform all the deliveries(Print, Preview, Email, Fax, Imagedoc).";
                ////Copy Reg3
                ////copy reg2
                ////copy reg1

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and Validate buttons in service fees screen on first page load";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                Support.AreEqual("true", FastDriver.ServiceFee.New.IsEnabled().ToString().ToLower(), "New.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Cancel.IsEnabled().ToString().ToLower(), "Cancel.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.Transfer.IsEnabled().ToString().ToLower(), "Transfer.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferAll.IsEnabled().ToString().ToLower(), "TransferAll.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.TransferDetaiLs.IsEnabled().ToString().ToLower(), "TransferDetaiLs.IsEnabled");
                Support.AreEqual("false", FastDriver.ServiceFee.PayeeDetails.IsEnabled().ToString().ToLower(), "PayeeDetails.IsEnabled");

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FASetCheckbox(true);
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Sel", TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                ////

                Reports.TestStep = "Enter Service Fees and click on Payee Details";
                FastDriver.ServiceFee.WaitForScreenToLoad();

                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "12.00");
                FastDriver.ServiceFee.PayeeDetails.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate the Pending status of the service fee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                //FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ServiceFee.Table.PerformTableAction("Service Fee Payee", AutoConfig.SelectedOfficeName, "Status", TableAction.GetText).Message);

                Reports.TestStep = "Validate the message when user navigates away when there is pending sevice fee.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Pending Service Fee Transfers exist. Do you wish to navigate away from this page?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Validate Pending service fee can be seen in Active Disbursement summary";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.ServiceFeeTable.PerformTableAction("Status", "Pending", "Status", TableAction.Click);

                Reports.TestStep = "Validate Service fee can be transmitted along with the File Fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                Reports.TestStep = "Add a fee in Fee Entry.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", @"New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", @"New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "22.22");
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Handle Password/OverDraft Confirmation Dialog.";
                FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Cancel in Print Dialog.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Service fee got transmitted along with the File Fees";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                Support.AreEqual("12.00", FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 4, TableAction.GetText).Message);
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 4, TableAction.Click);

                FastDriver.ServiceFee.Cancel.FAClick();
                FastDriver.CancelDlg.WaitForScreenToLoad();

                FastDriver.CancelDlg.Reason.FASetText("Test reason");
                FastDriver.CancelDlg.OK.FAClick();
                ////

                Reports.TestStep = "Click on Remove Button";
                FastDriver.ServiceFee.WaitForScreenToLoad();

                FastDriver.ServiceFee.Table.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ServiceFee.Remove.FAClick();

                Reports.TestStep = "Click on New button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FASetCheckbox(true);
                FastDriver.PayeeSearchDlg.PayeeName_2.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees and click on Transfer";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "72.50");
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Validate the status of the Remove button when the service fee in transmitted status is selected";
                FastDriver.ServiceFee.Table.PerformTableAction("Status", "Transmitted", "Status", TableAction.Click);
                Support.AreEqual("false", FastDriver.ServiceFee.Remove.IsEnabled().ToString().ToLower(), "Remove.IsEnabled");

                Reports.TestStep = "Validate the Service Fee in the fee recap and service fee recap section";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual(@"$72.50", FastDriver.ServiceFee.TotalServiceFees.FAGetText(), "TotalServiceFees.FAGetText");
                FastDriver.ServiceFee.Table.PerformTableAction("Status", "Transmitted", "Status", TableAction.Click);
                FastDriver.ServiceFee.TransferDetaiLs.FAClick();

                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.ServiceFeeDetailsDlg.Amount.FAGetText().Contains("72.50").ToString().ToLower(), "Amount Contains 72.50");
                FastDriver.DialogBottomFrame.ClickDone();
                ////

                Reports.TestStep = "Validate Print deliver action on Service Fees";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction("Status", "Transmitted", "Status", TableAction.Click);
                FastDriver.ServiceFee.TransferDetaiLs.FAClick();

                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");

                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Validate Email deliver action on Service Fees";
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                FastDriver.ServiceFeeDetailsDlg.Method.FASelectItem("Email");
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");

                FastDriver.EmailDlg.WaitForScreenToLoad();
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false);

                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - " + AutoConfig.FASTHomeURL);
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);

                Reports.TestStep = "Validate Fax deliver action on Service Fees";
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                FastDriver.ServiceFeeDetailsDlg.Method.FASelectItem("Fax");
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");

                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Insert.FAClick();
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Name.FASetText("QA");
                FastDriver.FaxDlg.Attn.FASetText("1");
                FastDriver.FaxDlg.FAXNumber.FASetText(AutoConfig.DeliverFaxTo);
                FastDriver.FaxDlg.FAX.FAClick();

                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 200);

                Reports.TestStep = "Validate Imagedoc deliver action on Service Fees";
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                FastDriver.ServiceFeeDetailsDlg.Method.FASelectItem("Imagedoc");
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");

                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("ImageDoc", 200);

                Reports.TestStep = "Validate Preview deliver action on Service Fees";
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                FastDriver.ServiceFeeDetailsDlg.Method.FASelectItem("Preview");
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.TransferDetailsDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate EventLog for the Service fee process";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(5000);
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.FAGetText().Contains(@"[Transfer Service Fees]").ToString(), @"EventTable.FAGetText() Contains [Transfer Service Fees]");
                Support.AreEqual("True", FastDriver.EventTrackingLog.Comments.FAGetText().Contains(@"Transfer Amount: 72.50").ToString(), "Is Transfer Amount: 72.50 present in " + FastDriver.EventTrackingLog.Comments.FAGetText());
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0004

        #region Test FMUC0111_REG0005

        [TestMethod]
        public void FMUC0111_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM14270: Do not display Service Fee node when Corporate Parent is Other or NAT.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                Reports.TestStep = "Login to ADM and set Corporate Parent to OTHER/NAT";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.CorporateParent.FASelectItem("North American Title (NAT)");
                FastDriver.BottomFrame.Done();

                #region Login

                Reports.TestStep = "Login to Fast Application and Validate Service Fees is not available for NAT/Other";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Validate Service Fees is not available for NAT/Other";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);
                Support.AreEqual("False", FastDriver.PayeeSearchDlg.OfficeTable.FAGetText().Contains(AutoConfig.SelectedOfficeName).ToString(), "Fee Payee selections should not be available as Corporate Parent is Other/NAT");

                Reports.TestStep = "Login to ADM and revert to First American by setting Corporate Parent to FA";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.CorporateParent.FASelectItem("First American (FA)");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0005

        #region Test FMUC0111_REG0006

        [TestMethod]
        public void FMUC0111_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM13611: Not allow increase or decrease of Service Fee amount.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_2.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees and click on Transfer";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "12.00");
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Validate the Service Fee status";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 1, TableAction.Click);

                Reports.TestStep = "Click on Cancel button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Cancel.FAClick();

                Reports.TestStep = "Enter the reason for cancelling.";
                FastDriver.CancelDlg.WaitForScreenToLoad();
                FastDriver.CancelDlg.Reason.FASetText("Test reason");
                FastDriver.CancelDlg.OK.FAClick();

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0006

        #region Test FMUC0111_REG0007

        [TestMethod]
        public void FMUC0111_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM13613: Remove Service Fee transaction.";
                ////copy reg6

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_2.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees and click on Transfer";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "12.00");
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Validate the Service Fee status";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 1, TableAction.Click);

                Reports.TestStep = "Click on Cancel button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Cancel.FAClick();

                Reports.TestStep = "Enter the reason for cancelling.";
                FastDriver.CancelDlg.WaitForScreenToLoad();
                FastDriver.CancelDlg.Reason.FASetText("Test reason");
                FastDriver.CancelDlg.OK.FAClick();

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                ////

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_2.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the service Fee status is pending";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 1, TableAction.Click);

                Reports.TestStep = "Click on Remove Button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Remove.FAClick();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0007

        #region Test FMUC0111_REG0008

        [TestMethod]
        public void FMUC0111_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM13614: Transfer one or all Service Fees.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Sel", TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "3.00");

                Reports.TestStep = "Click on New button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                // Previously set to @"#1^Pending^#4|3.00"
                //FastDriver.ServiceFee.Table.PerformTableAction("#1^Pending^#4|3.00").ToString();
                FastDriver.ServiceFee.ServiceFeeAmount1.FAClick();
                FastDriver.ServiceFee.ServiceFeeAmount1.FASetText("3.00");

                Reports.TestStep = "Click On Transfer All Button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.TransferAll.Highlight();
                FastDriver.ServiceFee.TransferAll.FAClick();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0008

        #region Test FMUC0111_REG0009

        [TestMethod]
        public void FMUC0111_REG0009()
        {
            try
            {
                Reports.TestDescription = "FM13615: Service Fee amount required before Transfer.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Transfer button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Validate Service Fee amount required before Transfer.";
                Support.AreEqual(@"Service Fee amount is required to transfer Service Fees.", FastDriver.WebDriver.HandleDialogMessage());
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0009

        #region Test FMUC0111_REG0010

        [TestMethod]
        public void FMUC0111_REG0010()
        {
            try
            {
                Reports.TestDescription = "FM13616: Cancel Service Fees.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees and click on Transfer";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "12.00");
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Click on Cancel button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Cancel.FAClick();

                Reports.TestStep = "Enter the reason for cancelling.";
                FastDriver.CancelDlg.WaitForScreenToLoad();
                FastDriver.CancelDlg.Reason.FASetText("Test reason");
                FastDriver.CancelDlg.OK.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify if Service Fees is Cancelled";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.Click);
                Support.AreEqual("False", FastDriver.ServiceFee.Cancel.IsEnabled().ToString(), "Cancel.IsEnabled");
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0010

        #region Test FMUC0111_REG0011

        [TestMethod]
        public void FMUC0111_REG0011()
        {
            try
            {
                Reports.TestDescription = "FM13617: Select Payees on Payee Search.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Multiple selection of Payee";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);
                FastDriver.PayeeSearchDlg.PayeeName_2.FASetCheckbox(true);
                FastDriver.PayeeSearchDlg.PayeeName_3.FASetCheckbox(true);
                FastDriver.PayeeSearchDlg.PayeeName_4.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify if all the 4 payees are displayed";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("4", (FastDriver.ServiceFee.Table.GetRowCount() - 1).ToString(), "Table GetRowCount equals 4");
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0011

        #region Test FMUC0111_REG0012

        [TestMethod]
        public void FMUC0111_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM13618: Direct Office as Service Fee Payee.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();

                // Was set to PayeeName_5
                FastDriver.PayeeSearchDlg.PayeeName_2.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "3.00");

                Reports.TestStep = "Click on New button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Service Fees to be paid by File Production Offices options";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount1.FAClick();
                FastDriver.ServiceFee.ServiceFeeAmount1.SendKeys("3.00");
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0012

        #region Test FMUC0111_REG0013

        [TestMethod]
        public void FMUC0111_REG0013()
        {
            try
            {
                Reports.TestDescription = "FM13619_VPD: View Payee Details.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Sel", TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees and click on Payee Details";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 4, TableAction.SetText, "12.00");
                FastDriver.ServiceFee.PayeeDetails.FAClick();

                Reports.TestStep = "View Payee Details.";
                FastDriver.PayeeDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PayeeDetailsDlg.PayeeDetails.FAGetText().Contains(AutoConfig.SelectedOfficeBUID).ToString(), "PayeeDetails Contains SelectedOfficeBUID");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0013

        #region Test FMUC0111_REG0014

        [TestMethod]
        public void FMUC0111_REG0014()
        {
            try
            {
                Reports.TestDescription = "FM13620_FM13621_ED: Service Fees Details (verification is pending in service fees detail). And Executes delivery via a selected Delivery Method.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Navigating to Service Fee screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                Reports.TestStep = "Click on Transfer button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.Highlight();
                FastDriver.ServiceFee.ServiceFeeAmount.FAClick();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("3.00");
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Validate the Service Fee status is Transmitted";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 1, TableAction.Click);

                Reports.TestStep = "Click on Transfer details button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.TransferDetaiLs.FAClick();

                Reports.TestStep = "Service Fees Detail.";
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                FastDriver.ServiceFeeDetailsDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0014

        #region Test FMUC0111_REG0015

        [TestMethod]
        public void FMUC0111_REG0015()
        {
            try
            {
                Reports.TestDescription = "VWC: Service Fees - Warning Conditions.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Navigating to Service Fee screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the service Fee status is pending";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.Highlight();
                FastDriver.ServiceFee.ServiceFeeAmount.FAClick();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("1");

                Reports.TestStep = "Select Home from the tree view";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");

                Reports.TestStep = "User clicks on Done or navigates away from Service Fees screen when Pend Service Fees exist.";
                Support.AreEqual("Pending Service Fee Transfers exist. Do you wish to navigate away from this page?", FastDriver.WebDriver.HandleDialogMessage());
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0015

        #region Test FMUC0111_REG0016

        [TestMethod]
        public void FMUC0111_REG0016()
        {
            try
            {
                Reports.TestDescription = "FVISFA_FVICSF: Field Definitions in Service Fee Amount and Verify Without Entering the reason for cancelling.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                Reports.TestStep = "Navigating to Service Fee screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the service Fee status is pending";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Pending", 1, TableAction.Click);

                Reports.TestStep = "Verify the Field with Invalid data";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.Highlight();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("11111111111111100");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Enter invalid data.";
                Support.AreEqual(@"Please correct invalid data entered.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Validate the Field with Invalid data";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual(@"?", FastDriver.ServiceFee.ServiceFeeAmount.FAGetValue(), "ServiceFee.ServiceFeeAmount");

                Reports.TestStep = "Verify the Service Fee Amount with exact value";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("12345678912.22");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Validate the Service Fee Amount with exact value";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual(@"12,345,678,912.22", FastDriver.ServiceFee.ServiceFeeAmount.FAGetValue());

                Reports.TestStep = "Verify the Field with lower Boundary Value";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("123456789");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Validate the Field with lower Boundary Value";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("123456789");
                FastDriver.ServiceFee.Transfer.FAClick();

                Reports.TestStep = "Validate the Service Fee status is Transmitted";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 1, TableAction.Click);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Cancel.FAClick();

                Reports.TestStep = "Verify Reason for Cancellation of Service Fees";
                FastDriver.CancelDlg.WaitForScreenToLoad();
                FastDriver.CancelDlg.OK.FAClick();

                Reports.TestStep = "Cancel without any reason.";
                Support.AreEqual(@"Please enter the reason for Service Fees cancellation.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the Cancel Service Fees with valid data";
                FastDriver.CancelDlg.WaitForScreenToLoad();
                FastDriver.CancelDlg.Reason.FASetText("Thisisnotrequirediwanttocanceltheservicefeesf");
                FastDriver.CancelDlg.OK.FAClick();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0111_REG0016


        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r10
        //UserStory                               : US#836302:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Service Fees
        //TestCase                                : 869185
        //Appended By/ Created By                 : Sheetal Gothi

        [TestMethod]
        public void FMUC0111_REG0017()
        {
            try
            {
                Reports.TestDescription = "Verify on selection status from Display drop down the respetive office displayed in List";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion data setup

                #region Create a new office in ADm side.

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Verify if office is not created then create or just mark the office as Hidden.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                //string office = FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    //string office =FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.GetText).Message;
                    //if (office == "SRT Test Automation Office")
                    Reports.TestStep = "Select an office and edit it and verify office is marked as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();
                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                    {
                        FastDriver.BottomFrame.Done();
                    }
                    else
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);
                        FastDriver.BottomFrame.Done();
                    }
                }
                else if (!FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Test Automation Office"))
                {
                   FastDriver.OfficeSetupOffice.CreateNewOffice();
                }

                #endregion Create a new office in ADm side.

                #region Login
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");

                #endregion Login

                #region Create New File
                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion Create New File

                #region Select Active Office from the list and verify displayed Service fee
                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Validate the radio Button and set office.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);

                Reports.TestStep = "Select Active Office from Payee Search Dialog.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.Display.FASelectItemBySendingKeys("Active");
                //FastDriver.AddressBookSearchDlg.TableinpayeeSearch.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);//FASTLibrary.FASTLibrary.OfficeInUse_1
                FastDriver.AddressBookSearchDlg.TableinpayeeSearch.PerformTableAction(2, "SRT Test Automation Office", 1, TableAction.On);//FASTLibrary.FASTLibrary.OfficeInUse_1
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("SRT Test Automation Office", FastDriver.ServiceFee.ServiceFeePayeeDesc.FAGetText().ToString(), "Active office dispalyed in service fee screen");
                //Support.AreEqual(AutoConfig.SelectedOfficeName, FastDriver.ServiceFee.ServiceFeePayeeDesc.FAGetSelectedItem().ToString(), "Active office dispalyed in service fee screen");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion Select Active Office from the list and verify displayed Service fee

                #region Navigate to ADM and mark the office as Hidden.
                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Verify if office is not created then create or just mark the office as Hidden.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();

                Reports.TestStep = "Set the Hidden flag status as true for office";
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                FastDriver.BottomFrame.Done();
                #endregion Navigate to ADM and mark the office as Hidden.

                #region Login and serach the file
                Reports.TestStep = "Log into FAST application.";
                //credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                Reports.TestStep = "Verify the default state of the fields.";
                FastDriver.FileSearch.VerifyTheStateOfFields();

                Reports.TestStep = "Enter the file number.";
                FastDriver.FileSearch.SetFileNumber(fileNumber);
                Reports.TestStep = "Click the Find Now button.";
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(20000);

                #endregion Login and serach the file

                #region Select Hidden Office from the list and verify displayed Service fee
                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select Hidden offices";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Validate the radio Button and set office.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);

                Reports.TestStep = "Select Hidden Office from Payee Search Dialog.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.Display.FASelectItemBySendingKeys("Hidden");
                FastDriver.AddressBookSearchDlg.TableinpayeeSearch.PerformTableAction(2, "SRT Test Automation Office", 1, TableAction.On);
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount1.FASetText("899.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ServiceFee.WaitForScreenToLoad();
                Support.AreEqual("SRT Test Automation Office", FastDriver.ServiceFee.ServiceFeePayeeDesc1.FAGetText().ToString(), "Hidden office dispalyed in service fee screen");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion Select Hidden Office from the list and verify displayed Service fee

            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r10
        //UserStory                               : US#836302:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Service Fees
        //TestCase                                : 869182
        //Appended By/ Created By                 : Sheetal Gothi

        [TestMethod]
        public void FMUC0111_REG0018()
        {
            try
            {
                Reports.TestDescription = "Verify system displays Active and Hidden values for Service Fee Payee search dialog.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region UI Iteration
                #region Login
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");

                #endregion Login

                #region Create New File
                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion Create New File

                #region Verify Display status on Service Fee Payee Search.
                Reports.TestStep = "Verify Display status on Service Fee Payee Search.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);
                Support.AreEqual("Active", FastDriver.AddressBookSearchDlg.Display.FAGetSelectedItem().ToString(), "Active value selected by default in Title Production office selection window");

                Support.AreEqual("Active|Hidden", FastDriver.AddressBookSearchDlg.Display.FAGetAllTextFromSelect());
                //Support.AreEqual("0", FastDriver.OfficeSelectionDlg.Display.FASelectItemBySendingKeys("Avtive & Hidden"), "Active and Hidden displayed in Display drop down");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.BottomFrame.Done();
                #endregion Verify Display status on service fee Payee Search.
                #endregion UI Iteration
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion reg

        #region Class CleanUp

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

        #endregion Class CleanUp
    }
}