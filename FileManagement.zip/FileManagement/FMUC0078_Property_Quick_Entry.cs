﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTWCFHelpers;
using System.Linq;
using FASTWCFHelpers.Factories;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0078 : FASTHelpers
    {

        #region BAT

        [TestMethod]
        public void FMUC0078_BAT0001()
        {
            try
            {

                Reports.TestDescription = "MF1_01: Add Property Name, Address, Legal Description, and Tax Information.";
             
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Add Property Name, Address, Legal Description, and Tax Information.";
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);

                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property Name");

                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Condominium");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Acme street");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("street2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("street3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Princeton");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("CA");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("orange");
                Playback.Wait(2000);
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Playback.Wait(4000);
                FastDriver.PropertyTaxInfoLegalDesciption.Name.FASetText("Property Name");
                FastDriver.PropertyTaxInfoLegalDesciption.PropertyType.FASelectItem("Condominium");
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("LOT1");
                FastDriver.PropertyTaxInfoLegalDesciption.Block.FASetText("BLOCK2");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("UNIT3");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("TRACT4");
                FastDriver.PropertyTaxInfoLegalDesciption.Fee.FASetText("10000");
                FastDriver.PropertyTaxInfoLegalDesciption.Building.FASetText("CREATIVE");
                FastDriver.PropertyTaxInfoLegalDesciption.Book.FASetText("A23");
                FastDriver.PropertyTaxInfoLegalDesciption.Page.FASetText("B24");
                FastDriver.PropertyTaxInfoLegalDesciption.Section.FASetText("FIRST");
                FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FASetText("PRINCETON");
                FastDriver.PropertyTaxInfoLegalDesciption.Range.FASetText("X10");
                FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FASetText("Y20");
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASetText("CONDO");
                FastDriver.PropertyTaxInfoLegalDesciption.Phase.FASetText("2");
                FastDriver.PropertyTaxInfoLegalDesciption.GovtLotNo.FASetText("234");
                FastDriver.PropertyTaxInfoLegalDesciption.Borough.FASetText("QUEENS");
                FastDriver.PropertyTaxInfoLegalDesciption.Province.FASetText("SOUTH");
                FastDriver.PropertyTaxInfoLegalDesciption.CountyParish.FASetText("ORANGE");
                FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FASelectItem("Leasehold");

                FastDriver.PropertyTaxInfoLegalDesciption.ClickTaxTab();
                Playback.Wait(7000);
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToContentFrame();
                //FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("123");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("2010");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.FASetText("456");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo1.FASetText("678");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus1.FASelectItem("PAYABLE");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASetText("1,000.00");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInterest1.FASetText("100.00");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPenality1.FASetText("20.00");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxpartialPaymentAmount1.FASetText("500.00");

                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);


                Reports.TestStep = "Validate Property Name, Address, Legal Description, and Tax Information.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);

                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual("Property Name", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue());
                Support.AreEqual("Condominium", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetSelectedItem());
                Support.AreEqual("Acme street", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue());
                Support.AreEqual("street2", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue());
                Support.AreEqual("street3", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue());
                Support.AreEqual("Princeton", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue());
                Support.AreEqual("CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetValue());
                Support.AreEqual("orange", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue());
                Playback.Wait(2000);
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Playback.Wait(4000);
                Support.AreEqual("Property Name", FastDriver.PropertyTaxInfoLegalDesciption.Name.FAGetValue());
                Support.AreEqual("Condominium", FastDriver.PropertyTaxInfoLegalDesciption.PropertyType.FAGetSelectedItem());
                Support.AreEqual("LOT1", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue());
                Support.AreEqual("BLOCK2", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue());
                Support.AreEqual("UNIT3", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue());
                Support.AreEqual("TRACT4", FastDriver.PropertyTaxInfoLegalDesciption.Tract.FAGetValue());
                Support.AreEqual("10000", FastDriver.PropertyTaxInfoLegalDesciption.Fee.FAGetValue());
                Support.AreEqual("CREATIVE", FastDriver.PropertyTaxInfoLegalDesciption.Building.FAGetValue());
                Support.AreEqual("A23", FastDriver.PropertyTaxInfoLegalDesciption.Book.FAGetValue());
                Support.AreEqual("B24", FastDriver.PropertyTaxInfoLegalDesciption.Page.FAGetValue());
                Support.AreEqual("FIRST", FastDriver.PropertyTaxInfoLegalDesciption.Section.FAGetValue());
                Support.AreEqual("PRINCETON", FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FAGetValue());
                Support.AreEqual("X10", FastDriver.PropertyTaxInfoLegalDesciption.Range.FAGetValue());
                Support.AreEqual("Y20", FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FAGetValue());
                Support.AreEqual("CONDO", FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FAGetValue());
                Support.AreEqual("2", FastDriver.PropertyTaxInfoLegalDesciption.Phase.FAGetValue());
                Support.AreEqual("234", FastDriver.PropertyTaxInfoLegalDesciption.GovtLotNo.FAGetValue());
                Support.AreEqual("QUEENS", FastDriver.PropertyTaxInfoLegalDesciption.Borough.FAGetValue());
                Support.AreEqual("SOUTH", FastDriver.PropertyTaxInfoLegalDesciption.Province.FAGetValue());
                Support.AreEqual("ORANGE", FastDriver.PropertyTaxInfoLegalDesciption.CountyParish.FAGetValue());
                Support.AreEqual("Leasehold", FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FAGetSelectedItem());

                FastDriver.PropertyTaxInfoLegalDesciption.ClickTaxTab();
                Playback.Wait(7000);
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToContentFrame();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable1.PerformTableAction(2, 1, TableAction.Click);
                Playback.Wait(7000);
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToContentFrame();
                Support.AreEqual("123", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FAGetValue());
                Support.AreEqual("2010", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FAGetValue());
                Support.AreEqual("456", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.FAGetValue());
                Support.AreEqual("678", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo1.FAGetValue());
                Support.AreEqual("PAYABLE", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus1.FAGetSelectedItem());
                Support.AreEqual("1,000.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FAGetValue());
                Support.AreEqual("100.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInterest1.FAGetValue());
                Support.AreEqual("20.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPenality1.FAGetValue());
                Support.AreEqual("500.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxpartialPaymentAmount1.FAGetValue());


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG

        [TestMethod]
        public void FMUC0078_REG0001()
        {
            try
            {

                Reports.TestDescription = "FM2885: Transfer Info to Prop/Tax Info.";
                
                #region region Basic File Creation
                IISLOGIN();
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Validate property tax info details entered from QFE-1.";
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);
                Playback.Wait(3000);


                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue());
                Support.AreEqual("Condominium", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetSelectedItem());
                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue());
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue());
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue());
                Support.AreEqual("ALBANY", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue());
                Support.AreEqual("CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetValue());
                Support.AreEqual("ALAMEDA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue());
                Playback.Wait(2000);

                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Playback.Wait(4000);
                Support.AreEqual("Lot1", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue());
                Support.AreEqual("Block1", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue());
                Support.AreEqual("Unit1", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue());
                Playback.Wait(4000);

                FastDriver.PropertyTaxInfoLegalDesciption.ClickTaxTab();
                Playback.Wait(7000);
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToContentFrame();
                Playback.Wait(1000);
                Support.AreEqual("True", FastDriver.PropertyTaxInfoAnnualTax.Summarytable1.FAGetText().Contains("Prop1APN1").ToString());

               
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);


               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0078_REG0002()
        {
            try
            {

                Reports.TestDescription = "Errorcondition: Verify error/warn condition for SUBDIVISION/CONDO.";
               
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Reports.TestStep = "Add more than 255 characters to SUBDIVISION/CONDO.";
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);
                Playback.Wait(3000);


                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Condominium");

                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Playback.Wait(4000);
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWX");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                Support.AreEqual("Subdivision/Condominium cannot be more than 255 characters long", FastDriver.PropertyTaxInfoLegalDesciption.ErrorMasg.FAGetText());

                
               
                
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0078_REG0003()
        {
            try
            {

                Reports.TestDescription = "FD1: Verify Field definition for Property Information Name field.";
               
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction

                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.New.FAClick();
                Playback.Wait(5000);
                Playback.Wait(3000);


                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad(); 
                Reports.TestStep = "Validate Property Information Name field with lower boundary.";
                Playback.Wait(2000);
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGH");
                FastDriver.BottomFrame.Save();

                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGH",FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue());

             
                Playback.Wait(5000);
                Reports.TestStep = "Validate Property Information Name field with Exact value.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Validate Property Information Name field with lower boundary.";
                Playback.Wait(2000);
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHI");
                FastDriver.BottomFrame.Save();

                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHI", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue());



                Reports.TestStep = "Validate Property Information Name field with upper boundary value.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Validate Property Information Name field with lower boundary.";
                Playback.Wait(2000);
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJ");
                FastDriver.BottomFrame.Save();

                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHI", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0078_REG0004()
        {
            try
            {

                Reports.TestDescription = "FD2: Verify Field definition for Short Legal Information fields.";
               
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Validate Short Legal Information fields with lower boundary.";               
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Playback.Wait(4000);
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE123456789012345678");
                FastDriver.PropertyTaxInfoLegalDesciption.Block.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABC");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE123456789012345678");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("ABCDEFGHIJKLMNOPQRS");
                FastDriver.PropertyTaxInfoLegalDesciption.Fee.FASetText("ABCDEFGHIJKLMNOPQRS");
                FastDriver.PropertyTaxInfoLegalDesciption.Building.FASetText("ABCDEFGHIJKLMNOPQRS");
                FastDriver.PropertyTaxInfoLegalDesciption.Book.FASetText("ABCDEFGHIJKLMNOPQRS");
                FastDriver.PropertyTaxInfoLegalDesciption.Page.FASetText("ABCDEFGHI");
                FastDriver.PropertyTaxInfoLegalDesciption.Section.FASetText("ABCDEFGHIJKLMNOPQRS");
                FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FASetText("ABCDEFGHIJKLMNOPQRS");
                FastDriver.PropertyTaxInfoLegalDesciption.Range.FASetText("ABCDEFGHIJKLMNOPQRS");
                FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABC");
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRST");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE123456789012345678", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABC", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE123456789012345678", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRS", FastDriver.PropertyTaxInfoLegalDesciption.Tract.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRS", FastDriver.PropertyTaxInfoLegalDesciption.Fee.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRS", FastDriver.PropertyTaxInfoLegalDesciption.Building.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRS", FastDriver.PropertyTaxInfoLegalDesciption.Book.FAGetValue());
                Support.AreEqual("ABCDEFGHI", FastDriver.PropertyTaxInfoLegalDesciption.Page.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRS", FastDriver.PropertyTaxInfoLegalDesciption.Section.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRS", FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRS", FastDriver.PropertyTaxInfoLegalDesciption.Range.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABC", FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FAGetValue());

                Reports.TestStep = "Validate Short Legal Information fields with Exact value.";
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                Playback.Wait(4000);
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE1234567890123456789");
                FastDriver.PropertyTaxInfoLegalDesciption.Block.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE1234567890123456789");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("ABCDEFGHIJKLMNOPQRST");
                FastDriver.PropertyTaxInfoLegalDesciption.Fee.FASetText("ABCDEFGHIJKLMNOPQRST");
                FastDriver.PropertyTaxInfoLegalDesciption.Building.FASetText("ABCDEFGHIJKLMNOPQRST");
                FastDriver.PropertyTaxInfoLegalDesciption.Book.FASetText("ABCDEFGHIJKLMNOPQRST");
                FastDriver.PropertyTaxInfoLegalDesciption.Page.FASetText("ABCDEFGHIJ");
                FastDriver.PropertyTaxInfoLegalDesciption.Section.FASetText("ABCDEFGHIJKLMNOPQRST");
                FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FASetText("ABCDEFGHIJKLMNOPQRST");
                FastDriver.PropertyTaxInfoLegalDesciption.Range.FASetText("ABCDEFGHIJKLMNOPQRST");
                FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD");
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE1234567890123456789", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE1234567890123456789", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Tract.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Fee.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Building.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Book.FAGetValue());
                Support.AreEqual("ABCDEFGHIJ", FastDriver.PropertyTaxInfoLegalDesciption.Page.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Section.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Range.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FAGetValue());

                Reports.TestStep = "Validate Short Legal Information fields with upper boundary value.";
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                Playback.Wait(4000);
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE12345678901234567890");
                FastDriver.PropertyTaxInfoLegalDesciption.Block.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE12345678901234567890");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("ABCDEFGHIJKLMNOPQRSTU");
                FastDriver.PropertyTaxInfoLegalDesciption.Fee.FASetText("ABCDEFGHIJKLMNOPQRSTU");
                FastDriver.PropertyTaxInfoLegalDesciption.Building.FASetText("ABCDEFGHIJKLMNOPQRSTU");
                FastDriver.PropertyTaxInfoLegalDesciption.Book.FASetText("ABCDEFGHIJKLMNOPQRSTU");
                FastDriver.PropertyTaxInfoLegalDesciption.Page.FASetText("ABCDEFGHIJK");
                FastDriver.PropertyTaxInfoLegalDesciption.Section.FASetText("ABCDEFGHIJKLMNOPQRSTU");
                FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FASetText("ABCDEFGHIJKLMNOPQRSTU");
                FastDriver.PropertyTaxInfoLegalDesciption.Range.FASetText("ABCDEFGHIJKLMNOPQRSTU");
                FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE1234567890123456789", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE1234567890123456789", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Tract.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Fee.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Building.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Book.FAGetValue());
                Support.AreEqual("ABCDEFGHIJ", FastDriver.PropertyTaxInfoLegalDesciption.Page.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Section.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Range.FAGetValue());
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FAGetValue());
                

               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0078_REG0005()
        {
            try
            {

                Reports.TestDescription = "FM4527: Verify Property type displayed in ascend alphabetical order.";
               
                #region region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreaction
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
               string types =FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();

               Reports.TestStep = "Validate the Property Type.";                
                Support.AreEqual("True", types.Contains("Single Family Residence").ToString());
                Support.AreEqual("True", types.Contains("Multi Family Residence").ToString());
                Support.AreEqual("True", types.Contains("Condominium").ToString());
                Support.AreEqual("True", types.Contains("Agricultural Land").ToString());
                Support.AreEqual("True", types.Contains("Apartment").ToString());
                Support.AreEqual("True", types.Contains("Building").ToString());
                Support.AreEqual("True", types.Contains("Church/Religious Facility").ToString());
                Support.AreEqual("True", types.Contains("Commercial Structure").ToString());
                Support.AreEqual("True", types.Contains("Communication Site").ToString());
                Support.AreEqual("True", types.Contains("Convenience Store/Market").ToString());
                Support.AreEqual("True", types.Contains("Convention Facility").ToString());
                Support.AreEqual("True", types.Contains("Co-op").ToString());
                Support.AreEqual("True", types.Contains("Educational Facility").ToString());
                Support.AreEqual("True", types.Contains("Energy Facility").ToString());
                Support.AreEqual("True", types.Contains("Entertainment/Theatre").ToString());
                Support.AreEqual("True", types.Contains("Farm w/Homesite").ToString());
                Support.AreEqual("True", types.Contains("Golf Course").ToString());
                Support.AreEqual("True", types.Contains("Government Facility").ToString());
                Support.AreEqual("True", types.Contains("Health Care Facility").ToString());
                Support.AreEqual("True", types.Contains("Hotel/Motel").ToString());
                Support.AreEqual("True", types.Contains("Industrial").ToString());
                Support.AreEqual("True", types.Contains("Mobile Home").ToString());
                Support.AreEqual("True", types.Contains("Office").ToString());
                Support.AreEqual("True", types.Contains("Personal Property").ToString());
                Support.AreEqual("True", types.Contains("Petroleum/Oil Company").ToString());
                Support.AreEqual("True", types.Contains("Planned Unit Development").ToString());
                Support.AreEqual("True", types.Contains("Restaurant/Fast Food").ToString());
                Support.AreEqual("True", types.Contains("Retail").ToString());
                Support.AreEqual("True", types.Contains("Self Storage").ToString());
                Support.AreEqual("True", types.Contains("Sports Facility/Stadium").ToString());
                Support.AreEqual("True", types.Contains("Timber Land").ToString());
                Support.AreEqual("True", types.Contains("Townhouse").ToString());
                Support.AreEqual("True", types.Contains("Transportation Facilit").ToString());
                Support.AreEqual("True", types.Contains("Vacant Land Other").ToString());
                Support.AreEqual("True", types.Contains("Other").ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0078_REG0006()
        {
            try
            {

                Reports.TestDescription = "Validate that the property information is read only in file home page";
               
                #region region Basic File Creation
                IISLOGIN();
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateDetailedFile();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region GUI Intreaction
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Reports.TestStep = "Validate the datas of property is read only";
                string IsEnabled;
                FastDriver.FileHomepage.PropertyName.Enabled.ToString();
                IsEnabled= FastDriver.FileHomepage.PropertyName.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyType.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyLotName.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyBlock.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyUnit.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyTRact.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyFee.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyBuilding.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyBook.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyPage.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertySection.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyTownShip.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyRange.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyPropParcel.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyPropSubDivCondo.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyEstateType.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyPropTaxAPN1.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyPropTaxYear1.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyPropTaxAPN2.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyPropTaxYear2.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyBookAddressLine1.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyBookAddressLine2.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyBookAddressLine3.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyBookAddressLine4.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyAddressBookCity.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyState.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyZip.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyCounty.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);
                IsEnabled= FastDriver.FileHomepage.PropertyCountry.Enabled.ToString();
                Support.AreEqual("False",IsEnabled);

                Reports.TestStep = "Validate the property information can be edited";
                 Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();
               
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Table.PerformTableAction(2,1,TableAction.Click);
               FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(2000);
                 FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.Enabled.ToString());
                Support.AreEqual("True", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.Enabled.ToString());
                Playback.Wait(2000);
               
                Reports.TestStep = "Validate property tax info details entered from QFE-1.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue());
                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue());
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue());
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue());
                Support.AreEqual("ALBANY", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue());
                Support.AreEqual("CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetValue());
                Support.AreEqual("ALAMEDA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue());
                Playback.Wait(2000);

                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Playback.Wait(4000);
                Support.AreEqual("Lot1", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue());
                Support.AreEqual("Block1", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue());
                Support.AreEqual("Unit1", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue());
                
                Playback.Wait(4000);
                FastDriver.PropertyTaxInfoLegalDesciption.ClickTaxTab();
                Playback.Wait(7000);
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.PropertyTaxInfoAnnualTax.Summarytable1.FAGetText().Contains("Prop1APN1").ToString());

                Playback.Wait(5000);


               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0078_REG0007()
        {
            try
            {
                Reports.TestDescription = "FD: Validate that the default  estate type";
                #region region Basic File Creation
                IISLOGIN();
                CreateFilethroughUI();
                #endregion

                #region GUI Intreaction
                
              
                Reports.TestStep = "Validate the estate type as Fee Simple";
                FastDriver.FileHomepage.WaitForScreenToLoad();
               
                Playback.Wait(3000);
                Support.AreEqual("Fee Simple", FastDriver.FileHomepage.PropertyEstateType.FAGetSelectedItem());

                Reports.TestStep = "Validate the default estate type";
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();

                Playback.Wait(3000);
               
                FastDriver.PropertiesSummary.Table.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(4000);

                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Playback.Wait(4000);
                Support.AreEqual("Fee Simple", FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FAGetSelectedItem());

                Reports.TestStep = "Click on New and validate the default Estate type";
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();
                Playback.Wait(1000);
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Playback.Wait(4000);
                Support.AreEqual("Fee Simple", FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FAGetSelectedItem());

                FastDriver.BottomFrame.Done();
                #endregion
            }
            
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0078_REG0008()
        {
            try
            {
                Reports.TestDescription = "FD_FM4527:Create order with different Estate type and validate the same in property tax info screen";
                #region region Basic File Creation
                IISLOGIN();
                CreateFilethroughUI("Leasehold");
                #endregion

                #region GUI Intreaction


                Reports.TestStep = "Validate the estate type as Fee Simple";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Playback.Wait(3000);
                Support.value = FastDriver.FileHomepage.PropertyEstateType.FAGetSelectedItem();
                Support.AreEqual("Leasehold", FastDriver.FileHomepage.PropertyEstateType.FAGetSelectedItem());

                Reports.TestStep = "Create a file with Leasehold estate type";
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Open();

                Playback.Wait(3000);
                FastDriver.PropertiesSummary.Table.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(2000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Playback.Wait(4000);
                Support.AreEqual("Leasehold", FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FAGetSelectedItem());

                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0078_REG0009()
        {
            try
            {

                Reports.TestDescription = "FD:Field defination for short legal information";
                Reports.StatusUpdate("Functionality has covered in FMUC0078_REG0004", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion


        #region Private TestMethods

        private void IISLOGIN(string UserName = null, string Password = null)
        {
            var credentials = new Credentials() { UserName = UserName, Password = Password };
            if (UserName == null)
            {
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            }
            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
        }

        private void CreateBasicFile()
        {

            var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            Reports.TestStep = "Create File using web service.";
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);

            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            int FileNo = FileService.GetFilesByFileNum(fileNumber.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;


        }
        private void CreateFilethroughUI(string estate=null)
        {

           
            Reports.TestStep = "Create Order";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

            FastDriver.QuickFileEntry.WaitForScreenToLoad();

            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();

            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            if (estate != null)
            {
                FastDriver.QuickFileEntry.PropertyEstateType.FASelectItem(estate);
            }
               
            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);

            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
            FastDriver.FileHomepage.WaitForScreenToLoad();
        }

        #endregion
    }
}
