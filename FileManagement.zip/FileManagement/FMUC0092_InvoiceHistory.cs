﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using FASTWCFHelpers.FastFileService;
using System.Threading;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0092 : MasterTestClass
    {
        #region COMMONDATA
        string CommonInvoiceTo ="Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2" ;
        string[] FeeName = { "New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", "Eagle Lender Policy - 1", "1064_Recording_Fee_Mortgage" };
        #endregion
         #region ADMSETTINGS
        /* SUMMARY
         Following Fees are used in this script
         * "New Home Rate (Title Only)", 
         * "New Home Rate Eagle Lender Policy-1", 
         * "Eagle Lender Policy - 1", 
         * "1064_Recording_Fee_Mortgage"
           Make sure that these fees are present in Fee set up for both HUD and CD
         * */
         #endregion
        #region BAT
        [TestMethod]
        public void FMUC0092_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00:View Invoice History for Final/FINALADJ/CANCLFINAL.";
                //
                #region Data Setup

                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet = new InvoiceHistoryParameters[]
                {
                    new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "FINAL",
                    Total = "33.33",
                    FirstEstimated = string.Empty,
                    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                },                
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "CANCELFINL",
                    Total = "0.00",
                    FirstEstimated = string.Empty,
                    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    Description = FeeName[0],
                    Amount = "-33.33",
                    SalesTax = string.Empty,
                    Action = "Canceled",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                                               
                };
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on final button in Invoice screen and validate the status";
                Support.AreEqual("True", FinalizeTheInvoice(FeeName[0]).ToString());
                //
                Reports.TestStep = "Verify the Final Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                Reports.TestStep = "Deliver invoice.";
                DeliverInvoice("Print");
                //Reports.TestStep = "Edit fee amount for invoice.";
                //EditBuyerSellerChargesInFeeEntry(FeeName[0], "10.11","24.22");
                ////
                //Reports.TestStep = "Validate Invoice Status FINALADJ.";
                //ValidateInvoiceStatus("FINALADJ");
                ////
                //Reports.TestStep = "Validate Invoice History when fee is modified.";
                //VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
                //VerifyInvoiceHistory(2, Expected_InvoiceHistoryParameters_DataSet[2]);
                //
                //Reports.TestStep = "Print the checks.";
                //DeliverInvoice("Print");
                //
                Reports.TestStep = "Validate the cancel (CANCELFINL) status.";
                Support.AreEqual("True", CancelTheInvoice(FeeName[0], "CANCELFINL").ToString());
                //
                Reports.TestStep = "Verify the Final Cancelled Invoice in Invoice History.";
                VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
                //
                Reports.TestStep = "Print the checks.";
                DeliverInvoice("Print");
                //
                //10.7 change
                //Thread.Sleep(5000);
                //FastDriver.LeftNavigation.ClickHome();
                //Reports.TestStep = "Create file";
                //CreateFile();
                //Reports.TestStep = "Add a fee in Fee Entry.";
                //AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                ////
                //Reports.TestStep = "Click on final button in Invoice screen and validate the status";
                //Support.AreEqual("True", FinalizeTheInvoice(FeeName[0]).ToString());
                ////
                //Reports.TestStep = "Edit fee amount again.";
                //ClearAndEditBuyerSellerChargesInFeeEntry(FeeName[0], "15.11", "25.22");
                ////
                //if (AutoConfig.FormType.Equals("CD"))
                //    Reports.TestStep = "Verify invoice history.Expected to fail in CD file BUG 739962";
                //else
                //    Reports.TestStep = "Verify invoice history";
                //VerifyInvoiceHistory(2, Expected_InvoiceHistoryParameters_DataSet[4]);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
                #endregion
        }

        [TestMethod]
        public void FMUC0092_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_01: View Invoice History for ESTMTD/ESTMTDADJ/CANCELESTI";
                //
                #region Data Setup
                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet = new InvoiceHistoryParameters[]
                {new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "33.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "34.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "-33.33",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "34.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "34.33",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "CANCELESTI",
                    Total = "0.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "-34.33",
                    SalesTax = string.Empty,
                    Action = "Canceled",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "40.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(), 
                    FirstFinalized = string.Empty, 
                    Description = FeeName[0],
                    Amount = "40.33",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
            };
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on Estimate button and verify Invoice Status on Invoice screen.";
                Support.AreEqual("True", EstimateTheInvoice(new[]{ FeeName[0] }).ToString());
                //
                Reports.TestStep = "Verify the ESTIMATE Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                Reports.TestStep = "Deliver invoice.";
                DeliverInvoice("Print");
                Reports.TestStep = "Edit fee amount for invoice.";
                EditBuyerSellerChargesInFeeEntry(FeeName[0],"10.11","24.22");
                //
                Reports.TestStep = "Validate Invoice Status ESTMTADJ.";
                ValidateInvoiceStatus("ESTMTADJ");
                Reports.TestStep = "Validate  Invoice History when fee is modified.";
                VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
                VerifyInvoiceHistory(2, Expected_InvoiceHistoryParameters_DataSet[2]);
                //
                Reports.TestStep = "Validate the Invoice status CANCELESTI.";
                Support.AreEqual("True", CancelTheInvoice(FeeName[0], "CANCELESTI").ToString());
                //
                Reports.TestStep = "Verify the Cancelled (CANCELESTI) Invoice in Invoice History.";
                VerifyInvoiceHistory(3, Expected_InvoiceHistoryParameters_DataSet[3]);
                //
                Reports.TestStep = "Print the checks.";
                DeliverInvoice("Print");
                //
                Thread.Sleep(5000);
                FastDriver.LeftNavigation.ClickHome();
                Reports.TestStep = "Create second file. These steps are added so that CANCELESTI status can be validated irrespective of above failure (739962) in CD file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on Estimate button in Invoice screen and validate the status";
                Support.AreEqual("True", EstimateTheInvoice(new[] { FeeName[0] }).ToString());
                //
                Reports.TestStep = "Edit fee amount again.";
                ClearAndEditBuyerSellerChargesInFeeEntry(FeeName[0], "15.11", "25.22");
                //
                if (AutoConfig.FormType.Equals("CD"))
                    Reports.TestStep = "Verify invoice history.Expected to fail in CD file BUG 739962";
                else
                    Reports.TestStep = "Verify invoice history";
                VerifyInvoiceHistory(2, Expected_InvoiceHistoryParameters_DataSet[4]);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
                #endregion
        }
        #endregion
        //
        #region REG
        [TestMethod]
        public void FMUC0092_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM5317: User Security.";

                #region TestSteps
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                Reports.TestStep = "Navigate to Office.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedOfficeBUID);

                Reports.TestStep = "Check if Activity right is present";
                bool isActivityRightPresent = FastDriver.BusinessUnitRoleAssignment.isRolePresentWithRequiredActivityRight("IT - all", "Fee Entry Activity");
                if (isActivityRightPresent == false)
                {
                    Reports.TestStep = "Add ACtivity right";
                    isActivityRightPresent = FastDriver.RoleSetup.AddActivityRightToTheRole("IT - all", "Fee Entry Activity", "Office File Processing Activity Group");

                }
                Reports.TestStep = "Veirfy if Activity right is present or added";
                Support.AreEqual("True", isActivityRightPresent.ToString());
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }           
                #endregion
        }
        [TestMethod]
        public void FMUC0092_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM5286_FM5287_FM5288_FM5296_FM5297_FM5298_FM5299_FM5308_FM5311_FM5313_FM5316: Change Invoice Status from Uninvoiced to Estimated.";
                //
                #region Data Setup

                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet   =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "33.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "39.31",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[1],
                    Amount = "5.98",
                    SalesTax = string.Empty,
                    Action = "Added",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "20.96",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "-33.33",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "20.96",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "14.98",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "14.98",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[1],
                    Amount = "-5.98",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "0.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "-14.98",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "4.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "0.00",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "CANCELESTI",
                    Total = "0.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "-4.00",
                    SalesTax = string.Empty,
                    Action = "Canceled",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
            };
            
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on Estimate button and verify Invoice Status on Invoice screen.";
                //
                Support.AreEqual("True", EstimateTheInvoice(new[]{FeeName[0]}).ToString());
                //
                Reports.TestStep = "Verify the ESTIMATE Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                Reports.TestStep = "Select the second fee.";
                AddFeeInFeeEntry(FeeName[1], "2.99", "2.99");
                SelectInvoiceFees(FeeName[1]);
                //
                Reports.TestStep = "Verify the status as Estimated Adjusted when a new fee is added.";
                VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
                //
                Reports.TestStep = "Edit first fee Buyer and seller Charge in Title and escrow.";
                EditBuyerSellerChargesInFeeEntry(FeeName[0], "4.99", "9.99"); 
                //
                Reports.TestStep = "Verify the status as Estimated Adjusted when a fee is modified.";
                VerifyInvoiceHistory(2, Expected_InvoiceHistoryParameters_DataSet[2]);
                VerifyInvoiceHistory(3, Expected_InvoiceHistoryParameters_DataSet[3]);
                //
                Reports.TestStep = "Deselect Estimated Fee.";
                FastDriver.FileFees.DeselectTitleScrowFee(FeeName[1]);
                Reports.TestStep = "Verify the status as Estimated Adjusted when a fee is removed.";
                VerifyInvoiceHistory(4, Expected_InvoiceHistoryParameters_DataSet[4]);
                //
                Reports.TestStep = "Change the buyer and seller charges to zero for the fee.";
                EditBuyerSellerChargesInFeeEntry(FeeName[0], "0.00","0.00");
                //
                Reports.TestStep = "Verify the status as Estimated Adjusted when a fee is modified to zero.";
                VerifyInvoiceHistory(5, Expected_InvoiceHistoryParameters_DataSet[5]);
                //
                Reports.TestStep = "Change the buyer seller charges to normal for the fee.";
                ClearAndEditBuyerSellerChargesInFeeEntry(FeeName[0], "2.00", "2.00");
                if (AutoConfig.FormType.Equals("CD"))
                    Reports.TestStep = "Verify invoice history.Expected to fail in CD file BUG 739962";
                else
                    Reports.TestStep = "Verify invoice history";
                VerifyInvoiceHistory(6, Expected_InvoiceHistoryParameters_DataSet[6]);
                //
                Reports.TestStep = "Create second file. These steps are added so that CANCELESTI status can be validated irrespective of above failure (739962) in CD file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on Estimate button and verify Invoice Status on Invoice screen.";
                Support.AreEqual("True", EstimateTheInvoice(new[] { FeeName[0] }).ToString());
                //
                Reports.TestStep = "Edit fee";
                EditBuyerSellerChargesInFeeEntry(FeeName[0], "2.00", "2.00");
                //
               Reports.TestStep = "Validate the ESTMTADJ is changed cancel (CANCELESTI) status.";
               Support.AreEqual("True", CancelTheInvoice(FeeName[0], "CANCELESTI").ToString());
                //
               Reports.TestStep = "Verify the Estimated Cancelled Invoice in Invoice History.";
                VerifyInvoiceHistory(3, Expected_InvoiceHistoryParameters_DataSet[7]);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
                #endregion
        }
        //
        [TestMethod]
        public void FMUC0092_REG0004()
        {
            Reports.TestDescription = "FM5291_FM5300_FM5304_FM5305_FM5306_FM5307_FM5309_FM5312_FM5314_FM5315: Change Invoice Status from Uninvoiced to Final.";
            try
            {
                #region Data Setup
                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "FINAL",
                    Total = "33.33",
                    FirstEstimated = string.Empty, 
                    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "FINALADJ",
                    Total = "39.31",
                    FirstEstimated = string.Empty, 
                    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    Description = FeeName[1],
                    Amount = "5.98",
                    SalesTax = string.Empty,
                    Action = "Added",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                //new InvoiceHistoryParameters
                //{
                //    InvoiceTo = CommonInvoiceTo,
                //    CurrentStatus = "FINALADJ",
                //    Total = "14.98",
                //    FirstEstimated = string.Empty, 
                //    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                //    Description = FeeName[1],
                //    Amount = "-5.98",
                //    SalesTax = string.Empty,
                //    Action = "Adjusted",
                //    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                //},
                //new InvoiceHistoryParameters
                //{
                //    InvoiceTo = CommonInvoiceTo,
                //    CurrentStatus = "FINALADJ",
                //    Total = "0.00",
                //    FirstEstimated = string.Empty, 
                //    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                //    Description = FeeName[0],
                //    Amount = "-14.98",
                //    SalesTax = string.Empty,
                //    Action = "Adjusted",
                //    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                //},
                //new InvoiceHistoryParameters
                //{
                //    InvoiceTo = CommonInvoiceTo,
                //    CurrentStatus = "FINALADJ",
                //    Total = "4.00",
                //    FirstEstimated = string.Empty, 
                //    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                //    Description = FeeName[0],
                //    Amount = "0.00",
                //    SalesTax = string.Empty,
                //    Action = "Adjusted",
                //    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                //},
                // new InvoiceHistoryParameters
                //{
                //    InvoiceTo = CommonInvoiceTo,
                //    CurrentStatus = "CANCELFINL",
                //    Total = "0.00",
                //    FirstEstimated = string.Empty, 
                //    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                //    Description = FeeName[0],
                //    Amount = "-4.00",
                //    SalesTax = string.Empty,
                //    Action = "Canceled",
                //    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                //},
            };

                #endregion

            //
            #region TestSteps
            Reports.TestStep = "Log into FAST application.";
            IISLOGIN();
            Reports.TestStep = "Create file";
            CreateFile();
            Reports.TestStep = "Add a fee in Fee Entry.";
            AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
            //
            Reports.TestStep = "Click on Final button and verify Invoice Status on Invoice screen.";
            Support.AreEqual("True", FinalizeTheInvoice(FeeName[0]).ToString());
            //
            Reports.TestStep = "Verify the finalized Invoice in Invoice History.";
            VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
            //
            Reports.TestStep = "Select the second fee.";
            AddFeeInFeeEntry(FeeName[1], "2.99", "2.99");
            SelectInvoiceFees(FeeName[1]);

            Reports.TestStep = "Verify the status as final Adjusted when a new fee is added.";
            VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
            //
            //Reports.TestStep = "Edit first fee Buyer and seller Charge in Title and escrow.";
            //EditBuyerSellerChargesInFeeEntry(FeeName[0], "4.99", "9.99");
            ////
            //Reports.TestStep = "Verify the status as final Adjusted when a fee is modified.";
            //VerifyInvoiceHistory(2, Expected_InvoiceHistoryParameters_DataSet[2]);
            //VerifyInvoiceHistory(3, Expected_InvoiceHistoryParameters_DataSet[3]);
            //
            Reports.TestStep = "Try Deselect finalized Fee.";
            string Message= FastDriver.FileFees.DeselectTitleScrowFee(FeeName[1]);
            string ExpectedMessage = @"This fee is associated to an invoice that has been finalized. Cancel the finalized invoice to proceed with the changes.";
           Support.AreEqualTrim(Message, ExpectedMessage);
            Reports.TestStep = "Verify the invoice hostory is as is because user is not able to deselect fees.";
            VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
            
            #endregion
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception occured " + ex.Message, false);
            }
        }
        [TestMethod]
        public void FMUC0092_REG0005()
        {
            Reports.TestDescription = "FM5289_FM5301: Modify a Fee to a Positive Amount on a Final Invoice.";
            try
            {
                #region Data Setup
                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "FINAL",
                    Total = "33.33",
                    FirstEstimated = string.Empty, 
                    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },                
                
            };
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on Final button and verify Invoice Status on Invoice screen.";
                //
                Support.AreEqual("True", FinalizeTheInvoice(FeeName[0]).ToString());
                //
                Reports.TestStep = "Verify the Final Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                Reports.TestStep = "Edit fee amount for invoice.";
                string ExpectedMessage=@"Fee amount cannot be decreased/increased as it will cause an out of balance Invoice. Cancel the finalized invoice to proceed with the changes.";
                string Message=EditBuyerSellerChargesInFeeEntry(FeeName[0], "10.11", "20.22");
                Support.AreEqualTrim(ExpectedMessage.Trim(), Message.Trim());
                //
                Reports.TestStep = "Validate Invoice Status is unchanged ie FINAL.";
                ValidateInvoiceStatus("FINAL");
                Reports.TestStep = "Validate  Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);              
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        //
        [TestMethod]
        public void FMUC0092_REG0006()
        {
            Reports.TestDescription = "FM5289_FM5302: Remove a Fee From a Final Invoice.";
            Reports.StatusUpdate("This scenario is covered in REG0004", true);
        }
        [TestMethod]
        public void FMUC0092_REG0007()
        {
            Reports.TestDescription = "FM5289_FM5303: Modify a Fee to a Zero Amount on a Final Invoice.";
            try
            {

                #region Data Setup
                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "FINAL",
                    Total = "33.33",
                    FirstEstimated = string.Empty, 
                    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },
                 
            };
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on Final button and verify Invoice Status on Invoice screen.";
                //
                Support.AreEqual("True", FinalizeTheInvoice(FeeName[0]).ToString());
                Reports.TestStep = "Verify the Final Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                Reports.TestStep = "Change the buyer charges to zero for the fee.";
                EditBuyerSellerChargesInFeeEntry(FeeName[0], "0.00", "0.00");
                //
                Reports.TestStep = "Validate Invoice Status FINAL.";
                ValidateInvoiceStatus("FINAL");
                Reports.TestStep = "Verify data in invoice history in unchanged.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        [TestMethod]
        public void FMUC0092_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM5288_FM5293: Modify a Fee to a Positive Amount on an Estimated Invoice.";
                #region Data Setup
                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "33.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(), 
                    FirstFinalized = string.Empty, 
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "34.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(), 
                    FirstFinalized = string.Empty, 
                    Description = FeeName[0],
                    Amount = "-33.33",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "34.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "34.33",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "40.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(), 
                    FirstFinalized = string.Empty, 
                    Description = FeeName[0],
                    Amount = "40.33",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
            };
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on Estimate button and verify Invoice Status on Invoice screen.";
                Support.AreEqual("True", EstimateTheInvoice(new[]{FeeName[0]}).ToString());
                //
                Reports.TestStep = "Verify the ESTIMATED Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                Reports.TestStep = "Change the buyer charges to positive amount for the fee.";
                EditBuyerSellerChargesInFeeEntry(FeeName[0], "10.11", "24.22");
                //
                Reports.TestStep = "Verify the status as Estimated Adjusted when a fee is modified.";
                ValidateInvoiceStatus("ESTMTADJ");
                Reports.TestStep = "Verify ESTMTADJ invoice in Invoice History .";
                VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
                VerifyInvoiceHistory(2, Expected_InvoiceHistoryParameters_DataSet[2]);
                //
                Reports.TestStep = "Edit fee amount again.";
                ClearAndEditBuyerSellerChargesInFeeEntry(FeeName[0], "15.11", "25.22");
                //
                if (AutoConfig.FormType.Equals("CD"))
                    Reports.TestStep = "Verify invoice history.Expected to fail in CD file BUG 739962";
                else
                    Reports.TestStep = "Verify invoice history";
                VerifyInvoiceHistory(4, Expected_InvoiceHistoryParameters_DataSet[3]);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        [TestMethod]
        public void FMUC0092_REG0008A()
        {
            Reports.TestDescription = "FM5292:calculating fees through FACC and invoice the fees. Also modify the fees and remove the fees and verify in invoice history";
            try{
            #region Data Setup
            InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "303.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[2],
                    Amount = "30.00",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "303.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = "[ALTA 1-06] Street Assessments",
                    Amount = "0.00",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "303.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[3],
                    Amount = "21.00",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "303.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[3],
                    Amount = "22.00",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                },
                new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "303.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[3],
                    Amount = "230.00",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                },
                  new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "313.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[2],
                    Amount = "-30.00",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                  new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "273.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[2],
                    Amount = "40.00",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                  new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "273.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[2],
                    Amount = "-40.00",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
            };
            #endregion
            //
            #region TestSteps
            Reports.TestStep = "Log into FAST application.";
            IISLOGIN();
            Reports.TestStep = "Create file with loan details";
            CreateFile();
            Reports.TestStep = "Select All fees and Click on Calculate";
            FastDriver.FileFees.NavigateToFeeEntry();
            FastDriver.FileFees.AllFees.FASetCheckbox(true);
            FastDriver.FileFees.CalculateFees.FAClick();
            //
            Reports.TestStep = "Create Title Fees..";
            Reports.TestStep = "Click on Add on Title Policy..";
            FastDriver.CalculateFees.SelectTitleAndEndorsement("","Basic");

            Reports.TestStep = "Select Endorsement Fee.";
            FastDriver.CalculateFees.AddEndorsementWOProduct();
            //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
            FastDriver.CalculateFees.SwitchToContentFrame();

            Reports.TestStep = "Calculate Recording Fee Deed.";
            FastDriver.CalculateFees.SelectRecordingFees("Deed","3","2000");

            Reports.TestStep = "Click on Next Button.";
            FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
            FastDriver.CalculateFees.ClickNext();
            FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
            Playback.Wait(5000);
            FastDriver.CalculateFees.ClickNext();
            FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
            Reports.TestStep = "Select View More option.";
            string[] Fees = FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType(2, @"Title - Lenders Policy", FeeName[2], "Buyer", "Permitted Rate Reduction","30.00");

            Reports.TestStep = "Select View More option for the last fee.";
            //int RowCount=FastDriver.CalculateFees.SummaryTable.GetRowCount();
            Fees=FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType(6, @"Recording Fee - Mortgage", FeeName[3],"Buyer");
               
            Reports.TestStep = "Select Descriptions and other details for remaining Fees.";
            FastDriver.CalculateFees.SelectFeeFromSummaryTable(3, "Endorsement L", "Seller");
            FastDriver.CalculateFees.SelectFeeFromSummaryTable(4, Fees[0], "Seller");
            FastDriver.CalculateFees.SelectFeeFromSummaryTable(5, Fees[0], "Seller");

            Reports.TestStep = "Verify for Facc Fees.";
            FastDriver.FileFees.NavigateToFeeEntry();
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeName[2],"#2", TableAction.Click);

            Reports.TestStep = "Select the fees in invoice and Click on Estimate button and verify Invoice Status on Invoice screen.";
            //SelectAllFeesFromInvoiceFeeList();
            string[] AllFees = {  "[ALTA 1-06] Street Assessments","1064_Recording_Fee_Mortgage","1064_Recording_Fee_Mortgage", "1064_Recording_Fee_Mortgage", "Eagle Lender Policy - 1"};
            Support.AreEqual("True", EstimateTheInvoice(AllFees).ToString());
            Reports.TestStep = "verify the amount in invoice history";
            VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
            VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
            VerifyInvoiceHistory(2, Expected_InvoiceHistoryParameters_DataSet[2]);
            VerifyInvoiceHistory(3, Expected_InvoiceHistoryParameters_DataSet[3]);
            VerifyInvoiceHistory(4, Expected_InvoiceHistoryParameters_DataSet[4]);
            //
            Reports.TestStep = "Modify the override amount";
            FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
            FastDriver.CalculateFees.ModifyFeeDetailsFromSummaryTable(2, "Buyer", "Permitted Rate Reduction", "40.00", "50.00");
            Reports.TestStep = "Verify total amount in Invoice history";
            VerifyInvoiceHistory(5, Expected_InvoiceHistoryParameters_DataSet[5]);
            Reports.TestStep = "Remove the fee / make the fee zero and verify in history";
            FastDriver.FileFees.NavigateToFeeEntry();
            RemoveFeesFromFile(FeeName[2]);
            if (AutoConfig.FormType.Equals("CD"))
                Reports.TestStep = "Verify invoice history.This will fail in CD file BUG 739962";
            else
                Reports.TestStep = "Verify invoice history";
            VerifyInvoiceHistory(6, Expected_InvoiceHistoryParameters_DataSet[6]);
            VerifyInvoiceHistory(7, Expected_InvoiceHistoryParameters_DataSet[7]);
            #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
//
        [TestMethod]
        public void FMUC0092_REG0009()
        {
            Reports.TestDescription = "FM5288_FM5294: Remove a Fee From an Estimated Invoice.";
            try
            {
                #region Data Setup
                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "33.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized =  string.Empty, 
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "0.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized =  string.Empty, 
                    Description = FeeName[0],
                    Amount = "-33.33",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                
            };
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on Estimate button and verify Invoice Status on Invoice screen.";
                Support.AreEqual("True", EstimateTheInvoice(new[]{FeeName[0]}).ToString());
                //
                Reports.TestStep = "Verify the estimated Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                Reports.TestStep = "Deselect Estimated Fee.";
                RemoveFeesFromFile(FeeName[0]);
                //
                Reports.TestStep = "Validate Invoice Status ESTMTADJ.";
                ValidateInvoiceStatus("ESTMTADJ");
                Reports.TestStep = "Validate  Invoice History when fee is modified.";
                VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        //
        [TestMethod]
        public void FMUC0092_REG0010()
        {
            Reports.TestDescription = "FM5288_FM5295: Modify a Fee to Zero on an Estimated Invoice.";
            try
            {
                #region Data Setup
                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "33.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(), 
                    FirstFinalized = string.Empty, 
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },
                 new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTMTADJ",
                    Total = "0.00",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(), 
                    FirstFinalized = string.Empty, 
                    Description = FeeName[0],
                    Amount = "-33.33",
                    SalesTax = string.Empty,
                    Action = "Adjusted",
                    AdjustedOrCancelled = DateTime.UtcNow.AddHours(-8).ToDateString(),
                },
                
            };
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Click on Estimate button and verify Invoice Status on Invoice screen.";
                Support.AreEqual("True", EstimateTheInvoice(new[]{FeeName[0]}).ToString());
                //
                Reports.TestStep = "Verify the ESTIMATED Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                Reports.TestStep = "Change the buyer charges to zero for the fee.";
                EditBuyerSellerChargesInFeeEntry(FeeName[0], "0.00", "0.00");
                //
                Reports.TestStep = "Validate Invoice Status ESTMTADJ.";
                ValidateInvoiceStatus("ESTMTADJ");
                Reports.TestStep = "Verify the ESTMTADJ invoice data in Invoice History when a fee is modified to zero.";
                VerifyInvoiceHistory(1, Expected_InvoiceHistoryParameters_DataSet[1]);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        //
        [TestMethod]
        public void FMUC0092_REG0011()
        {
            Reports.TestDescription = "FM5288: Change Invoice Status from Prelim to Estimated.";
            try
            {
                #region Data Setup
                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "ESTIMATED",
                    Total = "33.33",
                    FirstEstimated = DateTime.UtcNow.AddHours(-8).ToDateString(),
                    FirstFinalized = string.Empty,
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },
            };
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Deliver invoice - preview";
                DeliverInvoice("Preview");
                //
                Reports.TestStep = "Validate the invoice Status - PRELIM.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "PRELIM", 6, TableAction.Click);
                Reports.TestStep = "Click on Estimate button and verify Invoice Status on Invoice screen.";
                Support.AreEqual("True", EstimateTheInvoice(new[]{FeeName[0]}).ToString());
                //
                Reports.TestStep = "Verify the ESTIMATED Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0092_REG0012()
        {
            Reports.TestDescription = "FM5289: Change Invoice Status from Prelim to Final.";
            try
            {
                #region Data Setup
                InvoiceHistoryParameters[] Expected_InvoiceHistoryParameters_DataSet =
               {
               new InvoiceHistoryParameters
                {
                    InvoiceTo = CommonInvoiceTo,
                    CurrentStatus = "FINAL",
                    Total = "33.33",
                    FirstEstimated = string.Empty,
                    FirstFinalized = DateTime.UtcNow.AddHours(-8).ToDateString(), 
                    Description = FeeName[0],
                    Amount = "33.33",
                    SalesTax = string.Empty,
                    Action = string.Empty,
                    AdjustedOrCancelled = string.Empty,
                
                },
            };
                #endregion
                //
                #region TestSteps
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file";
                CreateFile();
                Reports.TestStep = "Add a fee in Fee Entry.";
                AddFeeInFeeEntry(FeeName[0], "11.11", "22.22");
                //
                Reports.TestStep = "Deliver invoice - preview";
                DeliverInvoice("Preview");
                //
                Reports.TestStep = "Validate the invoice Status - PRELIM.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "PRELIM", 6, TableAction.Click);
                Reports.TestStep = "Click on Final button and verify Invoice Status on Invoice screen.";
                //
                Support.AreEqual("True", FinalizeTheInvoice(FeeName[0]).ToString());
                Reports.TestStep = "Verify the FINAL Invoice in Invoice History.";
                VerifyInvoiceHistory(0, Expected_InvoiceHistoryParameters_DataSet[0]);
                //
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        //
        [TestMethod]
        public void FMUC0092_REG0013_PH()
        {
            try
            {
                Reports.TestDescription = "FM5318_19: Invoice History Item Display Order.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        
        //
        [TestMethod]
        public void FMUC0092_REG0014_PH()
        {

            try
            {
                Reports.TestDescription = "FM5310: Prevent Editing of Invoice History.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }



        #region SRT-ServReq

        //Team                  :  ServReq-Team1
        //Iteration             :  r06
        //UserStory             :  User Story 760998
        //TestCase              :  776572,776687,776732,776758,776801,785930,785966
        //Appended By/ Created By: Amarnathh

        [TestMethod]
        public void FMUC0092_REG0015()
        {
            Reports.TestDescription = "calculating fees through FACC and invoice the fees.";
            try
            {
                #region TestSteps
                string str = string.Empty;
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create file with loan details";
                CreateFile();
                //FastDriver.TopFrame.SearchFileByFileNumber("40584");
                Playback.Wait(4000);

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees..";
                Reports.TestStep = "Click on Add on Title Policy..";
                FastDriver.CalculateFees.SelectTitleAndEndorsement("", "Basic");

                Reports.TestStep = "Create Recording Fees.";
                FastDriver.CalculateFees.SelectRecordingFees("Amendment", "1", "1");

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.ClickNext();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.ClickNext();

                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                Reports.TestStep = "Select View More option.";
                string[] Fees = FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType(2, @"Title - Lenders Policy", "1064_Title_Lender_Policy", "Buyer", "", "", "");

                Reports.TestStep = "Select View More option for the last fee.";
                Fees = FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType(3, @"Recording Fee - Deed", "1064_Recording_Fee_Deed", "Buyer", "", "", "");

                Reports.TestStep = "Verify for Facc Fees.";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "1064_Title_Lender_Policy", "#2", TableAction.Click);
                Playback.Wait(4000);

                Reports.TestStep = "Select the fees in invoice and Click on Estimate button and verify Invoice Status on Invoice screen.";
                string AllFees = "1064_Title_Lender_Policy";
                FinalizeTheInvoice(AllFees);

                //Verify Transaction type in FileHomePage

                //FastDriver.TopFrame.SearchFileByFileNumber("40709");
                Playback.Wait(4000);
                Reports.TestStep = "Verify fields in Filehomepage";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage");
                Playback.Wait(4000);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.TransactionType.FAClick();
                Keyboard.SendKeys("Accommodation");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(4000);
                str = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual(@"Transaction Type is associated with a fee that has been invoiced. Transaction Type Information cannot be modified. Cancel the invoice to before proceeding with changes", str);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage");
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                //Verify the Product deselect
                Reports.TestStep = "Verify the Product remove validation";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage");
                Playback.Wait(4000);
                FastDriver.FileHomepage.Products.FAClick();
                Playback.Wait(1000);
                str = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual(@"Product is associated with a fee that has been invoiced. Product Information cannot be modified. Cancel the invoice before proceeding with changes.", str);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage");
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                //Validate the underwriter
                Reports.TestStep = "Verify the Underwriter validation";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage");
                Playback.Wait(4000);
                int SelectedIndex = FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FAGetSelectedIndex();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemByIndex(SelectedIndex + 1, true);
                str = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(@"Underwriter is associated with a fee that has been invoiced. Underwriter Information cannot be modified.Cancel the invoice before proceeding with changes.", str);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                // Verify TDS screen
                Reports.TestStep = "Verify fields in Terms/status/Dates";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                Playback.Wait(4000);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.FirstNewLoanLiability.FASetText(@"3000000" + FAKeys.Tab);
                str = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(@"Liability Amount is associated with a fee that has been Invoiced. Liability information can not be modified. Cancel the Invoice before proceeding with the changes.", str);

                //Verify New Loan
                Reports.TestStep = "Verify fields in New Loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan");
                Playback.Wait(4000);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"300000000" + FAKeys.Tab);
                str = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(@"1st New Loan Liability Amount is associated with a fee that has been invoiced.Liability Amount\nInformation cannot be modified. Cancel the invoice before proceeding with changes.", str);

                //Verify the Property/Tax Info screen
                Reports.TestStep = "Verify the Propert/Tax Info Screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                Playback.Wait(4000);
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.Click();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("CO");
                str = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(@"Property State is associated with a fee that has been invoiced. State cannot be modified. Cancel invoiced fees before proceeding with changes.", str);
                Playback.Wait(1000);

                //Verify the county validation
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Santa Ana" + FAKeys.Tab);
                str = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(@"Property County is associated with a fee that has been invoiced. County cannot be modified. Cancel invoiced fees before proceeding with changes.", str);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion SRT-ServReq

            #endregion
        //
        #region PRIVATEMETHODS
        private void IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
           
        }
        //
        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            UserName = UserName ?? AutoConfig.UserNameSU;
            Password = Password ?? AutoConfig.UserPasswordSU;
            Credentials credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

        }
        //
        private bool CreateFile()
        {
            try
            {
                var customizableFileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.Properties = new Property[] 
                { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ",
                            Zip="97020"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                    
                } 
            };
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(customizableFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                return true;
            }
            catch(Exception)
            {
                try
                {
                    FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    FastDriver.QuickFileEntry.CreateDetailedFile();
                    return true;
                }
                catch(Exception ex)
                {
                    throw new Exception("Unable to create QFE" , ex);
                }

            }
        }
        //
        private void DeliverInvoice(string DeliveryMethod)
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.PerformDelivery(DeliveryMethod);
                FastDriver.InvoiceFees.SwitchToContentFrame();
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Unable to deliver invoice "+ex.Message,false);
            }
        }
        //
        private void AddFeeInFeeEntry(string FeeName, string BuyerCharge, string SellerCharge)
        {
            try
            {
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee(FeeName);
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction(2, FeeName, 4, TableAction.SetText, BuyerCharge+FAKeys.Tab);
                Playback.Wait(3000);
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction(2, FeeName, 7, TableAction.SetText, SellerCharge+FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
            }
            catch(Exception ex)
            {
                throw new Exception("Unable to add fee on Fee Entry screen.",ex);
            
            }
        }
        //
        private void ClearAndEditBuyerSellerChargesInFeeEntry(string FeeName, string BuyerCharge, string SellerCharge = "-1")
        {
            try
            {

                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen().WaitForScreenToLoad();

                for (int i = 4; i <= 7; i = i + 3)
                {
                    string XPATH = "//*[contains(text(),'" + FeeName + "')]//ancestor::tr[1]/td[" + i + "]//input";
                    IWebElement ChargeCell = FastDriver.FileFees.TitleandescrowTable.FindElement(By.XPath(XPATH));
                    ChargeCell.Clear();
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    FastDriver.FileFees.SwitchToContentFrame();
                    if (i == 7 && SellerCharge != "-1")
                        ChargeCell.FASetText(SellerCharge+ FAKeys.Tab);
                    else
                        ChargeCell.FASetText(BuyerCharge + FAKeys.Tab);

                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    FastDriver.FileFees.SwitchToContentFrame();
                }

                FastDriver.BottomFrame.Done();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false,10);
                //Delay added for ghost window to disappear
                Thread.Sleep(7000);
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to edit fee on Fee Entry screen.", ex);
            }

        }
        //
        private string EditBuyerSellerChargesInFeeEntry(string FeeName, string BuyerCharge, string SellerCharge="-1")
        {
            try
            {
                string Message = "";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen().WaitForScreenToLoad();              
                for (int i = 4; i <= 7; i = i + 3)
                {
                    string XPATH =  "//*[contains(text(),'"+FeeName+"')]//ancestor::tr[1]/td["+i+"]//input";                                      
                    IWebElement ChargeCell = FastDriver.FileFees.TitleandescrowTable.FindElement(By.XPath(XPATH));
                    FastDriver.FileFees.SwitchToContentFrame();
                    if (i == 7 && SellerCharge != "-1")
                    {
                        //ChargeCell.FASetText(SellerCharge+ FAKeys.Tab);
                        Message=SetTextInFeesTable(ChargeCell, SellerCharge);
                    }
                    else
                    { 
                        //ChargeCell.FASetText(BuyerCharge + FAKeys.Tab);
                        Message=SetTextInFeesTable(ChargeCell, BuyerCharge);
                    }
                    FastDriver.FileFees.SwitchToContentFrame();
                }

                return Message;
            }
            catch(Exception ex)
            {
                throw new Exception("Unable to edit fee on Fee Entry screen.",ex);
            }
            
        }
        //
                public string SetTextInFeesTable(IWebElement element, string text, bool clearFirst = true, bool continueOnFailure = false)
        {
            string Message = "";
            FastDriver.FileFees.SwitchToContentFrame();
            if (text == null) // if nothing pass in, just skip it
                return Message;

            try
            {
                Report.UpdateLog(element, "Set", "Text", text, () =>
                {
                    if (clearFirst) element.FAClick();
                    element.SendKeys(text+FAKeys.Tab);
                     Message=FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.FileFees.SwitchToContentFrame();
                });
            }
            catch (Exception)
            {
                if (continueOnFailure)
                {
                    Reports.StatusUpdate("Unable to set Text = " + text, true);
                }
                else
                    throw;
            }
            return Message;
        }

        //
        private void RemoveFeesFromFile(string FeeName)
        {
            try
            {
                Reports.TestStep = "Remove fees from file";
                FastDriver.FileFees.DeselectTitleScrowFee(FeeName);
                FastDriver.FileFees.WaitForScreenToLoad();

            }
            catch (Exception Ex)
            {
                Reports.StatusUpdate("Unable to remove fees "+Ex.Message, false);
            }
        }
        //
        private void SelectInvoiceFees(string FeeName,string InvoiceStatus="")
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                if (InvoiceStatus != "")
                {
                    FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, InvoiceStatus, 6, TableAction.Click);
                }
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, FeeName, 8, TableAction.On);
                Playback.Wait(2000);
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to select an invoice fees.", ex);
            }
        }
        //
        private bool FinalizeTheInvoice(string FeeName, string InvoiceStatus = "")
        {
            bool Status = false;
            try
            {
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                if (InvoiceStatus != "")
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, InvoiceStatus, 6, TableAction.Click);
                Status=FastDriver.InvoiceFees.FinalizeSelectedFee(FeeName);
                return Status;
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to finalize an invoice.", ex);
            }
        }
        //
        private bool EstimateTheInvoice(string[] FeeName,string InvoiceStatus="")
        {
            bool Status;
            try
            {
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                if (InvoiceStatus!="")
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, InvoiceStatus, 6, TableAction.Click);
                Status = FastDriver.InvoiceFees.EstimateSelectedFee(FeeName);
                return Status;
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to estimate an invoice.", ex);
            }
        }
        //
        private bool CancelTheInvoice(string FeeDesc, string ExpectedStatus)
        {
            try
            {
                bool Status = false;
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                Status=FastDriver.InvoiceFees.CancelInvoice(FeeDesc, ExpectedStatus);
                return Status;
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to cancel an invoice.", ex);
            }
        }
        //
        private void ValidateInvoiceStatus(string Status)
        {
            try
            {
                Reports.TestStep = "Validate status on Invoice fees screen";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, Status, 6, TableAction.Click);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Unable to validate invoice status - "+ex.Message,false);
            }
        }
        //
        private void VerifyInvoiceHistory(int DataSetNum, InvoiceHistoryParameters Expected_InvoiceHistoryParameters_DataSet)
        {
            try
            {
                InvoiceHistoryParameters InvoiceHistoryData = new InvoiceHistoryParameters();
               bool IsInvHostoryAlreadyLoaded= FastDriver.GetPage<FASTSelenium.PageObjects.IIS.InvoiceHistory>().CurrentStatus.Exists();
               if (!IsInvHostoryAlreadyLoaded)
               {
                   FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                   FastDriver.InvoiceFees.SwitchToContentFrame();
                   FastDriver.InvoiceFees.History.FAClick();
                   FastDriver.InvoiceHistory.WaitForScreenToLoad();
               }
                InvoiceHistoryData = FastDriver.InvoiceHistory.GetInvoiceHistoryData(DataSetNum);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.InvoiceTo,InvoiceHistoryData.InvoiceTo);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.CurrentStatus,InvoiceHistoryData.CurrentStatus);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.Total,InvoiceHistoryData.Total);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.FirstEstimated,InvoiceHistoryData.FirstEstimated);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.FirstFinalized,InvoiceHistoryData.FirstFinalized);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.Description,InvoiceHistoryData.Description);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.Amount,InvoiceHistoryData.Amount);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.Action,InvoiceHistoryData.Action);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.AdjustedOrCancelled,InvoiceHistoryData.AdjustedOrCancelled);
                Support.AreEqualTrim(Expected_InvoiceHistoryParameters_DataSet.SalesTax,InvoiceHistoryData.SalesTax);
            }
            catch(Exception Ex)
            {
                Reports.StatusUpdate("Unable to verify invoice history - "+Ex.Message,false);
            }
        }

        //
        #endregion
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
