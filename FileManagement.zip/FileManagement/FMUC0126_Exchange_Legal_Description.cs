﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Collections.Generic;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0126 : MasterTestClass
    {
        #region BAT

        #region FMUC0126_BAT0001
        [TestMethod]
        public void FMUC0126_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Main Course: Properties legal Description";

                #region Login into Fast
                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                #endregion

                #region Select Exchange Office
                Reports.TestStep = "Select Exchange Office";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12386");
                #endregion

                #region Create Exchange File
                Reports.TestStep = "Create Exchange File.";
                FastDriver.HomePage.WaitForHomeScreen();
                FastDriver.ExchangeFileEntry.Open();
                CreateExchangeFile(TransactionType: "Delayed", Office: "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)", PropertyType: "Relinquished");
                #endregion

                #region Navigate to Property Legal Description
                Reports.TestStep = "Navigate to Property Legal Description.";
                FastDriver.ExchangePropertiesLegalDecription.Open();
                #endregion

                #region Verify the error message
                Reports.TestStep = "Verify the error message.";
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Please select a Property", FastDriver.WebDriver.HandleDialogMessage() , "Verifying that an IEMessage appeared.");
                #endregion

                #region Verify default selection of "Property Selection"
                Reports.TestStep = "Verify default selection of \"Property Selection\"";
                FastDriver.ExchangePropertiesLegalDecription.WaitForScreenToLoad();
                Support.AreEqual("Select Property", FastDriver.ExchangePropertiesLegalDecription.PropertySelection.FAGetSelectedItem().ToString().Clean(), "Veryfing that selected value is: Select Property");
                #endregion

                #region Select the Required Property
                Reports.TestStep = "Select the Requiered Property.";
                FastDriver.ExchangePropertiesLegalDecription.PropertySelection.FASelectItemByIndex(1);
                #endregion

                #region Fill the Complete Legal Description
                Reports.TestStep = "Fill the Complete Legal Description.";
                FastDriver.ExchangePropertiesLegalDecription.CompleteLegalDescription.FASetText("Here is ac complete description.");
                #endregion

                #region Save the Property Legal Description
                Reports.TestStep = "Save the Property Legal Description.";
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify the Complete Legal Description Content
                Reports.TestStep = "Verify the Complete Legal Description content.";
                FastDriver.ExchangePropertiesLegalDecription.WaitForScreenToLoad();
                Support.AreEqual("Here is ac complete description.", FastDriver.ExchangePropertiesLegalDecription.CompleteLegalDescription.FAGetText() , "Verifying that Complete Legal Description is: Here is ac complete description: Here is ac complete description.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }    
        }
        #endregion

        #endregion

        #region REG

        #region FMUC0126_REG0001
        [TestMethod]
        public void FMUC0126_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM184058 – Complete Legal Description";

                #region Login into Fast and Exchange Office Selection
                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12386");
                #endregion

                #region Create Exchange File
                Reports.TestStep = "Create Exchange File.";
                FastDriver.HomePage.WaitForHomeScreen();
                FastDriver.ExchangeFileEntry.Open();
                CreateExchangeFile(TransactionType: "Delayed", Office: "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)", PropertyType: "Relinquished");
                #endregion

                #region Navigate to Property Legal Description
                Reports.TestStep = "Navigate to Property Legal Description.";
                FastDriver.ExchangePropertiesLegalDecription.Open();
                #endregion

                #region Verify the error message
                Reports.TestStep = "Verify the error message.";
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Please select a Property", FastDriver.WebDriver.HandleDialogMessage(), "Verifying that an IEMessage appeared.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0126_REG0001, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0126_REG0002
        [TestMethod]
        public void FMUC0126_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM184058 - Complete Legal description for all Properties";

                #region Login into Fast and Exchange Office Selection
                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12386");
                FastDriver.HomePage.WaitForHomeScreen();
                #endregion

                //Relinquished
                #region Testing Legal Description with Relinquished Property
                VerifyExchangeLegalDescription(TransactionType: "Delayed", Office: "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)", PropertyType: "Relinquished", FileCreated: false);
                #endregion

                //Replacement
                #region Testing Legal Description with Replacement Property
                VerifyExchangeLegalDescription(TransactionType: "Delayed", Office: "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)", PropertyType: "Replacement", FileCreated: true);
                #endregion

                //EAT Adquisition
                #region Testing Legal Description with EAT Adquisition Property
                VerifyExchangeLegalDescription(TransactionType: "Reverse / Construction", Office: "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)", PropertyType: "Adquisition", FileCreated: true);
                #endregion

                //EAT Disposition
                #region Testing Legal Description with EAT Disposition Property
                VerifyExchangeLegalDescription(TransactionType: "Reverse / Construction", Office: "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)", PropertyType: "Disposition", FileCreated: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0126_REG0002, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0126_REG0003
        [TestMethod]
        public void FMUC0126_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM252604 – Indexable Data Elements for legal description";

                //Adding Delayed Data Elements
                List<string> DelayedDataElements = new List<string>();
                DelayedDataElements.Add("Ex Relinq Prop Long Legal Description -EXRQLEG");
                DelayedDataElements.Add("Ex Replace Prop Long Legal Description -EXRPLEG");
                DelayedDataElements.Add("Replacement property -Seller Property Short Vesting - EXSLSV");
                DelayedDataElements.Add("Replacement property -Seller Property Full Vesting - EXSLFV");

                //Adding Reverse Data Elements
                List<string> ReversedDataElements = new List<string>();
                DelayedDataElements.Add("EAT Acq Prop Long Legal Description - EATAQLEG");
                DelayedDataElements.Add("EAT Disp Prop Long Legal Description - EATDSLEG");
                DelayedDataElements.Add("EAT Acquisition Property Address - EATQRPAD");
                DelayedDataElements.Add("EAT Acquisition Property City - EATQRPC");
                DelayedDataElements.Add("EAT Acquisition Property County - EATQCNTY");
                DelayedDataElements.Add("EAT Acquisition Property State - EATQRPS");
                DelayedDataElements.Add("EAT Acquisition Property Zip Code - EATQRPZ");
                DelayedDataElements.Add("EAT Seller Prop Full Vesting - EATQFV");
                DelayedDataElements.Add("EAT Seller Prop Short Vesting - EATQSV");
                DelayedDataElements.Add("EAT Disposition Property Address - EATDRPAD");
                DelayedDataElements.Add("EAT Disposition Property City - EATDRPC");
                DelayedDataElements.Add("EAT Disposition Property County- EATDCNTY");
                DelayedDataElements.Add("EAT Disposition Property State - EATDRPS");
                DelayedDataElements.Add("EAT Buyer Prop Full Vesting - EATDFV");
                DelayedDataElements.Add("EAT Buyer Prop Short Vesting – EATDSV");
                
                #region Login into Fast and Exchange Office Selection
                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12386");
                FastDriver.HomePage.WaitForHomeScreen();
                #endregion

                //Relinquished
                #region Testing Legal Description with Relinquished Property
                Reports.TestStep = "Create Exchange File for Relinquished Property.";
                FastDriver.ExchangeFileEntry.Open();
                CreateExchangeFile(TransactionType: "Delayed", Office: "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)", PropertyType: "Relinquished", FileCreated: false, CreateNewFile: false);
                #endregion

                #region Setting Up Data Elements for Relinquished
                string dataElements = SettingDataElements(PropertyType: "Relinquished", DataElements: DelayedDataElements);
                #endregion

                #region Filling Property Legal Description
                FillPropertyLegalDescription(Property: 1, PropertyType: "Relinquished", DataElements: dataElements);
                #endregion

                //Replacement
                #region Testing Legal Description with Replacement Property
                Reports.TestStep = "Create Exchange File for Replaced Property.";
                FastDriver.ExchangeFileEntry.Open();
                CreateExchangeFile(TransactionType: "Delayed", Office: "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)", PropertyType: "Replacement", FileCreated: true, CreateNewFile: false);
                #endregion

                #region Setting Up Data Elements for Relinquished
                dataElements = SettingDataElements(PropertyType: "Replacement", DataElements: DelayedDataElements);
                #endregion

                #region Filling Property Legal Description
                FillPropertyLegalDescription(Property: 2, PropertyType: "Replacement", DataElements: dataElements);
                #endregion

                //EAT Adquisition
                #region Testing Legal Description with EAT Adquisition Property
                Reports.TestStep = "Create Exchange File for Adquisition Property.";
                FastDriver.ExchangeFileEntry.Open();
                CreateExchangeFile(TransactionType: "Reverse / Construction", Office: "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)", PropertyType: "Adquisition", FileCreated: true, CreateNewFile: true);
                #endregion

                #region Setting Up Data Elements for Relinquished
                dataElements = SettingDataElements(PropertyType: "Adquisition", DataElements: DelayedDataElements);
                #endregion

                #region Filling Property Legal Description
                FillPropertyLegalDescription(Property: 1, PropertyType: "Adquisition", DataElements: dataElements);
                #endregion

                //EAT Disposition
                #region Testing Legal Description with EAT Disposition Property
                Reports.TestStep = "Create Exchange File for Disposition Property.";
                FastDriver.ExchangeFileEntry.Open();
                CreateExchangeFile(TransactionType: "Reverse / Construction", Office: "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)", PropertyType: "Disposition", FileCreated: true, CreateNewFile: false);
                #endregion

                #region Setting Up Data Elements for Relinquished
                dataElements = SettingDataElements(PropertyType: "Disposition", DataElements: DelayedDataElements);
                #endregion

                #region Filling Property Legal Description
                FillPropertyLegalDescription(Property: 2, PropertyType: "Disposition", DataElements: dataElements);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0126_REG0003, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0126_REG0004
        [TestMethod]
        public void FMUC0126_REG0004()
        {
            try
            {
                Reports.TestDescription = "User story – 212815.2 – Property Type";

                #region Login into Fast and Exchange Office Selection
                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12386");
                FastDriver.HomePage.WaitForHomeScreen();
                #endregion

                #region Create Exchange File
                Reports.TestStep = "Create Exchange File.";
                FastDriver.ExchangeFileEntry.Open();
                CreateExchangeFile(TransactionType: "Delayed", Office: "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)", PropertyType: "Relinquished", FileCreated: false);
                #endregion

                #region Navigate to Property Legal Description
                Reports.TestStep = "Navigate to Property Legal Description.";
                FastDriver.ExchangePropertiesLegalDecription.Open();
                #endregion

                #region Verify that Property Type is Disabled
                Reports.TestStep = "Verify that Property Type is disabled.";
                Support.AreEqual("False", FastDriver.ExchangePropertiesLegalDecription.PropertyType.IsEnabled().ToString().Clean(), "Verifying that Property Type is Disabled.");
                string PropertyTypeValue = FastDriver.ExchangePropertiesLegalDecription.PropertyType.FAGetValue();
                #endregion

                #region Verify Property Type change on Propery Selection change.
                Reports.TestStep = "Verify Property Type change on Property Selection change.";
                FastDriver.ExchangePropertiesLegalDecription.PropertySelection.FASelectItemByIndex(1);
                Support.AreNotEqual("", FastDriver.ExchangePropertiesLegalDecription.PropertyType.FAGetValue().Clean(), "Veryfing Property Type change on Property Selection change.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0126_REG0004, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #endregion

        #region Private Methods

        #region Login into Fast
        private void FALogin(string URL, string userName, string userPwd)
        {
            var credentials = new Credentials()
            {
                UserName = userName,
                Password = userPwd
            };

            FASTLogin.Login(URL, credentials, true);
        }

        #endregion

        #region Create Exchange File
        private void CreateExchangeFile(string TransactionType, string Office, string PropertyType, bool FileCreated = false, bool CreateNewFile = false)
        {
            if (CreateNewFile)
            {
                FastDriver.ExchangeFileEntry.Open();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
            }

            if(!FileCreated)
            {
                Reports.TestStep = "Setting up the File.";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem(TransactionType);
                FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItem(Office);
                FastDriver.ExchangeFileEntry.TaxPayerAddNew.FAClick();
                FastDriver.ExchangeFileEntry.TaxPayerType.FASelectItem("Individual");
                FastDriver.ExchangeFileEntry.TaxpyrIndividualName.FASetText("John");
                FastDriver.ExchangeFileEntry.TaxpyrIndividualLast.FASetText("Doe");
                FastDriver.ExchangeFileEntry.TaxpyrIndividualSSNTIN.FASetText("123456789");
                FastDriver.ExchangeFileEntry.TaxPayerAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.TaxPayerCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.TaxPayerState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.TaxPayerZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.TaxPayerCounty.FASetText("Orange");
                FastDriver.ExchangeFileEntry.TaxPayerBusPh.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerHomePh.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerCellFax.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerPager.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerEmail.FASetText("test@test.net");
                FastDriver.ExchangeFileEntry.PartiesTab.FAClick();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad();
                FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");
            }

            if (TransactionType.Equals("Delayed") && PropertyType.Equals("Relinquished"))
            {
                Reports.TestStep = "Setting up the Relinquished Property.";
                FastDriver.ExchangeFileEntry.RelinquishedTab.FAClick();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad();
                FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.RelPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.EnterRelinquishedTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.RelBuyersAddNew.FAClick();
                FastDriver.ExchangeFileEntry.RelBuyersType.FASelectItem("Individual");
                FastDriver.ExchangeFileEntry.RelBuyersIndividualFirstName.FASetText("Jane");
                FastDriver.ExchangeFileEntry.RelBuyersIndividualLastName.FASetText("Doe");
                FastDriver.ExchangeFileEntry.RelBuyersIndividualSSNTIN.FASetText("123456789");
                FastDriver.ExchangeFileEntry.RelAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelBuyersCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelBuyersState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelBuyersZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelBuyersCounty.FASetText("Orange");
                FastDriver.ExchangeFileEntry.RelBuyersBusPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.RelBuyersHomePhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.RelBuyersCellPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.RelBuyersPager.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.RelBuyersEmail.FASetText("test@test.net");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }

            if (TransactionType.Equals("Delayed") && PropertyType.Equals("Replacement"))
            {
                Reports.TestStep = "Setting up the Replacement Property.";
                FastDriver.ExchangeFileEntry.ReplacementTab.FAClick();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad();
                FastDriver.ExchangeFileEntry.REPPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.REPPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.REPPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.REPPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.REPPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.REPPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.EnterReplacementTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.REPAddNew.FAClick();
                FastDriver.ExchangeFileEntry.REPSellersType.FASelectItem("Individual");
                FastDriver.ExchangeFileEntry.REPSellersIndividualFirstName.FASetText("Jane");
                FastDriver.ExchangeFileEntry.REPSellersIndividualLastName.FASetText("Doe");
                FastDriver.ExchangeFileEntry.REPSellerIndividualSSNTIN.FASetText("123456789");
                FastDriver.ExchangeFileEntry.REPAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.REPSellersCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.REPSellersState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.REPSellersZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.REPSellersCounty.FASetText("Orange");
                FastDriver.ExchangeFileEntry.REPSellersBusPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.REPSellersHomePhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.REPSellersCellPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.REPSellersPager.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.REPSellersEmail.FASetText("test@test.net");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }

            if (TransactionType.Equals("Reverse") && PropertyType.Equals("Adquisition"))
            {
                Reports.TestStep = "Setting up the EATAcquisition.";
                FastDriver.ExchangeFileEntry.EATAcquisitionTab.FAClick();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad();
                FastDriver.ExchangeFileEntry.EATAcqPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.EATAcqPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.EATAcqPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.EATAcqPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.EATAcqPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.EATAcqPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.EnterEATAcquisitionTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.EATAcqSellersAddNew.FAClick();
                FastDriver.ExchangeFileEntry.EATAcqSellersType.FASelectItem("Individual");
                FastDriver.ExchangeFileEntry.EATAcqSellersIndividualFirstName.FASetText("Jane");
                FastDriver.ExchangeFileEntry.EATAcqSellersIndividualLastName.FASetText("Doe");
                FastDriver.ExchangeFileEntry.EATAcqSellersIndividualSSNTIN.FASetText("123456789");
                FastDriver.ExchangeFileEntry.EATAcqAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.EATAcqSellersCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.EATAcqSellersState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.EATAcqSellersZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.EATAcqSellersCounty.FASetText("Orange");
                FastDriver.ExchangeFileEntry.EATAcqSellersBusPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATAcqSellersHomePhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATAcqSellersCellPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATAcqSellersPager.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATAcqSellersEmail.FASetText("test@test.net");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }

            if (TransactionType.Equals("Reverse") && PropertyType.Equals("Disposition"))
            {
                Reports.TestStep = "Setting up the EATAcquisition.";
                FastDriver.ExchangeFileEntry.EATDispositionTab.FAClick();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad();
                FastDriver.ExchangeFileEntry.EATDispPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.EATDispPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.EATDispPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.EATDispPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.EATDispPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.EATDispPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.EnterEATDispositionGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.EATDispSellersAddNew.FAClick();
                FastDriver.ExchangeFileEntry.EATDispSellersType.FASelectItem("Individual");
                FastDriver.ExchangeFileEntry.EATDispSellersIndividualFirstName.FASetText("Jane");
                FastDriver.ExchangeFileEntry.EATDispSellersIndividualLastName.FASetText("Doe");
                FastDriver.ExchangeFileEntry.EATDispSellersIndividualSSNTIN.FASetText("123456789");
                FastDriver.ExchangeFileEntry.EATDispAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.EATDispSellersCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.EATDispSellersState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.EATDispSellersZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.EATDispSellersCounty.FASetText("Orange");
                FastDriver.ExchangeFileEntry.EATDispSellersBusPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATDispSellersHomePhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATDispSellersCellPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATDispSellersPager.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATDispSellersEmail.FASetText("test@test.net");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }
        }
        #endregion

        #region VerifyExchangeLegalDescription
        private void VerifyExchangeLegalDescription(string TransactionType, string Office, string PropertyType, bool FileCreated)
        {
            #region Create Exchange File
            Reports.TestStep = "Create Exchange File.";
            FastDriver.ExchangeFileEntry.Open();
            CreateExchangeFile(TransactionType: TransactionType, Office: Office, PropertyType: PropertyType, FileCreated: FileCreated, CreateNewFile: false);
            #endregion

            #region Navigate to Property Legal Description
            Reports.TestStep = "Navigate to Property Legal Description.";
            FastDriver.ExchangePropertiesLegalDecription.Open();
            #endregion

            #region Reset the Property Legal Description
            Reports.TestStep = "Reset the Property Legal Description.";
            FastDriver.ExchangePropertiesLegalDecription.WaitForScreenToLoad();
            FastDriver.BottomFrame.Reset();
            #endregion

            #region Navigate to Exchange File Entry & Close the File
            Reports.TestStep = "Navigate to Exchange File Entry and Close the File";
            FastDriver.ExchangeFileEntry.Open();
            FastDriver.ExchangeFileEntry.FileStatus.FASelectItem("Closed");
            FastDriver.BottomFrame.Done();
            #endregion
        }
        #endregion

        #region Fill Property Legal Description
        private void FillPropertyLegalDescription(int Property, string PropertyType, string DataElements)
        {
            #region Navigate to Property Legal Description
            Reports.TestStep = "Navigate to Property Legal Description.";
            FastDriver.ExchangePropertiesLegalDecription.Open();
            #endregion

            #region Fill With Relinguished Data Elements
            Reports.TestStep = "Fill with " + PropertyType + "Data Elements";
            FastDriver.ExchangePropertiesLegalDecription.PropertySelection.FASelectItemByIndex(Property);
            FastDriver.ExchangePropertiesLegalDecription.CompleteLegalDescription.FASetText(DataElements);
            FastDriver.BottomFrame.Done();
            #endregion
        }
        #endregion

        #region Setting DataElements
        private string SettingDataElements(string PropertyType, List<string> DataElements)
        {
            string dataElements = "";

            switch (PropertyType)
            {
                case "Relinquished":
                    dataElements = DataElements[0];
                    break;
                case "Replaced":
                    dataElements = DataElements[1] + "\n" + DataElements[2] + "\n" + DataElements[3];
                    break;
                case "Adquisition":
                    dataElements = DataElements[0] + "\n" + DataElements[2] + "\n" + DataElements[3] + "\n" + DataElements[4] + "\n" + DataElements[5] + "\n" + DataElements[6] + "\n" + DataElements[7] + "\n" + DataElements[8] + "\n" + DataElements[13] + "\n" + DataElements[14];
                    break;
                case "Disposition":
                    dataElements = DataElements[1] + "\n" + DataElements[2] + "\n" + DataElements[2] + "\n" + DataElements[2] + "\n" + DataElements[2] + "\n" + DataElements[2] + "\n" + DataElements[2] + "\n" + DataElements[2] + "\n" + DataElements[2];
                    break;
                default:
                    break;
            }

            return dataElements;
        }
        #endregion

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}