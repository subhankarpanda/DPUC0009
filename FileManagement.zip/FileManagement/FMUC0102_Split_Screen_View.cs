﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects;
using FASTWCFHelpers.FastFileService;
using System.Threading;


namespace FileManagement
{

    /// <summary>
    /// Summary description for FMUC0102 Split screen view
    /// </summary>
    [CodedUITest]

    public class FMUC0102 : MasterTestClass
    {

        #region BAT

        #region Test FMUC0102_BAT0001

        /// <summary>
        /// MF1: Utilize My FAST Today in Horizontal Split Screen View _ AF1: Utilize My FAST Today in Pop-Up (Float) Split Screen View.
        /// </summary>

        [TestMethod]
        public void FMUC0102_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Utilize My FAST Today in Horizontal Split Screen View _ AF1: Utilize My FAST Today in Pop-Up (Float) Split Screen View.";

                #region Data Setup

                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Verify the user and other details in MFT
                Reports.TestStep = "Verify the user, alert type and filter default criteria.";
                FastDriver.MyFASTToday.Open();
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All Categories", FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().ToString().Trim(), true);

                Reports.TestStep = "Click on Find Now and Select task.";
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.WaitForTaskTableToLoad();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("Assigned To", @"QA07, FAST", "Assigned To", TableAction.Click);
                FastDriver.MyFASTToday.TasksSelect.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.CollapseAll);
                #endregion

                #region Validate the Bottomlink elements
                Reports.TestStep = "Click onSplitMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> SplitMFT = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //SplitMFT[2].FAClick();

                Reports.TestStep = "Click AutoHideMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> AutoHideMFT = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //AutoHideMFT[2].FAClick();

                Reports.TestStep = "Click HideMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> HideMFT = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //HideMFT[2].FAClick();

                Reports.TestStep = "Click on SplitMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> SplitMFT2 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //SplitMFT2[2].FAClick();

                Reports.TestStep = "Click on Apply, Find Now and Next in the split view.";
                FastDriver.WebDriver.SwitchTo().Frame("fraWorkFlow").SwitchTo().Frame("fraPageWin");
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All Categories", FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().ToString().Trim(), true);
                FastDriver.MyFASTToday.Apply.FAClick();
                FastDriver.MyFASTToday.Next.FAClick();

                Reports.TestStep = "Click AutoHideMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> AutoHideMFT2 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //AutoHideMFT2[2].FAClick();

                Reports.TestStep = "Click HideMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> HideMFT2 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //HideMFT2[2].FAClick();

                #endregion

                #region AF1: Utilize My FAST Today in Pop-Up (Float) Split Screen View.
                Reports.TestStep = "Click on Pop up MFT in top frame.";
                FastDriver.TopFrame.SwitchToTopFrame();
                string s = FastDriver.TopFrame.Pop_UpMFT.IsDisplayed().ToString();
                FastDriver.TopFrame.Pop_UpMFT.FAClick();

                Reports.TestStep = "Verify the user.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST v5.0", true, 20);
                FastDriver.WebDriver.SwitchTo().Frame("fraMFTView").SwitchTo().Frame("fraPageWin");
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All Categories", FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().ToString().Trim(), true);


                Reports.TestStep = "Click on Find Now and Select task.";
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.WaitCreation(FastDriver.MyFASTToday._ActiveTasksTable);
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("Assigned To", @"QA07, FAST", "Assigned To", TableAction.Click);
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(2, 4, TableAction.Click);
                string FileNum = FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString();
                FastDriver.MyFASTToday.TasksSelect.FAClick();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                string FileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                Support.AreEqual(FileNum.Trim(), FileNumber2.Trim(), true);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.CollapseAll.IsDisplayed().ToString().Trim(), true);

                Reports.TestStep = "Click on Apply, Find Now and Next.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST v5.0", true, 20);
                FastDriver.WebDriver.SwitchTo().Frame("fraMFTView").SwitchTo().Frame("fraPageWin");
                FastDriver.MyFASTToday.Apply.FAClick();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.Next.FAClick();

                Reports.TestStep = "Close the MFT dialog.";
                FastDriver.WebDriver.Close();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0102_BAT0002
        /// <summary>
        /// AF1: Utilize My FAST Today in Pop-Up (Float) Split Screen View.
        /// </summary>

        [TestMethod, Obsolete]

        public void FMUC0102_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Utilize My FAST Today in Pop-Up (Float) Split Screen View. - Covered in BAT0001";
                Reports.StatusUpdate("AF1: Utilize My FAST Today in Pop-Up (Float) Split Screen View. - Covered in BAT0001", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0102_BAT0003A

        /// <summary>
        /// Precondition: Validate for Task is enabled.
        /// </summary>

        [TestMethod]
        public void FMUC0102_BAT0003A()
        {
            try
            {
                Reports.TestDescription = "Precondition: Validate for Task is enabled, Process for Manual Activation, if Task is not in Activate status, Add/Edit a Task Comment.";

                #region Data Setup

                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Precondition: Validate for Task is enabled.
                Reports.TestStep = "Navigate to file workflow.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Check if Process Name exists.";
                Support.AreEqual("True", FastDriver.FileWorkflow.ProcessName.Exists().ToString());
                if (FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "2", 3, TableAction.GetAttribute, "selected").Message != "true")
                {

                    Reports.TestStep = "Select the process.";
                    // Support.AreEqual("ADEC-ITI-BILL-FULL-SP", FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "2", 5, TableAction.GetText).Message);
                    FastDriver.FileWorkflow.ProcessActiveTable(4, "2", 5, TableAction.Click);

                    Reports.TestStep = "Click On Details Button.";
                    FastDriver.FileWorkflow.Details.FAClick();

                    Reports.TestStep = "Click On Manual Activation.";
                    FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                    FastDriver.TaskDetails.ClickManualActivation();

                    Reports.TestStep = "Validate for Task is activated.";
                    FastDriver.FileWorkflow.WaitForScreenToLoad();
                    // Support.AreEqual("true", FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "2", 3, TableAction.GetAttribute, "selected").Message);

                }
                #endregion

                #region AF2: Add/Edit a Task Comment.
                Reports.TestStep = "Click on Collapse All and Then Click on Add Comments, and Reset .";

                Reports.TestStep = "Copied Task Comments to File Notes via Workflow.";
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "1", 12, TableAction.Click);

                Reports.TestStep = "Add Taskcomments and Click Done.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("Internal Comment For Automation Script.");
                FastDriver.TaskCommentEditDlg.Comment.FASetText("Comment For Automation Script.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Add a Note.";
                FastDriver.FileNotes.Open();
                FastDriver.FileNotes.WaitForScreenToLoad(FastDriver.FileNotes.New);
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad(FastDriver.FileNotes.New);
                FastDriver.FileNotes.New.FAClick();
                Thread.Sleep(8000);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

                Reports.TestStep = "Click on Collapse All and Then Click on Add Comments.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "1", 12, TableAction.Click);

                Reports.TestStep = "Add Taskcomments and Click Done.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("Edited Internal Comment For Automation Script.");
                FastDriver.TaskCommentEditDlg.Comment.FASetText("Edited Comment For Automation Script.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Apply();

                Reports.TestStep = "Validate the Added Task comment in File notes.";
                FastDriver.FileNotes.Open();
                FastDriver.FileNotes.NotesType.FASelectItem("All Notes");
                string NotesTable = FastDriver.FileNotes.Table.PerformTableAction(2, 1, TableAction.GetText).Message.ToString();
                Support.AreEqual("true", NotesTable.Contains("Edited Internal Comment For Automation Script").ToString().Trim().ToLower(), true);
                Support.AreEqual("true", NotesTable.Contains("Edited Comment For Automation Script").ToString().Trim().ToLower(), true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0102_BAT0003B
        /// <summary>
        /// Process for Manual Activation, if Task is not in Activate status
        /// </summary>

        [TestMethod, Obsolete]

        public void FMUC0102_BAT0003B()
        {
            try
            {
                Reports.TestDescription = "Process for Manual Activation, if Task is not in Activate status. - Covered in BAT0003A";
                Reports.StatusUpdate("Process for Manual Activation, if Task is not in Activate status - Covered in BAT0003A", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0102_BAT0003C
        /// <summary>
        /// Add / Edit a task comment
        /// </summary>

        [TestMethod, Obsolete]

        public void FMUC0102_BAT0003C()
        {
            try
            {
                Reports.TestDescription = "Add / Edit a task comment. - Covered in BAT0003A";
                Reports.StatusUpdate("Add / Edit a task comment. - Covered in BAT0003A", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region Regression

        #region FMUC0102_REG0001
        /// <summary>
        /// BR_8275_8277: Split Screen Workflow, Refresh My FAST Today, Split Screen View Options.
        /// </summary>

        [TestMethod]

        public void FMUC0102_REG0001()
        {
            try
            {
                Reports.TestDescription = "BR_8275_8277_8272_8309_8273: Split Screen Workflow, Refresh My FAST Today, Split Screen View Options,Split Screen View Options, Minimize Summary Alerts , Change FAST Main Source Screens.";
                #region Data Setup
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Click onSplitMFT Link.
                Reports.TestStep = "Click onSplitMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //BottomLinkElements[2].FAClick();
                #endregion

                #region Change the Transaction type to Accommodation in File home page.
                Reports.TestStep = "Change the Transaction type to Accommodation in File home page.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Accommodation");
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("Accommodation", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem().ToString().Trim(), true);
                #endregion

                #region Perform finding a task and validate the default Filter options in MFT.

                Reports.TestStep = "Verify the user information.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.SwitchTo().Frame("fraWorkFlow").SwitchTo().Frame("fraPageWin");
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().ToString().Trim(), true);

                Reports.TestStep = "Perform finding a task and validate the default Filter options in MFT.";
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.WaitCreation(FastDriver.MyFASTToday._ActiveTasksTable);
                // FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("Assigned To", @"QA07, FAST", "Assigned To", TableAction.Click);
                string FileNum = FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(3, 4, TableAction.GetText).Message.ToString();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(3, 4, TableAction.Click);
                FastDriver.MyFASTToday.TasksSelect.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                string FileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                Support.AreEqual(FileNum.Trim(), FileNumber2.Trim(), true);

                // FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.CollapseAll);

                Reports.TestStep = "Select My filters and apply.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.SwitchTo().Frame("fraWorkFlow").SwitchTo().Frame("fraPageWin");
                FastDriver.MyFASTToday.MyFilters.FASelectItemByIndex(1);
                Thread.Sleep(5000);
                FastDriver.MyFASTToday.Apply.FAClick();
                #endregion

                Reports.TestStep = "Click AutoHideMFT, HideMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();

                // System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> AutoHideMFT = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));

                Reports.TestStep = "Click AutoHideMFT, HideMFT Link.";
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                // AutoHideMFT[2].FAClick();

                Reports.TestStep = "Click HideMFT Link.";
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> HideMFT = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //HideMFT[2].FAClick();

                Reports.TestStep = "Validate the Business segment values in File home page.";
                FastDriver.FileHomepage.Open();
                Support.AreEqual("Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().ToString().Trim(), true);

                Reports.TestStep = "Click on SplitMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements3 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //BottomLinkElements3[2].FAClick();

                Reports.TestStep = "Verify the Summary Alerts button.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.SwitchTo().Frame("fraWorkFlow").SwitchTo().Frame("fraPageWin");
                Support.AreEqual("cButtonExpandFalsePVR", FastDriver.MyFASTToday.SummaryAlerts.GetAttribute("class").ToString().Trim(), true);

                Reports.TestStep = "Delete a alert and click apply.";
                FastDriver.MyFASTToday.Open();
                FastDriver.MyFASTToday.DeleteAlerts.FAClick();
                FastDriver.MyFASTToday.Apply.FAClick();
                Support.AreEqual("cButtonExpandPVR", FastDriver.MyFASTToday.SummaryAlerts.GetAttribute("class").ToString().Trim(), true);

                Reports.TestStep = "Navigate to Survey screen.";
                FastDriver.SurveyDetail.Open();
                Support.AreEqual("Survey", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click AutoHideMFT, HideMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();

                // System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements4 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));

                Reports.TestStep = "Click AutoHideMFT, HideMFT Link.";
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                // BottomLinkElements4[2].FAClick();

                Reports.TestStep = "Click HideMFT Link.";
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements5 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //BottomLinkElements5[2].FAClick();
            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0102_REG0002
        /// <summary>
        /// BR_8272_8309_8273: Split Screen View Options, Minimize Summary Alerts , Change FAST Main Source Screens.
        /// </summary>

        [TestMethod, Obsolete]

        public void FMUC0102_REG0002()
        {
            try
            {
                Reports.TestDescription = "BR_8272_8309_8273: Split Screen View Options, Minimize Summary Alerts , Change FAST Main Source Screens. - Covered in REG0001";
                Reports.StatusUpdate("BR_8272_8309_8273: Split Screen View Options, Minimize Summary Alerts , Change FAST Main Source Screens. - Covered in REG0001", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0102_REG0003
        /// <summary>
        /// BR_8302_8276: Activate Work Queues, BR_8289: Deactivate Pop-Up (Float) view.
        /// </summary>

        [TestMethod]

        public void FMUC0102_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_8302_8276_8280_8735:: Activate Work Queues _ Deactivate Pop-Up (Float) view _ Retain Split Screen Workflow View.";
                #region Data Setup
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.FileHomepage.Open();
                #endregion

                #region Click onSplitMFT Link.
                Reports.TestStep = "Click onSplitMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //BottomLinkElements[2].FAClick();
                #endregion

                #region Click on WorkQ link.
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WorkQ.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(clickRetain: true);
                #endregion

                #region Validate the Business Segment Values, Verify the user information.
                Reports.TestStep = "Validate the Business segment values.";
                FastDriver.FileHomepage.SwitchToContentFrame();
                Support.AreEqual("Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().ToString().Trim(), true);

                Reports.TestStep = "Verify the user information.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.SwitchTo().Frame("fraWorkFlow").SwitchTo().Frame("fraPageWin");
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().ToString().Trim(), true);

                Reports.TestStep = "Verify Default value on Work Queue Screen.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem("EmailQueueedited");
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(clickRetain: true);
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Click AutoHideMFT, HideMFT Link.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomLinks.SwitchToBottomlink();
                // System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements4 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));

                Reports.TestStep = "Click AutoHideMFT, HideMFT Link.";
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                // BottomLinkElements4[2].FAClick();

                Reports.TestStep = "Click HideMFT Link.";
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements4_Hide = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //BottomLinkElements4_Hide[2].FAClick();
                #endregion

                #region BR_8280: Deactivate Pop-Up (Float) view.
                Reports.TestStep = "Click on Popup MFT in TOp Frame.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Pop_UpMFT.FAClick();

                Reports.TestStep = "Verify the user information.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST v5.0", true, 20);
                FastDriver.WebDriver.SwitchTo().Frame("fraMFTView").SwitchTo().Frame("fraPageWin");
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All Categories", FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().ToString().Trim(), true);
                FastDriver.WebDriver.Close();
                #endregion

                #region BR_8735: Retain Split Screen Workflow View.
                Reports.TestStep = "Click onSplitMFT Link.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements5 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //BottomLinkElements5[2].FAClick();

                Reports.TestStep = "Validate the Business segment values.";
                FastDriver.FileHomepage.SwitchToContentFrame();
                Support.AreEqual("Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().ToString().Trim(), true);

                Reports.TestStep = "Verify the user information.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.SwitchTo().Frame("fraWorkFlow").SwitchTo().Frame("fraPageWin");
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All Categories", FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().ToString().Trim(), true);

                Reports.TestStep = "Select File Owning Region and other click Find, select task and click select.";
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem("All Categories");
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.TaskRegion.FASelectItemByIndex(0);
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.SelectActiveTask1.FAClick();
                FastDriver.MyFASTToday.TasksSelect.FAClick();

                Reports.TestStep = "Click AutoHideMFT, HideMFT Link.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                // System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements6 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));

                Reports.TestStep = "Click AutoHideMFT, HideMFT Link.";
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                // BottomLinkElements6[2].FAClick();

                Reports.TestStep = "Click HideMFT Link.";
                FastDriver.BottomLinks.ClickOnBottomLinkElements();
                //System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements7 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
                //BottomLinkElements7[2].FAClick();
                #endregion

                #region BR_8736_EWC: Modal Windows.
                Reports.TestStep = "Click on PopUP MFT Link.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Pop_UpMFT.FAClick();

                Reports.TestStep = "Verify the user.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST v5.0", true, 20);
                FastDriver.WebDriver.SwitchTo().Frame("fraMFTView").SwitchTo().Frame("fraPageWin");
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All Categories", FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().ToString().Trim(), true);

                Reports.TestStep = "Click find, select task and click Event log.";
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem("All Categories");
                FastDriver.MyFASTToday.FileOwningRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.TaskRegion.FASelectItemByIndex(0);
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.SelectActiveTask1.FAClick();
                FastDriver.MyFASTToday.TasksSelect.FAClick();
                FastDriver.MyFASTToday.WaitCreation(FastDriver.MyFASTToday._ActiveTasksTable);
                FastDriver.MyFASTToday.TasksSelect.Highlight();
                FastDriver.MyFASTToday.EventLogTasks.Highlight(); //.FAClick();
                FastDriver.MyFASTToday.EventLogTasks.FAClick();
                // Thread.Sleep(5000);

                Reports.TestStep = "Verify the Event Category.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad(FastDriver.EventTrackingLogDlg.Comments);
                // FastDriver.EventTrackingLogDlg.WaitCreation(FastDriver.EventTrackingLogDlg.Comments);
                FastDriver.EventTrackingLogDlg.EventCategory.FASelectItem("Workflow");
                FastDriver.DialogBottomFrame.ClickDone();

                // Close the Event Tracking Log dialog
                Reports.TestStep = "Click on Task Comment icon.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST v5.0", true, 20);
                FastDriver.WebDriver.SwitchTo().Frame("fraMFTView").SwitchTo().Frame("fraPageWin");
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction("#9", "QA07, FAST", "#12", TableAction.Click);

                Reports.TestStep = "Enter comments and click cancel.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.Comment.FASetText("Test");
                FastDriver.TaskCommentEditDlg.Cancel.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 10);

                Reports.TestStep = "Verify the user information.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST v5.0", true, 20);
                FastDriver.WebDriver.SwitchTo().Frame("fraMFTView").SwitchTo().Frame("fraPageWin");
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.AlertUser.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All", FastDriver.MyFASTToday.AlertType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("QA07, FAST", FastDriver.MyFASTToday.FilterEmployee.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("All Categories", FastDriver.MyFASTToday.FilterTaskCategory.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Show all", FastDriver.MyFASTToday.TaskStatus.FAGetSelectedItem().ToString().Trim(), true);

                Reports.TestStep = "Select Active Task 2 on Pop-MFT window.";
                // FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.SelectActiveTask2.FAClick();

                Reports.TestStep = "Validate the Business segment values.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.Open();
                Support.AreEqual("Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().ToString().Trim(), true);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0102_REG0004
        /// <summary>
        /// BR_8280: Deactivate Pop-Up (Float) view.
        /// </summary>

        [TestMethod, Obsolete]

        public void FMUC0102_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_8280: Deactivate Pop-Up (Float) view. - Covered in REG0003";
                Reports.StatusUpdate("BR_8280: Deactivate Pop-Up (Float) view. - Covered in REG0003", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0102_REG0005
        /// <summary>
        /// BR_8735: Retain Split Screen Workflow View.
        /// </summary>

        [TestMethod, Obsolete]

        public void FMUC0102_REG0005()
        {
            try
            {
                Reports.TestDescription = "BR_8735: Retain Split Screen Workflow View. - Covered in REG0003";
                Reports.StatusUpdate("BR_8735: Retain Split Screen Workflow View. - Covered in REG0003", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0102_REG0006
        /// <summary>
        /// BR_8736_EWC: Modal Windows.
        /// </summary>

        [TestMethod, Obsolete]

        public void FMUC0102_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR_8736_EWC: Modal Windows. - Covered in REG0003";
                Reports.StatusUpdate("BR_8736_EWC: Modal Windows. - Covered in REG0003", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0102_REG0007
        /// <summary>
        /// Reports.TestDescription = "BR_8746: Region Level Access.
        /// </summary>

        [TestMethod]

        public void FMUC0102_REG0007()
        {
            try
            {
                Reports.TestDescription = "BR_8746: Region Level Access.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region BR_8746: Region Level Access.
                Reports.TestStep = "Click on Office.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();

                Reports.TestStep = "Verify Business unit.";
                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                FastDriver.LeftNavigation.Navigate<HomePage>("Home");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Validate the Pop-UpMFT button.";
                FastDriver.TopFrame.SwitchToTopFrame();
                Support.AreEqual("false", FastDriver.TopFrame.Pop_UpMFT.IsDisplayed().ToString().Trim().ToLower(), true);
                FastDriver.BottomLinks.SwitchToBottomlink();

                Reports.TestStep = "Validate that SplitMFT button doesnot exist in Region Level.";
                FastDriver.BottomLinks.ValidateSplitMFTButtonNonExistence();

                Reports.TestStep = "Click on Office.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();

                Reports.TestStep = "Navigate to Office Level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");
                FastDriver.LeftNavigation.Navigate<HomePage>("Home");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Validate the Pop-UpMFT button.";
                FastDriver.TopFrame.SwitchToTopFrame();
                Support.AreEqual("true", FastDriver.TopFrame.Pop_UpMFT.IsDisplayed().ToString().Trim().ToLower(), true);

                Reports.TestStep = "Validate SplitMFT button exist at office level.";
                FastDriver.BottomLinks.SwitchToBottomlink();
                FastDriver.BottomLinks.ValidateSplitMFTButtonExistence();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0102_REG0008_PH
        /// <summary>
        /// BR_8797: Disable Hot Key Functionality.
        /// </summary>

        [TestMethod, Obsolete]

        public void FMUC0102_REG0008_PH()
        {
            try
            {
                Reports.TestDescription = "BR_8797: Disable Hot Key Functionality.";
                Reports.StatusUpdate("Dummy subtest to use it as a Place holder for Non Automated scenarios - This Flow has NOT been Automated Please perform this MANUALLY", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0102_REG0009_PH
        /// <summary>
        /// Non_AutomatedFlows: BR_FM8274, BR_FM8734, BR_FM8746(TFS #123258), BR_FM8738 & 8797 (TFS#108678).
        /// </summary>

        [TestMethod, Obsolete]

        public void FMUC0102_REG0009_PH()
        {
            try
            {
                Reports.TestDescription = "Non_AutomatedFlows: BR_FM8274, BR_FM8734, BR_FM8746(TFS #123258), BR_FM8738 & 8797 (TFS#108678).";
                Reports.StatusUpdate("Dummy subtest to use it as a Place holder for Non Automated scenarios - This Flow has NOT been Automated Please perform this MANUALLY", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region Private Methods

        private void IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

}
