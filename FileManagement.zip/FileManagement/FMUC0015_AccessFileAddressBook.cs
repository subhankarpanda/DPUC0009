﻿// using OpenQA.Selenium;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
// using AutoIt;
using System.Linq;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Collections.Generic;
using System.Threading;

namespace FileManagement
{
    /// <summary>
    /// Summary description for FMUC0015 File Search
    /// </summary>
    [CodedUITest]

    public class FMUC0015 : MasterTestClass
    {
        #region Class Level Objects
        Dictionary<string, string> PropertyDictryFHP = new Dictionary<string, string>();
        Dictionary<string, string> BuyerDictryFHP = new Dictionary<string, string>();
        Dictionary<string, string> SellerDictryFHP = new Dictionary<string, string>();
        Dictionary<string, string> BusinessPartyDtlsOnFhp = new Dictionary<string, string>();
        Dictionary<string, string> BusinessPartyDtlsOnHOA = new Dictionary<string, string>();
        Dictionary<string, string> AssociatedBusPartyFHP = new Dictionary<string, string>();
        Dictionary<string, string> AssociatedBusPartyHOA = new Dictionary<string, string>();
        #endregion

        #region BAT
        #region Test FMUC0015_BAT0001

        /// <summary>
        /// MF1_01: 1.Login to Fast Application and set an order, MF1_02: 1 Set File Address book option in address book search.2 Validate that details of a party from File address book.
        /// </summary>
        [TestMethod]
        public void FMUC0015_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_01: 1.Login to Fast Application and set an order, MF1_02: 1 Set File Address book option in address book search.2 Validate that details of a party from File address book.";

                #region Data
                var ActivateAvailable = string.Empty;
                var DeactivateAvailable = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Save the data from File Home Page
                Reports.TestStep = "Verify the data in File Home Page";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                PropertyDictryFHP = FastDriver.FileHomepage.GetPropDetails;
                AssociatedBusPartyFHP = FastDriver.FileHomepage.GetAssociateBusinessPartyDtlsOnFhp;

                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                #endregion

                #region Set on Find button in Home Owner Association screen.
                Reports.TestStep = "Set on Find button in Home Owner Association screen.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.Find.FAClick();
                #endregion

                #region Set File address book radio button.
                Reports.TestStep = "Set File address book radio button.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Buyer", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Validate the data from address book of associated party is populated in this screen.
                Reports.TestStep = "Validate the data from address book of associated party is populated in this screen.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                AssociatedBusPartyHOA = FastDriver.HomeownerAssociation.GetAssociateBusinessPartyDtlsOnHOA;
                Support.AreEqual(AssociatedBusPartyHOA["BusPhoneHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyBusPhone"], true);
                Support.AreEqual(AssociatedBusPartyHOA["BusFaxHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyBusFax"], true);
                Support.AreEqual(AssociatedBusPartyHOA["CellPhoneHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyCellPhone"], true);
                Support.AreEqual(AssociatedBusPartyHOA["PagerHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyPager"], true);
                Support.AreEqual(AssociatedBusPartyHOA["EmailAddressHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyEmailAddress"], true);
                #endregion

                // modified on 26-May-2015
                //FM1319 - Display Active Entities  -  Inactivating a GAB and then validate 
                #region Create an invoice
                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.New.FAClick();
                Thread.Sleep(5000);

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search");
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("boa");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("#4", "Bank of America", "#1", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                EnterFeeInTitleEscrowTab();

                #region Associate the fee.
                Reports.TestStep = "Associate the fee.";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction("Invoice Name", "Bank of America", "Status", TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                #endregion

                #region Search for BOA and change status to inactive
                ADMLOGIN();

                Reports.TestStep = "Search For BOA GAB code.";
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.EntityID.FASetText("boa");
                FastDriver.AddressBookSearch.SearchActiveOnly.FASetCheckbox(false);
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", "BOA", "Name", TableAction.Click);
                FastDriver.AddressBookSearch.ViewChangeStatus.FAClick();

                Reports.TestStep = "Deactivate the fee";
                FastDriver.StatusEdit.WaitForScreenToLoad();
                DeactivateAvailable = FastDriver.StatusEdit.Deactivate.IsDisplayed().ToString();
                if (DeactivateAvailable == "true")
                {
                    FastDriver.StatusEdit.Deactivate.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                }
                FastDriver.StatusEdit.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Login to IIS side and verify if the deactivated payee is present in Invoice Fees
                IISLOGIN();

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify in Invoice Fees screen if the deactivated payee is present";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction("Invoice Name", "Bank of America", "Status", TableAction.Click);
                #endregion

                #region Loagin again go to ADM side and activate BOA payee

                ADMLOGIN();

                Reports.TestStep = "Search For BOA GAB code.";
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.EntityID.FASetText("boa");
                FastDriver.AddressBookSearch.SearchActiveOnly.FASetCheckbox(false);
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", "BOA", "Name", TableAction.Click);
                FastDriver.AddressBookSearch.ViewChangeStatus.FAClick();

                Reports.TestStep = "Deactivate the fee";
                FastDriver.StatusEdit.WaitForScreenToLoad();
                ActivateAvailable = FastDriver.StatusEdit.Activate.IsDisplayed().ToString();
                if (ActivateAvailable == "true")
                {
                    FastDriver.StatusEdit.Activate.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                }
                FastDriver.StatusEdit.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0015_BAT0002
        /// <summary>
        /// MF1_02: 1 Set File Address book option in address book search.2 Validate that details of a party from File address book.
        /// </summary>
        [TestMethod, Obsolete]
        public void FMUC0015_BAT0002()
        {
            Reports.TestDescription = "MF1_02: 1 Set File Address book option in address book search.2 Validate that details of a party from File address book- covered in FMUC0015_BAT001.";
            Reports.StatusUpdate("The same has been covered in FMUC0015_BAT001.", true);
        }
        #endregion

        #endregion BAT

        #region REG

        #region Test FMUC0015_REG0001

        /// <summary>
        /// BR_FM689_FM691: 1. FMUC0015 Access File Address Book 2. Access File Address Book.
        /// </summary>
        [TestMethod]
        public void FMUC0015_REG0001()
        {
            try
            {
                Reports.TestDescription = "BR_FM689_FM691: 1. FMUC0015 Access File Address Book 2. Access File Address Book. _ BR_FM700_FM701_FM1438_FM699_FM1443: 1. Individual Name Format 2. Show Husband and Wife to Select 3. Display Role as Buyer Seller 4. Display Format - Buyer Seller 5.User Selection.";

                #region Data

                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Office Level.
                Reports.TestStep = "Navigate to Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                Reports.TestStep = "Select QA Automation Region.";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedOfficeBUID);
                #endregion

                #region Create Order and save the data from FHP.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Save the data from File Home Page
                Reports.TestStep = "Verify the data in File Home Page";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                PropertyDictryFHP = FastDriver.FileHomepage.GetPropDetails;
                AssociatedBusPartyFHP = FastDriver.FileHomepage.GetAssociateBusinessPartyDtlsOnFhp;
                BusinessPartyDtlsOnFhp = FastDriver.FileHomepage.GetBusinessPartyDtlsOnFhp;

                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                #endregion

                #region Verify the details
                Reports.TestStep = "Set on Find button in Home Owner Association screen.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Business Source", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the HOA details against FHP details.";
                FastDriver.HomeownerAssociation.Open();
                BusinessPartyDtlsOnHOA = FastDriver.HomeownerAssociation.GetBusinessPartyDtlsOnHOA;
                Support.AreEqual(BusinessPartyDtlsOnHOA["IDCodeText"], BusinessPartyDtlsOnFhp["BusinessPartyIDCodeField"], true);
                Support.AreEqual(BusinessPartyDtlsOnHOA["HomeOwnerName1"], BusinessPartyDtlsOnFhp["BusinessPartyNameField"], true);
                Support.AreEqual(BusinessPartyDtlsOnHOA["HomeOwnerName2"], BusinessPartyDtlsOnFhp["BusinessPartyNameField2"], true);
                Support.AreEqual(BusinessPartyDtlsOnHOA["HomeOwnerAddress1"], BusinessPartyDtlsOnFhp["BusSrceAdd1"], true);
                Support.AreEqual(BusinessPartyDtlsOnHOA["HomeOwnerAddress2"], BusinessPartyDtlsOnFhp["BusSrceAdd2"], true);
                Support.AreEqual(BusinessPartyDtlsOnHOA["HomeOwnerAddress3"], BusinessPartyDtlsOnFhp["BusSrceAdd3"], true);

                Reports.TestStep = "Set File address book radio button.";
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the data from address book of associated party is populated in this screen.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                AssociatedBusPartyHOA = FastDriver.HomeownerAssociation.GetAssociateBusinessPartyDtlsOnHOA;
                Support.AreEqual(AssociatedBusPartyHOA["BusPhoneHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyBusPhone"], true);
                Support.AreEqual(AssociatedBusPartyHOA["BusFaxHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyBusFax"], true);
                Support.AreEqual(AssociatedBusPartyHOA["CellPhoneHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyCellPhone"], true);
                Support.AreEqual(AssociatedBusPartyHOA["PagerHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyPager"], true);
                Support.AreEqual(AssociatedBusPartyHOA["EmailAddressHOA"], AssociatedBusPartyFHP["AssociateBusinessPartyEmailAddress"], true);
                #endregion

                #region Validate Individual Name Format
                Reports.TestStep = "Validate Individual Name Format_ Set on Find button in Home Owner Association screen.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.Find.FAClick();

                Reports.TestStep = "Display Role Buyer or Seller.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Seller", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate Individual Format for Seller";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                Support.AreEqualTrim("Seller1FirstName Seller1Lastname", FastDriver.HomeownerAssociation.HomeOwnerName1.FAGetText().ToString());

                Reports.TestStep = "Display Role Buyer or Seller.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Name", "Buyer1Firstname Buyer1Lastname", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate Individual Format for Seller";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                Support.AreEqualTrim("Buyer1Firstname Buyer1Lastname", FastDriver.HomeownerAssociation.HomeOwnerName1.FAGetText().ToString());
                #endregion

                #region Validate Husband Wife name Format
                Reports.TestStep = "Set on Find button in Home Owner Association screen.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.Find.FAClick();

                Reports.TestStep = "Select instance with type Husband and wife.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Name", @"Buyer2Firstname Buyer2Lastname / Buyer2SpouseName Buyer2Lastname", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate Husband and wife format.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                Support.AreEqualTrim("Buyer2SpouseNam", FastDriver.HomeownerAssociation.HomeOwnerName2.FAGetText().ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }

        }

        #endregion

        #region Test FMUC0015_REG0002
        /// <summary>
        /// BR_FM700_FM701_FM1438_FM699_FM1443: 1. Individual Name Format 2. Show Husband and Wife to Select 3. Display Role as Buyer Seller 4. Display Format - Buyer Seller 5.User Selection.
        /// </summary>
        [TestMethod, Obsolete]
        public void FMUC0015_REG0002()
        {
            Reports.TestDescription = "BR_FM700_FM701_FM1438_FM699_FM1443: 1. Individual Name Format 2. Show Husband and Wife to Select 3. Display Role as Buyer Seller 4. Display Format - Buyer Seller 5.User Selection.- covered in FMUC0015_REG0001.";
            Reports.StatusUpdate("The same has been covered in FMUC0015_REG0001.", true);
        }
        #endregion

        #region Test FMUC0015_REG0003

        /// <summary>
        /// BR_FM705_FM706_FM9116: 1. Show Bus Entity to Select 2. Bus Org Short Name in File AB 3.Identify Exchange Company With Its Buyer/Seller By Name._ BR_FM13452_FM13453_FM13454_FM13455: 1.Select Contact Address 2.Allow selection of Title Officer and/or Escrow Officer 3.Display Broker Address when Search Domain = FAB 4.Display Broker Contact when Search Domain = FAB.
        /// </summary>
        [TestMethod]
        public void FMUC0015_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_FM705_FM706_FM9116: 1. Show Bus Entity to Select 2. Bus Org Short Name in File AB 3.Identify Exchange Company With Its Buyer/Seller By Name._ BR_FM13452_FM13453_FM13454_FM13455: 1.Select Contact Address 2.Allow selection of Title Officer and/or Escrow Officer 3.Display Broker Address when Search Domain = FAB 4.Display Broker Contact when Search Domain = FAB.";

                #region Data

                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Office Level.
                Reports.TestStep = "Navigate to Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                Reports.TestStep = "Select QA Automation Region.";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedOfficeBUID);
                #endregion

                #region Create Order and save the data from FHP.
                Reports.TestStep = "Create File using web service for buyer Trust Estate and Business.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                // Enter Buyer type Trust Estate with name and TIN
                fileRequest.File.Buyers[0].Type = "Trust/Estate";
                fileRequest.File.Buyers[0].Name = "Buyer1Trustname";
                fileRequest.File.Buyers[0].TIN = "12-3456789";

                // Enter Buyer type Business Entity with name and TIN
                fileRequest.File.Buyers[1].Type = "Business Entity";
                fileRequest.File.Buyers[1].Name = "Buyer2EntityName";
                fileRequest.File.Buyers[1].TIN = "12-3456789";

                // Enter Seller type Trust Estate with name and TIN
                fileRequest.File.Sellers[0].Type = "Trust/Estate";
                fileRequest.File.Sellers[0].Name = "Seller1TrustName";
                fileRequest.File.Sellers[0].TIN = "23-4567891";

                // Enter Seller type Business Entity with name and TIN
                fileRequest.File.Buyers[1].Type = "Business Entity";
                fileRequest.File.Buyers[1].Name = "Seller2EntityName";
                fileRequest.File.Buyers[1].TIN = "23-4567891";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create Seller Business Entity.
                Reports.TestStep = "Create Seller Business Entity.";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                Thread.Sleep(5000);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Seller BusEntity Name");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("23-6598235");
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.FindGAB("EXCH02");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate Exchange company by its buyer or seller name.
                Reports.TestStep = "Set on Find button in Home Owner Association screen.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.Find.FAClick();

                Reports.TestStep = "Validate Exchange company by its buyer or seller name.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Exchange Company for Seller BusEntity Name", "Role", TableAction.Click);

                Reports.TestStep = "Validate the display of short name.";
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Name", "Seller1TrustName", "Name", TableAction.Click);

                Reports.TestStep = "Show Bus Entity to Select.";
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Name", "Seller2EntityName", "Name", TableAction.Click);

                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Name", "Seller2EntityName", "Select", TableAction.On);

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate Bus Org Short Name in File AB.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                Support.AreEqualTrim("Seller2EntityName", FastDriver.HomeownerAssociation.HomeOwnerName1.FAGetText().ToString());
                #endregion

                #region Create a Broker with contact details and edit the electronic details.
                Reports.TestStep = "Create a Broker with contact details and edit the electronic details.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("HUDOTHRBR1",false);
                FastDriver.RealEstateBrokerAgent.BrokerInformationEdit.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhone.FASetText("(616)451-2292");
                FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessFax.FASetText("(616)451-2291");
                FastDriver.RealEstateBrokerAgent.BrokerInformationCellPhone.FASetText("(991)729-9290");
                FastDriver.RealEstateBrokerAgent.BrokerInformationPager.FASetText("(535)345-2425");
                FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress.FASetText("broker@aol.com");
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItemByIndex(1); ;
                FastDriver.RealEstateBrokerAgent.ContactEdit.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.ContactBusinessPhone.FASetText("616)451-2292");
                FastDriver.RealEstateBrokerAgent.ContactBusinessFax.FASetText("(991)729-9290");
                FastDriver.RealEstateBrokerAgent.ContactEmailAddress.FASetText("Contact@aol.com");
                #endregion

                #region Perform email delivery.
                Reports.TestStep = "Navigate to file balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();
                FastDriver.EscrowFileBalanceSummary.cboMethod.FASelectItem("Email");
                FastDriver.EscrowFileBalanceSummary.Deliver();

                Reports.TestStep = "Click on To button in email dialog.";
                FastDriver.EmailDlg.WaitForDialogToLoad();
                Keyboard.SendKeys("%T");
                FastDriver.EmailSearchDlg.WaitForScreenToLoad();
                FastDriver.EmailSearchDlg.FileAddressBookRadio.FASetCheckbox(true);
                Keyboard.SendKeys("%F");
                FastDriver.EmailSearchDlg.WaitForResultsToLoad();
                FastDriver.EmailSearchDlg.FileAddressBookTable.PerformTableAction("Role", "Seller's Broker", "Dlvr Sel", TableAction.On);
                FastDriver.EmailSearchDlg.FileAddressBookTable.PerformTableAction("Role", "Seller's Broker Contact", "Dlvr Sel", TableAction.On);
                FastDriver.EmailSearchDlg.Finished.FAClick();
                // FastDriver.DialogBottomFrame.ClickCancel();

                FastDriver.EmailDlg.WaitForScreenToLoad();
                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - " + AutoConfig.FASTHomeURL);
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }

        }

        #endregion

        #region Test FMUC0015_REG0004

        /// <summary>
        /// BR_FieldVerification: Button verification.
        /// </summary>
        [TestMethod]
        public void FMUC0015_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_FieldVerification: Button verification.";

                #region Data

                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Office Level.
                Reports.TestStep = "Navigate to Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                Reports.TestStep = "Select QA Automation Region.";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedOfficeBUID);
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Validate hotkey actions
                Reports.TestStep = "Validate hotkey action for find button.";
                Reports.TestStep = "Set on Find button in Home Owner Association screen.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("HOA1");
                Keyboard.SendKeys("%F");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();

                Reports.TestStep = "Validate hotkey action for Clear button.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                Keyboard.SendKeys("%C");

                FastDriver.DialogBottomFrame.ClickCancel();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }

        }

        #endregion

        #region Test FMUC0015_REG0005
        /// <summary>
        /// BR_FM13452_FM13453_FM13454_FM13455: 1.Select Contact Address 2.Allow selection of Title Officer and/or Escrow Officer 3.Display Broker Address when Search Domain = FAB 4.Display Broker Contact when Search Domain = FAB.
        /// </summary>
        [TestMethod, Obsolete]
        public void FMUC0015_REG0005()
        {
            Reports.TestDescription = "BR_FM13452_FM13453_FM13454_FM13455: 1.Select Contact Address 2.Allow selection of Title Officer and/or Escrow Officer 3.Display Broker Address when Search Domain = FAB 4.Display Broker Contact when Search Domain = FAB. - covered in FMUC0015_REG0003.";
            Reports.StatusUpdate("The same has been covered in FMUC0015_REG0003.", true);
        }
        #endregion

        #region Test FMUC0015_REG0006
        /// <summary>
        /// BR_FM8824: Display eBusiness Icon.
        /// </summary>
        [TestMethod]
        public void FMUC0015_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR_FM8824: Display eBusiness Icon. BR_FM697: Change Entity Role for a File.";
                #region Data

                #endregion

                #region Login to ADM Side
                ADMLOGIN();
                #endregion

                #region Search For BOA GAB code.
                Reports.TestStep = "Search For BOA GAB code.";
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.EntityID.FASetText("HUDFLINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", "HUDFLINSR1", "ID Code", TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                #endregion

                #region Click on eSubscription button.
                Reports.TestStep = "Click on eSubscription button.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Wells Fargo");
                FastDriver.BusPartyOrgSetUp.eSubscriptions.FAClick();

                Reports.TestStep = "Check the ePayoff check box.";
                FastDriver.BusPartyOrgeSubscriptionsDlg.WaitForScreenToLoad();
                FastDriver.BusPartyOrgeSubscriptionsDlg.ePayoff.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText("HUDFLINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", "HUDFLINSR1", "#2", TableAction.Click);
                Support.AreEqualTrim("True", FastDriver.AddressBookSearch.eBusinessIcon.IsDisplayed().ToString());
                #endregion

                // BR_FM697: Change Entity Role for a File.
                #region Login to File Side
                IISLOGIN();
                #endregion

                #region Create Order and save the data from FHP.
                Reports.TestStep = "Create File using web service.";
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DIRECTEDBY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                var FileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region
                Reports.TestStep = "Verify business sources in File Summary.";
                FastDriver.FileSummary.Open();
                FastDriver.FileSummary.BusinessParties.FAClick();
                FastDriver.FileSummary.BusinesspartiesTable.Highlight();
                // Support.AreEqual("FN8013 LN3b7a", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction("Name", "Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", "Contact", TableAction.GetText).Message.ToString(), true);
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction("Role", "Business Source", "Name", TableAction.GetText).Message.ToString(), true);
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction("Role", "New Lender", "Name", TableAction.GetText).Message.ToString(), true);
                #endregion

                #region
                Reports.TestStep = "Set on Find button in Home Owner Association screen.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.Find.FAClick();

                Reports.TestStep = "Select instance with role business source.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Business Source", "Name", TableAction.GetText).Message.ToString(), true);
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.", FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "New Lender", "Name", TableAction.GetText).Message.ToString(), true);
                Support.AreEqual("Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Directed By", "Name", TableAction.GetText).Message.ToString(), true);

                Reports.TestStep = "Select instance with role seller attorney.";
                Support.AreEqual("Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Lender- Originating Branch", "Name", TableAction.GetText).Message.ToString(), true);
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.", FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "New Lender", "Name", TableAction.GetText).Message.ToString(), true);


                Reports.TestStep = "Validate for e image.";
                FastDriver.AddressBookSearchDlg.ValidationOFeEnabled();

                #endregion

                #region Select instance with role Associated Party.
                // modified on 27-May-2015
                // FM697 - Change Entity Role for a File  - BRs describes that when Gab is selected from FAB, then it created another entry in FAB.
                // Script only validates that a Gab can have multiple roles (via additional roles). It needs to be enhanced

                Reports.TestStep = "Select instance with role Associated Party.";
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.", FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Associated Party", "Name", TableAction.GetText).Message.ToString(), true);
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Associated Party", "Select", TableAction.On).ToString();
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Navigate to other page and verify if the same GAB has another role attached.
                Reports.TestStep = "Navigate to other page and verify if the same GAB has another role attached.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.", FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Associated Party", "Name", TableAction.GetText).Message.ToString(), true);
                Support.AreEqual("Lenders Advantage", FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Homeowner Association", "Name", TableAction.GetText).Message.ToString(), true);
                #endregion

                int TotalNumberOfRecords = FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.GetRowCount();
                TotalNumberOfRecords = TotalNumberOfRecords - 1;
                var Records = TotalNumberOfRecords.ToString();
                var SearchRecordMsg = FastDriver.AddressBookSearchDlg.TotalRecords.FAGetText().ToString();
                Support.AreEqual("True", SearchRecordMsg.Contains(Records).ToString(), true);
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "BR_FM704 - Trust Signer Name in File AB.";
                Reports.StatusUpdate("This BR is Invalid", true);

            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0015_REG0007
        /// <summary>
        /// BR_FM697: Change Entity Role for a File.
        /// </summary>
        [TestMethod]
        public void FMUC0015_REG0007()
        {
            Reports.TestDescription = "BR_FM697: Change Entity Role for a File.- Covered in REG0006";
            Reports.StatusUpdate("BR_FM697: Change Entity Role for a File.- Covered in REG0006", true);
        }
        #endregion

        #region Test FMUC0015_REG0008_PH

        [TestMethod]
        public void FMUC0015_REG0008_PH()
        {
            Reports.TestDescription = "FM14833_FM14834_FM14835_FM14836_FM14837_FM14838_FM14839_FM14840_FM14841_FM14842_FM14843_FM14844_FM14845_FM14846_FM14847_FM14848_FM14849_FM14850_FM14851_PlaceHolder: MDM Business Requirements";
            Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);
        }
        #endregion Test

        #region Test FMUC0015_REG0009
        /// <summary>
        /// BR_FM8824: Display eBusiness Icon.
        /// </summary>
        [TestMethod]
        public void FMUC0015_REG0009()
        {
            try
            {
                Reports.TestDescription = "BR_FMXXXX: Access File Address Book - File Entry Activity Rights - Limited.";
                #region Data

                #endregion

                #region Login to ADM side with superuser credentials
                ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Office Level.
                Reports.TestStep = "Navigate to Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                Reports.TestStep = "Select QA Automation Region.";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedOfficeBUID);
                #endregion

                #region In role maintenance select a new role.
                Reports.TestStep = "In role maintenance select a new role.";
                FastDriver.RoleMaintenanceSummary.Open();
                FastDriver.RoleMaintenanceSummary.New.FAClick();

                // in role setup - give "role name" , select "office" radio button , activity group - office file processing activity - limited group
                FastDriver.RoleSetup.WaitForScreenToLoad();
                var SampleRoleName = Support.RandomString("AAAAAANNNN");
                FastDriver.RoleSetup.RoleName.FASetText(SampleRoleName);
                FastDriver.RoleSetup.Office.FASetCheckbox(true);
                FastDriver.RoleSetup.ActivityGroup.FASelectItem("Office File Processing Activity-Limited Group");
                Thread.Sleep(10000);
                FastDriver.RoleSetup.AvailableRightsTable.PerformTableAction("Activity", "File Entry Activity-Limited", "Select", TableAction.On);
                FastDriver.RoleSetup.AvailableRightsTable.PerformTableAction("Activity", "Search Vendor Only", "Select", TableAction.On);
                FastDriver.RoleSetup.Add.FAClick();

                FastDriver.BottomFrame.Save();
                FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
                FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();
                #endregion

                #region Navigate to Employee security - Enter userid and search
                Reports.TestStep = "Navigate to Employee security - Enter userid and search.";
                FastDriver.EmployeeSecurity.Open();
                FastDriver.EmployeeSecurity.LoginNameTextbox.FASetText(@"Fastts\Fastqa06");
                FastDriver.EmployeeSecurity.RegionDropdown.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.EmployeeSecurity.SearchNowButton.FAClick();
                FastDriver.EmployeeSearch.WaitCreation(FastDriver.EmployeeSearch.SearchResultsEmployees);

                FastDriver.EmployeeSecurity.ResultsTable.PerformTableAction(1, @"[FASTTS\FASTQA06]", 1, TableAction.DoubleClick);

                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad(null, Convert.ToInt32(AutoConfig.WaitTime));
                FastDriver.BusinessUnitRoleAssignment.SelectBusinessUnit(AutoConfig.SelectedRegionBUID);
                FastDriver.BusinessUnitRoleAssignment.SelectOfficeUnderBusinessUnits_(AutoConfig.SelectedOfficeBUID);

                #endregion

                #region Set only the Sample ROle
                Reports.TestStep = "Add role";
                FastDriver.BusinessUnitRoleAssignment.AddRole();
                
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();
                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", SampleRoleName, "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Save();

                FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
                FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();
                #endregion

                #region Login to File Side
                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Navigate to Office Level.
                Reports.TestStep = "Navigate to Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                Reports.TestStep = "Select QA Automation Region.";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedOfficeBUID);
                #endregion

                #region Create Order and save the data from FHP.
                Reports.TestStep = "Create File using web service.";
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DIRECTEDBY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                var FileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Verify in Business Parties
                Reports.TestStep = "Verify in Business Parties";
                FastDriver.FileSummary.Open();
                FastDriver.FileSummary.BusinessParties.FAClick();
                Thread.Sleep(5000);
                Support.AreEqual("XXX", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction("#2", "Business Source", "#3", TableAction.GetText).Message.ToString(), true);
                Support.AreEqual("XXX", FastDriver.FileSummary.BusinesspartiesTable.PerformTableAction("#2", "Associated Party", "#3", TableAction.GetText).Message.ToString(), true);
                #endregion

                #region Login to ADM and revert the changes
                Reports.TestStep = "Login to ADM and revert the changes";

                #region Login to ADM side with superuser credentials
                ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Office Level.
                Reports.TestStep = "Navigate to Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                Reports.TestStep = "Select QA Automation Region.";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedOfficeBUID);
                #endregion

                #region Navigate to Employee security - Enter userid and search
                Reports.TestStep = "Navigate to Employee security - Enter userid and search.";
                FastDriver.EmployeeSecurity.Open();
                FastDriver.EmployeeSecurity.LoginNameTextbox.FASetText(@"Fastts\Fastqa06");
                FastDriver.EmployeeSecurity.RegionDropdown.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.EmployeeSecurity.SearchNowButton.FAClick();
                FastDriver.EmployeeSearch.WaitCreation(FastDriver.EmployeeSearch.SearchResultsEmployees);

                FastDriver.EmployeeSecurity.ResultsTable.PerformTableAction("#1", @"[FASTTS\FASTQA06]", "#1", TableAction.DoubleClick);
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad(null, Convert.ToInt32(AutoConfig.WaitTime));
                FastDriver.BusinessUnitRoleAssignment.SelectBusinessUnit(AutoConfig.SelectedRegionBUID);
                FastDriver.BusinessUnitRoleAssignment.SelectOfficeUnderBusinessUnits_(AutoConfig.SelectedOfficeBUID);
                #endregion

                Reports.TestStep = "Revert back the changes for fastqa06";
                FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();
                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", SampleRoleName, "Select", TableAction.Off);
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", "IT - all", "Select", TableAction.On);
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", "Office Administrator", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Save();
                FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
                FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();

                #endregion
            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }
        }
        #endregion


        #region Test FMUC0015_REG0010
        /// <summary>
        /// SalesRep - (Verify the sales rep details in employee search - email and fax)
        /// </summary>
        [TestMethod]
        public void FMUC0015_REG0010()
        {
            try
            {
                Reports.TestDescription = "SalesRep - (Verify the sales rep details in employee search - email and fax).";
                #region Data

                #endregion

                #region Login to ADM side with superuser credentials
                ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Office Level.
                Reports.TestStep = "Navigate to Office Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                Reports.TestStep = "Select QA Automation Region.";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedOfficeBUID);
                #endregion

                #region Search an employee and click on Edit.
                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.LeftNavigation.Navigate<EmployeeSearch>(@"Home>System Maintenance>Employee Setup").WaitForScreenToLoad();
                FastDriver.EmployeeSearch.Office.FASelectItemByIndex(0);
                FastDriver.EmployeeSearch.FirstName.FASetText("FAST");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction("#2", "FAST QA04", "#2", TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Enter the Employee Setup Email and fax details";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                FastDriver.EmployeeSetup.EmailTypeEmailID.FASetText("qa04fast@firstam.com");
                FastDriver.EmployeeSetup.BusinessFaxNumber.FASetText("(714)800-1570");
                FastDriver.EmployeeSetup.HomeFaxTypeNumber.FASetText("(714)800-1570");
                FastDriver.BottomFrame.Done();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.Office.FASelectItemByIndex(0);
                FastDriver.EmployeeSearch.FirstName.FASetText("FAST");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction("#2", "FAST QA05", "#2", TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Enter the Employee Setup Email and fax details";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                FastDriver.EmployeeSetup.EmailTypeEmailID.FASetText("qa05fast@firstam.com");
                FastDriver.EmployeeSetup.BusinessFaxNumber.FASetText("(222)222-2222");
                FastDriver.EmployeeSetup.HomeFaxTypeNumber.FASetText("(222)222-2222");
                FastDriver.BottomFrame.Done();
                #endregion

                #region  Login to IIS side
                IISLOGIN();
                #endregion

                #region Create Order and save the data from FHP.
                Reports.TestStep = "Create File using web service.";
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        SaleRep1Name = "QA04, FAST",
                        SaleRep2Name = "QA05, FAST",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DIRECTEDBY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                var FileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Navigate to file balance summary screen _ Email Delivery
                Reports.TestStep = "Navigate to file balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();
                FastDriver.EscrowFileBalanceSummary.Method("Email");
                FastDriver.EscrowFileBalanceSummary.Deliver();

                Reports.TestStep = "Click on To button in email dialog.";
                FastDriver.EmailDlg.WaitForScreenToLoad();
                Keyboard.SendKeys("%T");

                Reports.TestStep = "Validate the display of SalesRep1 and SalesRep2 in Employee search dialog";
                FastDriver.EmailSearchDlg.WaitForScreenToLoad();
                FastDriver.EmailSearchDlg.EmployeeSearchRadio.FASetCheckbox(true);
                FastDriver.EmailSearchDlg.firstName.FASetText("Fast");
                FastDriver.EmailSearchDlg.FindNow.FAClick();
                FastDriver.EmailSearchDlg.WaitForResultsToLoad();
                FastDriver.EmailSearchDlg.FileAddressBookTable.PerformTableAction("Email", "qa04fast@firstam.com", "#1", TableAction.On);
                FastDriver.EmailSearchDlg.FileAddressBookTable.PerformTableAction("Email", "qa04fast@firstam.com", "#1", TableAction.On);
                FastDriver.EmailSearchDlg.Finished.FAClick();
                FastDriver.EmailDlg.WaitForScreenToLoad();
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                #endregion

                #region Navigate to file balance summary screen _ Fax Delivery
                Reports.TestStep = "Navigate to file balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();
                FastDriver.EscrowFileBalanceSummary.Method("Fax");
                FastDriver.EscrowFileBalanceSummary.Deliver();

                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Frombutton.FAClick();

                Reports.TestStep = "Click on employee search and findnow button.";
                FastDriver.SearchPageDlg.WaitForScreenToLoad();
                FastDriver.SearchPageDlg.EmployeeSearchAddressBook.FASetCheckbox(true);
                FastDriver.SearchPageDlg.firstName.FASetText("Fast");
                FastDriver.SearchPageDlg.FindNow.FAClick();
                FastDriver.SearchPageDlg.WaitForResultsToLoad();
                FastDriver.SearchPageDlg.SearchResults.PerformTableAction("Name", "FAST QA05", "#1", TableAction.On);
                FastDriver.SearchPageDlg.Finished.FAClick();

                Reports.TestStep = "Perform FAX delivery.";
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Insert.FAClick();
                FastDriver.FaxDlg.Name.FASetText("QA");
                FastDriver.FaxDlg.Attn.FASetText("1");
                FastDriver.FaxDlg.FAXNumber.FASetText(AutoConfig.DeliverFaxTo);
                FastDriver.FaxDlg.FAX.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 200);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }
        }
        #endregion

        #endregion REG

        #region Private Methods

        private void EnterFeeInTitleEscrowTab()
        {
            Reports.TestStep = "Enter first fee in Title and escrow.";
            FastDriver.FileFees.Open();
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99");
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99");
        }


        private void IISLOGIN(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }

        #endregion PrivateMethods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
