﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects;
using FASTWCFHelpers.FastFileService;


namespace FileManagement
{
    /// <summary>
    /// Summary description for FMUC0005_Seller
    /// </summary>
    [CodedUITest]
    public class FMUC0005_Seller : MasterTestClass
    {

        #region BAT
        
        [TestMethod]
        public void FMUC0005S_Seller_BAT0001_2_3()
        {
            try
            {

                Reports.TestDescription = "MF1: Create Individual Seller. AF11_AF4: 1.View or Modify Seller SSN/TIN data 2.Edit Non-Sensitive Seller Information for any Seller Type.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
                
                Reports.TestStep = "Enter Seller details for Individual type.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText("SellerMiddleName");
                FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText("sufix");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName.FASetText("Sellersign");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem("a single man");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem("as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText("Additional Vesting");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate for Seller details for individual.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Equals("SellerName"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue().Equals("SellerMiddleName"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Equals("SellerLastName"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue().Equals("sufix"), "Verifying seller details");
                FastDriver.BuyerSellerSetup.btnViewEdit.FAClick();
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.txtSSN.FAGetValue().Equals("123-45-6789"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MaritalStatus.FAGetSelectedItem().Equals("a single man"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Vesting.FAGetSelectedItem().Equals("as community property"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue().Equals("Additional Vesting"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue().Equals("Misc Ref 1"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue().Equals("Misc Ref 2"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetInputValue).Message.Clean().Equals("(991)889-8383"), "Verifying seller details");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingPhonesTable.PerformTableAction(1, 2, TableAction.GetInputValue).Message.Clean().Equals("(991)889-8383"), "Verifying seller details");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the contact name in Seller summary screen.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean().Equals("Sellersign"), "Verifying Contact Name");

                Reports.TestStep = "Validate the exchange company in Seller summary screen.";
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 7, TableAction.GetText).Message.Clean().Equals("Exchange Company1 Name 1"), "Verifying Contact Name");

                Reports.TestStep = "Verifying for[SSN/TIN View] Event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.SelectEventCategory("Accounting/Privacy");
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[SSN/TIN View]");
                FastDriver.EventTrackingLog.VerifyEventTableData(2, 1, "[SSN/TIN Edit]");

                Reports.TestStep = "Change SSN number.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnViewEdit.FAClick();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("413-45-6759");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for[SSN/TIN View] Event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.SelectEventCategory("Accounting/Privacy");
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[SSN/TIN Edit]");
                FastDriver.EventTrackingLog.VerifyEventTableData(2, 1, "[SSN/TIN View]");

                Reports.TestStep = "Set current address to other and set values to forward and current address.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("1 Main St");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Alameda");
                FastDriver.BuyerSellerSetup.ForwardingSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText("1 Main St");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Alameda");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");

                Reports.TestStep = "Enter AKA name for buyer individual.";
                FastDriver.BuyerSellerSetup.btnAKA.FAClick();
                FastDriver.AKANames.WaitForScreenToLoad();
                FastDriver.AKANames.AKANew.FAClick();
                FastDriver.AKANames.WaitForScreenToLoad(FastDriver.AKANames.AKA);
                FastDriver.AKANames.AKATable.PerformTableAction(2, 1, TableAction.SetText, "Binfo");
                FastDriver.AKANames.AKATable.PerformTableAction(2, 2, TableAction.On);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0004()
        {
            try
            {
                
                Reports.TestDescription = "AF1: Create Husband/Wife Seller.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create Seller of type Husband/Wife.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.HusbandSpouseSuffix);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Seller Husband First");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("Seller Husband Last");
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.Click();
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Wife First");
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem("married spouses");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem("as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText("Additional Vesting");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");
                FastDriver.BuyerSellerSetup.Salutation.FASetText("Mr. and Mrs. Seller Husband Last");
                FastDriver.BuyerSellerSetup.HusbandSpous1SSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.HusbandAuthorizeddrop.FAClick();
                FastDriver.BuyerSellerSetup.HusbandAuthorizedSignatureName.FASetText("HSSign");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "validate Seller with Husband and Wife Type full details.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue().Equals("Seller Husband First"), "Verifying spouse's last name");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.HusbandLastName.FAGetValue().Equals("Seller Husband Last"), "Verifying spouse's last name");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue().Equals("Wife First"), "Verifying spouse's last name");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue().Equals("Seller Husband Last"), "Verifying spouse's last name");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Salutation.FAGetValue().Equals("Mr. and Mrs. Seller Husband Last"), "Verifying marital status");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MaritalStatus.FAGetSelectedItem().Equals("married spouses"), "Verifying marital status");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Vesting.FAGetSelectedItem().Equals("as community property"), "Verifying vesting");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the exchange company in Seller summary screen.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 7, TableAction.GetText).Message.Clean().Equals("Exchange Company1 Name 1"), "Verifying Contact Name");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0005()
        {
            try
            {
                
                Reports.TestDescription = "AF2_AF12: 1.Create Trust/Estate Seller 2.Additional Role Seller Type is Trust /Estate.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create Seller of type Trust/Estate.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("trust");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Seller Trust Name");
                FastDriver.BuyerSellerSetup.TrustDated.FASetText("07-10-2012");
                FastDriver.BuyerSellerSetup.TrustNumber.FASetText("12345678");
                FastDriver.BuyerSellerSetup.TrustTIN.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("12-3124231");
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrustAuthorizedName.FASetText("Trust");
                FastDriver.BuyerSellerSetup.TrustAuthorizedType.FASelectItem("Other");
                FastDriver.BuyerSellerSetup.TrustApply.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Seller Trustee or Estate with all details.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 7, TableAction.GetText).Message.Clean().Equals("Exchange Company1 Name 1"), "Verifying Contact Name");

                Reports.TestStep = "Validate Seller Trustee or Estate with all details.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 7, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue().Equals("Seller Trust Name"), "Verifying Trust/Estate info");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.TrustDated.FAGetValue().Equals("07-10-2012"), "Verifying Trust/Estate info");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.TrustNumber.FAGetValue().Equals("12345678"), "Verifying Trust/Estate info");

                Reports.TestStep = "Attorney in Fact' Unavailable for Trust/Estate Buyer/Seller";
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrustAuthorizedName);
                Support.AreEqual(false, FastDriver.BuyerSellerSetup.TrustAuthorizedType.FAGetAllTextFromSelect(", ").Contains("Attorney in fact"), "Attorney in Fact should not be listed");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0006()
        {
            try
            {

                Reports.TestDescription = "AF3_AF13: 1. Create Business Entity Seller2.Additional Role Seller Type is Business Entity.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create Seller of type Business Entity.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("business");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.BusinessEntityShortname);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Seller Short Name");
                FastDriver.BuyerSellerSetup.StateofIncorp.FASelectItem("Alaska");
                FastDriver.BuyerSellerSetup.EntityType.FASelectItem("Business Trust");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("53-4553543");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Seller Business Entity and enter all details.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 7, TableAction.GetText).Message.Clean().Equals("Exchange Company1 Name 1"), "Verifying Contact Name");

                Reports.TestStep = "Validate Seller Trustee or Estate with all details.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 7, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAGetValue().Equals("Seller Short Name"), "Verifying Business Entity info");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.StateofIncorp.FAGetSelectedItem().Equals("Alaska"), "Verifying Business Entity info");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.EntityType.FAGetSelectedItem().Equals("Business Trust"), "Verifying Business Entity info");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0007()
        {
            try
            {
                
                Reports.TestDescription = "AF5_01: Change Seller Type from Individual to Husband/Wife: On disbursement.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);

                Reports.TestStep = "Change the type from Individual to Husband and wife.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");

                Reports.TestStep = "Error/Warning#5 AF5_01 : Validate the message on change buyer type and click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0008_9()
        {
            try
            {
                
                Reports.TestDescription = "AF5_02: Change Seller Type from Individual to Husband/Wife: without Disbursement.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Change the type from Individual to Husband and wife.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");

                Reports.TestStep = "Error/Warning#5 AF5_01 : Validate the message on change buyer type and click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that Individual has been changed to Husband/Wife.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean().Equals("Husband/Wife"), "Verifying that Buyer/Seller type has changed");
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();

                Reports.TestStep = "Change from Husband wife to Individual.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");

                Reports.TestStep = "Validate warning message is as per EWC#1 and Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Validate warning message is as per EWC#4 and Click on Ok button";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that Husband wife is changed to Individual.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean().Equals("Individual"), "Verifying that Buyer/Seller type has changed");
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0010()
        {
            try
            {


                Reports.TestDescription = "AF6_02: Change Seller Type from Husband/Wife to Individual: On disbursement.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Change the type from Individual to Husband and wife.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);

                Reports.TestStep = "Change the type from Individual to Husband and wife.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");

                Reports.TestStep = "Validate the message on change buyer type and click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0011()
        {
            try
            {
                
                Reports.TestDescription = "AF7: Change Seller Type from Individual to Trust/Estate or Business Entity.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Change from Individual to Trust.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");

                Reports.TestStep = "Validate the message on change buyer type and click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that Individual has been changed to Husband/Wife.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean().Equals("Trust/Estate"), "Verifying that Buyer/Seller type has changed");
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();

                Reports.TestStep = "Change from Trust to Individual.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("SellerName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("SellerLastname");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);

                Reports.TestStep = "Change the type from Individual to Husband and wife.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");

                Reports.TestStep = "Validate the message on change buyer type and click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0012()
        {
            try
            {


                Reports.TestDescription = "AF8: Clear Seller.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "1.Navigate to Seller summary screen.2. delete an instance.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0013()
        {
            try
            {

                Reports.TestDescription = "AF9: Modify Address for Country other than USA or Canada.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create an instance with different Country other than USA and Canada.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("SellerName");
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText("SellerMiddleName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("SellerLastname");
                FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText("sufix");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName.FASetText("Sellersign");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem("a single man");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem("as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText("Additional Vesting");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                Playback.Wait(2000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("1 Main St");
                FastDriver.BuyerSellerSetup.CurrentCountry.FASelectItem("ALBANIA");

                Reports.TestStep = "Validate that property fields are disabled on select other country.";
                Support.AreEqual("true", FastDriver.BuyerSellerSetup.CurrentCity.FAGetAttribute("disabled").ToString(), "Verifying field is disabled.");
                Support.AreEqual("true", FastDriver.BuyerSellerSetup.CurrentState.FAGetAttribute("disabled").ToString(), "Verifying field is disabled.");
                Support.AreEqual("true", FastDriver.BuyerSellerSetup.CurrentZip.FAGetAttribute("disabled").ToString(), "Verifying field is disabled.");
                Support.AreEqual("true", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetAttribute("disabled").ToString(), "Verifying field is disabled.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0005S_Seller_BAT0014()
        {
            try
            {
                Reports.TestDescription = "AF10: Full Vesting.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Validate the Full vest details before edit.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerVesting.Names.FAGetValue().Equals("SellerName SellerLastName"), "Verifying vesting");
                Support.AreEqual(true, FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Equals("SellerName SellerLastName"), "Verifying vesting");

                Reports.TestStep = "Enter Full vest details.";
                FastDriver.BuyerVesting.Names.FASetText("Edited Name in Vesting screen");
                FastDriver.BuyerVesting.CompleteVesting.FASetText("Edited Complete vesting in Vesting screen");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Full vest details before edit.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerVesting.Names.FAGetValue().Equals("Edited Name in Vesting screen"), "Verifying vesting");
                Support.AreEqual(true, FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Equals("Edited Complete vesting in Vesting screen"), "Verifying vesting");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


    

        #endregion

        #region REG
        [TestMethod]
        public void FMUC0005S_REG0001_2_3()
        {
            try
            {

                Reports.TestDescription = "BR_FM324_1972_EW1_607_325_604_2905, BR_FM770_2907_2070_334_627_628_608 & BR_FM4209_339_EW3_EW2_605: Mandatory Information. Indicate Buyer or Seller 3.Indicate Buyer/Seller Type. Add, Edit, Delete, View info. Validate all functionality related to Trust entity";
                Reports.TestStep = "Log into FAST application. & create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create Seller of type Individual.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

                Reports.TestStep = "Validate that default type is individual.";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem().Contains("Individual").ToString(), "Verifying default Buyer Type selection");

                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("TestFN");
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText("TestMN");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("TestMN");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();

                Reports.TestStep = "Create Seller with Husband and Wife Type.";
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");

                Reports.TestStep = "Validate error/Warning for mandatory data EWC#1 when Last name for both Husband and wife is not present";
                Reports.TestStep = "Enter suffix";
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.HusbandSpouseSuffix);
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FASetText("Suffix");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerSellerError.FAGetText().Contains("LastName: FirstName or LastName is Required.").ToString(), "Validating error message.");

                Reports.TestStep = "FM2118  Default Spouse Last Name on Sellers screen";
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Seller Husband First");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("Seller Husband Last");
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.Click();
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Wife First");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue().Contains("Seller Husband Last").ToString(), "Verifying spouse's last name");

                Reports.TestStep = "Enter exchange company details";
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.FindGAB(gabcode: "EXCH02");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Seller Trustee or Estate and validate the data.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Seller Trust Name");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.FindGAB(gabcode: "EXCH02");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(5, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue().Contains("Seller Trust Name").ToString(), "Validating Trustee Name");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Seller Business Entity.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.BusinessEntityShortname);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Seller BusEntity Name");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("23-6598235");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.FindGAB(gabcode: "EXCH02");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate exchange company for Business Entity in summary screen.";
                Support.AreEqual("True", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(6, 7, TableAction.GetText).Message.Clean().Contains("Exchange Company2 Name 1").ToString(), "Validating Exchange Company");

                Reports.TestStep = "save Changes without Bus Party.";
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.BusinessEntityShortname);
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem("E-Mail");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                //Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerSellerError.FAGetText().Contains("Business Entity: A business entity name must be entered").ToString(), "Validating error message.");
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Delete a seller instance.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(6, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the exchange company in Seller summary screen.";
                Support.AreEqual("True", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(6, 7, TableAction.GetText).Message.Clean().Contains("Exchange Company2 Name 1").ToString(), "Validating Exchange Company");

                Reports.TestStep = "Validate that on issue a disbursement exchange company cannot be deleted.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                Support.AreEqual("True", FastDriver.ExchangeCompany.Find.IsEnabled().ToString(), "Validating Find button status");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual("True", FastDriver.BottomFrame.btnDelete.IsEnabled().ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change the type from Husband and wife to Trust.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("T");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change the 1099s details for a seller instance.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("H");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.HusbandSpous1SSN.FASetText("434-44-2342");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change the 1099s clarification to N/A.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.HusbandwifeSSNType.FASelectItem("N/A");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the buyer as Husband and wife in summary screen.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                Support.AreEqual("True", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Contains("SellerLastName / SellerLastName").ToString(), "Validating Husband & Wife");

                //Reports.TestStep = "Navigate to Seller screen and click on Edit.";
                //FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);

                Reports.TestStep = "Create Seller Trustee or Estate and enter all details.";
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrustDated);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Seller Trust Name");
                FastDriver.BuyerSellerSetup.TrustDated.FASetText("07-10-2012");
                FastDriver.BuyerSellerSetup.TrustNumber.FASetText("12345678");
                FastDriver.BuyerSellerSetup.TrustTIN.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("12-3124231");
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrustAuthorizedName);
                FastDriver.BuyerSellerSetup.TrustAuthorizedName.FASetText("Trust");
                FastDriver.BuyerSellerSetup.TrustAuthorizedType.FASelectItem("Other");
                FastDriver.BuyerSellerSetup.TrustApply.FAClick();
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Full vest details.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("Edited Name in Vesting Screen");
                FastDriver.BuyerVesting.CompleteVesting.FASetText("Edited Complete Vesting in Vesting screen");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Seller Trustee or Estate with all details.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(7, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem().Contains("Trust/Estate").ToString(), "Verifying Buyer/Seller Type");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue().Contains("Seller Trust Name").ToString(), "Verifying Shortname Entry");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrustDated.FAGetValue().Contains("07-10-2012").ToString(), "Verifying Trust Dated");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrustNumber.FAGetValue().Contains("12345678").ToString(), "Verifying Trust Number");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate first phone type as Home and second as Business for buyer as Individual.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem().Contains("Home Phone").ToString(), "Verifying Selection");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem().Contains("Business Phone").ToString(), "Verifying Selection");

                Reports.TestStep = "Validate that Set to current is disabled in forward address when set to property is selected in Current Address.";
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentStreet1.IsEnabled().ToString(), "Verifying field state.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentStreet2.IsEnabled().ToString(), "Verifying field state.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentStreet3.IsEnabled().ToString(), "Verifying field state.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentCity.IsEnabled().ToString(), "Verifying field state.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentState.IsEnabled().ToString(), "Verifying field state.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentZip.IsEnabled().ToString(), "Verifying field state.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentCounty.IsEnabled().ToString(), "Verifying field state.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.ForwardingSetToCurrent.IsEnabled().ToString(), "Verifying field state.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate error/Warning for mandatory data";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(5, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.TrusteeShortName.Clear();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerSellerError.FAGetText().Contains("Trust Name is Required!").ToString(), "Verifying error message.");
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Seller Trust Name");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_FM768: Default max char Short Name-Expected failure.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create Seller of type Trust/Estate.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur." + FAKeys.Tab);

                Reports.TestStep = "Validate that the first eighty is present in trust short name";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem().Contains("Trust/Estate").ToString(), "Verifying selection.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue().Length.Equals(80).ToString(), "Verifying character count.");

                Reports.TestStep = "FM609 - Change from SSN to TIN";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrustSSN.IsSelected().ToString(), "Verifying option is selected.");
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("111111111" + FAKeys.Tab);
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrustSSNtext.FAGetValue().Contains("111-11-1111").ToString(), "Verifying if value was formatted.");
                FastDriver.BuyerSellerSetup.TrustTIN.FASetCheckbox(true);
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrustSSNtext.FAGetValue().Contains("11-1111111").ToString(), "Verifying if value was formatted.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter more than 80 character in Business entity and tab out";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.BusinessEntityName);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur." + FAKeys.Tab);

                Reports.TestStep = "Validate that the first forty is present in Business entity short name";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem().Contains("Business Entity").ToString(), "Verifying selection.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAGetValue().Length.Equals(80).ToString(), "Verifying character count.");

                Reports.TestStep = "FM609 - Change from SSN to TIN";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BusinessEntyTinRadButtn.IsSelected().ToString(), "Verifying option is selected.");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("111111111" + FAKeys.Tab);
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue().Contains("11-1111111").ToString(), "Verifying if value was formatted.");
                FastDriver.BuyerSellerSetup.BusinessEntySsnRadButtn.FASetCheckbox(true);
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue().Contains("111-11-1111").ToString(), "Verifying if value was formatted.");
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0005()
        {
            try
            {
                Reports.TestDescription = "BR_FM2909_2911_2913_2915_2914_335_621_620: Validate all functionality related to business entity- EXPECTED FAILURE in current phone type.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create Buyer Business Entity and enter all details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.BusinessEntityName);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Seller BusEntity Name");
                FastDriver.BuyerSellerSetup.StateofIncorp.FASelectItem("Alaska");
                FastDriver.BuyerSellerSetup.EntityType.FASelectItem("Business Trust");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("53-4553543");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Full vest details.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("Edited Name in Vesting Screen");
                FastDriver.BuyerVesting.CompleteVesting.FASetText("Edited Complete vesint in Vesting screen");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Buyer Business Entity and enter all details.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem().Contains("Business Entity").ToString(), "Verifying selection.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAGetValue().Contains("Seller BusEntity Name").ToString(), "Verifying shortname.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.StateofIncorp.FAGetSelectedItem().Contains("Alaska").ToString(), "Verifying selection.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.EntityType.FAGetSelectedItem().Contains("Business Trust").ToString(), "Verifying selection.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter more than 80 characters to Trust Estate name.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur." + FAKeys.Tab);

                Reports.TestStep = "Validate that Default max char Short Name.";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue().Length.Equals(80).ToString(), "Verifying character count.");

                Reports.TestStep = "Validate that trust Estate name is preserved.";
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Edit trust shortname");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.TrusteeName.FAGetValue().Contains("Edit trust shortname").ToString(), "Verifying shortname.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate first phone type as Home and second as Business for seller as Trust Estate.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem().Contains("Home Phone").ToString(), "Verifying Selection");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem().Contains("Business Phone").ToString(), "Verifying Selection");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Buyer Business Entity and enter all details.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur." + FAKeys.Tab);

                Reports.TestStep = "Validate first phone type as Business and second as Business Fax for seller as Business Entity.";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem().Contains("Business Phone").ToString(), "Verifying Selection");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem().Contains("Business Fax").ToString(), "Verifying Selection");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate error/Warning for mandatory data for Business Entity";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAClick();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.Clear();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerSellerError.FAGetText().Contains("Business Entity: A business entity name must be entered").ToString(), "Validating error message.");
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Seller BusEntity Name");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR_622_4290_4291: Entity Authorized Signature.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create Buyer Business Entity and enter all details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.BusinessEntityName);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.");
                
                Reports.TestStep = "Enter authorized signature for Business Entity.";
                FastDriver.BuyerSellerSetup.Signatures.FAClick();
                FastDriver.BuyerSellerEntitySignatures.WaitForScreenToLoad();
                FastDriver.BuyerSellerEntitySignatures.NameofEntity.FASetText("Business Entity");
                FastDriver.BuyerSellerEntitySignatures.StateOfIncorp.FASelectItem("Alaska");
                FastDriver.BuyerSellerEntitySignatures.Entitytype.FASelectItem("Business Trust");
                FastDriver.BuyerSellerEntitySignatures.NewAuthorized.FAClick();
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FASetText("Business Authorized Signature");
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FASetText("Corp Title");
                FastDriver.BuyerSellerEntitySignatures.NewNameofEntity.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByNameOfEntity.FASetText("Entity Name");
                FastDriver.BuyerSellerEntitySignatures.ByStateOfIncorp.FASelectItem("Alaska");
                FastDriver.BuyerSellerEntitySignatures.ByEntityType.FASelectItem("Business Trust");
                FastDriver.BuyerSellerEntitySignatures.ByContactName.FASetText("Contact Name");
                FastDriver.BuyerSellerEntitySignatures.ApplyNameofEntity.FAClick();
                FastDriver.BuyerSellerEntitySignatures.NewAuthorizedSignature.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FASetText("Entity Authorized Signature Name");
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FASetText("Entity Authorized Signature Name Title Corp");

                Reports.TestStep = "Validate the data entered as authorized signature for Business Entity.";
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.NameofEntity.FAGetValue().Contains("Business Entity").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.StateOfIncorp.FAGetSelectedItem().Contains("Alaska").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.Entitytype.FAGetSelectedItem().Contains("Business Trust").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FAGetValue().Contains("Business Authorized Signature").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FAGetValue().Contains("Corp Title").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.ByNameOfEntity.FAGetValue().Contains("Entity Name").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.ByStateOfIncorp.FAGetSelectedItem().Contains("Alaska").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.ByEntityType.FAGetSelectedItem().Contains("Business Trust").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.ByContactName.FAGetValue().Contains("Contact Name").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FAGetValue().Contains("Entity Authorized Signature Name").ToString(), "Verifying value matches.");
                Support.AreEqual("True", FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FAGetValue().Contains("Entity Authorized Signature Name Title Corp").ToString(), "Verifying value matches.");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0007()
        {
            try
            {
                Reports.TestDescription = "BR_5155_5156: Prevent deletion or changing of Seller type once issued.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #region Data Setup
                var deposit = new DepositParameters()
                {
                    Amount = 6000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "FMUC0005 Seller Deposit in Escrow",
                    ReceivedFrom = "Seller"
                };
                #endregion  

                Reports.TestStep = "Deposit a cash more than sales price.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);

                Reports.TestStep = "Navigate to Buyer summary screen and delete an instance.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();

                Reports.TestStep = "Chang the type from Individual to Husband and wife.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("husband");

                Reports.TestStep = "Delete a buyer seller instance when disbursement is issued.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Buyer Individual and validate the data.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText("sufix");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate error/Warning for mandatory data";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BuyerSellerError.FAGetText().Contains("LastName: FirstName or LastName is Required.").ToString(), "Validating error message and warning.");
                FastDriver.BottomFrame.Cancel();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0008()
        {
            try
            {
                
                Reports.TestDescription = "BR_FM1985_330_337_338_8060: Validate the vesting and spell check functionality.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter vesting information in Title Production tab.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertyTaxSummary.PropertiesSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.ClickTitleProdTab();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionVesting.FASetText("BuyerVesting");
                FastDriver.PropertyTaxInfoTitleProd.ExceptionRequestInformationSave.FAClick();

                Reports.TestStep = "Validate the Full vest details before edit.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetValue().Contains("SellerName SellerLastName").ToString(), "Verifying data in Names field");
                Support.AreEqual("True", FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Contains("SellerName SellerLastName").ToString(), "Verifying data in Names field");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Full vest details.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("Edited Name in Vesting Screen.");
                FastDriver.BuyerVesting.CompleteVesting.FASetText("Edited Complete vesting in Vesting screen.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Full vest details after edit.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetValue().Contains("Edited Name in Vesting Screen.").ToString(), "Verifying data in Names field");
                Support.AreEqual("True", FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Contains("Edited Complete vesting in Vesting screen.").ToString(), "Verifying data in Names field");

                Reports.TestStep = "Click on Copy Title Vest button in vest screen.";
                FastDriver.BuyerVesting.CopyTitleVesting.FAClick();

                Reports.TestStep = "Validate that vesting information is same as that of Title production.";
                FastDriver.TitleVestingDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.TitleVestingDlg.TitleVesting.FAGetValue().Contains("BuyerVesting").ToString(), "Verifying vesting");
                FastDriver.TitleVestingDlg.Done.FAClick();

                Reports.TestStep = "Validate the Vest information appears as from Copy Title Vest.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Contains("BuyerVesting").ToString(), "Verifying data in Names field");

                Reports.TestStep = "Check the Spelling.";
                FastDriver.BuyerVesting.Names.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.SpellingErrorDlg.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDlg.Change.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the spell check functionality for Name Spelling.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetValue().Contains("Spelling").ToString(), "Verifying misspelling fix.");

                Reports.TestStep = "Verify the spell check functionality for Complete vesting";
                FastDriver.BuyerVesting.CompleteVesting.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingCompVest.FAClick();

                Reports.TestStep = "Check the Spelling.";
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.SpellingErrorDlg.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDlg.Change.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Contains("Spelling").ToString(), "Verifying misspelling fix.");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Buyer Business Entity and enter all details.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.BusinessEntityName);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Seller BusEntity Name");
                FastDriver.BuyerSellerSetup.StateofIncorp.FASelectItem("Alaska");
                FastDriver.BuyerSellerSetup.EntityType.FASelectItem("Business Trust");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("53-4553543");

                Reports.TestStep = "Verify the spell check functionality for Name Spelling.";
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.SpellingErrorDlg.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDlg.Change.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the spell check functionality for Name Spelling.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetValue().Contains("Spelling").ToString(), "Verifying misspelling fix.");

                Reports.TestStep = "Verify the spell check functionality for Complete vesting";
                FastDriver.BuyerVesting.CompleteVesting.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingCompVest.FAClick();

                Reports.TestStep = "Check the Spelling.";
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.SpellingErrorDlg.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDlg.Change.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Contains("Spelling").ToString(), "Verifying misspelling fix.");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Seller of type Trust/Estate.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Lorem ipsum dolor sit amet");

                Reports.TestStep = "Verify the spell check functionality for Name Spelling.";
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.SpellingErrorDlg.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDlg.Change.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the spell check functionality for Name Spelling.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetValue().Contains("Spelling").ToString(), "Verifying misspelling fix.");

                Reports.TestStep = "Verify the spell check functionality for Complete vesting";
                FastDriver.BuyerVesting.CompleteVesting.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingCompVest.FAClick();

                Reports.TestStep = "Check the Spelling.";
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.SpellingErrorDlg.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDlg.Change.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Contains("Spelling").ToString(), "Verifying misspelling fix.");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Seller of type Husband/Wife.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("husband");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.Husband1FirstName);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Seller Husband First");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("Seller Husband Last");
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.Click();
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Wife First");

                Reports.TestStep = "Verify the spell check functionality for Name Spelling.";
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.Names.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.SpellingErrorDlg.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDlg.Change.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the spell check functionality for Name Spelling.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.Names.FAGetValue().Contains("Spelling").ToString(), "Verifying misspelling fix.");

                Reports.TestStep = "Verify the spell check functionality for Complete vesting";
                FastDriver.BuyerVesting.CompleteVesting.FASetText("Speling");
                FastDriver.BuyerVesting.CheckSpellingCompVest.FAClick();

                Reports.TestStep = "Check the Spelling.";
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.SpellingErrorDlg.SuggestedWords.FASelectItem("Spelling");
                FastDriver.SpellingErrorDlg.Change.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.SpellingErrorDlg.WaitForScreeToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the spell check functionality.";
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Contains("Spelling").ToString(), "Verifying misspelling fix.");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0009()
        {
            try
            {
                Reports.TestDescription = "BR_FM331_332_333_603_765_766: Validate the marital status and salutation functionality.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Sellers and edit.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                
                Reports.TestStep = "Validate the marital status options";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MaritalStatus.IsEnabled().ToString(), "Verifying Marital Status field");
                string maritalStatus = FastDriver.BuyerSellerSetup.MaritalStatus.FAGetAllTextFromSelect(separator: ", ");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MaritalStatus.FAGetAllTextFromSelect(separator: ", ").Contains(maritalStatus).ToString(), "Verifying options in Marital Status.");

                Reports.TestStep = "Validate Vesting options";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MaritalStatus.IsEnabled().ToString(), "Verifying Vesting field");
                string vesting = FastDriver.BuyerSellerSetup.Vesting.FAGetAllTextFromSelect(separator: ", ");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Vesting.FAGetAllTextFromSelect(separator: ", ").Contains(vesting).ToString(), "Verifying options in Vesting");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Seller of type Husband/Wife.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.HusbandSpouseSuffix);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Seller Husband First");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("Seller Husband Last");
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.Click();
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Wife First");

                Reports.TestStep = "Validate the marital status options";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MaritalStatus.IsEnabled().ToString(), "Verifying Marital Status field");
                maritalStatus = FastDriver.BuyerSellerSetup.MaritalStatus.FAGetAllTextFromSelect(separator: ", ");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MaritalStatus.FAGetAllTextFromSelect(separator: ", ").Contains(maritalStatus).ToString(), "Verifying options in Marital Status.");

                Reports.TestStep = "Validate Vesting options";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MaritalStatus.IsEnabled().ToString(), "Verifying Vesting field");
                vesting = FastDriver.BuyerSellerSetup.Vesting.FAGetAllTextFromSelect(separator: ", ");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Vesting.FAGetAllTextFromSelect(separator: ", ").Contains(vesting).ToString(), "Verifying options in Vesting");

                Reports.TestStep = "Validate populated salutation for Husband/Wife";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Salutation.IsEnabled().ToString(), "Verifying Salutation field");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Salutation.FAGetValue().Contains("Dear Mr. & Mrs.").ToString(), "Verifying salutation for Husband/Wife");
                FastDriver.BottomFrame.Done();


            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0005S_REG0010()
        {
            try
            {
                Reports.TestDescription = "BR_FM602_601_600_2120_610_598_FM6565: Phone Information, Salutation and misc reference number.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Sellers and edit Individual Seller entry.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

                Reports.TestStep = "FM601: Show Individual 1st # as Home";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem().Contains("Home Phone").ToString(), "Verifying Phone Type selection for Individual.");
                
                Reports.TestStep = "FM2120: Current and Forwarding phone";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneNumber.IsEnabled().ToString(), "Verifying Current Phone status.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingPhoneNum.IsEnabled().ToString(), "Verifying Forwarding Phone status.");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");

                Reports.TestStep = "FM598: Enter Misc Reference Numbers";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MiscRef1.IsEnabled().ToString(), "Verifying Misc Ref 1 status.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MiscRef2.IsEnabled().ToString(), "Verifying Misc Ref 2 status.");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");

                Reports.TestStep = "FM610: Enter Salutation";
                FastDriver.BuyerSellerSetup.Salutation.FASetText("Mr.");

                Reports.TestStep = "FM6565: Select 1099-S Classification";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetAllTextFromSelect(", ").Contains("1099-S, Certificate of Exempt Status, N/A").ToString(), "Verifying 1099-S Classification options");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Sellers and create a Husband/Wife entry";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.Husband1FirstName);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Seller Husband First");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("Seller Husband Last");
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.Click();
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Wife First");

                Reports.TestStep = "FM601: Show Husband/Wife 1st # as Home";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem().Contains("Home Phone").ToString(), "Verifying Phone Type selection for Husband/Wife.");

                Reports.TestStep = "FM2120: Current and Forwarding phone";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneNumber.IsEnabled().ToString(), "Verifying Current Phone status.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingPhoneNum.IsEnabled().ToString(), "Verifying Forwarding Phone status.");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");

                Reports.TestStep = "FM598: Enter Misc Reference Numbers";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MiscRef1.IsEnabled().ToString(), "Verifying Misc Ref 1 status.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MiscRef2.IsEnabled().ToString(), "Verifying Misc Ref 2 status.");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");

                Reports.TestStep = "FM610: Enter Salutation";
                FastDriver.BuyerSellerSetup.Salutation.FASetText("Mr. and Mrs. Seller Husband Last");

                Reports.TestStep = "FM6565: Select 1099-S Classification";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.HusbandwifeSSNType.FAGetAllTextFromSelect(", ").Contains("1099-S, Certificate of Exempt Status, N/A").ToString(), "Verifying 1099-S Classification options");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.HusbandwifeSSNType2.FAGetAllTextFromSelect(", ").Contains("1099-S, Certificate of Exempt Status, N/A").ToString(), "Verifying 1099-S Classification options");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Sellers and create a Trust/Estate entry";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("trustee");
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Lorem ipsum dolor sit amet");

                Reports.TestStep = "FM601: Show Trustee/Estate 1st # as Home";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem().Contains("Home Phone").ToString(), "Verifying Phone Type selection for Trustee/Estate.");

                Reports.TestStep = "FM2120: Current and Forwarding phone";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneNumber.IsEnabled().ToString(), "Verifying Current Phone status.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingPhoneNum.IsEnabled().ToString(), "Verifying Forwarding Phone status.");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");

                Reports.TestStep = "FM598: Enter Misc Reference Numbers";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MiscRef1.IsEnabled().ToString(), "Verifying Misc Ref 1 status.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MiscRef2.IsEnabled().ToString(), "Verifying Misc Ref 2 status.");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");

                Reports.TestStep = "FM610: Enter Salutation";
                FastDriver.BuyerSellerSetup.Salutation.FASetText("Mr. Trustee");

                Reports.TestStep = "FM6565: Select 1099-S Classification";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.TrustSSNtype.FAGetAllTextFromSelect(", ").Contains("1099-S, Certificate of Exempt Status, N/A").ToString(), "Verifying 1099-S Classification options");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Sellers and create a Business Entity entry";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("business");
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.BusinessEntityShortname);
                //FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.BusinessEntityShortname);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Company Entity");

                Reports.TestStep = "FM601: Show Trustee/Estate 1st # as Home";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem().Contains("Business Phone").ToString(), "Verifying Phone Type selection for Business Entity.");

                Reports.TestStep = "FM2120: Current and Forwarding phone";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneNumber.IsEnabled().ToString(), "Verifying Current Phone status.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingPhoneNum.IsEnabled().ToString(), "Verifying Forwarding Phone status.");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");

                Reports.TestStep = "FM598: Enter Misc Reference Numbers";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MiscRef1.IsEnabled().ToString(), "Verifying Misc Ref 1 status.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.MiscRef2.IsEnabled().ToString(), "Verifying Misc Ref 2 status.");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");

                Reports.TestStep = "FM610: Enter Salutation";
                FastDriver.BuyerSellerSetup.Salutation.FASetText("Mr. Business");

                Reports.TestStep = "FM6565: Select 1099-S Classification";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.BusinessSSNType.FAGetAllTextFromSelect(", ").Contains("1099-S, Certificate of Exempt Status, N/A").ToString(), "Verifying 1099-S Classification options");
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0005S_REG0011()
        {
            try
            {
                Reports.TestDescription = "BR_FM1988_767_342: Property Address Unchanged- EXPECTED FAILURE.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Set current address to other and set values to forward and current address.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("1 Main St");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Alameda");
                FastDriver.BuyerSellerSetup.ForwardingSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText("1 Main St");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Alameda");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");

                Reports.TestStep = "Validate the set to other property reflects in buyer screen.";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Contains(FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Contains(FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue().Contains(FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Contains(FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingSetToOther.IsEnabled().ToString(), "Verifying that field is enabled.");
                FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Property Address Unchanged.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("1 Main St" + FAKeys.Tab);
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Contains(FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue()).ToString(), "Verifying if address changed.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0012()
        {
            try
            {
                Reports.TestDescription = "BR_FM6607_6608_6610_6611_6612_6614_6615_6616_6617_6618_6619_6620_EW8 : Seller screen Address functionality.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Validate that Set to other is set as default and property is linked to seller screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingSetToOther.IsSelected().ToString(), "Verifying field is selected by default.");

                Reports.TestStep = "FM6607: View Property Address Link.";

                Reports.TestStep = "FM6608: System Establishes Property Address Link.";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Equals("1 Main St").ToString(), "Verifying if Current Address fields matches Property Address info");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Equals("ALBANY").ToString(), "Verifying if Current Address fields matches Property Address info");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem().Equals("CA").ToString(), "Verifying if Current Address fields matches Property Address info");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Equals("ALAMEDA").ToString(), "Verifying if Current Address fields matches Property Address info");

                Reports.TestStep = "FM6610: User Establishes Property Address Link";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentSetToProperty.IsVisible().ToString(), "Verifying that Current Set To Property is visible");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentSetToProperty.IsEnabled().ToString(), "Verifying that Current Set To Property is enabled");
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FASetCheckbox(true);
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.CurrentStreet1);

                Reports.TestStep = "FM6611 & FM6614: Disable Seller Address w/ Property Address Link. Replace Values with Property Address";
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentStreet1.IsEnabled().ToString(), "Verifying if Current Address fields becomes read-only.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentCity.IsEnabled().ToString().ToString(), "Verifying if Current Address fields becomes read-only.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentState.IsEnabled().ToString().ToString(), "Verifying if Current Address fields becomes read-only.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentCounty.IsEnabled().ToString().ToString(), "Verifying if Current Address fields becomes read-only.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Equals("1 Main St").ToString(), "Verifying if Current Address fields matches Property Address info");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Equals("ALBANY").ToString(), "Verifying if Current Address fields matches Property Address info");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem().Equals("CA").ToString(), "Verifying if Current Address fields matches Property Address info");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Equals("ALAMEDA").ToString(), "Verifying if Current Address fields matches Property Address info");

                Reports.TestStep = "FM6612: Remove Property Address Link";
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.CurrentStreet1);
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentStreet1.IsEnabled().ToString(), "Verifying if Current Address fields are editable.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCity.IsEnabled().ToString().ToString(), "Verifying if Current Address fields are editable.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentState.IsEnabled().ToString().ToString(), "Verifying if Current Address fields are editable.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCounty.IsEnabled().ToString().ToString(), "Verifying if Current Address fields are editable.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Property Tax Info and update Property Address.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertyTaxSummary.PropertiesSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("32 Second St");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Lakeport");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Lake");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM6614: Replace Values with Property Address.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

                Reports.TestStep = "FM6615: System Updates Seller Address";
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FASetCheckbox(true);
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.CurrentStreet1);
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Equals("32 Second St").ToString(), "Verifying if Current Address fields matches Property Address info");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Equals("Lakeport").ToString(), "Verifying if Current Address fields matches Property Address info");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem().Equals("CA").ToString(), "Verifying if Current Address fields matches Property Address info");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Equals("Lake").ToString(), "Verifying if Current Address fields matches Property Address info");

                Reports.TestStep = "FM6616: View Seller Current Address Link";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Contains(FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue().Contains(FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue().Contains(FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue().Contains(FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue()).ToString(), "Verifying that values match.");

                Reports.TestStep = "Set Current Address to Other";
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.CurrentStreet1);

                Reports.TestStep = "FM6617: Disable Seller Forwarding Address w/ Current Address Link";
                FastDriver.BuyerSellerSetup.ForwardingSetToCurrent.FASetCheckbox(true);
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.CurrentStreet1);
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.ForwardingStreet1.IsEnabled().ToString(), "Verifying if Current Address fields are editable.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.ForwardingCity.IsEnabled().ToString(), "Verifying if Current Address fields are editable.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.ForwardingState.IsEnabled().ToString(), "Verifying if Current Address fields are editable.");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.ForwardingCounty.IsEnabled().ToString(), "Verifying if Current Address fields are editable.");

                Reports.TestStep = "FM6618 & FM6620: System Updates Seller. Forwarding Address Replace Values with Seller Current Address.";
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("1 Main St");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Alameda");
                FastDriver.BuyerSellerSetup.CurrentStreet2.Click();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Contains(FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue().Contains(FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingState.FAGetValue().Contains(FastDriver.BuyerSellerSetup.CurrentState.FAGetValue()).ToString(), "Verifying that values match.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue().Contains(FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue()).ToString(), "Verifying that values match.");

                Reports.TestStep = "FM6619: Remove Seller Current Address Link";
                FastDriver.BuyerSellerSetup.ForwardingSetToOther.FASetCheckbox(true);
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.CurrentStreet1);
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingStreet1.IsEnabled().ToString(), "Verifying if Current Address fields are editable.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingCity.IsEnabled().ToString(), "Verifying if Current Address fields are editable.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingState.IsEnabled().ToString(), "Verifying if Current Address fields are editable.");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardingCounty.IsEnabled().ToString(), "Verifying if Current Address fields are editable.");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0005S_REG0013()
        {
            try
            {
                Reports.TestDescription = "BR_FM341: Adding multiple AKA name.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Sellers and edit Individual Seller entry.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem("a single man");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem("as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText("Additional Vesting");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter AKA name for buyer individual.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnAKA.FAClick();
                FastDriver.AKANames.WaitForScreenToLoad();
                FastDriver.AKANames.AKANew.FAClick();
                FastDriver.AKANames.WaitForScreenToLoad(FastDriver.AKANames.AKA);
                FastDriver.AKANames.AKATable.PerformTableAction(2, 1, TableAction.SetText, "Binfo");
                FastDriver.AKANames.AKATable.PerformTableAction(2, 2, TableAction.On);
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0014()
        {
            try
            {
                Reports.TestDescription = "BR_FM9195_11501_11503_11506_11508_11511: Validate the functionality of IBA beneficiary as Seller.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #region Data Setup
                var deposit = new DepositParameters()
                {
                    Amount = 6000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "FMUC0005 Seller Deposit in Escrow",
                    ReceivedFrom = "Seller"
                };
                #endregion  
                
                Reports.TestStep = "To enter the first property address in Property tax screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertyTaxSummary.PropertiesSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("32 Second St");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Lakeport");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Lake");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deposit a cash more than sales price.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Select Seller as beneficiary.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.SellersTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Prevent add IBA beneficiaries if required values are miss.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Enter seller details for Individual type.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName.FASetText("Sellersign");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem("a single man");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem("as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText("Additional Vesting");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Set current address to other and set values to forward and current address.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ForwardingSetToCurrent.FASetCheckbox(true);
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.CurrentStreet1);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("4 Belt St");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Alameda");
                FastDriver.BuyerSellerSetup.CurrentStreet2.Click();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Select Seller as beneficiary.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.SellersTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter the IBA bank";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab().WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, 4, TableAction.SetText, "10.00");
                FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();

                Reports.TestStep = "1.Navigate to seller summary screen.2. delete an instance.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();

                Reports.TestStep = "Validate that buyer seller instance cannot be removed if it is an IBA beneficiary.";
                FastDriver.WebDriver.HandleDialogMessage();
                
                Reports.TestStep = "Add, edit and view info in the instance.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("413-45-6759");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select reason to change entity  type.";
                FastDriver.ReasonforchangeDlg.WaitForDialogToLoad();
                FastDriver.ReasonforchangeDlg.Change.FASelectItem("Change in Buyer/Seller type");
                FastDriver.ReasonforchangeDlg.OK.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Change the type from Individual to Husband and wife.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("husband");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("individual");
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //Reports.TestStep = "Create Buyer Trustee or Estate.";
                //FastDriver.BuyerSellerSummary.WaitForScreenToLoad(element: FastDriver.BuyerSellerSummary.btnNew);
                //FastDriver.BuyerSellerSummary.btnNew.FAClick();
                //FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                //FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("trust");
                //Playback.Wait(2000);
                //FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                //FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Seller Short Name");
                //FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                //FastDriver.ExchangeCompany.WaitForScrenToLoad();
                //FastDriver.ExchangeCompany.Find.FAClick();

                //Reports.TestStep = "Set an exchange company id from Global address book.";
                //FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                //FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                //FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                //FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                //FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.BottomFrame.Done();
                //FastDriver.BottomFrame.Done();

                //Reports.TestStep = "Select reason to change entity  type.";
                //FastDriver.ReasonforchangeDlg.WaitForDialogToLoad();
                //FastDriver.ReasonforchangeDlg.Change.FASelectItem("Other");
                //FastDriver.ReasonforchangeDlg.OK.FAClick();
                //Playback.Wait(2000);
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0015()
        {
            try
            {

                Reports.TestDescription = "BR_FM9095_9097_9098_9099_9100_9106_9103_9105: Validate the functionality of Exchange company and Authorized signature.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                string fileNum1 = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum1);

                #region Data Setup
                var deposit = new DepositParameters()
                {
                    Amount = 6000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "FMUC0005 Seller Deposit in Escrow",
                    ReceivedFrom = "Seller"
                };
                #endregion  

                Reports.TestStep = "Enter seller details for Individual type.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName.FASetText("Sellersign");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem("a single man");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem("as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText("Additional Vesting");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Seller with Hus and Wife Type full details and validate the data.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("husband");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.Husband1FirstName);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("John");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("Doe");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Jane");
                FastDriver.BuyerSellerSetup.HusbandSpous1SSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.HusbandAuthorizeddrop.FAClick();
                FastDriver.BuyerSellerSetup.HusbandAuthorizedSignatureName.FASetText("HSSign");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Husbandspouse1TrusteeType.FAGetSelectedItem().Equals("Attorney In Fact").ToString(), "Verifying Trustee Type selection");
                FastDriver.BuyerSellerSetup.HusbandApply.FAClick();
                FastDriver.BuyerSellerSetup.Husbandspouse2TrusteeName.FASetText("HSSign2");
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Husbandspouse2TrusteeType.FAGetSelectedItem().Equals("Attorney In Fact").ToString(), "Verifying Trustee Type selection");
                FastDriver.BuyerSellerSetup.HusbandSpouse2Apply.FAClick();
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem("married spouses");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem("as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText("Additional Vesting");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Seller Business Entity.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.BusinessEntityName);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Seller BusEntity Name");
                FastDriver.BuyerSellerSetup.StateofIncorp.FASelectItem("Alaska");
                FastDriver.BuyerSellerSetup.EntityType.FASelectItem("Business Trust");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("53-4553543");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a 2nd order.";
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                string fileNum2 = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum2);

                Reports.TestStep = "Selecting Buyer and seller.";
                FastDriver.LeftNavigation.Navigate<StarterReference>("Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(fileNum1);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.StarterReference.WaitForScreenToLoad();

                Reports.TestStep = "Validate the exchange company in Seller summary screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 7, TableAction.GetText).Message.Clean().Equals("Exchange Company1 Name 1").ToString(), "Verifying Exchange Company Info");
                Support.AreEqual("True", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 7, TableAction.GetText).Message.Clean().Equals("Exchange Company1 Name 1").ToString(), "Verifying Exchange Company Info");
                Support.AreEqual("True", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, 7, TableAction.GetText).Message.Clean().Equals("Exchange Company1 Name 1").ToString(), "Verifying Exchange Company Info");

                Reports.TestStep = "Deposit a cash more than sales price.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Validate that exchange company name appears in Active Disbursement screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 8, TableAction.GetText).Message.Clean().Equals("Exchange Company1 Name 1 Exchange Compan").ToString(), "Verifying Exchange Company Info");

                Reports.TestStep = "Validate the presence of Exchange company name in borrowers name.";
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Escrow Closing>HUD-1 Statement").WaitForScreenToLoad();
                    Support.AreEqual("True", FastDriver.HUD1PrintOptions.SellerName.FAGetText().Contains("Exchange Company1 Name 1").ToString(), "Verifying Exchange Company Info");

                    Reports.TestStep = "Validate in PDF that exchange company name appears.";
                    FastDriver.HUD1PrintOptions.Combined.FASetCheckbox(true);
                    FastDriver.HUD1PrintOptions.SellerOnly.FASetCheckbox(true);
                    FastDriver.HUD1PrintOptions.SellerOnlySignature.FASetCheckbox(true);

                    Reports.TestStep = "Perform Preview delivery.";
                    FastDriver.HUD1PrintOptions.Delivery();
                    FastDriver.PrintDlg.ClickPrint();
                    FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);
                    FastDriver.HUD1PrintOptions.WaitForScreenToLoad();

                }
                else
                {
                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                    FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                    FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                    FastDriver.ClosingDisclosure.SellerOnly5.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.Delivery(method: "Print");
                    FastDriver.PrintDlg.ClickPrint();
                    FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);
                    FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                }

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);
                FastDriver.PrintChecks.WaitForScreenToLoad();

                Reports.TestStep = "Validate that on issue a disbursement exchange company cannot be deleted.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                Support.AreEqual("False", FastDriver.ExchangeCompany.Find.IsEnabled().ToString(), "Verifying Find button's status.");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual("False", FastDriver.BottomFrame.btnDelete.IsDisplayed().ToString(), "Verifying if Delete button is displayed.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0016()
        {
            try
            {
                
                Reports.TestDescription = "BR_FM10684: Prevent Changing the Seller type when invoiced with status final.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, chargeDescription: "New Home Rate (Title Only)", buyerCharge: 1.99, sellerCharge: 2.99);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, chargeDescription: "New Home Rate Eagle Lender Policy-1", buyerCharge: 1.99, sellerCharge: 2.99);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Navigate to Invoice Fees for file event.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();

                Reports.TestStep = "Set on final button in Invoice screen.";
                FastDriver.InvoiceFees.Final.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.InvoiceFees.WaitForScreenToLoad();

                Reports.TestStep = "Deselect invoice fees/Uninvoiced.";
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 8, TableAction.Off);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(3, 8, TableAction.Off);

                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Create an invoice/Select Final option.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 8, TableAction.On);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(3, 8, TableAction.On);
                FastDriver.InvoiceFees.Final.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "1.Navigate to Buyer summary screen.2. delete an instance.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();

                Reports.TestStep = "Chang the type from Individual to Husband and wife.";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("husband");

                Reports.TestStep = "Validate that Final invoiced buyer cannot be modified.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Invoice Fees for file event.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0005S_REG0017_18()
        {
            try
            {
                Reports.TestDescription = "BR_FM8754_8755_8756_8757_8758_8759_8760_8761_8762_precondition: Validate the GAB and wire instruction functionality-precondition.";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for GAB Id code";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchAddressBook("SELLATRNY");
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Select Buyer type as Trust estate and enter wire instruction.";
                FastDriver.BusPartyOrgSetUp.BuyerSellerType.FASelectItem("Trust/Estate");
                FastDriver.BusPartyOrgSetUp.ABANumber.FASetText("123456789");
                FastDriver.BusPartyOrgSetUp.BankName.FASetText("test bank name");
                FastDriver.BusPartyOrgSetUp.BankAddress.FASetText("test address 1 test address 2");
                FastDriver.BusPartyOrgSetUp.AccountNumber.FASetText("41256718909787");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST IIS side and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("SELLATRNY"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.None,
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter a gab code which has buyer type as trust Estate.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("SELLATRNY");
                FastDriver.HomeownerAssociation.AssociationChargesTable.EnterCharges(Row: 2, buyerCharge: 10.00, sellerCharge: 10.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Validate that Wire instructions are same as in business party org setup.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().Equals("123456789").ToString(), "Verifying values match.");
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().Equals("test bank name").ToString(), "Verifying values match.");
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue().Equals("test address 1 test address 2").ToString(), "Verifying values match.");
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().Equals("41256718909787").ToString(), "Verifying values match.");
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FAGetValue().Equals("41256718909787").ToString(), "Verifying values match.");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0019_20()
        {
            try
            {
                Reports.TestDescription = "BR_FM12983_13119_13120_13121_12989_13123_12990_12986_13118_12991_12992_12993_12995_12996: Validate the Notification functionality.";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Create new task.";
                FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Home>System Maintenance>Process Setup>Task Templates").WaitForScreenToLoad();
                FastDriver.TaskTemplateSelection.New.FAClick();
                string taskName = "FMUC0005_Task_" + Support.RandomString("AZAZA");
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount(), 3, TableAction.SetText, taskName);
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount(), 5, TableAction.SelectItem, "Yes");
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount(), 4, TableAction.SetText, taskName);
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount(), 7, TableAction.SelectItemBySendkeys, "notificacion");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Task Templates").WaitForScreenToLoad(element: FastDriver.TaskTemplateSelection.TasksForTable);
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(3, taskName, 3, TableAction.Click);

                Reports.TestStep = "Select Email as delivery method.";
                FastDriver.TaskTemplateSelection.Notification.FAClick();
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.TaskStatus.FASelectItem("Activated");
                FastDriver.NotificationSetup.DeliveryMethod.FASelectItem("Email");
                FastDriver.NotificationSetup.SubjectLine.FASetText("FMUC0005 - Proactive Notification Test");
                FastDriver.NotificationSetup.Select.FAClick();
                FastDriver.MessageTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.MessageTemplateSelectionDlg.FindNow.FAClick();
                FastDriver.MessageTemplateSelectionDlg.SearchResults.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.MessageTemplateSelectionDlg.Select.FAClick();
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NotificationSetup.SenderInfoTableCell.FAGetText().Contains("Notification will be sent from the first Selected Sender").ToString(), "Verifying Sender Info Warning.");

                Reports.TestStep = "Validate that Email Address button is enabled.";
                Support.AreEqual("True", FastDriver.NotificationSetup.TaskEmailAddresses.IsEnabled().ToString(), "Verifying button state");
                FastDriver.NotificationSetup.TaskEmailAddresses.FAClick();

                Reports.TestStep = "Enter name an email address and validate that 10 email address can be entered.";
                FastDriver.NotificationEmailAddressesDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NotificationEmailAddressesDlg.Table.GetRowCount().Equals(11).ToString(), "Verifying amount of email address that can be added.");
                FastDriver.NotificationEmailAddressesDlg.Table.PerformTableAction(2, 1, TableAction.SetText, "Name1");
                FastDriver.NotificationEmailAddressesDlg.Table.PerformTableAction(2, 2, TableAction.SetText, "test@proactivenotification.com");
                FastDriver.NotificationEmailAddressesDlg.Table.PerformTableAction(3, 1, TableAction.SetText, "Name2");
                FastDriver.NotificationEmailAddressesDlg.Table.PerformTableAction(3, 2, TableAction.SetText, "rjahagirdar@firstam.com");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on File Roles.";
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.FileRoles.FAClick();

                Reports.TestStep = "Select buyer, seller, Invoice to party as FBP role";
                FastDriver.SelectFBPRolesDlg.WaitForScreenToLoad();
                FastDriver.SelectFBPRolesDlg.Table.PerformTableAction(2, "Buyer", 1, TableAction.On);
                FastDriver.SelectFBPRolesDlg.Table.PerformTableAction(2, "Invoice To Party", 1, TableAction.On);
                FastDriver.SelectFBPRolesDlg.Table.PerformTableAction(2, "Seller", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Designated as a sender.";
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.AvailabeSender.FASelectItem("Designated Sender");
                FastDriver.NotificationSetup.RightDirectionArrow.FAClick();
                FastDriver.NotificationSetup.Name.FASetText("tester");
                FastDriver.NotificationSetup.EmailAddress.FASetText("rjahagirdar@firstam.com");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate that Invoice appears under documents table.";
                FastDriver.NotificationSetup.WaitForScreenToLoad(element: FastDriver.NotificationSetup.DocumentsTable);
                Support.AreEqual("True", FastDriver.NotificationSetup.DocumentsTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean().Equals("Invoice").ToString(), "Verifying item was added to table.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Regional Process Summary and create new process.";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>("Regional Process Summary").WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.New.FAClick();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessType.FASelectItem("Title Production");
                FastDriver.RegionalProcessEdit.ProcessName.FASetText("FMUC0005_Test - " + Support.RandomString("AAZNZNNA"));
                FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
                FastDriver.RegionalProcessEdit.Description.FASetText("FMUC0005 Regression Test.");
                string processName = FastDriver.RegionalProcessEdit.ProcessName.FAGetValue();

                Reports.TestStep = "Select a Process Template";
                FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.TranType.FASelectItem("Short Sale w/Mortgage");

                Reports.TestStep = "Clear state selection and select CA";
                FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction(2, "CA", 1, TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Clear county selection and select Alameda";
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                FastDriver.CountySelectionDlg.Table.PerformTableAction(2, "ORANGE", 1, TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();

                Reports.TestStep = "Clear city selection and select Anaheim";
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.AddRemoveCity.FAClick();
                FastDriver.CitySelectionDlg.WaitForScreenToLoad();
                FastDriver.CitySelectionDlg.Clear.FAClick();
                FastDriver.CitySelectionDlg.CityTable.PerformTableAction(2, "ANAHEIM", 1, TableAction.On);
                FastDriver.CitySelectionDlg.Select.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.Done.FAClick();

                Reports.TestStep = "Select First Invoice Finalized as a Process Event";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "First Invoice Finalized", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Add a newly created task to new process";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.Add.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, taskName, 4, TableAction.Click);
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, taskName, 2, TableAction.On);
                FastDriver.TaskTemplateSelectionDlg.Done.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Activating tasks";
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processName, 2, TableAction.Click);
                FastDriver.RegionalProcessSummary.WaitForProcessDetailsTableToLoad();
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.WaitForScreenToLoad();
                FastDriver.StatusEdit.Activate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select a process and click on Refresh button.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(processName);
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.TransactionTypeObjectCD = "SHTSALEMG";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                string fileNum1 = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum1);

                Reports.TestStep = "Activate the task for email notification";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.AddProcess.FAClick();
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, "Title Production", 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string processTable = FastDriver.FileWorkflow.GetWorkFlowTableID(processName);

                FastDriver.WebDriver.FAFindElement(ByLocator.Id, processTable).PerformTableAction(1, 1, TableAction.On);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Sellers screen and click on Edit";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItem("1099-S");
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(2, 1, TableAction.SelectItem, "E-Mail");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.CurrentEmailComments);
                Playback.Wait(2000);
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(2, 2, TableAction.SetText, "email@abc.com");
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(2, 4, TableAction.Click);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(2, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsSelected(), "Verifying Email Notification is checked.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, chargeDescription: "New Home Rate (Title Only)", buyerCharge: 1.99, sellerCharge: 2.99);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, chargeDescription: "New Home Rate Eagle Lender Policy-1", buyerCharge: 1.99, sellerCharge: 2.99);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Navigate to Invoice Fees for file event.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 8, TableAction.Off);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(3, 8, TableAction.Off);

                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Create an invoice";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 8, TableAction.On);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(3, 8, TableAction.On);

                Reports.TestStep = "Set on final button in Invoice screen.";
                FastDriver.InvoiceFees.Final.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.InvoiceFees.WaitForScreenToLoad();

                Reports.TestStep = "Verifying for the Notification via Email Successful event";
                Reports.TestStep = "Verifying for the Fast Search Initiated event";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    Reports.StatusUpdate("-- RETRYING -- ", true);
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                    FastDriver.EventTrackingLog.SelectEventCategory("Notifications");
                    Playback.Wait(500);
                    return FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Notification via Email Successful]");
                }, timeout: 60, idleInterval: 10);
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[Notification via Email Successful]");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0021_22()
        {
            try
            {
                
                Reports.TestDescription = "BR_FM6569: Validate the 1099 s alert in File workflow and MFT screen.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                string fileNum1 = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum1);

                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Open in error.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open In Error");
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("07-12-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter 1099s details to seller screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("1 Main St");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Alameda");
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItem("1099-S");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate and enter details to create a 1099-S.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.SSNTIN.FASetText("1213456966");
                FastDriver._1099S.ActiveAddress.FASetText("1 Main St");
                FastDriver._1099S.ActiveCity.FASetText("Alameda");
                FastDriver._1099S.ActivecboState.FASelectItem("CA");
                FastDriver._1099S.ActiveZip.FASetText("97020");
                FastDriver.BottomFrame.Save();
                FastDriver._1099S.WaitForScreenToLoad();

                Reports.TestStep = "Changing seller info after adding a 1099-S record.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("434-44-2342");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Update the 1099s record summary and check the Ready for extract.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 4, TableAction.SetText, "100");
                FastDriver._1099S.ActiveReadyForExtract.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver._1099S.WaitForScreenToLoad();

                Reports.TestStep = "Changing seller info after adding a 1099-S record ready to extract.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-44-6789");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change seller details after save active 1099s record.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate the 1099s alert image and the message for 1099 s.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("File Workflow").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileWorkflow.MessagesTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean().Contains("1099-S data has changed."), "Verifying 1099-S change message");

                //Reports.TestStep = "Validate the 1099s alert message.";
                //FastDriver.LeftNavigation.Navigate<MyFASTToday>("My Fast Today").WaitForScreenToLoad();

                Reports.TestDescription = "Change Seller 1099-S Classification to N/A.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItemBySendingKeys("n");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "1.Navigate to Seller summary screen.2. delete an instance.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0005S_REG0023()
        {
            try
            {
                Reports.TestDescription = "BR_FM6929: Assign Default 1099-S Classification to Seller.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Validate that 1099s classification is N/A.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem().Equals("N/A"), "Verifying Buyer Classification default selection");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0005S_REG0024_25_26_27()
        {
            try
            {
                Reports.TestDescription = "BR_FM6931_6933: Making activity date as blank & validate that 1099s alert is not present in file workflow.";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Making 1099-S Activity Date blank.";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                if (FastDriver.OfficeSetupOffice.ActivityDate1099s.FAGetValue().Clean() == "")
                {
                    Reports.StatusUpdate("Activity date value was already empty.", true);
                }
                else
                {
                    FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("");
                    Reports.StatusUpdate("Activity date was erased", true);
                }
                FastDriver.BottomFrame.Done();
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.WebDriver.Quit();
                
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Change the 1099s clarification to 1099s.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("1 Main St");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Alameda");
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItem("1099-S");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Open in error.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open In Error");
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("07-12-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate and enter details to create a 1099-S.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.SSNTIN.FASetText("1213456966");
                FastDriver._1099S.ActiveAddress.FASetText("1 Main St");
                FastDriver._1099S.ActiveCity.FASetText("Alameda");
                FastDriver._1099S.ActivecboState.FASelectItem("CA");
                FastDriver._1099S.ActiveZip.FASetText("97020");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver._1099S.WaitForScreenToLoad();

                Reports.TestStep = "Validate the 1099s alert image and the message for 1099 s.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("File Workflow").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileWorkflow.MessagesTable.GetRowCount().Equals(1), "Verifying lack of warning messages.");
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "BR_FM6931_6933_postcondition: Enter an activity date. Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Making 1099-S Activity Date blank.";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("07-12-2010");
                FastDriver.BottomFrame.Done();
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "BR_FM6931_6933: Validate that 1099s alert is not present in file workflow.";
                Login(AutoConfig.FASTHomeURL);
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Change the 1099s clarification to 1099s.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("434-44-2342");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that 1099s alert is not there.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("File Workflow").WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains("1099-S data has changed."), "Verifying lack of 1099-S warning messages.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0005S_REG0028()
        {
            try
            {
                string loBound = "DHGd775689$!@";
                string upBound = "DHGd775689$!@1reet34";
                string longField = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452";
                string addressField = "ghkdjrjky2i5729571957395!#$%%^#&^";
                Reports.TestDescription = "FieldDefinations: Validating field definitions in seller screen.";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Change the buyer type as trust without enter SSN and Short name.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.EmployedBy.FASelectItemByIndex(1);

                //Reports.TestStep = "Validate the hot key action for Search functionality."; - Functionality causes bug. TFS# 784615
                //Keyboard.SendKeys("%E");

                //Reports.TestStep = "Validate newly added Entity Type Corporate in Address Book search.";
                //FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();
                //FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Corporate");
                //FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                //FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Validate fields for type Individual lower bound.";
                //FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.IndividualFirstName);
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(loBound);
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText(loBound);
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(loBound);
                FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText("12345");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.Salutation.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(longField);
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                Playback.Wait(700);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
                string stateList = FastDriver.BuyerSellerSetup.CurrentState.FAGetAllTextFromSelect(", ");
                string countryList = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetAllTextFromSelect(", ");
                FastDriver.BuyerSellerSetup.ForwardingSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("23234-4244" + FAKeys.Tab);

                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean().Equals(loBound), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue().Clean().Equals(loBound), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean().Equals(loBound), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue().Clean().Equals("12345"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.txtSSN.FAGetValue().Clean().Equals("123-45-6789"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Salutation.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentState.FAGetAllTextFromSelect(", ").Equals(stateList), "Verifying state list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentCountry.FAGetAllTextFromSelect(", ").Equals(countryList), "Verifying state list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingState.FAGetAllTextFromSelect(", ").Equals(stateList), "Verifying state list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue().Clean().Equals("23234-4244"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetAllTextFromSelect(", ").Equals(countryList), "Verifying state list.");

                Reports.TestStep = "Validate fields for type Individual upper bound.";
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(upBound);
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText(upBound);
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(upBound);
                FastDriver.BuyerSellerSetup.Salutation.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(longField);

                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean().Equals(upBound), "Verifying upper bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue().Clean().Equals(upBound), "Verifying upper bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean().Equals(upBound), "Verifying upper bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Salutation.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                
                Reports.TestStep = "Validate fields for type husband and wife lower bound.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("husband");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.Husband1FirstName);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText(loBound);
                FastDriver.BuyerSellerSetup.Husband1MiddleName.FASetText(loBound);
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText(loBound);
                FastDriver.BuyerSellerSetup.Husband1suffix.FASetText("12345");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText(loBound);
                FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FASetText(loBound);
                FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FASetText(loBound);
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FASetText("12345");
                FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FASetText("3424");
                FastDriver.BuyerSellerSetup.Salutation.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(longField);
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                Playback.Wait(700);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244");
                FastDriver.BuyerSellerSetup.ForwardingSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("23234-4244");

                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue().Clean().Equals(loBound), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Husband1MiddleName.FAGetValue().Clean().Equals(loBound), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue().Clean().Equals("DHGd775689$!@"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Husband1suffix.FAGetValue().Clean().Equals("12345"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue().Clean().Equals(loBound), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FAGetValue().Clean().Equals(loBound), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue().Clean().Equals("DHGd775689$!@"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FAGetValue().Clean().Equals("12345"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FAGetAttribute("title").Clean().Equals("Field is Invalid"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Salutation.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentState.FAGetAllTextFromSelect(", ").Equals(stateList), "Verifying state list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentCountry.FAGetAllTextFromSelect(", ").Equals(countryList), "Verifying country list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue().Clean().Equals("23234-4244"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingState.FAGetAllTextFromSelect(", ").Equals(stateList), "Verifying state list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue().Clean().Equals("23234-4244"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetAllTextFromSelect(", ").Equals(countryList), "Verifying state list.");

                Reports.TestStep = "Validate fields for type husband and wife upper bound.";
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText(upBound);
                FastDriver.BuyerSellerSetup.Husband1MiddleName.FASetText(upBound);
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText(upBound);
                FastDriver.BuyerSellerSetup.Husband1suffix.FASetText("12345");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText(upBound);
                FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FASetText(upBound);
                FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FASetText(upBound);
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FASetText("12345");
                FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FASetText("43444234234");
                FastDriver.BuyerSellerSetup.Salutation.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(longField);

                Reports.TestStep = "Validate fields for Business entity type lower bound.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("business");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.BusinessEntityShortname);
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("3424");
                FastDriver.BuyerSellerSetup.Salutation.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(longField);
                string stateIncorporation = FastDriver.BuyerSellerSetup.StateofIncorp.FAGetAllTextFromSelect(", ");
                string entityType = FastDriver.BuyerSellerSetup.EntityType.FAGetAllTextFromSelect(", ");
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                Playback.Wait(700);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244");
                FastDriver.BuyerSellerSetup.ForwardingSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("23234-4244");

                Support.AreEqual(true, FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetAttribute("title").Equals("Field is Invalid"), "Verifying lower bound of field.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.StateofIncorp.FAGetAllTextFromSelect(", ").Equals(stateIncorporation), "Verifying menu options.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.EntityType.FAGetAllTextFromSelect(", ").Equals(entityType), "Verifying menu options.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Salutation.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentState.FAGetAllTextFromSelect(", ").Equals(stateList), "Verifying state list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentCountry.FAGetAllTextFromSelect(", ").Equals(countryList), "Verifying country list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue().Clean().Equals("23234-4244"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingState.FAGetAllTextFromSelect(", ").Equals(stateList), "Verifying state list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue().Clean().Equals("23234-4244"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetAllTextFromSelect(", ").Equals(countryList), "Verifying state list.");

                Reports.TestStep = "Validate fields for Business entity type upper bound.";
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("434442342" + FAKeys.Tab);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue().Equals("43-4442342"), "Verifying lower bound of field.");

                Reports.TestStep = "Validate fields for Trust Estate type Lower bound.";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("trust");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Lorem ipsum dolor sit amet, consectetur.");
                FastDriver.BuyerSellerSetup.TrustNumber.FASetText("434-44-2342");
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("434-44-2342");
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrustAuthorizedName);
                FastDriver.BuyerSellerSetup.TrustAuthorizedName.FASetText("Lorem ipsum dolor sit amet, consectetur.");
                string trustautType = FastDriver.BuyerSellerSetup.TrustAuthorizedType.FAGetAllTextFromSelect(", ");
                FastDriver.BuyerSellerSetup.TrustTitle.FASetText("Lorem ipsum dolor sit amet, consectetur.");
                FastDriver.BuyerSellerSetup.Salutation.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(longField);
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(longField);
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FASetCheckbox(true);
                Playback.Wait(700);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(addressField);
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244");
                FastDriver.BuyerSellerSetup.ForwardingSetToOther.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(addressField);
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("23234-4244");

                Support.AreEqual(true, FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue().Equals("Lorem ipsum dolor sit amet, consectetur."), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.TrustNumber.FAGetValue().Equals("434-44-2342"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.TrustSSNtext.FAGetValue().Equals("43-4442342"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.TrustAuthorizedName.FAGetValue().Equals("Lorem ipsum dolor sit amet, consectetur."), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.TrustAuthorizedType.FAGetAllTextFromSelect(", ").Equals(trustautType), "Verifying all options in dropdown.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.TrustTitle.FAGetValue().Equals("Lorem ipsum dolor sit amet, consectetur."), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.Salutation.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue().Clean().Equals(longField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentState.FAGetAllTextFromSelect(", ").Equals(stateList), "Verifying state list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentCountry.FAGetAllTextFromSelect(", ").Equals(countryList), "Verifying country list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue().Clean().Equals("23234-4244"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue().Clean().Equals(addressField), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingState.FAGetAllTextFromSelect(", ").Equals(stateList), "Verifying state list.");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue().Clean().Equals("23234-4244"), "Verifying lower bound for field");
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetAllTextFromSelect(", ").Equals(countryList), "Verifying state list.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0005S_REG0029()
        {
            try
            {
                Reports.TestDescription = "FD:Additional vesting";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Seller screen and click on Edit.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

                Reports.TestStep = "Validate fields for text field Additional Vesting lower bound.";
                string limitTesting = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras imperdiet sem in egestas fringillarm.";
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText(limitTesting);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue().Clean().Equals(limitTesting), "Verifying lower bound for field.");

                Reports.TestStep = "Validate fields for text field Additional Vesting upper bound.";
                limitTesting = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras imperdiet sem in egestas fringillarm!@#";
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText(limitTesting);
                Support.AreEqual(false, FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue().Clean().Length.Equals(101), "Verifying upper bound for field.");

                Reports.TestStep = "Validate fields for text field Additional Vesting exact value.";
                limitTesting = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras imperdiet sem in egestas fringillarm!.";
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText(limitTesting);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue().Clean().Length.Equals(100), "Verifying exact value for field.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0005S_REG0030()
        {
            try
            {
                Reports.TestDescription = "FM9102  Identify Exchange Company with its Buyer or Seller";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Phrase Maintenance and create Phrase";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
                string phraseGroup = Support.RandomString("AZAZ");
                FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(phraseGroup, "FMUC0005 Regression Phrase Group", "Escrow Phrase", "FMUC0005 Regression Test", applyToAllPhrases: true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Add);
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                string phraseName = Support.RandomString("ZAZA");
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: "FMUC0005 Regression Phrase", comments: "FMUC0005 Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertDataElement);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem("Seller");
                Playback.Wait(2000);
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(element: FastDriver.DataElementSelectionDlg.SearchResultsTable);
                FastDriver.DataElementSelectionDlg.SearchResultsTable.PerformTableAction(1, "SENAME", 1, TableAction.DoubleClick);
                FastDriver.DataElementSelectionDlg.SearchResultsTable.PerformTableAction(1, "SXCNAME", 1, TableAction.DoubleClick);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2000);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertDataElement);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestDescription = "Creation of Template";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Template Maintenance").WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                string templateName = "FMUC0005" + Support.RandomString("AZAZ");
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(name: templateName, description: templateName, comments: "FMUC0005 Reg Testing", underConstruction: false);
                FastDriver.TemplateMaintenanceInformation.ClickPhrasesTab();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.OpenPhraseSelectDialog();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                while (FastDriver.PhraseSelectDlg.PhraseGroup.FAGetSelectedItem().Contains(phraseGroup.ToUpper()) == false)
                {
                    Reports.StatusUpdate("--Finding Phrase Group Name--", true);
                    FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItemBySendingKeys("f");
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                }
                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.DoubleClick);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhraseTable.PerformTableAction(2, 3, TableAction.On);
                FastDriver.TemplateMaintenancePhrase.ClickFormattingTab();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFormating.FormatSummaryTable.PerformTableAction(2, 6, TableAction.Click);
                FastDriver.TemplateMaintenanceFormating.FormatSummaryTable.PerformTableAction(3, 6, TableAction.Click);
                FastDriver.TemplateMaintenanceFormating.FormatSummaryTable.PerformTableAction(4, 6, TableAction.Click);
                FastDriver.TemplateMaintenanceFormating.FormatSummaryTable.PerformTableAction(5, 6, TableAction.Click);
                FastDriver.TemplateMaintenanceFormating.ClickFilteringTab();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateFilterSelectionDlg.ServiceTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.UnderWriterSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.TrassactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProgrammeTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Seller screen and click on Edit.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.Find.FAClick();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "EXCH01");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                string exchangeName = FastDriver.ExchangeCompany.NameLabel1.Text.Clean() + "," + FastDriver.ExchangeCompany.NameLabel2.Text.Clean();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Document Repository - click Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad(element: FastDriver.DocumentRepository.Add);
                if (FastDriver.DocumentRepository.AddDocRep.IsDisplayed())
                {
                    FastDriver.DocumentRepository.AddDocRep.FAClick();
                }
                else
                {
                    FastDriver.DocumentRepository.Add.FAClick();
                }

                Reports.TestStep = "Select template created in ADM & click on save button.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.CreateandEditDocument("Both", "Escrow Instruction", templateName, "CA");

                Reports.TestStep = "Verify the Phrase name and Business Contacts for the Business source.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, "grdDocuments_0_grdDocPhrase").PerformTableAction(1, 2, TableAction.GetText).Message.Clean().Equals("Seller Name(s)"), "Verifying element content.");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, "grdDocuments_0_grdDocPhrase").PerformTableAction(1, 3, TableAction.GetInputValue).Message.Clean().Equals("SellerName SellerLastName"), "Verifying element content.");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, "grdDocuments_0_grdDocPhrase").PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Equals("Seller Exchange Company: Name (Lines 1-2)"), "Verifying element content.");
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, "grdDocuments_0_grdDocPhrase").PerformTableAction(2, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea").FAGetAttribute("value").Clean().Equals(exchangeName), "Verifying element content.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0031()
        {
            try
            {
                Reports.TestDescription = "BR_FM11511_EW10: Validate that Prevent Save of XML- incompatible characters for an IBA Bene";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #region Data Setup
                var deposit = new DepositParameters()
                {
                    Amount = 6000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "FMUC0005 Seller Deposit in Escrow",
                    ReceivedFrom = "Seller"
                };
                #endregion

                Reports.TestStep = "To enter the first property address in Property tax screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertyTaxSummary.PropertiesSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("32 Second St");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Lakeport");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Lake");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deposit a cash more than sales price.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Enter invalid or incompatible values to instance which is an IBA beneficiary.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("~ ` ! @ ^  * [ { ] }");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("413-45-6759");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a seller instance with invalid or incompatible values";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("~ ` ! @ ^  * [ { ] }");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a seller instance with invalid or incompatible values";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.BusinessEntityShortname);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("~ ` ! @ ^  * [ { ] }");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a seller instance with invalid or incompatible values";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("husband");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.Husband1FirstName);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Z<>$#:'/+-=().,_&");
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText("A~!%^*{}[]");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Z<>$#:'/+-=().,_&");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                

                for (int i = 1; i <= 5; i++)
                {
                    FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                    Reports.TestStep = "Select Seller entry #" + i + " as beneficiary.";
                    FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                    FastDriver.SelectIBABeneficiaryDlg.SellersTable.PerformTableAction(i, 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();

                    Reports.TestStep = "Prevent Save for XML-incompatible Special Characters in IBA Beneficiary #" + i + ".";
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: false);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                }
                

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005S_REG0032()
        {
            try
            {

                Reports.TestDescription = "Validate full vesting, refresh vesting and cf notification phone type";
                Reports.TestStep = "Log into FAST application and create a file";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 Main St";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ANAHEIM";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ORANGE";
                fileRequest.File.SalesPriceAmount = 5000m;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #region Individual
                Reports.TestStep = "Enter Seller details for Individual type.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("123-45-6789");
                FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName.FASetText("Sellersign");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem("a single man");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem("as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText("Additional Vesting");
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.ForwardingPhoneNum.FASetText("(991)889-8383");
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText("Misc Ref 1");
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText("Misc Ref 2");
                string vesting = FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean() + " " + FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean() + ", " + FastDriver.BuyerSellerSetup.MaritalStatus.FAGetSelectedItem();
                string completeVesting = FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().Clean() + " " + FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().Clean() + ", " + FastDriver.BuyerSellerSetup.MaritalStatus.FAGetSelectedItem() + " " + FastDriver.BuyerSellerSetup.Vesting.FAGetSelectedItem() + ", " + FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue().Clean();

                Reports.TestStep = "Get buyers data to validate full vesting";
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerVesting.Names.FAGetValue().Equals(vesting), "Verifying vesting value");
                Support.AreEqual(true, FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Equals(completeVesting), "Verifying vesting value");

                Reports.TestStep = "Validate Refresh functionality in full vesting";
                FastDriver.BuyerVesting.RefreshShort.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerVesting.Names.FAGetValue().Equals(FastDriver.BuyerVesting.CompleteVesting.FAGetValue()), "Verifying Refresh functionality.");
                FastDriver.BottomFrame.Reset();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.RefreshFull.FAClick();
                Support.AreEqual(true, FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Equals(completeVesting), "Verifying Refresh functionality.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate phone types CF Notification";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 1, TableAction.SelectItem, "CF Notification");
                Playback.Wait(2000);
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.SetText, "111" + FAKeys.Tab);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetAttribute, "title").Message.Clean().Contains("invalid"), "Verifying character limit.");
                //FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.SetText, "1111111111" + FAKeys.Tab);
                //Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetInputValue).Message.Clean().Equals("(111)111-1111"), "Verifying character limit.");
                //FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.SetText, "1111111111" + FAKeys.Tab);
                //Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetInputValue).Message.Clean().Equals("1111111111"), "Verifying character limit.");
                //Support.AreEqual(false, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsDisplayed(), "Verifying if notification checkbox appears");
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Husband/Wife
                Reports.TestStep = "Enter Seller details for Husband/Wife type.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("husband");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.Husband1FirstName);
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Jane");
                FastDriver.BuyerSellerSetup.MaritalStatus.FASelectItem("married spouses");
                FastDriver.BuyerSellerSetup.Vesting.FASelectItem("as community property");
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText("Additional Vesting");
                vesting = FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue() + " " + FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue() + " and " + FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue() + " " + FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue() + ", " + FastDriver.BuyerSellerSetup.MaritalStatus.FAGetSelectedItem() + " " + FastDriver.BuyerSellerSetup.Vesting.FAGetSelectedItem() + ", " + FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue();

                Reports.TestStep = "Get buyers data to validate full vesting";
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.RefreshFull.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.RefreshShort.FAClick();
                Support.AreEqual(true, FastDriver.BuyerVesting.Names.FAGetValue().Equals(vesting), "Verifying Buyer Vesting");
                Support.AreEqual(true, FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Equals(vesting), "Verifying Buyer Vesting");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate phone types CF Notification";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 1, TableAction.SelectItem, "CF Notification");
                Playback.Wait(2000);
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.SetText, "111" + FAKeys.Tab);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetAttribute, "title").Message.Clean().Contains("invalid"), "Verifying character limit.");
                
                //FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.SetText, "1111111111" + FAKeys.Tab);
                //Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetInputValue).Message.Clean().Equals("(111)111-1111"), "Verifying character limit.");
                //FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 3, TableAction.SetText, "1111111111" + FAKeys.Tab);
                //Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 3, TableAction.GetInputValue).Message.Clean().Equals("1111111111"), "Verifying character limit.");
                //Support.AreEqual(false, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsDisplayed(), "Verifying if notification checkbox appears");
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Trust/Estate
                Reports.TestStep = "Enter Seller details for Trust/Estate type.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("trust");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Seller Trust Name");
                FastDriver.BuyerSellerSetup.TrustDated.FASetText("07-10-2012");
                FastDriver.BuyerSellerSetup.TrustNumber.FASetText("12345678");
                FastDriver.BuyerSellerSetup.TrustTIN.FASetCheckbox(true);
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("12-3124231");
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                FastDriver.BuyerSellerSetup.TrustAuthorizedName.FASetText("Trust");
                FastDriver.BuyerSellerSetup.TrustAuthorizedType.FASelectItem("Other");
                FastDriver.BuyerSellerSetup.TrustApply.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.TrusteeShortName);
                vesting = FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue();

                Reports.TestStep = "Get buyers data to validate full vesting";
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.RefreshFull.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.RefreshShort.FAClick();
                Support.AreEqual(true, FastDriver.BuyerVesting.Names.FAGetValue().Equals(vesting + ", dated July 10, 2012"), "Verifying Buyer Vesting");
                Support.AreEqual(true, FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Equals(vesting + ", dated July 10, 2012"), "Verifying Buyer Vesting");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate phone types CF Notification";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 1, TableAction.SelectItem, "CF Notification");
                Playback.Wait(2000);
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.SetText, "111" + FAKeys.Tab);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetAttribute, "title").Message.Clean().Contains("invalid"), "Verifying character limit.");
                System.Diagnostics.Debug.Print(FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetAttribute, "title").Message.Clean());
                //FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.SetText, "1111111111" + FAKeys.Tab);
                //Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetInputValue).Message.Clean().Equals("(111)111-1111"), "Verifying character limit.");
                //FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 3, TableAction.SetText, "1111111111" + FAKeys.Tab);
                //Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 3, TableAction.GetInputValue).Message.Clean().Equals("1111111111"), "Verifying character limit.");
                //Support.AreEqual(false, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsDisplayed(), "Verifying if notification checkbox appears");
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Business Entity
                Reports.TestStep = "Enter Seller details for Business Entity type.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("business");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(elem: FastDriver.BuyerSellerSetup.BusinessEntityShortname);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Seller Short Name");
                FastDriver.BuyerSellerSetup.StateofIncorp.FASelectItem("Alaska");
                FastDriver.BuyerSellerSetup.EntityType.FASelectItem("Business Trust");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("53-4553543");
                vesting = FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAGetValue() + ", an " + FastDriver.BuyerSellerSetup.StateofIncorp.FAGetSelectedItem() + " " + FastDriver.BuyerSellerSetup.EntityType.FAGetSelectedItem().ToLower();

                Reports.TestStep = "Get buyers data to validate full vesting";
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.RefreshFull.FAClick();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.RefreshShort.FAClick();
                Support.AreEqual(true, FastDriver.BuyerVesting.Names.FAGetValue().Equals(vesting), "Verifying Buyer Vesting");
                Support.AreEqual(true, FastDriver.BuyerVesting.CompleteVesting.FAGetValue().Equals(vesting), "Verifying Buyer Vesting");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate phone types CF Notification";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 1, TableAction.SelectItem, "CF Notification");
                FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.SetText, "111" + FAKeys.Tab);
                //Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetAttribute, "title").Message.Clean().Equals("Field is invalid"), "Verifying character limit.");
                //FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.SetText, "1111111111" + FAKeys.Tab);
                //Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 2, TableAction.GetInputValue).Message.Clean().Equals("(111)111-1111"), "Verifying character limit.");
                //FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 3, TableAction.SetText, "1111111111" + FAKeys.Tab);
                //Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 3, TableAction.GetInputValue).Message.Clean().Equals("1111111111"), "Verifying character limit.");
                //Support.AreEqual(false, FastDriver.BuyerSellerSetup.CurrentPhonesTable.PerformTableAction(1, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsDisplayed(), "Verifying if notification checkbox appears");
                FastDriver.BottomFrame.Reset();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                           :  SRT-Team2
        //Iteration                      :  r09
        //UserStory                      :  User Story 830371: N-issue: EVAL03 - Release 10.5 - Elements are not displaying correctly after selecting CF Notification on Buyers/Sellers screen.
        // TestCase                      :  862379
        //Appended By/ Created By        :  Diego Hilario

        [TestMethod]
        public void FMUC0005S_REG0033()
        {
            try
            {
                Reports.TestDescription = "To Verify US# 830371 - Ext. field to update correctly after changing Current/Forwarding Phones type - Seller";

                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a basic file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Seller screen and add First and Last names on Seller Details section ";

                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");

                Reports.TestStep = "On Current Phones section, select CF Notification on the dropdown menu for the first row";
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem("CF Notification");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Playback.Wait(2000);

                Reports.TestStep = "Ensure Ext. textbox is removed for the first row ";
                Support.AreEqual(false, FastDriver.BuyerSellerSetup.CurrentPhoneOneExtnTxt.Exists(), "Verifying Ext. textbox is removed");

                Reports.TestStep = "On first row, change the Type back to Home Phone";
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem("Home Phone");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Playback.Wait(2000);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhoneOneExtnTxt.Exists(), "Verifying Ext. textbox is displayed");

                Reports.TestStep = "Perform steps 4-6 for Forwarding Phones section using E-mail type instead of CF Notification";

                Reports.TestStep = "On Current Phones section, select CF Notification on the dropdown menu for the first row";
                FastDriver.BuyerSellerSetup.ForwardingPhoneType.FASelectItem("E-Mail");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Playback.Wait(2000);

                Reports.TestStep = "Ensure Ext. textbox is removed for the first row ";
                Support.AreEqual(false, FastDriver.BuyerSellerSetup.ForwardingExtension.Exists(), "Verifying Ext. textbox is removed");

                Reports.TestStep = "On first row, change the Type back to Home Phone";
                FastDriver.BuyerSellerSetup.ForwardingPhoneType.FASelectItem("Home Phone");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Playback.Wait(2000);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingExtension.Exists(), "Verifying Ext. textbox is displayed");

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        #endregion

        #region Useful methods
        private void Login(string Key)
        {

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(Key, credentials, true);
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
