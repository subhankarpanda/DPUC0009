﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium;


namespace FileManagement
{
    [CodedUITest]
    public partial class FPUC0012 : MasterTestClass
    {

        #region FPUC0012_BAT0001
        [TestMethod]
        public void FPUC0012_BAT0001()
        {
            //Combined: FPUC0012_BAT0001, FPUC0012_BAT0002A, FPUC0012_BAT0002B, FPUC0012_BAT0002C, FPUC0012_BAT0007, FPUC0012_BAT0014

            try
            {
                Reports.TestDescription = "MF1_00: Access File Workflow; FP9013_Precondition: Validate for Task is enabled; Process for Manual Activation, if Task is not in Activate status; AF2_00: Start a Task on Tasks Section/View File Event Log; AF5_00: Assign a Task on Tasks Section; AF1_00_9756: Manually Activate a Task on Tasks Section";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyTaskName4 = "Task Inactive";
                string MyUserName = "QA06, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();

                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All and Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Validate at least one process has pulled into the file";
                Support.AreNotEqual("0", FastDriver.FileWorkflow.Process.GetRowCount().ToString(), "At least one process pulled into file");

                Reports.TestStep = "Check Active Only checkbox, validate task is enabled";
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileWorkflow.Process.PerformTableAction(1, 1, TableAction.GetCell).Element.IsEnabled(), "Task enable");

                Reports.TestStep = "Select the disabled task and activate it";
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                    
                Reports.TestStep = "Validate task is disabled";
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskDisabled(MyTaskName4), "Task disabled");
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName4, TableAction.Click, 5);
                FastDriver.FileWorkflow.Details.FAClick();
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                FastDriver.TaskDetailsDlg.WorkGroupTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.TaskDetailsDlg.ManualActivation.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Validate Task has been activated";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.FileWorkflow.IsTaskDisabled(MyTaskName4), "Task enabled");

                Reports.TestStep = "Start the first task";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.On, 1);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                
                Reports.TestStep = "Validate task has been started";
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskStarted(MyTaskName1), "Task started");

                Reports.TestStep = "Verify system assigns the selected Task to the current user name";
                Support.AreEqual("QA07, FAST", FastDriver.FileWorkflow.GetAssignedToUser(MyTaskName1), "Assigned To");

                Reports.TestStep = "Click Event Log button, validate event log";
                FastDriver.FileWorkflow.EventLog.FAClick();
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual("Task: " + MyTaskName4, FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Manual Task Activation]", 5, TableAction.GetText).Message.Clean(), "[Manual Task Activation]");
                Support.AreEqual("Task: " + MyTaskName1 + " To: FAST QA07", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Started and Assigned]", 5, TableAction.GetText).Message.Clean(), "[Task Started and Assigned]");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_BAT0002
        [TestMethod]
        public void FPUC0012_BAT0002()
        {
            //Combined: FPUC0012_BAT0003, FPUC0012_BAT0004; FPUC0012_REG0013

            try
            {
                Reports.TestDescription = "AF3_00: Complete a Task on Tasks Section; AF4_00: Waive a Task on Tasks Section; FP3118: Complete A Task";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyTaskName2 = "Task 2";
                string MyTaskName3 = "Task 3";
                string MyUserName = "QA06, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Complete the third task";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName3, TableAction.On, 2);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Validate task has been completed";
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskCompleted(MyTaskName3), "Task completed");

                Reports.TestStep = "Waive the second task";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.On, 3);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Validate task has been vaived";
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskWaived(MyTaskName2), "Task waived");

                Reports.TestStep = "Click Event Log button, validate event logs";
                FastDriver.FileWorkflow.EventLog.FAClick();
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual("Task: " + MyTaskName3, FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Completed]", 5, TableAction.GetText).Message.Clean(), "[Task Completed]");
                Support.AreEqual("Task: " + MyTaskName2, FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Waived]", 5, TableAction.GetText).Message.Clean(), "[Task Waived]");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_BAT0003
        [TestMethod]
        public void FPUC0012_BAT0003()
        {
            //Combined: FPUC0012_BAT0005, FPUC0012_BAT0006

            try
            {
                Reports.TestDescription = "AF7_00: Change the Task Office on a Task";

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All checkbox";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Click task office icon on the first task";
                string TaskName1 = FastDriver.FileWorkflow.Process.PerformTableAction(1, 5, TableAction.GetText).Message;
                FastDriver.FileWorkflow.Process.PerformTableAction(1, 7, TableAction.Click);

                Reports.TestStep = "Select QA SANDPOINTE OFFICE task office";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.PerformTableAction(3, "QA SANDPOINTE OFFICE", 3, TableAction.DoubleClick);

                Reports.TestStep = "Validate task office is displayed on File Workflow";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("QA SANDPOINTE OFFICE", FastDriver.FileWorkflow.GetAssignedTaskOffice(TaskName1), "Assigned Task Office");

                Reports.TestStep = "Select workgroup on the first task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Process.PerformTableAction(5, TaskName1, 9, TableAction.Click);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.SelWorkgrp.FASelectItemBySendingKeys("++View More Workgroups...");

                Reports.TestStep = "Select a workgroup from the WorkgroupSelection dialog";
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem("1099");
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Validate workgroup is displayed on File Workflow";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("1099", FastDriver.FileWorkflow.GetAssignedWorkgroup(TaskName1), "Assigned Workgroup");
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Click Event Log button, validate event logs";
                FastDriver.FileWorkflow.EventLog.FAClick();
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual("Task: " + TaskName1 + " To: QA SANDPOINTE OFFICE", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Office Assigned]", 5, TableAction.GetText).Message.Clean(), "[Task Office Assigned]");
                Support.AreEqual("Task: " + TaskName1 + " To: 1099", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Workgroup Assigned]", 5, TableAction.GetText).Message.Clean(), "[Task Workgroup Assigned]");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_BAT0004
        [TestMethod]
        public void FPUC0012_BAT0004()
        {
            //Combined: FPUC0012_BAT0008, FPUC0012_BAT0009, FPUC0012_BAT0010; FPUC0012_REG0020; FPUC0012_REG0110

            try
            {
                Reports.TestDescription = "AF8_00: Add a Process; AF9_00: Add a Task from Process Template; AF10_00: Add a Task from Task Template (View More); 4775: Add a Process to File Workflow";

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = @"Navigate to Properties/Tax Info screen and change the to California address";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "1", 1, TableAction.DoubleClick);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "Santa Ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);
                FastDriver.BottomFrame.Save();
                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Click Add Process button";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.AddProcess.FAClick();

                Reports.TestStep = "Add 'Title Production' process to the file";
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, "Title Production", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                
                Reports.TestStep = "Validate process is added to the file";
                Support.AreEqual("AUTO_DONOTTOUCH_Template Setup Maintenan", FastDriver.FileWorkflow.ProcessName1.FAGetText().Clean());

                Reports.TestStep = "Click Event Log button, validate event logs";
                FastDriver.FileWorkflow.EventLog.FAClick();
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual(@"Description: Best match process added for the selected process type. Process Type: Title Production, AUTO_DONOTTOUCH_Template Setup Maintenan", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Manual Process Added]", 5, TableAction.GetText).Message.Clean(), "[Manual Process Added]");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Select the first task and click the Add Task button";
                int currentRowCount = FastDriver.FileWorkflow.Process.GetRowCount();
                FastDriver.FileWorkflow.Process.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Select the first task from the Add Tasks from Process Template Screen dialog";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                string Taskname = FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.AddTasksfromProcessTemplateScreenDlg.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Validate a new task has been added (row count increase by 1)";
                Support.AreEqual((currentRowCount + 1).ToString(), FastDriver.FileWorkflow.Process.GetRowCount().ToString(), "row count increase by 1");

                Reports.TestStep = "Select the first task and click the Add Task button";
                currentRowCount = FastDriver.FileWorkflow.Process.GetRowCount();
                FastDriver.FileWorkflow.Process.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.FileWorkflow.AddTask.FAClick();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                
                Reports.TestStep = "Click View More button, select the first task from the Open Order category";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                Taskname = FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(1, "1", 3, TableAction.GetText).Message.Clean();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(1, "1", 2, TableAction.On);
                FastDriver.TaskTemplateSelectionDlg.SelectTask.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Validate new task has been added to file";
                Support.AreEqual(Taskname, FastDriver.FileWorkflow.PeformActionOnTask(Taskname, TableAction.GetText, 5).Message.Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_BAT0005
        [TestMethod]
        public void FPUC0012_BAT0005()
        {
            //Combined: FPUC0012_BAT0011, FPUC0012_BAT0012

            try
            {
                Reports.TestDescription = "AF14_00: Move a Task Up on Tasks Section; AF15_00: Move a Task Down on Tasks Section";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyTaskName2 = "Task 2";

                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                #region Move task up/down
                Reports.TestStep = "Select the second task and click Up button";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.Click, 5);
                FastDriver.FileWorkflow.Up.FAClick();

                Reports.TestStep = "Validate the second task have been moved to the first position, and task 1 moved down one position";
                Support.AreEqual("1", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.GetText, 4).Message, "Tasks 2 moved up to postion 1");
                Support.AreEqual("2", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.GetText, 4).Message, "Tasks 1 moved down to postion 2");

                Reports.TestStep = "Select the first task and click Down button";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.Click, 5);
                FastDriver.FileWorkflow.Down.FAClick();

                Reports.TestStep = "Validate task 1 & 2 has moved back to their original positions";
                Support.AreEqual("1", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.GetText, 4).Message, "Tasks 1 moved up to postion 1");
                Support.AreEqual("2", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.GetText, 4).Message, "Tasks 2 moved down to postion 2");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_BAT0006
        [TestMethod]
        public void FPUC0012_BAT0006()
        {
            //Combined: FPUC0012_BAT0013

            try
            {
                Reports.TestDescription = @"AF16_00: Add/Edit a Task Comment";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";

                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);

                Reports.TestStep = "Click the task comment on the task # 1";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.Click, 12);

                Reports.TestStep = "Enter task comments";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.PublishedComment.FASetText("Public WF Task Comments");
                FastDriver.TaskCommentEditDlg.NonPublishedComment.FASetText("Non Public Task Comments");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Navigate to File Notes screen, validate Public and Nonpublic task comments";
                FastDriver.FileNotes.Open();
                Support.AreEqual(true, FastDriver.FileNotes.Table.StringExistOnTable(MyTaskName1), "Task Name");
                Support.AreEqual(true, FastDriver.FileNotes.Table.StringExistOnTable("Public WF Task Comments"), "Public Task Comments");
                Support.AreEqual(true, FastDriver.FileNotes.Table.StringExistOnTable("Non Public Task Comments"), "Non Public Task Comments");

                Reports.TestStep = "Edit the task comments";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.Click, 12);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.PublishedComment.FASetText("Public WF Task Comments Changed");
                FastDriver.TaskCommentEditDlg.NonPublishedComment.FASetText("Non Public Task Comments - Changed");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Navigate to File Notes screen, validate task comments";
                FastDriver.FileNotes.Open();
                Support.AreEqual(true, FastDriver.FileNotes.Table.StringExistOnTable(MyTaskName1), "Task Name");
                Support.AreEqual(true, FastDriver.FileNotes.Table.StringExistOnTable("Public WF Task Comments Changed"), "Public Task Comments");
                Support.AreEqual(true, FastDriver.FileNotes.Table.StringExistOnTable("Non Public Task Comments - Changed"), "Non Public Task Comments");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_BAT0007
        [TestMethod]
        public void FPUC0012_BAT0007()
        {
            //Combined: FPUC0012_BAT0015, FPUC0012_BAT0016, Start Task When Deliver Document

            try
            {
                Reports.TestDescription = @"AF17_00: Update a Task Status via a Task Event; AF18_00: Update a Task that Triggers a File Event";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                string processName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string processType = "1099";
                string taskName = "Start Task When Deliver Document";
                string templateName = "Accomm Signing-Customer Buyer";
                PropertyAddressParameters addr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();
                
                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(processName, processType))
                    this.CreateNewProcessAndTasks(processName: processName, taskName: taskName, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(addr);

                Reports.TestStep = "Navigate to Document Repository screen, add escrow instruction 'Accomm Signing-Customer Buyer'";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.DocumentRepository.FindNow.FAClick();
                FastDriver.DocumentRepository.WaitForDocumentRepositoryTemplatesScreenToLoad(FastDriver.DocumentRepository.SearchTable);
                FastDriver.DocumentRepository.SearchTable.PerformTableAction(2, templateName, 2, TableAction.Click);
                FastDriver.DocumentRepository.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Deliver (print) the escrow instruction 'Accomm Signing-Customer Buyer'";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 4, TableAction.Click);
                FastDriver.Delivery.Perform(FADeliveryMethod.Print);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);

                Reports.TestStep = "Navigate to File Workflow screen, validate 'Start Task When Deliver Document' is started";
                FastDriver.FileWorkflow.Open();
                if (!FastDriver.FileWorkflow.CheckIfProcessIsPulled(processName))
                {
                    Playback.Wait(10000);
                    FastDriver.FileWorkflow.Open();
                }
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                if (!FastDriver.FileWorkflow.IsTaskStarted("Start Task When Deliver Document"))
                {
                    // Sometimes it takes a few seconds for the task to update, so wait 30 seconds and try again
                    Playback.Wait(30000);
                    FastDriver.FileWorkflow.Open();
                }
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskStarted("Start Task When Deliver Document"), "Start Task When Deliver Document");

                Reports.TestStep = "Complete the task";
                FastDriver.FileWorkflow.PeformActionOnTask(taskName, TableAction.On, 2);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Navigate to Event Tracking Log, validate SIU event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Workflow");
                FastDriver.EventTrackingLog.WaitForScreenToLoad(FastDriver.EventTrackingLog.EventTable);
                string expectedValue = @"File Number: " + FileNumber + @" Task Status: Completed Recipients: SIU";
                
                if (!FastDriver.EventTrackingLog.EventTable.StringExistOnTable(expectedValue))
                {
                    Playback.Wait(10000);
                    FastDriver.EventTrackingLog.Open();
                    FastDriver.EventTrackingLog.EventCategory.FASelectItem("Workflow");
                    FastDriver.EventTrackingLog.WaitForScreenToLoad(FastDriver.EventTrackingLog.EventTable);
                }

                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.StringExistOnTable(expectedValue), "Event sent to SIU: " + expectedValue);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_BAT0008
        [TestMethod]
        public void FPUC0012_BAT0008()
        {
            //Combined: FPUC0012_BAT0017

            try
            {
                Reports.TestDescription = @"AF19_00: Auto-Waive Tasks When File is Cancelled";

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Cancel";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");
                // Set Status Date to universal time as it will fail if run in offshore box. System automatically default this field to current date
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Today.ToUniversalTime().AddHours(-8).ToDateString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);

                Reports.TestStep = "Validate all processes have been waived";
                FastDriver.FileWorkflow.Open();

                if (!FastDriver.FileWorkflow.Waive.IsDisplayed())
                {
                    Playback.Wait(10000);
                    FastDriver.FileWorkflow.Open();
                }

                Support.AreEqual(true, FastDriver.FileWorkflow.GetWaiveStatus(), "Process is waived");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_BAT0009
        [TestMethod]
        public void FPUC0012_BAT0009()
        {
            //Combined: FPUC0012_BAT0018, FPUC0012_BAT0019; FPUC0012_REG0019

            try
            {
                Reports.TestDescription = @"AF11_00: Add a Misc. Task on File Workflow Section; AF13_00: Delete a Task on File Workflow Dialog; 3134_EW2: Delete a Task on File Workflow Dialog";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyMiscTaskName = "Misc Task Name";
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All and Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Select a task and click Add Task";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.Click, 5);
                FastDriver.FileWorkflow.AddTask.FAClick();

                    Reports.TestStep = "Click View More, click Add Misc";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.AddMisc.FAClick();

                Reports.TestStep = "Enter task name, click Done";
                FastDriver.AddNewMiscellaneousTaskDlg.WaitForScreenToLoad();
                FastDriver.AddNewMiscellaneousTaskDlg.Name.FASetText(MyMiscTaskName);
                FastDriver.AddNewMiscellaneousTaskDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Validate Misc task has been added to workflow";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(MyMiscTaskName, FastDriver.FileWorkflow.PeformActionOnTask(MyMiscTaskName, TableAction.GetText, 5).Message.Clean(), MyMiscTaskName);

                Reports.TestStep = "Select the Misc task and click Remove";
                FastDriver.FileWorkflow.PeformActionOnTask(MyMiscTaskName, TableAction.Click, 5);
                FastDriver.FileWorkflow.RemoveTask.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Validate Misc task is no longer on table";
                Support.AreEqual("Task is not on table", FastDriver.FileWorkflow.GetWorkFlowTableID(MyMiscTaskName), "Task is not on table");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_REG0001
        [TestMethod]
        public void FPUC0012_REG0001()
        {
            //Combined: FPUC0012_REG0001, FPUC0012_REG0002

            try
            {
                Reports.TestDescription = @"4727_3111_3112_8996: Validating basic functionality of file workflow";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                string processName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string processType = "1099";
                string taskName = "Start Task When Deliver Document";
                string MyGABCode = "BOA";

                PropertyAddressParameters addr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(processName, processType))
                    this.CreateNewProcessAndTasks(processName: processName, taskName: taskName, taskEvent: true);
                else
                {
                    FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                    FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processName, 2, TableAction.Click);
                    FastDriver.RegionalProcessSummary.Edit.FAClick();
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                }
                    FastDriver.WebDriver.Quit();


                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(addr, MyGABCode);

                Reports.TestStep = "Validate that Priority check box is present";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                Support.AreEqual(true, FastDriver.FileWorkflow.PriorityProcess.IsDisplayed(), "Priority checkbox present");
                FastDriver.FileWorkflow.PriorityProcess.FASetCheckbox(true);

                Reports.TestStep = "Start one of the task";
                FastDriver.FileWorkflow.PeformActionOnTask(taskName, TableAction.On, 1);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Navigate to My Fast Today screen, select Accounting workgroup";
                FastDriver.MyFASTToday.Open();
                FastDriver.MyFASTToday.AddRemoveWorkGroup.FAClick();
                FastDriver.WorkGroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkGroupSelectionDlg.WorkGroupTable.PerformTableAction(2, "Unassigned", 1, TableAction.On);
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();

                Reports.TestStep = "Select Task Status";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.TaskStatus.FASelectItem("Show started tasks only");

                Reports.TestStep = "Select Business Source GAB Code";
                if (!FastDriver.MyFASTToday.GABCode.IsVisible())
                    FastDriver.MyFASTToday.AddSearchFexpand.FAClick();
                FastDriver.MyFASTToday.GABCode.FASetText(MyGABCode);
                FastDriver.MyFASTToday.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Click Find Now button";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.MyFASTToday.WaitForTaskTableToLoad();

                Reports.TestStep = "Select the current task from the same file";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(4, FileNumber, 4, TableAction.Click);
                FastDriver.MyFASTToday.TasksSelect.FAClick();

                Reports.TestStep = "Validate Priority checkbox is present on File Workflow screen";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileWorkflow.PriorityProcess.IsDisplayed(), "Priority checkbox present");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_REG0002
        [TestMethod]
        public void FPUC0012_REG0002()
        {
            //Combined: FPUC0012_REG0004

            try
            {
                Reports.TestDescription = @"8995_8996_8999: Create File Workflow";

                #region data setup

                PropertyAddressParameters MyBadAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "Orange",
                    City = "Santa Ana",
                    Zip = "90027"
                };

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName = "Start Task When Deliver Document";

                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using a 'bad' address";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyBadAddr);

                Reports.TestStep = "Navigate to File Workflow screen, validate " + MyProcessName + " is not present";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual(false, FastDriver.FileWorkflow.CheckIfProcessIsPulled(MyProcessName), MyProcessName + " is not present");

                Reports.TestStep = "Create a file using a 'good' address";
                FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, validate " + MyProcessName + " is present";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual(true, FastDriver.FileWorkflow.CheckIfProcessIsPulled(MyProcessName), MyProcessName + " is present");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_REG0003
        [TestMethod]
        public void FPUC0012_REG0003()
        {
            //Combined: FPUC0012_REG0005; FPUC0012_REG0008

            try
            {
                Reports.TestDescription = @"4762_4777_6904_7096: Validating the functinality of task sort, down and up of task, adding comments editing the task, deleting and checking event log; 4864: Validate the sequence of the task in fileworkflow screen";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyTaskName2 = "Task 2";
                string MyTaskName3 = "Task 3";

                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                
                #region task sort
                Reports.TestStep = "Validate tasks are sorted properly according to ADM setup";
                Support.AreEqual("1", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.GetText, 4).Message, "Position 1");
                Support.AreEqual("2", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.GetText, 4).Message, "Position 2");
                Support.AreEqual("3", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName3, TableAction.GetText, 4).Message, "Position 3");
                #endregion

                #region Move task up/down
                Reports.TestStep = "Select the second task and click Up button";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.Click, 5);
                FastDriver.FileWorkflow.Up.FAClick();

                Reports.TestStep = "Validate the second task have been moved to the first position, and task 1 moved down one position";
                Support.AreEqual("1", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.GetText, 4).Message, "Tasks 2 moved up to postion 1");
                Support.AreEqual("2", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.GetText, 4).Message, "Tasks 1 moved down to postion 2");

                Reports.TestStep = "Select the first task and click Down button";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.Click, 5);
                FastDriver.FileWorkflow.Down.FAClick();

                Reports.TestStep = "Validate task 1 & 2 has moved back to their original positions";
                Support.AreEqual("1", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.GetText, 4).Message, "Tasks 1 moved up to postion 1");
                Support.AreEqual("2", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.GetText, 4).Message, "Tasks 2 moved down to postion 2");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }
        #endregion

        #region FPUC0012_REG0004
        [TestMethod]
        public void FPUC0012_REG0004()
        {
            //Combined: FPUC0012_REG0006

            try
            {
                Reports.TestDescription = @"FP6650_3120_7079_7080_4746_4747_FP4744_: Assign a Task to an Employee";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyWorkgroupName = "Accounting";
                string MyUserName = "QA06, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                string MyAssignedToOffice = "QA SANDPOINTE OFFICE";
                string MyEmployeeOffice = "QA Automation Office - DO NOT TOUCH";
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Assign Task Office, Workgroup, and Employee to task";
                FastDriver.FileWorkflow.AssignedTaskOfficeToTask(MyTaskName1, MyAssignedToOffice);
                FastDriver.FileWorkflow.AssignedWorkgroupToTask(MyTaskName1, MyWorkgroupName);
                FastDriver.FileWorkflow.AssignedEmployeeToTask(MyTaskName1, MyEmployeeOffice, MyUserName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Click Event Log button, validate event log";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual("Task: " + MyTaskName1 + " To: " + MyAssignedToOffice, FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Office Assigned]", 5, TableAction.GetText).Message.Clean(), "[Task Office Assigned]");
                Support.AreEqual("Task: " + MyTaskName1 + " To: " + MyWorkgroupName, FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Workgroup Assigned]", 5, TableAction.GetText).Message.Clean(), "[Task Workgroup Assigned]");
                Support.AreEqual("Task: " + MyTaskName1 + " To: " + MyUserNameFormatted, FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Owner Assigned]", 5, TableAction.GetText).Message.Clean(), "[Task Owner Assigned]");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "6652- Verify the user is NOT able to remove the Production office from file,If one or more active task are assigned to that Production Office";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveEscrowProdOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Region.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad("", FastDriver.OfficeSelectionDlg.OfficesTable);
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction(2, MyAssignedToOffice, 1, TableAction.Off);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Click Save button, validate error message";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10, false);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.Errormessage.FAGetAttribute("innerHTML").Contains("The following production office(s) cannot be removed from the file because tasks are assigned to the office(s)."), "Can't remove office");
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5, true);

                Reports.TestStep = "9758-Verify the Task Owning Office has changed for a task in FileWork flow if the user changes owning office in file ";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.HandlingWarningmsg(VerifyMessage: "", Yes_No: "Yes");
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to File Workflow screen, validate task office has changed";
                FastDriver.FileWorkflow.Open();
                Support.AreEqual("JVR Office", FastDriver.FileWorkflow.PeformActionOnTask("Task 2", TableAction.GetText, 6).Message.Clean(), "Task Office");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FPUC0012_REG0005
        [TestMethod]
        public void FPUC0012_REG0005()
        {
            //Combined: FPUC0012_REG0009

            try
            {
                Reports.TestDescription = @"6651_6653: Protect task office on completed and waived tasks and validate that on pointing the cursor to task office, it shows the office name";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyTaskName2 = "Task 2";
                string MyTaskName3 = "Task 3";
                string MyUserName = "QA06, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Complete 'Task 2' and waive 'Task 3'";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.On, 2);
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName3, TableAction.On, 3);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Validate the change task office icon is disabled for both tasks";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskDisabled(MyTaskName2), "Task 2 is disabled");
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskDisabled(MyTaskName3), "Task 3 is disabled");

                Reports.TestStep = "Hover the mouse over the task office";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.GetCell, 6).Element.FAFindElement(ByLocator.XPath, "./span").FAMoveToElement();
                Support.AreEqual("QA Automation Office - DO NOT TOUCH", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.GetCell, 6).Element.FAFindElement(ByLocator.XPath, "./span").FAGetAttribute("title"), "Tool tips displayed");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FPUC0012_REG0006
        [TestMethod]
        public void FPUC0012_REG0006()
        {
            //Combined: FPUC0012_REG0010

            try
            {
                Reports.TestDescription = @"FP6654: Assign Workgroup to a Task; FP6655: Show default workgroup; FP6657: Change workgroup; FP6658: Assign a workgroup";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyTaskName4 = "Task Inactive";
                string MyUserName = "QA06, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                string MyWorkgroupName = "Accounting";
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Check default workgroup";
                Support.AreEqual("Multiple", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName4, TableAction.GetInputValue, 8).Message.Clean(), "Default workgroup");

                Reports.TestStep = "Assign a workgroup to " + MyTaskName1 + " validate workgroup name";
                FastDriver.FileWorkflow.AssignedWorkgroupToTask(MyTaskName1, MyWorkgroupName);
                Support.AreEqual(MyWorkgroupName, FastDriver.FileWorkflow.GetAssignedWorkgroup(MyTaskName1), MyWorkgroupName + " workgroup");

                Reports.TestStep = "Change office name and validate workgroup name";
                FastDriver.FileWorkflow.AssignedWorkgroupToTask(MyTaskName1, "Agency");
                Support.AreEqual("Agency", FastDriver.FileWorkflow.GetAssignedWorkgroup(MyTaskName1), "Agency workgroup");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FPUC0012_REG0007
        [TestMethod]
        public void FPUC0012_REG0007()
        {
            //Combined: FPUC0012_REG0012

            try
            {
                Reports.TestDescription = @"FP3117: Start A Task; FP4729: Start Assignment; FP6664: Assign Auto Started Tasks to an Employee; FP5455: Assign a Started Task to Another Employee";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyUserName = "QA06, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                string MyOfficeName = "QA Automation Office - DO NOT TOUCH";
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Start a task and validate it is automatically assigned to the current user";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.On, 1);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("QA07, FAST", FastDriver.FileWorkflow.GetAssignedToUser(MyTaskName1), "Current User");

                Reports.TestStep = "Reassign the task to another employee, validate user name updated";
                FastDriver.FileWorkflow.AssignedEmployeeToTask(MyTaskName1, MyOfficeName, MyUserName);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(MyUserName, FastDriver.FileWorkflow.GetAssignedToUser(MyTaskName1), "New User");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FPUC0012_REG0008
        [TestMethod]
        public void FPUC0012_REG0008()
        {
            //Combined: FPUC0012_REG0014, FPUC0012_REG0015

            try
            {
                Reports.TestDescription = @"FP4765: Delete Warnings & Alerts on Completed Task";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyUserName = "QA06, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Select task 1 and click Details button";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.Click, 5);
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Enter Warn Date and Due Date";
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                FastDriver.TaskDetailsDlg.WarnDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.TaskDetailsDlg.DueDate.FASetText(DateTime.Now.AddDays(1).ToDateString());
                FastDriver.TaskDetailsDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Validate a warning has been created for the task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileWorkflow.MessagesTable.StringExistOnTable("Warning for Task: " + MyTaskName1), "Warning for task " + MyTaskName1);

                Reports.TestStep = "Complete the task";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.On, 2);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Validate the alert has been removed";
                Support.AreEqual(false, FastDriver.FileWorkflow.MessagesTable.StringExistOnTable("Warning for Task: " + MyTaskName1), "Warning for task " + MyTaskName1);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FPUC0012_REG0009
        [TestMethod]
        public void FPUC0012_REG0009()
        {
            //Combined: FPUC0012_REG0016, FPUC0012_REG0017_PH

            try
            {
                Reports.TestDescription = @"FP3954: Waive A Task; FP4735: Waived Assignment";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyUserName = "QA07, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Waive the first task";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.On, 3);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Validate the task is waived and it's assigned to the current user, and the task is disabled";
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskWaived(MyTaskName1), "Task waived " + MyTaskName1);
                Support.AreEqual(MyUserName, FastDriver.FileWorkflow.GetAssignedToUser(MyTaskName1), "Assigned to current user");
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskDisabled(MyTaskName1), "Task disabled " + MyTaskName1);

                Reports.TestStep = "Select the task and click the Details button";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.Click, 5);
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Validate the task's Started Date is blank";
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.TaskDetailsDlg.TaskDatesTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean(), "Started Date is blank");
                FastDriver.TaskDetailsDlg.Done.FAClick();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FPUC0012_REG0010
        [TestMethod]
        public void FPUC0012_REG0010()
        {
            //Combined: FPUC0012_REG0018

            try
            {
                Reports.TestDescription = @"FP5457: Waiving a Started Task";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyUserName = "QA07, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Start the first task";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.On, 1);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Waive the first task";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.On, 3);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Select the task and click the Details button";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.Click, 5);
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Validate the task's Started Date and Waived Date are populated";
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.TaskDetailsDlg.TaskDatesTable.PerformTableAction(2, 2, TableAction.GetText).Message.Contains(DateTime.Now.ToDateString()), "Started Date is populated");
                Support.AreEqual(true, FastDriver.TaskDetailsDlg.TaskDatesTable.PerformTableAction(2, 4, TableAction.GetText).Message.Contains(DateTime.Now.ToDateString()), "Waived Date is populated");
                FastDriver.TaskDetailsDlg.Done.FAClick();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FPUC0012_REG0011
        [TestMethod]
        public void FPUC0012_REG0011()
        {
            //Combined: FPUC0012_REG0021

            try
            {
                Reports.TestDescription = @"FP3996: Add One or More Tasks to File Workflow; FP9009: Location for Inserting New Tasks; FP9012: Add Tasks From a Specific Process";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyTaskName2 = "Task 2";
                string MyTaskName3 = "Task 3";
                string MyTaskName4 = "Task Inactive";
                string MyUserName = "QA07, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true, fileEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {

                    Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                    FastDriver.FileWorkflow.Open();
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                    Reports.TestStep = "Validate the Add Task button is disabled if no task is selected";
                    Support.AreEqual(false, FastDriver.FileWorkflow.AddTask.IsEnabled(), "Add Task button is disabled");
                    return FastDriver.FileWorkflow.Process.IsDisplayed();

                }, 60);

                Reports.TestStep = "Select task 4, click Add Task button";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName4, TableAction.Click, 5);
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Validate only tasks from " + MyProcessName + " process are available to add";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                Support.AreEqual(MyTaskName1, FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(2, MyTaskName1, 2, TableAction.GetText).Message.Clean());
                Support.AreEqual(MyTaskName2, FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(2, MyTaskName2, 2, TableAction.GetText).Message.Clean());
                Support.AreEqual(MyTaskName3, FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(2, MyTaskName3, 2, TableAction.GetText).Message.Clean());
                Support.AreEqual(MyTaskName4, FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(2, MyTaskName4, 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Select task 1, click Select button";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(2, MyTaskName1, 1, TableAction.On);
                FastDriver.AddTasksfromProcessTemplateScreenDlg.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Validate task has been added to position # 5";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("5", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.GetText, 4, startRow: 2).Message.Clean(), "Task is added to postion # 5");

                Reports.TestStep = "Add another task after position # 3";
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName3, TableAction.Click, 5);
                FastDriver.FileWorkflow.AddTask.FAClick();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(2, MyTaskName1, 1, TableAction.On);
                FastDriver.AddTasksfromProcessTemplateScreenDlg.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Validate the task has been added to position # 4";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("4", FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.GetText, 4, startRow: 2).Message.Clean(), "Task is added to postion # 4");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FPUC0012_REG0012
        //Team                      : SRT-Team2
        //Iteration                 : r07
        //UserStory                 : User Story 691611: INC2323018 FAST - Title Production Process is not staying assigned to Agency
        // TestCase                 : 714987
        //Appended By/ Created By   : Diego Hilario

        [TestMethod]
        public void FPUC0012_REG0012()
        {
            try
            {
                Reports.TestDescription = "Validate Title Production Process remains assigned to Agency";

                #region data setup

                string processName1 = "US691611 Title Owning Process";
                string processType1 = "Title Production";

                string processName2 = "US691611 Escrow Owning Process";
                string processType2 = "Escrow";

                #endregion

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                #region createTitleOwningProcess
                Reports.TestStep = "Check if the process exist, if not exist create it";
                FastDriver.RegionalProcessSummary.Open();

                //Check if the process exist, if not exist create it
                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(processName1, processType1))
                {
                    FastDriver.RegionalProcessSummary.New.FAClick();
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.ProcessType.FASelectItem(processType1);
                    FastDriver.RegionalProcessEdit.ProcessName.FASetText(processName1);
                    FastDriver.RegionalProcessEdit.Description.FASetText("Verifying US691611");
                    FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
                    FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                    FastDriver.SelectionCriteriaDlg.TranType.FASelectItem("Sale w/Mortgage");
                    FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();

                    Reports.TestStep = "Change states from all to another state";
                    FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                    FastDriver.StateSelectionDlg.Clear.FAClick();
                    FastDriver.StateSelectionDlg.table.PerformTableAction(40, 1, TableAction.On);
                    FastDriver.StateSelectionDlg.Select.FAClick();
                    FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                    FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();

                    Reports.TestStep = "Change county from all to another county";
                    FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                    FastDriver.CountySelectionDlg.Clear.FAClick();
                    FastDriver.CountySelectionDlg.Table.PerformTableAction(9, 1, TableAction.On);
                    FastDriver.CountySelectionDlg.Select.FAClick();
                    FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                    FastDriver.SelectionCriteriaDlg.Done.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                    Reports.TestStep = "Add Tasks and select Title Owning Office as Task Office";
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.Add.FAClick();
                    FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(1, 3, TableAction.Click);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(2, 3, TableAction.Click);

                    FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                    FastDriver.RegionalProcessEdit.TaskOffice.FASelectItem("Title Owning Office");
                    FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, 2, TableAction.Click);
                    FastDriver.RegionalProcessEdit.TaskOffice.FASelectItem("Title Owning Office");

                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Activate the created process";
                    FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                    FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processName1, 2, TableAction.Click);
                    FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                    FastDriver.StatusEdit.WaitForScreenToLoad();
                    FastDriver.StatusEdit.Deactivate.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                    FastDriver.PendingRefreshSummary.RefreshProcessTemplate(processName1);
                }
                
                #endregion

                #region CreateEscrowOwningProcess
                Reports.TestStep = "Create Process for Order";
                FastDriver.RegionalProcessSummary.Open();

                //Check if the process exist, if not exist create it
                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(processName2, processType2))
                {
                    FastDriver.RegionalProcessSummary.New.FAClick();
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.ProcessType.FASelectItem(processType2);
                    FastDriver.RegionalProcessEdit.ProcessName.FASetText(processName2);
                    FastDriver.RegionalProcessEdit.Description.FASetText("Verifying US691611");
                    FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
                    FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                    FastDriver.SelectionCriteriaDlg.TranType.FASelectItem("Sale w/Mortgage");
                    FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();

                    Reports.TestStep = "Change states from all to another state";
                    FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                    FastDriver.StateSelectionDlg.Clear.FAClick();
                    FastDriver.StateSelectionDlg.table.PerformTableAction(40, 1, TableAction.On);
                    FastDriver.StateSelectionDlg.Select.FAClick();
                    FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                    FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();

                    Reports.TestStep = "Change county from all to another county";
                    FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                    FastDriver.CountySelectionDlg.Clear.FAClick();
                    FastDriver.CountySelectionDlg.Table.PerformTableAction(9, 1, TableAction.On);
                    FastDriver.CountySelectionDlg.Select.FAClick();
                    FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                    FastDriver.SelectionCriteriaDlg.Done.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                    Reports.TestStep = "Add Tasks and select Title Owning Office as Task Office";
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.Add.FAClick();
                    FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(1, 3, TableAction.Click);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(2, 3, TableAction.Click);

                    FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                    FastDriver.RegionalProcessEdit.TaskOffice.FASelectItem("Escrow Owning Office");
                    FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, 2, TableAction.SelectItem);
                    FastDriver.RegionalProcessEdit.TaskOffice.FASelectItem("Escrow Owning Office");

                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Activate the created process";
                    FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                    FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processName2, 2, TableAction.Click);
                    FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                    FastDriver.StatusEdit.WaitForScreenToLoad();
                    FastDriver.StatusEdit.Deactivate.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                    FastDriver.PendingRefreshSummary.RefreshProcessTemplate(processName2);
                }
                
                #endregion

                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log in to IIS";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic Title/Escrow file which compiles with Process filter criteria";
                #region createFile
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.Properties = new FASTWCFHelpers.FastFileService.Property[]
                {
                    new FASTWCFHelpers.FastFileService.Property()
                    {
                        PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                        {
                            new FASTWCFHelpers.FastFileService.PhysicalAddress()
                            {
                                State = "NJ",
                                County = "HUDSON",
                                Country = "USA",
                            }
                        }
                    }
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to File Workflow screen";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"File Workflow").WaitForScreenToLoad();

                Reports.TestStep = "Validate Process are assigned to their respective Owning Offices";
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.AddProcess.FAClick();
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, "Title Production", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                FastDriver.FileWorkflow.AddProcess.FAClick();
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, "Escrow", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                var tableTitleID = FastDriver.FileWorkflow.GetWorkFlowTableID(processName1);
                var tableTitle = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, tableTitleID);
                Support.AreEqual("True", tableTitle.PerformTableAction(1, 6, TableAction.GetText).Message.Clean().Contains("QA Automation Office -").ToString(), "Verifying Office is the correct office");
                Support.AreEqual("True", tableTitle.PerformTableAction(2, 6, TableAction.GetText).Message.Clean().Contains("QA Automation Office -").ToString(), "Verifying Office is the correct office");

                var tableEscrowID = FastDriver.FileWorkflow.GetWorkFlowTableID(processName2);
                var tableEscrow = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, tableEscrowID);
                Support.AreEqual("True", tableEscrow.PerformTableAction(1, 6, TableAction.GetText).Message.Clean().Contains("QA Automation Office -").ToString(), "Verifying Office is the correct office");
                Support.AreEqual("True", tableEscrow.PerformTableAction(2, 6, TableAction.GetText).Message.Clean().Contains("QA Automation Office -").ToString(), "Verifying Office is the correct office");

                Reports.TestStep = "Navigate to File Homepage screen";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Click on Change OO button";
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();

                Reports.TestStep = "Change Escrow Owning Office to another Office";
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();
                FastDriver.WarningDlg.Handle(true);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Playback.Wait(15000);

                Reports.TestStep = "Navigate to Workflow screen and validate Task Office change for process";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                tableTitleID = FastDriver.FileWorkflow.GetWorkFlowTableID(processName1);
                tableTitle = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, tableTitleID);
                Support.AreEqual("True", tableTitle.PerformTableAction(1, 6, TableAction.GetText).Message.Clean().Contains("QA Automation Office -").ToString(), "Verifying is NOT changing");
                Support.AreEqual("True", tableTitle.PerformTableAction(2, 6, TableAction.GetText).Message.Clean().Contains("QA Automation Office -").ToString(), "Verifying is NOT changing");

                tableEscrowID = FastDriver.FileWorkflow.GetWorkFlowTableID(processName2);
                tableEscrow = FastDriver.FileWorkflow.ProcessTable.FAFindElement(ByLocator.Id, tableEscrowID);
                Support.AreEqual("True", tableEscrow.PerformTableAction(1, 6, TableAction.GetText).Message.Clean().Contains("JVR Office").ToString(), "Verifying Office is changed correctly");
                Support.AreEqual("True", tableEscrow.PerformTableAction(2, 6, TableAction.GetText).Message.Clean().Contains("JVR Office").ToString(), "Verifying Office is changed correctly");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region Private Class Methods

        private void LoginFastFileSite(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private string CreateBasicFileWithSpecifiedGAB(string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File.FileNumber;
        }

        private string CreateBasicFileWithSpecifiedGABAndAddress(PropertyAddressParameters physicalAddr, string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = physicalAddr.State,
                            City = physicalAddr.City,
                            County = physicalAddr.County,
                            Country = physicalAddr.Country,
                            AddrLine1 = physicalAddr.StreetLine1,
                            AddrLine2 = physicalAddr.StreetLine2,
                            AddrLine3 = physicalAddr.StreetLine3
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File.FileNumber;
        }

        private void CreateNewProcessAndTasks(string processName, string taskName, bool taskEvent = false, bool fileEvent = true) 
        {

            Reports.TestStep = "Click New and enter process info";
            FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.New.FAClick();
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.ProcessType.FASelectItem("1099");
            FastDriver.RegionalProcessEdit.ProcessName.FASetText(processName);
            FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();

            Reports.TestStep = "Select state";
            FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();
            FastDriver.StateSelectionDlg.WaitForScreenToLoad();
            FastDriver.StateSelectionDlg.Clear.FAClick();
            FastDriver.StateSelectionDlg.table.PerformTableAction(2, "CA", 1, TableAction.On);
            FastDriver.StateSelectionDlg.Select.FAClick();

            Reports.TestStep = "Select county";
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();
            FastDriver.CountySelectionDlg.WaitForScreenToLoad();
            FastDriver.CountySelectionDlg.Clear.FAClick();
            FastDriver.CountySelectionDlg.Table.PerformTableAction(2, "AMADOR", 1, TableAction.On);
            FastDriver.CountySelectionDlg.Select.FAClick();

            Reports.TestStep = "Select city";
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.AddRemoveCity.FAClick();
            FastDriver.CitySelectionDlg.WaitForScreenToLoad();
            FastDriver.CitySelectionDlg.Clear.FAClick();
            FastDriver.CitySelectionDlg.CityTable.PerformTableAction(2, "AMADOR CITY", 1, TableAction.On);
            FastDriver.CitySelectionDlg.Select.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.Done.FAClick();

            Reports.TestStep = "Select process event";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
            FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
            FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "File created with Open status", 1, TableAction.On);
            FastDriver.DialogBottomFrame.ClickDone();

            Reports.TestStep = "Add new task";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.Add.FAClick();
            FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
            int rowCount = 0;
            if (!FastDriver.TaskTemplateSelectionDlg.TasksForTable.StringExistOnTable(taskName))
            {
                FastDriver.TaskTemplateSelectionDlg.New.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad(element: FastDriver.TaskTemplateSelectionDlg.TasksForTable);
                rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 3, TableAction.SetText, taskName);
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 5, TableAction.SelectItem, "Yes");
                Playback.Wait(2000);
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 4, TableAction.SetText, taskName);
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 2, TableAction.On);
            }
            else
            {
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, taskName, 2, TableAction.On);
            }

            Reports.TestStep = "Add new task # 2";
            if (!FastDriver.TaskTemplateSelectionDlg.TasksForTable.StringExistOnTable("Task 2"))
            {
                FastDriver.TaskTemplateSelectionDlg.New.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad(element: FastDriver.TaskTemplateSelectionDlg.TasksForTable);
                rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 3, TableAction.SetText, "Task 2");
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 2, TableAction.On);
            }
            else
            {
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, "Task 2", 2, TableAction.On);
            }

            Reports.TestStep = "Add new task # 3";
            if (!FastDriver.TaskTemplateSelectionDlg.TasksForTable.StringExistOnTable("Task 3"))
            {
                FastDriver.TaskTemplateSelectionDlg.New.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad(element: FastDriver.TaskTemplateSelectionDlg.TasksForTable);
                rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 3, TableAction.SetText, "Task 3");
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 2, TableAction.On);
            }
            else
            {
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, "Task 3", 2, TableAction.On);
            }

            Reports.TestStep = "Add multiple workgroup to Task inactive";
            
            if (!FastDriver.TaskTemplateSelectionDlg.TasksForTable.StringExistOnTable("Task Inactive"))
            {
                FastDriver.TaskTemplateSelectionDlg.New.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad(element: FastDriver.TaskTemplateSelectionDlg.TasksForTable);
                rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 3, TableAction.SetText, "Task Inactive");
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 2, TableAction.On);
            }
            else
            {
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, "Task Inactive", 2, TableAction.On);
            }

            FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

            if (taskEvent)
            {

                Reports.TestStep = "Set task event action";
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, taskName, 2, TableAction.Click);
                FastDriver.RegionalProcessEdit.TaskEventAction.FASelectItem("Start");
                FastDriver.RegionalProcessEdit.SelTaskEvent.FASelectItem("Document Delivered");
                FastDriver.RegionalProcessEdit.TaskEventSetup.FAClick();

                Reports.TestStep = "Setup document delivery task event";
                FastDriver.DocumentDeliveryTaskEventSetupDlg.WaitForScreenToLoad();
                FastDriver.DocumentDeliveryTaskEventSetupDlg.DeliveryMethods.FASelectItem("PRINT");
                FastDriver.DocumentDeliveryTaskEventSetupDlg.DeliveryMethods.FASelectItem("FAX");
                FastDriver.DocumentDeliveryTaskEventSetupDlg.DeliveryMethods.FASelectItem("EMAIL");
                FastDriver.DocumentDeliveryTaskEventSetupDlg.DeliveryMethods.FASelectItem("PRINT PREVIEW");
                FastDriver.DocumentDeliveryTaskEventSetupDlg.Add.FAClick();
                FastDriver.DocumentDeliverySelectionDlg.WaitForScreenToLoad();
                FastDriver.DocumentDeliverySelectionDlg.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.DocumentDeliverySelectionDlg.TemplateDescription.FASetText("Accomm Signing-Customer Buyer");
                FastDriver.DocumentDeliverySelectionDlg.FindNow.FAClick();
                FastDriver.DocumentDeliverySelectionDlg.SearchResultsTable.PerformTableAction(3, "Accomm Signing-Customer Buyer", 1, TableAction.On);
                FastDriver.DocumentDeliverySelectionDlg.SelectTemplates.FAClick();
                FastDriver.DocumentDeliveryTaskEventSetupDlg.WaitForScreenToLoad();
                FastDriver.DocumentDeliveryTaskEventSetupDlg.Done.FAClick();
            }

            if (fileEvent)
            {
                Reports.TestStep = "Setup file event";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.WhenStatusis.FASelectItem("Completed");
                FastDriver.RegionalProcessEdit.FileEvent.FASelectItem("Send info to SIU");
            }

            Reports.TestStep = "Inactivate the task and add multiple workgroups";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, "Task Inactive", 2, TableAction.Click);
            FastDriver.RegionalProcessEdit.Inactive.FASetCheckbox(true);
            FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
            
            FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
            FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
            FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
            FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItemByIndex(1);
            FastDriver.WorkgroupSelectionDlg.Select.FAClick();

            FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
            FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
            FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
            FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItemByIndex(2);
            FastDriver.WorkgroupSelectionDlg.Select.FAClick();

            FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
            FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(1, 1, TableAction.On);
            FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

            Reports.TestStep = "Enter notes";
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
            //FastDriver.NotesEntryDlg.WaitForScreenToLoad();
            //FastDriver.NotesEntryDlg.Notes.FASetText("Test");
            //FastDriver.NotesEntryDlg.Done.FAClick();

            Reports.TestStep = "Activate the process";
            FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processName, 1, TableAction.Click);
            FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
            FastDriver.StatusEdit.WaitForScreenToLoad();
            FastDriver.StatusEdit.Activate.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true);
            FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);
            FastDriver.RegionalProcessSummary.WaitForScreenToLoad();

            Reports.TestStep = "Refesh the process";
            FastDriver.PendingRefreshSummary.Open();
            FastDriver.PendingRefreshSummary.RefreshProcessTemplate(processName);
        }
        
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}