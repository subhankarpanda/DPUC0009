﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.Common;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;





namespace FileManagement
{
    [CodedUITest]
    public class FMUC0094 : MasterTestClass
    {
        #region BAT
        #region  FMUC0094_BAT0001

        [TestMethod]
        public void FMUC0094_BAT0001()
        {
            Reports.TestDescription = "FMUC0094_BAT0001: MF1_001: Check the Rate Type checkbox for fees.";
            Reports.StatusUpdate("FMUC0094_BAT0001:MF_00: MF1_001: Check the Rate Type checkbox for fees.: Functionality has covered in FMUC0094_REG003A", true);

        }
        #endregion

        #region  FMUC0094_BAT0002

        [TestMethod]
        public void FMUC0094_BAT0002()
        {
            Reports.TestDescription = "FMUC0094_BAT0002: MF1_01: Associate Policy Fee to its Endorsement(s).";
            Reports.StatusUpdate("FMUC0094_BAT0002:MF1_01: Associate Policy Fee to its Endorsement(s).: Functionality has covered in FMUC0094_REG003A", true);

        }
        #endregion

        #region  FMUC0094_BAT0003

        [TestMethod]
        public void FMUC0094_BAT0003()
        {
            Reports.TestDescription = "AF1_00: Deselect an Endorsement Fee.";
            Reports.StatusUpdate("FMUC0094_BAT0003:AF1_00: Deselect an Endorsement Fee.: Functionality has covered in FMUC0094_REG003A", true);

        }
        #endregion

        #region  FMUC0094_BAT0004

        [TestMethod]
        public void FMUC0094_BAT0004()
        {
            Reports.TestDescription = "AF1_00: AF3_00: Add and/or Edit a Policy Fee Rate Type.";
            Reports.StatusUpdate("FMUC0094_BAT0004:AF3_00: Add and/or Edit a Policy Fee Rate Type.: Functionality has covered in FMUC0094_REG003B", true);

        }
        #endregion

        #region  FMUC0094_BAT0005

        [TestMethod]
        public void FMUC0094_BAT0005()
        {
            Reports.TestDescription = "AF1_00: AF3_00: AF4_00: Associate a Policy Fee to a Loan (Liability Amount).";
            Reports.StatusUpdate("FMUC0094_BAT0005:AF3_00: AF4_00: Associate a Policy Fee to a Loan (Liability Amount).: Functionality has covered in FMUC0094_REG003A", true);

        }
        #endregion

        #region  FMUC0094_BAT0006

        [TestMethod]
        public void FMUC0094_BAT0006()
        {
            Reports.TestDescription = "AF5_00: Disassociate a Lender Policy Fee to a New Loan.";
            Reports.StatusUpdate("FMUC0094_BAT0006:AF5_00: Disassociate a Lender Policy Fee to a New Loan.: Functionality has covered in FMUC0094_REG003A", true);

        }
        #endregion

        #region  FMUC0094_BAT0007

        [TestMethod]
        public void FMUC0094_BAT0007()
        {
            Reports.TestDescription = "MF1_02: Deactivate the fee(set up).";
            Reports.StatusUpdate("FMUC0094_BAT0007 : MF1_02: Deactivate the fee(set up).: Functionality has covered in FMUC0094_REG003C", true);

        }
        #endregion

        #endregion

        #region REGRESSION

        #region FMUC0094_REG0003A


        [TestMethod]
        public void FMUC0094_REG0003A()
        {
            try
            {

                Reports.TestDescription = "Verify Association and De-Association of Loan and Endorsement Fee to Policy Fees";

                Reports.TestStep = "Login to Fast ADM Application";
                ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level and Select the QA Automation Region - DO NOT TOUCH";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                #region Create New Title Endorsement Policies

                Reports.TestStep = "Create 2 Title - Endorsement Fee Policy fee in Fee Setup. and Verify the fee status of 2 Endorsement fee and make it active";
                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                string TE1Fee_Des = Support.RandomString("ANANA");
                string TE1Fee_Code = Support.RandomString("ANANA");

                Reports.TestStep = "Create A Fee with in Fee Setup.";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(TE1Fee_Des, TE1Fee_Code, "Title - Endorsement Fee");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + TE1Fee_Des + " and Fee Description " + TE1Fee_Des;
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE1Fee_Code, "Title - Endorsement Fee", TE1Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TE1Fee_Code, 3, TableAction.Click);
                FastDriver.FeeList2.Edit.Click();
                FastDriver.FeeSetup.SwitchToContentFrame();

                Reports.TestStep = "Check the Government Reportable? Check Box";
                FastDriver.FeeSetup.FeeStatus.FASelectItem("Active");                
                FastDriver.BottomFrame.Done();
                
                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                string TE2Fee_Des = Support.RandomString("ANANA");
                string TE2Fee_Code = Support.RandomString("ANANA");

                Reports.TestStep = "Create A Fee with in Fee Setup.";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(TE2Fee_Des, TE2Fee_Code, "Title - Endorsement Fee");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + TE2Fee_Des + " and Fee Description " + TE2Fee_Des;
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE2Fee_Code, "Title - Endorsement Fee", TE2Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TE2Fee_Code, 3, TableAction.Click);
                FastDriver.FeeList2.Edit.Click();
                FastDriver.FeeSetup.SwitchToContentFrame();

                Reports.TestStep = "Check the Government Reportable? Check Box";
                FastDriver.FeeSetup.FeeStatus.FASelectItem("Active");
                FastDriver.BottomFrame.Done();


                #endregion
                

                Reports.TestStep = "Validated for QC Closing tab is enabled";               
                Reports.TestStep = "Enter QC Closing Gab Code and Verify QC Closing TAB.";

                Reports.TestStep = "Login to Fast IIS Application";
                IISLOGIN();

                Reports.TestStep = "Create file with title Only.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();

                fileRequest.File.Services = RequestFactory.GetServices(isTO: true, isEO: true, isSEO: false);
                var response2 = FileService.CreateFile(fileRequest);
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                                                 
                Reports.TestStep = "Add a new loan instance to the file";
                FastDriver.NewLoan.Open();                
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000");
                string LenderName = FastDriver.NewLoan.LenderName.FAGetText().Trim() + " " + FastDriver.NewLoan.BusinessPartyNameField2.FAGetText().Trim();

                FastDriver.BottomFrame.Done();
                                
                Reports.TestStep = "Validated for QC Closing tab is enabled";
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.QCClosingTab);
                Support.AreEqual(true.ToString(), FastDriver.NewLoan.QCClosingTab.IsEnabled().ToString());
                
                Reports.TestStep = "Enter the Transaction Type as Refinance in QC @ Closing Information Table";
                FastDriver.NewLoan.QCClosingTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.TransactionType);
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to the Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees);

                Reports.TestStep = "Enter the Buyer and Seller Charge for the New Home Rate Eagle Lender Policy-1";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "2.99");                

                Reports.TestStep = "Enter the Buyer and Seller Charge for the New Home Rate (Title Only)";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "3.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "4.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Endorsement Fee via Add Fee button";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(TE1Fee_Des); 
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Endorsement Fee -1";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE1Fee_Des, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE1Fee_Des, 4, TableAction.SetText, "3.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE1Fee_Des, 7, TableAction.SetText, "4.99");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Add Another Endorsement Fee via Add Fee button";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(TE2Fee_Des); 
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Endorsement Fee -2";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE2Fee_Des, 4, TableAction.SetText, "5.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE2Fee_Des, 7, TableAction.SetText, "6.99");
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to the Associate Fees Screen";
                FastDriver.LeftNavigation.Navigate<AssociateFeesReporting>("Home>Order Entry>Title/Escrow Fees>Associate Fees").SwitchToContentFrame();

                Reports.TestStep = "Verify the Policy Fee, Associate Loan to Loan Policy Fees and Endorsement Fee Details Table Information";
                Support.AreEqual("New Home Rate (Title Only)", FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.FAGetText());
                Support.AreEqual("$ 8.98", FastDriver.AssociateFeesReporting.FeeAmount1.FAGetText());
                
                Support.AreEqual("New Home Rate Eagle Lender Policy-1", FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1.FAGetText());
                Support.AreEqual("$ 4.98", FastDriver.AssociateFeesReporting.FeeAmount2.FAGetText());
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.Simlutaneous1.IsSelected().ToString());

                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.SelectLender.IsSelected().ToString());
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.SelectLender.IsEnabled().ToString());
                Support.AreEqual("1", FastDriver.AssociateFeesReporting.LoanNumber.FAGetText());
                Support.AreEqual(LenderName, FastDriver.AssociateFeesReporting.LenderName.FAGetText());
                Support.AreEqual("$ 1,000.00", FastDriver.AssociateFeesReporting.LiabilityAmount.FAGetText());

                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.Endorsement1Select.IsSelected().ToString());
                Support.AreEqual(true.ToString(), FastDriver.AssociateFeesReporting.Endorsement1Select.IsEnabled().ToString());
                Support.AreEqual(TE1Fee_Des, FastDriver.AssociateFeesReporting.Endorsement1Edit_L.FAGetText());
                Support.AreEqual("$ 9.84", FastDriver.AssociateFeesReporting.EndorsementFeeAmount1.FAGetText());

                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.Endorsement2Select.IsSelected().ToString());
                Support.AreEqual(true.ToString(), FastDriver.AssociateFeesReporting.Endorsement2Select.IsEnabled().ToString());
                Support.AreEqual(TE2Fee_Des, FastDriver.AssociateFeesReporting.Endorsement1Edit_O.FAGetText());
                Support.AreEqual("$ 14.23", FastDriver.AssociateFeesReporting.EndorsementFeeAmount2.FAGetText());

                #region Verify Associate and Deselect of Endorsement to Policy Fees

                Reports.TestStep = "Verify Associate Endorsement to Policy Fees.";
                Reports.TestStep = "Associate Endorsement1 Fee to Policy1";
                FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.FAClick();
                FastDriver.AssociateFeesReporting.EndorsementFeesTable.PerformTableAction(2, TE1Fee_Des, 1, TableAction.On);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify that Endorsement1 is Associated to Policy1";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);
                FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1.FAClick();
                Support.AreEqual(false.ToString(),FastDriver.AssociateFeesReporting.Endorsement1Select.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.AssociateFeesReporting.Endorsement1Select.IsSelected().ToString());
                
                Reports.TestStep = "Associate Endorsement1 Fee to Policy2";
                FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.FAClick();
                FastDriver.AssociateFeesReporting.Endorsement1Select.FASetCheckbox(false);
                FastDriver.AssociateFeesReporting.PolicyFeesTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 1, TableAction.Click);
                FastDriver.AssociateFeesReporting.Endorsement1Select.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify that Endorsement1 is Associated to Policy2";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);
                FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.FAClick();
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.Endorsement1Select.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.AssociateFeesReporting.Endorsement1Select.IsSelected().ToString());


                Reports.TestStep = "Deselect the associated Endorsement1 with Policy 2.";
                FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1.FAClick();
                FastDriver.AssociateFeesReporting.Endorsement1Select.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify that Deselect the associated Endorsement1 with Policy 2.";
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.Endorsement1Select.IsSelected().ToString());
                

                Reports.TestStep = "Associate Endorsement2 Fee to Policy1";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);
                FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.FAClick();
                FastDriver.AssociateFeesReporting.EndorsementFeesTable.PerformTableAction(2, TE2Fee_Des, 1, TableAction.On);
                FastDriver.AssociateFeesReporting.Endorsement2Select.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify that Endorsement2 is Associated to Policy1";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);
                FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1.FAClick();
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.Endorsement2Select.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.AssociateFeesReporting.Endorsement2Select.IsSelected().ToString());

                Reports.TestStep = "Associate Endorsement2 Fee to Policy2";
                FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.FAClick();
                FastDriver.AssociateFeesReporting.Endorsement2Select.FASetCheckbox(false);
                FastDriver.AssociateFeesReporting.PolicyFeesTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 1, TableAction.Click);
                FastDriver.AssociateFeesReporting.Endorsement2Select.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify that Endorsement2 is Associated to Policy2";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);
                FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.FAClick();
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.Endorsement2Select.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.AssociateFeesReporting.Endorsement2Select.IsSelected().ToString());
                
                Reports.TestStep = "Deselect the associated Endorsement1 with Policy 2.";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);
                FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1.FAClick();
                FastDriver.AssociateFeesReporting.Endorsement2Select.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify that Deselect the associated Endorsement1 with Policy 2.";
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.Endorsement2Select.IsSelected().ToString());
                
                #endregion

                #region Associate and De-Select of Loan to Loan Policy Fees

                Reports.TestStep = "Verify that Associate Loan to Loan Policy Fees Lender Checkbox will be Enabled only for Lender Policy Selection";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);
                FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1.FAClick();
                Support.AreEqual(true.ToString(), FastDriver.AssociateFeesReporting.SelectLender.IsEnabled().ToString());
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.SelectLender.IsSelected().ToString());

                Reports.TestStep = "Check In the Associate Loan to Loan Policy Fees Checkbox";
                FastDriver.AssociateFeesReporting.SelectLender.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify that Associate Loan to Loan Policy Fees Checkbox will be Checked and Disabled after Clicking the Policy Other than Lender";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);                
                FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.Click();
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.SelectLender.IsEnabled().ToString());
                Support.AreEqual(true.ToString(), FastDriver.AssociateFeesReporting.SelectLender.IsSelected().ToString());

                Reports.TestStep = "De-Select the Associate Loan to Loan Policy Fees from Lender Policy and Verify";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);
                FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1.FAClick();
                FastDriver.AssociateFeesReporting.SelectLender.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                Support.AreEqual(false.ToString(),FastDriver.AssociateFeesReporting.SelectLender.IsSelected().ToString());

                Reports.TestStep = "Verify the Associate Loan to Loan Policy Fees Checkbox after De-Select from Lender and Clicking the Non Lender Policy";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1);                
                FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.FAClick();                
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.SelectLender.IsEnabled().ToString());
                Support.AreEqual(false.ToString(), FastDriver.AssociateFeesReporting.SelectLender.IsSelected().ToString());

                #endregion
                

            }


            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }

        


        }

        #endregion

        #region FMUC0094_REG0003B


        [TestMethod]
        public void FMUC0094_REG0003B()
        {
            try
            {         

                Reports.TestDescription = "Add and/or Edit an Endorsement Fee Rate Type and Add and/or Edit a Policy Fee Rate Type";

                Reports.TestStep = "Login to Fast ADM Application";
                ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level and Select the QA Automation Region - DO NOT TOUCH";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                #region Create New Title Endorsement Policies

                Reports.TestStep = "Create 2 Title - Endorsement Fee Policy fee in Fee Setup. and Verify the fee status of 2 Endorsement fee and make it active";
                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                string TE1Fee_Des = Support.RandomString("ANANA");
                string TE1Fee_Code = Support.RandomString("ANANA");

                Reports.TestStep = "Create A Fee with in Fee Setup.";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(TE1Fee_Des, TE1Fee_Code, "Title - Endorsement Fee");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + TE1Fee_Des + " and Fee Description " + TE1Fee_Des;
                FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE1Fee_Code, "Title - Endorsement Fee", TE1Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TE1Fee_Code, 3, TableAction.Click);
                FastDriver.FeeList2.Edit.Click();
                FastDriver.FeeSetup.SwitchToContentFrame();

                Reports.TestStep = "Check the Government Reportable? Check Box";
                FastDriver.FeeSetup.GovtRep.FASetCheckbox(true);
                FastDriver.FeeSetup.RateType.FASetCheckbox(true);
                FastDriver.FeeSetup.TransactionCode.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                string TE2Fee_Des = Support.RandomString("ANANA");
                string TE2Fee_Code = Support.RandomString("ANANA");

                Reports.TestStep = "Create A Fee with in Fee Setup.";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(TE2Fee_Des, TE2Fee_Code, "Title - Endorsement Fee");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + TE2Fee_Des + " and Fee Description " + TE2Fee_Des;
                FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE2Fee_Code, "Title - Endorsement Fee", TE2Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TE2Fee_Code, 3, TableAction.Click);
                FastDriver.FeeList2.Edit.Click();
                FastDriver.FeeSetup.SwitchToContentFrame();

                Reports.TestStep = "Check the Government Reportable? Check Box";
                FastDriver.FeeSetup.GovtRep.FASetCheckbox(true);
                FastDriver.FeeSetup.RateType.FASetCheckbox(true);
                FastDriver.FeeSetup.TransactionCode.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Create Title - Lender Policy fee in Fee Setup and Owner Policy Fee Set Up.";
                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                string TE3Fee_Des = Support.RandomString("ANANA");
                string TE3Fee_Code = Support.RandomString("ANANA");

                Reports.TestStep = "Create A Fee with in Fee Setup.";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(TE3Fee_Des, TE3Fee_Code, "Title - Lenders Policy");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + TE3Fee_Des + " and Fee Description " + TE3Fee_Des;
                FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE3Fee_Code, "Title - Lenders Policy", TE3Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TE3Fee_Code, 3, TableAction.Click);
                FastDriver.FeeList2.Edit.Click();
                FastDriver.FeeSetup.SwitchToContentFrame();

                Reports.TestStep = "Check the Government Reportable? Check Box";
                FastDriver.FeeSetup.GovtRep.FASetCheckbox(true);
                FastDriver.FeeSetup.RateType.FASetCheckbox(true);
                FastDriver.FeeSetup.TransactionCode.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();


                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                string TE4Fee_Des = Support.RandomString("ANANA");
                string TE4Fee_Code = Support.RandomString("ANANA");

                Reports.TestStep = "Create A Fee with in Fee Setup.";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(TE4Fee_Des, TE4Fee_Code, "Title - Owners Policy");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + TE4Fee_Des + " and Fee Description " + TE4Fee_Des;
                FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE4Fee_Code, "Title - Owners Policy", TE4Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TE4Fee_Code, 3, TableAction.Click);
                FastDriver.FeeList2.Edit.Click();
                FastDriver.FeeSetup.SwitchToContentFrame();

                Reports.TestStep = "Check the Government Reportable? Check Box";
                FastDriver.FeeSetup.GovtRep.FASetCheckbox(true);
                FastDriver.FeeSetup.RateType.FASetCheckbox(true);
                FastDriver.FeeSetup.TransactionCode.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                

                #endregion

                Reports.TestStep = "Login to Fast IIS Application";
                IISLOGIN();

                Reports.TestStep = "Create file with State as New Jersy and County as Atlantic";
                var fileNumber = CreateFile("NJ", "Atlantic", "Atlantic City", "USA");

                Reports.TestStep = "Add a new loan instance to the file";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000");
                string LenderName = FastDriver.NewLoan.LenderName.FAGetText().Trim() + " " + FastDriver.NewLoan.BusinessPartyNameField2.FAGetText().Trim();

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validated for QC Closing tab is enabled";
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.QCClosingTab);
                Support.AreEqual(true.ToString(), FastDriver.NewLoan.QCClosingTab.IsEnabled().ToString());

                Reports.TestStep = "Enter the Transaction Type as Refinance in QC @ Closing Information Table";
                FastDriver.NewLoan.QCClosingTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.TransactionType);
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees);

                Reports.TestStep = "Add Lender and Owner Policy Fee via Add Fee button";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(TE3Fee_Des);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.FileFees.NewSearch.FAClick();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(TE4Fee_Des);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Lender Policy";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE3Fee_Des, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE3Fee_Des, 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE3Fee_Des, 7, TableAction.SetText, "2.99");

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Owner Policy";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE4Fee_Des, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE4Fee_Des, 4, TableAction.SetText, "3.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE4Fee_Des, 7, TableAction.SetText, "4.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Endorsement Fee via Add Fee button";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(TE1Fee_Des);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Endorsement Fee -1";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE1Fee_Des, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE1Fee_Des, 4, TableAction.SetText, "3.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE1Fee_Des, 7, TableAction.SetText, "4.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Another Endorsement Fee via Add Fee button";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(TE2Fee_Des);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Endorsement Fee -2";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE2Fee_Des, 4, TableAction.SetText, "5.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE2Fee_Des, 7, TableAction.SetText, "6.99");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to the Associate Fees Screen";
                FastDriver.LeftNavigation.Navigate<AssociateFeesReporting>("Home>Order Entry>Title/Escrow Fees>Associate Fees").SwitchToContentFrame();
             
                Reports.TestStep = "Add and/or Edit a Policy Fee Rate Type : Change the Rate Type for the New Home Rate (Title Only) Policy and Verify the Changes in Fee Rate Type and File Rate Type";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.Ellipse1);               
                FastDriver.AssociateFeesReporting.Ellipse1.FAClick();
                FastDriver.RateTypeSelectDlg.SwitchToDialogContentFrame();               
                FastDriver.AssociateFeesReporting.RateTypesDialogLableDescription2.FADoubleClick();

                Reports.TestStep = "Verify the Pop Up You are changing the Fee Rate Type. Do you want to change the File Rate Type also?";
               Support.AreEqual("You are changing the Fee Rate Type. Do you want to change the File Rate Type also?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, timeout: 20));

                Reports.TestStep = "Verify the Fee Rate Type Updated for New Home Rate (Title Only) Policy and also File Rate Type";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.FileRateType);
                string PolFeeRateType1 = FastDriver.AssociateFeesReporting.FeeRate1.FAGetText();
                Support.AreEqual(PolFeeRateType1, FastDriver.AssociateFeesReporting.FileRateType.FAGetValue());
                Support.AreEqual(PolFeeRateType1, FastDriver.AssociateFeesReporting.FeeRate1.FAGetText());
                                
                Reports.TestStep = "Change the Rate Type for the New Home Rate Eagle Lender Policy-1 and Verify the Changes in Fee Rate Type and File Rate Type";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.Ellipse2);
                FastDriver.AssociateFeesReporting.Ellipse2.FAClick();
                FastDriver.RateTypeSelectDlg.SwitchToDialogContentFrame();
                FastDriver.AssociateFeesReporting.RateTypesDialogLableDescription3.FADoubleClick();

                Reports.TestStep = "Verify the Pop Up You are changing the Fee Rate Type. Do you want to change the File Rate Type also?";
                Support.AreEqual("You are changing the Fee Rate Type. Do you want to change the File Rate Type also?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, timeout: 20));

                Reports.TestStep = "Verify the Fee Rate Type Updated for New Home Rate Eagle Lender Policy-1 and also File Rate Type";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.FileRateType);
                string PolFeeRateType2 = FastDriver.AssociateFeesReporting.FeeRate2.FAGetText();
                Support.AreEqual(PolFeeRateType2, FastDriver.AssociateFeesReporting.FileRateType.FAGetValue());
                Support.AreEqual(PolFeeRateType2, FastDriver.AssociateFeesReporting.FeeRate2.FAGetText());

                Reports.TestStep = "Verify the Endorsement Fee Rate Pop Up Dialogue displayed for both Endorsement Fee " + TE1Fee_Des + " and " + TE2Fee_Des + "";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.EndorseEllipse1);
                FastDriver.AssociateFeesReporting.EndorseEllipse1.FAClick();
                FastDriver.RateTypeSelectDlg.SwitchToDialogContentFrame();
                Support.AreEqual("True", FastDriver.AssociateFeesReporting.EndorseRateTypesDialogLableDescription1.IsDisplayed().ToString());                    
                FastDriver.AssociateFeesReporting.EndorseRateTypesDialogLableDescription1.FADoubleClick();

                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.EndorseEllipse2);
                FastDriver.AssociateFeesReporting.EndorseEllipse2.FAClick();
                FastDriver.RateTypeSelectDlg.SwitchToDialogContentFrame();
                Support.AreEqual("True", FastDriver.AssociateFeesReporting.EndorseRateTypesDialogLableDescription1.IsDisplayed().ToString());                
                FastDriver.AssociateFeesReporting.EndorseRateTypesDialogLableDescription1.FADoubleClick();
                FastDriver.BottomFrame.Done();

            }


            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }




        }

        #endregion

        #region FMUC0094_REG0003C


        [TestMethod]
        public void FMUC0094_REG0003C()
        {
            try
            {

                Reports.TestDescription = "MF1_02: Deactivate the fee(set up). and Disburse the fees.";

                Reports.TestStep = "Login to Fast ADM Application";
                ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level and Select the QA Automation Region - DO NOT TOUCH";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                #region Create New Title Endorsement Policies

                Reports.TestStep = "Create 2 Title - Endorsement Fee Policy fee in Fee Setup. and Verify the fee status of 2 Endorsement fee and make it active";
                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                string TE1Fee_Des = Support.RandomString("ANANA");
                string TE1Fee_Code = Support.RandomString("ANANA");

                Reports.TestStep = "Create A Fee with in Fee Setup.";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(TE1Fee_Des, TE1Fee_Code, "Title - Endorsement Fee");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + TE1Fee_Des + " and Fee Description " + TE1Fee_Des;
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE1Fee_Code, "Title - Endorsement Fee", TE1Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TE1Fee_Code, 3, TableAction.Click);


                Reports.TestStep = "Create another Title - Endorsement Fee Policy";
                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                string TE2Fee_Des = Support.RandomString("ANANA");
                string TE2Fee_Code = Support.RandomString("ANANA");

                Reports.TestStep = "Create A Fee with in Fee Setup.";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(TE2Fee_Des, TE2Fee_Code, "Title - Endorsement Fee");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + TE2Fee_Des + " and Fee Description " + TE2Fee_Des;
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE2Fee_Code, "Title - Endorsement Fee", TE2Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TE2Fee_Code, 3, TableAction.Click);
                FastDriver.FeeList2.Edit.Click();
                FastDriver.FeeSetup.SwitchToContentFrame();

                Reports.TestStep = "De-Activate the Fee " + TE2Fee_Des + " Created";
                FastDriver.FeeSetup.FeeStatus.FASelectItem("Deactivated");
                FastDriver.FeeSetup.SwitchToContentFrame();
                FastDriver.FeeSetup.WaitForScreenToLoad(FastDriver.FeeSetup.FeeType);
                FastDriver.FeeSetup.WaitForScreenToLoad(FastDriver.FeeSetup.FeeType);
                Support.AreEqual(false.ToString(), FastDriver.FeeSetup.FeeType.IsEnabled().ToString());
                FastDriver.FeeSetup.WaitForScreenToLoad(FastDriver.FeeSetup.FeeType);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the De-Activated Fee " + TE2Fee_Des + " Should not be Displayed in the List";
                FastDriver.FeeList2.WaitScreenToLoad();                
                Support.AreEqual(false.ToString(), FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE2Fee_Code, "Title - Endorsement Fee", TE2Fee_Des).ToString());
                Reports.TestStep = "Un-Check the Active Only Check Box and Verify the De-Activated Fee Displayed in List";
                FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.ActiveOnly);
                FastDriver.FeeList2.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Verify the De-Activated Fee " + TE2Fee_Des + " Should be Displayed in the List";
                FastDriver.FeeList2.WaitScreenToLoad();  
                Support.AreEqual(true.ToString(), FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TE2Fee_Code, "Title - Endorsement Fee", TE2Fee_Des).ToString());

                Reports.TestStep = "Verify the De-Activated Fee and Activate it Back";
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TE2Fee_Code, 3, TableAction.Click);
                FastDriver.FeeList2.Edit.Click();
                FastDriver.FeeSetup.SwitchToContentFrame();

                Reports.TestStep = "Activate the Fee " + TE2Fee_Des + " Created";
                FastDriver.FeeSetup.FeeStatus.FASelectItem("Active");
                FastDriver.FeeSetup.SwitchToContentFrame();
                FastDriver.FeeSetup.WaitForScreenToLoad(FastDriver.FeeSetup.FeeType);
                FastDriver.FeeSetup.WaitForScreenToLoad(FastDriver.FeeSetup.FeeType);
                Support.AreEqual(true.ToString(), FastDriver.FeeSetup.FeeType.IsEnabled().ToString());
                FastDriver.BottomFrame.Done();

                #endregion
                               

                Reports.TestStep = "Login to Fast IIS Application";
                IISLOGIN();

                Reports.TestStep = "Create file with State as pennsylvania and County as pennsylvania";
                var fileNumber = CreateFile("PA", "Philadelphia", "Philadelphia", "USA");

                Reports.TestStep = "Add a new loan instance to the file";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000");
                string LenderName = FastDriver.NewLoan.LenderName.FAGetText().Trim() + " " + FastDriver.NewLoan.BusinessPartyNameField2.FAGetText().Trim();

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validated for QC Closing tab is enabled";
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.QCClosingTab);
                Support.AreEqual(true.ToString(), FastDriver.NewLoan.QCClosingTab.IsEnabled().ToString());

                Reports.TestStep = "Enter the Transaction Type as Refinance in QC @ Closing Information Table";
                FastDriver.NewLoan.QCClosingTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.TransactionType);
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees);

                Reports.TestStep = "Enter the Buyer and Seller Charge for the New Home Rate Eagle Lender Policy-1";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "2.99");

                Reports.TestStep = "Enter the Buyer and Seller Charge for the New Home Rate (Title Only)";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "3.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "4.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Endorsement Fee via Add Fee button";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(TE1Fee_Des);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Endorsement Fee -1";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE1Fee_Des, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE1Fee_Des, 4, TableAction.SetText, "3.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE1Fee_Des, 7, TableAction.SetText, "4.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Another Endorsement Fee via Add Fee button";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(TE2Fee_Des);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Endorsement Fee -2";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE2Fee_Des, 4, TableAction.SetText, "5.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TE2Fee_Des, 7, TableAction.SetText, "6.99");
                FastDriver.BottomFrame.Done();
                                
                Reports.TestStep = "Disburse the Fees";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad(FastDriver.ActiveDisbursementSummary.Disbursements);
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#1", "Pending", "#1", TableAction.GetText).Message);              


                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#3", "Fee Transfer", "#3", TableAction.Click);

                Reports.TestStep = "Click on the Fee Transfer Button";
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Enter the Values in Password Confirmation Dialogue";
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();

                Reports.TestStep = "Click on the Done Button on Change File Status";
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Closed");


                Reports.TestStep = "Click Cancel on PrintWebPage Dialog";
                FastDriver.PrintDlg.ClickCancel();
                
                Reports.TestStep = "Navigate to the Disbursement History Page";
                FastDriver.DisbursementHistory.Open();
                
                Reports.TestStep = "Click on the Issued Status and Click on the Adjust Button";
                FastDriver.DisbursementHistory.WaitForScreenToLoad(FastDriver.DisbursementHistory.DisbursementTable);
                Support.AreEqual("Issued", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("#1", "Issued", "#1", TableAction.GetText).Message);
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("#1", "Issued", "#1", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Select the Adjustment Reason as Cancel, Enter the Comment and Save";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DisbursementAdjustment.Comment.FASetText("Cancel Comments");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the Pop Up Accounting Adjustment Form is ready for printing. Continue?";
                Support.AreEqual("Accounting Adjustment Form is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, timeout: 20));

                Reports.TestStep = "Click Cancel on PrintWebPage Dialog";
                FastDriver.PrintDlg.ClickCancel();
                
                Reports.TestStep = "Navigate to the Associate Fees Screen";
                FastDriver.LeftNavigation.Navigate<AssociateFeesReporting>("Home>Order Entry>Title/Escrow Fees>Associate Fees").SwitchToContentFrame();

                Reports.TestStep = "Verify the Policy Fee, Associate Loan to Loan Policy Fees and Endorsement Fee Details Table Information";
                FastDriver.AssociateFeesReporting.WaitForScreenToLoad(FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly);
                Support.AreEqual("New Home Rate (Title Only)", FastDriver.AssociateFeesReporting.NewHomeRateTitleOnly.FAGetText());
                Support.AreEqual("$ 8.98", FastDriver.AssociateFeesReporting.FeeAmount1.FAGetText());

                Support.AreEqual("New Home Rate Eagle Lender Policy-1", FastDriver.AssociateFeesReporting.NewHomeRateLenderPolicy_1.FAGetText());
                Support.AreEqual("$ 4.98", FastDriver.AssociateFeesReporting.FeeAmount2.FAGetText());

            }


            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }




        }

        #endregion

        #region  FMUC0094_REG0003D

        [TestMethod]
        public void FMUC0094_REG0003D()
        {
            Reports.TestDescription = "Continuation from FMUC0094_REG0003A";
            Reports.StatusUpdate("FMUC0094_REG0004 : Continuation from FMUC0094_REG0003A : Functionality has covered in FMUC0094_REG003A", true);

        }
        #endregion

        #region  FMUC0094_REG0004

        [TestMethod]
        public void FMUC0094_REG0004()
        {
            Reports.TestDescription = "FM7638_FM7639_FM7645_FM7644: Link Loan Policy Fee to Loan Liability Amount on File.";
            Reports.StatusUpdate("FMUC0094_REG0004 : Continuation from FMUC0094_REG0003A : Functionality has covered in FMUC0094_REG003A", true);

        }
        #endregion

        #region  FMUC0094_REG0005

        [TestMethod]
        public void FMUC0094_REG0005()
        {
            Reports.TestDescription = "Disburse the fees.";
            Reports.StatusUpdate("FMUC0094_REG0005 : Disburse the fees. : Functionality has covered in FMUC0094_REG003C", true);

        }
        #endregion

        #region  FMUC0094_REG0006_PH

        [TestMethod]
        public void FMUC0094_REG0006_PH()
        {
            Reports.TestDescription = "FM7641_FM7642: Fee Information is view only.";
            Reports.StatusUpdate("FMUC0094_REG0006_PH : FM7641_FM7642: Fee Information is view only. : Functionality has covered in FMUC0094_REG003A, FMUC0094_REG003B", true);

        }
        #endregion

        #region  FMUC0094_REG0007_PH

        [TestMethod]
        public void FMUC0094_REG0007_PH()
        {
            Reports.TestDescription = "FM7646_FM7648_FM7649: Fees can be reported by property state.";
            Reports.StatusUpdate("FMUC0094_REG0007_PH : FM7646_FM7648_FM7649: Fees can be reported by property state. : Functionality has covered in FMUC0094_REG003C", true);

        }
        #endregion

        #region  FMUC0094_REG0008_PH

        [TestMethod]
        public void FMUC0094_REG0008_PH()
        {
            Reports.TestDescription = "FM7652_FM7653_FM7647_FM7650_FM7651: Fee can be reported by Rate Type.";
            Reports.StatusUpdate("FMUC0094_REG0008_PH : FM7652_FM7653_FM7647_FM7650_FM7651: Fee can be reported by Rate Type. : Functionality has covered in FMUC0094_REG003B", true);

        }
        #endregion


        #endregion


        #region PRIVATE METHODS

        private void IISLOGIN(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }


        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);
        }


        private string CreateFile(string State, string County, string City, string Country, bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            string buyerRandomVal = Support.RandomString("AAAAAZ");
            //string[] State = { "CR", "AR" };
            Reports.TestStep = "Generate a random buyer name.";
            Support.DataSave("RandomBuyerName", buyerRandomVal);



            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = State;
                fileRequest.File.Properties[0].PropertyAddress[0].County = County;
                fileRequest.File.Properties[0].PropertyAddress[0].City = City;
                fileRequest.File.Properties[0].PropertyAddress[0].Country = Country;


                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch //If not able to create file via web service, create file via FAST GUI
            {
                return "";
            }
            return fileNumber;
        }




        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

}

