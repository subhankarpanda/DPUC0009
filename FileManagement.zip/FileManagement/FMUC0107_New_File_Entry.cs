﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using System.Linq;
using FASTWCFHelpers.FastFileService;
using System.Threading;
using SeleniumInternalHelpersSupportLibrary;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0107_New_File_Entry : MasterTestClass
    {
        #region BAT

        [TestMethod]
        public void FMUC0107_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Enter data in NFE/Create a Pending file.";
                this.Login();

                //
                Reports.TestStep = "Create a Pending file-Details Tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem("No Program Type");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("Title Agent");
                FastDriver.NewFileEntry.DetailsSearchType.FASelectItem("No Search Type");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Husband/Wife");
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText("Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText("Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText("Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText("Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText("Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText("Seller2SpouseName");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.NewFileEntry.FormType_CD.FAClick();
                }
                else
                    if (AutoConfig.FormType.ToLower().Equals("hud"))
                    {
                        FastDriver.NewFileEntry.FormType_HUD.FAClick();
                    }

                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText("92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem("Orange");
                FastDriver.NewFileEntry.DetailsSalePrice.FASetText("600,000.00");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText("250,000.00");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText("150,000.00");

                //
                Reports.TestStep = "Validate the Pending file-Details Tab.";
                Support.AreEqual("Residential", FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryBusinessSegment");
                Support.AreEqual("Sale w/Mortgage", FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryTransactionType");
                Support.AreEqual("No Program Type", FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryProgramType");
                Support.AreEqual("Title Agent", FastDriver.NewFileEntry.DetailsAddtionalRole.FAGetSelectedItem(), "Verifies the DetailsAddtionalRole");
                Support.AreEqual("No Search Type", FastDriver.NewFileEntry.DetailsSearchType.FAGetSelectedItem(), "Verifies the DetailsSearchType");
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.DetailsBuyerType.FAGetSelectedItem(), "Verifies the DetailsBuyerType");
                Support.AreEqual("Buyer2Firstname", FastDriver.NewFileEntry.DetailsBuyerHusbandName.FAGetValue(), "Verifies the DetailsBuyerHusbandName");
                Support.AreEqual("Buyer2Lastname", FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FAGetValue(), "Verifies the DetailsBuyerHusbandLast");
                Support.AreEqual("Buyer2SpouseName", FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FAGetValue(), "Verifies the DetailsBuyerSpouseFirstName");
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.DetailsSellerType.FAGetSelectedItem(), "Verifies the DetailsSellerType");
                Support.AreEqual("Seller2Firstname", FastDriver.NewFileEntry.DetailsSellerHusbandName.FAGetValue(), "Verifies the DetailsSellerHusbandName");
                Support.AreEqual("Seller2Lastname", FastDriver.NewFileEntry.DetailsSellerHusbandLast.FAGetValue(), "Verifies the DetailsSellerHusbandLast");
                Support.AreEqual("Seller2SpouseName", FastDriver.NewFileEntry.DetailsSellerSpouseName.FAGetValue(), "Verifies the DetailsSellerSpouseName");
                Support.AreEqual("1 First American Way", FastDriver.NewFileEntry.DetailsPropertyStreet1.FAGetValue(), "Verifies the DetailsPropertyStreet1");
                Support.AreEqual("PropertyStreet3", FastDriver.NewFileEntry.DetailsPropertyStreet3.FAGetValue(), "Verifies the DetailsPropertyStreet3");
                Support.AreEqual("PropertyStreet4", FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue(), "Verifies the DetailsPropertyStreet4");
                Support.AreEqual("PropertyStreet4", FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue(), "Verifies the DetailsPropertyStreet4");
                Support.AreEqual("Santa Ana", FastDriver.NewFileEntry.DetailsPropertyCity.FAGetValue(), "Verifies the DetailsPropertyCity");
                Support.AreEqual("CA", FastDriver.NewFileEntry.DetailsPropertyState.FAGetSelectedItem(), "Verifies the DetailsPropertyState");
                Support.AreEqual("92707", FastDriver.NewFileEntry.DetailsPropertyZIP.FAGetValue(), "Verifies the DetailsPropertyZIP");
                Support.AreEqual("Orange", FastDriver.NewFileEntry.DetailsPropertyCounty.FAGetSelectedItem(), "Verifies the DetailsPropertyCounty");
                Support.AreEqual("600,000.00", FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue(), "Verifies the DetailsSalePrice");
                Support.AreEqual("250,000.00", FastDriver.NewFileEntry.DetailsFirstNewLoan.FAGetValue(), "Verifies the DetailsFirstNewLoan");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Enter data for Parties Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.PartiesParties.FAClick();
                Playback.Wait(2500);

                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PartiesDirectedByGABcode);
                FastDriver.NewFileEntry.PartiesDirectedByGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.PartiesDirectedByFind.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyGABcode.FAClick();
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyFind.FAClick();
                Playback.Wait(2500);

                //
                Reports.TestStep = "Validate the Pending file-Parties Tab.";
                FastDriver.NewFileEntry.PartiesParties.FAClick();
                Playback.Wait(2500);
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Enter data for PartiesPropertyInfo Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyInfo);
                FastDriver.NewFileEntry.PropertyInfoPropertyInfo.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyType);
                FastDriver.NewFileEntry.PropertyInfoPropertyType.FASelectItem("Single Family Residence");
                Keyboard.SendKeys("{ENTER}");
                FastDriver.NewFileEntry.PropertyInfoLot.FASetText("Lot1");
                FastDriver.NewFileEntry.PropertyInfoBlock.FASetText("Block1");
                FastDriver.NewFileEntry.PropertyInfoUnit.FASetText("Unit1");
                FastDriver.NewFileEntry.PropertyInfoTrack.FASetText("Tract1");
                FastDriver.NewFileEntry.PropertyInfoFee.FASetText("Fee1");
                FastDriver.NewFileEntry.PropertyInfoBuilding.FASetText("Building1");
                FastDriver.NewFileEntry.PropertyInfoBook.FASetText("Book1");
                FastDriver.NewFileEntry.PropertyInfoPage.FASetText("Page1");
                FastDriver.NewFileEntry.PropertyInfoSection.FASetText("Section1");

                //
                Reports.TestStep = "Validate the Pending file-PropertyInfoTab.";
                Support.AreEqual("Single Family Residence", FastDriver.NewFileEntry.PropertyInfoPropertyType.FAGetSelectedItem(), "Verifies the PropertyInfoPropertyType");
                Support.AreEqual("Lot1", FastDriver.NewFileEntry.PropertyInfoLot.FAGetValue(), "Verifies the DetailsFirstNewLoan");
                Support.AreEqual("Block1", FastDriver.NewFileEntry.PropertyInfoBlock.FAGetValue(), "Verifies the PropertyInfoBlock");
                Support.AreEqual("Unit1", FastDriver.NewFileEntry.PropertyInfoUnit.FAGetValue(), "Verifies the PropertyInfoUnit");
                Support.AreEqual("Tract1", FastDriver.NewFileEntry.PropertyInfoTrack.FAGetValue(), "Verifies the PropertyInfoTrack");
                Support.AreEqual("Fee1", FastDriver.NewFileEntry.PropertyInfoFee.FAGetValue(), "Verifies the PropertyInfoFee");
                Support.AreEqual("Building1", FastDriver.NewFileEntry.PropertyInfoBuilding.FAGetValue(), "Verifies the PropertyInfoBuilding");
                Support.AreEqual("Book1", FastDriver.NewFileEntry.PropertyInfoBook.FAGetValue(), "Verifies the PropertyInfoBook");
                Support.AreEqual("Page1", FastDriver.NewFileEntry.PropertyInfoPage.FAGetValue(), "Verifies the PropertyInfoPage");
                Support.AreEqual("Section1", FastDriver.NewFileEntry.PropertyInfoSection.FAGetValue(), "Verifies the PropertyInfoSection");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Enter data for Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();

                //
                Reports.TestStep = "Validate the Pending file- Lender/Mortgage Broker Tab.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter data for Special Instructions Tab.";
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FASetText("SpecialInstruction Notes Data including - * # Specialcharacter :) ! ");

                //
                Reports.TestStep = "Validate the Pending file- Special Instructions Tab.";
                Support.AreEqual(@"SpecialInstruction Notes Data including - * # Specialcharacter :) ! ", FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FAGetText());
                FastDriver.BottomFrame.Save();
                Playback.Wait(4000);
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0107_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_00: Scan document to the Pending File.";

                //
                Reports.TestStep = "Login To FAST File Side";
                this.Login();

                //
                Reports.TestStep = "Login To FAST File Side";
                // this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                Reports.TestStep = "Create Order.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false);

                //
                Reports.TestStep = "Scan document to the Pending File.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsScan.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad(FastDriver.ImagingWorkBench.Open);
                //FastDriver.ImagingWorkBench.Open.FAClick();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                //FastDriver.OpenImageDlg.OpenImage(@"C:\TFS2\FASTSelenium_MainINT\DocPrep\bin\Debug\Common\Support" + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);
                Keyboard.SendKeys("{ENTER}");
                Playback.Wait(1000);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "", imageTrigger: "AFFIX INV");
                Playback.Wait(1000);
                Keyboard.SendKeys("{ENTER}");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsRefresh.FAClick();

                //
                Reports.TestStep = "Validate the scan is done.";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsRefresh.Click();
                    return FastDriver.NewFileEntry.UploadedDocumentsTable.Text.Contains("INST-Estimated Settlement Statement");
                });
                Support.AreEqual(true, FastDriver.NewFileEntry.UploadedDocumentsTable.Text.Contains("INST-Estimated Settlement Statement"), "Is the scanned doc present.");
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_BAT0003_0004_0005_0006_0007()
        {
            try
            {
                Reports.TestDescription = @"AF3_00: Create Distribution and Delivery Instruction./ AF4_00: Edit saved Distribution and Delivery Instruction.";
                this.Login();
                //
                Reports.TestStep = "Create a Pending file-Details Tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem("No Program Type");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("Title Agent");
                FastDriver.NewFileEntry.DetailsSearchType.FASelectItem("No Search Type");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Husband/Wife");
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText("Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText("Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText("Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText("Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText("Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText("Seller2SpouseName");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.NewFileEntry.FormType_CD.FAClick();
                }
                else
                    if (AutoConfig.FormType.ToLower().Equals("hud"))
                    {
                        FastDriver.NewFileEntry.FormType_HUD.FAClick();
                    }

                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText("92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem("Orange");
                FastDriver.NewFileEntry.DetailsSalePrice.FASetText("600,000.00");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText("250,000.00");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText("150,000.00");

                //
                Reports.TestStep = "Validate the Pending file-Details Tab.";
                Support.AreEqual("Residential", FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryBusinessSegment");
                Support.AreEqual("Sale w/Mortgage", FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryTransactionType");
                Support.AreEqual("No Program Type", FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryProgramType");
                Support.AreEqual("Title Agent", FastDriver.NewFileEntry.DetailsAddtionalRole.FAGetSelectedItem(), "Verifies the DetailsAddtionalRole");
                Support.AreEqual("No Search Type", FastDriver.NewFileEntry.DetailsSearchType.FAGetSelectedItem(), "Verifies the DetailsSearchType");
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.DetailsBuyerType.FAGetSelectedItem(), "Verifies the DetailsBuyerType");
                Support.AreEqual("Buyer2Firstname", FastDriver.NewFileEntry.DetailsBuyerHusbandName.FAGetValue(), "Verifies the DetailsBuyerHusbandName");
                Support.AreEqual("Buyer2Lastname", FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FAGetValue(), "Verifies the DetailsBuyerHusbandLast");
                Support.AreEqual("Buyer2SpouseName", FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FAGetValue(), "Verifies the DetailsBuyerSpouseFirstName");
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.DetailsSellerType.FAGetSelectedItem(), "Verifies the DetailsSellerType");
                Support.AreEqual("Seller2Firstname", FastDriver.NewFileEntry.DetailsSellerHusbandName.FAGetValue(), "Verifies the DetailsSellerHusbandName");
                Support.AreEqual("Seller2Lastname", FastDriver.NewFileEntry.DetailsSellerHusbandLast.FAGetValue(), "Verifies the DetailsSellerHusbandLast");
                Support.AreEqual("Seller2SpouseName", FastDriver.NewFileEntry.DetailsSellerSpouseName.FAGetValue(), "Verifies the DetailsSellerSpouseName");
                Support.AreEqual("1 First American Way", FastDriver.NewFileEntry.DetailsPropertyStreet1.FAGetValue(), "Verifies the DetailsPropertyStreet1");
                Support.AreEqual("PropertyStreet3", FastDriver.NewFileEntry.DetailsPropertyStreet3.FAGetValue(), "Verifies the DetailsPropertyStreet3");
                Support.AreEqual("PropertyStreet4", FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue(), "Verifies the DetailsPropertyStreet4");
                Support.AreEqual("PropertyStreet4", FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue(), "Verifies the DetailsPropertyStreet4");
                Support.AreEqual("Santa Ana", FastDriver.NewFileEntry.DetailsPropertyCity.FAGetValue(), "Verifies the DetailsPropertyCity");
                Support.AreEqual("CA", FastDriver.NewFileEntry.DetailsPropertyState.FAGetSelectedItem(), "Verifies the DetailsPropertyState");
                Support.AreEqual("92707", FastDriver.NewFileEntry.DetailsPropertyZIP.FAGetValue(), "Verifies the DetailsPropertyZIP");
                Support.AreEqual("Orange", FastDriver.NewFileEntry.DetailsPropertyCounty.FAGetSelectedItem(), "Verifies the DetailsPropertyCounty");
                Support.AreEqual("600,000.00", FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue(), "Verifies the DetailsSalePrice");
                Support.AreEqual("250,000.00", FastDriver.NewFileEntry.DetailsFirstNewLoan.FAGetValue(), "Verifies the DetailsFirstNewLoan");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Enter data for Parties Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.PartiesParties.FAClick();
                Playback.Wait(2500);

                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PartiesDirectedByGABcode);
                FastDriver.NewFileEntry.PartiesDirectedByGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.PartiesDirectedByFind.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyGABcode.FAClick();
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyFind.FAClick();
                Playback.Wait(2500);

                //
                Reports.TestStep = "Validate the Pending file-Parties Tab.";
                FastDriver.NewFileEntry.PartiesParties.FAClick();
                Playback.Wait(2500);
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Enter data for PartiesPropertyInfo Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyInfo);
                FastDriver.NewFileEntry.PropertyInfoPropertyInfo.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyType);
                FastDriver.NewFileEntry.PropertyInfoPropertyType.FASelectItem("Single Family Residence");
                Keyboard.SendKeys("{ENTER}");
                FastDriver.NewFileEntry.PropertyInfoLot.FASetText("Lot1");
                FastDriver.NewFileEntry.PropertyInfoBlock.FASetText("Block1");
                FastDriver.NewFileEntry.PropertyInfoUnit.FASetText("Unit1");
                FastDriver.NewFileEntry.PropertyInfoTrack.FASetText("Tract1");
                FastDriver.NewFileEntry.PropertyInfoFee.FASetText("Fee1");
                FastDriver.NewFileEntry.PropertyInfoBuilding.FASetText("Building1");
                FastDriver.NewFileEntry.PropertyInfoBook.FASetText("Book1");
                FastDriver.NewFileEntry.PropertyInfoPage.FASetText("Page1");
                FastDriver.NewFileEntry.PropertyInfoSection.FASetText("Section1");

                //
                Reports.TestStep = "Validate the Pending file-PropertyInfoTab.";
                Support.AreEqual("Single Family Residence", FastDriver.NewFileEntry.PropertyInfoPropertyType.FAGetSelectedItem(), "Verifies the PropertyInfoPropertyType");
                Support.AreEqual("Lot1", FastDriver.NewFileEntry.PropertyInfoLot.FAGetValue(), "Verifies the DetailsFirstNewLoan");
                Support.AreEqual("Block1", FastDriver.NewFileEntry.PropertyInfoBlock.FAGetValue(), "Verifies the PropertyInfoBlock");
                Support.AreEqual("Unit1", FastDriver.NewFileEntry.PropertyInfoUnit.FAGetValue(), "Verifies the PropertyInfoUnit");
                Support.AreEqual("Tract1", FastDriver.NewFileEntry.PropertyInfoTrack.FAGetValue(), "Verifies the PropertyInfoTrack");
                Support.AreEqual("Fee1", FastDriver.NewFileEntry.PropertyInfoFee.FAGetValue(), "Verifies the PropertyInfoFee");
                Support.AreEqual("Building1", FastDriver.NewFileEntry.PropertyInfoBuilding.FAGetValue(), "Verifies the PropertyInfoBuilding");
                Support.AreEqual("Book1", FastDriver.NewFileEntry.PropertyInfoBook.FAGetValue(), "Verifies the PropertyInfoBook");
                Support.AreEqual("Page1", FastDriver.NewFileEntry.PropertyInfoPage.FAGetValue(), "Verifies the PropertyInfoPage");
                Support.AreEqual("Section1", FastDriver.NewFileEntry.PropertyInfoSection.FAGetValue(), "Verifies the PropertyInfoSection");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Enter data for Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();

                //
                Reports.TestStep = "Validate the Pending file- Lender/Mortgage Broker Tab.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Enter data for Special Instructions Tab.";
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FASetText("SpecialInstruction Notes Data including - * # Specialcharacter :) ! ");

                //
                Reports.TestStep = "Validate the Pending file- Special Instructions Tab.";
                Support.AreEqual(@"SpecialInstruction Notes Data including - * # Specialcharacter :) ! ", FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FAGetText());
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);

                //BreakPoint
                //
                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();

                //
                Reports.TestStep = "Validate all parties are visible in Dialog.";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.DirectedBy.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.Buyer.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.Seller.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.NewLender.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.MortgageBroker.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.AssociatedBusinessParty.Exists().ToString());
                FastDriver.DialogBottomFrame.ClickCancel();

                //
                Reports.StatusUpdate("AF4_00 Section", true);
                //****BAT0004 Merged Here.

                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();

                //
                Reports.TestStep = "Edit the data in the dialog for B/s.";
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FASetText("3");
                FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport.FASetText("3");
                FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs.FASetText("3");
                FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement.FASetText("3");
                FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FASetText("3");

                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage.FASelectItem("Branch");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPrelimReport.FASelectItem("Courier");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectCopies0cboCCRs.FASelectItem("Email");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPlottedEasement.FASelectItem("Fax");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectExceptions.FASelectItem("Mail");

                //
                Reports.TestStep = "Edit Data for Directed By.";
                FastDriver.ViewDeliveryInstrucionsDlg.DirectedBy.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage1.FASelectItem("Branch");
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage1.FASetText("1");

                //
                Reports.TestStep = "Edit Data for New Lender.";
                FastDriver.ViewDeliveryInstrucionsDlg.NewLender.FAClick();

                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage2.FASelectItem("Courier");
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackageNewLender.FASetText("1");

                //
                Reports.TestStep = "Edit Data for MB.";
                FastDriver.ViewDeliveryInstrucionsDlg.MortgageBroker.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage3.FASelectItem("Email");
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage3.FASetText("1");

                //
                Reports.TestStep = "Edit Data for Associated B/S Party.";
                FastDriver.ViewDeliveryInstrucionsDlg.AssociatedBusinessParty.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage4.FASelectItem("Fax");
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage7.FASetText("1");
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage5.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage5.FASendKeys(FAKeys.Backspace);
                FastDriver.DialogBottomFrame.ClickDone();

                //***BAT0005 Section****//
                Reports.StatusUpdate("BAT0006: AF5_00: Cancel Pending File.", true);

                //
                Reports.TestStep = "Cancel Pending File.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Cancelled");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //***BAT0006 Section****//
                Reports.StatusUpdate("BAT0006: AF7_00: In error Pending File.", true);

                //
                Reports.TestStep = "Change the status to Open in Error.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open In Error");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...");
                //
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Playback.Wait(1000);

                //
                Reports.TestStep = "Verify file is Open in Error.";
                Support.AreEqual("Open In Error", FastDriver.NewFileEntry.FileStatus.FAGetSelectedItem().Clean());

                //***BAT0007 Section****//
                Reports.StatusUpdate("AF6_00: Open Pending File.", true);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion BAT

        #region REG

        [TestMethod]
        public void FMUC0107_REG0001()
        {
            try
            {
                Reports.TestDescription = "BR_FM10213: Access Rights.";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Region Level.";
                this.NavigateToRegionLevel();

                //
                Reports.TestStep = "Enter userid and search.";
                FastDriver.LeftNavigation.Navigate<EmployeeSecurity>("Home>System Maintenance>Security Maintenance>Employee Security").WaitForScreenToLoad();
                FastDriver.EmployeeSecurity.LoginNameTextbox.FASetText(AutoConfig.UserName);
                FastDriver.EmployeeSecurity.SearchNowButton.FAClick();
                FastDriver.EmployeeSecurity.WaitForScreenToLoad(FastDriver.EmployeeSecurity.ResultsTable);
                FastDriver.EmployeeSecurity.ResultsTable.PerformTableAction(1, "[" + AutoConfig.UserName.ToUpper() + "]", 2, TableAction.DoubleClick);

                //
                Reports.TestStep = "Click on region in use.";
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad(FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable);
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction("BUID", AutoConfig.SelectedRegionBUID, "#2", TableAction.Click);
                    FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction("BUID", AutoConfig.SelectedRegionBUID, "#1", TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                }
                else
                {
                    FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedRegionBUID, 2, TableAction.Click);
                }
                Playback.Wait(15000);
                //
                Reports.TestStep = "Click open the Office.";
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad(FastDriver.BusinessUnitRoleAssignment.AssociatedRolesTable);
                if (AutoConfig.FormType.Equals("CD"))
                {
                    FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction("BUID", AutoConfig.SelectedOfficeBUID, "BUID", TableAction.Click);
                }
                else
                {
                    FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedOfficeBUID, 2, TableAction.Click);
                }

                FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();
                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", "IT - all", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                FastDriver.BusinessUnitRoleAssignment.AssociatedRolesTable.PerformTableAction(2, "IT - all", 2, TableAction.Click);
                FastDriver.BusinessUnitRoleAssignment.AssociatiatedRoleExpandIcon.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                try
                {
                    FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                    FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText(DateTime.Now.Date.ToDateString().Replace("-", string.Empty));
                    FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("TrackChangeHistoryDialog not present test ends here", true);
                }
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM10221_01: Business Source type(ADM)";
                this.Login(true);

                Reports.TestStep = "Navigate to Region Lvl.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                //
                Reports.TestStep = "To check upload doc checkbox";
                FastDriver.LeftNavigation.Navigate<ProcessingRegionSetup>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST").WaitForScreenToLoad(FastDriver.ProcessingRegionSetup.UploadWordExcel);
                if (FastDriver.ProcessingRegionSetup.UploadWordExcel.IsSelected())
                    FastDriver.ProcessingRegionSetup.UploadWordExcel.FAClick();

                //
                Reports.TestStep = "To click AddNew Business type button.";
                FastDriver.ProcessingRegionSetup.BusinessSourceTypesAddNew.FAClick();
                FastDriver.ProcessingRegionSetup.BusinessSourceTypesName.FASetText("BusTypeName");
                if (!FastDriver.ProcessingRegionSetup.DisplayBustype.Selected)
                {
                    FastDriver.ProcessingRegionSetup.DisplayBustype.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                //Playback.Wait(6000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Select Special Instructions for NFE-1";
                FastDriver.LeftNavigation.Navigate<SpecialInstructionsSetup>("Home>System Maintenance>Special Instructions Setup[0]>Special Instructions Setup[1]").WaitForScreenToLoad();
                FastDriver.SpecialInstructionsSetup.WaitForScreenToLoad(FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable);
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Sanity_Instruction1", 4, TableAction.On);

                //
                Reports.TestStep = "Select Special Instructions for NFE-2";
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Sanity_Instruction2", 4, TableAction.On);
                FastDriver.BottomFrame.Save();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0107_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_FM10151: Create Pending File.";
                Reports.TestDescription = "MF1_00: Enter data in NFE/Create a Pending file.";

                this.Login();

                //
                Reports.TestStep = "Create a Pending file-Details Tab.";
                this.NavigateToNewFileEntry();
                FastDriver.BottomFrame.New();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                Support.AreEqual(AutoConfig.SelectedOfficeName + " PR: STEST off: 7878(1487)", FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedItem());
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem("No Program Type");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                Playback.Wait(2000);

                //
                Reports.TestStep = "Click on Add/Remove Owner Policy";
                FastDriver.NewFileEntry.DetailsAddRemove.FAClick();

                //
                Reports.TestStep = "Select  Policy";
                FastDriver.LenderPoliciesDlg.WaitForScreenToLoad();
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 2, TableAction.Click);
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                //
                Reports.TestStep = "Click on Add/Remove Lender Policy";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddRemoveLenderPolicy.FAClick();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Select 1999 EAGLE Manufactured Home Loan Policy";
                FastDriver.LenderPoliciesDlg.WaitForScreenToLoad();
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Manufactured Home Loan Policy", 2, TableAction.Click);
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Manufactured Home Loan Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                //
                Reports.TestStep = "Click on Add/Remove Guarantee";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddRemoveGuarantee.FAClick();

                //
                Reports.TestStep = "Select Abstract";
                FastDriver.LenderPoliciesDlg.WaitForScreenToLoad();
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Combo Guarantee", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                //
                Reports.TestStep = "Click on Add/Remove Other Policy";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddRemoveother.FAClick();

                //
                Reports.TestStep = "Select Abstract";
                FastDriver.LenderPoliciesDlg.WaitForScreenToLoad();
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Abstract", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Leasehold Owners Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        return FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Leasehold Owners Policy");
                    }, timeout: 30, idleInterval: 2);
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);
                }
                if (!FastDriver.NewFileEntry.LenderPolicyTable.FAGetText().Contains("Manufactured Home Loan Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.LenderPoliciesDlg.WaitForScreenToLoad()
                        .LenderProductTable.PerformTableAction(2, "Manufactured Home Loan Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        return FastDriver.NewFileEntry.LenderPolicyTable.Text.Contains("Manufactured Home Loan Policy");
                    }, timeout: 30, idleInterval: 2);
                }
                else
                {
                    FastDriver.NewFileEntry.LenderPolicyTable.PerformTableAction(2, "Manufactured Home Loan Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.GuaranteeTable.PerformTableAction(2, "Combo Guarantee", 1, TableAction.On);
                FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "Abstract", 1, TableAction.On);

                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.GiveFocus();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsFind.FAClick();
                //this might be bugged, lets talk to the Manual QA Guys;
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(4500);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsFind.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("Title Agent");
                FastDriver.NewFileEntry.DetailsSearchType.FASelectItem("No Search Type");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Husband/Wife");
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText("Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText("Buyer2Lastname" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText("Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();

                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText("Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText("Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText("Seller2SpouseName");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.NewFileEntry.FormType_CD.FAClick();
                }
                else
                    if (AutoConfig.FormType.ToLower().Equals("hud"))
                    {
                        FastDriver.NewFileEntry.FormType_HUD.FAClick();
                    }

                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText("92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem("Orange");
                FastDriver.NewFileEntry.DetailsSalePrice.FASetText("600,000.00");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText("250,000.00");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText("150,000.00");

                //
                Reports.TestStep = "Validate the Pending file-Details Tab.";
                Support.AreEqual("Residential", FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryBusinessSegment");
                Support.AreEqual("Sale w/Mortgage", FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryTransactionType");
                Support.AreEqual("No Program Type", FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryProgramType");
                Support.AreEqual("Title Agent", FastDriver.NewFileEntry.DetailsAddtionalRole.FAGetSelectedItem(), "Verifies the DetailsAddtionalRole");
                Support.AreEqual("No Search Type", FastDriver.NewFileEntry.DetailsSearchType.FAGetSelectedItem(), "Verifies the DetailsSearchType");
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.DetailsBuyerType.FAGetSelectedItem(), "Verifies the DetailsBuyerType");
                Support.AreEqual("Buyer2Firstname", FastDriver.NewFileEntry.DetailsBuyerHusbandName.FAGetValue(), "Verifies the DetailsBuyerHusbandName");
                Support.AreEqual("Buyer2Lastname", FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FAGetValue(), "Verifies the DetailsBuyerHusbandLast");
                Support.AreEqual("Buyer2SpouseName", FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FAGetValue(), "Verifies the DetailsBuyerSpouseFirstName");
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.DetailsSellerType.FAGetSelectedItem(), "Verifies the DetailsSellerType");
                Support.AreEqual("Seller2Firstname", FastDriver.NewFileEntry.DetailsSellerHusbandName.FAGetValue(), "Verifies the DetailsSellerHusbandName");
                Support.AreEqual("Seller2Lastname", FastDriver.NewFileEntry.DetailsSellerHusbandLast.FAGetValue(), "Verifies the DetailsSellerHusbandLast");
                Support.AreEqual("Seller2SpouseName", FastDriver.NewFileEntry.DetailsSellerSpouseName.FAGetValue(), "Verifies the DetailsSellerSpouseName");
                Support.AreEqual("1 First American Way", FastDriver.NewFileEntry.DetailsPropertyStreet1.FAGetValue(), "Verifies the DetailsPropertyStreet1");
                Support.AreEqual("PropertyStreet3", FastDriver.NewFileEntry.DetailsPropertyStreet3.FAGetValue(), "Verifies the DetailsPropertyStreet3");
                Support.AreEqual("PropertyStreet4", FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue(), "Verifies the DetailsPropertyStreet4");
                Support.AreEqual("PropertyStreet4", FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue(), "Verifies the DetailsPropertyStreet4");
                Support.AreEqual("Santa Ana", FastDriver.NewFileEntry.DetailsPropertyCity.FAGetValue(), "Verifies the DetailsPropertyCity");
                Support.AreEqual("CA", FastDriver.NewFileEntry.DetailsPropertyState.FAGetSelectedItem(), "Verifies the DetailsPropertyState");
                Support.AreEqual("92707", FastDriver.NewFileEntry.DetailsPropertyZIP.FAGetValue(), "Verifies the DetailsPropertyZIP");
                Support.AreEqual("Orange", FastDriver.NewFileEntry.DetailsPropertyCounty.FAGetSelectedItem(), "Verifies the DetailsPropertyCounty");
                Support.AreEqual("600,000.00", FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue(), "Verifies the DetailsSalePrice");
                Support.AreEqual("250,000.00", FastDriver.NewFileEntry.DetailsFirstNewLoan.FAGetValue(), "Verifies the DetailsFirstNewLoan");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.FAGetText().Contains("ALTA Extended Leasehold Owners Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        bool policyExists = FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("Manufactured Home Loan Policy");
                        return policyExists;
                    }, timeout: 30, idleInterval: 2);
                }

                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);
                FastDriver.NewFileEntry.LenderPolicyTable.PerformTableAction(2, "Manufactured Home Loan Policy", 1, TableAction.On);
                FastDriver.NewFileEntry.GuaranteeTable.PerformTableAction(2, "Combo Guarantee", 1, TableAction.On);
                FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "Abstract", 1, TableAction.On);
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Enter data for Parties Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.PartiesParties.FAClick();
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PartiesDirectedByGABcode);
                FastDriver.NewFileEntry.PartiesDirectedByGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.PartiesDirectedByFind.FAClick();
                Playback.Wait(3000);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyFind.FAClick();
                Playback.Wait(3000);
                //
                Reports.TestStep = "Validate the Pending file-Parties Tab.";
                //FastDriver.WebDriver.WaitForActionToComplete()
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.NewFileEntry.PartiesParties.FAClick();

                        return FastDriver.NewFileEntry.PropertyInfoPropertyInfo.Exists();
                    }, timeout: 30, idleInterval: 2);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Enter data for PartiesPropertyInfo Tab.";
                //FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyInfo);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.PropertyInfoPropertyInfo.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyType);
                FastDriver.NewFileEntry.PropertyInfoPropertyType.FASelectItem("Single Family Residence");
                Keyboard.SendKeys("{ENTER}");
                FastDriver.NewFileEntry.PropertyInfoLot.FASetText("Lot1");
                FastDriver.NewFileEntry.PropertyInfoBlock.FASetText("Block1");
                FastDriver.NewFileEntry.PropertyInfoUnit.FASetText("Unit1");
                FastDriver.NewFileEntry.PropertyInfoTrack.FASetText("Tract1");
                FastDriver.NewFileEntry.PropertyInfoFee.FASetText("Fee1");
                FastDriver.NewFileEntry.PropertyInfoBuilding.FASetText("Building1");
                FastDriver.NewFileEntry.PropertyInfoBook.FASetText("Book1");
                FastDriver.NewFileEntry.PropertyInfoPage.FASetText("Page1");
                FastDriver.NewFileEntry.PropertyInfoSection.FASetText("Section1");

                //
                Reports.TestStep = "Validate the Pending file-PropertyInfoTab.";
                Support.AreEqual("Single Family Residence", FastDriver.NewFileEntry.PropertyInfoPropertyType.FAGetSelectedItem(), "Verifies the PropertyInfoPropertyType");
                Support.AreEqual("Lot1", FastDriver.NewFileEntry.PropertyInfoLot.FAGetValue(), "Verifies the DetailsFirstNewLoan");
                Support.AreEqual("Block1", FastDriver.NewFileEntry.PropertyInfoBlock.FAGetValue(), "Verifies the PropertyInfoBlock");
                Support.AreEqual("Unit1", FastDriver.NewFileEntry.PropertyInfoUnit.FAGetValue(), "Verifies the PropertyInfoUnit");
                Support.AreEqual("Tract1", FastDriver.NewFileEntry.PropertyInfoTrack.FAGetValue(), "Verifies the PropertyInfoTrack");
                Support.AreEqual("Fee1", FastDriver.NewFileEntry.PropertyInfoFee.FAGetValue(), "Verifies the PropertyInfoFee");
                Support.AreEqual("Building1", FastDriver.NewFileEntry.PropertyInfoBuilding.FAGetValue(), "Verifies the PropertyInfoBuilding");
                Support.AreEqual("Book1", FastDriver.NewFileEntry.PropertyInfoBook.FAGetValue(), "Verifies the PropertyInfoBook");
                Support.AreEqual("Page1", FastDriver.NewFileEntry.PropertyInfoPage.FAGetValue(), "Verifies the PropertyInfoPage");
                Support.AreEqual("Section1", FastDriver.NewFileEntry.PropertyInfoSection.FAGetValue(), "Verifies the PropertyInfoSection");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Enter data for Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();

                //
                Reports.TestStep = "Validate the Pending file- Lender/Mortgage Broker Tab.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers);
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();

                //
                Reports.TestStep = "Click on AddNew in Payoff section.";
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderAddNew.FAClick();

                //
                Reports.TestStep = "Enter first Payoff lender.";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderAddNew);
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderGABcode.FASetText("HUDPAYOFF1");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderFind.FAClick();

                //
                Reports.TestStep = "Enter data for Special Instructions Tab.";
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FASetText("SpecialInstruction Notes Data including - * # Specialcharacter :) ! ");

                //
                Reports.TestStep = "Validate the Pending file- Special Instructions Tab.";
                Support.AreEqual("SpecialInstruction Notes Data including - * # Specialcharacter :) ! ", FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FAGetText());
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);

                //
                Reports.TestStep = "Scan document to the Pending File.";
                Reports.TestStep = "Scan document to the Pending File.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad(FastDriver.NewFileEntry.DetailsScan);
                //FastDriver.PendingFileSearch.ClickOnSkipSearch();
                // FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsScan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to hFastDriver.OpenImageDlg.OpenImage(this.ReadConfig("sharedLocation", () => AutoConfig.WFEServerName) + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Playback.Wait(4000); //wait for Save Document dialog (wbacause we are using AutoIt to handle it)
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Validate the scan is done.";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsRefresh.FAClick();
                    return FastDriver.NewFileEntry.UploadedDocumentsTable.FAGetText().Contains("INST-Estimated Settlement Statement");
                });

                //
                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();
                // Playback.Wait(4500);

                //
                Reports.TestStep = "Validate all parties are visible in Dialog.";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_FM10153_FM10158_FM10154_FM10155_FM10156_FM10157_FD_Status: Pending File Statuses.";
                this.Login();

                //
                Reports.TestStep = "Create details.";
                this.NavigateToNewFileEntry();
                FastDriver.BottomFrame.New();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                Support.AreEqual(AutoConfig.SelectedOfficeName + " PR: STEST off: 7878(1487)", FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedItem());
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem("No Program Type");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);

                FastDriver.NewFileEntry.DetailsBussSourceGABcode.GiveFocus();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.FASetText("HUDFLINSR1" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsFind.FAClick();
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("Title Agent");
                FastDriver.NewFileEntry.DetailsSearchType.FASelectItem("No Search Type");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Husband/Wife");
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText("Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText("Buyer2Lastname" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText("Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText("Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText("Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText("Seller2SpouseName");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.NewFileEntry.FormType_CD.FAClick();
                }
                else
                    if (AutoConfig.FormType.ToLower().Equals("hud"))
                    {
                        FastDriver.NewFileEntry.FormType_HUD.FAClick();
                    }

                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText("92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem("Orange");
                FastDriver.NewFileEntry.DetailsSalePrice.FASetText("600,000.00");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText("250,000.00");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText("150,000.00");

                //
                Reports.TestStep = "Validate the File Status before Save of NFE.";
                Support.AreEqual(FastDriver.NewFileEntry.FileStatus.FAGetText().Clean(), " Pending Open".Clean());
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);

                //
                Reports.TestStep = "Validate the File Status after Save of NFE.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", toExist: false);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.NewFileEntry.FileStatus.FAGetText().Clean(), " Pending Open Cancelled Open In Error".Clean());

                //
                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.PartiesParties.FAClick();
                Playback.Wait(4500);

                //
                Reports.TestStep = "Change file status to Cancelled.";
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Cancelled");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);

                //
                Reports.TestStep = "Navigate to Property Info tab.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", toExist: false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.PropertyInfoPropertyInfo.FAClick();

                //
                Reports.TestStep = "Change file status back to Pending from Cancelled.";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.FileStatus);
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Pending");
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", toExist: false);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnLenderMortgageBrokerTab();

                //
                Reports.TestStep = "Change file status to Open In Error.";
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open In Error");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);

                //
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                Reports.TestStep = "Navigate to Special Instructions Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnSpecialInstructionsTab();

                //
                Reports.TestStep = "Change file status back to Pending.";
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open In Error");
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Change the status to Open.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", toExist: false);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.FileStatus);
                FastDriver.NewFileEntry.ClickOnDetailsTab();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                string detailsCustomFileNumber = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", toExist: false);

                //
                Reports.TestStep = "Verify file is Open.";
                FastDriver.PendingFileSearch.WaitForScreenToLoad(FastDriver.PendingFileSearch.SkipSearch);

                //
                Reports.TestStep = "Validate file number from NFE.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(detailsCustomFileNumber, FastDriver.FileHomepage.FileNum.FAGetValue());
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0005_REG0005B()
        {
            try
            {
                Reports.TestDescription = "BR_FM10160_FM10174: Assign a FAST file number.";
                this.Login();

                //
                Reports.TestStep = "Create a Pending file-Details Tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Leasehold Owners Policy", saveFile: false);

                //
                Reports.TestStep = "Uncheck the Auto Number Checkbox.";
                FastDriver.NewFileEntry.DetailsAutoNumber.FASetCheckbox(false);

                //
                Reports.TestStep = "Enter Manual File number.";
                string prefx1 = "QQQ";
                FastDriver.NewFileEntry.DetailsNewFileEntryPrefix.FASetText(prefx1);
                string File1 = Support.RandomString("NZNZNNZN");
                FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FASetText(File1);
                string sufix1 = "PPP";
                FastDriver.NewFileEntry.DetailsNewFileEntrySuffix.FASetText(sufix1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                //
                Reports.TestStep = "Validate file number is non editable.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.NewFileEntry.DetailsNewFileEntryPrefix.Enabled.ToString(), "Verifies DetailsNewFileEntryPrefix is disabled");
                Support.AreEqual("False", FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.Enabled.ToString(), "Verifies DetailsNewFileEntryCustFileNo is disabled");
                Support.AreEqual("False", FastDriver.NewFileEntry.DetailsNewFileEntrySuffix.Enabled.ToString(), "Verifies DetailsNewFileEntrySuffix is disabled");
                Support.AreEqual("False", FastDriver.NewFileEntry.DetailsAutoNumber.Selected.ToString(), "Verifies DetailsNewFileEntrySuffix is disabled");

                //
                Reports.TestStep = "Validate file number entered manually.";
                Support.AreEqual(prefx1, FastDriver.NewFileEntry.DetailsNewFileEntryPrefix.FAGetValue().ToString());
                Support.AreEqual(File1, FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue().ToString());
                Support.AreEqual(sufix1, FastDriver.NewFileEntry.DetailsNewFileEntrySuffix.FAGetValue().ToString());

                //***Steps for REG0005B***//

                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                //***Steps for REG0005B***//
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR_FM10161_ER2_ER3_ER4_ER5_ER18: Mandatory values to create a Pending File.";
                this.Login();

                //
                Reports.TestStep = "Navigate to New File Entry. - NFE0046";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                //
                Reports.TestStep = "Create order without Business Segment in NFE.";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                //
                Reports.TestStep = "Remove the Business Segment.";
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Create order without Business Segment in NFE Dialog Handling.";
                Support.AreEqual("Business Segment is required.", FastDriver.WebDriver.HandleDialogMessage(timeout: 15));
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Select a Business Segment.";
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Create order without Transaction segment in NFE.";
                Support.AreEqual("Transaction Type is required.", FastDriver.WebDriver.HandleDialogMessage(timeout: 15));
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Select a Transaction Type.";
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Accommodation");
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Create order without Business Party in NFE.";
                Support.AreEqual("Business Source is required.", FastDriver.WebDriver.HandleDialogMessage(timeout: 15));
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Select a Business Source.";
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Create order without Property State in QFE. Dialog";
                Support.AreEqual("Property State is a required field.  Please enter State before saving.", FastDriver.WebDriver.HandleDialogMessage(timeout: 15));
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Select a State.";
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                FastDriver.NewFileEntry.FormType_CD.FAClick();

                //
                Reports.TestStep = "Remove service types.";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(false);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Create order without Service Type in NFE. Dialog";
                Support.AreEqual("Service Type is required.", FastDriver.WebDriver.HandleDialogMessage(timeout: 15));
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Select T/E service types.";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);

                //
                Reports.TestStep = "Remove Underwriter.";
                FastDriver.NewFileEntry.DetailsNewFileEntryUnderWriters.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Set Underwriter to Blank and Save. DIalog Handling";
                Support.AreEqual("Underwriter is required", FastDriver.WebDriver.HandleDialogMessage(timeout: 15));
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Select Underwriter.";
                FastDriver.NewFileEntry.DetailsNewFileEntryUnderWriters.FASelectItem("First American Title Insurance Company");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                // This verification cannot be done.
                //Reports.TestStep = "Validate error message if no product is selected and select a product.";
                //if (FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span")
                //  .FirstOrDefault(p => p.GetAttribute("text").Contains("Service File: Atleast one product required.")) != null)
                //{
                //    Reports.TestStep = "Select a Product.";
                //    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);
                //    FastDriver.BottomFrame.Save();
                //    Playback.Wait(3500);
                //}

                //***Steps For REG0006B***//
                Reports.TestDescription = "Change the status of the Pending order to Open from the previous flow.";

                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0007()
        {
            try
            {
                Reports.TestDescription = "BR_FM10162_FM10163_FM10164_FM10222: Ability to capture Commission details for Parties (Business Source and Buyers Broker).";
                this.Login();
                //
                Reports.TestStep = "Select data in Details tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile();

                //
                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                string file1 = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue();
                FastDriver.BottomFrame.Done();

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "To verify the buyer's broker created via NFE.";
                    try
                    {
                        FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                    }
                    catch (Exception)
                    {
                        Reports.TestStep = "Load file";

                        FastDriver.TopFrame.SwitchToTopFrame();
                        FastDriver.TopFrame.FileNumberEditBox.SendKeys(FAKeys.Enter);
                        Playback.Wait(7000);
                        FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker>Agent");
                    }
                    FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.Click);
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                }
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0008()
        {
            try
            {
                Reports.TestDescription = "BR_FM10162_01_FM10163_01_FM10164_01_FM10222_01: Ability to capture Commission details for Parties (Directed By, Associated Party and Seller's Broker).";
                this.Login();
                //
                Reports.TestStep = "Create a Pending file-Details Tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "No Product Issued", saveFile: false);

                //
                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                //
                Reports.TestStep = "Enter data for Parties Tab with additional Role.";
                FastDriver.NewFileEntry.PartiesDirectedByGABcode.FASetText("HUDASLNDR1");
                FastDriver.NewFileEntry.PartiesDirectedByFind.FAClick();
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASelectItem("Seller's Broker");
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASendKeys(FAKeys.Tab);
                FastDriver.NewFileEntry.PartiesDirectedByPercent.FASetText("20.0000" + FAKeys.Tab);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyGABcode.FASetText("HUDASLNDR2");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyFind.FAClick();
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddtionalRole.FASelectItem("Buyer's Broker");
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASendKeys(FAKeys.Tab);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyPercent.FASetText("20.0000" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                //
                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                string file1 = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetText();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                //
                Reports.TestStep = "To verify the seller's broker created via NFE.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Assumption Lender 1 for HUD Test Name 1", 3, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//span[.='20 %']").FAClick();
                FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//span[.='120,000.00']").FAClick();
                //FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//span[.='20 %']").FAClick();
                //FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//span[.='20 %']").FAClick();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0009()
        {
            try
            {
                Reports.TestDescription = "BR_FM10165: Prepopulate Business Organization information to Additional Role.";
                this.Login();
                //
                Reports.TestStep = "Create details with additional role as New Lender.";
                this.NavigateToNewFileEntry();
                this.NewFileDetailsCheckBoxesCheck();
                this.DetailsNFETypesComboBoxes();
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("New Lender");
                FastDriver.NewFileEntry.DetailsSearchType.FASelectItem("No Search Type");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Husband/Wife");

                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText("Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText("Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText("Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(5000);

                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText("Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText("Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText("Seller2SpouseName");

                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.NewFileEntry.FormType_CD.FAClick();
                }
                else
                    if (AutoConfig.FormType.ToLower().Equals("hud"))
                    {
                        FastDriver.NewFileEntry.FormType_HUD.FAClick();
                    }

                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText("92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem("Orange");
                FastDriver.NewFileEntry.DetailsSalePrice.FASetText("600,000.00");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText("250,000.00");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText("150,000.00");
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                try
                {
                    FastDriver.PendingFileSearch.WaitForScreenToLoad();
                    FastDriver.PendingFileSearch.ClickOnSkipSearch();
                }
                catch (Exception)
                { }
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();

                //
                Reports.TestStep = "Validate new lender in Lender Mortgage Tab.";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0107_REG0010()
        {
            try
            {
                Reports.TestDescription = "BR_FM10166_FM10167_FM10168: Add documents to the Pending File.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };

                #endregion data setup

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                Reports.TestStep = "Create details with additional role as New Lender.";
                this.NavigateToNewFileEntry();
                this.NewFileDetailsCheckBoxesCheck();
                this.DetailsNFETypesComboBoxes();
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("New Lender");
                FastDriver.NewFileEntry.DetailsSearchType.FASelectItem("No Search Type");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Husband/Wife");

                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText("Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText("Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText("Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(5000);

                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText("Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText("Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText("Seller2SpouseName");

                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.NewFileEntry.FormType_CD.FAClick();
                }
                else
                    if (AutoConfig.FormType.ToLower().Equals("hud"))
                    {
                        FastDriver.NewFileEntry.FormType_HUD.FAClick();
                    }

                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText("92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem("Orange");
                FastDriver.NewFileEntry.DetailsSalePrice.FASetText("600,000.00");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText("250,000.00");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText("150,000.00");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                //try
                //{
                //    FastDriver.PendingFileSearch.WaitForScreenToLoad();
                //    FastDriver.PendingFileSearch.ClickOnSkipSearch();
                //}
                //catch (Exception)
                //{ }
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();

                //
                Reports.TestStep = "Validate new lender in Lender Mortgage Tab.";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);

                //REG010

                //
                Reports.TestStep = "Navigate to Details tab.";
                //if (FastDriver.PendingFileSearch.SkipSearch.Exists())
                //    FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.ClickOnDetailsTab();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //
                Reports.TestStep = "Scan document to the Pending File.";
                //FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsScan.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to hFastDriver.OpenImageDlg.OpenImage(this.ReadConfig("sharedLocation", () => AutoConfig.WFEServerName) + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Playback.Wait(4000); //wait for Save Document dialog (wbacause we are using AutoIt to handle it)
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Closing Statements", "INST-Estimated Settlement Statement", "", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsRefresh.FAClick();

                //
                Reports.TestStep = "Validate the scan is done.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate the uploaded Documents form NFE are present in DocRep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.Text.Contains("INST-Estimated Settlement Statement"), "Verify whether the .tif img is present in the Document Table.");
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void FMUC0107_REG0011()
        {
            try
            {
                Reports.TestDescription = "BR_FM10169_FM10171_FM10173_FD_Documents: Upload documents(pdf).";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };

                #endregion data setup

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                Reports.TestStep = "Create details with additional role as New Lender.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile();

                //
                Reports.TestStep = "Click on Upload button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsUpload.FAClick();

                //
                Reports.TestStep = "Browse document and upload it.(pdf).";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(Reports.DEPLOYDIR + @"\EMAIL_Offshore_Pdf.pdf");
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                //
                Reports.TestStep = "Save the PDF Doc.";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("Miscellaneous");
                FastDriver.SaveDocumentDlg.DocumentName.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("PDFDocument");
                FastDriver.SaveDocumentDlg.AdditionalInfo.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.Ok.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsRefresh.FAClick();
                    Playback.Wait(2000);
                    return FastDriver.NewFileEntry.UploadedDocumentsTable.Text.Contains("Miscellaneous PDFDocument");
                }, timeout: 120, idleInterval: 5);
                Playback.Wait(3500);

                //
                Reports.TestStep = "Validate the PDF uploaded.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.UploadedDocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.Click);
                FastDriver.NewFileEntry.MouseOverUploadedImg();
                Support.AreEqual(true, FastDriver.NewFileEntry.UploadedImg.Exists(), "Verify whether the img icon does exist.");
                Support.AreEqual("View Document", FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"), "Verify  the tootlkit message.  " + FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"));
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate the uploaded Documents form NFE are present in DocRep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.Text.Contains("Miscellaneous PDFDocument"), "Verify whether the PDF document is present in the Document Table.");
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC0107_REG0012()
        {
            try
            {
                Reports.TestDescription = "BR_FM10169_001_FM10171: Upload documents(jpg).";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };

                #endregion data setup

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                this.EnterStandardNewFileData(false);
                //
                Reports.TestStep = "Click on Upload button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.DetailsUpload);
                FastDriver.NewFileEntry.DetailsUpload.FAClick();

                //
                Reports.TestStep = "Browse document and upload it.(jpg).";
                Playback.Wait(10000);
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(Reports.DEPLOYDIR + @"\JpegFile.jpg");
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                //
                Reports.TestStep = "Save the JPG file.";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("Miscellaneous");
                FastDriver.SaveDocumentDlg.DocumentName.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("JPGFile");
                FastDriver.SaveDocumentDlg.AdditionalInfo.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.Ok.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsRefresh.FAClick();
                    Playback.Wait(2000);
                    return FastDriver.NewFileEntry.UploadedDocumentsTable.Text.Contains("Miscellaneous JPGFile");
                }, timeout: 120, idleInterval: 5);
                Playback.Wait(3500);
                //
                Reports.TestStep = "Validate the JPG uploaded.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.UploadedDocumentsTable.PerformTableAction("Name", "Miscellaneous JPGFile", "Name", TableAction.Click);
                FastDriver.NewFileEntry.MouseOverUploadedImg();
                Support.AreEqual(true, FastDriver.NewFileEntry.UploadedImg.Exists(), "Verify whether the img icon does exist.");
                Support.AreEqual("View Document", FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"), "Verify  the tootlkit message.  " + FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"));
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate the uploaded Documents form NFE are present in DocRep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.Text.Contains("Miscellaneous JPGFile"), "Verify whether the .jpg img is present in the Document Table.");
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0107_REG0013()
        {
            try
            {
                Reports.TestDescription = "BR_FM10169_002_FM10171: Upload documents(tiff).";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };

                #endregion data setup

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                this.EnterStandardNewFileData(false);
                //
                Reports.TestStep = "Click on Upload button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.DetailsUpload);
                FastDriver.NewFileEntry.DetailsUpload.FAClick();

                //
                Reports.TestStep = "Browse document and upload it.(tiff).";
                Playback.Wait(10000);
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                //
                Reports.TestStep = "Save the tiff file.";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("Miscellaneous");
                FastDriver.SaveDocumentDlg.DocumentName.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("TIFFFile");
                FastDriver.SaveDocumentDlg.AdditionalInfo.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.Ok.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsRefresh.FAClick();
                    Playback.Wait(2000);
                    return FastDriver.NewFileEntry.UploadedDocumentsTable.Text.Contains("Miscellaneous TIFFFile");
                }, timeout: 120, idleInterval: 5);
                Playback.Wait(3500);

                //
                Reports.TestStep = "Validate the tiff uploaded.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.UploadedDocumentsTable.PerformTableAction("Name", "Miscellaneous TIFFFile", "Name", TableAction.Click);
                FastDriver.NewFileEntry.MouseOverUploadedImg();
                Support.AreEqual(true, FastDriver.NewFileEntry.UploadedImg.Exists(), "Verify whether the img icon does exist.");
                Support.AreEqual("View Document", FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"), "Verify  the tootlkit message.  " + FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"));
            }
            catch (System.Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\GeneralForm2.doc")]
        public void FMUC0107_REG0014()
        {
            try
            {
                Reports.TestDescription = "BR_FM10169_003_FM10171: Upload documents(doc).";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };

                #endregion data setup

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create standard File.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false);

                //
                Reports.TestStep = "Click on Upload button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsUpload.FAClick();

                //
                Reports.TestStep = "Browse document and upload it.(doc).";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(Reports.DEPLOYDIR + @"\GeneralForm2.doc");
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                //
                Reports.TestStep = "Save the doc file.";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("Miscellaneous");
                FastDriver.SaveDocumentDlg.DocumentName.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("DOCFile");
                FastDriver.SaveDocumentDlg.AdditionalInfo.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.Ok.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsRefresh.FAClick();
                    Playback.Wait(2000);
                    return FastDriver.NewFileEntry.UploadedDocumentsTable.Text.Contains("Miscellaneous DOCFile");
                }, timeout: 120, idleInterval: 5);
                Playback.Wait(3500);

                //
                //
                Reports.TestStep = "Validate the tiff uploaded.";
                FastDriver.NewFileEntry.UploadedDocumentsTable.PerformTableAction("Name", "Miscellaneous DOCFile", "Name", TableAction.Click);
                FastDriver.NewFileEntry.MouseOverUploadedImg();
                Support.AreEqual(true, FastDriver.NewFileEntry.UploadedImg.Exists(), "Verify whether the img icon does exist.");
                Support.AreEqual("View Document", FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"), "Verify  the tootlkit message.  " + FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"));
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate the uploaded Documents form NFE are present in DocRep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.Text.Contains("Miscellaneous DOCFile"), "Verify whether the .doc document is present in the Document Table.");
            }
            catch (System.Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\DOCXFormat.docx")]
        public void FMUC0107_REG0015()
        {
            try
            {
                Reports.TestDescription = "BR_FM10169_004_FM10171: Upload documents(docx).";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };

                #endregion data setup

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                this.EnterStandardNewFileData(false);
                //
                Reports.TestStep = "Click on Upload button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsUpload.FAClick();

                //
                Reports.TestStep = "Browse document and upload it.(docx).";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(Reports.DEPLOYDIR + @"\DOCXFormat.docx");
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                //
                Reports.TestStep = "Save the DOCX file.";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("Miscellaneous");
                FastDriver.SaveDocumentDlg.DocumentName.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("DOCXFile");
                FastDriver.SaveDocumentDlg.AdditionalInfo.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.Ok.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsRefresh.FAClick();
                    Playback.Wait(2000);
                    return FastDriver.NewFileEntry.UploadedDocumentsTable.Text.Contains("Miscellaneous DOCXFile");
                }, timeout: 120, idleInterval: 5);
                Playback.Wait(3500);

                //
                //
                Reports.TestStep = "Validate the DOCXFile uploaded.";
                FastDriver.NewFileEntry.UploadedDocumentsTable.PerformTableAction("Name", "Miscellaneous DOCXFile", "Name", TableAction.Click);
                FastDriver.NewFileEntry.MouseOverUploadedImg();
                Support.AreEqual(true, FastDriver.NewFileEntry.UploadedImg.Exists(), "Verify whether the img icon does exist.");
                Support.AreEqual("View Document", FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"), "Verify  the tootlkit message.  " + FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"));
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate the uploaded Documents form NFE are present in DocRep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.Text.Contains("Miscellaneous DOCXFile"), "Verify whether the .docx document is present in the Document Table.");
            }
            catch (System.Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\UseCase_Dictionary.xls")]
        public void FMUC0107_REG0016()
        {
            try
            {
                Reports.TestDescription = "BR_FM10169_005_FM10171: Upload documents(xls).";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };

                #endregion data setup

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                this.EnterStandardNewFileData(false);
                //
                Reports.TestStep = "Click on Upload button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsUpload.FAClick();

                //
                Reports.TestStep = "Browse document and upload it.(xls).";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(Reports.DEPLOYDIR + @"\UseCase_Dictionary.xls");
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                //
                Reports.TestStep = "Save the xls file.";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("Miscellaneous");
                FastDriver.SaveDocumentDlg.DocumentName.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("XLSFile");
                FastDriver.SaveDocumentDlg.AdditionalInfo.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.Ok.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsRefresh.FAClick();
                    Playback.Wait(2000);
                    return FastDriver.NewFileEntry.UploadedDocumentsTable.Text.Contains("Miscellaneous XLSFile");
                }, timeout: 120, idleInterval: 5);
                Playback.Wait(3500);

                //
                Reports.TestStep = "Validate the XLSFile uploaded.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.UploadedDocumentsTable.PerformTableAction("Name", "Miscellaneous XLSFile", "Name", TableAction.Click);
                FastDriver.NewFileEntry.MouseOverUploadedImg();
                Support.AreEqual(true, FastDriver.NewFileEntry.UploadedImg.Exists(), "Verify whether the img icon does exist.");
                Support.AreEqual("View Document", FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"), "Verify  the tootlkit message.  " + FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"));
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate the uploaded Documents form NFE are present in DocRep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.Text.Contains("Miscellaneous XLSFile"), "Verify whether the .xls document is present in the Document Table.");
            }
            catch (System.Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\UseCase_Dictionary_11.xlsx")]
        public void FMUC0107_REG0017()
        {
            try
            {
                Reports.TestDescription = "BR_FM10169_006_FM10171: Upload documents(xlsx).";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };

                #endregion data setup

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                this.EnterStandardNewFileData(false);
                //
                Reports.TestStep = "Click on Upload button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsUpload.FAClick();

                //
                Reports.TestStep = "Browse document and upload it.(xlsx).";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(Reports.DEPLOYDIR + @"\UseCase_Dictionary_11.xlsx");
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                //
                Reports.TestStep = "Save the xlsx file.";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("Miscellaneous");
                FastDriver.SaveDocumentDlg.DocumentName.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("xlsxFile");
                FastDriver.SaveDocumentDlg.AdditionalInfo.SendKeys(FAKeys.Tab);
                FastDriver.SaveDocumentDlg.Ok.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Refresh the page.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsRefresh.FAClick();
                    Playback.Wait(2000);
                    return FastDriver.NewFileEntry.UploadedDocumentsTable.Text.Contains("Miscellaneous xlsxFile");
                }, timeout: 120, idleInterval: 5);
                Playback.Wait(3500);

                //
                Reports.TestStep = "Validate the xlsx uploaded.";
                FastDriver.NewFileEntry.UploadedDocumentsTable.PerformTableAction("Name", "Miscellaneous xlsxFile", "Name", TableAction.Click);
                FastDriver.NewFileEntry.MouseOverUploadedImg();
                Support.AreEqual(true, FastDriver.NewFileEntry.UploadedImg.Exists(), "Verify whether the img icon does exist.");
                Support.AreEqual("View Document", FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"), "Verify  the tootlkit message.  " + FastDriver.NewFileEntry.UploadedImg.FAGetAttribute("title"));
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Validate the uploaded Documents form NFE are present in DocRep.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.Text.Contains("Miscellaneous xlsxFile"), "Verify whether the .xlsx document is present in the Document Table.");
            }
            catch (System.Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0018()
        {//TODO
            try
            {
                Reports.TestDescription = "BR_FM10170: Display as Icon.";
                this.Login();
                Reports.StatusUpdate("This TestCase was split into the former testcases, so each one verifies its on icons", true);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [TestMethod]
        public void FMUC0107_REG0019()
        {//TODO
            try
            {
                Reports.TestDescription = "BR_FM10170: Display as Icon.";
                this.Login();
                Reports.StatusUpdate("This TestCase was split into the former testcases, so each one verifies its on icons", true);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [TestMethod]
        public void FMUC0107_REG0020()
        {
            try
            {
                Reports.TestDescription = "BR_FM10180_001: Added Documents in Doc Rep.";
                this.Login();

                //
                Reports.TestStep = "Change the status to Open.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0022()
        {
            try
            {
                Reports.TestDescription = "BR_FM10175: Service Types.";
                this.Login();

                //
                Reports.TestStep = "Create a Title Pending file-Details Tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                this.NewFileDetailsCheckBoxesCheck(DetailsEscrowcheckbox: false);
                this.EnterStandardNewFileData(false, false);

                //
                Reports.TestStep = "Check the Escrow checkbox in Details tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Validate Title and Escrow service is checked.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString());
                Support.AreEqual("True", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString());

                //
                Reports.TestStep = "Click on ChangeO/O button.";
                FastDriver.NewFileEntry.DetailsChangeOObutton.FAClick();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Remove Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Validate Title alone is checked.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString());
                Support.AreEqual("False", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString());
                Support.AreEqual("False", FastDriver.NewFileEntry.DetailsSubEscrowcheckbox.Selected.ToString());

                //
                Reports.TestStep = "Check the Sub-Escrow checkbox in Details tab.";
                FastDriver.NewFileEntry.DetailsSubEscrowcheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(3000);

                //
                Reports.TestStep = "Validate Title and Sub Escrow service is checked.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString());
                Support.AreEqual("False", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString());
                Support.AreEqual("True", FastDriver.NewFileEntry.DetailsSubEscrowcheckbox.Selected.ToString());

                //
                Reports.TestStep = "Click on ChangeO/O button.";
                FastDriver.NewFileEntry.DetailsChangeOObutton.FAClick();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Check the Escrow checkbox in Details tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Click on ChangeO/O button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsChangeOObutton.FAClick();
                Playback.Wait(5000);

                //
                Reports.TestStep = "Remove Title Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Title.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Check the Sub-Escrow checkbox in Details tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsSubEscrowcheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(3000);

                //
                Reports.TestStep = "Validate Escrow and Sub Escrow service is checked.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString());
                Support.AreEqual("True", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString());
                Support.AreEqual("True", FastDriver.NewFileEntry.DetailsSubEscrowcheckbox.Selected.ToString());

                //
                Reports.TestStep = "Check the Title checkbox in Details tab.";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Select all three service type in NFE.";
                Support.AreEqual("You cannot select both Title and Escrow services with Sub Escrow. Please select either Title or Escrow service with Sub Escrow.", FastDriver.WebDriver.HandleDialogMessage());

                //
                Reports.TestStep = "Uncheck the Title checkbox in Details tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(false);
                Support.AreEqual("True", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString());
                Support.AreEqual("True", FastDriver.NewFileEntry.DetailsSubEscrowcheckbox.Selected.ToString());
                FastDriver.BottomFrame.Save();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0023()
        {
            try
            {
                Reports.TestDescription = "BR_FM10176: Escrow Owning Office and Title Owning Office.";
                this.Login();
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                this.NewFileDetailsCheckBoxesCheck(DetailsEscrowcheckbox: false);
                this.EnterStandardNewFileData(false, false);

                //
                Reports.TestStep = "Select T/E Assistant and Officer.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FASelectItem(AutoConfig.SelectedOfficeName + " PR: STEST off: 7878(1487)");
                FastDriver.NewFileEntry.DetailsNewFileEntryTitleOfficer.FASelectItem("QA10, FAST");
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FASelectItem(AutoConfig.SelectedOfficeName + " PR: STEST off: 7878(1487)");
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOfficer.FASelectItem("QA10, FAST");
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowAssisstant.FASelectItem("QA10, FAST");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                // Playback.Wait(4500);

                //
                Reports.TestStep = "Validate T/E Assistant and Officer.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetSelectedItem().Clean(), AutoConfig.SelectedOfficeName + " PR: STEST off: 7878(1487)");
                Support.AreEqual(FastDriver.NewFileEntry.DetailsNewFileEntryTitleOfficer.FAGetSelectedItem().Clean(), "QA10, FAST");
                Support.AreEqual(FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedItem().Clean(), AutoConfig.SelectedOfficeName + " PR: STEST off: 7878(1487)");
                Support.AreEqual(FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOfficer.FAGetSelectedItem().Clean(), "QA10, FAST");
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0024_25()
        {
            try
            {
                Reports.TestDescription = "BR_FM10187_FM10188_FM10190_FM10189_FD_Dates: Terms and Dates." + "  REG005: BR_FM10187_001_FM10188_001_FM10190_001_FM10189_001: Terms and Dates(Validate).";
                this.Login();
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                this.NewFileDetailsCheckBoxesCheck(DetailsEscrowcheckbox: false);
                this.EnterStandardNewFileData(false, false);

                //
                Reports.TestStep = "Enter data for Dates section in details screen.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                var estimatedDays = "none";
                if (DateTime.Today.AddDays(Convert.ToInt32("100")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("100")).DayOfWeek.ToString() == "Sunday")
                    estimatedDays = "103";//(Convert.ToInt32("100") + 3).ToString();
                else
                    estimatedDays = "100";

                FastDriver.NewFileEntry.DetailsEstimatedDaystoClose.FASetText(estimatedDays + FAKeys.Tab);
                string EDC = FastDriver.NewFileEntry.DetailsEstimatedDaystoClose.FAGetValue();
                //string detailsEstimatedSettleDate = FastDriver.NewFileEntry.DetailsEstimatedSettleDate.FAGetText();
                string DT = FastDriver.NewFileEntry.DetailsEstimatedSettleDate.FAGetValue();
                FastDriver.NewFileEntry.DetailsDateOfContract.FASetText("02-11-2014");
                string DOC = FastDriver.NewFileEntry.DetailsDateOfContract.FAGetValue();
                FastDriver.NewFileEntry.DetailsDateofContractAccept.FASetText("05-11-2014");
                string DOA = FastDriver.NewFileEntry.DetailsDateofContractAccept.FAGetValue();

                //
                Reports.TestStep = "Store the data in Terms and Property Section.";
                string PS1 = FastDriver.NewFileEntry.DetailsPropertyStreet1.FAGetValue();
                string PS2 = FastDriver.NewFileEntry.DetailsPropertyStreet2.FAGetValue();
                string PS3 = FastDriver.NewFileEntry.DetailsPropertyStreet3.FAGetValue();
                string PS4 = FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue();
                string City = FastDriver.NewFileEntry.DetailsPropertyCity.FAGetValue();
                string State = FastDriver.NewFileEntry.DetailsPropertyState.FAGetSelectedItem();
                string Zip = FastDriver.NewFileEntry.DetailsPropertyZIP.FAGetValue();
                string County = FastDriver.NewFileEntry.DetailsPropertyCounty.FAGetSelectedItem();
                string SP = FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue();
                string Liab = FastDriver.NewFileEntry.DetailsLiability.FAGetValue();
                string FNewLoan = FastDriver.NewFileEntry.DetailsFirstNewLoan.FAGetValue();
                string FNewLoanLiab = FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.FAGetValue();
                string SNewLoan = FastDriver.NewFileEntry.DetailsSecondNewLoan.FAGetValue();
                string SNewLoanLiab = FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.FAGetValue();
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Navigate to Property Info tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.PropertyInfoPropertyInfo.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(5000);

                //
                Reports.TestStep = "Enter data for PartiesPropertyInfo Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyType);
                FastDriver.NewFileEntry.PropertyInfoPropertyType.FASelectItem("Single Family Residence");
                FastDriver.NewFileEntry.PropertyInfoLot.FASetText("Lot1");
                FastDriver.NewFileEntry.PropertyInfoBlock.FASetText("Block1");
                FastDriver.NewFileEntry.PropertyInfoUnit.FASetText("Unit1");
                FastDriver.NewFileEntry.PropertyInfoTrack.FASetText("Tract1");
                FastDriver.NewFileEntry.PropertyInfoFee.FASetText("Fee1");
                FastDriver.NewFileEntry.PropertyInfoBuilding.FASetText("Building1");
                FastDriver.NewFileEntry.PropertyInfoBook.FASetText("Book1");
                FastDriver.NewFileEntry.PropertyInfoPage.FASetText("Page1");
                FastDriver.NewFileEntry.PropertyInfoSection.FASetText("Section1");

                //
                Reports.TestStep = "Store data for PartiesPropertyInfo Tab.";
                string PropertyLot = FastDriver.NewFileEntry.PropertyInfoLot.FAGetValue();
                string PropertyBlock = FastDriver.NewFileEntry.PropertyInfoBlock.FAGetValue();
                string PropertyUnit = FastDriver.NewFileEntry.PropertyInfoUnit.FAGetValue();
                string PropertyTract = FastDriver.NewFileEntry.PropertyInfoTrack.FAGetValue();
                string PropertyFee = FastDriver.NewFileEntry.PropertyInfoFee.FAGetValue();
                string PropertyBuilding = FastDriver.NewFileEntry.PropertyInfoBuilding.FAGetValue();
                string PropertyBook = FastDriver.NewFileEntry.PropertyInfoBook.FAGetValue();
                string PropertyPage = FastDriver.NewFileEntry.PropertyInfoPage.FAGetValue();
                string PropertySection = FastDriver.NewFileEntry.PropertyInfoSection.FAGetValue();

                //
                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();
                Playback.Wait(5000);

                //
                Reports.TestStep = "Enter first new lender.";
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode.FASetText("HUDLEASE01");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Highlight the Available row.";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);

                //
                Reports.TestStep = "Enter second new lender.";
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode.FASetText("HUDLEASE02");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Validate first lender is added.";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Lease 1 for HUD Testing Name 1", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate second lender is added.";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Lease 2 for HUD Testing Name 1", 2, TableAction.Click);

                //
                Reports.TestStep = "Enter first new MB.";
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode.FASetText("HUDNWMGBR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Highlight the Available row.";
                FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);

                //
                Reports.TestStep = "Enter second MB.";
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode.FASetText("HUDNWMGBR2");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Validate first MB is added.";
                FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "New Loan Mrtg. Broker 1 HUD Test Name 1", 2, TableAction.Click);

                Reports.TestStep = "Validate second MB is added.";
                FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "New Loan Mrtg. Broker 2 HUD Test Name 1", 1, TableAction.Click);

                //
                Reports.TestStep = "Click on AddNew in Payoff section.";
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderAddNew.FAClick();
                Playback.Wait(5000);

                //
                Reports.TestStep = "Enter first Payoff lender.";
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderGABcode.FASetText("HUDPAYOFF1");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderFind.FAClick();
                Playback.Wait(5000);

                //
                Reports.TestStep = "Click on AddNew in Payoff section.";
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderAddNew.FAClick();
                Playback.Wait(5000);

                //
                Reports.TestStep = "Enter second Payoff lender.";
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderGABcode.FASetText("HUDPAYOFF2");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderFind.FAClick();
                Playback.Wait(5000);

                //
                Reports.TestStep = "Validate first Payoff lender is added.";
                FastDriver.NewFileEntry.PayOffSummaryTable.PerformTableAction(2, "Payoff Lender 1 for HUD Testing Name 1", 1, TableAction.Click);

                //
                Reports.TestStep = "Validate second Payoff lender is added.";
                FastDriver.NewFileEntry.PayOffSummaryTable.PerformTableAction(2, "Payoff Lender 2 for HUD Testing Name 1", 1, TableAction.Click);
                FastDriver.BottomFrame.Save();
                Playback.Wait(3500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                #region REG0025

                //"BR_FM10187_001_FM10188_001_FM10190_001_FM10189_001: Terms and Dates(Validate).";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(SP, FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue(), "SP");
                Support.AreEqual(Liab, FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue(), "Liab");
                Support.AreEqual(FNewLoan, FastDriver.TermsDatesStatus.FirstNewLoan.FAGetValue(), "FNewLoan");
                Support.AreEqual(FNewLoanLiab, FastDriver.TermsDatesStatus.FirstNewLoanLiability.FAGetValue(), "FNewLoanLiab");
                Support.AreEqual(SNewLoan, FastDriver.TermsDatesStatus.SecondNewLoan.FAGetValue(), "SNewLoan");
                Support.AreEqual(SNewLoanLiab, FastDriver.TermsDatesStatus.SecondNewLoanLiability.FAGetValue(), "SNewLoanLiab");
                Support.AreEqual(EDC, FastDriver.TermsDatesStatus.EstimattedDaysToClose.FAGetValue(), "EDC");
                Support.AreEqual(DT, FastDriver.TermsDatesStatus.EstimattedSettlementDate.FAGetValue(), "DT");
                Support.AreEqual(DOC, FastDriver.TermsDatesStatus.DateofContract.FAGetValue(), "DOC");
                Support.AreEqual(DOA, FastDriver.TermsDatesStatus.DateofContractAcceptance.FAGetValue(), "DOA");

                //
                Reports.TestStep = "Validate the property and legal description from NFE.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual(PS1, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue());
                Support.AreEqual(PS2, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue());
                Support.AreEqual(PS3, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue());
                Support.AreEqual(PS4, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FAGetValue());
                Support.AreEqual(City, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue());
                Support.AreEqual(State, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem());
                Support.AreEqual(Zip, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FAGetValue());
                Support.AreEqual(County, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue());

                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegal.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                Support.AreEqual(PropertyLot, FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue(), "PropertyLot");
                Support.AreEqual(PropertyBlock, FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue(), "PropertyBlock");
                Support.AreEqual(PropertyUnit, FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue(), "PropertyUnit");
                Support.AreEqual(PropertyTract, FastDriver.PropertyTaxInfoLegalDesciption.Tract.FAGetValue(), "PropertyTract");
                Support.AreEqual(PropertyFee, FastDriver.PropertyTaxInfoLegalDesciption.Fee.FAGetValue(), "PropertyFee");
                Support.AreEqual(PropertyBuilding, FastDriver.PropertyTaxInfoLegalDesciption.Building.FAGetValue(), "PropertyBuilding");
                Support.AreEqual(PropertyBook, FastDriver.PropertyTaxInfoLegalDesciption.Book.FAGetValue(), "PropertyBook");
                Support.AreEqual(PropertySection, FastDriver.PropertyTaxInfoLegalDesciption.Section.FAGetValue(), "PropertySection");

                //
                Reports.TestStep = "Validate the first New Loan instance from NFE.";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, "Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                Playback.Wait(4500);

                //
                Reports.TestStep = "Validate the liability amount for first instance.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual(FNewLoan, FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue(), "FNewLoan");
                Support.AreEqual(FNewLoanLiab, FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue(), "FNewLoanLiab");

                //
                Reports.TestStep = "Validate the second New Loan instance from NFE.";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();

                //
                Reports.TestStep = "Validate the liability amount for second instance.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual(SNewLoan, FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue(), "SNewLoan");
                Support.AreEqual(SNewLoanLiab, FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue(), "SNewLoanLiab");

                //
                Reports.TestStep = "Validate PayOff instances from NFE";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction(2, "Payoff Lender 1 for HUD Testing Name 1", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate PayOff instances from NFE";
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction(2, "Payoff Lender 2 for HUD Testing Name 1", 2, TableAction.Click);

                #endregion REG0025
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0026()
        {
            try
            {
                Reports.TestDescription = "FM10191_FM10195_FD_SPInstructions: Special Instructions.";
                this.Login();
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                this.NewFileDetailsCheckBoxesCheck();
                this.EnterStandardNewFileData(false, false);

                //
                Reports.TestStep = "Navigate to Special Instructions Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect);

                FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect.FASetCheckbox(true);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FASetText(@"SpecialInstruction Notes Data including - * # Specialcharacter :) ! ");
                string FLNotes = FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FAGetValue();

                //
                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Validate note created from NFE.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.Table.PerformTableAction("Note", @"SpecialInstruction Notes Data including - * # Specialcharacter :) ! ", "Note", TableAction.Click);
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0027()
        {
            try
            {
                Reports.TestDescription = "FM10192_FM10194: Standard list of Special Instructions.";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                //FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                Playback.Wait(4000);

                //
                Reports.TestStep = "Validate special instruction Presale Transaction (Listing Pre) - Do not send letters.";
                FastDriver.LeftNavigation.Navigate<SpecialInstructionsSetup>("Home>System Maintenance>Special Instructions Setup[0]>Special Instructions Setup[1]").WaitForScreenToLoad();
                //Playback.Wait(40000000);
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction("Name", "Presale Transaction (Listing Pre) – Do not send letters", "Name", TableAction.Click);

                //
                Reports.TestStep = "Validate special instruction Lot Reservation - Do not send letters or assign production.";
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Lot Reservation - Do not send letters or assign production", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate special instruction Starter information.";
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Starter information", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate special instruction Multiple APN's.";
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Multiple APN's", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate special instruction Express/JLP Policy Requested.";
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Express/JLP Policy Requested", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate special instruction No opening packages.";
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "No opening packages", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate special instruction Notes to EPIC.";
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Notes to EPIC", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate special instruction Escrow Notes.";
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Escrow Notes", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate special instruction Title Notes.";
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Title Notes", 2, TableAction.Click);
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0028()
        {
            try
            {
                Reports.TestDescription = "FM10196_001: Distribution and Delivery(ADM Setup).";
                this.Login(true);

                //
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                //FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                Playback.Wait(400);

                //
                Reports.TestStep = "Search for a gab code(Pre-condition).";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText("HUDFLINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                Playback.Wait(3000);
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "HUDFLINSR1", 7, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                FastDriver.LeftNavigation.Navigate<OpenOrderDocumentCopies>("Home>System Maintenance>Address Book>Flood Insurance 1 for HUD Testing Name 1>Open Order Document Copies>Flood Insurance 1 for HUD Testing Name 1>DUMMY").WaitForScreenToLoad();
                FastDriver.OpenOrderDocumentCopies.DocumentNameTable.PerformTableAction(1, "Opening Package", 1, TableAction.Click);

                //
                Reports.TestStep = "Click on Edit button and set to blank.";
                FastDriver.OpenOrderDocumentCopies.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.OpenOrderDocumentCopies.WaitForScreenToLoad();
                FastDriver.OpenOrderDocumentCopies.DefaultCopies.FASetText("");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0029_30()
        {
            try
            {
                Reports.TestDescription = "FM10196: Distribution and Delivery." + "FM10197_FM10198_FM10199_FM10200_FM10201_FM10202_FD_DDInsructions: Role types.";
                this.Login();
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                this.NewFileDetailsCheckBoxesCheck();
                this.EnterStandardNewFileData(false, false, save: false);

                //
                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                //
                Reports.TestStep = "Enter data for Parties Tab with additional Role.";
                FastDriver.NewFileEntry.PartiesDirectedByGABcode.FASetText("HUDASLNDR1");
                FastDriver.NewFileEntry.PartiesDirectedByFind.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASelectItem("Seller's Broker");
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASendKeys(FAKeys.Tab);
                FastDriver.NewFileEntry.PartiesDirectedByPercent.FASetText("20.0000");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyGABcode.FASetText("HUDASLNDR2");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyFind.FAClick();
                Playback.Wait(3000);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddtionalRole.FASelectItem("Buyer's Broker");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddtionalRole.FASendKeys(FAKeys.Tab);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyPercent.FASetText("20.0000" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);

                //
                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnLenderMortgageBrokerTab();

                //
                Reports.TestStep = "Enter first new lender.";
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode.FASetText("HUDLEASE01");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();

                //
                Reports.TestStep = "Highlight the Available row.";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);

                //
                Reports.TestStep = "Enter second new lender.";
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode.FASetText("HUDLEASE02");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();

                //
                Reports.TestStep = "Validate first lender is added.";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Lease 1 for HUD Testing Name 1", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate second lender is added.";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Lease 2 for HUD Testing Name 1", 2, TableAction.Click);

                //
                Reports.TestStep = "Enter first new MB.";
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode.FASetText("HUDNWMGBR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();

                //
                Reports.TestStep = "Highlight the Available row.";
                FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);

                //
                Reports.TestStep = "Enter second MB.";
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode.FASetText("HUDNWMGBR2");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();

                //
                Reports.TestStep = "Validate first MB is added.";
                FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "New Loan Mrtg. Broker 1 HUD Test Name 1", 2, TableAction.Click);

                //
                Reports.TestStep = "Validate second MB is added.";
                FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "New Loan Mrtg. Broker 2 HUD Test Name 1", 2, TableAction.Click);

                //
                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                //
                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();

                #region REG0030

                Reports.TestStep = "Validate the Bus Parties.";
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.DirectedBy.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Buyer.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Seller.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.NewLender.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.MortgageBroker.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.AssociatedBusinessParty.FAClick();

                //
                Reports.TestStep = "Validate the Bus Parties and the standard delivery methods.";
                // FastDriver.ViewDeliveryInstrucionsDlg.ou
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FAGetValue());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.OpeningPackage6.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.PrelimReport6.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.CCRs6.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.PlottedEasement6.Exists().ToString());
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.Exceptions6.Exists().ToString());

                //
                Reports.TestStep = "Select number of copies and delivery method.";
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FASetText("9");
                FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport.FASetText("9");
                FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs.FASetText("9");
                FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement.FASetText("9");
                FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FASetText("9");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage.FASelectItem("Branch");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPrelimReport.FASelectItem("c/o Buyer Broker");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectCopies0cboCCRs.FASelectItem("Courier");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPlottedEasement.FASelectItem("Email");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectExceptions.FASelectItem("Overnight");
                Keyboard.SendKeys("{TAB}");
                FastDriver.DialogBottomFrame.ClickSave();
                Playback.Wait(5000);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(4500);

                //
                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();

                //
                Reports.TestStep = "Validate the date entered.";
                Support.AreEqual("9", FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FAGetValue());
                Support.AreEqual("9", FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport.FAGetValue());
                Support.AreEqual("9", FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs.FAGetValue());
                Support.AreEqual("9", FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement.FAGetValue());
                Support.AreEqual("9", FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FAGetValue());
                Support.AreEqual("Branch", FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage.FAGetSelectedItem());
                Support.AreEqual("c/o Buyer Broker", FastDriver.ViewDeliveryInstrucionsDlg.SelectPrelimReport.FAGetSelectedItem());
                Support.AreEqual("Courier", FastDriver.ViewDeliveryInstrucionsDlg.SelectCopies0cboCCRs.FAGetSelectedItem());
                Support.AreEqual("Email", FastDriver.ViewDeliveryInstrucionsDlg.SelectPlottedEasement.FAGetSelectedItem());
                Support.AreEqual("Overnight", FastDriver.ViewDeliveryInstrucionsDlg.SelectExceptions.FAGetSelectedItem());

                //
                Reports.TestStep = "Edit number of copies and delivery method.";
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                string id = AutoConfig.UserName;
                int index = id.IndexOf(@"\");
                int length = id.Length - index - 1;
                id = id.ToLower().Substring(index + 1, length).Trim();
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.FirstRolePane.FAGetText().Contains(id).ToString());

                Playback.Wait(400);
                string editDate = DateTime.Now.ToDateString().Replace("-", "/");
                Support.AreEqual("True", FastDriver.ViewDeliveryInstrucionsDlg.EditDate.FAGetText().Contains(editDate).ToString());

                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FASetText("2");
                FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport.FASetText("2");
                FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs.FASetText("2");
                FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement.FASetText("2");
                FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FASetText("2");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage.FASelectItem("Branch");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPrelimReport.FASelectItem("c/o Seller Broker Deliver");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectCopies0cboCCRs.FASelectItem("Fax");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectPlottedEasement.FASelectItem("Other");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectExceptions.FASelectItem("Branch");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();

                //
                Reports.TestStep = "Validate the Edited number of copies and delivery method.";
                Support.AreEqual("2", FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FAGetValue());
                Support.AreEqual("2", FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport.FAGetValue());
                Support.AreEqual("2", FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs.FAGetValue());
                Support.AreEqual("2", FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement.FAGetValue());
                Support.AreEqual("2", FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FAGetValue());
                Support.AreEqual("Branch", FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage.FAGetSelectedItem());
                Support.AreEqual("c/o Seller Broker Deliver", FastDriver.ViewDeliveryInstrucionsDlg.SelectPrelimReport.FAGetSelectedItem());
                Support.AreEqual("Fax", FastDriver.ViewDeliveryInstrucionsDlg.SelectCopies0cboCCRs.FAGetSelectedItem());
                Support.AreEqual("Other", FastDriver.ViewDeliveryInstrucionsDlg.SelectPlottedEasement.FAGetSelectedItem());
                Support.AreEqual("Branch", FastDriver.ViewDeliveryInstrucionsDlg.SelectExceptions.FAGetSelectedItem());

                #endregion REG0030
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0031_32()
        {
            try
            {
                Reports.TestDescription = "FM10209: Remove Delivery method on change/removal of FBP." + "001: Open the file.";
                this.Login();
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                this.NewFileDetailsCheckBoxesCheck();
                this.EnterStandardNewFileData(false, false);
                //
                Reports.TestStep = "Change BusOrg.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.FASetText("247");
                FastDriver.NewFileEntry.DetailsFind.FAClick();
                Playback.Wait(4500);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();

                //
                Reports.TestStep = "Validate after editing the BusOrg.";
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FASetText("");
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.Doces0PrelimReport.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.DocmentCopies0CCRs.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.DocPlottedEasement.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FAGetValue());
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.Docpies0Exceptions.FAGetValue());
                FastDriver.DialogBottomFrame.ClickCancel();

                #region REG0032

                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                #endregion REG0032
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0032()
        {
            try
            {
                //This was merged with REG0031
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0033_34()
        {
            try
            {
                Reports.TestDescription = "Enter details for New File Entry";
                this.Login();
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(saveFile: false, ownerPolicy: "ALTA Extended Owner Policy", busGAB: "HUDFLINSR1", addRole: "Other Real Estate Agent", buyer: false, seller: false, city: "", zipCode: "", county: "");

                //
                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                //
                Reports.TestStep = "Enter data for Parties Tab with additional Role(Buyers' and Sellers real estate Agent).";
                FastDriver.NewFileEntry.FindDirectedByGAB("HUDASLNDR1");
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASelectItem("Seller's Real Estate Agent");
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.SendKeys(FAKeys.Tab);
                FastDriver.NewFileEntry.FindAssociatedBusinessPartyGAB("HUDASLNDR2");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddtionalRole.FASelectItem("Buyer's Real Estate Agent");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddtionalRole.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();

                //
                Reports.TestStep = "Validate Real Estate Agents.";
                FastDriver.ViewDeliveryInstrucionsDlg.SummaryTable.PerformTableAction("Role", "Buyers Real Estate Agent", "Role", TableAction.Click);
                FastDriver.ViewDeliveryInstrucionsDlg.SummaryTable.PerformTableAction("Role", "Sellers Real Estate Agent", "Role", TableAction.Click);
                FastDriver.ViewDeliveryInstrucionsDlg.SummaryTable.PerformTableAction("Role", "Other Real Estate Agent", "Role", TableAction.Click);

                //
                Reports.TestStep = "Validate Business role has no instructions and select new lender for role.";
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FASetText("");
                Support.AreEqual("", FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FAGetValue());
                FastDriver.ViewDeliveryInstrucionsDlg.Role7.FASelectItem("Outside Escrow Company");
                FastDriver.ViewDeliveryInstrucionsDlg.Role7.FASendKeys(FAKeys.Tab);
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage7.FASetText("7");
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage7.FASendKeys(FAKeys.Tab);
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage4.FASelectItem("Overnight");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage4.FASendKeys(FAKeys.Tab);
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage3.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage3.FASendKeys(FAKeys.Backspace);
                FastDriver.DialogBottomFrame.ClickDone();

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type Hus/Wife.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText("Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText("Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText("Buyer2SpouseName");

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type Trust/Estate.";
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Trust/Estate");
                FastDriver.NewFileEntry.TrustBuyer.FASetText("TstBuyer");

                //
                Reports.TestStep = "Click on Save - double wait";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type Bus Entity.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Business Entity");
                FastDriver.NewFileEntry.TrustBuyer.FASetText("BEBuyer");

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type individual.";
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.IndBuyerF.FASetText("IndBuyerF" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndBuyerM.FASetText("IndBuyerM" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndBuyerL.FASetText("IndBuyerL" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Save - double wait";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type individual once more.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.IndBuyerF.FASetText("Ind1BuyerF" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndBuyerM.FASetText("Ind1BuyerM" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndBuyerL.FASetText("Ind1BuyerL" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter Seller of type Hus/Wife.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText("Seller2Firstname" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText("Seller2Lastname" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText("Seller2SpouseName" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsSellerSpouseLast.FASetText("Seller2SpouseLastName" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Save - double wait";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter buyer of type Trust/Estate.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Trust/Estate");
                //changed
                FastDriver.NewFileEntry.TrustSeller.FASetText("TstSeller");
                FastDriver.NewFileEntry.TrustSellerSSNTIN.FASetText(@"1523215202");
                FastDriver.NewFileEntry.TrustLastNameFor1099_S.FASetText(@"TrustEstateSellerLastName");

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter Seller of type Bus Entity.";
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Business Entity");
                FastDriver.NewFileEntry.TrustSeller.FASetText("BESeller");
                FastDriver.NewFileEntry.TrustSellerSSNTIN.FASetText("1523215202");

                //
                Reports.TestStep = "Click on Save - double wait";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter buyer of type individual.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.IndSellerF.FASetText("IndSellerF" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndSellerM.FASetText("IndSellerM" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndSellerL.FASetText("IndSellerL" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter Seller of type individual once more.";
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.IndSellerF.FASetText("Ind1SellerF" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndSellerM.FASetText("Ind1SellerM" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndSellerL.FASetText("Ind1SellerL" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Save - double wait";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //FastDriver.TopFrame.SearchFileByFileNumber("71796");//////////////////
                //FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();//////////////////////

                //
                Reports.TestStep = "Validate the buyer1.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual("Individual", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Ind1BuyerF Ind1BuyerM Ind1BuyerL", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the buyer2.";
                Support.AreEqual("Trust/Estate", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "TstBuyer", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the buyer3.";
                Support.AreEqual("Business Entity", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "BEBuyer", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the buyer4.";
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the buyer5.";
                Support.AreEqual("Individual", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "IndBuyerF IndBuyerM IndBuyerL", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller1.";
                Support.AreEqual("Individual", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "IndSellerF IndSellerM IndSellerL", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller2.";
                Support.AreEqual("Trust/Estate", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "TstSeller", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller3.";
                Support.AreEqual("Business Entity", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "BESeller", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller4.";
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Seller2Firstname  Seller2Lastname /Seller2SpouseName  Seller2SpouseLastNam", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller5.";
                Support.AreEqual("Individual", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Ind1SellerF Ind1SellerM Ind1SellerL", "Type", TableAction.GetText).Message.Clean());

                #region REG0034

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type Hus/Wife.";
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Type", "Husband/Wife", "Type", TableAction.Click);
                Playback.Wait(4500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText("Buyer2Firstname" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText("Buyer2Lastname" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText("Buyer2SpouseName" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type Trust/Estate.";
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "TstBuyer", "Type", TableAction.Click);
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Trust/Estate");
                FastDriver.NewFileEntry.TrustBuyer.FASetText("TstBuyer" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type Bus Entity.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "BEBuyer", "Type", TableAction.Click);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Business Entity");
                FastDriver.NewFileEntry.TrustBuyer.FASetText("BEBuyer" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type individual.";
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "IndBuyerF IndBuyerM IndBuyerL", "Type", TableAction.Click);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.IndBuyerF.FASetText("IndBuyerF" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndBuyerM.FASetText("IndBuyerM" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndBuyerL.FASetText("IndBuyerL" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Buyer and enter buyer of type individual once more.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Ind1BuyerF Ind1BuyerM Ind1BuyerL", "Type", TableAction.Click);
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.IndBuyerF.FASetText("Ind1BuyerF" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndBuyerM.FASetText("Ind1BuyerM" + FAKeys.Tab);
                FastDriver.NewFileEntry.IndBuyerL.FASetText("Ind1BuyerL" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter Seller of type Hus/Wife.";
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Seller2Firstname  Seller2Lastname /Seller2SpouseName  Seller2SpouseLastNam", "Type", TableAction.Click);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText("Seller2Firstname" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText("Seller2Lastname" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText("Seller2SpouseName" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter buyer of type Trust/Estate.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "TstSeller", "Type", TableAction.Click);
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Trust/Estate");
                Keyboard.SendKeys("{TAB}");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.TrustSeller.FASetText("TstSeller" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter Seller of type Bus Entity.";
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "BESeller", "Type", TableAction.Click);
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Business Entity");
                FastDriver.NewFileEntry.TrustSeller.FASetText("BESeller" + FAKeys.Tab);

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter buyer of type individual.";
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "IndSellerF IndSellerM IndSellerL", "Type", TableAction.Click);
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.IndSellerF.FASetText("IndSellerF");
                FastDriver.NewFileEntry.IndSellerM.FASetText("IndSellerM");
                FastDriver.NewFileEntry.IndSellerL.FASetText("IndSellerL");

                //
                Reports.TestStep = "Click on Add/Remove in Seller and enter Seller of type individual once more.";
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Ind1SellerF Ind1SellerM Ind1SellerL", "Type", TableAction.Click);
                Playback.Wait(2500);
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.IndSellerF.FASetText("Ind1SellerF");
                FastDriver.NewFileEntry.IndSellerM.FASetText("Ind1SellerM");
                FastDriver.NewFileEntry.IndSellerL.FASetText("Ind1SellerL");

                //
                Reports.TestStep = "Click on Save - double wait";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Validate the buyer1.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual("Individual", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Ind1BuyerF Ind1BuyerM Ind1BuyerL", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the buyer2.";
                Support.AreEqual("Trust/Estate", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "TstBuyer", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the buyer3.";
                Support.AreEqual("Business Entity", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "BEBuyer", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the buyer4.";
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the buyer5.";
                Support.AreEqual("Individual", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "IndBuyerF IndBuyerM IndBuyerL", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller1.";
                Support.AreEqual("Individual", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "IndSellerF IndSellerM IndSellerL", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller2.";
                Support.AreEqual("Trust/Estate", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "TstSeller", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller3.";
                Support.AreEqual("Business Entity", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "BESeller", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller4.";
                Support.AreEqual("Husband/Wife", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Seller2Firstname  Seller2Lastname /Seller2SpouseName  Seller2Lastname", "Type", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the seller5.";
                Support.AreEqual("Individual", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Ind1SellerF Ind1SellerM Ind1SellerL", "Type", TableAction.GetText).Message.Clean());

                #endregion REG0034
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0035_36()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10207_01: Precedence of Delivery and Distribution instructions (ADM)";

                Reports.TestStep = "Log into FAST ADM application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for a gab code(Pre-condition).";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText(@"HUDFLINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "HUDFLINSR1", 7, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Select Default Open order document copie";
                FastDriver.LeftNavigation.Navigate<OpenOrderDocumentCopies>(@"Home>System Maintenance>Address Book>Flood Insurance 1 for HUD Testing Name 1>Open Order Document Copies").WaitForScreenToLoad();
                FastDriver.OpenOrderDocumentCopies.DocumentNameTable.PerformTableAction(1, "Opening Package", 1, TableAction.Click);

                Reports.TestStep = "Click on Edit button and set to 4 copies";
                FastDriver.OpenOrderDocumentCopies.Edit.FAClick();
                FastDriver.OpenOrderDocumentCopies.DefaultCopies.FASetText(@"4");
                FastDriver.BottomFrame.Done();

                #region FMUC0107_REG0036

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to NFE-Lender/MortgageBroker Tab";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.FAClick();
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                if (FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("No Product Issued"))
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                }
                else if (FastDriver.NewFileEntry.OthersTable.Text.Contains("No Product Issued"))
                {
                    FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                }
                else
                {
                    FailTest("'No Product Issued' element not found within Owner Policy/Others table.");
                }
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderAddNew.FAClick();
                FastDriver.NewFileEntry.FindLenderMortgageBrokerGAB(@"HUDFLINSR1");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();

                Reports.TestStep = "Validate New Lender role instruction is replaced by ADM set up value";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.NewLender.FAClick();
                string[] temp = FastDriver.ViewDeliveryInstrucionsDlg.NewLender.FAGetAttribute("id").Split('_');
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, "DI_dgridDocumentCopies_" + temp[2] + "_cboOpeningPackage").FASelectItem(@"Overnight");
                FastDriver.DialogBottomFrame.ClickDone();

                #endregion FMUC0107_REG0036

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0037()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10203: Default delivery instructions from GAB";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Enter data for a Pending file-Details Tab";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false, addRole: "");

                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();

                Reports.TestStep = "Validate the instruction from GAB for Bus Org";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                Support.AreEqual(@"4", FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FAGetValue().Clean());
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage.FASelectItem(@"Branch");
                FastDriver.DialogBottomFrame.ClickDone();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0038_39()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10203_001: Set delivery instructions from GAB(set to blank)";

                Reports.TestStep = "Log into FAST ADM application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();

                Reports.TestStep = "Navigate to Region level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for a gab code(Pre-condition).";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText(@"HUDFLINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "HUDFLINSR1", 7, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Select Default Open order document copie";
                FastDriver.LeftNavigation.Navigate<OpenOrderDocumentCopies>(@"Home>System Maintenance>Address Book>Flood Insurance 1 for HUD Testing Name 1>Open Order Document Copies").WaitForScreenToLoad();
                FastDriver.OpenOrderDocumentCopies.DocumentNameTable.PerformTableAction(1, "Opening Package", 1, TableAction.Click);

                Reports.TestStep = "Click on Edit button and set to blank.";
                FastDriver.OpenOrderDocumentCopies.Edit.FAClick();
                FastDriver.OpenOrderDocumentCopies.DefaultCopies.FASetText(@"");
                FastDriver.BottomFrame.Done();

                #region FMUC0107_REG0039

                Reports.TestStep = "FMUC0107_REG0039 Test Description: FM10212_01: Do not initiate FAST Search and Automated Payoff request.";
                Reports.StatusUpdate("FM10212_01: Do not initiate FAST Search and Automated Payoff request", true);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to NFE-Lender/MortgageBroker Tab";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Negverifieng for the[Fast Search Initiated]Event in 1st row.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Reports.StatusUpdate("Verify whether [Fast Search Initiated] process is present in the Event Table.", !FastDriver.EventTrackingLog.EventTable.Text.Contains("[Fast Search Initiated]"));

                #endregion FMUC0107_REG0039

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0040()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10216: Nav Tree Display when the status of file is Pending.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File via 'NewFileEntry'.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", searchType: "", addRole: "", buyer: false, seller: false, city: "", zipCode: "", county: "");

                Reports.TestStep = "To verify the links existing for a Pending file";
                FastDriver.LeftNavigation.Navigate<FileSiteLeftNavigationPane>(@"Home>Order Entry").SwitchToLeftNavigationPane();
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.MFT.Exists().ToString(), "Verify whether 'My Fast Today' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.FileSearch.Exists().ToString(), "Verify whether 'File Search' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.ReserveFileNum.Exists().ToString(), "Verify whether 'Reserve File Num' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.NewFileEntry.Exists().ToString(), "Verify whether 'New File Entry' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.QuickFileEntry.Exists().ToString(), "Verify whether 'Quick File Entry' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.QuickRefiEntry.Exists().ToString(), "Verify whether 'Quick Refi Entry' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.FileWorkflow.Exists().ToString(), "Verify whether 'File Workflow' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.EscrowClosing.Exists().ToString(), "Verify whether 'Escrow Closing' link does exist.");

                Reports.TestStep = "To verify Deposits exists for a Pending file";
                FastDriver.LeftNavigation.Navigate<FileSiteLeftNavigationPane>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToLeftNavigationPane();
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.Deposits.Exists().ToString(), "Verify whether 'Deposits' link does exist.");

                Reports.TestStep = "To verify Deposit Sublinks exists for a Pending file";
                FastDriver.LeftNavigation.Navigate<FileSiteLeftNavigationPane>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToLeftNavigationPane();
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.DepositinEscrow.Exists().ToString(), "Verify whether 'Deposit In Escrow' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.DepositHistory.Exists().ToString(), "Verify whether 'Deposit/Receipt History' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.DepositOutsideEscrow.Exists().ToString(), "Verify whether 'Deposit Outside Escrow' link does exist.");

                Reports.TestStep = "To verify EventLog and FileNotes  exists for a Pending file";
                FastDriver.LeftNavigation.Navigate<FileSiteLeftNavigationPane>(@"Home>Order Entry").SwitchToLeftNavigationPane();
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.FileNotes.Exists().ToString(), "Verify whether 'File Notes' link does exist.");
                Support.AreEqual(@"True", FastDriver.FileSiteLeftNavigationPane.EventLog.Exists().ToString(), "Verify whether 'Event/Tracking Log' link does exist.");

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0041()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10219: Disable service type selected and additional role after save";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an Order.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false, city: "", zipCode: "", county: "");

                Reports.TestStep = "Navigate to New File Entry - NFE0138";
                FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Validate the service type and additional role is disabled.";
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsTitlecheckbox.Enabled.ToString(), "Verify whether the 'DetailsTitlecheckbox' checkbox is Disabled.");
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Enabled.ToString(), "Verify whether the 'DetailsEscrowcheckbox' checkbox is Disabled.");
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsAddtionalRole.Enabled.ToString(), "Verify whether the 'DetailsAddtionalRole' dropdown is Disabled.");

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0042()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10223_FM10224: Pending Icon";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an Order.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false, city: "", zipCode: "", county: "");

                Reports.TestStep = "Validate is Pending File icon";
                FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.Title.VerifyIfImgExist("PendingFile.JPG").ToString(), "Verify whether the Pending img does exist.");

                Reports.TestStep = "Verify the EventLog for Pending file created";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    return FastDriver.EventTrackingLog.EventTable.Text.Contains("Pending");
                }, timeout: 60, idleInterval: 5);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Pending]", "Event", TableAction.Click);

                Reports.TestStep = "Verifying for user name";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("User", credentials.UserName.ToUpper(), "User", TableAction.Click);

                Reports.TestStep = "Verify the Event Log for File created(Source)";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "FAST Application", "Source", TableAction.Click);

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0043()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10218_01_FD_Signature: Buyer/Seller Signature";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an Order.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false, city: "", zipCode: "", county: "");

                Reports.TestStep = "Navigate to New File Entry - NFE0138";
                FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Validate the Signature button is disabled and enter data for Buyer and Seller";
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsSignatures.Enabled.ToString(), "Verify whether 'DetailsSignatures' element is Disabled.");
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem(@"Business Entity");
                FastDriver.NewFileEntry.TrustBuyer.FASetText(@"BEBuyer" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsSignaturesseller.Enabled.ToString(), "Verify whether 'DetailsSignaturesseller' element is Disabled.");
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem(@"Business Entity");
                FastDriver.NewFileEntry.TrustSeller.FASetText(@"BESeller" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate the Signature button is enabled.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.NewFileEntry.DetailsSignatures.Enabled.ToString(), "Verify whether 'DetailsSignatures' element is Enabled.");
                Support.AreEqual(@"True", FastDriver.NewFileEntry.DetailsSignaturesseller.Enabled.ToString(), "Verify whether 'DetailsSignaturesseller' element is Enabled.");

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0044()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10218_02_FD_Signature: Buyer/Seller Signature";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyerType: BuyerSellerType.BusinessEntity, sellerType: BuyerSellerType.BusinessEntity,
                    city: "", zipCode: "", county: "");

                Reports.TestStep = "Click on Buyer Signature button";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsSignatures.FAClick();

                Reports.TestStep = "Enter authorized signature for Business Entity.";
                FastDriver.BuyerSellerEntitySignatures.WaitForScreenToLoad();
                FastDriver.BuyerSellerEntitySignatures.NameofEntity.FASetText(@"Business Entity");
                FastDriver.BuyerSellerEntitySignatures.StateOfIncorp.FASelectItem(@"Alaska");
                FastDriver.BuyerSellerEntitySignatures.Entitytype.FASelectItem(@"Business Trust");
                FastDriver.BuyerSellerEntitySignatures.NewAuthorized.FAClick();
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FASetText(@"Business Authorized Signature");
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FASetText(@"Corp Title");
                FastDriver.BuyerSellerEntitySignatures.NewNameofEntity.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByNameOfEntity.FASetText(@"Entity Name");
                FastDriver.BuyerSellerEntitySignatures.ByStateOfIncorp.FASelectItem(@"Alaska");
                FastDriver.BuyerSellerEntitySignatures.ByEntityType.FASelectItem(@"Business Trust");
                FastDriver.BuyerSellerEntitySignatures.ByContactName.FASetText(@"Contact Name");
                FastDriver.BuyerSellerEntitySignatures.ApplyNameofEntity.FAClick();
                FastDriver.BuyerSellerEntitySignatures.NewAuthorizedSignature.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FASetText(@"Entity Authorized Signature Name");
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FASetText(@"Entity Authorized Signature Title Corp");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);

                Reports.TestStep = "Click on Buyer Signature button";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.DetailsSignatures);
                FastDriver.NewFileEntry.DetailsSignatures.FAClick();

                Reports.TestStep = "Validate the data entered as authorized signature for Business Entity.";
                FastDriver.BuyerSellerEntitySignatures.WaitForScreenToLoad();
                Support.AreEqual(@"Business Entity", FastDriver.BuyerSellerEntitySignatures.NameofEntity.FAGetValue().Clean());
                Support.AreEqual(@"Alaska", FastDriver.BuyerSellerEntitySignatures.StateOfIncorp.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Business Trust", FastDriver.BuyerSellerEntitySignatures.Entitytype.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Business Authorized Signature", FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FAGetValue().Clean());
                Support.AreEqual(@"Corp Title", FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FAGetValue().Clean());
                Support.AreEqual(@"Entity Name", FastDriver.BuyerSellerEntitySignatures.ByNameOfEntity.FAGetValue().Clean());
                Support.AreEqual(@"Alaska", FastDriver.BuyerSellerEntitySignatures.ByStateOfIncorp.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Business Trust", FastDriver.BuyerSellerEntitySignatures.ByEntityType.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Contact Name", FastDriver.BuyerSellerEntitySignatures.ByContactName.FAGetValue().Clean());
                FastDriver.BuyerSellerEntitySignatures.ApplyNameofEntity.FAClick();
                Support.AreEqual(@"Entity Authorized Signature Name", FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FAGetValue().Clean());
                Support.AreEqual(@"Entity Authorized Signature Title Corp", FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);

                Reports.TestStep = "Click on Seller Signature button";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.DetailsSignaturesseller);
                FastDriver.NewFileEntry.DetailsSignaturesseller.FAClick();

                Reports.TestStep = "Enter authorized signature for Business Entity.";
                FastDriver.BuyerSellerEntitySignatures.WaitForScreenToLoad();
                FastDriver.BuyerSellerEntitySignatures.NameofEntity.FASetText(@"Business Entity");
                FastDriver.BuyerSellerEntitySignatures.StateOfIncorp.FASelectItem(@"Alaska");
                FastDriver.BuyerSellerEntitySignatures.Entitytype.FASelectItem(@"Business Trust");
                FastDriver.BuyerSellerEntitySignatures.NewAuthorized.FAClick();
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FASetText(@"Business Authorized Signature");
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FASetText(@"Corp Title");
                FastDriver.BuyerSellerEntitySignatures.NewNameofEntity.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByNameOfEntity.FASetText(@"Entity Name");
                FastDriver.BuyerSellerEntitySignatures.ByStateOfIncorp.FASelectItem(@"Alaska");
                FastDriver.BuyerSellerEntitySignatures.ByEntityType.FASelectItem(@"Business Trust");
                FastDriver.BuyerSellerEntitySignatures.ByContactName.FASetText(@"Contact Name");
                FastDriver.BuyerSellerEntitySignatures.ApplyNameofEntity.FAClick();
                FastDriver.BuyerSellerEntitySignatures.NewAuthorizedSignature.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FASetText(@"Entity Authorized Signature Name");
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FASetText(@"Entity Authorized Signature Title Corp" + FAKeys.Tab);

                Reports.TestStep = "Validate the data entered as authorized signature for Business Entity.";
                Support.AreEqual(@"Business Entity", FastDriver.BuyerSellerEntitySignatures.NameofEntity.FAGetValue().Clean());
                Support.AreEqual(@"Alaska", FastDriver.BuyerSellerEntitySignatures.StateOfIncorp.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Business Trust", FastDriver.BuyerSellerEntitySignatures.Entitytype.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Business Authorized Signature", FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FAGetValue().Clean());
                Support.AreEqual(@"Corp Title", FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FAGetValue().Clean());
                Support.AreEqual(@"Entity Name", FastDriver.BuyerSellerEntitySignatures.ByNameOfEntity.FAGetValue().Clean());
                Support.AreEqual(@"Alaska", FastDriver.BuyerSellerEntitySignatures.ByStateOfIncorp.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Business Trust", FastDriver.BuyerSellerEntitySignatures.ByEntityType.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Contact Name", FastDriver.BuyerSellerEntitySignatures.ByContactName.FAGetValue().Clean());
                FastDriver.BuyerSellerEntitySignatures.ApplyNameofEntity.FAClick();
                Support.AreEqual(@"Entity Authorized Signature Name", FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FAGetValue().Clean());
                Support.AreEqual(@"Entity Authorized Signature Title Corp", FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0045_46()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10221_02_FM10197_02_FD_Bustype: Business Source type(File)";

                Reports.TestStep = "Pre-req for reg0046 and 47";
                Reports.TestStep = "Login in ADM side.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Pre-req Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Pre-req Select the new template to activate it.";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>("Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.New.FAClick();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessType.FASelectItem("Title Production");
                var processName = "AUTO_DONOTTOUCH_File Created With PS " + Support.RandomString("ZNNAZZE");
                FastDriver.RegionalProcessEdit.ProcessName.FASetText(processName);
                FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
                FastDriver.RegionalProcessEdit.Description.FASetText(@"!!!!!!This is QA automation template. DO NOT TOUCH!!!!!");
                FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.SelectTransType("Sale w/Mortgage");
                FastDriver.SelectionCriteriaDlg.SelectBusinessSegment("Residential");
                FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();

                Reports.TestStep = "Pre-req Change states from all to another state";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction(2, "LA", 1, TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();

                Reports.TestStep = "Pre-req Change county from all to another county";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                FastDriver.CountySelectionDlg.Table.PerformTableAction(2, "DE SOTO", 1, TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Pre-req Navigates back to Regional Process Edit";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction("Process Events", "File created with Pending Status", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                Reports.TestStep = "Pre-req Add tasks to the process";
                FastDriver.RegionalProcessEdit.Add.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TaskCategoryTable.PerformTableAction(2, "Title", 2, TableAction.Click);
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                    return FastDriver.TaskTemplateSelectionDlg.TaskTable.Text.Contains("ADEC-ITI-BILL-FULL");
                });
                FastDriver.TaskTemplateSelectionDlg.OverrideTask(3, searchValue: "ADEC-ITI-BILL-FULL", isPublic: true);
                FastDriver.TaskTemplateSelectionDlg.OverrideTask(3, searchValue: "ADEC-ITI-BILL-FULL-SP", isPublic: true, clickOnSelectTask: true);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.Inactive.FASetCheckbox(false);

                Reports.TestStep = "Pre-req Add workgroups to all tasks";
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.Table.PerformTableAction(1, 1, TableAction.SelectItem, "1099");
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, "1099", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, "1099", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Pre-req Activating Task";
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processName, 2, TableAction.Click);
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.WaitForScreenToLoad();
                FastDriver.StatusEdit.Deactivate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                Reports.StatusUpdate("Template refresh successful.", FastDriver.PendingRefreshSummary.RefreshProcessTemplate(processName));
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Enter all the details";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Outside Escrow Company", state: "LA", county: "De Soto", city: "", zipCode: "", saveFile: false);

                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Enter data for Parties Tab with additional Role(Buyers' and Sellers Attorney)";
                FastDriver.NewFileEntry.FindDirectedByGAB(@"HUDASLNDR1");
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASelectItem(@"Seller's Attorney");
                FastDriver.NewFileEntry.FindAssociatedBusinessPartyGAB(@"HUDASLNDR2");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddtionalRole.FASelectItem(@"Buyer's Attorney");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();

                Reports.TestStep = "Validate the Attorney";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.BuyerAttorney.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.SellerAttorney.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.OutsideEscrowCompany.FAClick();
                FastDriver.DialogBottomFrame.ClickCancel();

                #region FMUC0107_REG0046

                Reports.TestStep = "FMUC0107_REG0046 Test Description: FM10226_FM10220: Change Task Office.";
                Reports.StatusUpdate("FM10226_FM10220: Change Task Office", true);

                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Click on AddRemove Escrow Prod office";
                FastDriver.NewFileEntry.PartiesAddRemoveEscrowproductionOffice.FAClick();

                Reports.TestStep = "Select different region.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Region.FASelectItem(@"QA-Canada");
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    return FastDriver.OfficeSelectionDlg.OfficesTable1.Text.Contains("QA-Canada");
                }, timeout: 30, idleInterval: 2);
                FastDriver.OfficeSelectionDlg.Office1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate the workflow for NFE";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                if (!FastDriver.FileWorkflow.ProcessTable.Text.Contains(processName))
                {
                    FastDriver.FileWorkflow.AddProcess.Click();
                    FastDriver.FileWorkflow.AddProcess.FAClick();
                    FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                    FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, "Title Production", 1, TableAction.Click);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                    FastDriver.FileWorkflow.WaitForScreenToLoad();
                }
                var tableID = FastDriver.FileWorkflow.GetWorkFlowTableID(processName);
                if (tableID != null)
                {
                    Reports.StatusUpdate(String.Format("Process {0} was added.", processName), true);
                }
                else
                {
                    Reports.StatusUpdate("Process was not added.", false);
                    FailTest("Process was not added FileWorkflow screen.");
                }

                Reports.TestStep = "Verify the existing owning office in first task";
                Support.AreEqual(@"QA Automation Office -", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(5, "ADEC-ITI-BILL-FULL", 6, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Select the second task";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(5, "ADEC-ITI-BILL-FULL-SP", 7, TableAction.Click);

                Reports.TestStep = "Select the Task Office";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.PerformTableAction("Office", "QA-Canada Test Region", "Office", TableAction.Click);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Verify the production center owning office in second task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(@"QA-Canada Test Region", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(5, "ADEC-ITI-BILL-FULL-SP", 6, TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Click on ChangeO/O button.";
                FastDriver.NewFileEntry.DetailsChangeOObutton.FAClick();

                Reports.TestStep = "Chang Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878 (1487)");
                FastDriver.BottomFrame.Save();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Verify owning office is reassigned to new one.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                Support.AreEqual(@"QA Automation Office -", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(5, "ADEC-ITI-BILL-FULL", 6, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Verify production center owning office is not retained.";
                Support.AreEqual(@"QA-Canada Test Region", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(5, "ADEC-ITI-BILL-FULL-SP", 6, TableAction.GetText).Message.Clean());

                #endregion FMUC0107_REG0046

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0047()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10225_01: Initiate Interface Triggers when file is promoted to Open(FASTSEARCH)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order via New File Entry.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Outside Escrow Company", state: "LA", county: "De Soto", city: "", zipCode: "");

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.FileStatus.FASelectItem(@"Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Verifying for the FAST Search Initiated event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    return FastDriver.EventTrackingLog.EventTable.Text.Contains("Opened");
                });
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Opened]", "Event", TableAction.Click);

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0048()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10225_02: Initiate Interface Triggers when file is promoted to Open(1099S)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order via New File Entry.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Outside Escrow Company", state: "LA", county: "De Soto", city: "", zipCode: "");

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.FileStatus.FASelectItem(@"Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate 1099s Record is created form NFE-1";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                Reports.StatusUpdate("Verify whether 'RecordSummaryTable' has new records.", FastDriver._1099S.RecordSummaryTable.GetRowCount() > 1);

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0049_50()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10227_FM10228_FM10229_FM10230_FM10231_FM10234_Open_FM10182: Ability to select Program Type.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order via New File Entry.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASendKeys(@"++");

                Reports.TestStep = "Select a program type.";
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad();
                FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction("Program Name", "PT_DO_NOT_DELETE", "Sel", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "click on view more search type.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsSearchType.FASendKeys(@"++");

                Reports.TestStep = "Select the Instruction Type.";
                FastDriver.SearchTypeDialogDlg.WaitForScreenToLoad();
                FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Change transaction type,BusOrg.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Search Package");
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDLEASE01");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText(@"1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText(@"PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText(@"PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText(@"PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem(@"Orange");
                FastDriver.NewFileEntry.DetailsSalePrice.FASetText(@"600,000.00");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText(@"250,000.00");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText(@"150,000.00");

                Reports.TestStep = "Verify program type is retained";
                Support.AreEqual(@"PT_DO_NOT_DELETE", FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FAGetSelectedItem() ?? "");

                Reports.TestStep = "Click on Search Type";
                FastDriver.NewFileEntry.DetailsSearchType.FASendKeys(@"++");

                Reports.TestStep = "Select the Instruction Type.";
                FastDriver.SearchTypeDialogDlg.WaitForScreenToLoad();
                FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Change program type,product and verify search type is not refreshed.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem(@"No Program Type");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("No Product Issued"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                }
                Support.AreEqual(@"04-Ownership Report", FastDriver.NewFileEntry.DetailsSearchType.FAGetSelectedItem() ?? "");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                #region FMUC0107_REG0050

                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem(@"Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate Program type and search type from NFE";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"No Program Type", FastDriver.FileHomepage.ProgramType.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"04-Ownership Report", FastDriver.FileHomepage.SearchType.FAGetSelectedItem() ?? "");

                #endregion FMUC0107_REG0050

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0051_52()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10232_01: Provide ability to select Search Instructions. FM10232_02_FM10233: Provide ability to select Search Instructions(file)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Search for a gab code(Pre-condition).";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText(@"HUDFLINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "HUDFLINSR1", 7, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Select the instructions.";
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.InstructionsAddRemove.FAClick();

                Reports.TestStep = "Select the Instruction 'Regression_Set1_Instruction1'.";
                FastDriver.SelectInstructionDlg.WaitForScreenLoad();
                FastDriver.SelectInstructionDlg.InstructionTable.PerformTableAction(2, "Regression_Set1_Instruction1", 1, TableAction.On);

                Reports.TestStep = "Select the Instruction 'Regression_Set1_Instruction2'.";
                FastDriver.SelectInstructionDlg.InstructionTable.PerformTableAction(2, "Regression_Set1_Instruction2", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText(@"HUDASLNDR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "HUDASLNDR1", 7, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Select the instructions.";
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.InstructionsAddRemove.FAClick();

                Reports.TestStep = "Select the Instruction 'Sanity_Instruction1'";
                FastDriver.SelectInstructionDlg.WaitForScreenLoad();
                FastDriver.SelectInstructionDlg.InstructionTable.PerformTableAction(2, "Sanity_Instruction1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #region FMUC0107_REG0052

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file in NFE and validate the instructions";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem(@"No Program Type");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                    FastDriver.ProductSelectionDlg.Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Support.AreEqual(@"True", FastDriver.NewFileEntry.DetailsNewFileEntryInstructions.FAGetValue().Clean().Contains("Regression_Set1_Instruction1").ToString(),
                    "Verify whether 'DetailsNewFileEntryInstructions' element contains 'Regression_Set1_Instruction1'.");
                Support.AreEqual(@"True", FastDriver.NewFileEntry.DetailsNewFileEntryInstructions.FAGetValue().Clean().Contains("Regression_Set1_Instruction2").ToString(),
                    "Verify whether 'DetailsNewFileEntryInstructions' element contains 'Regression_Set1_Instruction2'.");
                FastDriver.NewFileEntry.AdditionalInstructions.FASetText(@"Entered AdditionalInstructions");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem(@"Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate search instructions from NFE";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"Regression_Set1_Instruction1, Regression_Set1_Instruction2", FastDriver.FileHomepage.SearchInstructions.FAGetValue().Clean());
                Support.AreEqual(@"Entered AdditionalInstructions", FastDriver.FileHomepage.AddInstruction.FAGetValue().Clean());

                Reports.TestStep = "Change the BusOrg in FHP.";
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText(@"HUDASLNDR1");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();

                Reports.TestStep = "Click on Ok button.";
                Support.AreEqual(@"Would you like to update the Title Officer?", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Click on Ok button.";
                Support.AreEqual(@"Would you like to update the Escrow Officer?", FastDriver.WebDriver.HandleDialogMessage(false, true, timeout: 10).Clean());

                Reports.TestStep = "Click on Ok button.";
                var value = FastDriver.WebDriver.HandleDialogMessage(true, true, timeout: 20).Clean();
                if (value.Contains("Retain"))
                {
                    Support.AreEqual(@"Retain the Program Type that was selected for the previous Business Source?", value);
                }
                else
                {
                    Support.AreEqual(@"Would you like to update the file Product and Search Type?", value);
                }

                Reports.TestStep = "Validate default  instructions for changed Bus Org";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"Sanity_Instruction1", FastDriver.FileHomepage.SearchInstructions.FAGetValue().Clean());
                Support.AreEqual(@"Entered AdditionalInstructions", FastDriver.FileHomepage.AddInstruction.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validating instructions from NFE in PTI";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual(@"Sanity_Instruction1", FastDriver.PropertyTaxInfoGeneral.GeneralInstructions.FAGetValue().Clean());
                Support.AreEqual(@"Entered AdditionalInstructions", FastDriver.PropertyTaxInfoGeneral.GeneralAdditionalInstructions.FAGetValue().Clean());

                #endregion FMUC0107_REG0052

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0053_54()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10235_01: Allow depositing funds to a Pending File-1";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Pending file-Details Tab";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy");

                Reports.TestStep = "Go to Deposit In Escrow screen and deposit amount.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText(@"8000" + FAKeys.Tab);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(@"Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem(@"Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText(@"Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(@"Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText(@"Buyer");
                var DepositedToAcctNo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem() ?? "";

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "To validate that Deposit/Receipt History is loaded.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem(@"Cancel");
                // ***************************************** START *********************************************
                var Description = FastDriver.DepositAdjustment.AdjustmentDate.FAGetValue().Clean();
                Description = "Cancel " + Description;
                // ***************************************** END *********************************************
                var value = FastDriver.DepositAdjustment.Description.FAGetValue().Clean();
                // ***************************************** START *********************************************
                Support.AreEqual("True", value.Contains(Description).ToString(), "Verify whether the Description field contains text: '" + Description + "'");
                // ***************************************** END *********************************************
                FastDriver.DepositAdjustment.Comment.FASetText(@"Deposit Adjustment");
                Support.AreEqual(@"True", FastDriver.DepositAdjustment.UpdateTrustAccounting.Selected.ToString(), "Verify whether the 'UpdateTrustAccounting' checkbox is checked.");
                Support.AreEqual(@"True", FastDriver.DepositAdjustment.Loggedonuser.Displayed.ToString(), "Verify whether the 'Loggedonuser' element does exist.");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click);

                #region FMUC0107_REG0054

                Reports.TestStep = "FMUC0107_REG0054 Test Description: FM10235_02: Allow depositing funds to a Pending File-2";
                Reports.StatusUpdate(@"Test Case FMUC0107_REG0054.", true);

                Reports.TestStep = "To select the adjusted deposit and repost.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "To validate that Deposit/Receipt History is loaded.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Deposit.";
                Support.AreEqual(@"REPOST", FastDriver.DepositAdjustment.AdjustmentReason.FAGetSelectedItem() ?? "");
                // ***************************************** START *********************************************
                Description = FastDriver.DepositAdjustment.AdjustmentDate.FAGetValue().Clean();
                Description = "REPOST " + Description;
                // ***************************************** END *********************************************
                value = FastDriver.DepositAdjustment.Description.FAGetValue().Clean();
                // *********************************** Start **********************************************
                Support.AreEqual(@"True", value.Contains(Description).ToString(), "Verify whether the field 'Description' contains text: '" + Description + "'");
                // *********************************** End **********************************************
                FastDriver.DepositAdjustment.Comment.FASetText(@"Repost deposit");
                Support.AreEqual(@"True", FastDriver.DepositAdjustment.UpdateTrustAccounting.Selected.ToString(), "Verify whether 'UpdateAccounting' checkbox is checked.");
                Support.AreEqual(@"True", FastDriver.DepositAdjustment.Loggedonuser.Displayed.ToString(), "Verify whether the 'Loggedonuser' element is displayed.");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Validate after repost deposit.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.DepositSummary.RepostDescription.FAGetText().Clean().Contains(Description).ToString(), "Verify whether the 'RepostDescription' element contains text '" + Description + "'.");

                #endregion FMUC0107_REG0054

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0055()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10235_03: Allow depositing funds to a Pending File-3";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyerType: BuyerSellerType.Individual);

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText(@"10" + FAKeys.Tab);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(@"Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem(@"Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText(@"Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(@"Buyer");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Create a Deposit and click on History button.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.History.FAClick();

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit amount.";
                FastDriver.DepositSummary.WaitForScreenToLoad();
                Support.AreEqual(@"Sanity Deposit In Escrow", FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10.00", "Description", TableAction.GetText).Message.Clean());

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit Totals.";
                Support.AreEqual(@"10.00", FastDriver.DepositSummary.Net3300.Text.Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0056()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10235_04: Allow depositing funds to a Pending File-4";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Outside Escrow Company", saveFile: false);

                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Enter data for Parties Tab with additional Role(Buyers' and Sellers Attorney)";
                FastDriver.NewFileEntry.FindDirectedByGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASelectItem(@"Seller's Attorney");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewFileEntry.FindAssociatedBusinessPartyGAB(@"HUDLEASE03");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddtionalRole.FASelectItem(@"Seller's Broker");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Deposit outside escrow and prevalidate the datas in Deposit outside escrow";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue().Clean());
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testi", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue().Clean());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to Deposit outside escrow and set values for seller's broker.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"500.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem(@"Seller's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FASetText(@"Seller's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"500.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the amount entered for seller's broker.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"500.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue().Clean());
                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem().Clean() ?? "");
                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue().Clean());

                Reports.TestStep = "Enter Amount for Seller's Attorney.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"1,000.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem(@"Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FASetText(@"Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"500.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the amount entered for seller's attorney.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"1,000.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue().Clean());
                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue().Clean());
                Support.AreEqual(@"500.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue().Clean());
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue().Clean());

                Reports.TestStep = "Enter Excess deposit amount for (existing deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"1,800.00");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText(@"800.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate for Excess deposit amount for existing deposit.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"1,800.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue().Clean());
                Support.AreEqual(@"800.00", FastDriver.DepositOutsideEscrow.ExcessDeposit.FAGetValue().Clean());

                Reports.TestStep = "Record Amount to be Disbursed as Proceeds (on a Existing Deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"2,000.00");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"200.00");
                FastDriver.BottomFrame.Save();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0057()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM12776_FM10197_04: Image Distribution and Delivery Instructions";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Other Real Estate Broker");

                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();

                Reports.TestStep = "Click on ImageDoc";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                if (FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FAGetValue().Clean() != "")
                {
                    FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FASetText("" + FAKeys.Tab);
                }
                FastDriver.ViewDeliveryInstrucionsDlg.OtherRealEstateBroker.FAClick();
                if (FastDriver.ViewDeliveryInstrucionsDlg.Doc3OpeningPackage.FAGetValue().Clean() != "")
                {
                    FastDriver.ViewDeliveryInstrucionsDlg.Doc3OpeningPackage.FASetText("" + FAKeys.Tab);
                }
                if (!FastDriver.ViewDeliveryInstrucionsDlg.Imagedoc.Exists())
                {
                    Keyboard.SendKeys("^L");
                }
                else
                {
                    FastDriver.ViewDeliveryInstrucionsDlg.Imagedoc.FAClick();
                }
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc);
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();

                Reports.TestStep = "Verify affter image doc";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                if (FastDriver.ViewDeliveryInstrucionsDlg.LastImagedByFASTQA07.Exists())
                {
                    FastDriver.ViewDeliveryInstrucionsDlg.LastImagedByFASTQA07.FAClick();
                }
                else
                {
                    Reports.StatusUpdate(@"Element 'LastImagedByFASTQA07', not present.", false);
                }
                var IssueDate = DateTime.Now.ToDateString().Replace("-", "/");
                Support.AreEqual(@"True", FastDriver.ViewDeliveryInstrucionsDlg.EditDate.FAGetText().Clean().Contains(IssueDate).ToString(), "Verify whether 'EditDate' element contains '" + IssueDate + "'.");
                FastDriver.DialogBottomFrame.ClickDone();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0058_59()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM13633_01_FM13632_01: Change Business Segment(ADM)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Get the Business Segment value from Office Set up.";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                var BSegment = FastDriver.OfficeSetupOffice.BusinessSegment.FAGetSelectedItem() ?? "";

                #region FMUC0107_REG0059

                Reports.TestStep = "FMUC0107_REG0059 Test Description: FM13633_02_FM13632_02: Change Business Segment(file)";
                Reports.StatusUpdate(@"FM13633_02_FM13632_02: Change Business Segment(file)", true);

                Reports.TestStep = "Login in IIS.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                Support.AreEqual(BSegment, FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FAGetSelectedItem() ?? "");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem(@"No Program Type");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table);
                    FastDriver.ProductSelectionDlg.Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");

                Reports.TestStep = "Change Business Segment";
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"New Home");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Change the status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FileStatus.FASelectItem(@"Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                #endregion FMUC0107_REG0059

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0060_61()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var credentials2 = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM13631_01: Default Service Type(Role= Title Assistant)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.LoginName.FASetText(AutoConfig.UserNameSecondary);
                FastDriver.EmployeeSearch.SearchNow.FAClick();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, "[" + AutoConfig.UserNameSecondary.ToUpper() + "]", 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Change the Employee Type to Title Assistant.";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (FastDriver.EmployeeSetup.RoleTOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleTOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleEOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleEAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.SalesRep.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.SalesRep.Click();

                        return !FastDriver.EmployeeSetup.SalesRep.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleOther.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleOther.Click();

                        return !FastDriver.EmployeeSetup.RoleOther.Selected;
                    });
                }
                FastDriver.EmployeeSetup.RoleTAssistant.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                #region FMUC0107_REG0061

                Reports.TestStep = "Validate Title service is checked by default";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                    FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                    return FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected;
                }, timeout: 600, idleInterval: 5);
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString(), "Verify whether the 'DetailsTitlecheckbox' is checked by default.");
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString(), "Verify whether the 'DetailsEscrowcheckbox' is unchecked by default.");
                FastDriver.LeftNavigation.ClickHome();

                #endregion FMUC0107_REG0061

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0062_63()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var credentials2 = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM13631_03: Default Service Type (Role= Title Officer)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.LoginName.FASetText(AutoConfig.UserNameSecondary);
                FastDriver.EmployeeSearch.SearchNow.FAClick();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, "[" + AutoConfig.UserNameSecondary.ToUpper() + "]", 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Change the Employee Type to Title Officer.";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (FastDriver.EmployeeSetup.RoleTAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleTAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleEOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleEAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.SalesRep.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.SalesRep.Click();

                        return !FastDriver.EmployeeSetup.SalesRep.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleOther.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleOther.Click();

                        return !FastDriver.EmployeeSetup.RoleOther.Selected;
                    });
                }
                FastDriver.EmployeeSetup.RoleTOfficer.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                #region FMUC0107_REG0063

                Reports.TestStep = "Validate Title service is checked by default";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                    FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                    return FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected;
                }, timeout: 600, idleInterval: 5);
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString(), "Verify whether the 'DetailsTitlecheckbox' is checked by default.");
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString(), "Verify whether the 'DetailsEscrowcheckbox' is unchecked by default.");
                FastDriver.LeftNavigation.ClickHome();

                #endregion FMUC0107_REG0063

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0064_65()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var credentials2 = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM13631_05: Default Service Type (Role= Escrow Officer)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.LoginName.FASetText(AutoConfig.UserNameSecondary);
                FastDriver.EmployeeSearch.SearchNow.FAClick();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, "[" + AutoConfig.UserNameSecondary.ToUpper() + "]", 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Change the Employee Type to Escrow Officer.";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (FastDriver.EmployeeSetup.RoleTAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleTAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleTOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleTOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleEAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.SalesRep.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.SalesRep.Click();

                        return !FastDriver.EmployeeSetup.SalesRep.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleOther.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleOther.Click();

                        return !FastDriver.EmployeeSetup.RoleOther.Selected;
                    });
                }
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.EmployeeSetup.RoleEOfficer.Click();
                    return FastDriver.EmployeeSetup.RoleEOfficer.Selected;
                });
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                #region FMUC0107_REG0065

                Reports.TestStep = "Validate Title service is checked by default";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                    FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                    return FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected;
                }, timeout: 600, idleInterval: 5);
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString(), "Verify whether the 'DetailsTitlecheckbox' is unchecked by default.");
                Support.AreEqual(@"True", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString(), "Verify whether the 'DetailsEscrowcheckbox' is checked by default.");
                FastDriver.LeftNavigation.ClickHome();

                #endregion FMUC0107_REG0065

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0066_67()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var credentials2 = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM13631_07: Default Service Type (Role= Escrow Assistant)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.LoginName.FASetText(AutoConfig.UserNameSecondary);
                FastDriver.EmployeeSearch.SearchNow.FAClick();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, "[" + AutoConfig.UserNameSecondary.ToUpper() + "]", 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Change the Employee Type to Escrow Officer.";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (FastDriver.EmployeeSetup.RoleTAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleTAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleTOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleTOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleEOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.SalesRep.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.SalesRep.Click();

                        return !FastDriver.EmployeeSetup.SalesRep.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleOther.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleOther.Click();

                        return !FastDriver.EmployeeSetup.RoleOther.Selected;
                    });
                }
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.EmployeeSetup.RoleEAssistant.Click();
                    return FastDriver.EmployeeSetup.RoleEAssistant.Selected;
                });
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                #region FMUC0107_REG0067

                Reports.TestStep = "Validate Title service is checked by default";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                    FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                    return FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected;
                }, timeout: 600, idleInterval: 5);
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString(), "Verify whether the 'DetailsTitlecheckbox' is unchecked by default.");
                Support.AreEqual(@"True", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString(), "Verify whether the 'DetailsEscrowcheckbox' is checked by default.");
                FastDriver.LeftNavigation.ClickHome();

                #endregion FMUC0107_REG0067

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0068_69()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var credentials2 = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM13631_09: Default Service Type (Role= Sales Rep)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.LoginName.FASetText(AutoConfig.UserNameSecondary);
                FastDriver.EmployeeSearch.SearchNow.FAClick();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, "[" + AutoConfig.UserNameSecondary.ToUpper() + "]", 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Change the Employee Type to Sales Rep.";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (FastDriver.EmployeeSetup.RoleTAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleTAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleTOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleTOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleEOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleEAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleOther.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleOther.Click();

                        return !FastDriver.EmployeeSetup.RoleOther.Selected;
                    });
                }
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.EmployeeSetup.SalesRep.Click();
                    return FastDriver.EmployeeSetup.SalesRep.Selected;
                });
                FastDriver.WebDriver.HandleDialogMessage();
                //Playback.Wait(10000000);
                FastDriver.BottomFrame.Done();

                #region FMUC0107_REG0069

                Reports.TestStep = "Validate Title service is checked by default";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                    FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                    return !FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected;
                }, timeout: 600, idleInterval: 5);
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                    FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                    return !FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected;
                }, timeout: 600, idleInterval: 5);
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString(), "Verify whether the 'DetailsTitlecheckbox' is unchecked by default.");
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString(), "Verify whether the 'DetailsEscrowcheckbox' is unchecked by default.");
                FastDriver.LeftNavigation.ClickHome();

                #endregion FMUC0107_REG0069

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0070_71()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM13631_11: Default Service Type (Role= Other)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.LoginName.FASetText(AutoConfig.UserNameSecondary);
                FastDriver.EmployeeSearch.SearchNow.FAClick();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, "[" + AutoConfig.UserNameSecondary.ToUpper() + "]", 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Change the Employee Type to Sales Rep.";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (FastDriver.EmployeeSetup.RoleTAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleTAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleTOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleTOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleEOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleEAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.SalesRep.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.SalesRep.Click();

                        return !FastDriver.EmployeeSetup.SalesRep.Selected;
                    });
                }
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.EmployeeSetup.RoleOther.Click();
                    return FastDriver.EmployeeSetup.RoleOther.Selected;
                });
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                FastDriver.EmployeeSetup.Description.FASetText(@"Test");
                FastDriver.BottomFrame.Done();

                #region FMUC0107_REG0071

                Reports.TestStep = "Validate Title service is checked by default";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                    FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                    return !FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected;
                }, timeout: 600, idleInterval: 5);
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                    FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                    return !FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected;
                }, timeout: 600, idleInterval: 5);
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected.ToString(), "Verify whether the 'DetailsTitlecheckbox' is unchecked by default.");
                Support.AreEqual(@"False", FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected.ToString(), "Verify whether the 'DetailsEscrowcheckbox' is unchecked by default.");
                FastDriver.LeftNavigation.ClickHome();

                #endregion FMUC0107_REG0071

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0072()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM13631_13: Set the type back to Title/Escrow";

                Reports.TestStep = "Log into FAST application.";
               FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                //Reports.TestStep = "Navigate to Region Level.";
                //FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                //FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.LoginName.FASetText(AutoConfig.UserNameSecondary);
                FastDriver.EmployeeSearch.SearchNow.FAClick();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, "[" + AutoConfig.UserNameSecondary.ToUpper() + "]", 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Change the Employee Type to Sales Rep.";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (FastDriver.EmployeeSetup.RoleTAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleTAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleTOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleTOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleTOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEOfficer.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEOfficer.Click();

                        return !FastDriver.EmployeeSetup.RoleEOfficer.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleEAssistant.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleEAssistant.Click();

                        return !FastDriver.EmployeeSetup.RoleEAssistant.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.SalesRep.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.SalesRep.Click();

                        return !FastDriver.EmployeeSetup.SalesRep.Selected;
                    });
                }
                if (FastDriver.EmployeeSetup.RoleOther.Selected)
                {
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        FastDriver.EmployeeSetup.RoleOther.Click();

                        return !FastDriver.EmployeeSetup.RoleOther.Selected;
                    });
                }
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.EmployeeSetup.RoleEOfficer.Click();
                    return FastDriver.EmployeeSetup.RoleEOfficer.Selected;
                });
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.EmployeeSetup.RoleTOfficer.Click();
                    return FastDriver.EmployeeSetup.RoleTOfficer.Selected;
                });
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0073_74()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10183_FM10181_FM10177_FM10182_FD_Products: Owner Policy for a Escrow Only file_1";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(title: false, ownerPolicy: "No Product Issued", addRole: "Other Real Estate Broker", saveFile: false);

                Reports.TestStep = "Validate No Product Issued is selected by default on Escrow file.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Reports.StatusUpdate("Verify the RowCount of the 'OwnerPolicyTable'.", FastDriver.NewFileEntry.OwnerPolicyTable.GetRowCount() >= 2);
                Reports.StatusUpdate("Verify the RowCount of the 'LenderPolicyTable'.", FastDriver.NewFileEntry.LenderPolicyTable.GetRowCount() >= 1);
                Reports.StatusUpdate("Verify the RowCount of the 'OthersTable'.", FastDriver.NewFileEntry.OthersTable.GetRowCount() >= 1);

                Reports.TestStep = "Click on Add/Remove Owner Policy";
                FastDriver.NewFileEntry.DetailsAddRemove.FAClick();

                Reports.TestStep = "Select ALTA Extended Owner Policy";
                FastDriver.LenderPoliciesDlg.WaitForScreenToLoad();
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "ALTA Extended Owner Policy", 2, TableAction.Click);
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verfiy owner policy added.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 2, TableAction.Click);
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);

                Reports.TestStep = "Click on Add/Remove Lender Policy";
                FastDriver.NewFileEntry.DetailsAddRemoveLenderPolicy.FAClick();

                Reports.TestStep = "Select 1999 EAGLE Manufactured Home Loan Policy";
                FastDriver.LenderPoliciesDlg.WaitForScreenToLoad();
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Manufactured Home Loan Policy", 1, TableAction.On);

                Reports.TestStep = "Select ALTA Construction Loan 1992 Policy";
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "ALTA Construction Loan 1992 Policy", 1, TableAction.On);

                Reports.TestStep = "Select ALTA Extended Loan Policy";
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "ALTA Extended Loan Policy", 1, TableAction.On);

                Reports.TestStep = "Select ALTA Extended Leasehold Loan Policy";
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "ALTA Extended Leasehold Loan Policy", 1, TableAction.On);

                Reports.TestStep = "Select ALTA Expanded (Eagle Loan) Policy";
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "ALTA Expanded (Eagle Loan) Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                #region FMUC0107_REG0074

                Reports.TestStep = "FMUC0107_REG0074 Test Description: FM10236_FM10237_FM10184_FM10185_FM10186_ER_16: Owner Policy for a Escrow Only file_2";
                Reports.StatusUpdate(@"FMUC0107_REG0074: FM10236_FM10237_FM10184_FM10185_FM10186_ER_16: Owner Policy for a Escrow Only file_2", true);

                Reports.TestStep = "Verfiy lender policy added-1";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.LenderPolicyTable.PerformTableAction(2, "Manufactured Home Loan Policy", 1, TableAction.On);

                Reports.TestStep = "Verfiy lender policy added-2";
                FastDriver.NewFileEntry.LenderPolicyTable.PerformTableAction(2, "ALTA Construction Loan 1992 Policy", 1, TableAction.On);

                Reports.TestStep = "Verfiy lender policy added-3";
                FastDriver.NewFileEntry.LenderPolicyTable.PerformTableAction(2, "ALTA Extended Loan Policy", 1, TableAction.On);

                Reports.TestStep = "Verfiy lender policy added-4";
                FastDriver.NewFileEntry.LenderPolicyTable.PerformTableAction(2, "ALTA Extended Leasehold Loan Policy", 1, TableAction.On);

                Reports.TestStep = "Verfiy lender policy added-5";
                FastDriver.NewFileEntry.LenderPolicyTable.PerformTableAction(2, "ALTA Expanded (Eagle Loan) Policy", 1, TableAction.On);

                Reports.TestStep = "Select more than 4 lender policy";
                Support.AreEqual(@"A maximum of 4 Lender Policies allowed for the Order.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click on Add/Remove Other Policy";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddRemoveother.FAClick();

                Reports.TestStep = "Select Abstract";
                FastDriver.LenderPoliciesDlg.WaitForScreenToLoad();
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Abstract", 1, TableAction.On);

                Reports.TestStep = "Select Agency File Scanning";
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Agency File Scanning", 1, TableAction.On);

                Reports.TestStep = "Select Agency Policy Typing";
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Agency Policy Typing", 1, TableAction.On);

                Reports.TestStep = "Select Agency Post Closing";
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Agency Post Closing", 1, TableAction.On);

                Reports.TestStep = "Select Attorney Assistance";
                FastDriver.LenderPoliciesDlg.LenderProductTable.PerformTableAction(2, "Attorney Assistance", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (FastDriver.NewFileEntry.OthersTable.Text.Contains("No Product Issued"))
                {
                    if (FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "No Product Issued", 1, TableAction.GetCell).Element.FAFindElements(ByLocator.TagName, "input").GetAllVisible().FirstOrDefault().Selected)
                    {
                        FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "No Product Issued", 1, TableAction.Off);
                    }
                }

                Reports.TestStep = "Verfiy other policy added-1";
                FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "Abstract", 1, TableAction.On);

                Reports.TestStep = "Verfiy other policy added-2";
                FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "Agency File Scanning", 1, TableAction.On);

                Reports.TestStep = "Verfiy other policy added-3";
                FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "Agency Policy Typing", 1, TableAction.On);

                Reports.TestStep = "Verfiy other policy added-4";
                FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "Agency Post Closing", 1, TableAction.On);

                Reports.TestStep = "Verfiy other policy added-5";
                FastDriver.NewFileEntry.OthersTable.PerformTableAction(2, "Attorney Assistance", 1, TableAction.On);

                Reports.TestStep = "Select more than 4 other policy";
                Support.AreEqual(@"A maximum of 4 Other Products allowed for the Order.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.BottomFrame.Save();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                #endregion FMUC0107_REG0074

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0077_78()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_1: Buttons / Icons / Tool Tips-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                Support.AreEqual(AutoConfig.SelectedOfficeName + @" PR: STEST off: 7878(1487)", FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetSelectedItem() ?? "");
                Support.AreEqual(AutoConfig.SelectedOfficeName + @" PR: STEST off: 7878(1487)", FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedItem() ?? "");
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOfficer.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowAssisstant.FASelectItem(@"QA10, FAST");
                Support.AreEqual(@"First American Title Insurance Company", FastDriver.NewFileEntry.DetailsNewFileEntryUnderWriters.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Residential Commercial New Home Subdivision Time Share Default-Residential Default-Commercial", FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.Text ?? "");
                Support.AreEqualTrim(@" Accommodation Bulk Sale Construction Disbursement Construction Finance Equity Loan Foreclosure Limited Escrow Mtg Mod w/Endorsement Mtg Mod w/Increased Liability Refinance REO Sale w/Mortgage REO Sale/Cash Sale w/Construction Loan Sale w/Mortgage Sale/Cash Sale/Exchange Search Package Second Mortgage Settlement Statement Only Short Sale w/Mortgage Short Sale/Cash ",
                    FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.Text ?? "");
                Support.AreEqualTrim(@"No Program Type++View More...", FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.Text ?? "");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                Support.AreEqualTrim(@"Assumption Lender Buyer Buyer's Attorney Buyer's Broker Buyer's Real Estate Agent Construction Company/Builder For Sale by Owner Lender's Attorney Lender- Funding Lender- Loan Officer Lender- Mobile Banker Lender- Mortgage Centre Lender- Originating Branch Lender- Processor Lender- Signing Location Miscellaneous Mortgage Broker New Lender Other Real Estate Agent Other Real Estate Broker Outside Escrow Company Outside Title Company Payoff Lender Real Estate Investment Trust Search Vendor Seller Seller's Attorney Seller's Broker Seller's Real Estate Agent Title Agent",
                    FastDriver.NewFileEntry.DetailsAddtionalRole.Text ?? "");
                Support.AreEqualTrim(@"No Search Type ++View More...", FastDriver.NewFileEntry.DetailsSearchType.Text ?? "");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItemBySendingKeys(@"Husband/Wife");
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText(@"Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText(@"Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText(@"Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsBuyerStreet1.FASetText(@"Address1");
                FastDriver.NewFileEntry.DetailsBuyerStreet2.FASendKeys(@"Address");
                FastDriver.NewFileEntry.DetailsBuyerStreet2.FASendKeys(@"2");
                FastDriver.NewFileEntry.DetailsBuyerStreet3.FASetText(@"Address3");
                FastDriver.NewFileEntry.DetailsBuyerStreet4.FASetText(@"Address4");
                FastDriver.NewFileEntry.DetailsBuyerCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsBuyerState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsBuyerZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsBuyerCounty.FASetText(@"Orange");
                FastDriver.NewFileEntry.DetailsBuyerBusPh.FASetText(@"(112)233-4455");
                FastDriver.NewFileEntry.DetailsBuyerCellFax.FASetText(@"(112)233-4455");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText(@"Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText(@"Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText(@"Seller2SpouseName");
                FastDriver.NewFileEntry.DetailsSellerStreet1.FASetText(@"Address1");
                FastDriver.NewFileEntry.DetailsSellerStreet2.FASetText(@"Address2");
                FastDriver.NewFileEntry.DetailsSellerStreet3.FASetText(@"Address3");
                FastDriver.NewFileEntry.DetailsSellerStreet4.FASetText(@"Address4");
                FastDriver.NewFileEntry.DetailsSellerCity.FASetText(@"santa ana");
                FastDriver.NewFileEntry.DetailsSellerCity.FASendKeys(@"CA");
                FastDriver.NewFileEntry.DetailsSellerZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsSellerCounty.FASetText(@"Orange");
                FastDriver.NewFileEntry.DetailsSellerBusPh.FASetText(@"(112)133-6666");
                FastDriver.NewFileEntry.DetailsSellerCellFax.FASetText(@"(112)133-6666");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText(@"1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText(@"PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText(@"PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText(@"PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASendKeys(@"Orange");

                Reports.TestStep = "Validate the BuyerSummary table-1";
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Accommodation");
                Support.AreEqual(@"(112)233-4455", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Address", "Address1, Address2", "Bus Phone", TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate the BuyerSummary table-2";
                Support.AreEqual(@"(112)233-4455", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Address", "Address1, Address2", "Cell Phone", TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate the SellerSummary table-1";
                Support.AreEqual(@"(112)133-6666", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Address", "Address1, Address2", "Bus Phone", TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate the SellerSummary table-2";
                Support.AreEqual(@"(112)133-6666", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Address", "Address1, Address2", "Cell Phone", TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                #region FMUC0107_REG0078

                Reports.TestStep = "FMUC0107_REG0078 Test Description: FD_2_ER_13: Buyer/Seller Summary-Details Tab";
                Reports.StatusUpdate(@"FD_2_ER_13: Buyer/Seller Summary-Details Tab", true);

                Reports.TestStep = "Click on Remove Buyer";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"Husband/Wife", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", "Type", TableAction.GetText).Message.Clean());
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", "Name", TableAction.Click);
                FastDriver.NewFileEntry.DetailsRemove_buyer.FAClick();

                Reports.TestStep = "Remove Buyer in NFE";
                Support.AreEqual(@"Are you sure you want to Remove Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Validate after removing buyer";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"Husband/Wife", FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Available / Available", "Type", TableAction.GetText).Message.Clean());

                Reports.TestStep = "Click on Remove Seller";
                Support.AreEqual(@"Husband/Wife", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname", "Type", TableAction.GetText).Message.Clean());
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname", "Name", TableAction.Click);
                FastDriver.NewFileEntry.DetailsRemoveSeller.FAClick();

                Reports.TestStep = "Remove Seller in NFE";
                Support.AreEqual(@"True", FastDriver.WebDriver.HandleDialogMessage().Clean().Contains(@"Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname").ToString(),
                    "Verify whether the Alert Message text contains 'Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname'.");

                Reports.TestStep = "Validate after removing seller";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"Husband/Wife", FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Available / Available", "Type", TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                #endregion FMUC0107_REG0078

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0079()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_3: Search Instructions  Section/lot/master file-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOfficer.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowAssisstant.FASelectItem(@"QA10, FAST");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItemBySendingKeys(@"Husband/Wife");
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText(@"Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText(@"Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText(@"Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsBuyerStreet1.FASetText(@"Address1");
                FastDriver.NewFileEntry.DetailsBuyerStreet2.FASendKeys(@"Address");
                FastDriver.NewFileEntry.DetailsBuyerStreet2.FASendKeys(@"2");
                FastDriver.NewFileEntry.DetailsBuyerStreet3.FASetText(@"Address3");
                FastDriver.NewFileEntry.DetailsBuyerStreet4.FASetText(@"Address4");
                FastDriver.NewFileEntry.DetailsBuyerCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsBuyerState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsBuyerZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsBuyerCounty.FASetText(@"Orange");
                FastDriver.NewFileEntry.DetailsBuyerBusPh.FASetText(@"(112)233-4455");
                FastDriver.NewFileEntry.DetailsBuyerCellFax.FASetText(@"(112)233-4455");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText(@"Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText(@"Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText(@"Seller2SpouseName");
                FastDriver.NewFileEntry.DetailsSellerStreet1.FASetText(@"Address1");
                FastDriver.NewFileEntry.DetailsSellerStreet2.FASetText(@"Address2");
                FastDriver.NewFileEntry.DetailsSellerStreet3.FASetText(@"Address3");
                FastDriver.NewFileEntry.DetailsSellerStreet4.FASetText(@"Address4");
                FastDriver.NewFileEntry.DetailsSellerCity.FASetText(@"santa ana");
                FastDriver.NewFileEntry.DetailsSellerCity.FASendKeys(@"CA");
                FastDriver.NewFileEntry.DetailsSellerZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsSellerCounty.FASetText(@"Orange");
                FastDriver.NewFileEntry.DetailsSellerBusPh.FASetText(@"(112)133-6666");
                FastDriver.NewFileEntry.DetailsSellerCellFax.FASetText(@"(112)133-6666");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText(@"1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText(@"PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText(@"PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText(@"PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASendKeys(@"Orange");

                Reports.TestStep = "Validate the BuyerSummary table-1";
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Accommodation");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Remove Buyer";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", "Name", TableAction.Click);
                FastDriver.NewFileEntry.DetailsRemove_buyer.FAClick();

                Reports.TestStep = "Remove Buyer in NFE";
                Support.AreEqual(@"Are you sure you want to Remove Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click on Remove Seller";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname", "Name", TableAction.Click);
                FastDriver.NewFileEntry.DetailsRemoveSeller.FAClick();

                Reports.TestStep = "Remove Seller in NFE";
                Support.AreEqual(@"True", FastDriver.WebDriver.HandleDialogMessage().Clean().Contains(@"Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname").ToString(),
                    "Verify whether the Alert Message text contains 'Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname'.");

                Reports.TestStep = "Validate after removing seller";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Change Gabcode and click on search instructions";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"", FastDriver.NewFileEntry.DetailsNewFileEntryMasterFile.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.NewFileEntry.DetailsNewFileEntryLotNo.FAGetValue().Clean());
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"247");
                FastDriver.NewFileEntry.DetailsAddRemoveInstruction.FAClick();

                Reports.TestStep = "Click on Check All";
                FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
                FastDriver.SelectInstructionsDlg.CheckAll.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter more than 7 instructions";
                Support.AreEqual(@"The maximum number of instructions has been reached for this file.", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false, timeout: 10);

                Reports.TestStep = "Click on Clear";
                FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
                FastDriver.SelectInstructionsDlg.Clear.FAClick();

                Reports.TestStep = "Select Instruction1.";
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(2, "Regression_Set1_Instruction1", 1, TableAction.On);

                Reports.TestStep = "Select Instruction2.";
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(2, "Regression_Set1_Instruction2", 1, TableAction.On);

                Reports.TestStep = "Select Instruction3.";
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(2, "Regression_Set1_Instruction3", 1, TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the instructions and enter more than 250 chars for Additional Inst.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsNewFileEntryMasterFile.FASetText(@"ABC123ABC12333HIIIIHHH" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsNewFileEntryLotNo.FASetText(@"12121233321313123232312323232323123231244353545555" + FAKeys.Tab);
                Support.AreEqual(@"Regression_Set1_Instruction1, Regression_Set1_Instruction2, Regression_Set1_Instruction3", FastDriver.NewFileEntry.DetailsNewFileEntryInstructions.FAGetValue().Clean());
                FastDriver.NewFileEntry.DetailsNewFileEntryAddInstructions.FASetText(@"Regression_Set1_Instruction1, Regression_Set1_Instruction2, Regression_Set1_Instruction3, Regression_Set1_Instruction1, Regression_Set1_Instruction2, Regression_Set1_Instruction3, Regression_Set1_Instruction1, Regression_Set1_Instruction2, Regression_Set1_Instruction3" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Keyboard.SendKeys("{DEL}");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Validate the lot, master file and 255 chars for additional instructions";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"ABC123ABC12333HIIIIHHH", FastDriver.NewFileEntry.DetailsNewFileEntryMasterFile.FAGetValue().Clean());
                Support.AreEqual(@"12121233321313123232312323232323123231244353545555", FastDriver.NewFileEntry.DetailsNewFileEntryLotNo.FAGetValue().Clean());
                Support.AreEqual(@"Regression_Set1_Instruction1,Regression_Set1_Instruction2,Regression_Set1_Instruction1,Regression_Set1_Instruction2,Regression_Set1_Instruction3",
                    FastDriver.NewFileEntry.DetailsNewFileEntryInstructions.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.NewFileEntry.DetailsNewFileEntryAddInstructions.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0080()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_4_ER_12: Business Party section-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOfficer.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowAssisstant.FASelectItem(@"QA10, FAST");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem(@"Husband/Wife");
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText(@"Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText(@"Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText(@"Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsBuyerStreet1.FASetText(@"Address1");
                FastDriver.NewFileEntry.DetailsBuyerStreet2.FASendKeys(@"Address");
                FastDriver.NewFileEntry.DetailsBuyerStreet2.FASendKeys(@"2");
                FastDriver.NewFileEntry.DetailsBuyerStreet3.FASetText(@"Address3");
                FastDriver.NewFileEntry.DetailsBuyerStreet4.FASetText(@"Address4");
                FastDriver.NewFileEntry.DetailsBuyerCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsBuyerState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsBuyerZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsBuyerCounty.FASetText(@"Orange");
                FastDriver.NewFileEntry.DetailsBuyerBusPh.FASetText(@"(112)233-4455");
                FastDriver.NewFileEntry.DetailsBuyerCellFax.FASetText(@"(112)233-4455");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText(@"Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText(@"Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText(@"Seller2SpouseName");
                FastDriver.NewFileEntry.DetailsSellerStreet1.FASetText(@"Address1");
                FastDriver.NewFileEntry.DetailsSellerStreet2.FASetText(@"Address2");
                FastDriver.NewFileEntry.DetailsSellerStreet3.FASetText(@"Address3");
                FastDriver.NewFileEntry.DetailsSellerStreet4.FASetText(@"Address4");
                FastDriver.NewFileEntry.DetailsSellerCity.FASetText(@"santa ana");
                FastDriver.NewFileEntry.DetailsSellerCity.FASendKeys(@"CA");
                FastDriver.NewFileEntry.DetailsSellerZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsSellerCounty.FASetText(@"Orange");
                FastDriver.NewFileEntry.DetailsSellerBusPh.FASetText(@"(112)133-6666");
                FastDriver.NewFileEntry.DetailsSellerCellFax.FASetText(@"(112)133-6666");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText(@"1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText(@"PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText(@"PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText(@"PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASendKeys(@"Orange");

                Reports.TestStep = "Validate the BuyerSummary table-1";
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Accommodation");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Remove Buyer";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction("Name", "Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", "Name", TableAction.Click);
                FastDriver.NewFileEntry.DetailsRemove_buyer.FAClick();

                Reports.TestStep = "Remove Buyer in NFE";
                Support.AreEqual(@"Are you sure you want to Remove Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click on Remove Seller";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction("Name", "Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname", "Name", TableAction.Click);
                FastDriver.NewFileEntry.DetailsRemoveSeller.FAClick();

                Reports.TestStep = "Remove Seller in NFE";
                Support.AreEqual(@"True", FastDriver.WebDriver.HandleDialogMessage().Clean().Contains(@"Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname").ToString(),
                    "Verify whether the Alert Message text contains 'Seller2Firstname Seller2Lastname /Seller2SpouseName Seller2Lastname'.");

                Reports.TestStep = "Validate after removing seller";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Change Gabcode and click on search instructions";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"", FastDriver.NewFileEntry.DetailsNewFileEntryMasterFile.FAGetValue().Clean());
                Support.AreEqual(@"", FastDriver.NewFileEntry.DetailsNewFileEntryLotNo.FAGetValue().Clean());
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"247");
                FastDriver.NewFileEntry.DetailsAddRemoveInstruction.FAClick();

                Reports.TestStep = "Click on Check All";
                FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
                FastDriver.SelectInstructionsDlg.CheckAll.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter more than 7 instructions";
                Support.AreEqual(@"The maximum number of instructions has been reached for this file.", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false, timeout: 10);

                Reports.TestStep = "Click on Clear";
                FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
                FastDriver.SelectInstructionsDlg.Clear.FAClick();

                Reports.TestStep = "Select Instruction1.";
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(2, "Regression_Set1_Instruction1", 1, TableAction.On);

                Reports.TestStep = "Select Instruction2.";
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(2, "Regression_Set1_Instruction2", 1, TableAction.On);

                Reports.TestStep = "Select Instruction3.";
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(2, "Regression_Set1_Instruction3", 1, TableAction.On);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the instructions and enter more than 250 chars for Additional Inst.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsNewFileEntryMasterFile.FASetText(@"ABC123ABC12333HIIIIHHH" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsNewFileEntryLotNo.FASetText(@"12121233321313123232312323232323123231244353545555" + FAKeys.Tab);
                Support.AreEqual(@"Regression_Set1_Instruction1, Regression_Set1_Instruction2, Regression_Set1_Instruction3", FastDriver.NewFileEntry.DetailsNewFileEntryInstructions.FAGetValue().Clean());
                FastDriver.NewFileEntry.DetailsNewFileEntryAddInstructions.FASetText(@"Regression_Set1_Instruction1, Regression_Set1_Instruction2, Regression_Set1_Instruction3, Regression_Set1_Instruction1, Regression_Set1_Instruction2, Regression_Set1_Instruction3, Regression_Set1_Instruction1, Regression_Set1_Instruction2, Regression_Set1_Instruction3" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsNewFileEntryAddInstructions.FireEvent("onfocus");
                    Playback.Wait(500);
                    Keyboard.SendKeys("{DEL}");
                    Playback.Wait(500);
                    FastDriver.NewFileEntry.Gcode1.Click();
                    Playback.Wait(500);
                    if (FastDriver.NewFileEntry.DetailsNewFileEntryAddInstructions.FAGetValue().Clean() != "")
                        return false;
                    return FastDriver.NewFileEntry.DetailsNewFileEntryAddInstructions.FAGetValue().Clean() == "";
                });
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Validating max of 10 chars for GAB Code";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");

                Reports.TestStep = "Validating max of 40 chars for Name";
                FastDriver.NewFileEntry.DetailsBuinessSourceName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.DetailsFind.FAClick();
                Support.AreEqual(@"HUDFLINSR1", FastDriver.NewFileEntry.Gcode1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1", FastDriver.NewFileEntry.Name1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 2", FastDriver.NewFileEntry.Name2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 1, Fire Insurance 1 business street 2", FastDriver.NewFileEntry.Address1.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 3, Fire Insurance 1 business street 4", FastDriver.NewFileEntry.Address2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business city, NY, 74081-6545, USA", FastDriver.NewFileEntry.Address3.FAGetText().Clean());
                FastDriver.NewFileEntry.DetailsEditCheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.DetailsNewFileEntryBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.DetailsNewFileEntryCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.DetailsPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.DetailsEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Validated the data";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.DetailsNewFileEntryBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.DetailsNewFileEntryBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.DetailsNewFileEntryCellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.DetailsPager.FAGetValue().Clean());
                Support.AreEqual(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com", FastDriver.NewFileEntry.DetailsEmailAddress.FAGetValue().Clean());

                Reports.TestStep = "Enter Attention and other details";
                FastDriver.NewFileEntry.DetailsAttention.FASelectItem(@"Contact, Flood Insurance 1");
                FastDriver.NewFileEntry.DetailsEditNameCheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEditName.FASetText(@"EDITATTENTION123");
                FastDriver.NewFileEntry.DetailsSalesRep1.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.DetailsSalesRep2.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.DetailsReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");

                Reports.TestStep = "Enter invalid email";
                FastDriver.NewFileEntry.DetailsEditCheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111" + FAKeys.Tab);

                Reports.TestStep = "Validate invalid email";
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsEmailAddress.FAGetValue().Clean());

                Reports.TestStep = "enter valid email";
                FastDriver.NewFileEntry.DetailsEmailAddress.FASetText(@"mail@mail.com" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Validated the data-1";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"EDITATTENTION123", FastDriver.NewFileEntry.DetailsEditName.FAGetValue().Clean());
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.DetailsSalesRep1.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.DetailsSalesRep2.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"REFERENCE12355555555555555555555555555555555555555", FastDriver.NewFileEntry.DetailsReference.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0081()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_5: Terms/Dates Section-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOfficer.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowAssisstant.FASelectItem(@"QA10, FAST");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem(@"Husband/Wife");
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText(@"Buyer2Firstname");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText(@"Buyer2Lastname");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText(@"Buyer2SpouseName");
                FastDriver.NewFileEntry.DetailsBuyerStreet1.FASetText(@"Address1");
                FastDriver.NewFileEntry.DetailsBuyerStreet2.FASendKeys(@"Address");
                FastDriver.NewFileEntry.DetailsBuyerStreet2.FASendKeys(@"2");
                FastDriver.NewFileEntry.DetailsBuyerStreet3.FASetText(@"Address3");
                FastDriver.NewFileEntry.DetailsBuyerStreet4.FASetText(@"Address4");
                FastDriver.NewFileEntry.DetailsBuyerCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsBuyerState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsBuyerZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsBuyerCounty.FASetText(@"Orange");
                FastDriver.NewFileEntry.DetailsBuyerBusPh.FASetText(@"(112)233-4455");
                FastDriver.NewFileEntry.DetailsBuyerCellFax.FASetText(@"(112)233-4455");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText(@"Seller2Firstname");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText(@"Seller2Lastname");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText(@"Seller2SpouseName");
                FastDriver.NewFileEntry.DetailsSellerStreet1.FASetText(@"Address1");
                FastDriver.NewFileEntry.DetailsSellerStreet2.FASetText(@"Address2");
                FastDriver.NewFileEntry.DetailsSellerStreet3.FASetText(@"Address3");
                FastDriver.NewFileEntry.DetailsSellerStreet4.FASetText(@"Address4");
                FastDriver.NewFileEntry.DetailsSellerCity.FASetText(@"santa ana");
                FastDriver.NewFileEntry.DetailsSellerCity.FASendKeys(@"CA");
                FastDriver.NewFileEntry.DetailsSellerZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsSellerCounty.FASetText(@"Orange");
                FastDriver.NewFileEntry.DetailsSellerBusPh.FASetText(@"(112)133-6666");
                FastDriver.NewFileEntry.DetailsSellerCellFax.FASetText(@"(112)133-6666");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText(@"1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText(@"PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText(@"PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText(@"PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText(@"Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText(@"92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASendKeys(@"Orange");
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Accommodation");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Enter 12 chars for SP";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                    FastDriver.NewFileEntry.DetailsSalePrice.Click();
                    Keyboard.SendKeys("{DEL}");
                    FastDriver.NewFileEntry.DetailsSalePrice.FASetText(@"11111111111111" + FAKeys.Tab);
                    FastDriver.WebDriver.HandleDialogMessage(true, false, timeout: 30);
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                    return FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue().Clean() == "?";
                });

                Reports.TestStep = "Enter 12 chars for liability and new loan liability amounts";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                    FastDriver.NewFileEntry.DetailsLiability.Click();
                    Keyboard.SendKeys("{DEL}");
                    FastDriver.NewFileEntry.DetailsLiability.FASetText(@"11111111111111" + FAKeys.Tab);
                    return FastDriver.NewFileEntry.DetailsLiability.FAGetValue().Clean() == "?";
                });
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                    FastDriver.NewFileEntry.DetailsFirstNewLoan.Click();
                    Keyboard.SendKeys("{DEL}");
                    FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText(@"11111111111111" + FAKeys.Tab);
                    return FastDriver.NewFileEntry.DetailsFirstNewLoan.FAGetValue().Clean() == "?";
                });
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                    FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.Click();
                    Keyboard.SendKeys("{DEL}");
                    FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.FASetText(@"11111111111111" + FAKeys.Tab);
                    return FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.FAGetValue().Clean() == "?";
                });
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                    FastDriver.NewFileEntry.DetailsSecondNewLoan.Click();
                    Keyboard.SendKeys("{DEL}");
                    FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText(@"11111111111111" + FAKeys.Tab);
                    return FastDriver.NewFileEntry.DetailsSecondNewLoan.FAGetValue().Clean() == "?";
                });
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                    FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.Click();
                    Keyboard.SendKeys("{DEL}");
                    FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.FASetText(@"11111111111111" + FAKeys.Tab);
                    return FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.FAGetValue().Clean() == "?";
                });

                Reports.TestStep = "Validate system has not accepted more than 11.2 chars.";
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue().Clean());
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsLiability.FAGetValue().Clean());
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsFirstNewLoan.FAGetValue().Clean());
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.FAGetValue().Clean());
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsSecondNewLoan.FAGetValue().Clean());
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0082()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_5_01: Terms/Dates Section-01";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order via New File Entry.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", transType: "Accommodation");

                Reports.TestStep = "Enter 9.2 chars for SP";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                    FastDriver.NewFileEntry.DetailsSalePrice.Click();
                    Keyboard.SendKeys("{DEL}");
                    FastDriver.NewFileEntry.DetailsSalePrice.FASetText(@"111,111,111.11" + FAKeys.Tab);
                    value = FastDriver.WebDriver.HandleDialogMessage(false, false).Clean();
                    FastDriver.WebDriver.HandleDialogMessage(true, false, 15);
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                    return FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue().Clean() == "111,111,111.11";
                });

                Reports.TestStep = "validate to recalculate the real estate broker commission after change the sales price in TDS screen.";
                Support.AreEqual(@"Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", value);

                Reports.TestStep = "Enter 9.2 chars for Liability";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsLiability.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsLiability.FASetText(@"111,111,111.11" + FAKeys.Tab);

                Reports.TestStep = "Enter 9.2 chars for loan amount";
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsFirstNewLoan.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText(@"111,111,111.11" + FAKeys.Tab);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Enter 9.2 chars for new loan liability amount";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.FASetText(@"111,111,111.11" + FAKeys.Tab);

                Reports.TestStep = "Enter 9.2 chars for second new loan amount.";
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsSecondNewLoan.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText(@"111,111,111.11" + FAKeys.Tab);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Enter 9.2 chars for second new loan liability amount";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.FASetText(@"111,111,111.11" + FAKeys.Tab);

                Reports.TestStep = "Validate system accepts 9.2 chars in TDS section";
                Support.AreEqual(@"111,111,111.11", FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue().Clean());
                Support.AreEqual(@"111,111,111.11", FastDriver.NewFileEntry.DetailsLiability.FAGetValue().Clean());
                Support.AreEqual(@"111,111,111.11", FastDriver.NewFileEntry.DetailsFirstNewLoan.FAGetValue().Clean());
                Support.AreEqual(@"111,111,111.11", FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.FAGetValue().Clean());
                Support.AreEqual(@"111,111,111.11", FastDriver.NewFileEntry.DetailsSecondNewLoan.FAGetValue().Clean());
                Support.AreEqual(@"111,111,111.11", FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0083()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var value = "";

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_5_02: Terms/Dates Section-02";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order via New File Entry.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", transType: "Accommodation");

                Reports.TestStep = "Enter 11chars for SP";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                    FastDriver.NewFileEntry.DetailsSalePrice.Click();
                    Keyboard.SendKeys("{DEL}");
                    FastDriver.NewFileEntry.DetailsSalePrice.FASetText(@"11111111111" + FAKeys.Tab);
                    value = FastDriver.WebDriver.HandleDialogMessage(false, false).Clean();
                    FastDriver.WebDriver.HandleDialogMessage(true, false, 15);
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                    return FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue().Clean() == "11,111,111,111.00";
                });

                Reports.TestStep = "validate to recalculate the real estate broker commission after change the sales price in TDS screen.";
                Support.AreEqual(@"Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", value);

                Reports.TestStep = "Enter 11 chars for Liability";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsLiability.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsLiability.FASetText(@"11111111111" + FAKeys.Tab);

                Reports.TestStep = "Enter 11  chars for loan amount";
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsFirstNewLoan.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText(@"11111111111" + FAKeys.Tab);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Enter 11 chars for new loan liability amount";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.FASetText(@"11111111111" + FAKeys.Tab);

                Reports.TestStep = "Enter 11 chars for second new loan amount.";
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsSecondNewLoan.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText(@"11111111111" + FAKeys.Tab);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Enter 11 chars for second new loan liability amount";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.FASetText(@"11111111111" + FAKeys.Tab);

                Reports.TestStep = "Validate system accepts 11chars in TDS section";
                Support.AreEqual(@"11,111,111,111.00", FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue().Clean());
                Support.AreEqual(@"11,111,111,111.00", FastDriver.NewFileEntry.DetailsLiability.FAGetValue().Clean());
                Support.AreEqual(@"11,111,111,111.00", FastDriver.NewFileEntry.DetailsFirstNewLoan.FAGetValue().Clean());
                Support.AreEqual(@"11,111,111,111.00", FastDriver.NewFileEntry.DetailsFirstNewLoanLiability.FAGetValue().Clean());
                Support.AreEqual(@"11,111,111,111.00", FastDriver.NewFileEntry.DetailsSecondNewLoan.FAGetValue().Clean());
                Support.AreEqual(@"11,111,111,111.00", FastDriver.NewFileEntry.DetailsSecondNewLoanLiability.FAGetValue().Clean());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0084()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_6: Buyer and Seller Address-Hus/Wife-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Enter data for a Pending file-Details Tab";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false);

                Reports.TestStep = "Click on Add Buyer and verify the types";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                Support.AreEqual(@"Individual Husband/Wife Trust/Estate Business Entity", FastDriver.NewFileEntry.DetailsBuyerType.Text ?? "");

                Reports.TestStep = "Enter buyer seller details for Hus/Wife";
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem(@"Husband/Wife");
                FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText(@"Buyer2Firstname20chr");
                FastDriver.NewFileEntry.DetailsBuyerHusbandMiddle.FASetText(@"Buyer2Middlename20ch");
                FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText(@"Buyer2Lastname20char");
                FastDriver.NewFileEntry.DetailsBuyerHusbandSuffix.FASetText(@"HUSBN");
                FastDriver.NewFileEntry.DetailsBuyerHusbandSSNTIN.FASetText(@"212-13-4444");
                FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText(@"Buyer2SpouseName20ch");
                FastDriver.NewFileEntry.DetailsBuyerSpouseMiddle.FASetText(@"Buyer2SpouseMDNamech");
                FastDriver.NewFileEntry.DetailsBuyerSpouseLast.FASetText(@"Buyer2Lastname20char");
                FastDriver.NewFileEntry.DetailsBuyerSpouseSuffix.FASetText(@"WIFEN");
                FastDriver.NewFileEntry.DetailsBuyerSpouseSSNTIN.FASetText(@"212-13-3322");
                FastDriver.NewFileEntry.DetailsBuyerStreet1.FASetText(@"Adress11wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww1");
                FastDriver.NewFileEntry.DetailsBuyerStreet2.FASetText(@"Adress22wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww2");
                FastDriver.NewFileEntry.DetailsBuyerStreet3.FASetText(@"Adress33wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww3");
                FastDriver.NewFileEntry.DetailsBuyerStreet4.FASetText(@"Adress44wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww4");
                FastDriver.NewFileEntry.DetailsBuyerCity.FASetText(@"santa ana");
                FastDriver.NewFileEntry.DetailsBuyerState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsBuyerZIP.FASetText(@"92606");
                FastDriver.NewFileEntry.DetailsBuyerCounty.FASetText(@"orange");
                FastDriver.NewFileEntry.DetailsBuyerBusPh.FASetText(@"(111)111-1111");
                FastDriver.NewFileEntry.BuyerPhExtn.FASetText(@"222");
                FastDriver.NewFileEntry.DetailsBuyerHomePh.FASetText(@"(111)111-1112");
                FastDriver.NewFileEntry.DetailsBuyerBusFax.FASetText(@"(111)111-1113");
                FastDriver.NewFileEntry.DetailsBuyerCellFax.FASetText(@"(111)111-1114");
                FastDriver.NewFileEntry.DetailsBuyerPager.FASetText(@"(111)111-1115");
                FastDriver.NewFileEntry.DetailsBuyerEmail.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem(@"Husband/Wife");
                FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText(@"Seller2Firstname20ch");
                FastDriver.NewFileEntry.DetailsSellerHusbandMiddle.FASetText(@"Seller2Middlename20c");
                FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText(@"Seller2Lastname20cha");
                FastDriver.NewFileEntry.DetailsSellerHusbandSuffix.FASetText(@"HUSBN");
                FastDriver.NewFileEntry.DetailsSellerHusbandSSNTIN.FASetText(@"212-13-4444");
                FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText(@"Seller2SpouseName20c");
                FastDriver.NewFileEntry.DetailsSellerSpouseMiddle.FASetText(@"Seller2SpouseMDNamec");
                FastDriver.NewFileEntry.DetailsSellerSpouseLast.FASetText(@"Seller2Lastname20cha");
                FastDriver.NewFileEntry.DetailsSelerSpouseSuffix.FASetText(@"WIFEN");
                FastDriver.NewFileEntry.DetailsSellerSpouseSSNTIN.FASetText(@"212-13-3322");
                FastDriver.NewFileEntry.DetailsSellerStreet1.FASetText(@"Adress11wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww1");
                FastDriver.NewFileEntry.DetailsSellerStreet2.FASetText(@"Adress22wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww2");
                FastDriver.NewFileEntry.DetailsSellerStreet3.FASetText(@"Adress33wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww3");
                FastDriver.NewFileEntry.DetailsSellerStreet4.FASetText(@"Adress44wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww4");
                FastDriver.NewFileEntry.DetailsSellerCity.FASetText(@"santa ana");
                FastDriver.NewFileEntry.DetailsSellerState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsSellerZIP.FASetText(@"92606");
                FastDriver.NewFileEntry.DetailsSellerCounty.FASetText(@"orange");
                FastDriver.NewFileEntry.DetailsSellerBusPh.FASetText(@"(111)111-1111");
                FastDriver.NewFileEntry.SellerPhExtn.FASetText(@"222");
                FastDriver.NewFileEntry.DetailsSellerHomePh.FASetText(@"(111)111-1112");
                FastDriver.NewFileEntry.DetailsSellerBusFax.FASetText(@"(111)111-1113");
                FastDriver.NewFileEntry.DetailsSellerCellFax.FASetText(@"(111)111-1114");
                FastDriver.NewFileEntry.DetailsSellerPager.FASetText(@"(111)111-1115");
                FastDriver.NewFileEntry.DetailsSellerEmail.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");

                Reports.TestStep = "Enter invalid email for buyer seller";
                FastDriver.NewFileEntry.DetailsBuyerEmail.FASetText(@"ggg" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsSellerEmail.FASetText(@"ggg" + FAKeys.Tab);

                Reports.TestStep = "Validate system doesnot accept invalid email";
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsBuyerEmail.FAGetValue().Clean());
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsSellerEmail.FAGetValue().Clean());

                Reports.TestStep = "Enter valid email for buyer seller";
                FastDriver.NewFileEntry.DetailsBuyerEmail.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.NewFileEntry.DetailsSellerEmail.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");

                Reports.TestStep = "Validate buyer and seller  details for Hus/Wife";
                Support.AreEqual(@"Husband/Wife", FastDriver.NewFileEntry.DetailsBuyerType.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Buyer2Firstname20chr", FastDriver.NewFileEntry.DetailsBuyerHusbandName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2Middlename20ch", FastDriver.NewFileEntry.DetailsBuyerHusbandMiddle.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2Lastname20char", FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FAGetValue().Clean());
                Support.AreEqual(@"HUSBN", FastDriver.NewFileEntry.DetailsBuyerHusbandSuffix.FAGetValue().Clean());
                Support.AreEqual(@"212-13-4444", FastDriver.NewFileEntry.DetailsBuyerHusbandSSNTIN.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2SpouseName20ch", FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2SpouseMDNamech", FastDriver.NewFileEntry.DetailsBuyerSpouseMiddle.FAGetValue().Clean());
                Support.AreEqual(@"Buyer2Lastname20char", FastDriver.NewFileEntry.DetailsBuyerSpouseLast.FAGetValue().Clean());
                Support.AreEqual(@"WIFEN", FastDriver.NewFileEntry.DetailsBuyerSpouseSuffix.FAGetValue().Clean());
                Support.AreEqual(@"212-13-3322", FastDriver.NewFileEntry.DetailsBuyerSpouseSSNTIN.FAGetValue().Clean());
                Support.AreEqual(@"Adress11wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww1", FastDriver.NewFileEntry.DetailsBuyerStreet1.FAGetValue().Clean());
                Support.AreEqual(@"Adress22wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww2", FastDriver.NewFileEntry.DetailsBuyerStreet2.FAGetValue().Clean());
                Support.AreEqual(@"Adress33wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww3", FastDriver.NewFileEntry.DetailsBuyerStreet3.FAGetValue().Clean());
                Support.AreEqual(@"Adress44wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww4", FastDriver.NewFileEntry.DetailsBuyerStreet4.FAGetValue().Clean());
                Support.AreEqual(@"santa ana", FastDriver.NewFileEntry.DetailsBuyerCity.FAGetValue().Clean());
                Support.AreEqual(@"CA", FastDriver.NewFileEntry.DetailsBuyerState.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"92606", FastDriver.NewFileEntry.DetailsBuyerZIP.FAGetValue().Clean());
                Support.AreEqual(@"orange", FastDriver.NewFileEntry.DetailsBuyerCounty.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1111", FastDriver.NewFileEntry.DetailsBuyerBusPh.FAGetValue().Clean());
                Support.AreEqual(@"222", FastDriver.NewFileEntry.BuyerPhExtn.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1112", FastDriver.NewFileEntry.DetailsBuyerHomePh.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1113", FastDriver.NewFileEntry.DetailsBuyerBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1114", FastDriver.NewFileEntry.DetailsBuyerCellFax.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1115", FastDriver.NewFileEntry.DetailsBuyerPager.FAGetValue().Clean());
                Support.AreEqual(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com", FastDriver.NewFileEntry.DetailsBuyerEmail.FAGetValue().Clean());
                Support.AreEqual(@"Husband/Wife", FastDriver.NewFileEntry.DetailsSellerType.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"Seller2Firstname20ch", FastDriver.NewFileEntry.DetailsSellerHusbandName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Middlename20c", FastDriver.NewFileEntry.DetailsSellerHusbandMiddle.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname20cha", FastDriver.NewFileEntry.DetailsSellerHusbandLast.FAGetValue().Clean());
                Support.AreEqual(@"HUSBN", FastDriver.NewFileEntry.DetailsSellerHusbandSuffix.FAGetValue().Clean());
                Support.AreEqual(@"212-13-4444", FastDriver.NewFileEntry.DetailsSellerHusbandSSNTIN.FAGetValue().Clean());
                Support.AreEqual(@"Seller2SpouseName20c", FastDriver.NewFileEntry.DetailsSellerSpouseName.FAGetValue().Clean());
                Support.AreEqual(@"Seller2SpouseMDNamec", FastDriver.NewFileEntry.DetailsSellerSpouseMiddle.FAGetValue().Clean());
                Support.AreEqual(@"Seller2Lastname20cha", FastDriver.NewFileEntry.DetailsSellerSpouseLast.FAGetValue().Clean());
                Support.AreEqual(@"WIFEN", FastDriver.NewFileEntry.DetailsSelerSpouseSuffix.FAGetValue().Clean());
                Support.AreEqual(@"212-13-3322", FastDriver.NewFileEntry.DetailsSellerSpouseSSNTIN.FAGetValue().Clean());
                Support.AreEqual(@"Adress11wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww1", FastDriver.NewFileEntry.DetailsSellerStreet1.FAGetValue().Clean());
                Support.AreEqual(@"Adress22wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww2", FastDriver.NewFileEntry.DetailsSellerStreet2.FAGetValue().Clean());
                Support.AreEqual(@"Adress33wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww3", FastDriver.NewFileEntry.DetailsSellerStreet3.FAGetValue().Clean());
                Support.AreEqual(@"Adress44wwwwwwwwwwwwwwwwwwwwwwwwwwwwwww4", FastDriver.NewFileEntry.DetailsSellerStreet4.FAGetValue().Clean());
                Support.AreEqual(@"santa ana", FastDriver.NewFileEntry.DetailsSellerCity.FAGetValue().Clean());
                Support.AreEqual(@"CA", FastDriver.NewFileEntry.DetailsSellerState.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"92606", FastDriver.NewFileEntry.DetailsSellerZIP.FAGetValue().Clean());
                Support.AreEqual(@"orange", FastDriver.NewFileEntry.DetailsSellerCounty.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1111", FastDriver.NewFileEntry.DetailsSellerBusPh.FAGetValue().Clean());
                Support.AreEqual(@"222", FastDriver.NewFileEntry.SellerPhExtn.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1112", FastDriver.NewFileEntry.DetailsSellerHomePh.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1113", FastDriver.NewFileEntry.DetailsSellerBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1114", FastDriver.NewFileEntry.DetailsSellerCellFax.FAGetValue().Clean());
                Support.AreEqual(@"(111)111-1115", FastDriver.NewFileEntry.DetailsSellerPager.FAGetValue().Clean());
                Support.AreEqual(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com", FastDriver.NewFileEntry.DetailsSellerEmail.FAGetValue().Clean());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0085()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_6_01: Buyer and Seller Address-Individual-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Enter data for a Pending file-Details Tab";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false);

                Reports.TestStep = "Enter buyer seller details for Individual type";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.IndBuyerF.FASetText(@"IndBuyerFirstName20c");
                FastDriver.NewFileEntry.IndBuyerM.FASetText(@"IndBuyerMiddlName20c");
                FastDriver.NewFileEntry.IndBuyerL.FASetText(@"IndBuyerLastName20ch");
                FastDriver.NewFileEntry.IndBuyerSuffix.FASetText(@"BINDV");
                FastDriver.NewFileEntry.IndBuyerSSNTIN.FASetText(@"212-13-4444");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem(@"Individual");
                FastDriver.NewFileEntry.IndSellerF.FASetText(@"IndSellerFirstName20");
                FastDriver.NewFileEntry.IndSellerM.FASetText(@"IndSellerMiddlName20");
                FastDriver.NewFileEntry.IndSellerL.FASetText(@"IndSellerLastName20c");
                FastDriver.NewFileEntry.IndSellerSuffix.FASetText(@"BINDV");
                FastDriver.NewFileEntry.IndSellerSSNTIN.FASetText(@"212-13-4444");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Higlight Individual buyer";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction(3, "Individual", 3, TableAction.Click);

                Reports.TestStep = "Verify buyer details for Individual type";
                Support.AreEqual(@"IndBuyerFirstName20c", FastDriver.NewFileEntry.IndBuyerF.FAGetValue().Clean());
                Support.AreEqual(@"IndBuyerMiddlName20c", FastDriver.NewFileEntry.IndBuyerM.FAGetValue().Clean());
                Support.AreEqual(@"IndBuyerLastName20ch", FastDriver.NewFileEntry.IndBuyerL.FAGetValue().Clean());
                Support.AreEqual(@"BINDV", FastDriver.NewFileEntry.IndBuyerSuffix.FAGetValue().Clean());
                Support.AreEqual(@"212-13-4444", FastDriver.NewFileEntry.IndBuyerSSNTIN.FAGetValue().Clean());

                Reports.TestStep = "Higlight Individual seller";
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction(3, "Individual", 3, TableAction.Click);

                Reports.TestStep = "Verify seller details for Individual type";
                Support.AreEqual(@"IndSellerFirstName20", FastDriver.NewFileEntry.IndSellerF.FAGetValue().Clean());
                Support.AreEqual(@"IndSellerMiddlName20", FastDriver.NewFileEntry.IndSellerM.FAGetValue().Clean());
                Support.AreEqual(@"IndSellerLastName20c", FastDriver.NewFileEntry.IndSellerL.FAGetValue().Clean());
                Support.AreEqual(@"BINDV", FastDriver.NewFileEntry.IndSellerSuffix.FAGetValue().Clean());
                Support.AreEqual(@"212-13-4444", FastDriver.NewFileEntry.IndSellerSSNTIN.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0086()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_6_02: Buyer and Seller Address-Trust/Estate-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Enter data for a Pending file-Details Tab";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false);

                Reports.TestStep = "Enter buyer seller details for Trust/Estate type";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem(@"Trust/Estate");
                FastDriver.NewFileEntry.TrustBuyer.FASetText(@"TSTBuyerFirstName20c");
                FastDriver.NewFileEntry.TrustBuyerSSNTIN.FASetText(@"212-13-4444");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem(@"Trust/Estate");
                FastDriver.NewFileEntry.TrustSeller.FASetText(@"TSTSellrFirstName20c");
                FastDriver.NewFileEntry.TrustSellerSSNTIN.FASetText(@"212-13-4444");
                FastDriver.NewFileEntry.TrustLastNameFor1099_S.FASetText(@"TSTSellrLastName20c");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Higlight Individual buyer Trust";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction(3, "Trust/Estate", 3, TableAction.Click);

                Reports.TestStep = "Verify buyer details for Trust/Estate type";
                Support.AreEqual(@"TSTBuyerFirstName20c", FastDriver.NewFileEntry.TrustBuyer.FAGetValue().Clean());
                Support.AreEqual(@"212-13-4444", FastDriver.NewFileEntry.TrustBuyerSSNTIN.FAGetValue().Clean());

                Reports.TestStep = "Higlight Individual seller Trust";
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction(3, "Trust/Estate", 3, TableAction.Click);

                Reports.TestStep = "Verify seller details for Trust/Estate type";
                Support.AreEqual(@"TSTSellrFirstName20c", FastDriver.NewFileEntry.TrustSeller.FAGetValue().Clean());
                Support.AreEqual(@"212-13-4444", FastDriver.NewFileEntry.TrustSellerSSNTIN.FAGetValue().Clean());
                Support.AreEqual(@"TSTSellrLastName20c", FastDriver.NewFileEntry.TrustLastNameFor1099_S.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0087()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_6_03: Buyer and Seller Address-Business Entity-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Enter data for a Pending file-Details Tab";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false);

                Reports.TestStep = "Enter buyer seller details for Business Entity type";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem(@"Business Entity");
                FastDriver.NewFileEntry.TrustBuyer.FASetText(@"BENBuyerFirstName20c");
                FastDriver.NewFileEntry.TrustBuyerSSNTIN.FASetText(@"11-1111222");
                FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
                FastDriver.NewFileEntry.DetailsSellerType.FASelectItem(@"Business Entity");
                FastDriver.NewFileEntry.TrustSeller.FASetText(@"BENSellrFirstName20c");
                FastDriver.NewFileEntry.TrustSellerSSNTIN.FASetText(@"11-1111222");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Higlight Individual buyer Business Entity type";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.BuyerSummary.PerformTableAction(3, "Business Entity", 3, TableAction.Click);

                Reports.TestStep = "Verify buyer details for Business Entity type";
                Support.AreEqual(@"BENBuyerFirstName20c", FastDriver.NewFileEntry.TrustBuyer.FAGetValue().Clean());
                Support.AreEqual(@"11-1111222", FastDriver.NewFileEntry.TrustBuyerSSNTIN.FAGetValue().Clean());

                Reports.TestStep = "Higlight Individual seller Business Entity type";
                FastDriver.NewFileEntry.SellerSummary.PerformTableAction(3, "Business Entity", 3, TableAction.Click);

                Reports.TestStep = "Verify seller details for Business Entity type";
                Support.AreEqual(@"BENSellrFirstName20c", FastDriver.NewFileEntry.TrustSeller.FAGetValue().Clean());
                Support.AreEqual(@"11-1111222", FastDriver.NewFileEntry.TrustSellerSSNTIN.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0088()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_7: Property Section-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create basic order.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false);

                Reports.TestStep = "Enter max characters of 40 for property section";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText(@"1 First American Way1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText(@"PropertyStreet2PropertyStreet2PropertySt");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText(@"PropertyStreet3PropertyStreet3PropertySt");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText(@"PropertyStreet4PropertyStreet4PropertySt");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate max characters for property section(35 chars)";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                //Support.AreEqual(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other",
                //    FastDriver.NewFileEntry.DetailsPropertyType.Text.Clean());
                Support.AreEqual(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", FastDriver.NewFileEntry.DetailsPropertyType.Text.Clean());
                Support.AreEqual(@"1 First American Way1 First America", FastDriver.NewFileEntry.DetailsPropertyStreet1.FAGetValue().Clean());
                Support.AreEqual(@"PropertyStreet2PropertyStreet2Prope", FastDriver.NewFileEntry.DetailsPropertyStreet2.FAGetValue().Clean());
                Support.AreEqual(@"PropertyStreet3PropertyStreet3Prope", FastDriver.NewFileEntry.DetailsPropertyStreet3.FAGetValue().Clean());
                Support.AreEqual(@"PropertyStreet4PropertyStreet4Prope", FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0089()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_8: Directed By Section-Parties Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create basic order.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Outside Escrow Company", saveFile: false);

                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Validating max of 10 chars for DirectedBy GAbCode";
                FastDriver.NewFileEntry.FindDirectedByGAB(@"HUDFLINSR1");

                Reports.TestStep = "Validating max of 40 chars for DirectedBy Name";
                FastDriver.NewFileEntry.PartiesDirectedByName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.PartiesDirectedByFind.FAClick();
                Support.AreEqual(@"HUDFLINSR1", FastDriver.NewFileEntry.PartiesGcode1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1", FastDriver.NewFileEntry.PartiesName1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 2", FastDriver.NewFileEntry.PartiesName2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 1, Fire Insurance 1 business street 2", FastDriver.NewFileEntry.PartiesAddress1.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 3, Fire Insurance 1 business street 4", FastDriver.NewFileEntry.PartiesAddress2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business city, NY, 74081-6545, USA", FastDriver.NewFileEntry.PartiesAddress3.FAGetText().Clean());
                FastDriver.NewFileEntry.PartiesDirectedByEditContact.FASetCheckbox(true);
                FastDriver.NewFileEntry.PartiesDirectedByBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesDirectedByBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesDirectedByCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesDirectedByPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesDirectedByEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.NewFileEntry.PartiesDirectedBySalesRep1.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.PartiesDirectedBySalesRep2.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.PartiesDirectedByReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASelectItem(@"Seller's Broker");
                Support.AreEqual(@"0.0000", FastDriver.NewFileEntry.PartiesDirectedByPercent.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.NewFileEntry.PartiEstimatedDirectedByAmount.FAGetValue().Clean());

                Reports.TestStep = "Enter more than 9 chars for Commision% and 11.2 chars for $.";
                FastDriver.NewFileEntry.PartiesGcode1.Click();
                FastDriver.NewFileEntry.PartiesDirectedByPercent.FASetText(@"999999999");
                FastDriver.NewFileEntry.PartiEstimatedDirectedByAmount.FASetText(@"11111111111" + FAKeys.Tab);

                Reports.TestStep = "Validate more than 9 chars for Commision% and 11.2 chars for $.";
                Support.AreEqual(@"?", FastDriver.NewFileEntry.PartiesDirectedByPercent.FAGetValue().Clean());
                Support.AreEqual(@"11,111,111,111.00", FastDriver.NewFileEntry.PartiEstimatedDirectedByAmount.FAGetValue().Clean());

                Reports.TestStep = "Enter 9999.9999 chars for Commision% and 10.2 chars for $.";
                FastDriver.NewFileEntry.PartiesGcode1.Click();
                FastDriver.NewFileEntry.PartiesDirectedByPercent.FASetText(@"9999.9999");
                FastDriver.NewFileEntry.PartiEstimatedDirectedByAmount.FASetText(@"1111111111" + FAKeys.Tab);

                Reports.TestStep = "Validate 9999.9999 chars for Commision% and 10.2 chars for $.";
                Support.AreEqual(@"9999.9999", FastDriver.NewFileEntry.PartiesDirectedByPercent.FAGetValue().Clean());
                Support.AreEqual(@"1,111,111,111.00", FastDriver.NewFileEntry.PartiEstimatedDirectedByAmount.FAGetValue().Clean());

                Reports.TestStep = "Enter 999.9999 chars for Commision% and 9.2 chars for $.";
                FastDriver.NewFileEntry.PartiesGcode1.Click();
                FastDriver.NewFileEntry.PartiesDirectedByPercent.FASetText(@"999.0999");
                FastDriver.NewFileEntry.PartiEstimatedDirectedByAmount.FASetText(@"111111111.9" + FAKeys.Tab);

                Reports.TestStep = "Validate 9999.9999 chars for Commision% and 9.2 chars for $.";
                Support.AreEqual(@"999.0999", FastDriver.NewFileEntry.PartiesDirectedByPercent.FAGetValue().Clean());
                Support.AreEqual(@"111,111,111.90", FastDriver.NewFileEntry.PartiEstimatedDirectedByAmount.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0090()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_9: Associated By Section-Parties Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create basic order.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Outside Escrow Company", saveFile: false);

                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Validating max of 10 chars for DirectedBy GAbCode";
                FastDriver.NewFileEntry.FindDirectedByGAB(@"HUDFLINSR1");

                Reports.TestStep = "Validating max of 40 chars for DirectedBy Name";
                FastDriver.NewFileEntry.PartiesDirectedByName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.PartiesDirectedByFind.FAClick();
                Support.AreEqual(@"HUDFLINSR1", FastDriver.NewFileEntry.PartiesGcode1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1", FastDriver.NewFileEntry.PartiesName1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 2", FastDriver.NewFileEntry.PartiesName2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 1, Fire Insurance 1 business street 2", FastDriver.NewFileEntry.PartiesAddress1.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 3, Fire Insurance 1 business street 4", FastDriver.NewFileEntry.PartiesAddress2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business city, NY, 74081-6545, USA", FastDriver.NewFileEntry.PartiesAddress3.FAGetText().Clean());
                FastDriver.NewFileEntry.PartiesDirectedByEditContact.FASetCheckbox(true);
                FastDriver.NewFileEntry.PartiesDirectedByBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesDirectedByBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesDirectedByCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesDirectedByPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesDirectedByEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.NewFileEntry.PartiesDirectedBySalesRep1.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.PartiesDirectedBySalesRep2.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.PartiesDirectedByReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");
                FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FASelectItem(@"Seller's Broker");
                Support.AreEqual(@"0.0000", FastDriver.NewFileEntry.PartiesDirectedByPercent.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.NewFileEntry.PartiEstimatedDirectedByAmount.FAGetValue().Clean());

                Reports.TestStep = "Validating max of 40 chars for  Associated Bus Party  Name";
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyFind.FAClick();
                Support.AreEqual(@"HUDFLINSR1", FastDriver.NewFileEntry.AssociatedPartiesGcode1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1", FastDriver.NewFileEntry.AssociatedPartiesName1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 2", FastDriver.NewFileEntry.AssociatedPartiesName2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 1, Fire Insurance 1 business street 2", FastDriver.NewFileEntry.AssociatedPartiesAddress1.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 3, Fire Insurance 1 business street 4", FastDriver.NewFileEntry.AssociatedPartiesAddress2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business city, NY, 74081-6545, USA", FastDriver.NewFileEntry.AssociatedPartiesAddress3.FAGetText().Clean());
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyEditcont.FASetCheckbox(true);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartySalesRep1.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartySalesRep2.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddtionalRole.FASelectItem(@"Seller's Broker");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual(@"0.0000", FastDriver.NewFileEntry.PartiesAssociatedBusPartyPercent.FAGetValue().Clean());
                Support.AreEqual(@"0.00", FastDriver.NewFileEntry.PartiesAssociatedBusPartyAmount.FAGetValue().Clean());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Validate the data entered for parties tab";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PartiesDirectedByBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PartiesDirectedByBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PartiesDirectedByCellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PartiesDirectedByPager.FAGetValue().Clean());
                Support.AreEqual(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com", FastDriver.NewFileEntry.PartiesDirectedByEmailAddress.FAGetValue().Clean());
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.PartiesDirectedBySalesRep1.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.PartiesDirectedBySalesRep2.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"REFERENCE12355555555555555555555555555555555555555", FastDriver.NewFileEntry.PartiesDirectedByReference.FAGetValue().Clean());
                Support.AreEqual(@"Seller's Broker", FastDriver.NewFileEntry.PartiesDirectedByAddtionalRole.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PartiesAssociatedBusPartyBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PartiesAssociatedBusPartyBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PartiesAssociatedBusPartyCellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PartiesAssociatedBusPartyPager.FAGetValue().Clean());
                Support.AreEqual(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com", FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddress.FAGetValue().Clean());
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.PartiesAssociatedBusPartySalesRep1.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.PartiesAssociatedBusPartySalesRep2.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"REFERENCE12355555555555555555555555555555555555555", FastDriver.NewFileEntry.PartiesAssociatedBusPartyReference.FAGetValue().Clean());
                Support.AreEqual(@"Seller's Broker", FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddtionalRole.FAGetSelectedItem() ?? "");

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0091()
        {
            try
            {
                Reports.TestDescription = "FD_9_01: Directed By and Associated By Section-Parties Tab";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                // #region UI Interaction

                Reports.TestDescription = "FD_9: Associated By Section-Parties Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create basic order.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Outside Escrow Company", saveFile: false);

                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Validating max of 10 chars for DirectedBy GAbCode";
                FastDriver.NewFileEntry.FindDirectedByGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.FindAssociatedBusinessPartyGAB(@"HUDFLINSR1");

                //
                Reports.TestStep = "Enter invalid email for Directed By and Associated Bus Party";
                FastDriver.NewFileEntry.PartiesDirectedByEditContact.FASetCheckbox(true);
                FastDriver.NewFileEntry.PartiesDirectedByEmailAddress.FASetText("eee");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyEditcont.FASetCheckbox(true);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddress.FASetText("eee" + FAKeys.Tab);

                //
                Reports.TestStep = "Validate system doesnot accept invalid email for Directed By and Associated Bus Party";
                Support.AreEqual("?", FastDriver.NewFileEntry.PartiesDirectedByEmailAddress.FAGetValue());
                Support.AreEqual("?", FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddress.FAGetValue());

                //
                Reports.TestStep = "Enter valid email for Directed By and Associated Bus Party";
                FastDriver.NewFileEntry.PartiesDirectedByEmailAddress.FASetText("qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAddress.FASetText("qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");

                //
                Reports.TestStep = "Select Attention and name details for Directed By and Associated Bus Party";
                FastDriver.NewFileEntry.PartiesDirectedByAttention.FASelectItem("Contact, Flood Insurance 1");
                FastDriver.NewFileEntry.PartiesDirectedByEdit.FASetCheckbox(true);
                FastDriver.NewFileEntry.PartiesDirectedByEditName.FASetText("EDITATTENTION123");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyAttention.FASelectItem("Contact, Flood Insurance 1");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyEdit.FASetCheckbox(true);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyEditName.FASetText("EDITATTENTION123");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                //
                Reports.TestStep = "Navigate to Parties tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                //
                Reports.TestStep = "Validate Attention and Anme details for Directed By and Associated Bus Party";
                Support.AreEqual("0", FastDriver.NewFileEntry.PartiesDirectedByAttention.FAGetSelectedIndex().ToString());
                Support.AreEqual("True", FastDriver.NewFileEntry.PartiesDirectedByEdit.Selected.ToString());
                Support.AreEqual("EDITATTENTION123", FastDriver.NewFileEntry.PartiesDirectedByEditName.FAGetValue());
                Support.AreEqual("0", FastDriver.NewFileEntry.PartiesAssociatedBusPartyAttention.FAGetSelectedIndex().ToString());
                Support.AreEqual("True", FastDriver.NewFileEntry.PartiesAssociatedBusPartyEdit.Selected.ToString());
                Support.AreEqual("EDITATTENTION123", FastDriver.NewFileEntry.PartiesAssociatedBusPartyEditName.FAGetValue());
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0092()
        {
            try
            {
                Reports.TestDescription = "FD_10: Properties Tab";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                // #region UI Interaction

                Reports.TestDescription = "FD_9: Associated By Section-Parties Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Enter data for Properties address and validate the default field values";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Outside Escrow Company", saveFile: false);
                //Playback.Wait(100000000);
                //
                Reports.TestStep = "Navigate to Property Info tab.";
                FastDriver.NewFileEntry.PropertyInfoPropertyInfo.FAClick();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                 {
                     return FastDriver.NewFileEntry.PropertyInfoPropertyStreet1.IsDisplayed();
                 }, timeout: 220, idleInterval: 5);
                Playback.Wait(3000);
                FastDriver.NewFileEntry.PropertyInfoPropertyStreet1.FASetText("1 First American Way1 First American Way");
                FastDriver.NewFileEntry.PropertyInfoPropertyStreet2.FASetText("PropertyStreet2PropertyStreet2PropertySt");
                FastDriver.NewFileEntry.PropertyInfoPropertyStreet3.FASetText("PropertyStreet3PropertyStreet3PropertySt");
                FastDriver.NewFileEntry.PropertyInfoPropertyStreet4.FASetText("PropertyStreet4PropertyStreet4PropertySt");
                FastDriver.NewFileEntry.PropertyInfoPropertyCity.FASetText("santa ana");
                FastDriver.NewFileEntry.PropertyInfoPropertyState.FASelectItem("CA");
                FastDriver.NewFileEntry.PropertyInfoPropertyZIP.FASetText("92707");
                FastDriver.NewFileEntry.PropertyInfoPropertyCounty.FASelectItem("Orange");

                //Support.AreEqual("Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", FastDriver.NewFileEntry.PropertyInfoPropertyType.FAGetText().Clean());
                Support.AreEqual("Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", FastDriver.NewFileEntry.PropertyInfoPropertyType.FAGetText().Clean());

                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoLot.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoBlock.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoUnit.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoTrack.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoFee.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoBuilding.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoBook.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoPage.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoSection.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoTownShip.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoRange.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.NewFileEntry.PropertyInfoParcel.FAGetValue().Clean());

                //
                Reports.TestStep = "Enter data for Properties section";
                FastDriver.NewFileEntry.PropertyInfoNewFileEntryAPNTMK.FASetText("APN11TMK2APN11TMK2APN11TMK2APN11TMK2APN11TMK2");
                FastDriver.NewFileEntry.PropertyInfoPropertyType.FASelectItem("Single Family Residence");
                FastDriver.NewFileEntry.PropertyInfoLot.FASetText("Lot1Lot2Lot1Lot2Lot1Lot2Lot1Lot2Lot1Lot2Lot1Lot211");
                FastDriver.NewFileEntry.PropertyInfoBlock.FASetText("Block1Block2Block1Block2Block1Block21122");
                FastDriver.NewFileEntry.PropertyInfoUnit.FASetText("Unit1Unit2Unit1Unit2Unit1Unit2Unit1Unit2");
                FastDriver.NewFileEntry.PropertyInfoTrack.FASetText("Tract1Tract2Tract1Tract2Tract1Tract2Trac");
                FastDriver.NewFileEntry.PropertyInfoFee.FASetText("Fee1Fee2Fee1Fee2Fee1Fee2Fee1Fee2Fee1Fee2");
                FastDriver.NewFileEntry.PropertyInfoBuilding.FASetText("Building1Building2Building1Building2Buil");
                FastDriver.NewFileEntry.PropertyInfoPage.FASetText("Page1Page1Page1Page1Page1Page1Page1Page1");
                FastDriver.NewFileEntry.PropertyInfoBook.FASetText("Book1Book2Book1Book2");
                FastDriver.NewFileEntry.PropertyInfoSection.FASetText("Section1Section2Section1Section2Section1");
                FastDriver.NewFileEntry.PropertyInfoTownShip.FASetText("Township1Township2Township1Township2Town");
                FastDriver.NewFileEntry.PropertyInfoRange.FASetText("Range1Range2Range1Range2Range1Range2Rang");
                FastDriver.NewFileEntry.PropertyInfoParcel.FASetText("Parcel1Parcel2Parcel1Parcel2Parcel1Parce");
                FastDriver.NewFileEntry.PropertyInfoSubDivisionCondominium.FASetText("Upon initial entry onto FAST, the options available in the FASTNav menu may be My FAST Today, File Search, Reserve File Number, New File Entry, Quick File Entry, and Quick Refi Entry. After a new file is created or an existing file has been opened, additional options become available.");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Validate message for extra chars in Subdivision/Condominium";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyType);
                Support.AreEqual("Real Property: SubDivision Name can have maximum of 255 characters", FastDriver.NewFileEntry.MessagePane.FAGetText());
                FastDriver.NewFileEntry.PropertyInfoSubDivisionCondominium.FASetText("Upon initial entry onto FAST, the options available in the FASTNav menu may be My FAST Today, File Search, Reserve File Number, New File Entry, Quick File Entry, and Quick Refi Entry. After a new file is created or an existing file has been opened, additi");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                //
                Reports.TestStep = "Navigate to Property Info tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.PropertyInfoPropertyInfo.FAClick();

                //
                Reports.TestStep = "Validate the field limit for all controls in Property tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyType);
                Support.AreEqual("Single Family Residence", FastDriver.NewFileEntry.PropertyInfoPropertyType.FAGetSelectedItem());
                Support.AreEqual("APN11TMK2APN11TMK2APN11TMK2APN11TMK2APN11TMK2", FastDriver.NewFileEntry.PropertyInfoNewFileEntryAPNTMK.FAGetValue());
                Support.AreEqual("1 First American Way1 First America", FastDriver.NewFileEntry.PropertyInfoPropertyStreet1.FAGetValue());
                Support.AreEqual("PropertyStreet2PropertyStreet2Prope", FastDriver.NewFileEntry.PropertyInfoPropertyStreet2.FAGetValue());
                Support.AreEqual("PropertyStreet3PropertyStreet3Prope", FastDriver.NewFileEntry.PropertyInfoPropertyStreet3.FAGetValue());
                Support.AreEqual("PropertyStreet4PropertyStreet4Prope", FastDriver.NewFileEntry.PropertyInfoPropertyStreet4.FAGetValue());
                Support.AreEqual("CA", FastDriver.NewFileEntry.PropertyInfoPropertyState.FAGetSelectedItem());
                Support.AreEqual("92707", FastDriver.NewFileEntry.PropertyInfoPropertyZIP.FAGetValue());
                Support.AreEqual("Orange", FastDriver.NewFileEntry.PropertyInfoPropertyCounty.FAGetSelectedItem());
                Support.AreEqual("Lot1Lot2Lot1Lot2Lot1Lot2Lot1Lot2Lot1Lot2Lot1Lot211", FastDriver.NewFileEntry.PropertyInfoLot.FAGetValue());
                Support.AreEqual("Tract1Tract2Tract1Tr", FastDriver.NewFileEntry.PropertyInfoTrack.FAGetValue());
                Support.AreEqual("Fee1Fee2Fee1Fee2Fee1", FastDriver.NewFileEntry.PropertyInfoFee.FAGetValue());
                Support.AreEqual("Building1Building2Bu", FastDriver.NewFileEntry.PropertyInfoBuilding.FAGetValue());
                Support.AreEqual("Book1Book2Book1Book2", FastDriver.NewFileEntry.PropertyInfoBook.FAGetValue());
                Support.AreEqual("Page1Page1", FastDriver.NewFileEntry.PropertyInfoPage.FAGetValue());
                Support.AreEqual("Section1Section2Sect", FastDriver.NewFileEntry.PropertyInfoSection.FAGetValue());
                Support.AreEqual("Township1Township2To", FastDriver.NewFileEntry.PropertyInfoTownShip.FAGetValue());
                Support.AreEqual("Range1Range2Range1Ra", FastDriver.NewFileEntry.PropertyInfoRange.FAGetValue());
                Support.AreEqual("Parcel1Parcel2Parcel1Parcel2Pa", FastDriver.NewFileEntry.PropertyInfoParcel.FAGetValue());
                Support.AreEqual("Upon initial entry onto FAST, the options available in the FASTNav menu may be My FAST Today, File Search, Reserve File Number, New File Entry, Quick File Entry, and Quick Refi Entry. After a new file is created or an existing file has been opened, additi", FastDriver.NewFileEntry.PropertyInfoSubDivisionCondominium.FAGetValue());
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0093()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_11: Lenders/Mortgage Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry and create a File.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(buyer: false, seller: false);

                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnLenderMortgageBrokerTab();

                Reports.TestStep = "Select new lender and enter all details";
                FastDriver.NewFileEntry.FindLenderMortgageBrokerGAB("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();
                Support.AreEqual(@"HUDFLINSR1", FastDriver.NewFileEntry.NewLenderGcode1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1", FastDriver.NewFileEntry.NewLenderName1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 2", FastDriver.NewFileEntry.NewLenderName2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 1, Fire Insurance 1 business street 2", FastDriver.NewFileEntry.NewLenderAddress1.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 3, Fire Insurance 1 business street 4", FastDriver.NewFileEntry.NewLenderAddress2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business city, NY, 74081-6545, USA", FastDriver.NewFileEntry.NewLenderAddress3.FAGetText().Clean());
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEditContact.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                Support.AreEqual(false, FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEmailStatus.Selected, "Verify whether 'LenderMortgageBrokersNewLenderEmailStatus' checkbox is unchecked.");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderSalesRep1.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderSalesRep2.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");

                Reports.TestStep = "Click on AddNew in Payoff section.";
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderAddNew.FAClick();

                Reports.TestStep = "Enter details for Pay off lender";
                FastDriver.NewFileEntry.FindLenderMortgageBrokersPayoffLenderGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderFind.FAClick();
                Support.AreEqual(@"HUDFLINSR1", FastDriver.NewFileEntry.PayOffGcode1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1", FastDriver.NewFileEntry.PayOffName1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 2", FastDriver.NewFileEntry.PayOffName2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 1, Fire Insurance 1 business street 2", FastDriver.NewFileEntry.PayOffAddress1.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 3, Fire Insurance 1 business street 4", FastDriver.NewFileEntry.PayOffAddress2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business city, NY, 74081-6545, USA", FastDriver.NewFileEntry.PayOffAddress3.FAGetText().Clean());
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEditCont.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                Support.AreEqual(false, FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEmailStatus.Selected, "Verify whether 'LenderMortgageBrokersPayOfficeLenderEmailStatus' checkbox is unchecked.");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");

                Reports.TestStep = "Enter details for Mortgage Broker";
                FastDriver.NewFileEntry.FindLenderMortgageBrokersMortagageBrokerDetailsGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();
                Support.AreEqual(@"HUDFLINSR1", FastDriver.NewFileEntry.MBGcode1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1", FastDriver.NewFileEntry.MBName1.FAGetText().Clean());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 2", FastDriver.NewFileEntry.MBName2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 1, Fire Insurance 1 business street 2", FastDriver.NewFileEntry.MBAddress1.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business street 3, Fire Insurance 1 business street 4", FastDriver.NewFileEntry.MBAddress2.FAGetText().Clean());
                Support.AreEqual(@"Fire Insurance 1 business city, NY, 74081-6545, USA", FastDriver.NewFileEntry.MBAddress3.FAGetText().Clean());
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEditcont.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                Support.AreEqual(false, FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEmailStatus.Selected, "Verify whether 'LenderMortgageBrokersMortgageBrokerEmailStatus' checkbox is unchecked.");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerSalesRep1.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerSalesRep2.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnLenderMortgageBrokerTab();

                Reports.TestStep = "Validate NewLender Table data-1";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate NewLender Table data-2";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 5, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate NewLender Table data-3";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 5, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate new lender details";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderCellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderPager.FAGetValue().Clean());
                Support.AreEqual(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEmailAddress.FAGetValue().Clean());
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderSalesRep1.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderSalesRep2.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"REFERENCE12355555555555555555555555555555555555555", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderReference.FAGetValue().Clean());

                Reports.TestStep = "Validate PayoffLender Table data-1";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PayOffSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate PayoffLender Table data-2";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PayOffSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 5, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate PayoffLender Table data-3";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.PayOffSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 5, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate details for Pay off lender";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderCellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderPager.FAGetValue().Clean());
                Support.AreEqual(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com", FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEmailAddress.FAGetValue().Clean());
                Support.AreEqual(@"REFERENCE12355555555555555555555555555555555555555", FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderReference.FAGetValue().Clean());

                Reports.TestStep = "Validate Mortgage Broker Table data-1";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate Mortgage Broker Table data-2";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 5, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate Mortgage Broker Table data-3";
                Support.AreEqual(@"Fire Insurance 1 business street 1, Fire Insurance 1 business street 2", FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 3, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate details for Mortgage Broker";
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerBusPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerBusFax.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerCellPhone.FAGetValue().Clean());
                Support.AreEqual(@"(745)451-9999", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerPager.FAGetValue().Clean());
                Support.AreEqual(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEmailAddress.FAGetValue().Clean());
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerSalesRep1.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"QA10, FAST", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerSalesRep2.FAGetSelectedItem() ?? "");
                Support.AreEqual(@"REFERENCE12355555555555555555555555555555555555555", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerReference.FAGetValue().Clean());

                Reports.TestStep = "Enter Attention and Name Details";
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderAttention.FASelectItem(@"Contact, Flood Insurance 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersEditName.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLendertextName.FASetText(@"EDITATTENTION123");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderAttention.FASelectItem(@"Contact, Flood Insurance 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEditName.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLendertextName.FASetText(@"EDITATTENTION123");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerAttention.FASelectItem(@"Contact, Flood Insurance 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEditName.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokertextName.FASetText(@"EDITATTENTION123");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnLenderMortgageBrokerTab();

                Reports.TestStep = "Validate Attention and Name Details";
                Support.AreEqual(@"0", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderAttention.FAGetSelectedIndex().ToString() ?? "", "Verify whether 'LenderMortgageBrokersNewLenderAttention' dropdown has index '0' selected.");
                Support.AreEqual(true, FastDriver.NewFileEntry.LenderMortgageBrokersEditName.Selected, "Verify whether 'LenderMortgageBrokersEditName' checkbox is checked.");
                Support.AreEqual(@"EDITATTENTION123", FastDriver.NewFileEntry.LenderMortgageBrokersNewLendertextName.FAGetValue().Clean());
                Support.AreEqual(@"0", FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderAttention.FAGetSelectedIndex().ToString() ?? "", "Verify whether 'LenderMortgageBrokersPayOfficeLenderAttention' dropdown has index '0' selected.");
                Support.AreEqual(true, FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEditName.Selected, "Verify whether 'LenderMortgageBrokersPayOfficeLenderEditName' checkbox is checked.");
                Support.AreEqual(@"EDITATTENTION123", FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLendertextName.FAGetValue().Clean());
                Support.AreEqual(@"0", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerAttention.FAGetSelectedIndex().ToString() ?? "", "Verify whether 'LenderMortgageBrokersMortgageBrokerAttention' dropdown has index '0' selected.");
                Support.AreEqual(true, FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEditName.Selected, "Verify whether 'LenderMortgageBrokersMortgageBrokerEditName' checkbox is checked.");
                Support.AreEqual(@"EDITATTENTION123", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokertextName.FAGetValue().Clean());

                Reports.TestStep = "Enter invalid email for Lender section Bus parties";
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEditContact.FASetCheckbox(true);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEmailAddress);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEmailAddress.FASetText(@"eee" + FAKeys.Tab);
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEditCont.FASetCheckbox(true);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEmailAddress);
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEmailAddress.FASetText(@"eee" + FAKeys.Tab);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEditcont.FASetCheckbox(true);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEmailAddress);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEmailAddress.FASetText(@"eee" + FAKeys.Tab);

                Reports.TestStep = "validate invalid email for Lender section Bus parties";
                Support.AreEqual(@"?", FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEmailAddress.FAGetValue().Clean());
                Support.AreEqual(@"?", FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEmailAddress.FAGetValue().Clean());
                Support.AreEqual(@"?", FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEmailAddress.FAGetValue().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0094()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_11_01: Lenders/Mortgage Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry and create a File.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(buyer: false, seller: false);

                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnLenderMortgageBrokerTab();

                Reports.TestStep = "Select new lender and enter all details";
                FastDriver.NewFileEntry.FindLenderMortgageBrokerGAB("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEditContact.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderSalesRep1.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderSalesRep2.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");

                Reports.TestStep = "Click on AddNew in Payoff section.";
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderAddNew.FAClick();

                Reports.TestStep = "Enter details for Pay off lender";
                FastDriver.NewFileEntry.FindLenderMortgageBrokersPayoffLenderGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderFind.FAClick();
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEditCont.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");

                Reports.TestStep = "Enter details for Mortgage Broker";
                FastDriver.NewFileEntry.FindLenderMortgageBrokersMortagageBrokerDetailsGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEditcont.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerBusPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerBusFax.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerCellPhone.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerPager.FASetText(@"(745)451-9999");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEmailAddress.FASetText(@"qfddxypgssssssssssssssssssssssssssssssssssssss111111111111111111111111111111111111111@regression.com");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerSalesRep1.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerSalesRep2.FASelectItem(@"QA10, FAST");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerReference.FASetText(@"REFERENCE12355555555555555555555555555555555555555");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnLenderMortgageBrokerTab();

                Reports.TestStep = "Enter Attention and Name Details";
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderAttention.FASelectItem(@"Contact, Flood Insurance 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersEditName.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLendertextName.FASetText(@"EDITATTENTION123");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderAttention.FASelectItem(@"Contact, Flood Insurance 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderEditName.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLendertextName.FASetText(@"EDITATTENTION123");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerAttention.FASelectItem(@"Contact, Flood Insurance 1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerEditName.FASetCheckbox(true);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokertextName.FASetText(@"EDITATTENTION123");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnLenderMortgageBrokerTab();

                Reports.TestStep = "Highlight first Lender and click on Remove";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
                var value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("TypeError"))
                {
                    Support.AreEqual(@"TypeError: Object doesn't support property or method 'setExpanded'", value);
                    Reports.StatusUpdate("Error message. Expected to fail here because of long string in Name field.", false);
                }
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderRemove);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderRemove.FAClick();

                Reports.TestStep = "Validate Available on removing first Lender";
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);

                Reports.TestStep = "Highlight PayoffLender and click on Remove";
                FastDriver.NewFileEntry.PayOffSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderRemove);
                FastDriver.NewFileEntry.LenderMortgageBrokersPayOfficeLenderRemove.FAClick();

                Reports.TestStep = "Validate Available on removing first PayoffLender";
                FastDriver.NewFileEntry.PayOffSummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);

                Reports.TestStep = "Highlight Mortgage Broker  and click on Remove";
                FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerRemove.FAClick();

                Reports.TestStep = "Validate Mortgage Broker is removed";
                FastDriver.NewFileEntry.MBSummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0095()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_12: Distribution and Delivery Instructions dialog";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Skip search";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false);

                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();

                Reports.TestStep = "Verify the valid values for role type";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                var value = FastDriver.ViewDeliveryInstrucionsDlg.Role2.FAGetText();
                Reports.StatusUpdate("Verify: Business Source Directed By Buyer 1 Buyer 2 Buyer 3 Buyer 4 Buyer 5 Seller 1 Seller 2 Seller 3 Seller 4 Seller 5",
                    value.Contains("Business Source Directed By Buyer 1 Buyer 2 Buyer 3 Buyer 4 Buyer 5 Seller 1 Seller 2 Seller 3 Seller 4 Seller 5"));
                Reports.StatusUpdate("Verify: New Lender 1 New Lender 2 Mortgage Broker 1 Mortgage Broker 2 Associated Business Party Buyers Broker Buyers Real Estate Agent",
                    value.Contains("New Lender 1 New Lender 2 Mortgage Broker 1 Mortgage Broker 2 Associated Business Party Buyers Broker Buyers Real Estate Agent"));
                Reports.StatusUpdate("Verify: Seller Attorney Outside Title Company Outside Escrow Company", value.Contains("Seller Attorney Outside Title Company Outside Escrow Company"));
                FastDriver.DialogBottomFrame.ClickDone();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0096()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_13_FM10159: Duplicate Pending File search";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create file for pending file search";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", underwriters: "First American Title Insurance Company");

                Reports.TestStep = "Save filenumber for pending file search";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                var PendFileNum1 = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue().Clean();

                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Create second file for pending file search";
                FastDriver.PendingFileSearch.WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", underwriters: "First American Title Insurance Company");

                Reports.TestStep = "Save second filenumber for pending file search";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                var PendFileNum2 = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue().Clean();

                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Verify enable property of all controls.";
                FastDriver.PendingFileSearch.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.PendingFileSearch.PropertyAddress.Enabled, "Verify whether 'PropertyAddress' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.PropertyName.Enabled, "Verify whether 'PropertyName' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.PropertyLot.Enabled, "Verify whether 'PropertyLot' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.PropertyTract.Enabled, "Verify whether 'PropertyTract' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.PropertyParcel.Enabled, "Verify whether 'PropertyParcel' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.PropertySubDivision.Enabled, "Verify whether 'PropertySubDivision' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.APNTaxNo.Enabled, "Verify whether 'APNTaxNo' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.State.Enabled, "Verify whether 'State' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.County.Enabled, "Verify whether 'County' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.Country.Enabled, "Verify whether 'Country' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.Numbers.Enabled, "Verify whether 'Numbers' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.EmployeeName.Enabled, "Verify whether 'EmployeeName' dropwdown is enabled.");
                Support.AreEqual(true, FastDriver.PendingFileSearch.EmployeeType.Enabled, "Verify whether 'EmployeeType' dropwdown is enabled.");

                Reports.TestStep = "Enter number and on Find button.";
                FastDriver.PendingFileSearch.Principals.FASetText(@"buyer*");
                FastDriver.PendingFileSearch.PrincipalsAny1.FASetCheckbox(true);
                FastDriver.PendingFileSearch.PrincipalsIndHusWif.FASetCheckbox(true);
                FastDriver.PendingFileSearch.PropertyAddress.FASetText(@"1 First American*");
                var value = PendFileNum1.Substring(0, 4);
                value = String.Concat(value, "*");
                FastDriver.PendingFileSearch.Numbers.FASetText(value + FAKeys.Tab);
                FastDriver.PendingFileSearch.Country.FASelectItem(@"USA");
                FastDriver.PendingFileSearch.State.FASelectItem(@"CA");
                FastDriver.PendingFileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.HandleDialogMessage(timeout: 60);
                bool IsOnlyOneFile = false;
                try
                {
                    FastDriver.PendingFileSearch.WaitForScreenToLoad(FastDriver.PendingFileSearch.NewSearch1);
                    if (FastDriver.PendingFileSearch.Continue.Exists())
                    {
                        Reports.StatusUpdate("Verify:Continue button is disabled", !FastDriver.PendingFileSearch.Continue.Enabled);
                        Reports.StatusUpdate("Verify:Select button is disabled", !FastDriver.PendingFileSearch.Select.Enabled);
                        Reports.StatusUpdate("Verify:NewSearch1 button is Enabled", FastDriver.PendingFileSearch.NewSearch1.Enabled);
                        Reports.StatusUpdate("Verify:GoBack button is disabled", !FastDriver.PendingFileSearch.GoBack.Enabled);

                        Reports.TestStep = "Select the filenumber and verify the status of controls";
                        var element = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(i => i.FAGetText().Contains(PendFileNum1));
                        if (element != null)
                        {
                            element.FAClick();
                        }
                        Reports.StatusUpdate("Verify:Continue button is Enabled", FastDriver.PendingFileSearch.Continue.Enabled);
                        Reports.StatusUpdate("Verify:Select button is Enabled", FastDriver.PendingFileSearch.Select.Enabled);
                        Reports.StatusUpdate("Verify:NewSearch1 button is Enabled", FastDriver.PendingFileSearch.NewSearch1.Enabled);
                        Reports.StatusUpdate("Verify:GoBack button is Enabled", FastDriver.PendingFileSearch.GoBack.Enabled);

                        Reports.TestStep = "Click on Select";
                        FastDriver.PendingFileSearch.Select.FAClick();

                        Reports.TestStep = "Validate file number from pending file search";
                        FastDriver.NewFileEntry.WaitForScreenToLoad();
                        Support.AreEqual(PendFileNum1, FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue().Clean());
                    }
                }
                catch (Exception)
                {
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                    if (FastDriver.NewFileEntry.FileStatus.Exists())
                    {
                        Reports.StatusUpdate("New File Entry Screen loaded as single file found in the search", true);
                        IsOnlyOneFile = true;
                    }
                    else
                    {
                        Reports.StatusUpdate("Pending File Search not working", false);
                    }
                }

                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter number and on Find button.";
                FastDriver.PendingFileSearch.WaitForScreenToLoad();
                FastDriver.PendingFileSearch.Principals.FASetText(@"buyer*");
                FastDriver.PendingFileSearch.PrincipalsAny1.FASetCheckbox(true);
                FastDriver.PendingFileSearch.PrincipalsIndHusWif.FASetCheckbox(true);
                FastDriver.PendingFileSearch.PropertyAddress.FASetText(@"1 First American*");
                value = PendFileNum1.Substring(0, 4);
                value = String.Concat(value, "*");
                FastDriver.PendingFileSearch.Numbers.FASetText(value + FAKeys.Tab);
                FastDriver.PendingFileSearch.Country.FASelectItem(@"USA");
                FastDriver.PendingFileSearch.State.FASelectItem(@"CA");
                FastDriver.PendingFileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PendingFileSearch.WaitForScreenToLoad(FastDriver.PendingFileSearch.Continue);
                if (!IsOnlyOneFile)
                {
                    Reports.StatusUpdate("Verify:Continue button is disabled", !FastDriver.PendingFileSearch.Continue.Enabled);
                    Reports.StatusUpdate("Verify:Select button is disabled", !FastDriver.PendingFileSearch.Select.Enabled);
                    Reports.StatusUpdate("Verify:NewSearch1 button is Enabled", FastDriver.PendingFileSearch.NewSearch1.Enabled);
                    Reports.StatusUpdate("Verify:GoBack button is disabled", !FastDriver.PendingFileSearch.GoBack.Enabled);

                    Reports.TestStep = "Click on Continue";
                    var element = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(i => i.FAGetText().Contains(PendFileNum1));
                    if (element != null)
                    {
                        element.FAClick();
                    }
                    FastDriver.PendingFileSearch.Continue.FAClick();

                    Reports.TestStep = "Validate new pending file screen is loaded";
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                    Support.AreEqual(@"", FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue().Clean());

                    Reports.TestStep = "Click on Cancel.";
                    FastDriver.BottomFrame.Cancel();

                    Reports.TestStep = "Click on Ok button.";
                    FastDriver.WebDriver.HandleDialogMessage();

                    Reports.TestStep = "Enter number and on Find button.";
                    FastDriver.PendingFileSearch.WaitForScreenToLoad();
                    FastDriver.PendingFileSearch.Principals.FASetText(@"buyer*");
                    FastDriver.PendingFileSearch.PrincipalsAny1.FASetCheckbox(true);
                    FastDriver.PendingFileSearch.PrincipalsIndHusWif.FASetCheckbox(true);
                    FastDriver.PendingFileSearch.PropertyAddress.FASetText(@"1 First American*");
                    value = PendFileNum1.Substring(0, 4);
                    value = String.Concat(value, "*");
                    FastDriver.PendingFileSearch.Numbers.FASetText(value + FAKeys.Tab);
                    FastDriver.PendingFileSearch.Country.FASelectItem(@"USA");
                    FastDriver.PendingFileSearch.State.FASelectItem(@"CA");
                    FastDriver.PendingFileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                    try
                    {
                        FastDriver.PendingFileSearch.WaitForScreenToLoad(FastDriver.PendingFileSearch.NewSearch1);
                        if (FastDriver.PendingFileSearch.Continue.Exists())
                        {
                            Reports.StatusUpdate("Verify:Continue button is disabled", !FastDriver.PendingFileSearch.Continue.Enabled);
                            Reports.StatusUpdate("Verify:Select button is disabled", !FastDriver.PendingFileSearch.Select.Enabled);
                            Reports.StatusUpdate("Verify:NewSearch1 button is Enabled", FastDriver.PendingFileSearch.NewSearch1.Enabled);
                            Reports.StatusUpdate("Verify:GoBack button is disabled", !FastDriver.PendingFileSearch.GoBack.Enabled);
                        }
                    }
                    catch (Exception)
                    {
                        Reports.StatusUpdate("Pending File Search is not working", false);
                    }

                    Reports.TestStep = "Click on New Search";
                    FastDriver.PendingFileSearch.WaitForScreenToLoad(FastDriver.PendingFileSearch.NewSearch1);
                    element = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(i => i.FAGetText().Contains(PendFileNum1));
                    if (element != null)
                    {
                        element.FAClick();
                    }
                    FastDriver.PendingFileSearch.NewSearch1.FAClick();

                    Reports.TestStep = "Validate Pending File Search is loaded.";
                    FastDriver.PendingFileSearch.WaitForScreenToLoad();

                    Reports.TestStep = "Enter number and on Find button.";
                    FastDriver.PendingFileSearch.Principals.FASetText(@"buyer*");
                    FastDriver.PendingFileSearch.PrincipalsAny1.FASetCheckbox(true);
                    FastDriver.PendingFileSearch.PrincipalsIndHusWif.FASetCheckbox(true);
                    FastDriver.PendingFileSearch.PropertyAddress.FASetText(@"1 First American*");
                    value = PendFileNum1.Substring(0, 4);
                    value = String.Concat(value, "*");
                    FastDriver.PendingFileSearch.Numbers.FASetText(value + FAKeys.Tab);
                    FastDriver.PendingFileSearch.Country.FASelectItem(@"USA");
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.PendingFileSearch.WaitForScreenToLoad();
                    FastDriver.PendingFileSearch.State.FASelectItem(@"CA");
                    FastDriver.PendingFileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                    try
                    {
                        FastDriver.PendingFileSearch.WaitForScreenToLoad(FastDriver.PendingFileSearch.NewSearch1);
                        if (FastDriver.PendingFileSearch.Continue.Exists())
                        {
                            Reports.StatusUpdate("Verify:Continue button is disabled", !FastDriver.PendingFileSearch.Continue.Enabled);
                            Reports.StatusUpdate("Verify:Select button is disabled", !FastDriver.PendingFileSearch.Select.Enabled);
                            Reports.StatusUpdate("Verify:NewSearch1 button is Enabled", FastDriver.PendingFileSearch.NewSearch1.Enabled);
                            Reports.StatusUpdate("Verify:GoBack button is disabled", !FastDriver.PendingFileSearch.GoBack.Enabled);

                            Reports.TestStep = "Click on Go Back";
                            element = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "span").FirstOrDefault(i => i.FAGetText().Contains(PendFileNum1));
                            if (element != null)
                            {
                                element.FAClick();
                            }
                            FastDriver.PendingFileSearch.GoBack.FAClick();

                            Reports.TestStep = "Validate Pending File Search is loaded.";
                            FastDriver.PendingFileSearch.WaitForScreenToLoad();
                        }
                    }
                    catch (Exception)
                    {
                        Reports.StatusUpdate("Pending File Search is not working", false);
                    }

                    Reports.TestStep = "Enter number and on New Search button.";
                    FastDriver.PendingFileSearch.WaitForScreenToLoad();
                    FastDriver.PendingFileSearch.PropertyAddress.FASetText(@"1 First American*");
                    value = PendFileNum1.Substring(0, 4);
                    value = String.Concat(value, "*");
                    FastDriver.PendingFileSearch.Numbers.FASetText(value + FAKeys.Tab);
                    FastDriver.PendingFileSearch.Country.FASelectItem(@"USA");
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.PendingFileSearch.WaitForScreenToLoad();
                    FastDriver.PendingFileSearch.State.FASelectItem(@"CA");
                    FastDriver.PendingFileSearch.NewSearch.FAClick();

                    Reports.TestStep = "Validate data is cleared on New search";
                    FastDriver.PendingFileSearch.WaitForScreenToLoad(FastDriver.PendingFileSearch.Principals);
                    Support.AreEqual(@"", FastDriver.PendingFileSearch.Principals.FAGetValue().Clean());
                    Support.AreEqual(true, FastDriver.PendingFileSearch.PrincipalsAny1.Selected, "Verify whether 'PrincipalsAny1' checkbox is checked.");
                    Support.AreEqual(true, FastDriver.PendingFileSearch.PrincipalsAny2.Selected, "Verify whether 'PrincipalsAny2' checkbox is checked.");
                    Support.AreEqual(@"", FastDriver.PendingFileSearch.PropertyAddress.FAGetValue().Clean());
                    Support.AreEqual(@"", FastDriver.PendingFileSearch.Numbers.FAGetValue().Clean());
                    Support.AreEqual(@"USA", FastDriver.PendingFileSearch.Country.FAGetSelectedItem() ?? "");
                }

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0099()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_1: User has selected an option to cancel a new order without saving.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "User has selected an option to cancel a new order without saving in NFE";
                Support.AreEqual(@"All information will be erased for this new order. Do you wish to cancel this entry?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Validate Pending File Search is loaded.";
                FastDriver.PendingFileSearch.WaitForScreenToLoad();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0100()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_7: A wildcard is the first character in the search field.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Search with wild card only";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.Principals.FASetText(@"*" + FAKeys.Tab);
                FastDriver.PendingFileSearch.Country.FASelectItem(@"USA");
                FastDriver.PendingFileSearch.FindNow.FAClick();

                Reports.TestStep = "A wildcard is the first character in the search field in NFE";
                Support.AreEqual(@"Searching with wildcard or leading wildcard characters is not allowed", FastDriver.WebDriver.HandleDialogMessage().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0101()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_8: Manually entered file number is invalid";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                Reports.TestStep = "Enter manual file number with special chars";
                FastDriver.NewFileEntry.DetailsAutoNumber.FASetCheckbox(false);
                FastDriver.NewFileEntry.DetailsNewFileEntryPrefix.FASetText(@"123");
                FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FASetText(@"###23");
                FastDriver.NewFileEntry.DetailsNewFileEntrySuffix.FASetText(@"123");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Manually entered file number is invalid in NFE";
                Support.AreEqual(@"Service File: a valid file number can only consist of a combination of letter, numbers and dashes.", FastDriver.WebDriver.HandleDialogMessage(timeout: 15).Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0102()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_6: The user has manually entered a duplicate file number.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                Reports.TestStep = "Create file for pending file search";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryUnderWriters.FASelectItem(@"First American Title Insurance Company");
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Save filenumber";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                var F1 = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue().Clean();

                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Create file with duplicate file number for pending file search";
                FastDriver.PendingFileSearch.WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsAutoNumber.FASetCheckbox(false);
                FastDriver.NewFileEntry.DetailsNewFileEntryPrefix.FASetText(@"123");
                FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FASetText(F1);
                FastDriver.NewFileEntry.DetailsNewFileEntrySuffix.FASetText(@"123");
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryUnderWriters.FASelectItem(@"First American Title Insurance Company");
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate the error message for duplicate file number";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (FastDriver.NewFileEntry.ErrorMsg.Exists())
                    Support.AreEqual("Service File: File Number already exists or reserved.", FastDriver.NewFileEntry.ErrorMsg.FAGetText().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0103()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_11_17: User selects Sub Escrow service without Escrow service or Title service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                Reports.TestStep = "Uncheck auto number and select only sub escrow";
                FastDriver.NewFileEntry.DetailsAutoNumber.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(false);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(false);
                FastDriver.NewFileEntry.DetailsSubEscrowcheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "User selects Sub Escrow service without Escrow service or Title service in NFE";
                Support.AreEqual(@"Please select either Title or Escrow service with Sub Escrow.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0104()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_21: User tries to change a Business Party which has a Reference number specified against it.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                Reports.TestStep = "Select Reference for Bus org";
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsSubEscrowcheckbox.FASetCheckbox(false);
                FastDriver.NewFileEntry.DetailsReference.FASetText(@"REFER1");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Change Bus party";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"247");

                Reports.TestStep = "User tries to change a Business Party which has a Reference number specified against it.";
                var value = FastDriver.WebDriver.HandleDialogMessage(true, false).Clean();
                Support.AreEqual(true, value.Contains("Changing the Business Party will remove"), "Verify whether Alert Message contains 'Changing the Business Party will remove'.");
                Support.AreEqual(true, value.Contains("Do you want to retain the"), "Verify whether Alert Message contains 'Do you want to retain the'.");

                Reports.TestStep = "Validate system removes reference";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"", FastDriver.NewFileEntry.DetailsReference.FAGetValue().Clean(), "Verify DetailsReference value (should be empty).");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Select Reference for Bus org";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsSubEscrowcheckbox.FASetCheckbox(false);
                FastDriver.NewFileEntry.DetailsReference.FASetText(@"REFER1");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Change Bus party back to same";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");

                Reports.TestStep = "Change Business Party have Ref No.";
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                Support.AreEqual(true, value.Contains("Changing the Business Party will remove"), "Verify whether Alert Message contains 'Changing the Business Party will remove'.");
                Support.AreEqual(true, value.Contains("Do you want to retain the"), "Verify whether Alert Message contains 'Do you want to retain the'.");

                Reports.TestStep = "Validate reference is retained";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Support.AreEqual(@"REFER1", FastDriver.NewFileEntry.DetailsReference.FAGetValue().Clean());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0105()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_10: The User updates the page and then navigates off the page.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                Reports.TestStep = "Change Bus Segment";
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Time Share");

                Reports.TestStep = "Navigate away from NFE";
                FastDriver.LeftNavigation.ClickHome();

                Reports.TestStep = "User navigates away after update page.";
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate away from NFE";
                FastDriver.LeftNavigation.ClickHome();

                Reports.TestStep = "User attempts to navigate away without save changes.";
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0106()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_19: User tries to create a next new Pending File without saving the first entered file.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                Reports.TestStep = "Create file and do not save";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryUnderWriters.FASelectItem(@"First American Title Insurance Company");
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");

                Reports.TestStep = "Navigate away from NFE";
                FastDriver.LeftNavigation.ClickHome();

                Reports.TestStep = "User navigates away after update page.";
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate away from NFE";
                FastDriver.LeftNavigation.ClickHome();

                Reports.TestStep = "User attempts to navigate away without save changes.";
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0107()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_20: User tries to access distribution and delivery screen before saving the pending file for the first time.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();

                Reports.TestStep = "User tries to access distribution and delivery screen before saving the pending file for the first time.";
                Support.AreEqual("Please save the Pending File first", FastDriver.WebDriver.HandleDialogMessage().Clean());

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0108()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_14_15: User tries to save Add Distribution and Delivery instruction without Document Type selected.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                Reports.TestStep = "Create file in NFE";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryUnderWriters.FASelectItem(@"First American Title Insurance Company");
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.NewFileEntry.FormType_HUD.FAClick();
                }
                else
                {
                    FastDriver.NewFileEntry.FormType_CD.FAClick();
                }
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on ViewDeliveryInstructions.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();

                Reports.TestStep = "Enter the copies and click on Save";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FASetText(@"1");
                FastDriver.DialogBottomFrame.ClickSave();

                Reports.TestStep = "User tries to save Add Distribution and Delivery instruction without Document Type selected.";
                Support.AreEqual("Please select a delivery method", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Remove the copies and select delivery method alone";
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                FastDriver.ViewDeliveryInstrucionsDlg.BusinessSource.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.Doc0OpeningPackage.FASetText(@"");
                FastDriver.ViewDeliveryInstrucionsDlg.SelectOpeningPackage.FASelectItem(@"Branch");
                FastDriver.DialogBottomFrame.ClickSave();

                Reports.TestStep = "User tries to save Add Distribution and Delivery instruction without copies selected.";
                Support.AreEqual("Please enter number of copies", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void FMUC0107_REG0109()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_9: User tries to add document when one or more mandatory value(s) are missing.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File via New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Leasehold Owners Policy", buyer: false, seller: false);

                Reports.TestStep = "Click on Upload button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsUpload.FAClick();

                Reports.TestStep = "Browse document and upload it.(pdf).";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                var DocumentFile = Reports.DEPLOYDIR + @"\EMAIL_Offshore_Pdf.pdf";
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(DocumentFile);
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                Reports.TestStep = "Click on Ok without entering details";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.Ok.FAClick();

                Reports.TestStep = "User tries to add document when one or more mandatory value(s) are missing.";
                Support.AreEqual("File Number, Document Type and Document Name are required to attach to file", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Click on Cancel";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.Cancel.FAClick();

                Reports.TestStep = "Click on Cancel";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.Cancel.FAClick();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\Customerview.xml")]
        public void FMUC0107_REG0110()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "ER_22: User has not selected valid file type for uploading";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File via New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Leasehold Owners Policy", buyer: false, seller: false);

                Reports.TestStep = "Click on Upload button.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsUpload.FAClick();

                Reports.TestStep = "Browse an invalid document type";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                var DocumentFile = Reports.DEPLOYDIR + @"\Customerview.xml";
                FastDriver.UploadDocumentDlg.DocumentFile.FASetText(DocumentFile);
                FastDriver.UploadDocumentDlg.Upload.FAClick();

                Reports.TestStep = "User has not selected valid file type for uploading";
                Support.AreEqual("File type is invalid. It must have an extension of .tif .tiff .pdf .jpg .jpeg .doc .docx .xls .xlsx", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                Reports.TestStep = "Click on Cancel";
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.Cancel.FAClick();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0111()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_14: AdhocBusOrg";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File via New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Leasehold Owners Policy", buyer: false, seller: false);

                Reports.TestStep = "Click on Find";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsFind.FAClick();

                Reports.TestStep = "Enter GAB code and click on Find button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText(@"Test");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                Reports.TestStep = "Click on New GAB button.";
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();

                Reports.TestStep = "Creates a New GAB Request.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem(@"Corporate");
                FastDriver.GABEntryRequestDlg.Name1.FASetText(@"Name 1 TFS 106786");
                FastDriver.GABEntryRequestDlg.Name2.FASetText(@"Name 2 TFS 106786");
                FastDriver.GABEntryRequestDlg.LocDescription.FASetText(@"Loc Descscription");
                FastDriver.GABEntryRequestDlg.TaxIDNumber.FASetText(@"1111111111");
                FastDriver.GABEntryRequestDlg.BusOrgComments.FASetText(@"Bus Org Comments");
                FastDriver.GABEntryRequestDlg.EntryInstructions.FASetText(@"Entity Instruction");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText(@"1 First American Way");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText(@"Santa Ana");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem(@"CA");
                FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText(@"92707");
                FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText(@"Orange");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0112()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FD_4_01: BusParty Commission-Details Tab";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File via New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad();

                Reports.TestStep = "Enter more than 9 chars for Commision% and 11.2 chars for $.";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                if (!FastDriver.NewFileEntry.OwnerPolicyTable.Text.Contains("ALTA Extended Owner Policy"))
                {
                    FastDriver.NewFileEntry.DetailsAddRemove.FAClick();
                    FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                        .Table.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NewFileEntry.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Owner Policy", 1, TableAction.On);
                }
                FastDriver.NewFileEntry.FindBusinessSourceGAB(@"HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem(@"Seller's Broker");
                FastDriver.NewFileEntry.DetailsPercent.FASetText(@"999999999" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsAmount.FASetText(@"11111111111" + FAKeys.Tab);

                Reports.TestStep = "Validate more than 9 chars for Commision% and 11.2 chars for $.";
                Support.AreEqual(@"?", FastDriver.NewFileEntry.DetailsPercent.FAGetValue().Clean());
                Support.AreEqual(@"11,111,111,111.00", FastDriver.NewFileEntry.DetailsAmount.FAGetValue().Clean());

                Reports.TestStep = "Enter 9999.9999 chars for Commision% and 10.2 chars for $.";
                FastDriver.NewFileEntry.DetailsPercent.FASetText(@"9999.9999" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsAmount.FASetText(@"1111111111" + FAKeys.Tab);

                Reports.TestStep = "Validate 9999.9999 chars for Commision% and 10.2 chars for $.";
                Support.AreEqual(@"9999.9999", FastDriver.NewFileEntry.DetailsPercent.FAGetValue().Clean());
                Support.AreEqual(@"1,111,111,111.00", FastDriver.NewFileEntry.DetailsAmount.FAGetValue().Clean());

                Reports.TestStep = "Enter 999.9999 chars for Commision% and 9.2 chars for $.";
                FastDriver.NewFileEntry.DetailsPercent.FASetText(@"999.0999" + FAKeys.Tab);
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.Click();
                FastDriver.NewFileEntry.DetailsAmount.FASetText(@"111111111.9" + FAKeys.Tab);

                Reports.TestStep = "Validate 9999.9999 chars for Commision% and 9.2 chars for $.";
                Support.AreEqual(@"999.0999", FastDriver.NewFileEntry.DetailsPercent.FAGetValue().Clean());
                Support.AreEqual(@"111,111,111.90", FastDriver.NewFileEntry.DetailsAmount.FAGetValue().Clean());
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(@"CA");
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0113()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "RemoveSetUp_ADM: Remove the set up in ADM";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "To uncheck Display In QFE/QRE/FHP/NFE";
                FastDriver.LeftNavigation.Navigate<ProcessingRegionSetup>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST").WaitForScreenToLoad();
                FastDriver.ProcessingRegionSetup.DisplayBustype.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0116()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10193_FM10208";

                Reports.TestStep = "Log into FAST ADM application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region level.";
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Select Special Instructions for NFE-1";
                FastDriver.LeftNavigation.Navigate<SpecialInstructionsSetup>("Home>System Maintenance>Special Instructions Setup[0]>Special Instructions Setup[1]").WaitForScreenToLoad();
                FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction(2, "Sanity_Instruction1", 4, TableAction.On);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to New File Entry and verify whether special instruction 'Sanity_Instruction1' is displayed.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(buyer: false, seller: false);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnSpecialInstructionsTab();
                FastDriver.NewFileEntry.SpecialInstructionsTable.PerformTableAction(2, "Sanity_Instruction1", 2, TableAction.Click);

                Reports.TestStep = "Navigate to New File Entry and create a file.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Navigate to Lenders/Mortgage Brokers tab and add New Lender information and save the File.";
                FastDriver.PendingFileSearch.ClickOnSkipSearch().WaitForScreenToLoad().CreateDetailedFile(buyer: false, seller: false);
                FastDriver.NewFileEntry.WaitForScreenToLoad().ClickOnLenderMortgageBrokerTab().FindLenderMortgageBrokerGAB(@"boa");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Check Bus Org added in View Delivery Instruction DLG.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.ViewDeliveryInstrucionsDlg.BOA.Exists(), "Verify whether the Bus Org 'BOA' is present.");
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Navigate to Lenders/Mortgage Brokers tab and remove the GAB.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.ClickOnLenderMortgageBrokerTab();
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Bank of America", 2, TableAction.Click);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderRemove.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Verify whether the Bus Org 'BOA' is not present in View Delivery Instruction Dlg.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsDistributieryInstructions.FAClick();
                FastDriver.ViewDeliveryInstrucionsDlg.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.ViewDeliveryInstrucionsDlg.BOA.Exists(), "Verify whether the Bus Org 'BOA' is not present.");
                FastDriver.DialogBottomFrame.ClickCancel();

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0117()
        {
            try
            {
                Reports.TestDescription = "FM10212  scripted";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();

                Reports.TestStep = "Enter data for Properties address and validate the default field values";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", addRole: "Outside Escrow Company");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Event Tracking Log and check FS event.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Fast Search Initiated]"), "Verify whether the Fast Search event is not present in the Event Tracking Log table.");
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0118()
        {
            try
            {
                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region UI Interaction

                Reports.TestDescription = "FM10494: Prevent changing status of an Open File to Pending.";

                Reports.TestStep = "Log into FAST Admin site";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Products Setup and select at least six options in Owner Policy, Lender Policy and Other Products tab.";
                FastDriver.LeftNavigation.Navigate<ProductSetup>("Home>System Maintenance>Products Setup").WaitForScreenToLoad();
                FastDriver.ProductSetup.OwnerTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.ProductSetup.OwnerTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.ProductSetup.OwnerTable.PerformTableAction(3, 1, TableAction.On);
                FastDriver.ProductSetup.OwnerTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.ProductSetup.OwnerTable.PerformTableAction(5, 1, TableAction.On);
                FastDriver.ProductSetup.OwnerTable.PerformTableAction(6, 1, TableAction.On);
                FastDriver.ProductSetup.LenderPolicies.FAClick();
                FastDriver.ProductSetup.WaitForScreenToLoad(FastDriver.ProductSetup.LenderTable);
                FastDriver.ProductSetup.LenderTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.ProductSetup.LenderTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.ProductSetup.LenderTable.PerformTableAction(3, 1, TableAction.On);
                FastDriver.ProductSetup.LenderTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.ProductSetup.LenderTable.PerformTableAction(5, 1, TableAction.On);
                FastDriver.ProductSetup.LenderTable.PerformTableAction(6, 1, TableAction.On);
                FastDriver.ProductSetup.OtherProducts.FAClick();
                FastDriver.ProductSetup.WaitForScreenToLoad(FastDriver.ProductSetup.OtherTable);
                FastDriver.ProductSetup.OtherTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.ProductSetup.OtherTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.ProductSetup.OtherTable.PerformTableAction(3, 1, TableAction.On);
                FastDriver.ProductSetup.OtherTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.ProductSetup.OtherTable.PerformTableAction(5, 1, TableAction.On);
                FastDriver.ProductSetup.OtherTable.PerformTableAction(6, 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Verify if the row count of the Lender/Owner/Others table are greater or equal to 5.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").WaitForScreenToLoad().ClickOnSkipSearch().WaitForScreenToLoad()
                    .CreateDetailedFile(ownerPolicy: "ALTA Extended Owner Policy", buyer: false, seller: false, saveFile: false);
                Support.AreEqual("True", (FastDriver.NewFileEntry.LenderPolicyTable.GetRowCount() > 5).ToString());
                Support.AreEqual("True", (FastDriver.NewFileEntry.OwnerPolicyTable.GetRowCount() > 5).ToString());
                Support.AreEqual("True", (FastDriver.NewFileEntry.OthersTable.GetRowCount() > 5).ToString());

                Reports.TestStep = "Save the File.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Change file status to Open.";
                FastDriver.NewFileEntry.WaitForScreenToLoad().FileStatus.FASelectItem(@"Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to TermsDatesStatus screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Verify whether 'Pending' option is not present within Status dropdown.";
                Reports.StatusUpdate("Pending option not present.", !FastDriver.TermsDatesStatus.Status.Text.Contains("Pending"));

                #endregion UI Interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0119()
        {
            try
            {
                //Additional Roles should not be selected from the below: New Lender, Outside Escrow Company,Outside Title Company,Other RE Agent,Other RE Broker, Seller Attorney,Seller RE Broker,Seller RE Agent,Buyer Attorney,Buyer RE Broker,Buyer RE Agent,Mortgage Broker,

                Reports.TestDescription = "USER STORY - 516573 :Additional Roles should not be selected from the below: New Lender, Outside Escrow Company,Outside Title Company,Other RE Agent,Other RE Broker, Seller Attorney,Seller RE Broker,Seller RE Agent,Buyer Attorney,Buyer RE Broker,Buyer RE Agent,Mortgage Broker";
                Reports.TestStep = "Login to FAST IIS";
                this.Login(false);

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "SELECT SERVICE TYPE.";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FAClick();
                Reports.TestStep = "SELECT TRANSACTION TYPE.";
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Construction Disbursement");
                Reports.TestStep = "SELECT FORM TYPE AS CD.";
                FastDriver.NewFileEntry.FormType_CD.FAClick();
                Playback.Wait(2000);

                //ENTER LENDER GAB CODE.
                Reports.TestStep = "ENTER LENDER GAB CODE.";
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.FASetText("BOA");//5842733
                //CLICK ON FIND BUTTON.
                Reports.TestStep = "CLICK ON FIND BUTTON.";
                FastDriver.NewFileEntry.DetailsFind.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "SELECT ADDITIONAL ROLE AS NEW LENDER.";
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("Assumption Lender");
                Playback.Wait(1000);

                Reports.TestStep = "SELECT PROPERTY STATE.";
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("AL");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Construction Disbursement");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad(element: FastDriver.NewFileEntry.NMLSID);

                Reports.TestStep = "SELECT FILE STATUS AS OPEN.";
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.BottomFrame.Done();

                Playback.Wait(10000);
                Reports.TestStep = "VALIDATION IN THE FILE HOMEPAGE.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "VALIDATION FOR NMLSID.";
                string NMLSID = FastDriver.FileHomepage.NMLSID.FAGetValue();
                string NMLSID1 = FastDriver.FileHomepage.NMLSID.IsEnabled().ToString();
                Support.AreEqual("", NMLSID, "BLANK value");
                Support.AreEqual("False", NMLSID1, "Field Disabled");

                Reports.TestStep = "VALIDATION FOR STLICENSE.";
                string STLicence = FastDriver.FileHomepage.STLicense.FAGetValue();
                Support.AreEqual("0", STLicence, "BLANK value");

                Reports.TestStep = "VALIDATION FOR ADDITIONAL ROLE.";
                Support.AreEqual("Assumption Lender", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0120()
        {
            try
            {
                //Additional Roles should be selected from the below: New Lender, Outside Escrow Company,Outside Title Company,Other RE Agent,Other RE Broker, Seller Attorney,Seller RE Broker,Seller RE Agent,Buyer Attorney,Buyer RE Broker,Buyer RE Agent,Mortgage Broker,
                //GAB Should be created with NMLS ID and State License

                Reports.TestDescription = "USER STORY - 516573 :";
                Reports.TestStep = "Login to FAST IIS";
                this.Login(false);

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                //SELECT TRANSACTION TYPE.

                Reports.TestStep = "SELECT SERVICE TYPE.";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FAClick();
                Reports.TestStep = "SELECT TRANSACTION TYPE.";
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Construction Disbursement");

                Reports.TestStep = "SELECT FORM TYPE AS CD.";
                FastDriver.NewFileEntry.FormType_CD.FAClick();
                Playback.Wait(2000);

                //ENTER LENDER GAB CODE.
                Reports.TestStep = "ENTER LENDER GAB CODE.";
                FastDriver.NewFileEntry.DetailsBussSourceGABcode.FASetText("BOA");//5842733");
                //CLICK ON FIND BUTTON.
                Reports.TestStep = "CLICK ON FIND BUTTON.";
                FastDriver.NewFileEntry.DetailsFind.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "SELECT ADDITIONAL ROLE AS NEW LENDER.";
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("New Lender");
                Playback.Wait(1000);

                //SELECT PROPERTY STATE.
                Reports.TestStep = "SELECT PROPERTY STATE.";
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("AL");

                Reports.TestStep = "VALIDATION FOR NMLSID.";
                string NMLSID = FastDriver.NewFileEntry.NMLSID.FAGetValue();
                string NMLSID1 = FastDriver.NewFileEntry.NMLSID.IsEnabled().ToString();

                Support.AreEqual("", NMLSID, "BLANK value");
                Support.AreEqual("False", NMLSID1, "Field Disabled");

                Reports.TestStep = "VALIDATION FOR STLICENSE.";
                string STLicence = FastDriver.NewFileEntry.STLicense.FAGetValue();
                string STLicence1 = FastDriver.NewFileEntry.STLicense.IsEnabled().ToString();

                Support.AreEqual("0", STLicence, "BLANK value");
                Support.AreEqual("True", STLicence1, "Field Enabled");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad(element: FastDriver.NewFileEntry.NMLSID);
                //FastDriver.PendingFileSearch.ClickOnSkipSearch();
                //FastDriver.NewFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "AFTER SAVE VALIDATION FOR NMLSID.";
                string NMLSID3 = FastDriver.NewFileEntry.NMLSID.FAGetValue();
                string NMLSID33 = FastDriver.NewFileEntry.NMLSID.IsEnabled().ToString();

                Support.AreEqual("", NMLSID3, "Value Blank");
                Support.AreEqual("False", NMLSID33, "Field Disabled");

                Reports.TestStep = "AFTER SAVE VALIDATION FOR STLICENSE.";
                string STLicence3 = FastDriver.NewFileEntry.STLicense.FAGetValue();
                string STLicence33 = FastDriver.NewFileEntry.STLicense.IsEnabled().ToString();

                Support.AreEqual("0", STLicence3);
                Support.AreEqual("True", STLicence33);

                //SELECT FILE STATUS AS OPEN.
                Reports.TestStep = "SELECT FILE STATUS AS OPEN.";
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");

                //CLICK ON SAVE BUTTON.
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                /* NAVIGATE TO FILE HOMEPAGE.  */
                Reports.TestStep = "VALIDATION IN THE FILE HOMEPAGE.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.STLicense.FASelectItem("");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(7000);
                Reports.TestStep = "VALIDATION FOR NMLSID.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string NMLSID2 = FastDriver.FileHomepage.NMLSID.FAGetValue();
                Support.AreEqualTrim("", NMLSID2);
                Reports.TestStep = "VALIDATION FOR STLICENSE.";
                string STLicence2 = FastDriver.FileHomepage.STLicense.FAGetValue();
                Support.AreEqualTrim("0", STLicence2);
                Reports.TestStep = "VALIDATION FOR ADDITIONAL ROLE.";
                string Addrole = FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem();
                Support.AreEqualTrim("New Lender", Addrole);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0121()
        {
            try
            {
                Reports.TestDescription = "TC824123 A drop-down selection list of 'UW Employee' is added to the Title Owning Office section of the New File Entry";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Check and setup on UW Employee type on ADM side
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa06";


                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa06");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA06]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa07";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa07");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA07]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Create a FAST file via Home | Order Entry | New File Entry";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>(@"Home>Order Entry>New File Entry").ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Check Tittle and Escrow in Service area";

                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);

                Reports.TestStep = "Verify that UW Employee default to Blank";
                FastDriver.NewFileEntry.UW_Employee.IsVisible();
                Support.AreEqual(true, FastDriver.NewFileEntry.UW_Employee.FAGetSelectedItem().Contains(""), "Default to Blank");

                //This block for US830477, please comment out if it is not deployed.

                //Reports.TestStep = "Verify UW Employee Drop-Down position is alongside the Policy Issued By field";
                //FastDriver.NewFileEntry.UW_Employee.IsVisible();
                //Support.AreEqual("True", FastDriver.NewFileEntry.TitleOwningOfficeTable.PerformTableAction(1, "Policy Issued By* :", 3, TableAction.GetText).Message.Clean().Contains("UW Employee :").ToString());

                //Endblock

                Reports.TestStep = "Select an UW Employee";
                FastDriver.NewFileEntry.UW_Employee.FASelectItem("QA07, FAST");

                Reports.TestStep = "Enter a GAB and Required info";
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.NewFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.NewFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.NewFileEntry.DetailsBussSourceGABcode.FASetText("HUDFLINSR1");

                FastDriver.NewFileEntry.DetailsFind.FAClick();




                Reports.TestStep = "Enter Property State and Click Save to create file";

                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Event/Tracking Log screen and verify file created.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Pending]"), "File Created");

            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0122()
        {
            try
            {
                Reports.TestDescription = "US795533_TC854576: Verify Manufactured Home value exists in Property Type dropdown on NFE screen";

                Reports.TestDescription = "Login to IIS";
                this.Login();

                // 
                Reports.TestStep = "Create a Pending file-Details Tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem("No Program Type");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("Title Agent");
                FastDriver.NewFileEntry.DetailsSearchType.FASelectItem("No Search Type");
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.NewFileEntry.FormType_CD.FAClick();
                }

                else
                    if (AutoConfig.FormType.ToLower().Equals("hud"))
                {
                    FastDriver.NewFileEntry.FormType_HUD.FAClick();
                }

                FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText("92707");
                FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem("Orange");
                FastDriver.NewFileEntry.DetailsSalePrice.FASetText("600,000.00");
                FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText("250,000.00");
                FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText("150,000.00");

                //
                Reports.TestStep = "Validate the Pending file-Details Tab.";
                Support.AreEqual("Residential", FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryBusinessSegment");
                Support.AreEqual("Sale w/Mortgage", FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryTransactionType");
                Support.AreEqual("No Program Type", FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FAGetSelectedItem(), "Verifies the DetailsNewFileEntryProgramType");
                Support.AreEqual("Title Agent", FastDriver.NewFileEntry.DetailsAddtionalRole.FAGetSelectedItem(), "Verifies the DetailsAddtionalRole");
                Support.AreEqual("No Search Type", FastDriver.NewFileEntry.DetailsSearchType.FAGetSelectedItem(), "Verifies the DetailsSearchType");
                Support.AreEqual("1 First American Way", FastDriver.NewFileEntry.DetailsPropertyStreet1.FAGetValue(), "Verifies the DetailsPropertyStreet1");
                Support.AreEqual("PropertyStreet3", FastDriver.NewFileEntry.DetailsPropertyStreet3.FAGetValue(), "Verifies the DetailsPropertyStreet3");
                Support.AreEqual("PropertyStreet4", FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue(), "Verifies the DetailsPropertyStreet4");
                Support.AreEqual("PropertyStreet4", FastDriver.NewFileEntry.DetailsPropertyStreet4.FAGetValue(), "Verifies the DetailsPropertyStreet4");
                Support.AreEqual("Santa Ana", FastDriver.NewFileEntry.DetailsPropertyCity.FAGetValue(), "Verifies the DetailsPropertyCity");
                Support.AreEqual("CA", FastDriver.NewFileEntry.DetailsPropertyState.FAGetSelectedItem(), "Verifies the DetailsPropertyState");
                Support.AreEqual("92707", FastDriver.NewFileEntry.DetailsPropertyZIP.FAGetValue(), "Verifies the DetailsPropertyZIP");
                Support.AreEqual("Orange", FastDriver.NewFileEntry.DetailsPropertyCounty.FAGetSelectedItem(), "Verifies the DetailsPropertyCounty");
                Support.AreEqual("600,000.00", FastDriver.NewFileEntry.DetailsSalePrice.FAGetValue(), "Verifies the DetailsSalePrice");
                Support.AreEqual("250,000.00", FastDriver.NewFileEntry.DetailsFirstNewLoan.FAGetValue(), "Verifies the DetailsFirstNewLoan");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                // 
                Reports.TestStep = "Enter data for Parties Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.PartiesParties.FAClick();
                Playback.Wait(2500);

                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PartiesDirectedByGABcode);
                FastDriver.NewFileEntry.PartiesDirectedByGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.PartiesDirectedByFind.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyGABcode.FAClick();
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.PartiesAssociatedBusPartyFind.FAClick();
                Playback.Wait(2500);

                // 
                Reports.TestStep = "Validate the Pending file-Parties Tab.";
                FastDriver.NewFileEntry.PartiesParties.FAClick();
                Playback.Wait(2500);
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                // 
                Reports.TestStep = "Enter data for PartiesPropertyInfo Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyInfo);
                FastDriver.NewFileEntry.PropertyInfoPropertyInfo.FAClick();
                Playback.Wait(2500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.PropertyInfoPropertyType);
                FastDriver.NewFileEntry.PropertyInfoPropertyType.FASelectItem("Manufactured Home");
                Keyboard.SendKeys("{ENTER}");
                FastDriver.NewFileEntry.PropertyInfoLot.FASetText("Lot1");
                FastDriver.NewFileEntry.PropertyInfoBlock.FASetText("Block1");
                FastDriver.NewFileEntry.PropertyInfoUnit.FASetText("Unit1");
                FastDriver.NewFileEntry.PropertyInfoTrack.FASetText("Tract1");
                FastDriver.NewFileEntry.PropertyInfoFee.FASetText("Fee1");
                FastDriver.NewFileEntry.PropertyInfoBuilding.FASetText("Building1");
                FastDriver.NewFileEntry.PropertyInfoBook.FASetText("Book1");
                FastDriver.NewFileEntry.PropertyInfoPage.FASetText("Page1");
                FastDriver.NewFileEntry.PropertyInfoSection.FASetText("Section1");

                // 
                Reports.TestStep = "Validate the Pending file-PropertyInfoTab.";
                Support.AreEqual("Manufactured Home", FastDriver.NewFileEntry.PropertyInfoPropertyType.FAGetSelectedItem(), "Verifies the PropertyInfoPropertyType");
                Support.AreEqual("Lot1", FastDriver.NewFileEntry.PropertyInfoLot.FAGetValue(), "Verifies the DetailsFirstNewLoan");
                Support.AreEqual("Block1", FastDriver.NewFileEntry.PropertyInfoBlock.FAGetValue(), "Verifies the PropertyInfoBlock");
                Support.AreEqual("Unit1", FastDriver.NewFileEntry.PropertyInfoUnit.FAGetValue(), "Verifies the PropertyInfoUnit");
                Support.AreEqual("Tract1", FastDriver.NewFileEntry.PropertyInfoTrack.FAGetValue(), "Verifies the PropertyInfoTrack");
                Support.AreEqual("Fee1", FastDriver.NewFileEntry.PropertyInfoFee.FAGetValue(), "Verifies the PropertyInfoFee");
                Support.AreEqual("Building1", FastDriver.NewFileEntry.PropertyInfoBuilding.FAGetValue(), "Verifies the PropertyInfoBuilding");
                Support.AreEqual("Book1", FastDriver.NewFileEntry.PropertyInfoBook.FAGetValue(), "Verifies the PropertyInfoBook");
                Support.AreEqual("Page1", FastDriver.NewFileEntry.PropertyInfoPage.FAGetValue(), "Verifies the PropertyInfoPage");
                Support.AreEqual("Section1", FastDriver.NewFileEntry.PropertyInfoSection.FAGetValue(), "Verifies the PropertyInfoSection");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                // 
                Reports.TestStep = "Enter data for Lender/Mortgage Broker Tab.";
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode);
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersNewLenderFind.FAClick();
                Playback.Wait(4500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode);
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerGABcode.FASetText("HUDFLINSR1");
                FastDriver.NewFileEntry.LenderMortgageBrokersMortgageBrokerFind.FAClick();

                // 
                Reports.TestStep = "Validate the Pending file- Lender/Mortgage Broker Tab.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Enter data for Special Instructions Tab.";
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FASetText("SpecialInstruction Notes Data including - * # Specialcharacter :) ! ");

                // 
                Reports.TestStep = "Validate the Pending file- Special Instructions Tab.";
                Support.AreEqual(@"SpecialInstruction Notes Data including - * # Specialcharacter :) ! ", FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FAGetText());
                FastDriver.BottomFrame.Save();
                
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        //SRT  FMUC0107_REG0123, FMUC0107_REG0124, FMUC0107_REG0125
        [TestMethod]
        public void FMUC0107_REG0123()
        {
            try
            {
                Reports.TestStep = "Create a Pending file with Special Instructions";

                Reports.TestStep = "Log into FAST application.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Change the status to Open.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", toExist: false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.FileStatus);
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                string detailsCustomFileNumber = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetText();
                FastDriver.BottomFrame.Done();
                Playback.Wait(4500);

                Reports.TestStep = "Navigate to File Note screen and verify the Special Instructions File Note";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.Table.PerformTableAction("Note", @"Special Instructions: Escrow Notes ", "Note", TableAction.Click);
                Playback.Wait(2000);
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0124()
        {
            try
            {
                Reports.TestStep = "Create a Pending file with Special Instructions Note";

                Reports.TestStep = "Log into FAST application.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Enter data for Special Instructions Tab.";
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FASetText("SpecialInstruction Notes Data including - * # Specialcharacter :) ! ");
                FastDriver.BottomFrame.Save();
                Playback.Wait(1000);
                Reports.TestStep = "Change the status to Open.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", toExist: false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.FileStatus);
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                string detailsCustomFileNumber = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetText();
                FastDriver.BottomFrame.Done();
                Playback.Wait(4500);

                Reports.TestStep = "Navigate to File Note screen and verify the Special Instructions File Note";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.Table.PerformTableAction("Note", @"SpecialInstruction Notes Data including - * # Specialcharacter :) ! ", "Note", TableAction.Click);
                Playback.Wait(2000);
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0107_REG0125()
        {
            try
            {
                Reports.TestStep = "Create a Pending file with Special Instructions";

                Reports.TestStep = "Log into FAST application.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Enter the Special Instructions Note After Pending File Creation.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Enter data for Special Instructions Tab.";
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(500);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntryNotes.FASetText("SpecialInstruction Notes Data including - * # Specialcharacter :) ! ");
                FastDriver.BottomFrame.Save();
                Playback.Wait(1000);

                Reports.TestStep = "Change the status to Open.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", toExist: false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.FileStatus);
                FastDriver.NewFileEntry.FileStatus.FASelectItem("Open");
                string detailsCustomFileNumber = FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetText();
                FastDriver.BottomFrame.Done();
                Playback.Wait(4500);

                Reports.TestStep = "Navigate to File Note screen and verify the Special Instructions File Note";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.Table.PerformTableAction("Note", @"Special Instructions: Escrow Notes ", "Note", TableAction.Click);
                FastDriver.FileNotes.Table.PerformTableAction("Note", @"SpecialInstruction Notes Data including - * # Specialcharacter :) ! ", "Note", TableAction.Click);
                Playback.Wait(3000);

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }


        //Team                           :  SRT-Team2
        //Iteration                      :  r10
        //UserStory                      :  User Story 865069:INC2969354 FASTSearch launching when order is in Pending status
        // TestCase                      :  886174
        //Appended By/ Created By        :  Diego Hilario
        [TestMethod]
        public void FMUC0107_REG0126()
        {
            try
            {
                Reports.TestDescription = "To Verify US# 8650569 - FAST Search to not initiate when order created in Pending status - through CreateFile() webservice method";

                Reports.TestStep = "Create a basic file";
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                Reports.TestStep = "Add a complete and valid address to the request";
                fileRequest.File.Properties = new FASTWCFHelpers.FastFileService.Property[]
                {
                    new FASTWCFHelpers.FastFileService.Property()
                    {
                        PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                        {
                            new FASTWCFHelpers.FastFileService.PhysicalAddress()
                            {
                                AddrLine1 = "1 First American Way",
                                City = "Santa Ana",
                                State = "CA",
                                Zip = "92707",
                                County = "Orange",
                                Country = "USA",
                            }
                        }
                    }
                };

                Reports.TestStep = "Set IsPending field to true";
                fileRequest.File.IsPendingFile = true;

                Reports.TestStep = "Set InitiateFastSearch to True or False ";
                fileRequest.File.InitiateFastSearch = true;

                Reports.TestStep = "On Source field, enter 'FAST' or any interface partner code (for ex.  'FAMOS', 'WINTRACK', 'LA.COM', 'AgentNet', etc)";
                fileRequest.Source = "WINTRACK";

                Reports.TestStep = "Execute the request and get the FileID. Use GetOrderDetails to get the FileNumber using the FileID ";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                Reports.TestStep = "Log in to FAST IIS ";
                Login();

                Reports.TestStep = "Navigate to the region entered in the CreateFile mehtod and enter the FileNumber on the  MRU (top frame)";
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Event/Tracking Log ";
                FastDriver.EventTrackingLog.Open();

                Reports.TestStep = "On Event Category 'File Process' ensure FAST Search events are not displayed ";
                FastDriver.EventTrackingLog.SelectEventCategory("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.StringExistOnTable("Pending"), "Verifying file is in Pending status");
                Support.AreEqual(false, FastDriver.EventTrackingLog.EventTable.StringExistOnTable("Fast Search Initiated"), "Verifying Fast Search is not initated for Files in Pending status");

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 823597:REQ0909373 - NCS - Hide Select Office Names in FAST Office Selection- NFE
        //TestCase                                : 855232
        //Appended By/ Created By                 : Sheetal Gothi

        [TestMethod]
        public void FMUC0107_REG0127()
        {
            string OfficeCode1 = "0";
            try
            {
                Reports.TestDescription = "Verify system is not displaying  Hidden offices which are marked Hidden in Change OO screen for Project file and Site files.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion data setup

                #region UI Iteration
                #region Create a new office in ADM side if not created .

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select an Office and Click on New.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                //string office = FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it and verify office is marked as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    Console.WriteLine(OfficeCode1);
                    //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();
                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                        FastDriver.BottomFrame.Done();
                    }
                    else
                    {
                        FastDriver.BottomFrame.Done();
                    }
                }
                else if (!FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Test Automation Office"))
                {
                    this.CreateNewOffice();

                    Reports.TestStep = "Verify if office is not created then create or just mark the office as Hidden.";
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                    Reports.TestStep = "Mark the office as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for office";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    FastDriver.BottomFrame.Done();
                }

                #endregion Create a new office in ADM side if not created.

                #region Create File
                Reports.TestStep = "Log into FAST application.";
                //#region data setup
                //credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                //#endregion

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(40000);

                #endregion Create File

                #region Navigate to Change OO
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsChangeOObutton.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Reports.TestStep = "Check Escrow Own Office.";

                string[] AllEscrowOffices = FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under Escrow owning office.");

                string[] AllTitleOffices = FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');
                bool isPresent_Title = false;
                foreach (string office in AllTitleOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Title = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Title, "Verify the Hidden Office should not be present under title owning office.");
                FastDriver.BottomFrame.Done();

                #endregion Navigate to Change OO
                #endregion UI Iteration
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 823597:REQ0909373 - NCS - Hide Select Office Names in FAST Office Selection- NFE
        //TestCase                                : 856493
        //Appended By/ Created By                 : Sheetal Gothi

        [TestMethod]
        public void FMUC0107_REG0128()
        {
            string OfficeCode1 = "0";
            string OfficeBuid = "0";
            try
            {
                Reports.TestDescription = "Verify system selects Blank office from Office drop down if logged in office is marked as Hidden.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion data setup

                #region UI Iteration

                #region Create a new office in ADM side if not created.

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select an Office and Click on New.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                //string office = FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it and verify office is marked as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    Console.WriteLine(OfficeCode1);
                    //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();
                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                        FastDriver.BottomFrame.Done();
                    }
                    else
                    {
                        FastDriver.BottomFrame.Done();
                    }
                }
                else if (!FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Test Automation Office"))
                {
                    this.CreateNewOffice();

                    Reports.TestStep = "Verify if office is not created then create or just mark the office as Hidden.";
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                    Reports.TestStep = "Mark the office as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for office";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    FastDriver.BottomFrame.Done();
                }

                #endregion Create a new office in ADM side if not created.


                #region Create File
                Reports.TestStep = "Log into FAST application.";
                #region data setup
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.IsSelected())
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                }

                if (FastDriver.NewFileEntry.DetailsEscrowcheckbox.IsSelected())
                {
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(false);
                }

                //if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                //  FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Title Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Title owning office");
                }
                string[] AllTitleOffices = FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Title = false;
                foreach (string office in AllTitleOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Title = true;
                        break;
                    }
                }
                Support.AreEqual(false, isPresent_Title, "Verify the Hidden Office should not be present under Title owning office.");
                Playback.Wait(3000);
                FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FASelectItemBySendingKeys("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878");
                Playback.Wait(4000);
                FastDriver.NewFileEntry.DetailsNewFileEntryUnderWriters.FASelectItem("New Underwriter");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.SpecialInstructionSpecialInstructions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect);
                FastDriver.NewFileEntry.SpecialInstructionNewFileEntrySelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(40000);

                #endregion Create File

                #region Navigate to New File Entry page and add Escrow Service
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                Reports.TestStep = "Verify the escrow service owning office value.";
                if (FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Escrow Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Escrow owning office");
                }
                string[] AllEscrowOffices = FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under Escrow owning office.");

                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(2000);
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FASelectItemBySendingKeys("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878");
                FastDriver.BottomFrame.Done();
                #endregion Navigate to New File Entry page and add Escrow Service
                #endregion UI Iteration
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r08
        //UserStory                               : User Story 799322:REQ0909373 - NCS - Hide Select Office Names in FAST Office Selection Screens-File side-QFE/QRE/NFE
        //TestCase                                : 826644
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0107_REG0129()
        {

            string OfficeCode1 = "0";
            string OfficeBuid = "0";
            try
            {
                Reports.TestDescription = "Verify system is displaying  acive offices which are not hidden in NFE screen.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    this.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for the created office.";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }

                Playback.Wait(4000);
                Reports.TestStep = "Log into IIS.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                Reports.TestStep = "Create a Pending file-Details Tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();

                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);

                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "No Product Issued", 1, TableAction.On);
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                Playback.Wait(2000);
                FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
                FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
                FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
                FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
                FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");

                if (FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Escrow Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Escrow owning office");
                }

                string[] AllEscrowOffices = FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under escrow owning office.");

                if (FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Title Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Title owning office");
                }

                string[] AllTitleOffices = FastDriver.NewFileEntry.DetailsNewFileEntryTitleOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Title = false;
                foreach (string office in AllTitleOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Title = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Title, "Verify the Hidden Office should not be present under title owning office.");

                #endregion UI

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 823690:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Production Office selection Window- NFE
        //TestCase                                : 851756
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0107_REG0130()
        {

            Reports.TestDescription = "US# 823690: Verify the Display dropdown in the Office Selection webpage (NFE/Parties screen).";

            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
            #endregion

            #region UI Iteration

            Reports.TestStep = "Log into IIS.";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            Reports.TestStep = "Create a Pending file-Details Tab.";
            FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
            FastDriver.PendingFileSearch.ClickOnSkipSearch();
            FastDriver.NewFileEntry.WaitForScreenToLoad();
            if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
            if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
            FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
            FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
            FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
            FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
            FastDriver.NewFileEntry.ClickOnPartiesTab();

            Reports.TestStep = "Click on Add Remove Production offices(Escrow) and verify the Display dropdown.";
            FastDriver.NewFileEntry.PartiesAddRemoveEscrowproductionOffice.FAClick();
            FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
            FastDriver.OfficeSelectionDlg.Display.Exists();
            Support.AreEqualTrim(@"Active|Hidden", FastDriver.OfficeSelectionDlg.Display.FAGetAllTextFromSelect());
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Hidden");
            Playback.Wait(3000);
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Active");
            Playback.Wait(3000);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.NewFileEntry.SwitchToContentFrame();
            Playback.Wait(1000);

            Reports.TestStep = "Click on Add Remove Production offices(Title) and verify the Display dropdown.";
            FastDriver.NewFileEntry.PartiesAddRemoveTitleproductionOffice.FAClick();
            FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
            FastDriver.OfficeSelectionDlg.Display.Exists();
            Support.AreEqualTrim(@"Active|Hidden", FastDriver.OfficeSelectionDlg.Display.FAGetAllTextFromSelect());
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Hidden");
            Playback.Wait(3000);
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Active");
            Playback.Wait(3000);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.NewFileEntry.SwitchToContentFrame();
            Playback.Wait(1000);

            #endregion UI
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 823690:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Production Office selection Window- NFE
        //TestCase                                : 851757
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0107_REG0131()
        {

            string OfficeCode1 = "0";
            string OfficeBuid = "0";
            try
            {
                Reports.TestDescription = "US# 823690: Verify  Active and Hidden Offices in Currently Selected Offices section (NFE/Parties screen) which is selected in the Office Selection webpage.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    this.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    Playback.Wait(1000);
                }

                Reports.TestStep = "Log into IIS.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Pending file-Details Tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.Product1.FAClick();
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Click on Add Remove Production offices(Escrow).";
                FastDriver.NewFileEntry.PartiesAddRemoveEscrowproductionOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the Active Production offices(Escrow) and verify in the NFE screen.";
                bool status = AddEscrowProdOffice_NFE("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Active");
                Support.AreEqual("True", status.ToString());
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(3000);
                FastDriver.NewFileEntry.SwitchToContentFrame();
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Click on Add Remove Production offices(Title).";
                FastDriver.NewFileEntry.PartiesAddRemoveTitleproductionOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the avtive Production offices(Title) and verify in the NFE screen.";
                bool status1 = AddTitleProdOffice_NFE("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Active");
                Support.AreEqual("True", status1.ToString());

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", OfficeCode1, "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                Reports.TestStep = "Set the Close flag status as true for office";
                if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                }
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                Reports.TestStep = "Log into IIS.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Pending file-Details Tab.";
                FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
                FastDriver.PendingFileSearch.ClickOnSkipSearch();
                FastDriver.NewFileEntry.WaitForScreenToLoad();
                if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
                    FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem("Residential");
                FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
                FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
                FastDriver.NewFileEntry.ClickOnPartiesTab();

                Reports.TestStep = "Click on Add Remove Production offices(Escrow).";
                FastDriver.NewFileEntry.PartiesAddRemoveEscrowproductionOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the hidden Production offices(Escrow) and verify in the NFE screen.";
                //bool status = AddProdOffice("QA Automation Region - DO NOT TOUCH", "Test Automation" + OfficeCode1, "");
                bool status2 = AddEscrowProdOffice_NFE("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Hidden");
                Support.AreEqual("True", status2.ToString());
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Playback.Wait(3000);
                FastDriver.NewFileEntry.SwitchToContentFrame();
                FastDriver.NewFileEntry.ClickOnPartiesTab();


                Reports.TestStep = "Click on Add Remove Production offices(Title).";
                FastDriver.NewFileEntry.PartiesAddRemoveTitleproductionOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the hidden Production offices(Title) and verify in the NFE screen.";
                //bool status1 = AddProdOffice("QA Automation Region - DO NOT TOUCH", "Test Automation" + OfficeCode1, "Active");
                bool status3 = AddTitleProdOffice_NFE("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Hidden");
                Support.AreEqual("True", status3.ToString());


                #endregion UI

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }       


        #endregion REG

        #region Custom Class Methods

        private void Login(bool admLogin = false)
        {
            if (!admLogin)
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            else
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU
                };

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            }
        }

        private void NavigateToNewFileEntry()
        {
            FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry").WaitForScreenToLoad();
            FastDriver.PendingFileSearch.ClickOnSkipSearch();
            FastDriver.NewFileEntry.WaitForScreenToLoad();
        }

        private void DetailsNFETypesComboBoxes(string DetailsNewFileEntryBusinessSegment = "Residential", string DetailsNewFileEntryTransactionType = "Sale w/Mortgage", string DetailsNewFileEntryProgramType = "No Program Type")
        {
            FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(DetailsNewFileEntryBusinessSegment);
            FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(DetailsNewFileEntryTransactionType);
            FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem(DetailsNewFileEntryProgramType);
        }

        private void NewFileDetailsCheckBoxesCheck(bool DetailsTitlecheckbox = true, bool DetailsEscrowcheckbox = true)
        {
            //if (!FastDriver.NewFileEntry.DetailsTitlecheckbox.Selected)
            FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(DetailsTitlecheckbox);

            //if (!FastDriver.NewFileEntry.DetailsEscrowcheckbox.Selected)
            FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(DetailsEscrowcheckbox);
        }

        private void CreateFileWithWCF(CreateFileRequest fileRequest)
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }

        private void NavigateToRegionLevel()
        {
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);
            Playback.Wait(2000);
            Keyboard.SendKeys(FAKeys.Enter);
            Playback.Wait(3000);
            //FastDriver.BottomFrame.Done();
        }

        private void EnterStandardNewFileData(bool navigateToMortageBroker = true, bool navigateToNewFileEntry = true, bool save = true)
        {
            //
            Reports.TestStep = "Create details with additional role as New Lender.";
            if (navigateToNewFileEntry)
                this.NavigateToNewFileEntry();
            this.NewFileDetailsCheckBoxesCheck();
            this.DetailsNFETypesComboBoxes();
            FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, "ALTA Extended Leasehold Owners Policy", 1, TableAction.On);
            FastDriver.NewFileEntry.FindBusinessSourceGAB("HUDFLINSR1");
            FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem("New Lender");
            FastDriver.NewFileEntry.DetailsSearchType.FASelectItem("No Search Type");
            FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
            Playback.Wait(4500);
            FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Husband/Wife");

            FastDriver.NewFileEntry.DetailsBuyerHusbandName.FASetText("Buyer2Firstname");
            FastDriver.NewFileEntry.DetailsBuyerHusbandLast.FASetText("Buyer2Lastname");
            FastDriver.NewFileEntry.DetailsBuyerSpouseFirstName.FASetText("Buyer2SpouseName");
            FastDriver.NewFileEntry.DetailsAddNewSeller.FAClick();
            Playback.Wait(5000);

            FastDriver.NewFileEntry.DetailsSellerType.FASelectItem("Husband/Wife");
            FastDriver.NewFileEntry.DetailsSellerHusbandName.FASetText("Seller2Firstname");
            FastDriver.NewFileEntry.DetailsSellerHusbandLast.FASetText("Seller2Lastname");
            FastDriver.NewFileEntry.DetailsSellerSpouseName.FASetText("Seller2SpouseName");

            FastDriver.NewFileEntry.DetailsPropertyStreet1.FASetText("1 First American Way");
            FastDriver.NewFileEntry.DetailsPropertyStreet2.FASetText("PropertyStreet2");
            FastDriver.NewFileEntry.DetailsPropertyStreet3.FASetText("PropertyStreet3");
            FastDriver.NewFileEntry.DetailsPropertyStreet4.FASetText("PropertyStreet4");
            FastDriver.NewFileEntry.DetailsPropertyCity.FASetText("Santa Ana");
            FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem("CA");
            if (AutoConfig.FormType.ToLower().Equals("cd"))
            {
                FastDriver.NewFileEntry.FormType_CD.FAClick();
            }
            else
                if (AutoConfig.FormType.ToLower().Equals("hud"))
                {
                    FastDriver.NewFileEntry.FormType_HUD.FAClick();
                }

            FastDriver.NewFileEntry.DetailsPropertyZIP.FASetText("92707");
            FastDriver.NewFileEntry.DetailsPropertyCounty.FASelectItem("Orange");
            FastDriver.NewFileEntry.DetailsSalePrice.FASetText("600,000.00");
            FastDriver.NewFileEntry.DetailsFirstNewLoan.FASetText("250,000.00");
            FastDriver.NewFileEntry.DetailsSecondNewLoan.FASetText("150,000.00");
            if (save)
            {
                FastDriver.BottomFrame.Save();
                Playback.Wait(4500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            }
            //FastDriver.WebDriver.WaitForWindowAndSwitch(supp);
            if (navigateToMortageBroker)
            {//
                Reports.TestStep = "Navigate to Lender/Mortgage Broker Tab.";
                //if(FastDriver.PendingFileSearch.SkipSearch.Exists())
                //{
                //    FastDriver.PendingFileSearch.ClickOnSkipSearch();
                //}
                //FastDriver.NewFileEntry.WaitForScreenToLoad();
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers);
                FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...");
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(7500);

                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.NewLenderSummaryTable);
                //FastDriver.NewFileEntry.LenderMortgageBrokersLendersMortgageBrokers.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...", false);
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //
                Reports.TestStep = "Validate new lender in Lender Mortgage Tab.";
                // Playback.Wait(100000000);
                // FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.NewLenderSummaryTable);
                FastDriver.NewFileEntry.NewLenderSummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 2, TableAction.Click);
            }
        }

        private void CreateNewOffice()
        {
            FastDriver.OfficeSummary.New.FAClick();

            Reports.TestStep = "Enter details to newly created office.";
            FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
            Random random = new Random();
            string OfficeCode1 = random.Next(999, 10000).ToString();
            FastDriver.OfficeSetupOffice.OfficeCode.FASetText(OfficeCode1);
            FastDriver.OfficeSetupOffice.FederalTaxID.FASetText("567891234");
            FastDriver.OfficeSetupOffice.OfficeName.FASetText("SRT Test Automation Office");
            FastDriver.OfficeSetupOffice.OfficeCompanyName1.FASetText("SRT DO Not Touch Automation Office");
            FastDriver.OfficeSetupOffice.OfficeComments.FASetText("Creating a new Office");
            FastDriver.OfficeSetupOffice.OfficeLogoFile1.FASetText("Test");
            FastDriver.OfficeSetupOffice.OfficeSystemLogoFile.FASetText("Automation Test");
            FastDriver.OfficeSetupOffice.BusinessSegment.FASelectItem("Commercial");
            FastDriver.OfficeSetupOffice.Can_be_Inter_Regional_Production_office.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.FeeTransmittalType.FASelectItem("Fee Transfer");
            FastDriver.OfficeSetupOffice.TimeZone.FASelectItem("Mountain Time");
            FastDriver.OfficeSetupOffice.DivisionProductionCenter.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.NPSProductionOffice.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.StatisticalReportingOffice.FASelectItem("Agency");
            FastDriver.OfficeSetupOffice.ProductionSystem.FASelectItem("FAST deployed");
            FastDriver.OfficeSetupOffice.FileNumberSchemaPrefix.FASetText("EWS");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator1.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator2.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSuffix.FASetText("ADC");
            FastDriver.OfficeSetupOffice.DocumentNumberSchemaInvoicePrefix.FASetText("100");
            FastDriver.OfficeSetupOffice.FastStatCode.FASetText("12345");
            FastDriver.OfficeSetupOffice.CorporateParent.FASelectItemBySendingKeys("First American (FA)");
            FastDriver.OfficeSetupOffice.UnderwritersMenu.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwritersNew.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwriterName1.FASelectItem("New Underwriter");
            FastDriver.OfficeSetupUnderwriters.PremiumPercentage.FASetText("10");
            FastDriver.OfficeSetupUnderwriters.UseAsDefaultUnderwriter.FASetCheckbox(true);

            FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
            FastDriver.OfficeSetupBankAccounts.BankAccountSummaryNew.FAClick();
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName.FASelectItemBySendingKeys("Automation Bank - Automation Testing");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1.FASetText("232345");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_AccountDescription.FASetText("SRT AUTOMATION BANK");
            FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDeposit.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Bank Name", "Automation Bank - Automation Testing", "Bank Name", TableAction.Click);

            FastDriver.BottomFrame.Done();



        }

        private bool AddEscrowProdOffice_NFE(string Region, string OfficeName, string Display)
        {
            try
            {
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Region.FASelectItem(Region);
                Thread.Sleep(3000);
                FastDriver.OfficeSelectionDlg.Display.FASelectItem(Display);
                Thread.Sleep(3000);
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", OfficeName, "Sel", TableAction.On);
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the ProductionOffice added.";
                FastDriver.NewFileEntry.SwitchToContentFrame();

                bool status = false;
                for (int i = 1; i <= FastDriver.NewFileEntry.EscrowProdOfficeGridTable.GetRowCount(); i++)
                {
                    string ActualProdOfc = FastDriver.NewFileEntry.EscrowProdOfficeGridTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (AutoConfig.SelectedRegionName.Contains(Region))
                        status = ActualProdOfc.Contains(OfficeName);
                    else
                        status = ActualProdOfc.Contains(OfficeName) && ActualProdOfc.Contains(Region);
                    if (status)
                        break;
                }
                return status;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        private bool AddTitleProdOffice_NFE(string Region, string OfficeName, string Display)
        {
            try
            {
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Region.FASelectItem(Region);
                Thread.Sleep(3000);
                FastDriver.OfficeSelectionDlg.Display.FASelectItem(Display);
                Thread.Sleep(3000);
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", OfficeName, "Sel", TableAction.On);
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the ProductionOffice added.";
                FastDriver.NewFileEntry.SwitchToContentFrame();

                bool status = false;
                for (int i = 1; i <= FastDriver.NewFileEntry.TitleProdOfficeGridTable.GetRowCount(); i++)
                {
                    string ActualProdOfc = FastDriver.NewFileEntry.TitleProdOfficeGridTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (AutoConfig.SelectedRegionName.Contains(Region))
                        status = ActualProdOfc.Contains(OfficeName);
                    else
                        status = ActualProdOfc.Contains(OfficeName) && ActualProdOfc.Contains(Region);
                    if (status)
                        break;
                }
                return status;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion Custom Class Methods

        #region Class CleanUp

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

        #endregion Class CleanUp
    }
}