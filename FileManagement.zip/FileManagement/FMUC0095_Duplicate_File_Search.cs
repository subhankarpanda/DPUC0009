﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
// using AutoIt;
using System.Linq;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace FileManagement
{
    /// <summary>
    /// Summary description for FMUC005 Duplicate File Search
    /// </summary>
    [CodedUITest]

    public class FMUC0095 : MasterTestClass
    {

        Dictionary<string, string> DfsDictry = new Dictionary<string, string>();

        #region BAT

        #region Test FMUC0095_BAT0001

        /// <summary>
        /// MF1_01: Search with results for Duplicate File by Buyer Name(Individual).
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_01: Search with results for Duplicate File by Buyer Name(Individual).";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File1 With Buyer Type as Individual
                Reports.TestStep = "Create File1 using web service.";

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                // Enter Buyer type Husband/Wife  with names
                fileRequest.File.Buyers[0].Type = "Individual";
                fileRequest.File.Buyers[0].FirstName = "Buyer1Firstname";
                fileRequest.File.Buyers[0].LastName = "FMUC0095Buyer1LName";
                fileRequest.File.Buyers[0].SSN = "123-45-6789";


                // Enter Buyer type Husband/Wife with names
                fileRequest.File.Buyers[1].Type = "Husband and Wife";
                fileRequest.File.Buyers[1].FirstName = "Buyer2Firstname";
                fileRequest.File.Buyers[1].LastName = "FMUC0095Buyer2LName";
                fileRequest.File.Buyers[1].SpouseFirstName = "Buyer2SPName";
                fileRequest.File.Buyers[1].SpouseLastName = "FMUC0095Buyer2LName";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create File2 With same details as File 1 to ensure there are duplicate files.
                // Creating additonal file to ensure there are duplicate files.
                Reports.TestStep = "Create File2 using web service.";
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FileNumberEditBox.Clear();
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);
                #endregion

                #region Navigate to DFS and Search the file with specific search criteria
                Reports.TestStep = "Navigate to DFS and Search the file with specific search criteria";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText("B");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("FMUC0095");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                ValidateFileCreation();
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Clicking upon expected file number click on the Select button and  valdiate navigation to FileHomePage
                Reports.TestStep = "Clicking upon expected file number click on the Select button and  valdiate navigation to FileHomePage";
                FastDriver.DuplicateFileSearchResults.ClickSelect();
                #endregion

                #region Validate the file number in file home page
                Reports.TestStep = "Validate the file number in file home page";
                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0095_BAT0002
        [TestMethod, Obsolete]
        public void FMUC0095_BAT0002()
        {
            Reports.TestDescription = @"MF1_01_Setup: Create order for all search criteria used in next flows. ( Covered in respective TestMethods )";
            Reports.StatusUpdate("Additional orders created at each test method to ensure data is available.", true);
        }
        #endregion

        #region Test FMUC0095_BAT0003
        /// <summary>
        /// MF1_00: Search with results for Duplicate File by Buyer Name(Husband/Wife).
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Search with results for Duplicate File by Buyer Name(Husband/Wife).";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File1 With Buyer Type as Husband/wife
                Reports.TestStep = "Create File1 using web service.";

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                // Enter Buyer type Husband/Wife  with names
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "SPBuyer1Firstname";
                fileRequest.File.Buyers[0].LastName = "SPBuyer1LastName";
                fileRequest.File.Buyers[0].SpouseFirstName = "SPBuyer1Spouse";
                fileRequest.File.Buyers[0].SpouseLastName = "SPBuyer1LastName";
                fileRequest.File.Buyers[0].SSN = "123-45-6789";


                // Enter Buyer type Husband/Wife with names
                fileRequest.File.Buyers[1].Type = "Husband and Wife";
                fileRequest.File.Buyers[1].FirstName = "SPBuyer2Firstname";
                fileRequest.File.Buyers[1].LastName = "SPBuyer2LastName";
                fileRequest.File.Buyers[1].SpouseFirstName = "SPBuyer2Spouse";
                fileRequest.File.Buyers[1].SpouseLastName = "SPBuyer2LastName";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create File2 With same details as File 1 to ensure there are duplicate files.
                // Creating additonal file to ensure there are duplicate files.
                Reports.TestStep = "Create File2 using web service.";
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FileNumberEditBox.Clear();
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);
                #endregion

                #region Navigate to DFS and Search the file with specific search criteria
                Reports.TestStep = "Navigate to DFS and Search the file with specific search criteria";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Husband/Wife");
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText("SPBuyer1");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("SPBuyer1Last");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                ValidateFileCreation();
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page.";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Clicking upon expected file number click on the Select button and  valdiate navigation to FileHomePage
                Reports.TestStep = "Clicking upon expected file number click on the Select button and  valdiate navigation to FileHomePage";
                FastDriver.DuplicateFileSearchResults.ClickSelect();
                #endregion

                #region Validate the file number in file home page
                Reports.TestStep = "Validate the file number in file home page";
                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion

        #region Test FMUC0095_BAT0004
        /// <summary>
        /// MF1_02: Search with results for Duplicate File by Buyer Name(Trust/Estate).
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0004()
        {
            try
            {
                Reports.TestDescription = "MF1_02: Search with results for Duplicate File by Buyer Name(Trust/Estate).";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File With Buyer Type as Trust/Estate
                Reports.TestStep = "Create File1 using web service.";

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                // Enter Buyer type Trust Estate with name and TIN
                fileRequest.File.Buyers[0].Type = "Trust/Estate";
                fileRequest.File.Buyers[0].Name = "Trstbuyer1";
                fileRequest.File.Buyers[0].TIN = "12-3456789";

                // Enter Buyer type Husband/Wife with names
                fileRequest.File.Buyers[1].Type = "Husband and Wife";
                fileRequest.File.Buyers[1].FirstName = "TrstBuyer2FN";
                fileRequest.File.Buyers[1].LastName = "Trst95Buyer2LN";
                fileRequest.File.Buyers[1].SpouseFirstName = "TrstBuyer2SN";
                fileRequest.File.Buyers[1].SpouseLastName = "Trst95Buyer2LN";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create File2 With same details as File 1 to ensure there are duplicate files.
                // Creating additonal file to ensure there are duplicate files.
                Reports.TestStep = "Create File2 using web service.";
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FileNumberEditBox.Clear();
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);
                #endregion

                #region Navigate to DFS and enter the specific search criteria
                Reports.TestStep = "Navigate to DFS and enter the specific search criteria";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText("Trstbuyer1");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                ValidateFileCreation();
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Clicking upon expected file number click on the View button and valdiate FileSummary dialog is loaded
                Reports.TestStep = "Clicking upon expected file number click on the View button and valdiate FileSummary dialog is loaded.";
                FastDriver.DuplicateFileSearchResults.ClickView();
                FastDriver.FileSummaryDlg.WaitForScreenToLoad();
                FastDriver.FileSummaryDlg.SwitchToDialogContentFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Validate the DFSearchResults title, click on Go Back and Validate DuplicateFileSearch label.
                Reports.TestStep = "Validate the DFSearchResults title, click on Go Back and Validate DuplicateFileSearch label";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DuplicateFileSearchResults.SwitchToContentFrame();
                FastDriver.DuplicateFileSearchResults.ClickGoBack();
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                #endregion

                #region Navigate to DFS and Search the file with specific search criteria
                Reports.TestStep = "Navigate to DFS and Search the file with specific search criteria.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText("Trstbuyer1");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Clicking upon expected file number click on the Continue button and valdiate QFE is loaded with DFS Buyer Data.
                Reports.TestStep = "Clicking upon expected file number click on the Continue button and valdiate QFE is loaded with DFS Buyer Data.";
                FastDriver.DuplicateFileSearchResults.ClickContinue();
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Support.AreEqual("Trust/Estate", FastDriver.QuickFileEntry.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Trstbuyer1", FastDriver.QuickFileEntry.Buyer1FirstName.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_BAT0005
        /// <summary>
        /// AF1_00: Search with results for Duplicate File by Property Address.
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF1_00: Search with results for Duplicate File by Property Address.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File With Specific Property details.
                Reports.TestStep = "Create File1 using web service.";

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                // Enter Buyer type Husband/Wife  with names
                fileRequest.File.Buyers[0].Type = "Individual";
                fileRequest.File.Buyers[0].FirstName = "Buyer1Firstname";
                fileRequest.File.Buyers[0].LastName = "FMUC0095Buyer1LName";
                fileRequest.File.Buyers[0].SSN = "123-45-6789";


                // Enter Buyer type Husband/Wife with names
                fileRequest.File.Buyers[1].Type = "Husband and Wife";
                fileRequest.File.Buyers[1].FirstName = "Buyer2Firstname";
                fileRequest.File.Buyers[1].LastName = "FMUC0095Buyer2LName";
                fileRequest.File.Buyers[1].SpouseFirstName = "Buyer2SPName";
                fileRequest.File.Buyers[1].SpouseLastName = "FMUC0095Buyer2LName";

                // Enter Property address details
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "AL1FMUC0095";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine2 = "AL2FMUC0095";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine3 = "AL3FMUC0095";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Athens";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Fulton";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "97020";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create File2 With same property address deatils as File 1 to ensure there are duplicate files.
                // Creating additonal file to ensure there are duplicate files.
                Reports.TestStep = "Create File2 using web service.";
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FileNumberEditBox.Clear();
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);
                #endregion

                #region Navigate to DFS and Search the file with specific search criteria
                Reports.TestStep = "Navigate to DFS and enter the property details for Search.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("AL1FMUC0095");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("Athens");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("GA");
                FastDriver.DuplicateFileSearch.ClickFindNow();

                ValidateFileCreation();
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page.";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Click on expected file number and click on the Select button
                Reports.TestStep = "Click on Select in DFS results page.";
                FastDriver.DuplicateFileSearchResults.ClickSelect();
                #endregion

                #region Validate navigation to FileHomePage and file number.
                Reports.TestStep = "Validate navigation to FileHomePage and the file number.";
                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                #endregion

                #region Navigate to DFS and Search the file with specific search criteria
                Reports.TestStep = "Navigate to Duplicate File Search and enter the property details for search.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("AL1FMUC0095");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("Athens");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("GA");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Clicking upon expected file number click on the View button and Validate that FileSummary dialog is loaded for the same file.
                Reports.TestStep = "Clicking upon expected file number click on the View button and Validate that FileSummary dialog is loaded for the same file.";
                ValidateFileSearch(FileNumber1);
                FastDriver.DuplicateFileSearchResults.ClickView();
                FastDriver.FileSummaryDlg.WaitForScreenToLoad();
                FastDriver.FileSummaryDlg.SwitchToDialogContentFrame();
                string FileFromFileSumamryDlg = FastDriver.FileSummaryDlg.FileNo.FAGetText().ToString().Trim();
                Support.AreEqual(FileNumber1, FileFromFileSumamryDlg, true);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Validate the DFSearchResults title, click on Go Back and Validate the Property details in DuplicateFileSearch.
                Reports.TestStep = "Validate the DFSearchResults title, click on Go Back and Validate the Property details in DuplicateFileSearch.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DuplicateFileSearchResults.SwitchToContentFrame();
                FastDriver.DuplicateFileSearchResults.ClickGoBack();
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                Support.AreEqual("AL1FMUC0095", FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Athens", FastDriver.DuplicateFileSearch.PropertyAddressCity.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("GA", FastDriver.DuplicateFileSearch.PropertyAddressState.FAGetSelectedItem().ToString().Trim(), true);
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Clicking upon expected file number click on the Continue button and valdiate QFE is loaded with DFS Buyer Data.
                Reports.TestStep = "Clicking upon expected file number click on the Continue button and valdiate QFE is loaded with DFS Buyer Data";
                ValidateFileSearch(FileNumber1);
                FastDriver.DuplicateFileSearchResults.ClickContinue();
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Support.AreEqual("AL1FMUC0095", FastDriver.QuickFileEntry.PropertyBookAddrLin1.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Athens", FastDriver.QuickFileEntry.PropertyCity.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("GA", FastDriver.QuickFileEntry.PropertyState.FAGetSelectedItem().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_BAT0006
        /// <summary>
        /// AF2_00: Search with results for Duplicate file by Lender Reference Number.
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF2_00: Search with results for Duplicate file by Lender Reference Number.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File With Specific Lender GAB and Reference details.
                Reports.TestStep = "Create File1 using WCF.";

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                fileRequest.File.NewLoan.LoanNumber = "950012345";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create File2 With same Lender GAB and Reference deatils as File 1 to ensure there are duplicate files.
                Reports.TestStep = "Creating additonal file to ensure there are duplicate files.";
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                #endregion

                #region Navigate to DFS and Search the file with specific search criteria
                Reports.TestStep = "Navigate to DFS and enter the Lender details for Search.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.GABcode.FASetText("247");
                FastDriver.DuplicateFileSearch.Find.FAClick();
                FastDriver.DuplicateFileSearch.Reference.FASetText("950012345");
                FastDriver.DuplicateFileSearch.ClickFindNow();

                ValidateFileCreation();
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page.";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Click on expected file number and click on the Select button
                Reports.TestStep = "Click on Select in DFS results page.";
                FastDriver.DuplicateFileSearchResults.ClickSelect();
                #endregion

                #region Validate navigation to FileHomePage and file number.
                Reports.TestStep = "Validate navigation to FileHomePage and the file number.";
                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                #endregion

                #region Navigate to DFS and Search the file with specific search criteria
                Reports.TestStep = "Navigate to DFS and enter the property details for Search.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.GABcode.FASetText("247");
                FastDriver.DuplicateFileSearch.Find.FAClick();
                FastDriver.DuplicateFileSearch.Reference.FASetText("950012345");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate the file in DFSearchResults and click on Go Back
                Reports.TestStep = "Validate the presence of expected file in DFS results page.";
                ValidateFileSearch(FileNumber1);
                FastDriver.DuplicateFileSearchResults.ClickGoBack();
                #endregion

                #region Validate the Lender details in DFS page on click of Go Back.
                Reports.TestStep = "Validate the Lender details in DFS page on click of Go Back";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.DuplicateFileSearch.GABIDCode.FAGetText().ToString().Trim(), true);
                Support.AreEqual("950012345", FastDriver.DuplicateFileSearch.Reference.FAGetValue().ToString().Trim(), true);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_BAT0007
        /// <summary>
        /// AF4_00: Search without results for a Duplicate File from QFE.
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Search without results for a Duplicate File from QFE.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Navigate to DFS, Enter invalid property and click on FIND.
                Reports.TestStep = "Navigate to DFS, Enter invalid property and click on FIND.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("ZZZ");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("AAA");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Click on Cancel and validate Duplicate File Search label.
                Reports.TestStep = "Click on Cancel and validate Duplicate File Search label";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: false);
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                #endregion

                #region Navigate to DFS, Enter invalid property and click on FIND.
                Reports.TestStep = "Navigate to DFS, Enter invalid property and click on FIND.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("ZZZ");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("AAA");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Click on OK and validate Duplicate File Search label.
                Reports.TestStep = "Click on OK and validate QFE label";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_BAT0008
        /// <summary>
        /// AF4_01: Search without results for a Duplicate File from QRE.
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF4_01: Search without results for a Duplicate File from QRE.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Navigate to DFS, Enter invalid property and click on FIND.
                Reports.TestStep = "Navigate to DFS, Enter invalid property and click on FIND.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick Refi Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("ZZZ");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("AAA");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Click on Cancel and validate Duplicate File Search label.
                Reports.TestStep = "Click on Cancel and validate Duplicate File Search label";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: false);
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                #endregion

                #region Navigate to DFS, Enter invalid property and click on FIND.
                Reports.TestStep = "Navigate to DFS, Enter invalid property and click on FIND.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick Refi Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("ZZZ");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("AAA");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Click on Ok and validate Quick Refi Entry label.
                Reports.TestStep = "Click on Ok and validate Quick Refi Entry label.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.QuickRefiFileEntry.SwitchToContentFrame();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_BAT0009
        /// <summary>
        /// AF1_00: Search with results for Duplicate File by Buyer(Business Entity).";
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF1_00: Search with results for Duplicate File by Buyer(Business Entity).";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File With Buyer Type as Business Entity
                Reports.TestStep = "Create File1 using web service.";

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                // Enter Buyer type Trust Estate with name and TIN
                fileRequest.File.Buyers[0].Type = "Business Entity";
                fileRequest.File.Buyers[0].Name = "BEbuyer1FMUC0095";

                // Enter Buyer type Husband/Wife with names
                fileRequest.File.Buyers[1].Type = "Husband and Wife";
                fileRequest.File.Buyers[1].FirstName = "BE2BuyerName";
                fileRequest.File.Buyers[1].LastName = "BE95Buyer2LN";
                fileRequest.File.Buyers[1].SpouseFirstName = "BEBuyer2Sp";
                fileRequest.File.Buyers[1].SpouseLastName = "BE95Buyer2LN";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create File2 With same details as File 1 to ensure there are duplicate files.
                // Creating additonal file to ensure there are duplicate files.
                Reports.TestStep = "Create File2 using web service.";
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FileNumberEditBox.Clear();
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);
                #endregion

                #region Navigate to DFS and enter Enter first 15 character in Business Entity Name
                Reports.TestStep = "Navigate to DFS and Enter first 15 character in Business Entity Name";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Business Entity");
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText("BEbuyer1FMUC009");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                ValidateFileCreation();
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Click on expected file number and click on the Select button
                Reports.TestStep = "Click on Select in DFS results page.";
                FastDriver.DuplicateFileSearchResults.ClickSelect();
                #endregion

                #region Validate navigation to FileHomePage and file number.
                Reports.TestStep = "Validate navigation to FileHomePage and the file number.";
                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_BAT0010
        /// <summary>
        /// AF4_00: Search without results for a Duplicate File from QFE.
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0010()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Search without results for a Duplicate File from QFE.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Navigate to DFS, Enter invalid property and click on FIND.
                Reports.TestStep = "Navigate to DFS, Enter invalid property and click on FIND.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("RandomBuyer");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate the message, Click on Cancel and validate Duplicate File Search label.
                Reports.TestStep = "Validate the message, Click on Cancel and validate Duplicate File Search label";
                Support.AreEqual("No matching record found. Do you want to continue to Open Order?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: false), true);
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                #endregion

                #region Navigate to DFS, Enter invalid property and click on FIND.
                Reports.TestStep = "Navigate to DFS, Enter invalid property and click on FIND.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("RandomBuyer");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate the message, Click on OK and validate Quick File Entry label.
                Reports.TestStep = "Validate the message, Click on Cancel and validate Quick File Entry label";
                Support.AreEqual("No matching record found. Do you want to continue to Open Order?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true), true);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_BAT0011_EXPECTEDFAILURE
        /// <summary>
        /// AF2_00: Search with results for Duplicate file by Lender Reference Number.TFS#19762 Is logged for this
        /// </summary>
        [TestMethod]
        public void FMUC0095_BAT0011_EXPECTEDFAILURE()
        {
            try
            {
                Reports.TestDescription = "AF2_00: Search with results for Duplicate file by Lender Reference Number.TFS#19762 Is logged for this";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File With Specific Lender GAB and Reference details.

                Reports.TestStep = "Create File1 using WCF.";

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                fileRequest.File.NewLoan.LoanNumber = "123456qaw";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create File2 With same Lender GAB and Reference deatils as File 1 to ensure there are duplicate files.
                Reports.TestStep = "Creating additonal file to ensure there are duplicate files.";
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                #endregion

                #region Navigate to DFS and Search the file with specific search criteria
                Reports.TestStep = "Navigate to DFS and enter the Lender details for Search.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.GABcode.FASetText("247");
                FastDriver.DuplicateFileSearch.Find.FAClick();
                FastDriver.DuplicateFileSearch.Reference.FASetText("123456qaw");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page.";
                ValidateFileSearch(FileNumber1);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion


        #endregion BAT

        #region Regression


        #region Test FMUC0095_REG0001

        /// <summary>
        /// FM6159_FM6160_FM6161_FM6163_FM6164_FM6165_EWC2__FM6170_HK: Duplicate File Search Screen/Lender Reference Number Search /Property Address Line Search.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM6159_FM6160_FM6161_FM6163_FM6164_FM6165_EWC2__FM6170_HK: Duplicate File Search Screen/Lender Reference Number Search /Property Address Line Search.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion Login

                #region Create File
                Reports.TestStep = "Create File1 using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var RandomBuyer1LastName = Support.RandomString("AAAA") + "FMUC0095";
                // Enter Buyer type Individual  with names
                fileRequest.File.Buyers[0].Type = "Individual";
                fileRequest.File.Buyers[0].FirstName = "Buyer1Firstname";
                fileRequest.File.Buyers[0].LastName = RandomBuyer1LastName;
                fileRequest.File.Buyers[0].SSN = "123-45-6789";


                // Enter Buyer type Husband/Wife with names
                fileRequest.File.Buyers[1].Type = "Husband and Wife";
                fileRequest.File.Buyers[1].FirstName = "Buyer2Firstname";
                fileRequest.File.Buyers[1].LastName = "FMUC0095Buyer2LName";
                fileRequest.File.Buyers[1].SpouseFirstName = "Buyer2SPName";
                fileRequest.File.Buyers[1].SpouseLastName = "FMUC0095Buyer2LName";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion Create File

                #region Click on FINDNOW without giiving mandatory search criteria and Validate the message for Required Search Criteria.
                Reports.TestStep = "Click on FINDNOW without giiving mandatory search criteria";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickFindNow();
                string EWMessage1 = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true).ToString().Replace("\r", string.Empty).Replace("\n", string.Empty);
                Support.AreEqual("Search cannot be executed without one of the following:1) Buyer Last Name/Entity Name2) APN/Tax No.3) Property Street Line 1, City and State4) Lender and Reference", EWMessage1, true);
                #endregion

                #region Property Address Line Search with only one character in property address street1
                Reports.TestStep = "Property Address Line Search with only one character in property address street1.";
                FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("Bu");
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.DuplicateFileSearch.Buyer2LastName.FASetText("Bu");
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("J");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("ALB");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.GABcode.FASetText("HUDFLINSR1");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate error message for Search with only one character in property address street1
                Reports.TestStep = "Valdiate the error message for Search with only one character in property address street1.";
                Support.AreEqual("At least 2 characters must be entered in Street Line 1 to search by Property.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true), true);
                #endregion

                #region Search the file with buyername (individual) with single character at last name.
                Reports.TestStep = "Search the file with buyername (individual) with single character at last name.";
                FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("B");
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.DuplicateFileSearch.Buyer2LastName.FASetText("Bu");
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("J305");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("ALB");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.GABcode.FASetText("HUDFLINSR1");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate error message for Search the file with buyername (individual) with single character at last name
                Reports.TestStep = "Valdiate the error message for Search the file with buyername (individual) with single character at last name";
                Support.AreEqual("At least 2 characters must be entered in Buyer Last Name.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true), true);
                #endregion

                #region Search the file with buyername (husband/wife) with single character at last name.
                Reports.TestStep = "Search the file with buyername (husband/wife) with single character at last name.";
                FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText(RandomBuyer1LastName);
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.DuplicateFileSearch.Buyer2LastName.FASetText("B");
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("J305");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("ALB");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.GABcode.FASetText("HUDFLINSR1");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate error message for Search the file with buyername (husband/wife) with single character at last name
                Reports.TestStep = "Valdiate the error message for Search the file with buyername (husband/wife) with single character at last name";
                Support.AreEqual("At least 2 characters must be entered in Buyer Last Name.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true), true);
                #endregion

                #region Search the file with Property Address with single character Entered at City Name.
                Reports.TestStep = "Search the file with Property Address with single character Entered at City Name.";
                FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText(RandomBuyer1LastName);
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.DuplicateFileSearch.Buyer2LastName.FASetText("FMUC0095");
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("J305");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("A");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.GABcode.FASetText("HUDFLINSR1");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate error message for Search the file with Property Address with single character Entered at City Name
                Reports.TestStep = "Valdiate the error message for Search the file with Property Address with single character Entered at City Name";
                Support.AreEqual("At least 2 characters must be entered in City to search by Property.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true), true);
                #endregion

                #region Duplicate file search with valid search criteria
                Reports.TestStep = "Search the file with valid search criteria.";
                DfsDictry.Add("Buyer1Type", "Individual");
                DfsDictry.Add("Buyer1LastName", RandomBuyer1LastName);//RandomBuyer1LastName);
                DfsDictry.Add("Buyer2Type", "Husband/Wife");
                DfsDictry.Add("Buyer2LastName", "FMUC0095");
                DfsDictry.Add("PropertyAddressStreet1", "J305");
                DfsDictry.Add("PropertyAddressCity", "ALB");
                DfsDictry.Add("PropertyAddressState", "CA");

                DFSforValidSearchCriteriaUsingDict(DfsDictry);
                ValidateFileCreationUsingDict(DfsDictry);

                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region On selecting the file click Select and valdiate the Filenum, buyer and property details in File Home Page
                Reports.TestStep = "On selecting the file click Select and valdiate the Filenum, buyer and property details in File Home Page";
                FastDriver.DuplicateFileSearchResults.ClickSelect();
                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                //These two depend on the environment
                //Support.AreEqual("QAPF", FastDriver.FileHomepage.FileNumPrefix.FAGetValue().ToString().Trim(), true);
                //Support.AreEqual("QASF", FastDriver.FileHomepage.FileNumSufix.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("CA", FastDriver.FileHomepage.PropertyState.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual(RandomBuyer1LastName, FastDriver.FileHomepage.Buyer1LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Buyer2SPName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("FMUC0095Buyer2LName", FastDriver.FileHomepage.Buyer2LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Done();


                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0002

        /// <summary>
        /// FM6162_FM6158_FM6171_FD: Trust/Business Entity Buyer Name Search/Search Result Display/Required Search Criteria.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM6162_FM6158_FM6171_FD: Trust/Business Entity Buyer Name Search/Search Result Display/Required Search Criteria.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion Login

                #region Create File
                Reports.TestStep = "Create File1 using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                string RandomBuyerName = Support.RandomString("AAAA") + "FMUC0095";
                // Enter Buyer type Trust/Estate  with names
                fileRequest.File.Buyers[0].Type = "Trust/Estate";
                fileRequest.File.Buyers[0].Name = RandomBuyerName;

                // Enter Buyer type Business Entity with names
                fileRequest.File.Buyers[1].Type = "Business Entity";
                fileRequest.File.Buyers[1].Name = "Buyer2EntityName";

                // Enter Seller type Trust/Estate  with names
                fileRequest.File.Sellers[0].Type = "Trust/Estate";
                fileRequest.File.Sellers[0].Name = "Seller1TrustName";

                // Enter Seller type Business Entity with names
                fileRequest.File.Sellers[1].Type = "Business Entity";
                fileRequest.File.Sellers[1].Name = "Seller2EntityName";

                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BUYATTRNY");

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion Create File

                #region Enter the Trust Buyer Name of four character.
                Reports.TestStep = "Enter the Trust Buyer Name of four character.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText("Trus");
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Business Entity");
                FastDriver.DuplicateFileSearch.Buyer2FirstName.FASetText("Buyer");
                FastDriver.DuplicateFileSearch.GABcode.FASetText("BUYATTRNY");
                FastDriver.DuplicateFileSearch.Find.FAClick();
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate error message for Search with Trust Buyer Name of four character
                Reports.TestStep = "Validate error message for Search with Trust Buyer Name of four character";
                Support.AreEqual("At least 5 characters must be entered for the search by Buyer Entity name.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true), true);
                #endregion

                #region Enter the Business Entity Buyer Name of four character.
                Reports.TestStep = "Enter the Business Entity Buyer Name of four character.";
                FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText(RandomBuyerName);
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Business Entity");
                FastDriver.DuplicateFileSearch.Buyer2FirstName.FASetText("Buye");
                FastDriver.DuplicateFileSearch.GABcode.FASetText("BUYATTRNY");
                FastDriver.DuplicateFileSearch.Find.FAClick();
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate error message for Search with Enter the Business Entity Buyer Name of four character.
                Reports.TestStep = "Valdiate the error message for Search Enter the Business Entity Buyer Name of four character.";
                Support.AreEqual("At least 5 characters must be entered for the search by Buyer Entity name.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true), true);
                #endregion

                #region Search with the Valid Trust/estate and Business Entity buyer name
                Reports.TestStep = "Search with the Valid Trust/estate and Business Entity buyer name.";
                DfsDictry.Add("Buyer1Type", "Trust/Estate");
                DfsDictry.Add("Buyer1FirstName", RandomBuyerName);
                DfsDictry.Add("Buyer2Type", "Business Entity");
                DfsDictry.Add("Buyer2FirstName", "Buyer");
                DfsDictry.Add("GABcode", "BUYATTRNY");
                this.DFSforValidSearchCriteriaUsingDict(DfsDictry);
                this.ValidateFileCreationUsingDict(DfsDictry);

                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region On selecting the file click Select and valdiate the Filenum, buyer and property details in File Home Page
                Reports.TestStep = "On selecting the file click Select and valdiate the Filenum, buyer and property details in File Home Page";
                FastDriver.DuplicateFileSearchResults.ClickSelect();
                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                //These two depend on the environment
                //Support.AreEqual("QAPF", FastDriver.FileHomepage.FileNumPrefix.FAGetValue().ToString().Trim(), true);
                //Support.AreEqual("QASF", FastDriver.FileHomepage.FileNumSufix.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("CA", FastDriver.FileHomepage.PropertyState.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Trust/Estate", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual(RandomBuyerName, FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Business Entity", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Buyer2EntityName", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Trust/Estate", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Seller1TrustName", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Business Entity", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Seller2EntityName", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Done();


                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0003
        /// <summary>
        /// FM6172_FM6173_FM6174_EWC1: Display when No Match/Display and Populate QFE Screen from Duplicate FS/Display and Populate QRE Screen from Duplicate FS.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM6172_FM6173_FM6174_EWC1: Display when No Match/Display and Populate QFE Screen from Duplicate FS/Display and Populate QRE Screen from Duplicate FS.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion Login

                #region Enter randaom search criteria in DFS for no match records- From QFE.
                Reports.TestStep = "Enter randaom search criteria in DFS from QFE for no match records.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("ZZZZ");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate error message for search with random search criteria for which no macthing records are available.
                Support.AreEqual("No matching record found. Do you want to continue to Open Order?", FastDriver.WebDriver.HandleDialogMessage(true, true, 10));
                #endregion

                #region Validate Buyer data from DFS to create a new order in QFE.
                Reports.TestStep = "Validate Buyer data from DFS to create a new order in QFE.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual("Individual", FastDriver.QuickFileEntry.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("ZZZZ", FastDriver.QuickFileEntry.Buyer1LastName.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion

                #region Enter randaom search criteria in DFS for no match records- From QRE.
                Reports.TestStep = "Enter randaom search criteria in DFS from QRE for no match records.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick Refi Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("ZZZZ");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate error message for search with random search criteria for which no macthing records are available.
                Support.AreEqual("No matching record found. Do you want to continue to Open Order?", FastDriver.WebDriver.HandleDialogMessage(true, true, 10));
                #endregion

                #region Validate Buyer data from DFS to create a new order in QRE.
                Reports.TestStep = "Validate Buyer data from DFS to create a new order in QRE.";
                FastDriver.QuickRefiFileEntry.SwitchToContentFrame();
                Support.AreEqual("Individual", FastDriver.QuickRefiFileEntry.Borrower1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("ZZZZ", FastDriver.QuickRefiFileEntry.Borrower1LastName.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0004

        /// <summary>
        /// FM6173_1_FM6174_1_HK: Display and Populate QFE and QRE Screen from Duplicate FS Results.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM6173_1_FM6174_1_HK: Display and Populate QFE and QRE Screen from Duplicate FS Results.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order
                Reports.TestStep = "Create order with Buyer names.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                // Enter Buyer type Trust/Estate  with names
                fileRequest.File.Buyers[0].Type = "Individual";
                fileRequest.File.Buyers[0].FirstName = "Buyer1Firstname";
                fileRequest.File.Buyers[0].LastName = "FMUC0095Buyer1LName";

                // Enter Buyer type Business Entity with names
                fileRequest.File.Buyers[1].Type = "Husband and Wife";
                fileRequest.File.Buyers[1].FirstName = "Buyer2Firstname";
                fileRequest.File.Buyers[1].LastName = "FMUC0095Buyer2LName";
                fileRequest.File.Buyers[1].SpouseFirstName = "Buyer2SpouseName";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion Create File

                #region Duplicate File Search with Buyer names
                Reports.TestStep = "Enter the complete buyer details in DFS Screen from QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                DfsDictry.Add("Buyer1Type", "Individual");
                DfsDictry.Add("Buyer1LastName", "FMUC0095");
                DfsDictry.Add("Buyer2Type", "Husband/Wife");
                DfsDictry.Add("Buyer2LastName", "FMUC0095");
                DfsDictry.Add("PropertyAddressStreet1", "J305");
                DfsDictry.Add("PropertyAddressCity", "ALB");
                DfsDictry.Add("PropertyAddressState", "CA");
                DfsDictry.Add("GABcode", "HUDFLINSR1");
                this.DFSforValidSearchCriteriaUsingDict(DfsDictry);
                this.ValidateFileCreationUsingDict(DfsDictry);
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region On selecting the file click Continue and valdiate the DFS data in QFE
                Reports.TestStep = "On selecting the file click Continue and validate the DFS data in QFE";
                FastDriver.DuplicateFileSearchResults.ClickContinue();
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Support.AreEqual("Individual", FastDriver.QuickFileEntry.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("FMUC0095", FastDriver.QuickFileEntry.Buyer1LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.QuickFileEntry.Buyer2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("FMUC0095", FastDriver.QuickFileEntry.Buyer2LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("FMUC0095", FastDriver.QuickFileEntry.Buyer2SpouseLastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("J305", FastDriver.QuickFileEntry.PropertyBookAddrLin1.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("ALB", FastDriver.QuickFileEntry.PropertyCity.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("CA", FastDriver.QuickFileEntry.PropertyState.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("HUDFLINSR1", FastDriver.QuickFileEntry.LenderIdCode.FAGetText().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion

                #region Duplicate File Search with Buyer names
                Reports.TestStep = "Enter the complete buyer details in DFS Screen from QRE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick Refi Entry").WaitForScreenToLoad();
                this.DFSforValidSearchCriteriaUsingDict(DfsDictry);
                #endregion

                #region Validate the presence of expected file in DFS results page
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region On selecting the file click Continue and valdiate the DFS data in QRE
                Reports.TestStep = "On selecting the file click Continue and validate the DFS data in QRE";
                FastDriver.DuplicateFileSearchResults.ClickContinue();
                FastDriver.QuickRefiFileEntry.SwitchToContentFrame();
                Support.AreEqual("Individual", FastDriver.QuickRefiFileEntry.Borrower1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("FMUC0095", FastDriver.QuickRefiFileEntry.Borrower1LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.QuickRefiFileEntry.Borrower2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("FMUC0095", FastDriver.QuickRefiFileEntry.Borrower2LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("FMUC0095", FastDriver.QuickRefiFileEntry.BorrowerSpouseLastName.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0005

        /// <summary>
        /// FM6179 : File Status Not Displayed.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM6179 : File Status Not Displayed.  ";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order
                Reports.TestStep = "Create order with specific property details.";
                Random RandomNum = new Random();
                int SuffixNum = RandomNum.Next(0, 9);
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HW1");

                // Enter Property address details
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "J306_" + SuffixNum.ToString();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine2 = "J306_" + (SuffixNum + 1).ToString();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine3 = "J306_" + (SuffixNum + 2).ToString();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine4 = "J306_" + (SuffixNum + 3).ToString();
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ASHLEY";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AR";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Washington";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "43003";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion Create File

                #region Duplicate File Search with property address details
                Reports.TestStep = "Enter the complete Property details in DFS Screen.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                DfsDictry.Add("PropertyAddressStreet1", "J306_" + SuffixNum.ToString());
                DfsDictry.Add("PropertyAddressStreet2", "J306_" + (SuffixNum + 1).ToString());
                DfsDictry.Add("PropertyAddressStreet3", "J306_" + (SuffixNum + 2).ToString());
                DfsDictry.Add("PropertyAddressStreet4", "J306_" + (SuffixNum + 3).ToString());
                DfsDictry.Add("PropertyAddressCity", "ASHLEY");
                DfsDictry.Add("PropertyAddressState", "AR");
                this.DFSforValidSearchCriteriaUsingDict(DfsDictry);
                this.ValidateFileCreationUsingDict(DfsDictry);
                #endregion

                #region Validate the presence of expected file in DFS results page.
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Navigate to TDS screen and Change file status From Open to Cancelled.
                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Cancelled.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");
                string SettlementDate = DateTime.Now.Date.ToString().Trim();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(SettlementDate);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate the status of File as Cancelled in TDS.
                Reports.TestStep = "Navigate to TDS screen and Change file status From Open to Cancelled.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().ToString().Trim(), true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Duplicate File Search with property details.
                Reports.TestStep = "Duplicate File Search with property details.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                Reports.TestStep = "Enter the complete Property details in DFS Screen.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                this.DFSforValidSearchCriteriaUsingDict(DfsDictry);
                #endregion

                #region Validate that Cancelled file is not available.
                Reports.TestStep = "Validate that Cancelled file is not available.";
                this.ValidateFileNotAvailable(DfsDictry);
                #endregion

                #region Navigate to TDS screen and Change file status From Cancelled to Open In Error
                Reports.TestStep = "Navigate to TDS screen and Change file status From Cancelled to Open In Error.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open In Error");
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(SettlementDate);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate the status of File as Open In Error in TDS.
                Reports.TestStep = "Navigate to TDS screen and Change file status From Cancelled to Open In Error.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open In Error", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().ToString().Trim(), true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Duplicate File Search with property details.
                Reports.TestStep = "Enter the complete Property details in DFS Screen.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                this.DFSforValidSearchCriteriaUsingDict(DfsDictry);
                #endregion

                #region Validate that Open In Error file is not available.
                Reports.TestStep = "Validate that Open In Error file is not available.";
                this.ValidateFileNotAvailable(DfsDictry);
                #endregion

                #region Navigate to TDS screen and Change file status From Open In Error to Open
                Reports.TestStep = "Navigate to TDS screen and Change file status From Open In Error to Open.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open");
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(SettlementDate);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate the status of File as Open in TDS.
                Reports.TestStep = "Navigate to TDS screen and Change file status From Open in Error to Open.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().ToString().Trim(), true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Duplicate File Search with property details.
                Reports.TestStep = "Enter the complete Property details in DFS Screen.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                this.DFSforValidSearchCriteriaUsingDict(DfsDictry);
                #endregion

                #region Validate that Open file is available.
                Reports.TestStep = "Validate that Open file is available.";
                this.ValidateFileCreationUsingDict(DfsDictry);
                #endregion

                #region Validate the presence of expected file in DFS results page.
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0006

        /// <summary>
        /// FM6183_FM6184_HK: Display and Populate QFE from Basic File Info/Display and Populate QRE from Basic File Info.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM6183_FM6184_HK: Display and Populate QFE from Basic File Info/Display and Populate QRE from Basic File Info.";

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order
                Reports.TestStep = "Create order with specific property details.";
                var RandomBuyerLastName = Support.RandomString("AAAA") + "FMUC0095";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                fileRequest.File.Buyers[0].Type = "Individual";
                fileRequest.File.Buyers[0].LastName = RandomBuyerLastName;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion Create File

                #region Duplicate File Search with property details From QFE
                Reports.TestStep = "Enter the complete Property details in DFS Screen from QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                DfsDictry.Add("Buyer1Type", "Individual");
                DfsDictry.Add("Buyer1LastName", RandomBuyerLastName);
                this.DFSforValidSearchCriteriaUsingDict(DfsDictry);
                this.ValidateFileCreationUsingDict(DfsDictry);
                #endregion

                #region Validate the presence of expected file in DFS results page.
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Click on Continue from File Sumamry Dialog after search.
                Reports.TestStep = "Click on Continue from File Sumamry Dialog after search.";
                FastDriver.DuplicateFileSearchResults.ClickView();
                FastDriver.FileSummaryDlg.WaitForScreenToLoad();
                FastDriver.FileSummaryDlg.SwitchToDialogContentFrame();
                FastDriver.FileSummaryDlg.Continue.FAClick();
                #endregion

                #region Valdiate QFE loaded with file details
                Reports.TestStep = "Valdiate QFE loaded with file details.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Support.AreEqual("Individual", FastDriver.QuickFileEntry.Buyer1Type.FAGetSelectedItem().ToString().Trim());
                Support.AreEqual(RandomBuyerLastName, FastDriver.QuickFileEntry.Buyer1LastName.FAGetValue().ToString().Trim());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion

                #region Duplicate File Search with property details from QRE
                Reports.TestStep = "Enter the complete Property details in DFS Screen from QRE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick Refi Entry").WaitForScreenToLoad();
                this.DFSforValidSearchCriteriaUsingDict(DfsDictry);
                this.ValidateFileCreationUsingDict(DfsDictry);
                #endregion

                #region Validate the presence of expected file in DFS results page.
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Click on Continue from File Sumamry Dialog after search.
                Reports.TestStep = "Click on Continue from File Sumamry Dialog after search.";
                FastDriver.DuplicateFileSearchResults.ClickView();
                FastDriver.FileSummaryDlg.WaitForScreenToLoad();
                FastDriver.FileSummaryDlg.SwitchToDialogContentFrame();
                FastDriver.FileSummaryDlg.Continue.FAClick();
                #endregion

                #region Valdiate QRE loaded with file details
                Reports.TestStep = "Valdiate QRE loaded with file details.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickRefiFileEntry.SwitchToContentFrame();
                Support.AreEqual("Individual", FastDriver.QuickRefiFileEntry.Borrower1Type.FAGetSelectedItem().ToString().Trim());
                Support.AreEqual(RandomBuyerLastName, FastDriver.QuickRefiFileEntry.Borrower1LastName.FAGetValue().ToString().Trim());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0007
        [TestMethod, Obsolete]
        public void FMUC0095_REG0007()
        {
            Reports.TestDescription = @"FM6166: Canadian Region Display. ( Covered in FMUC0095_REG0008 )";
            Reports.StatusUpdate("Covered in FMUC0095_REG0008", true);
        }
        #endregion

        #region Test FMUC0095_REG0008

        /// <summary>
        /// FM6166_PlaceHolder: Canadian Region Display _ Validate the canadian address format
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM6166_PlaceHolder: Canadian Region Display _ Validate the canadian address format";

                #region Login to file side as superuser
                Reports.TestStep = "Login to file side as superuser.";
                IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                #region Navigate to Canadian Region Level.
                Reports.TestStep = "Navigate to Canadian Region Level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("2162");
                #endregion

                #region Validate the canadian address format
                Reports.TestStep = "Validate the canadian address format.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                Support.AreEqual("City, Province, Postal Cd:", FastDriver.DuplicateFileSearch.CityProvincePostalCd.FAGetText().ToString().Trim());
                Support.AreEqual("LT/Reg Off, Country:", FastDriver.DuplicateFileSearch.LT_Reg.FAGetText().ToString().Trim());
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0009

        /// <summary>
        /// FM6167_FM6168_HK: Partial Property Address Search.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0009()
        {
            try
            {
                Reports.TestDescription = "FM6167_FM6168_HK: Partial Property Address Search.";

                #region Login to file side
                Reports.TestStep = "Login to File Side.";
                IISLOGIN();
                #endregion

                #region Search the file number with Lender Reference Number with 2 characters Only and valdiate the error meesage.
                Reports.TestStep = "Search the file number with Lender Reference Number with 2 characters Only and valdiate the error meesage.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("ALB");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.GABcode.FASetText("247");
                FastDriver.DuplicateFileSearch.Find.FAClick();
                FastDriver.DuplicateFileSearch.Reference.FASetText("12");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                Support.AreEqual("At least 3 characters must be entered in Reference to search by Lender.", FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString().Trim(), true);
                #endregion

                #region Partial Property Address Search.Enter the address. Enter the Name of the property only.
                Reports.TestStep = "Partial Property Address Search.Enter the address. Enter the Name of the property only.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("J305");
                FastDriver.DuplicateFileSearch.GABcode.FASetText("247");
                FastDriver.DuplicateFileSearch.Find.FAClick();
                FastDriver.DuplicateFileSearch.Reference.FASetText("REF1");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                Support.AreEqual("No matching record found. Do you want to continue to Open Order?", FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString().Trim(), true);
                #endregion

                #region
                Reports.TestStep = "Validate Lender information as well property Name is carry forwarded from DFS to create a new order.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual("J305", FastDriver.QuickFileEntry.PropertyInformationName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("J305", FastDriver.QuickFileEntry.PropertyBookAddrLin1.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("247", FastDriver.QuickFileEntry.LenderIdCode.FAGetText().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0010

        /// <summary>
        /// FM6169: Lender Reference Number Search when Lender not Selected from GAB.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0010()
        {
            try
            {
                Reports.TestDescription = "FM6169: Lender Reference Number Search when Lender not Selected from GAB.";

                #region Login to file side
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Lender Reference Number Search when Lender not Selected from GAB.
                Reports.TestStep = "Lender Reference Number Search when Lender not Selected from GAB.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("Bu");
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.DuplicateFileSearch.Buyer2LastName.FASetText("Bu");
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("J305");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("ALB");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.Reference.FASetText("123123123");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Validate the error message displayed when No Match found.
                Reports.TestStep = "Validate the error message displayed when No Match found.";
                Support.AreEqual("No matching record found. Do you want to continue to Open Order?", FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString().Trim(), true);
                #endregion

                #region
                Reports.TestStep = "Verify that reference number has been carried forward to QFE";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual("Individual", FastDriver.QuickFileEntry.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Bu", FastDriver.QuickFileEntry.Buyer1LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.QuickFileEntry.Buyer2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Bu", FastDriver.QuickFileEntry.Buyer2LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("ALB", FastDriver.QuickFileEntry.PropertyCity.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("CA", FastDriver.QuickFileEntry.PropertyState.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("123123123", FastDriver.QuickFileEntry.NewLenderInformationReference.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        [TestMethod, Obsolete]
        public void FMUC0095_REG0011()
        {
            Reports.TestDescription = @"FM6180_FM6177_1_FD: OR Search Criteria. (Commented in Coded UI)";
            Reports.StatusUpdate("This test case is commented in Coded UI", true);
        }

        #region Test FMUC0095_REG0012

        /// <summary>
        /// FM6180_FM6177_Validate: Validate the help text, Shortcut key for DFS and DFSResults, Field validation.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM6180_FM6177_Validate: Validate the help text, Shortcut key for DFS and DFSResults, Field validation.";
                #region Login to file side
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create a file for Search conditions
                Reports.TestStep = "Create a file for Search conditions";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                // Enter Buyer type Husband/Wife  with names
                fileRequest.File.Buyers[0].Type = "Individual";
                fileRequest.File.Buyers[0].FirstName = "Buyer1Firstname";
                fileRequest.File.Buyers[0].LastName = "FD95Buyer";
                fileRequest.File.Buyers[0].SSN = "123-45-6789";

                // Enter Property address details
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "FD95Street1";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "ALBANY";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "ALAMEDA";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "97020";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Navigate to DFS Screen and Validate the help text of the buttons availabe in DFS screen.
                Reports.TestStep = "Navigate to DFS Screen and Validate the help text of the buttons availabe in DFS screen.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                Support.AreEqual("Continue to File Entry", FastDriver.DuplicateFileSearch.SkipSearchButton.FAGetAttribute("title").ToString().Trim(), true);
                Support.AreEqual("Clear", FastDriver.DuplicateFileSearch.NewSearch.FAGetAttribute("title").ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.FindNow.FAGetAttribute("title").ToString().Trim(), true);
                Support.AreEqual("Find", FastDriver.DuplicateFileSearch.Find.FAGetAttribute("title").ToString().Trim(), true);
                #endregion

                #region Validating the length of characters for Buyer Name(Individual and Husband/Wife) entered for different fields availabe at DFS screen.
                Reports.TestStep = "Validating the length of characters for Buyer Name(Individual and Husband/Wife) entered for different fields availabe at DFS screen.";
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.DuplicateFileSearch.Buyer1FirstName.FAGetValue().ToString().Trim(), true);
                FastDriver.DuplicateFileSearch.Buyer1MiddleName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.DuplicateFileSearch.Buyer1MiddleName.FAGetValue().ToString().Trim(), true);
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.DuplicateFileSearch.Buyer1LastName.FAGetValue().ToString().Trim(), true);

                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer2FirstName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.DuplicateFileSearch.Buyer2FirstName.FAGetValue().ToString().Trim(), true);
                FastDriver.DuplicateFileSearch.Buyer2MiddleName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.DuplicateFileSearch.Buyer2MiddleName.FAGetValue().ToString().Trim(), true);
                FastDriver.DuplicateFileSearch.Buyer2LastName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.DuplicateFileSearch.Buyer2LastName.FAGetValue().ToString().Trim(), true);
                #endregion

                #region Validating the length of characters for Buyer Name(Trust/Estate and Business) entered for different fields availabe at DFS screen.
                Reports.TestStep = "Validating the length of characters for Buyer Name(Trust/Estate and Business) entered for different fields availabe at DFS screen.";
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFG");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZAB", FastDriver.DuplicateFileSearch.Buyer1FirstName.FAGetValue().ToString().Trim(), true);
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Business Entity");
                FastDriver.DuplicateFileSearch.Buyer2FirstName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABC");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABC", FastDriver.DuplicateFileSearch.Buyer2FirstName.FAGetValue().ToString().Trim(), true);
                #endregion

                #region Validating the length of characters for Property Address.
                Reports.TestStep = "Validating the length of characters for Property Address.";
                FastDriver.DuplicateFileSearch.PropertyAddressAPNTaxNo.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567891234");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234", FastDriver.DuplicateFileSearch.PropertyAddressAPNTaxNo.FAGetValue().ToString().Trim(), true);
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567891234");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789", FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FAGetValue().ToString().Trim(), true);
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567891234");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234", FastDriver.DuplicateFileSearch.PropertyAddressCity.FAGetValue().ToString().Trim(), true);
                FastDriver.DuplicateFileSearch.PropertyAddressZip.FASetText("123456789023");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("12345-6789", FastDriver.DuplicateFileSearch.PropertyAddressZip.FAGetValue().ToString().Trim(), true);
                #endregion

                #region Validating the hotkey for the NewSearch Button.
                Reports.TestStep = "Validating the hotkey for the NewSearch Button.";
                Keyboard.SendKeys("{W}", ModifierKeys.Alt);
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                Support.AreEqual("Husband/Wife", FastDriver.DuplicateFileSearch.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.DuplicateFileSearch.Buyer2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer1FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer1LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer2FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer2LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressAPNTaxNo.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressCity.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressZip.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressState.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("USA", FastDriver.DuplicateFileSearch.PropertyCountry.FAGetSelectedItem().ToString().Trim(), true);
                #endregion


                #region Validating the hotkey for the SkipSearch Button.
                Reports.TestStep = "Validating the hotkey for the SkipSearch Button.";
                Keyboard.SendKeys("{K}", ModifierKeys.Alt);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                #endregion

                #region Validating the hotkey for the FindNow Button.
                Reports.TestStep = "Validating the hotkey for the FindNow Button.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("FD95Buyer");
                Keyboard.SendKeys("{F}", ModifierKeys.Alt);
                ValidateFileCreation();
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                #endregion

                #region Verify the Help Text for the buttons availabe in DFS results screen.
                Reports.TestStep = "Verify the Help Text for the buttons availabe in DFS results screen.";
                Support.AreEqual("Additional Information", FastDriver.DuplicateFileSearchResults.View.FAGetAttribute("title").ToString().Trim(), true);
                Support.AreEqual("Go to Order", FastDriver.DuplicateFileSearchResults.Select.FAGetAttribute("title").ToString().Trim(), true);
                Support.AreEqual("Clear", FastDriver.DuplicateFileSearchResults.NewSearch.FAGetAttribute("title").ToString().Trim(), true);
                Support.AreEqual("Continue to File Entry", FastDriver.DuplicateFileSearchResults.Continue.FAGetAttribute("title").ToString().Trim(), true);
                #endregion

                #region Validate the working of hotkey for View button.
                Reports.TestStep = "Validate the working of hotkey for View button.";
                ValidateFileSearch(FileNumber1);
                Keyboard.SendKeys("{V}", ModifierKeys.Alt);
                FastDriver.FileSummaryDlg.WaitForScreenToLoad();
                FastDriver.FileSummaryDlg.SwitchToDialogContentFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Validate the working of hotkey for GoBack Button.
                Reports.TestStep = "Validate the working of hotkey for GoBack Button.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DuplicateFileSearchResults.SwitchToContentFrame();
                Keyboard.SendKeys("{B}", ModifierKeys.Alt);
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                Support.AreEqual("Individual", FastDriver.DuplicateFileSearch.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("FD95Buyer", FastDriver.DuplicateFileSearch.Buyer1LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.DuplicateFileSearch.Buyer2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer2FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer2LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressAPNTaxNo.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressCity.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressZip.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressState.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("USA", FastDriver.DuplicateFileSearch.PropertyCountry.FAGetValue().ToString().Trim(), true);
                #endregion

                #region Validate the working of hotkey for Continue Button.
                Reports.TestStep = "Validate the working of hotkey for Continue Button.";
                Keyboard.SendKeys("{F}", ModifierKeys.Alt);
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                ValidateFileSearch(FileNumber1);
                Keyboard.SendKeys("{O}", ModifierKeys.Alt);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual("Individual", FastDriver.QuickFileEntry.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("FD95Buyer", FastDriver.QuickFileEntry.Buyer1LastName.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion

                #region Validate the working of hotkey for new Search Button at DFS results page.
                Reports.TestStep = "Validate the working of hotkey for new Search Button at DFS results page.";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("FD95Buyer");
                Keyboard.SendKeys("{F}", ModifierKeys.Alt);
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                ValidateFileSearch(FileNumber1);
                Keyboard.SendKeys("{W}", ModifierKeys.Alt);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                #endregion

                #region Verify the default values for the search criteria fields.
                Reports.TestStep = "Verify the default values for the search criteria fields.";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                Support.AreEqual("Husband/Wife", FastDriver.DuplicateFileSearch.Buyer1Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer1FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer1LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.DuplicateFileSearch.Buyer2Type.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer2FirstName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.Buyer2LastName.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressAPNTaxNo.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressCity.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressZip.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("", FastDriver.DuplicateFileSearch.PropertyAddressState.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("USA", FastDriver.DuplicateFileSearch.PropertyCountry.FAGetValue().ToString().Trim(), true);
                #endregion

                #region Validate the working of hotkey for Select Button at DFS results page.
                Reports.TestStep = "Validate the working of hotkey for Select Button at DFS results page.";
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("FD95Buyer");
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("FD95Street1");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("ALBANY");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                Keyboard.SendKeys("{F}", ModifierKeys.Alt);
                ValidateFileSearch(FileNumber1);
                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0013
        [TestMethod, Obsolete]
        public void FMUC0095_REG0013()
        {
            Reports.TestDescription = @"FM6180_FM6176: New Lender Information. ( Covered in FMUC0095_REG0015 )";
            Reports.StatusUpdate("Covered in FMUC0095_REG0015", true);
        }
        #endregion

        #region Test FMUC0095_REG0014

        /// <summary>
        /// FM6180_FM6178_PlaceHolder: Maximum Number of Records Displayed (Expected Failure when more than 300 records is not available).
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0014()
        {
            try
            {
                Reports.TestDescription = "FM6180_FM6178_PlaceHolder: Maximum Number of Records Displayed (Expected Failure when more than 300 records is not available).";
                #region
                Reports.TestStep = "Login to File Side.";
                IISLOGIN();
                #endregion

                #region Naviagte to DFS and search
                Reports.TestStep = "Naviagte to DFS and search";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("Buyer");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                string ActualValue = FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString().Trim();

                if (ActualValue == "No dialog present")
                    Reports.TestStep = "Not enough records to test (less than 300 records returned)";
                else
                    Support.AreEqual("Found more than 300 records.A maximum of 300 records will be displayed.In order to have less record please provide more data for search.", ActualValue, true);
                
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0015
        /// <summary>
        /// FM6180_FM6176_1_FM6177_2: New Lender Information/Duplicate File Search Results Screen.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0015()
        {
            try
            {
                Reports.TestDescription = "FM6180_FM6176_1_FM6177_2: New Lender Information/Duplicate File Search Results Screen.";

                #region Login to file side
                IISLOGIN();
                #endregion

                #region Create file with Lender Ref
                Reports.TestStep = "Create file with Lender Ref";

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                fileRequest.File.NewLoan.LoanNumber = "test95";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create file2 with same Lender Ref as of file 1 to ensure duplicates
                Reports.TestStep = "Create file2 with same Lender Ref as of file 1 to ensure duplicates";
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                #endregion

                #region New Lender Information in DFS
                Reports.TestStep = "New Lender Information in DFS.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.GABcode.FASetText("247");
                FastDriver.DuplicateFileSearch.Find.FAClick();
                if (FastDriver.DuplicateFileSearch.Edit.Selected.ToString() == "False")
                {
                    if (FastDriver.DuplicateFileSearch.Edit.Enabled.ToString() == "True")
                    {
                        FastDriver.DuplicateFileSearch.Edit.FASetCheckbox(true);
                    }
                }
                FastDriver.DuplicateFileSearch.BusPhone.FASetText("(616)451-2291");
                FastDriver.DuplicateFileSearch.Reference.FASetText("test95");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                ValidateFileCreation();
                #endregion

                #region Validate the presence of expected file in DFS results page.
                Reports.TestStep = "Validate the presence of expected file in DFS results page";
                ValidateFileSearch(FileNumber1);
                #endregion

                #region Click on Continue and Verify the DFS data in QFE.
                Reports.TestStep = "Click on Continue and Verify the DFS data in QFE. ";
                FastDriver.DuplicateFileSearchResults.ClickContinue();
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Support.AreEqual("(616)451-2291", FastDriver.QuickFileEntry.NewLenderInformationBusPhone.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("test95", FastDriver.QuickFileEntry.NewLenderInformationReference.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0095_REG0016

        /// <summary>
        /// FM6181_PlaceHolder: Order Opened in Previous 180 Days.
        /// </summary>
        [TestMethod]
        public void FMUC0095_REG0016()
        {
            try
            {
                Reports.TestDescription = "FM6181_PlaceHolder: Order Opened in Previous 180 Days.";
                #region Login to file side
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Navigate to DFS page
                Reports.TestStep = "Navigate to DFS page.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText("Test st");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("Santa Ana");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Search for the file number having 180 days before opened date.
                Reports.TestStep = "Search for the file number having 180 days before opened date.";
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                int Count = FastDriver.WebDriver.FindElements(By.XPath("//table[@id='dGridResults']//*[text()='dm1612141']")).Count();
                if (Count > 1)
                {
                    Reports.StatusUpdate("File with open date 180 days before should  not be available at DFS", false);
                }
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because" + ex.Message);
            }
        }
        #endregion

        #endregion Regression

        #region Private Methods

        private void DFSforValidSearchCriteriaUsingDict(Dictionary<string, string> DictObj)
        {
            FastDriver.DuplicateFileSearch.SwitchToContentFrame();
            if (DictObj.ContainsKey("Buyer1Type"))
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem(DictObj["Buyer1Type"]);
            if (DictObj.ContainsKey("Buyer1FirstName"))
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText(DictObj["Buyer1FirstName"]);
            if (DictObj.ContainsKey("Buyer1LastName"))
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText(DictObj["Buyer1LastName"]);
            if (DictObj.ContainsKey("Buyer2Type"))
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem(DictObj["Buyer2Type"]);
            if (DictObj.ContainsKey("Buyer2FirstName"))
                FastDriver.DuplicateFileSearch.Buyer2FirstName.FASetText(DictObj["Buyer2FirstName"]);
            if (DictObj.ContainsKey("Buyer2LastName"))
                FastDriver.DuplicateFileSearch.Buyer2LastName.FASetText(DictObj["Buyer2LastName"]);
            if (DictObj.ContainsKey("Buyer2SpouseFirstName"))
                FastDriver.DuplicateFileSearch.Buyer2SpouseFirstName.FASetText(DictObj["Buyer2SpouseFirstName"]);
            if (DictObj.ContainsKey("Buyer2SpouseLastName"))
                FastDriver.DuplicateFileSearch.Buyer2SpouseLastName.FASetText(DictObj["Buyer2SpouseLastName"]);
            if (DictObj.ContainsKey("PropertyAddressStreet1"))
                FastDriver.DuplicateFileSearch.PropertyAddressStreet1.FASetText(DictObj["PropertyAddressStreet1"]);
            if (DictObj.ContainsKey("PropertyAddressStreet2"))
                FastDriver.DuplicateFileSearch.PropertyAddressStreet2.FASetText(DictObj["PropertyAddressStreet2"]);
            if (DictObj.ContainsKey("PropertyAddressStreet3"))
                FastDriver.DuplicateFileSearch.PropertyAddressStreet3.FASetText(DictObj["PropertyAddressStreet3"]);
            if (DictObj.ContainsKey("PropertyAddressCity"))
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText(DictObj["PropertyAddressCity"]);
            if (DictObj.ContainsKey("PropertyCounty"))
                FastDriver.DuplicateFileSearch.PropertyCounty.FASetText(DictObj["PropertyCounty"]);
            if (DictObj.ContainsKey("PropertyAddressState"))
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem(DictObj["PropertyAddressState"]);
            if (DictObj.ContainsKey("GABcode"))
            {
                FastDriver.DuplicateFileSearch.GABcode.FASetText(DictObj["GABcode"]);
                FastDriver.DuplicateFileSearch.Find.FAClick();
            }
            if (DictObj.ContainsKey("Reference"))
                FastDriver.DuplicateFileSearch.Reference.FASetText(DictObj["Reference"]);
            FastDriver.DuplicateFileSearch.ClickFindNow();
        }

        private void ValidateFileCreationUsingDict(Dictionary<string, string> DictObj)
        {
            if (FastDriver.WebDriver.HandleDialogMessage(true, false, 5).ToString().Contains("No matching record found"))
            {
                int tries = 0;
                do
                {
                    FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                    DFSforValidSearchCriteriaUsingDict(DictObj);
                    if (!(FastDriver.WebDriver.HandleDialogMessage(true, false, 5).ToString().Contains("No matching record found")))
                    {
                        break;
                    }
                    else
                    {
                        tries = tries + 1;
                        Playback.Wait(5000);
                    }
                } while (tries <= 10);
            }
        }

        private void ValidateFileCreation()
        {
            if (FastDriver.WebDriver.HandleDialogMessage(true, false, 5).ToString().Contains("No matching record found"))
            {
                int tries = 0;
                do
                {
                    FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                    Playback.Wait(20000);
                    FastDriver.DuplicateFileSearch.ClickFindNow();
                    if (!(FastDriver.WebDriver.HandleDialogMessage(true, false, 5).ToString().Contains("No matching record found")))
                    {
                        break;
                    }
                    else
                    {
                        tries = tries + 1;
                        Playback.Wait(5000);
                    }
                } while (tries <= 10);
            }
        }

        private void ValidateFileNotAvailable(Dictionary<string, string> DictObj)
        {
            if (!(FastDriver.WebDriver.HandleDialogMessage(true, false, 5).ToString().Contains("No matching record found")))
            {
                int tries = 0;
                do
                {
                    FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                    DFSforValidSearchCriteriaUsingDict(DictObj);
                    if (FastDriver.WebDriver.HandleDialogMessage(true, false, 5).ToString().Contains("No matching record found"))
                    {
                        break;
                    }
                    else
                    {
                        tries = tries + 1;
                        Playback.Wait(5000);
                    }
                } while (tries <= 10);
            }
        }

        private void IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void ValidateFileSearch(string File)
        {
            int FileExistsStatus = FastDriver.DuplicateFileSearchResults.VerifyFileDisplayedInTabl(File);
            int LoopCount = 0;
            while (FileExistsStatus < 1)
            {
                FastDriver.DuplicateFileSearchResults.ClickGoBack();
                Playback.Wait(10000);
                FastDriver.DuplicateFileSearch.ClickFindNow();
                int FileExistsStatus1 = FastDriver.DuplicateFileSearchResults.VerifyFileDisplayedInTabl(File);
                if (FileExistsStatus1 == 1)
                {
                    FastDriver.DuplicateFileSearchResults.SearchFileInResultsTable(File);
                    break;
                }
                LoopCount = LoopCount + 4;
                if (LoopCount == 5)
                {
                    break;
                }
            }
            FastDriver.DuplicateFileSearchResults.SearchFileInResultsTable(File);
        }

        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
