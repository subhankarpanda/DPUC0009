﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.DataObjects.ADM;

namespace FileManagement
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class FMUC0086 : MasterTestClass
    {

        #region REG


        [TestMethod]
        public void FMUC0086_BAT00_BAT01_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM5158  Required Data for Bus. Party"+
                 "FM5159 Select a Business Party" +
                 "FM5160  Display Global Indicator" +
                 "Main Course:  Enter a QFE/QRE/FHP Business Party – Find Code Exact Match" +
                 "Alternate Course 1:  Enter a QFE/QRE/FHP Business Party – Find Name Exact Match";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file in QFE";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                Reports.TestStep = "Enter Data in Business Source";
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                Support.AreEqual("True",FastDriver.QuickFileEntry.BusinessSourceGABImage.IsVisible().ToString());
                Reports.TestStep = "Enter Data in Directed By";
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDFRINSR1");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.DirectedBYFind);
                Support.AreEqual("True",FastDriver.QuickFileEntry.DirectedByGABImage.IsVisible().ToString());
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                
                Reports.TestStep = "Enter Data in New Lender";
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.NewLenderInformationFind);
                Support.AreEqual("True",FastDriver.QuickFileEntry.NewLenderGABImage.IsVisible().ToString());

                
                Reports.TestStep = "Enter Data in Associated Lender";                
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.SendKeys("HUDERINSR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.AssociatedBusinessPartyFind);
                Support.AreEqual("True",FastDriver.QuickFileEntry.AssociateLenderGABImage.IsVisible().ToString());
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                
                Reports.TestStep = "Validate the data in FHP";
                Support.AreEqual("HUDFLINSR1", FastDriver.FileHomepage.BusinessPartyIDCodeField.Text);
                Support.AreEqual("True",FastDriver.FileHomepage.Globalicon.IsVisible().ToString());
                Support.AreEqual("HUDFRINSR1", FastDriver.FileHomepage.DirectedByIDCodeField.Text);
                Support.AreEqual("True",FastDriver.FileHomepage.DirectedByGABImage.IsVisible().ToString());
                Support.AreEqual("247", FastDriver.FileHomepage.NewLenderBusinessPartyIDcodeLabel.Text);
                Support.AreEqual("True",FastDriver.FileHomepage.NewLenderGABImage.IsVisible().ToString());
                Support.AreEqual("HUDERINSR1", FastDriver.FileHomepage.AssociateBusinessPartyIDcodeLabel.Text);
                Support.AreEqual("True",FastDriver.FileHomepage.AssociateLenderGABImage.IsVisible().ToString());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
         public void FMUC0086_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM6120 Edit Business Party" +
                "FM6121 Edit Existing GAB Business Party Contact Information" +
                "FM6139 Prevent Edit Contact Information" +
                "FM6222  Edited Contact Info when GAB Contact Info Changes " +
                "Field Validations";

                Reports.TestDescription = "Log into ADM";
                LoginFastAdmSite();

                string NewBusOrg = Support.RandomString("NANANA");
                CreateNewGAB(NewBusOrg);

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();
              
                
                Reports.TestStep = "Create a basic file in QFE";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                Reports.TestStep = "Enter Data in Business Source";
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(NewBusOrg);
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.QuickFileEntry.BusinessSourceGABImage.IsVisible();
                FastDriver.QuickFileEntry.BusinessSourceReference.FASetText("1234");
                Reports.TestStep = "Enter Data in Directed By";
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDFRINSR1");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.DirectedBYFind);
                FastDriver.QuickFileEntry.DirectedByGABImage.IsVisible();
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                
                Reports.TestStep = "Enter Data in New Lender";
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.NewLenderInformationFind);
                FastDriver.QuickFileEntry.NewLenderGABImage.IsVisible();

                
                Reports.TestStep = "Enter Data in Associated Lender";                
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.SendKeys("HUDERINSR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.AssociatedBusinessPartyFind);
                FastDriver.QuickFileEntry.AssociateLenderGABImage.IsVisible();
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                
                Reports.TestStep = "Validate the data in FHP";
                Support.AreEqual(NewBusOrg, FastDriver.FileHomepage.BusinessPartyIDCodeField.Text);             
                Support.AreEqual("HUDFRINSR1", FastDriver.FileHomepage.DirectedByIDCodeField.Text);                
                Support.AreEqual("247", FastDriver.FileHomepage.NewLenderBusinessPartyIDcodeLabel.Text);              
                Support.AreEqual("HUDERINSR1", FastDriver.FileHomepage.AssociateBusinessPartyIDcodeLabel.Text);
               

                Reports.TestStep = "Edit the Business Party details";
                FastDriver.FileHomepage.BusinessPartyEditCont.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessPartyBusPhone.FASetText("(888)451-0848");
                FastDriver.FileHomepage.BusinessPartyBusPhoneExtension.FASetText("888");
                FastDriver.FileHomepage.BusinessPartyBusFax.FASetText("(888)451-0848");
                FastDriver.FileHomepage.BusinessPartyCellPhone.FASetText("(888)451-0848");
                FastDriver.FileHomepage.BusinessPartyEmailAddress.FASetText("me@mail.com");

                Reports.TestStep = "Edit the Business Party Contacts's details";
                FastDriver.FileHomepage.BusinessPartyEditContact.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessPartyContactBusPhone.FASetText("(888)451-0848");
                FastDriver.FileHomepage.BusinessPartyContactPhoneExt.FASetText("888");
                FastDriver.FileHomepage.BusinessPartyContactCellPhone.FASetText("(888)451-0848");
                FastDriver.FileHomepage.BusinessPartyContactBusFax.FASetText("(888)451-0848");
                FastDriver.FileHomepage.BusinessPartyContactEmailAddress.FASetText("me@mail.com");
                FastDriver.BottomFrame.Save();

                FastDriver.FileHomepage.SwitchToContentFrame();
                Reports.TestStep = "Validate the Edited data for Business Party";
                Support.AreEqual("(888)451-0848",FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue());
                Support.AreEqual("888", FastDriver.FileHomepage.BusinessPartyBusPhoneExtension.FAGetValue());
                Support.AreEqual("(888)451-0848", FastDriver.FileHomepage.BusinessPartyBusFax.FAGetValue());
                Support.AreEqual("(888)451-0848", FastDriver.FileHomepage.BusinessPartyCellPhone.FAGetValue());
                Support.AreEqual("me@mail.com", FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue());
                
                
                Reports.TestStep = "Validate the Edited data for Business Party Contact";
                Support.AreEqual("(888)451-0848", FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue());
                Support.AreEqual("888", FastDriver.FileHomepage.BusinessPartyContactPhoneExt.FAGetValue());
                Support.AreEqual("(888)451-0848", FastDriver.FileHomepage.BusinessPartyContactCellPhone.FAGetValue());
                Support.AreEqual("(888)451-0848", FastDriver.FileHomepage.BusinessPartyContactBusFax.FAGetValue());
                Support.AreEqual("me@mail.com", FastDriver.FileHomepage.BusinessPartyContactEmailAddress.FAGetValue());

                FastDriver.FileHomepage.Open();
                Reports.TestStep = "User tries to change a Business Party which has a Reference number specified against it.";
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText("HUDFLINSR1");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false,true);
                FastDriver.WebDriver.HandleDialogMessage(false,true);
                string Act_Message = FastDriver.WebDriver.HandleDialogMessage(true);
                string Exp_Message = "Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?";
                Support.AreEqual("True", Act_Message.Equals(Exp_Message).ToString());
                //Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage(true));

                FastDriver.FileHomepage.SwitchToContentFrame();
                Reports.TestStep = "Validate all the details are disabled when the Edit checkbox is unchecked";
                FastDriver.FileHomepage.BusinessPartyEditCont.FASetCheckbox(false);
                Support.AreEqual("False",FastDriver.FileHomepage.BusinessPartyBusPhone.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileHomepage.BusinessPartyBusPhoneExtension.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileHomepage.BusinessPartyBusFax.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileHomepage.BusinessPartyCellPhone.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileHomepage.BusinessPartyEmailAddress.IsEnabled().ToString());

                


                


                


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0086_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM6197  Re-Populate Primary Contact Info when Edit Name Deselected"+
                "FM5218  Business Party Attention" +
                "FM5172  Use Primary Contact as Attn " +
                "FM5173  Select Another Contact " +
                "FM5174  Select Blank Line for Attention " +
                "FM6123  Deselect Edit Checkbox" +
                "FM5220  Enter Different Name for Attention" +
                "FM6122  Deselect Edit Name" +
                "FM6190  Default Contact Info to Bus Org when Edit Name Selected"+
                 "Field Validations";

                Reports.TestDescription = "Log into ADM";
                LoginFastAdmSite();

                string NewBusOrg = Support.RandomString("NANANA");
                CreateNewGAB(NewBusOrg);

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();


                Reports.TestStep = "Create a basic file in QFE";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                Reports.TestStep = "Enter Data in Business Source";
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(NewBusOrg);
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                                               
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate Primary Contact is displayed and the contact section displays the details of the Primary contact";
                Support.AreEqual("LastName, FirstName", FastDriver.FileHomepage.BusinessPartyAttention.FAGetSelectedItem());
                Support.AreEqual("LastName, FirstName", FastDriver.FileHomepage.BusinessPartyContactName.Text);
                Support.AreEqual("False", FastDriver.FileHomepage.BusinessPartyEditContact.IsSelected().ToString());
                Support.AreEqual("(666)451-0848", FastDriver.FileHomepage.BusinessPartyContactBusPhone.FAGetValue());
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyContactPhoneExt.FAGetValue());
                Support.AreEqual("(666)451-0848", FastDriver.FileHomepage.BusinessPartyContactCellPhone.FAGetValue());
                Support.AreEqual("(666)451-0848", FastDriver.FileHomepage.BusinessPartyContactBusFax.FAGetValue());
                Support.AreEqual("test1@test1.com", FastDriver.FileHomepage.BusinessPartyContactEmailAddress.FAGetValue());

                Reports.TestStep = "Check the Edit Name Checkbox and Enter name for Contact and edit teh details for contact";
                FastDriver.FileHomepage.BusinessPartyEdit.FASetCheckbox(true);
                FastDriver.FileHomepage.WaitForScreenToLoad(FastDriver.FileHomepage.BusinessPartyEditName);
                Support.AreEqual("False",FastDriver.FileHomepage.BusinessPartyAttention.IsEnabled().ToString());
                FastDriver.FileHomepage.BusinessPartyEditName.FASetText("CONTACTNAME");

                Keyboard.SendKeys(FAKeys.TabAway);

                Support.AreEqual("CONTACTNAME", FastDriver.FileHomepage.BusinessPartyContactName.Text);
                FastDriver.FileHomepage.BusinessPartyEditContact.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessPartyContactBusPhone.FASetText("(888)451-0848");
                FastDriver.FileHomepage.BusinessPartyContactPhoneExt.FASetText("888");
                FastDriver.FileHomepage.BusinessPartyContactCellPhone.FASetText("(888)451-0848");
                FastDriver.FileHomepage.BusinessPartyContactBusFax.FASetText("(888)451-0848");
                FastDriver.FileHomepage.BusinessPartyContactEmailAddress.FASetText("me@mail.com");


                Reports.TestStep ="Uncheck the Edit Name Checkbox and validate system displays the primary contact and its details";
                FastDriver.FileHomepage.BusinessPartyEdit.FASetCheckbox(false);
                Support.AreEqual("True",FastDriver.FileHomepage.BusinessPartyAttention.IsEnabled().ToString());
                Support.AreEqual("LastName, FirstName", FastDriver.FileHomepage.BusinessPartyAttention.FAGetSelectedItem());
                Support.AreEqual("False", FastDriver.FileHomepage.BusinessPartyEditName.IsEnabled().ToString());
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyEditName.FAGetText());
                Support.AreEqual("LastName, FirstName", FastDriver.FileHomepage.BusinessPartyContactName.Text);
                Support.AreEqual("(666)451-0848", FastDriver.FileHomepage.BusinessPartyContactBusPhone.FAGetValue());
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyContactPhoneExt.FAGetValue());
                Support.AreEqual("(666)451-0848", FastDriver.FileHomepage.BusinessPartyContactCellPhone.FAGetValue());
                Support.AreEqual("(666)451-0848", FastDriver.FileHomepage.BusinessPartyContactBusFax.FAGetValue());
                Support.AreEqual("test1@test1.com", FastDriver.FileHomepage.BusinessPartyContactEmailAddress.FAGetValue());



                Reports.TestStep = "Select different value from Attention dropdown other than primary contact";
                FastDriver.FileHomepage.BusinessPartyAttention.FASelectItemByIndex(0);
                Keyboard.SendKeys(FAKeys.TabAway);
                //FastDriver.FileHomepage.WaitForScreenToLoad(FastDriver.FileHomepage.BusinessPartyAttention);
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyContactName.Text);
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyContactBusPhone.FAGetValue());
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyContactPhoneExt.FAGetValue());
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyContactCellPhone.FAGetValue());
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyContactBusFax.FAGetValue());
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyContactEmailAddress.FAGetValue());

               }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0086_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM5219  Business Party Sales Reps"+
                 "FM5182  Populate Primary Contact's Sales Reps" +
                 "FM5184  Display Sales Reps if Bus Org Has a Contact" +
                 "FM5185  Display Business Organization's Sales Reps  " +
                 "FM5186  Display Business Organization's Blank Sales Rep" +
                 "FM5188  Sales Rep Display Format  " +
                 "FM6125  Default Sales Reps when Edit Deselected" +
                 "FM5195  Sales Rep when blank Attention field  " +
                 "FM5193  Populate associated Sales Rep 1" +
                 "FM5194  Populate associated Sales Rep 2" +
                 "FM5189  Maintain Sales Rep " + "Field Validations";

                Reports.TestStep = "Login FAST ADM application";
                LoginFastAdmSite();
                Reports.TestStep = "Create BusOrg and Contact with sales Rep Values";
                string ID_Code_BusOrg1 = Support.RandomString("NANANA");
                Setup("Lender", "QA03 FAST", "QA04 FAST", ID_Code_BusOrg1);
                FastDriver.AddressBookSearch.EditGAB(ID_Code_BusOrg1);                    
                FastDriver.BusinessPartyOrganizationSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.New.FAClick();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                 FastDriver.BusPartyContactSetup.FirstName.FASetText("FirstName");
                 FastDriver.BusPartyContactSetup.LastName.FASetText("LastName");
                 FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem("QA08 FAST");
                 FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem("QA09 FAST");
                 FastDriver.BottomFrame.Done();
                 FastDriver.BusPartyContactsList.SwitchToContentFrame();
                 FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                 FastDriver.BottomFrame.Done();
                 FastDriver.BusinessPartyOrganizationSetUp.SwitchToContentFrame();
                 FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                 FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItem("LastName, FirstName");
                 FastDriver.BusinessPartyOrganizationSetUp.SalesRep1.FASelectItem("QA03 FAST");
                 FastDriver.BusinessPartyOrganizationSetUp.SalesRep2.FASelectItem("QA04 FAST");
                 FastDriver.BottomFrame.Done();
                 Reports.TestStep = "Create second BusOrg with no sales Rep Values";
                 string ID_Code_Busorg2 = Support.RandomString("NANANA");
                 Setup1("Lender",ID_Code_Busorg2);
                 FastDriver.AddressBookSearch.EditGAB(ID_Code_BusOrg1);
                 FastDriver.BottomFrame.Done();

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();


                Reports.TestStep = "Create a basic file in QFE";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                Reports.TestStep = "Enter Data in Business Source";
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(ID_Code_BusOrg1);
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);

                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");

                Reports.TestStep = "Enter BusOrg in New Lender where both Bus Org and Contact do not have sales Rep ";
                FastDriver.FileHomepage.BusinessPartyLenderGABcode.FASetText(ID_Code_Busorg2);
                FastDriver.FileHomepage.BusinessPartyLenderFind.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad(FastDriver.FileHomepage.BusinessPartyLenderFind);
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate that the BusOrg has primary contact and sales rep for Primary contact is selected by default";
                Support.AreEqual("LastName, FirstName", FastDriver.FileHomepage.BusinessPartyAttention.FAGetSelectedItem());
                Support.AreEqual("QA08, FAST",FastDriver.FileHomepage.BusinessPartySalesRep1.FAGetSelectedItem());
                Support.AreEqual("QA09, FAST", FastDriver.FileHomepage.BusinessPartySalesRep2.FAGetSelectedItem());

             
                Reports.TestStep = "Make Attention blank and validate that the sales rep for BusOrg is populated";
                FastDriver.FileHomepage.BusinessPartyAttention.FASelectItemByIndex(0);
                Support.AreEqual("QA03, FAST", FastDriver.FileHomepage.BusinessPartySalesRep1.FAGetSelectedItem());
                Support.AreEqual("QA04, FAST", FastDriver.FileHomepage.BusinessPartySalesRep2.FAGetSelectedItem());

                Reports.TestStep = "Validate that there can be blank values for sales Rep ";
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyLenderAttention.FAGetSelectedItem());
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyLenderSalesRep1.FAGetSelectedItem());
                Support.AreEqual("", FastDriver.FileHomepage.BusinessPartyLenderSalesRep2.FAGetSelectedItem());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0086_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM6467  Create Event - Sales Rep Changed "+
                "FM5191  Associate Sales Reps to specific screens" +
                 "FM5192  Overwrite default Sales Rep"+
                 "FM6468  Create Event - File Business Party and Sales Rep(s) Changed"+
                 "FM5196  Sales Rep when Attention Modified"+
                 "FM5183  Populate Another Contact's Sales Reps"+
                 "Alternate Course 4:  FHP Change Business Party Name" + "Field Validations";


                LoginFastAdmSite();
                Reports.TestDescription = "Create GAB with Sales Rep";
                string ID_Code_BusOrg1 = Support.RandomString("NANANA");
                Setup("Lender", "QA03 FAST", "QA03 FAST", ID_Code_BusOrg1);
                Reports.TestDescription = "Create first Contact for GAB with Sales Rep";
                FastDriver.AddressBookSearch.EditGAB(ID_Code_BusOrg1);
                FastDriver.BusinessPartyOrganizationSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.New.FAClick();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.FirstName.FASetText("FirstName");
                FastDriver.BusPartyContactSetup.LastName.FASetText("LastName");
                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem("QA04 FAST");
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem("QA04 FAST");
                FastDriver.BottomFrame.Done();
                FastDriver.BusPartyContactsList.SwitchToContentFrame();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                Reports.TestDescription = "Create second Contact for GAB with Sales Rep";
                FastDriver.BusPartyContactsList.New.FAClick();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.FirstName.FASetText("FirstName1");
                FastDriver.BusPartyContactSetup.LastName.FASetText("LastName1");
                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem("QA05 FAST");
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem("QA05 FAST");
                FastDriver.BottomFrame.Done();
                FastDriver.BusPartyContactsList.SwitchToContentFrame();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();                
                FastDriver.BottomFrame.Done();
                FastDriver.BusinessPartyOrganizationSetUp.SwitchToContentFrame();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItem("LastName, FirstName");
                FastDriver.BusinessPartyOrganizationSetUp.SalesRep1.FASelectItem("QA03 FAST");
                FastDriver.BusinessPartyOrganizationSetUp.SalesRep2.FASelectItem("QA03 FAST");
                FastDriver.BottomFrame.Done();
         
                Reports.TestDescription = "Create third GAB with no sales rep";
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.New.FAClick();
                string ID_Code_BusOrg4 = Support.RandomString("NANANA");
                Setup("Lender", "QA03 FAST", "QA03 FAST", ID_Code_BusOrg4);
             

                
                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();


                Reports.TestStep = "Create a basic file in QFE";
                
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                Reports.TestStep = "Enter Data in Business Source";
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);

                Reports.TestStep = "Enter Data in Business  where both Bus Org and Contact have sales Rep";
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(ID_Code_BusOrg1);
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);

                Reports.TestStep = "Enter Data in Directed By  where both Bus Org and Contact have sales Rep";
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(ID_Code_BusOrg1);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.DirectedBYFind);

                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");

                Reports.TestStep = "Enter BusOrg in New Lender where both Bus Org and Contact have sales Rep ";
                FastDriver.FileHomepage.BusinessPartyLenderGABcode.FASetText(ID_Code_BusOrg1);
                FastDriver.FileHomepage.BusinessPartyLenderFind.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad(FastDriver.FileHomepage.BusinessPartyLenderFind);
               
                Reports.TestStep = "Enter Data in Associated Lender  where both Bus Org and Contact have sales Rep";
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText(ID_Code_BusOrg1);
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.AssociatedBusinessPartyFind);

                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.SwitchToContentFrame();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                
                Reports.TestStep = "Validate sales rep for Business Source/Directed By/New Lender/Associated Bus Party";
                Support.AreEqual("QA04, FAST", FastDriver.FileHomepage.BusinessPartySalesRep1.FAGetSelectedItem());
                Support.AreEqual("QA04, FAST", FastDriver.FileHomepage.BusinessPartySalesRep2.FAGetSelectedItem());
                Support.AreEqual("QA04, FAST", FastDriver.FileHomepage.DirectedBySalesRep1.FAGetSelectedItem());
                Support.AreEqual("QA04, FAST", FastDriver.FileHomepage.DirectedBySalesRep2.FAGetSelectedItem());
                Support.AreEqual("QA04, FAST", FastDriver.FileHomepage.AssociateBusinessPartySalesRep1.FAGetSelectedItem());
                Support.AreEqual("QA04, FAST", FastDriver.FileHomepage.AssociateBusinessPartySalesRep2.FAGetSelectedItem());
                Support.AreEqual("QA04, FAST", FastDriver.FileHomepage.BusinessPartyLenderSalesRep1.FAGetSelectedItem());
                Support.AreEqual("QA04, FAST", FastDriver.FileHomepage.BusinessPartyLenderSalesRep2.FAGetSelectedItem());

                Reports.TestStep = "Change sales rep from one to another and validate the Event Log";
                FastDriver.FileHomepage.BusinessPartySalesRep1.FASelectItem("QA05, FAST");
                FastDriver.FileHomepage.BusinessPartySalesRep2.FASelectItem("QA05, FAST");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[Sales Reps Changed]");
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 5, "File Business Party Business Source For: " + ID_Code_BusOrg1 + " Sales Rep 1 changed from QA04, FAST To: QA05, FAST Sales Rep 2 changed from QA04, FAST To: QA05, FAST");


                
                FastDriver.FileHomepage.Open();
                Reports.TestStep = "Change sales rep to blank and validate the Event Log";
                FastDriver.FileHomepage.BusinessPartySalesRep1.FASelectItemByIndex(0);
                FastDriver.FileHomepage.BusinessPartySalesRep2.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Save();

                
                FastDriver.EventTrackingLog.Open();
                
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[Sales Reps Changed]");
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 5, "File Business Party Business Source For: "+ID_Code_BusOrg1+" Sales Rep 1 changed from QA05, FAST To: <blank> Sales Rep 2 changed from QA05, FAST To: <blank>");

                Reports.TestStep = "Change sales rep from blank to a name and validate the Event Log";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.BusinessPartySalesRep1.FASelectItem("QA05, FAST");
                FastDriver.FileHomepage.BusinessPartySalesRep2.FASelectItem("QA05, FAST");
                FastDriver.BottomFrame.Save();

                FastDriver.EventTrackingLog.Open();
                string abc = FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message;
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[Sales Reps Changed]");
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 5, "File Business Party Business Source For: " + ID_Code_BusOrg1 + " Sales Rep 1 changed from <blank> To: QA05, FAST Sales Rep 2 changed from <blank> To: QA05, FAST");

                Reports.TestStep = "Change BusOrg and validate EventLog";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.DirectedByGABcode.FASetText(ID_Code_BusOrg4);
                FastDriver.FileHomepage.DirectedByFind.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.BottomFrame.Save();


                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[FileBusiness Party & SalesRep(s) changed]");
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 5, "File Business Party Directed By changed from: " + ID_Code_BusOrg1 + " To: "+ ID_Code_BusOrg4 +" Sales Rep 1 changed from QA04, FAST To: <blank> Sales Rep 2 changed from QA04, FAST To: <blank>");

                Reports.TestStep = "Enter value for attention and validate that the BusOrg's Sales Rep is displayed";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AssociateBusinessPartyEdit.FASetCheckbox(true);
                FastDriver.FileHomepage.AssociateBusinessPartyEidtName.FASetText("TEST");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("QA03, FAST", FastDriver.FileHomepage.AssociateBusinessPartySalesRep1.FAGetSelectedItem());
                Support.AreEqual("QA03, FAST", FastDriver.FileHomepage.AssociateBusinessPartySalesRep2.FAGetSelectedItem());
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0086_REG0006()
        { 
            try
            {
                Reports.TestDescription = "FM5190  Default blank Sales Rep for Ad Hoc entry"+
                 "FM5162  Enter Ad Hoc Business Party" +
                 "FM5163  Display Ad Hoc Indicator" +
                 "FM5163  Display Ad Hoc Indicator" +
                 "FM5181  Update Bus. Party to File AB" + "Field Validations";




                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();
              
                
                Reports.TestStep = "Create a basic file in QFE";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                Reports.TestStep = "Navigate to AddressBook SearchDialog and create an adhoc GAB";
                FastDriver.AddressBookSearchDlg.NewGabRequest();
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Validate that Sales Rep is blank for adhoc GAB";
                Support.AreEqual("",FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem());
                Support.AreEqual("",FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem());
                Reports.TestStep = "Validate that icon for adhoc GAB";
                FastDriver.QuickFileEntry.GabPencilImage.IsVisible();
                var AdGabCode = FastDriver.QuickFileEntry.btnBusinessSourceGABCodeLabel.FAGetText();

                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.SwitchToContentFrame();
                Support.AreEqual(AdGabCode, FastDriver.FileHomepage.BusinessPartyIDCodeField.FAGetText());
                




            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0086_REG0007()
        { 
            try
            {
                Reports.TestDescription = "FM5180  Edit Business Party on File Homepage" + "Field Validations";

              
                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();


                Reports.TestStep = "Create a basic file in QFE";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                Reports.TestStep = "Enter Data in Business Source";
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                                               
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
            
                Reports.TestStep = "Create an insynace for Survey and Disburse";
                FastDriver.SurveyDetail.Open();
                                
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.Click();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                FastDriver.Delivery.Perform(FADeliveryMethod.Print);            
                Reports.TestStep = "Navigate to FileHomePage and change BusParty.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText("HUDERINSR1");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.BottomFrame.Save();
            
                        
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
       
        [TestMethod]
        public void FMUC0086_ERR1_ERR2_REG0008()
        {
            try
            {
                Reports.TestDescription = "Error /Warnin1-User searches on ID Code and system does not find an exact match or any matches to the leading characters."+
                 "Error/Warning2-User searches on Name and system does not find an exact match or any matches to the leading characters"; 
                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file in QFE";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                Reports.TestStep = "Enter Data in Business Source";
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("iiiii");

                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                string Act_Message = FastDriver.WebDriver.HandleDialogMessage(true);
                string Exp_Message = "ID Code not found.";
                Support.AreEqual("True", Act_Message.Equals(Exp_Message).ToString());
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceName.FASetText("888");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                string Act_Message1 = FastDriver.WebDriver.HandleDialogMessage(true);
                string Exp_Message1 = "Name not found.";
                Support.AreEqual("True", Act_Message1.Equals(Exp_Message1).ToString());
                FastDriver.QuickFileEntry.SwitchToContentFrame();

                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0086_REG0009()
        {
            try
            {

                Reports.TestDescription = "US222965 Select License Information - QFE Lender Business Party Component";

                LoginFastAdmSite();
                Reports.TestDescription = "Create GAB with License";
                string ID_Code_BusOrg1 = Support.RandomString("NANANA");
                Setup("Lender", "QA03 FAST", "QA03 FAST", ID_Code_BusOrg1);
                Reports.TestDescription = "Create Contact for GAB with Sales Rep";
                FastDriver.AddressBookSearch.EditGAB(ID_Code_BusOrg1);
                FastDriver.BusinessPartyOrganizationSetUp.LicenseInformationNew.FAClick();
                string Lic = NMLSLicense();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.LicenseInformationNew.FAClick();
                string Lic1 = License("CA", "Lender / Mortgage Broker");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestDescription = "Create contact with License";
                FastDriver.AddressBookSearch.EditGAB(ID_Code_BusOrg1);
                FastDriver.BusinessPartyOrganizationSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.New.FAClick();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.FirstName.FASetText("FirstName");
                FastDriver.BusPartyContactSetup.LastName.FASetText("LastName");
                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem("QA04 FAST");
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem("QA04 FAST");
                FastDriver.BusPartyContactSetup.LicenseInformationNew.FAClick();
                string Contact_Lic = NMLSLicense();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.LicenseInformationNew.FAClick();
                string Contact_Lic1 = License("CA", "Lender / Mortgage Broker");
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.BusPartyContactsList.SwitchToContentFrame();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BusinessPartyOrganizationSetUp.SwitchToContentFrame();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItem("LastName, FirstName");
                FastDriver.BottomFrame.Done();
                                
           
                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file in QFE";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                Reports.TestStep = "Enter Data in Business Source";
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");

                Reports.TestStep = "Enter BusOrg in New Lender which has NMLS ";
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(ID_Code_BusOrg1);
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.NewLenderInformationFind);

                Reports.TestStep = "Validate NMLS ID for BusOrg and State License for New Lender when State is not selected";
                Support.AreEqual(Lic, FastDriver.QuickFileEntry.NewLenderNMLS.FAGetValue());
                Support.AreEqual("", FastDriver.QuickFileEntry.NewLenderStateLicense.FAGetSelectedItem());
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Validate NMLS ID for BusOrg/Contact and State License for New Lender when State is selected";
                Support.AreEqual("CA, "+Lic1, FastDriver.QuickFileEntry.NewLenderStateLicense.FAGetSelectedItem());
                Support.AreEqual(Contact_Lic, FastDriver.QuickFileEntry.NewLenderContactNMLS.FAGetValue());
                Support.AreEqual("CA, " + Contact_Lic1, FastDriver.QuickFileEntry.NewLenderContactStateLicense.FAGetSelectedItem());

                FastDriver.BottomFrame.Done();

                
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0086_BAT03_BAT04_REG0010()
        {
            try
            {
                Reports.TestStep = "Alternate Course 2:  Enter a QFE/QRE/FHP Business Party – Select from Global Address Book"+
                "Alternate Course 3:  Enter a QFE/QRE/FHP Business Party – Find Code/Name with Multiple Matches";
                
                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file in QFE";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                Reports.TestStep = "Enter Data in Business Source";
                FastDriver.QuickFileEntry.WaitForScreenToLoad(FastDriver.QuickFileEntry.btnBusinessSourceGABFind);
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("HUD*");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2,1,TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUD*");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectBusinessSegment("Residential");
                FastDriver.QuickFileEntry.SelectTransactionType("Bulk Sale");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a basic file in QRE";
                FastDriver.DuplicateFileSearch.Open();




            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        //(9.9-10.4) GAP - Closing Information
        [TestMethod]
        public void FMUC0086_REG0011()
        {
            try
            {
                Reports.TestDescription = "(9.9-10.4) GAP - US507839 Order Entry - Disable 'commission % or $' fields from multiple sections on screen "+
                    "Verify for Business source Buyer broker";

                #region Login and verify commission % and $ on QFE
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with Complete Property Address.";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItemByIndex(0);
                Support.AreEqual("False", FastDriver.QuickFileEntry.BusinessSourcePercentage.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.BusinessSourceAmount.IsEnabled().ToString());
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Buyer's Broker");
                Support.AreEqual("True", FastDriver.QuickFileEntry.BusinessSourcePercentage.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.QuickFileEntry.BusinessSourceAmount.IsEnabled().ToString());
                Support.AreEqual("0.0000", FastDriver.QuickFileEntry.BusinessSourcePercentage.FAGetValue().ToString());
                Support.AreEqual("0.00", FastDriver.QuickFileEntry.BusinessSourceAmount.FAGetValue().ToString());

                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYAddtionalRole.FASelectItemByIndex(0);
                Support.AreEqual("False", FastDriver.QuickFileEntry.DirectedBYPercentage.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.DirectedBYAmount.IsEnabled().ToString());
                FastDriver.QuickFileEntry.DirectedBYAddtionalRole.FASelectItem("Buyer's Broker");
                Support.AreEqual("True", FastDriver.QuickFileEntry.DirectedBYPercentage.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.QuickFileEntry.DirectedBYAmount.IsEnabled().ToString());
                Support.AreEqual("0.0000", FastDriver.QuickFileEntry.DirectedBYPercentage.FAGetValue().ToString());
                Support.AreEqual("0.00", FastDriver.QuickFileEntry.DirectedBYAmount.FAGetValue().ToString());

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyAddtionalRole.FASelectItemByIndex(0);
                Support.AreEqual("False", FastDriver.QuickFileEntry.AssociatedBusinessPartyPercent.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.AssociatedBusinessPartyAmount.IsEnabled().ToString());
                FastDriver.QuickFileEntry.AssociatedBusinessPartyAddtionalRole.FASelectItem("Buyer's Broker");
                Support.AreEqual("True", FastDriver.QuickFileEntry.AssociatedBusinessPartyPercent.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.QuickFileEntry.AssociatedBusinessPartyAmount.IsEnabled().ToString());
                Support.AreEqual("0.0000", FastDriver.QuickFileEntry.AssociatedBusinessPartyPercent.FAGetValue().ToString());
                Support.AreEqual("0.00", FastDriver.QuickFileEntry.AssociatedBusinessPartyAmount.FAGetValue().ToString());

                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();

                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                string[] Refi_Transaction_type = new string[6] { "Construction Finance", "Refinance", "Equity Loan", "Construction Disbursement", "Mtg Mod w/Endorsement", "Mtg Mod w/Increased Liability", };
                for (int i = 0; i < Refi_Transaction_type.Length; i++)
                {

                    Reports.TestStep = "Select the " + Refi_Transaction_type[i] + " tranaction type and verify on Coomision amount and Pecentage textbox properties";

                    FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys(Refi_Transaction_type[i]);
                    // KeyboardSendKeys("{TAB}");
                    Support.AreEqual("False", FastDriver.QuickFileEntry.BusinessSourcePercentage.IsEnabled().ToString());
                    Support.AreEqual("False", FastDriver.QuickFileEntry.BusinessSourceAmount.IsEnabled().ToString());

                    Support.AreEqual("False", FastDriver.QuickFileEntry.DirectedBYPercentage.IsEnabled().ToString());
                    Support.AreEqual("False", FastDriver.QuickFileEntry.DirectedBYAmount.IsEnabled().ToString());

                    Support.AreEqual("False", FastDriver.QuickFileEntry.AssociatedBusinessPartyPercent.IsEnabled().ToString());
                    Support.AreEqual("False", FastDriver.QuickFileEntry.AssociatedBusinessPartyAmount.IsEnabled().ToString());


                    Support.AreEqual("0.0000", FastDriver.QuickFileEntry.BusinessSourcePercentage.FAGetValue().ToString());
                    Support.AreEqual("0.00", FastDriver.QuickFileEntry.BusinessSourceAmount.FAGetValue().ToString());

                    Support.AreEqual("0.0000", FastDriver.QuickFileEntry.DirectedBYPercentage.FAGetValue().ToString());
                    Support.AreEqual("0.00", FastDriver.QuickFileEntry.DirectedBYAmount.FAGetValue().ToString());

                    Support.AreEqual("0.0000", FastDriver.QuickFileEntry.AssociatedBusinessPartyPercent.FAGetValue().ToString());
                    Support.AreEqual("0.00", FastDriver.QuickFileEntry.AssociatedBusinessPartyAmount.FAGetValue().ToString());

                }


                string[] Non_Refi_Transaction_type = new string[14]
                {"Accommodation", "Bulk Sale","Foreclosure","Limited Escrow", "REO Sale w/Mortgage", 
                 "REO Sale/Cash","Sale w/Construction Loan","Sale w/Mortgage","Sale/Cash","Sale/Exchange",
                 "Search Package","Settlement Statement Only","Short Sale w/Mortgage","Short Sale/Cash"};

                for (int i = 0; i < Non_Refi_Transaction_type.Length; i++)
                {

                    Reports.TestStep = "Select the " + Non_Refi_Transaction_type[i] + " tranaction type and verify on Coomision amount and Pecentage textbox properties";

                    FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys(Non_Refi_Transaction_type[i]);
                    // KeyboardSendKeys("{TAB}");
                    Support.AreEqual("True", FastDriver.QuickFileEntry.BusinessSourcePercentage.IsEnabled().ToString());
                    Support.AreEqual("True", FastDriver.QuickFileEntry.BusinessSourceAmount.IsEnabled().ToString());

                    Support.AreEqual("True", FastDriver.QuickFileEntry.DirectedBYPercentage.IsEnabled().ToString());
                    Support.AreEqual("True", FastDriver.QuickFileEntry.DirectedBYAmount.IsEnabled().ToString());

                    Support.AreEqual("True", FastDriver.QuickFileEntry.AssociatedBusinessPartyPercent.IsEnabled().ToString());
                    Support.AreEqual("True", FastDriver.QuickFileEntry.AssociatedBusinessPartyAmount.IsEnabled().ToString());


                    Support.AreEqual("0.0000", FastDriver.QuickFileEntry.BusinessSourcePercentage.FAGetValue().ToString());
                    Support.AreEqual("0.00", FastDriver.QuickFileEntry.BusinessSourceAmount.FAGetValue().ToString());

                    Support.AreEqual("0.0000", FastDriver.QuickFileEntry.DirectedBYPercentage.FAGetValue().ToString());
                    Support.AreEqual("0.00", FastDriver.QuickFileEntry.DirectedBYAmount.FAGetValue().ToString());

                    Support.AreEqual("0.0000", FastDriver.QuickFileEntry.AssociatedBusinessPartyPercent.FAGetValue().ToString());
                    Support.AreEqual("0.00", FastDriver.QuickFileEntry.AssociatedBusinessPartyAmount.FAGetValue().ToString());

                }

                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Buyer's Broker");
                FastDriver.QuickFileEntry.BusinessSourcePercentage.FASetText("50");
                // FastDriver.QuickFileEntry.BusinessSourceAmount.FASetText("");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);

                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }

                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("50.0000", FastDriver.FileHomepage.BusinessPartyPercent.FAGetValue());
                Support.AreEqual("2,500.00", FastDriver.FileHomepage.BusinessPartyAmount.FAGetValue());
                #endregion

                #region
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER");
                Support.AreEqual("50.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());
                Support.AreEqual("2,500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message.Trim());
            }
        }

        //(9.9-10.4) GAP - Closing Information
        [TestMethod]
        public void FMUC0086_REG0012()
        {
            try
            {
                Reports.TestDescription = "(9.9-10.4) GAP - US507839 Order Entry - Disable 'commission % or $' fields from multiple sections on screen" +
                    "Verify for Directed By Seller broker and associate businees party buyer broker";

                #region Login and verify commission % and $ on QFE
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                CreateFilewithCommisionValue("DIRECTEDBY", "Seller's Broker", "SELLERBROKER");
                CreateFilewithCommisionValue("BUSINESSSOURCE", "Seller's Broker", "SELLERBROKER");
                CreateFilewithCommisionValue("ASSOCIATEDBUSINESSPARTY", "Seller's Broker", "SELLERBROKER");

                CreateFilewithCommisionValue("DIRECTEDBY", "Buyer's Broker", "BUYERBROKER");
                CreateFilewithCommisionValue("BUSINESSSOURCE", "Buyer's Broker", "BUYERBROKER");
                CreateFilewithCommisionValue("ASSOCIATEDBUSINESSPARTY", "Buyer's Broker", "BUYERBROKER");


            }
            catch (Exception ex)
            {
                FailTest(ex.Message.Trim());
            }
        }

        //(9.9-10.4) GAP - Closing Information
        [TestMethod]
        public void FMUC0086_REG0013()
        {
            try
            {
                Reports.TestDescription = "(9.9-10.4) GAP - US507839 Order Entry - Disable 'commission % or $' fields from multiple sections on screen";

                #region Login and verify commission % and $ on QFE
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with Complete Property Address.";
                FastDriver.QuickRefiFileEntry.OpenQREPage();

                FastDriver.QuickRefiFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickRefiFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickRefiFileEntry.BusinessSourceAddtionalRole.FASelectItemByIndex(0);
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.BusinessSourcePercentage.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.BusinessSourceAmount.IsEnabled().ToString());
                FastDriver.QuickRefiFileEntry.BusinessSourceAddtionalRole.FASelectItem("Buyer's Broker");
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.BusinessSourcePercentage.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.BusinessSourceAmount.IsEnabled().ToString());
                Support.AreEqual("0.0000", FastDriver.QuickRefiFileEntry.BusinessSourcePercentage.FAGetValue().ToString());
                Support.AreEqual("0.00", FastDriver.QuickRefiFileEntry.BusinessSourceAmount.FAGetValue().ToString());

                FastDriver.QuickRefiFileEntry.DirectedByArrowIcon.FAClick();
                FastDriver.QuickRefiFileEntry.DirectedByGabCode.FASetText("HUDLEASE03");
                FastDriver.QuickRefiFileEntry.DirectedByFind.FAClick();

                FastDriver.QuickRefiFileEntry.DirectedByAddtionalRole.FASelectItemByIndex(0);
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.DirectedByPercentage.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.DirectedByAmount.IsEnabled().ToString());
                FastDriver.QuickRefiFileEntry.DirectedByAddtionalRole.FASelectItem("Buyer's Broker");
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.DirectedByPercentage.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.DirectedByAmount.IsEnabled().ToString());
                Support.AreEqual("0.0000", FastDriver.QuickRefiFileEntry.DirectedByPercentage.FAGetValue().ToString());
                Support.AreEqual("0.00", FastDriver.QuickRefiFileEntry.DirectedByAmount.FAGetValue().ToString());

                FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyAddtionalRole.FASelectItemByIndex(0);
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyPercent.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyAmount.IsEnabled().ToString());
                FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyAddtionalRole.FASelectItem("Buyer's Broker");
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyPercent.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyAmount.IsEnabled().ToString());
                Support.AreEqual("0.0000", FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyPercent.FAGetValue().ToString());
                Support.AreEqual("0.00", FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyAmount.FAGetValue().ToString());

                if (!FastDriver.QuickRefiFileEntry.Title.Selected)
                    FastDriver.QuickRefiFileEntry.Title.FAClick();
                if (!FastDriver.QuickRefiFileEntry.Escrow.Selected)
                    FastDriver.QuickRefiFileEntry.Escrow.FAClick();

                FastDriver.QuickRefiFileEntry.ProgramType.FASelectItemByIndex(0);

                string[] Refi_Transaction_type = new string[6] { "Construction Finance", "Refinance", "Equity Loan", "Construction Disbursement", "Mtg Mod w/Endorsement", "Mtg Mod w/Increased Liability", };
                for (int i = 0; i < Refi_Transaction_type.Length; i++)
                {

                    Reports.TestStep = "Select the " + Refi_Transaction_type[i] + " tranaction type and verify on Coomision amount and Pecentage textbox properties";

                    FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys(Refi_Transaction_type[i]);
                    // KeyboardSendKeys("{TAB}");
                    Support.AreEqual("False", FastDriver.QuickRefiFileEntry.BusinessSourcePercentage.IsEnabled().ToString());
                    Support.AreEqual("False", FastDriver.QuickRefiFileEntry.BusinessSourceAmount.IsEnabled().ToString());

                    Support.AreEqual("False", FastDriver.QuickRefiFileEntry.DirectedByPercentage.IsEnabled().ToString());
                    Support.AreEqual("False", FastDriver.QuickRefiFileEntry.DirectedByAmount.IsEnabled().ToString());

                    Support.AreEqual("False", FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyPercent.IsEnabled().ToString());
                    Support.AreEqual("False", FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyAmount.IsEnabled().ToString());


                    Support.AreEqual("0.0000", FastDriver.QuickRefiFileEntry.BusinessSourcePercentage.FAGetValue().ToString());
                    Support.AreEqual("0.00", FastDriver.QuickRefiFileEntry.BusinessSourceAmount.FAGetValue().ToString());

                    Support.AreEqual("0.0000", FastDriver.QuickRefiFileEntry.DirectedByPercentage.FAGetValue().ToString());
                    Support.AreEqual("0.00", FastDriver.QuickRefiFileEntry.DirectedByAmount.FAGetValue().ToString());

                    Support.AreEqual("0.0000", FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyPercent.FAGetValue().ToString());
                    Support.AreEqual("0.00", FastDriver.QuickFileEntry.AssociatedBusinessPartyAmount.FAGetValue().ToString());

                }

              
                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickRefiFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickRefiFileEntry.FormType_CD.FASetCheckbox(true);

               //FastDriver.QuickRefiFileEntry.ProductsSelect.FASetCheckbox(true);

                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                FastDriver.QuickRefiFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickRefiFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickRefiFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickRefiFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);

                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }

                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("Buyer's Broker", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
                Support.AreEqual("0.0000", FastDriver.FileHomepage.BusinessPartyPercent.FAGetValue());
                Support.AreEqual("0.00", FastDriver.FileHomepage.BusinessPartyAmount.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message.Trim());
            }
        }

        //(9.9-10.4) GAP - Closing Information
        [TestMethod]
        public void FMUC0086_REG0014()
        {
            try
            {
                Reports.TestDescription = "(9.9-10.4) GAP - US507851 QRE Order Entry - Relabel 'New Payoff Lender Info' to 'Payoff Lender Information'";

                #region Login and verify commission % and $ on QFE
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Verify PAYOFF LENDER INFORMATION lable on QRE.";
                FastDriver.QuickRefiFileEntry.OpenQREPage();

                FastDriver.QuickRefiFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickRefiFileEntry.BusinessSourceFind.FAClick();

                if (!FastDriver.QuickRefiFileEntry.Title.Selected)
                    FastDriver.QuickRefiFileEntry.Title.FAClick();
                if (!FastDriver.QuickRefiFileEntry.Escrow.Selected)
                    FastDriver.QuickRefiFileEntry.Escrow.FAClick();

                FastDriver.QuickRefiFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickRefiFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickRefiFileEntry.FormType_CD.FASetCheckbox(true);

                //FastDriver.QuickRefiFileEntry.ProductsSelect.FASetCheckbox(true);

                Support.AreEqual("Payoff Lender Information", FastDriver.QuickRefiFileEntry.NewPayOffLender.Text);

                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                FastDriver.QuickRefiFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickRefiFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);

                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }

                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message.Trim());
            }
        }




        #endregion

        #region Private Methods

        private void LoginFastFileSite(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }


        private void CreateFilewithCommisionValue(string SectionName , string BrokerType ,string Rebbrokertype )
        {

                Reports.TestStep = "Create a new file with Complete Property Address.";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();


                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                if (SectionName.ToUpper() == "DIRECTEDBY")
                {
                    FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                    FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                    FastDriver.QuickFileEntry.DirectedBYAddtionalRole.FASelectItem(BrokerType);
                    FastDriver.QuickFileEntry.DirectedBYPercentage.FASetText("50");
                }

                if (SectionName.ToUpper() == "BUSINESSSOURCE")
                {

                    FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem(BrokerType);
                    FastDriver.QuickFileEntry.BusinessSourcePercentage.FASetText("50");
                }

                if (SectionName.ToUpper() == "ASSOCIATEDBUSINESSPARTY")
                {
                    FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDLEASE03");
                    FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                    FastDriver.QuickFileEntry.AssociatedBusinessPartyAddtionalRole.FASelectItem(BrokerType);
                    FastDriver.QuickFileEntry.AssociatedBusinessPartyPercent.FASetText("50");
                }


                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();

                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);


                
                // FastDriver.QuickFileEntry.BusinessSourceAmount.FASetText("");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);

                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);

                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }

                if (SectionName.ToUpper() == "DIRECTEDBY")
                {
                    FastDriver.FileHomepage.WaitForScreenToLoad();
                    Support.AreEqual("50.0000", FastDriver.FileHomepage.DirectedByPercent.FAGetValue());
                    Support.AreEqual("2,500.00", FastDriver.FileHomepage.DirectedByAmount.FAGetValue());
                }

                if (SectionName.ToUpper() == "BUSINESSSOURCE")
                {
                    FastDriver.FileHomepage.WaitForScreenToLoad();
                    Support.AreEqual("50.0000", FastDriver.FileHomepage.BusinessPartyPercent.FAGetValue());
                    Support.AreEqual("2,500.00", FastDriver.FileHomepage.BusinessPartyAmount.FAGetValue());
                }

                if (SectionName.ToUpper() == "ASSOCIATEDBUSINESSPARTY")
                {
                    FastDriver.FileHomepage.WaitForScreenToLoad();
                    Support.AreEqual("50.0000", FastDriver.FileHomepage.AssociateBusinessPartyPercent.FAGetValue());
                    Support.AreEqual("2,500.00", FastDriver.FileHomepage.AssociateBusinessPartyAmount.FAGetValue());
                }


                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker(Rebbrokertype);
                Support.AreEqual("50.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());
                Support.AreEqual("2,500.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());

        }


        private void CreateBasicFileWithSpecifiedGAB(string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        private void CreateMasterFile()
        {
            FastDriver.DuplicateFileSearch.Open();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
            FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);
            FastDriver.QuickFileEntry.UseAsMasterFile.FASetCheckbox(true);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");

            Playback.Wait(1000);
            Keyboard.SendKeys("^{D}");
        }

        private void Setup(string EntityType,string salesrep1,string salesrep2,string IDCODE)
    {

        BusinessOrganizationParameters abc = new BusinessOrganizationParameters();
        //string ID_Code=Support.RandomString("NANANA");
        abc.IDCode = IDCODE;
        abc.Name1 = "BusOrg for Sales Rep 1";
        abc.Name2 = "BusOrg for Sales Rep 2";
        abc.EntityType = EntityType;
        abc.SalesRep1 = salesrep1;
        abc.SalesRep2 = salesrep2;
        FastDriver.AddressBookSearch.Open();
        FastDriver.AddressBookSearch.CreateNewAddressEntry(abc);
                      

    }
        private void Setup1(string EntityType,string IDCODE)
        {

            BusinessOrganizationParameters abc = new BusinessOrganizationParameters();
            //string ID_Code=Support.RandomString("NANANA");
            abc.IDCode = IDCODE;
            abc.Name1 = "BusOrg for Sales Rep 1";
            abc.Name2 = "BusOrg for Sales Rep 2";
            abc.EntityType = EntityType;
        // abc.SalesRep1 = salesrep1;
            //abc.SalesRep2 = salesrep2;
            FastDriver.AddressBookSearch.Open();
            FastDriver.AddressBookSearch.CreateNewAddressEntry(abc);


        }

        private void CreateNewGAB(string GabId)
         {


                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.New.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.IDCode.FASetText(GabId);
                FastDriver.BusinessPartyOrganizationSetUp.EntityType.FASelectItem("Lender");
                FastDriver.BusinessPartyOrganizationSetUp.Name1.FASetText("New BusOrg For FMUC0068");
                FastDriver.BusinessPartyOrganizationSetUp.Name2.FASetText("New BusOrg For FMUC0068");
                FastDriver.BusinessPartyOrganizationSetUp.SalesRep1.FASelectItem("QA03 FAST");
                FastDriver.BusinessPartyOrganizationSetUp.SalesRep2.FASelectItem("QA03 FAST");
                FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneTypeNumber.FASetText("(999)451-0848");
                FastDriver.BusinessPartyOrganizationSetUp.BusinessFaxTypeNumber.FASetText("(999)451-0848");
                FastDriver.BusinessPartyOrganizationSetUp.PagerNumber.FASetText("(999)451-0848");
                FastDriver.BusinessPartyOrganizationSetUp.CellularNumber.FASetText("(999)451-0848");
                FastDriver.BusinessPartyOrganizationSetUp.EmailNumber.FASetText("test@test.com");
                FastDriver.BusinessPartyOrganizationSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.New.FAClick();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.FirstName.FASetText("FirstName");
                FastDriver.BusPartyContactSetup.LastName.FASetText("LastName");
                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem("QA08 FAST");
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem("QA08 FAST");
                FastDriver.BusPartyContactSetup.BusNumber.FASetText("(666)451-0848");
                FastDriver.BusPartyContactSetup.BusFaxNumber.FASetText("(666)451-0848");
                FastDriver.BusPartyContactSetup.PagerNumber.FASetText("(666)451-0848");
                FastDriver.BusPartyContactSetup.CellularNumber.FASetText("(666)451-0848");
                FastDriver.BusPartyContactSetup.EmailNumber.FASetText("test1@test1.com");
                FastDriver.BottomFrame.Done();
                FastDriver.BusPartyContactsList.SwitchToContentFrame();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BusinessPartyOrganizationSetUp.SwitchToContentFrame();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItem("LastName, FirstName");
                FastDriver.BottomFrame.Done();

    
         }
  
         private void LoginFastAdmSite(string UserName = null, string Password = null)
            
         {

             var website = AutoConfig.FASTAdmURL;
             UserName = UserName ?? AutoConfig.UserName;
             Password = Password ?? AutoConfig.UserPassword;
             Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
             FASTLogin.Login(website, Credentials, true);
         }

          private string License(string state,string type)
         {

             string Lic_number = Support.RandomString("NNNNNNA");
             FastDriver.LicenseInformationDlg.WaitForScreenToLoad();
             FastDriver.LicenseInformationDlg.ID.FASetText(Lic_number);
             FastDriver.LicenseInformationDlg.State.FASelectItem(state);
             FastDriver.LicenseInformationDlg.StateLicenseType.FASelectItem(type);
             FastDriver.DialogBottomFrame.ClickDone();
             FastDriver.NotesEntryDlg.EnterNote("License Created");
             FastDriver.DialogBottomFrame.ClickDone();
             return Lic_number;

         }

        private string NMLSLicense()
         {

             string Lic_number1 = Support.RandomString("NNNNNNA");
             FastDriver.LicenseInformationDlg.WaitForScreenToLoad();
             FastDriver.LicenseInformationDlg.NMLS.FASetCheckbox(true);
             FastDriver.LicenseInformationDlg.ID.FASetText(Lic_number1);
             FastDriver.DialogBottomFrame.ClickDone();
             FastDriver.NotesEntryDlg.EnterNote("NMLS License Created");
             FastDriver.DialogBottomFrame.ClickDone();
             return Lic_number1;

         }

        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
