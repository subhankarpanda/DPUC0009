﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using System.Linq;
using FASTWCFHelpers.FastFileService;
using System.Threading;
using System.Collections.Generic;


namespace FileManagement
{
    [CodedUITest]
    public class FMUC0071 : MasterTestClass
    {

#region dependencies
      //  1.System displays “Duplicate File Search Screen” if the “Enable Duplicate Check from QFE/QRE” is selected on the Processing Region Setup screen 
        #endregion
        #region Test FMUC0071_BAT0001
        /// <summary>
        /// MF1_00: Create a New File Using Quick File Entry.
        /// FM5332  Add QFE/QRE Business Parties  
        /// FM5345  Select Business Source  
        /// FM5359  File Number  
        /// FM5380  New Lender  
        /// FM5412  Enter File Note  
        /// </summary>
        [TestMethod]
        public void FMUC0071_BAT0001()
        {

            try
            {
                Reports.TestDescription = "MF1_00: Create a New File Using Quick File Entry.";
                Reports.StatusUpdate("This test case also covers BRs - FM5332 FM5345 FM5359 FM5380 FM5412", true);

                #region Fast Search Setting
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with business party references.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1",BSREF:@"1234567891");
                SetDirectedByGABDetails("HUDLEASE03", DBRef: @"1234567894");
                SetServiceType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                //
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                AddInstructions();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000"+FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNewLenderDetails();
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1", @"1234567896");
                SetNotes();              
                //
                Reports.TestStep = "Get all the entered data from QFE page";
                Dictionary<string, string> PropertyDetailsQFE = new Dictionary<string, string>();
                PropertyDetailsQFE = FastDriver.QuickFileEntry.GetPropDetailsOnQFEPage;
                //
                Dictionary<string, string> BuyerDetailsQFE = new Dictionary<string, string>();
                BuyerDetailsQFE = FastDriver.QuickFileEntry.GetBuyerDetailsOnQFEPage;
                //
                Dictionary<string, string> SellerDetailsQFE = new Dictionary<string, string>();
                SellerDetailsQFE = FastDriver.QuickFileEntry.GetSellerDetailsOnQFEPage;
                //
                Reports.TestStep = "Get references for all business parties";
                string BusinessPartyReference = FastDriver.QuickFileEntry.BusinessSourceReference.FAGetValue();
                string DirectedByReference = FastDriver.QuickFileEntry.DirectedBYReference.FAGetValue();
                string BusinessPartyLenderReference = FastDriver.QuickFileEntry.NewLenderInformationReference.FAGetValue();
                string AssociateBusinessPartyReference = FastDriver.QuickFileEntry.AssociatedBusinessPartyReference.FAGetValue();
                //
                Reports.TestStep = "Click Done to create QFE";
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);

                VerifyDataInFileHomePage(PropertyDetailsQFE, BuyerDetailsQFE, SellerDetailsQFE);
                Reports.TestStep = "Verification of the Business party References";
                //
                Support.AreEqualTrim(BusinessPartyReference, FastDriver.FileHomepage.BusinessPartyReference.FAGetValue());
                Support.AreEqualTrim(DirectedByReference, FastDriver.FileHomepage.DirectedByReference.FAGetValue());
                Support.AreEqualTrim(BusinessPartyLenderReference, FastDriver.FileHomepage.BusinessPartyLenderReference.FAGetValue());
                Support.AreEqualTrim(AssociateBusinessPartyReference, FastDriver.FileHomepage.AssociateBusinessPartyReference.FAGetValue());
                //
                Reports.TestStep = @"Validate Event 'Fast Search Initiated' in Event Tracking log";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqualTrim("Success",FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event",@"[Fast Search Initiated]","Event",TableAction.Click).Status.ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_BAT0002

        [TestMethod]
        public void FMUC0071_BAT0002()
        {

            try
            {
                Reports.TestDescription = "AF4_01: Buyer as an Additional Role(ADM).";
                Reports.StatusUpdate("This set up flow is included as a part of BAT0003,4,5", true);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_BAT0003
        /// <summary>
        /// 
        /// FM5429  Updating Fields  
        /// FM8751  New Additional Roles  
        /// FM8752  Copy GAB Information and Create Link to Wire Instructions  
        /// </summary>
        [TestMethod]
        public void FMUC0071_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF4_00_FM5429_FM8751_FM8752: Buyer as an Additional Role(File). AF4_01: Buyer as an Additional Role(ADM)";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");

                Reports.TestStep = "Click Version button to enable editing of key fields";
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(5000);

                Reports.TestStep = "Set up Email/ Buyer Seller Type for HUDFLINSR1.";
                FastDriver.BusPartyOrgSetUp.BuyerSellerType.FASelectItem(@"Business Entity");
                string BuyerSellerType=FastDriver.BusPartyOrgSetUp.BuyerSellerType.FAGetSelectedItem().Replace(" ","");
                Thread.Sleep(1000);
               string SSNTIN= FastDriver.BusPartyOrgSetUp.TaxIdNumber.FAGetValue();
               if (string.IsNullOrEmpty(SSNTIN))
               {
                   FastDriver.BusPartyOrgSetUp.TaxIdNumber.FASetText("123456789" + FAKeys.Tab);
                   Thread.Sleep(1000);
                   SSNTIN = FastDriver.BusPartyOrgSetUp.TaxIdNumber.FAGetValue();
               }
                FastDriver.BusPartyOrgSetUp.EmailNumber.FASetText(@"busparty@regression.com");
                //
                Dictionary<string, string> AddressDetails = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing"); 
                BusinessOrganizationParameters BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Mailing";
                BusOrgParams.AddressLine1 = @"Fire Insurance 1 business street 1";
                BusOrgParams.AddressLine2 = @"Fire Insurance 1 business street 2";
                BusOrgParams.AddressLine3 = @"Fire Insurance 1 business street 3";
                BusOrgParams.AddressLine4 = @"Fire Insurance 1 business street 4";
                BusOrgParams.City = @"Fire Insurance 1 business city";
                BusOrgParams.State = "NY";
                BusOrgParams.Zip = @"74081-6545";
                BusOrgParams.County = @"Fire Insurance 1 business county";
                string value = "Success";
                if (!AddressDetails.TryGetValue("Status", out value))
                {

                    FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Mailing", BusOrgParams);

                }
                AddressDetails = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
                Dictionary<string, string[]> PhoneDetails = FastDriver.BusPartyOrgSetUp.GetPhoneDetails(); 
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                //
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                //
                Reports.TestStep = "Create Order with Buyer as Additional Role.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1", AdditionalRole: @"Buyer");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Navigate to Buyer summary screen and click on Edit.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", BuyerSellerType, "Type", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate SSN/TIN.";
                FastDriver.BuyerSellerSetup.BusinessEntityViewEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqualTrim(SSNTIN, FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue());
                Reports.TestStep = "Validate the Buyer data created from Additional Role in QFE.";
                Dictionary<string, string> BuyerDetails = new Dictionary<string, string>();
                BuyerDetails = FastDriver.BuyerSellerSetup.GetBusEntByrDtls;
                string Value = "Flood Insurance 1 for HUD Testing Name 1";
                Support.AreEqualTrim("True", BuyerDetails.TryGetValue("BusinessEntityShortname", out Value).ToString());
                //
                Reports.TestStep = "Validate current Phone details";
                Dictionary<string, string[]> Ex_CurrentPhoneDetails = new Dictionary<string, string[]>();
                Ex_CurrentPhoneDetails = FastDriver.BuyerSellerSetup.GetCurrentPhoneDetails();
                ComparePhoneDetails(Ex_CurrentPhoneDetails, PhoneDetails);
                //
                Reports.TestStep = "Validate Current address details";
                Dictionary<string, string> Ex_CurrentAddressDetails = new Dictionary<string, string>();
                Ex_CurrentAddressDetails = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;                              
                bool compare = CompareDictionaries(SetProperKeysForComparison(Ex_CurrentAddressDetails),SetProperKeysForComparison(AddressDetails));
                Support.AreEqual("True", compare.ToString());
          
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion Test
        //
        #region Test FMUC0071_BAT0004

        [TestMethod]
        public void FMUC0071_BAT0004()
        {

            try
            {
                Reports.TestDescription = "AF6_00: Buyer from a GAB search.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("199");

                Reports.TestStep = "Click Version button to enable editing of key fields";
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(2000);

                Reports.TestStep = "Set up Email/ Buyer Seller Type.";
                FastDriver.BusPartyOrgSetUp.BuyerSellerType.FASelectItem(@"Business Entity");
                Thread.Sleep(1000);
                FastDriver.BusPartyOrgSetUp.EmailNumber.FASetText(@"cbilsland@firstam.com");
                Dictionary<string, string> AddressDetails = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
                BusinessOrganizationParameters BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Mailing";
                BusOrgParams.AddressLine1 = @"Fire Insurance 1 business street 1";
                BusOrgParams.AddressLine2 = @"Fire Insurance 1 business street 2";
                BusOrgParams.AddressLine3 = @"Fire Insurance 1 business street 3";
                BusOrgParams.AddressLine4 = @"Fire Insurance 1 business street 4";
                BusOrgParams.City = @"Fire Insurance 1 business city";
                BusOrgParams.State = "NY";
                BusOrgParams.Zip = @"74081-6545";
                BusOrgParams.County = @"Fire Insurance 1 business county";
                string value = "Success";
                if (!AddressDetails.TryGetValue("Status", out value))
                {

                    FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Mailing", BusOrgParams);

                }
                AddressDetails = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
                Dictionary<string, string[]> PhoneDetails = FastDriver.BusPartyOrgSetUp.GetPhoneDetails();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create Order with Buyer as Additional Role.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1", AdditionalRole: @"Buyer");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Buyer summary screen and click on Edit.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("#1", "1", "#2", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Reports.TestStep = "Click on Search button.";
                FastDriver.BuyerSellerSetup.Search();

                Reports.TestStep = "Search a GAB for Buyer screen and click on modify GAB.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: @"199");

                Reports.TestStep = "Validate the Buyer data added from GAB.";
                //
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Dictionary<string, string> BuyerDetails = new Dictionary<string, string>();
                BuyerDetails = FastDriver.BuyerSellerSetup.GetBusEntByrDtls;
                string Value = @"Thomas Bucaro";
                Support.AreEqualTrim("True", BuyerDetails.TryGetValue("BusinessEntityShortname", out Value).ToString());
                //
                Reports.TestStep = "Validate Current address details";
                Dictionary<string, string> Ex_CurrentAddressDetails = new Dictionary<string, string>();
                Ex_CurrentAddressDetails = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
              bool compare = CompareDictionaries(SetProperKeysForComparison(Ex_CurrentAddressDetails), SetProperKeysForComparison(AddressDetails));
                Support.AreEqual("True", compare.ToString());
                //
                Reports.TestStep = "Validate forwarding address details";
                compare = false;
                Dictionary<string, string> Ex_FWAddressDetails = new Dictionary<string, string>();
                Ex_FWAddressDetails = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
                compare = CompareDictionaries(SetProperKeysForComparison(Ex_FWAddressDetails), SetProperKeysForComparison(AddressDetails));
                Support.AreEqual("True", compare.ToString());
                //
                Reports.TestStep = "Validate Current Email details";
                Dictionary<string, string[]> Ex_CurrentPhoneDetails = new Dictionary<string, string[]>();
                Ex_CurrentPhoneDetails = FastDriver.BuyerSellerSetup.GetCurrentPhoneDetails();
                Support.AreEqualTrim(@"cbilsland@firstam.com", Ex_CurrentPhoneDetails["E-Mail"][0]);
                //
                Reports.TestStep = "Validate current Phone details";
                compare = false;
                Ex_CurrentPhoneDetails = FastDriver.BuyerSellerSetup.GetCurrentPhoneDetails();
                compare =ComparePhoneDetails(Ex_CurrentPhoneDetails, PhoneDetails);
                Support.AreEqual("True", compare.ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_BAT0005

        [TestMethod]
        public void FMUC0071_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF5_00: Seller as an Additional Role.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");

                Reports.TestStep = "Click Version button to enable editing of key fields";
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(5000);

                Reports.TestStep = "Set up Email/ Buyer Seller Type for HUDFLINSR1.";
                FastDriver.BusPartyOrgSetUp.BuyerSellerType.FASelectItem(@"Business Entity");
                Thread.Sleep(1000);
                FastDriver.BusPartyOrgSetUp.EmailNumber.FASetText(@"busparty@regression.com");
                //
                Dictionary<string, string> AddressDetails = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
                BusinessOrganizationParameters BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Mailing";
                BusOrgParams.AddressLine1 = @"Fire Insurance 1 business street 1";
                BusOrgParams.AddressLine2 = @"Fire Insurance 1 business street 2";
                BusOrgParams.AddressLine3 = @"Fire Insurance 1 business street 3";
                BusOrgParams.AddressLine4 = @"Fire Insurance 1 business street 4";
                BusOrgParams.City = @"Fire Insurance 1 business city";
                BusOrgParams.State = "NY";
                BusOrgParams.Zip = @"74081-6545";
                BusOrgParams.County = @"Fire Insurance 1 business county";
                string value = "Success";
                if (!AddressDetails.TryGetValue("Status", out value))
                {

                    FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Mailing", BusOrgParams);

                }
                AddressDetails = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
                Dictionary<string, string[]> PhoneDetails = FastDriver.BusPartyOrgSetUp.GetPhoneDetails();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Create Order with Seller as Additional Role.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1", AdditionalRole: @"Seller");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Navigate to Buyer/Seller summary screen and click on Edit.";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(4, "BusinessEntity", 4, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate the Seller data created from Additional Role in QFE.";
                Dictionary<string, string> SellerDetails = new Dictionary<string, string>();
                SellerDetails = FastDriver.BuyerSellerSetup.GetBusEntByrDtls;
                string Value = "Flood Insurance 1 for HUD Testing Name 1";
                Support.AreEqualTrim("True", SellerDetails.TryGetValue("BusinessEntityShortname", out Value).ToString());
                //
                Reports.TestStep = "Validate current Phone details";
                Dictionary<string, string[]> Ex_CurrentPhoneDetails = new Dictionary<string, string[]>();
                Ex_CurrentPhoneDetails = FastDriver.BuyerSellerSetup.GetCurrentPhoneDetails();
                ComparePhoneDetails(Ex_CurrentPhoneDetails, PhoneDetails);
                //
                Reports.TestStep = "Validate Current address details";
                Dictionary<string, string> Ex_CurrentAddressDetails = new Dictionary<string, string>();
                Ex_CurrentAddressDetails = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
                bool compare = CompareDictionaries(SetProperKeysForComparison(Ex_CurrentAddressDetails), SetProperKeysForComparison(AddressDetails));
                Support.AreEqual("True", compare.ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_BAT0006

        [TestMethod]
        public void FMUC0071_BAT0006()
        {

                Reports.TestDescription = "AF7_00: Seller from a GAB search.";

                try
                {
                    Reports.TestStep = "Login to ADM";
                    ADMLOGIN();
                    FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                    Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                    FastDriver.AddressBookSearch.EditGAB("199");

                    Reports.TestStep = "Click Version button to enable editing of key fields";
                    FastDriver.BusPartyOrgSetUp.Version.FAClick();
                    Thread.Sleep(5000);

                    Reports.TestStep = "Set up Email/ Buyer Seller Type.";
                    FastDriver.BusPartyOrgSetUp.BuyerSellerType.FASelectItem(@"Business Entity");
                    Thread.Sleep(1000);
                    FastDriver.BusPartyOrgSetUp.EmailNumber.FASetText(@"cbilsland@firstam.com");
                    Dictionary<string, string> AddressDetails = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
                    BusinessOrganizationParameters BusOrgParams = new BusinessOrganizationParameters();
                    BusOrgParams.Addresstype = "Mailing";
                    BusOrgParams.AddressLine1 = @"Fire Insurance 1 business street 1";
                    BusOrgParams.AddressLine2 = @"Fire Insurance 1 business street 2";
                    BusOrgParams.AddressLine3 = @"Fire Insurance 1 business street 3";
                    BusOrgParams.AddressLine4 = @"Fire Insurance 1 business street 4";
                    BusOrgParams.City = @"Fire Insurance 1 business city";
                    BusOrgParams.State = "NY";
                    BusOrgParams.Zip = @"74081-6545";
                    BusOrgParams.County = @"Fire Insurance 1 business county";
                    string value = "Success";
                    if (!AddressDetails.TryGetValue("Status", out value))
                    {

                        FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                    }
                    else
                    {
                        FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Mailing", BusOrgParams);

                    }
                    AddressDetails = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
                    Dictionary<string, string[]> PhoneDetails = FastDriver.BusPartyOrgSetUp.GetPhoneDetails();
                    FastDriver.BottomFrame.Done();
                    Thread.Sleep(5000);
                    Reports.TestStep = "Log into FAST application.";
                    IISLOGIN();
                    //
                    Reports.TestStep = "Create Order with Seller as Additional Role.";
                    OpenQFEPage();
                    SetBusinessSourceDetails(@"HUDFLINSR1", AdditionalRole: @"Seller");
                    SetDirectedByGABDetails(@"HUDLEASE03");
                    SetServiceType(true, true);
                    FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                    SetFormType();
                    FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                    SetBlankProgramType();
                    SetPropertyDetailsInQFE();
                    SetNotes();
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Navigate to Seller summary screen and click on Edit.";
                    FastDriver.BuyerSellerSummary.Open(false);
                    FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("#1", "1", "#2", TableAction.Click);
                    FastDriver.BuyerSellerSummary.Edit();
                    FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                    Reports.TestStep = "Click on Search button.";
                    FastDriver.BuyerSellerSetup.Search();

                    Reports.TestStep = "Search a GAB for Buyer screen and click on modify GAB.";
                    FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                    FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: @"199");

                    Reports.TestStep = "Validate the Seller data added from GAB.";
                    //
                    Dictionary<string, string> SellerDetails = new Dictionary<string, string>();
                    SellerDetails = FastDriver.BuyerSellerSetup.GetBusEntByrDtls;
                    string Value = @"Thomas Bucaro";
                    Support.AreEqualTrim("True", SellerDetails.TryGetValue("BusinessEntityShortname", out Value).ToString());
                    //
                    Reports.TestStep = "Validate Current address details";
                    Dictionary<string, string> Ex_CurrentAddressDetails = new Dictionary<string, string>();
                    Ex_CurrentAddressDetails = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
                    CompareDictionaries(SetProperKeysForComparison(Ex_CurrentAddressDetails),SetProperKeysForComparison(AddressDetails));
                    //
                    Reports.TestStep = "Validate forwarding address details";
                    Dictionary<string, string> Ex_FWAddressDetails = new Dictionary<string, string>();
                    Ex_FWAddressDetails = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
                    bool compare = CompareDictionaries(SetProperKeysForComparison(Ex_FWAddressDetails), SetProperKeysForComparison(AddressDetails));
                    Support.AreEqual("True", compare.ToString());
                    //
                    Reports.TestStep = "Validate Current Email details";
                    Dictionary<string, string[]> Ex_CurrentPhoneDetails = new Dictionary<string, string[]>();
                    Ex_CurrentPhoneDetails = FastDriver.BuyerSellerSetup.GetCurrentPhoneDetails();
                    string [] Value1 = {@"cbilsland@firstam.com",""};
                    Support.AreEqualTrim("True", Ex_CurrentPhoneDetails.TryGetValue("E-Mail", out Value1).ToString());
                    //
                    Reports.TestStep = "Validate current Phone details";

                    Ex_CurrentPhoneDetails = FastDriver.BuyerSellerSetup.GetCurrentPhoneDetails();
                    ComparePhoneDetails(Ex_CurrentPhoneDetails, PhoneDetails);
                }
                catch (Exception ex)
                {
                    Support.Fail(ex.Message);
                }

        }
        #endregion Test
        //
        #region Test FMUC0071_BAT0007
        /// <summary>
        /// FM9692A  Filtering File's Program Type dropdown list  	5.0 626 Map Program Type
        ///  When the file Business Organization is associated with a Program Type, 
        ///   then the system will limit the Program Type dropdown list based on the business source (Business Org) selection.  
        /// </summary>
        [TestMethod]
        public void FMUC0071_BAT0007()
        {

            try
            {
                Reports.TestDescription = "AF8a8b_00: Selecting a Business Source with Program Type(s)/Selecting a Business Source with Instructions.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                bool status =CheckPresenceOrAddRequiredSplInstruction("Regression_Set1_Instruction1");
                if (!status)
                    Reports.StatusUpdate("Precondition failed", false);
                //
                FastDriver.ProgramTypeSetup.Open();
                string ProgramTypeName = "Sanity_Map_Program_Type_1";
                Dictionary<string, List<string>> ProgramTypeDetails = new Dictionary<string, List<string>>();
                try
                {
                    ProgramTypeDetails = FastDriver.ProgramTypeSetup.GetDetailsofProgramType(ProgramTypeName);
                }
                catch
                {
                    Reports.StatusUpdate("Given Prog type is not present", true);
                }
                //
                Reports.TestStep = "Search a GAB 247 in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("247");

                Reports.TestStep = "Click Version button to enable editing of key fields";
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(2000);
                Reports.TestStep = "Select the instructions.";
                FastDriver.BusPartyOrgSetUp.InstructionsAddRemove.FAClick();

                Reports.TestStep = "Select the Instruction.";
                FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction("#2", "Regression_Set1_Instruction1", "#1", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                Thread.Sleep(2000);
           
                Reports.TestStep = "Verify the addition of Program Name in the table.";
                FastDriver.ProgramTypes.Open(@"Lenders Advantage");
                FastDriver.ProgramTypes.AddRemove.FAClick();
                Reports.TestStep = "DeSelect all a programType.";
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad();

                for (int i = 1; i < FastDriver.ProgramTypesDlg.ProgramTable.GetRowCount() - 1; i++)
                {
                    FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction(i, 1, TableAction.Off);
                }
                Reports.TestStep = "Select a programType.";
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad();

                if (FastDriver.ProgramTypesDlg.ProgramTable.FAGetText().Contains("Sanity_Map_Program_Type_1"))
                {
                    FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction("#2", "Sanity_Map_Program_Type_1", "#1", TableAction.On);
                }
                else
                    Reports.StatusUpdate("Given program type is not present.Pls chck in admin", false);


                FastDriver.DialogBottomFrame.ClickDone();
                Thread.Sleep(1000);
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Thread.Sleep(2000);
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Thread.Sleep(1000);
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create Order with Program Type.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"247");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                Reports.TestStep = "FM9692 system will limit the Program Type dropdown list based on the business source";
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(ProgramTypeDetails["TransactionTypes"][1]);  //@"Sale w/Mortgage"
                Support.AreEqual("True", FastDriver.QuickFileEntry.ProgramType.FAGetSelectedItem().Contains(@"Sanity_Map_Program_Type_1").ToString());
                //
                Reports.TestStep = @"FM9692B If the file Transaction Type changes, the Program Type list will be filtered based on the user's selection of the Transaction Types";
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Accommodation");
                Support.AreEqual("False", FastDriver.QuickFileEntry.ProgramType.FAGetText().Contains(@"Sanity_Map_Program_Type_1").ToString());
                //
                Reports.TestStep = "Select a programType.";
                FastDriver.QuickFileEntry.SelectProgramType(@"Sanity_Map_Program_Type_1");
                Support.AreEqual(@"Sanity_Map_Program_Type_1", FastDriver.QuickFileEntry.ProgramType.FAGetSelectedItem());

                Reports.TestStep = "Check the Override Checkbox.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                if (!FastDriver.QuickFileEntry.ProgramTypeOverride.IsSelected())
                    FastDriver.QuickFileEntry.ProgramTypeOverride.FASetCheckbox(true);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.ProductTable.ScrollIntoView();
                if (!FastDriver.QuickFileEntry.ProductsSelect.IsSelected())
                    FastDriver.QuickFileEntry.ProductsSelect.FASetCheckbox(true);
                Thread.Sleep(4000);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion Test
        #region Test FMUC0071_BAT0008
        /// <summary>
        /// FM9692B  Filtering File's Program Type dropdown list  	
        ///   FM9693  Select Program Type  	
        ///   FM9694  Product Type Auto Select  	
        ///   FM9695  Search Type Auto Select  	
        ///   FM9691  Program Type Hierarchy  
        /// </summary>
        [TestMethod]
        public void FMUC0071_BAT0008()
        {

            try
            {
                Reports.TestDescription = "AF9_00: Selecting a Specific Program Type when Business Source has none.";
                Thread.Sleep(1000);
                Reports.StatusUpdate("This test case also covers BRs - FM9692B FM9693 FM9694 FM9695", true);
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                FastDriver.ProgramTypeSetup.Open();
                string ProgramTypeName = "Sanity_Map_Program_Type_1";
                Dictionary<string, List<string>> ProgramTypeDetails = new Dictionary<string, List<string>>();
                try
                {
                    ProgramTypeDetails=FastDriver.ProgramTypeSetup.GetDetailsofProgramType(ProgramTypeName);
                }
                catch
                {
                    string num=System.Guid.NewGuid().GetHashCode().ToString();
                    ProgramTypeName = "Automation_Test_" + num;
                    if (!FastDriver.ProgramTypeSetup.GetNewProgramType(ProgramTypeName, "2999.12",TransactionType: new[]{"Short Sale w/Mortgage"}, SearchTypes: new[] { "68-Two Owner Search" }, Products: new[] { "Abstract" }, States: new[] { "CA" }, County: new[] { "ORANGE"}))
                        Support.Fail("Precondition failed");
                    else
                        ProgramTypeDetails = FastDriver.ProgramTypeSetup.GetDetailsofProgramType(ProgramTypeName);

                }
                Reports.TestStep = "Search a GAB 247 in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("247");

                Reports.TestStep = "Click Version button to enable editing of key fields";
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(2000);
                Reports.TestStep = "Select the instructions.";
                FastDriver.BusPartyOrgSetUp.InstructionsAddRemove.FAClick();

                Reports.TestStep = "Select the Instruction.";
                FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction("#2", "Regression_Set1_Instruction1", "#1", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                Thread.Sleep(2000);

                Reports.TestStep = "Verify the addition of Program Name in the table.";
                FastDriver.ProgramTypes.Open(@"Lenders Advantage");
                FastDriver.ProgramTypes.AddRemove.FAClick();
                Reports.TestStep = "DeSelect all a programType.";
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad();

                for (int i = 1; i < FastDriver.ProgramTypesDlg.ProgramTable.GetRowCount() - 1; i++)
                {
                        FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction(i, 1, TableAction.Off);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);

                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Create Order with Program Type.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"247");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Accommodation");
                Thread.Sleep(3000);
                Support.AreEqual("False", FastDriver.QuickFileEntry.ProgramType.FAGetText().Contains(ProgramTypeName).ToString());
                //
                Reports.TestStep = "Select a programType.";
                FastDriver.QuickFileEntry.SelectProgramType(ProgramTypeName);
                Reports.TestStep = @"FM9695  Search Type Auto Select - Validate selected programType.";
                Support.AreEqual(ProgramTypeName, FastDriver.QuickFileEntry.ProgramType.FAGetSelectedItem());
                //Support.AreEqual(ProgramTypeName, FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount.FAGetValue());
                foreach (string sType in ProgramTypeDetails["SearchTypes"])
                {
                    Support.AreEqual(@"True", FastDriver.QuickFileEntry.SearchType.FAGetText().Contains(sType).ToString());
                }
                Reports.TestStep = "FM9694  Product Type Auto Select  - Validate productType auto-populated because of program type.";
                //
                foreach (string sType in ProgramTypeDetails["ProductTypes"])
                {
                    Support.AreEqual(@"True", FastDriver.QuickFileEntry.ProductTable.FAGetText().Contains(sType).ToString());
                }
                //
                Reports.TestStep = "Set New loan liability, State from program type defaults";
                FastDriver.QuickFileEntry.ProductTable.ScrollIntoView();
                if (!FastDriver.QuickFileEntry.ProductsSelect.IsSelected())
                    FastDriver.QuickFileEntry.ProductsSelect.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TermsDatesNewLoanLiability.FASetText(ProgramTypeDetails["LiabilityAmount"][0]);
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(ProgramTypeDetails["States"][0]);
                FastDriver.BottomFrame.Done();
                //

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_BAT0009
        /// <summary>
        /// FM5332  Add QFE/QRE Business Parties 
        /// FM4369  Quick Refi  - Borrowers section and screen   
        /// </summary>

        [TestMethod]
        public void FMUC0071_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF1_00: Quick Refi File Entry.";
                //
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                Reports.TestStep = "Navigate to QRE.";
                FastDriver.QuickRefiFileEntry.OpenQREPage();
                //
                Reports.TestStep = "Create Refi Order.";
                FastDriver.QuickRefiFileEntry.CreateStandardFile();
                //
                Reports.TestStep = "Navigate to Buyer summary screen and verify the borrower created via QRE.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "Buyer1Firstname Buyer1Lastname", 1, TableAction.Click);
                //
                Reports.TestStep = "Navigate to Buyer2 summary screen and verify the borrower created via QRE.";
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", 1, TableAction.Click);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_BAT0010
        [TestMethod]
        public void FMUC0071_BAT0010()
        {
            try
            {
                Reports.TestDescription = "AF3_00: Select Production Offices. ";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Enter details to Create Order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
                Reports.TestStep = "Select escrow prod office.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                if (!FastDriver.OfficeSelectionDlg.Office1.IsSelected()) 
                {
                    FastDriver.OfficeSelectionDlg.Office1.FAClick();
                }
                string ProdOfc = FastDriver.OfficeSelectionDlg.OfficeName1.FAGetText();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the EscrowProductionOffice added.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                bool ProdOfficeAdded = false;
                for (int i = 1; i <= FastDriver.QuickFileEntry.EscrowProdOfficeTable.GetRowCount(); i++)
                {
                    string OfficeCell = FastDriver.QuickFileEntry.EscrowProdOfficeTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (OfficeCell.Contains(ProdOfc))
                    {
                        ProdOfficeAdded = true;
                        break;
                    }

                }
                Support.AreEqual(ProdOfficeAdded.ToString(), "True");


                Reports.TestStep = "Select title prod office";
                FastDriver.QuickFileEntry.AddRemoveTitleProdOffice.FAClick();
                Reports.TestStep = "Select office.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                if (!FastDriver.OfficeSelectionDlg.Office1.IsSelected())
                {
                    FastDriver.OfficeSelectionDlg.Office1.FAClick();
                }
                ProdOfc = FastDriver.OfficeSelectionDlg.OfficeName1.FAGetText();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the TitleProductionOffice added.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                ProdOfficeAdded = false;
                for (int i = 1; i <= FastDriver.QuickFileEntry.TitleProdOfficeTable.GetRowCount(); i++)
                {
                    string OfficeCell = FastDriver.QuickFileEntry.TitleProdOfficeTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (OfficeCell.Contains(ProdOfc))
                    {
                        ProdOfficeAdded = true;
                        break;
                    }

                }
                Support.AreEqual(ProdOfficeAdded.ToString(), "True");
                Reports.TestStep = "Complete the order for adding Production offices.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                //SetBuyerSellerDetails();
                //SetNewLenderDetails(@"247");
                //SetAssociatedBusinessPartyDetails(@"HUDASLNDR1");
                SetNotes();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_BAT0011

        [TestMethod]
        public void FMUC0071_BAT0011()
        {

            try
            {
                Reports.TestDescription = "AF2_00: Create New File with Reserved File Number.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Open Reserve filenumber  page";
                FastDriver.ReserveFileNumber.Open();
                string FileNum=FastDriver.ReserveFileNumber.ReserveNewFileNumber("test");
                Reports.TestStep="Enter details to Create Order";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                Reports.TestStep = "create New File with Reserved File Number";
                if(FastDriver.QuickFileEntry.AutoNumber.IsSelected())
                {
                    FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(false);
                }
                    
                FastDriver.QuickFileEntry.FileNum.FASetText(FileNum);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                string Message = "Service File: File Number already exists or reserved.";
                Support.AreEqualTrim(Message, FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0001
        /// <summary>
        /// FM5350  Default Entity Type for QFE/QRE Business Parties  
        /// FM5346  Select or Enter Directed By  
        /// FM5332  Add QFE/QRE Business Parties 
        /// FM5345  Select Business Source 
        /// FM5347  Select or Enter Associated Business Party  
        /// FM5372  Select Owning Office
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0001()
        {

            try
            {
                Reports.TestDescription = "FM5346_FM5347_FM5350_FM5372: Create a New File Using Quick File Entry.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to Create Order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"",WaitCreation:false);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                Reports.TestStep = "FM5350  No Default Entity Type should be selected for business source";
                Support.AreEqualTrim("", FastDriver.AddressBookSearchDlg.EntityType.FAGetSelectedItem());
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: @"199");
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                SetDirectedByGABDetails(@"", WaitCreation: false);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                Reports.TestStep = "FM5350  No Default Entity Type should be selected for Directed by GAB";
                Support.AreEqualTrim("", FastDriver.AddressBookSearchDlg.EntityType.FAGetSelectedItem());
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: @"199");
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetAssociatedBusinessPartyDetails(@"", WaitCreation: false);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                Reports.TestStep = "FM5350  No Default Entity Type should be selected for Associated business party";
                Support.AreEqualTrim("", FastDriver.AddressBookSearchDlg.EntityType.FAGetSelectedItem());
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: @"199");
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "FM5372  Select Owning Office";
                FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItemByIndex(2);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItemByIndex(3);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                string EscrowOwningOffice=FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetSelectedItem();
                string TitleOwningOffice = FastDriver.QuickFileEntry.TitleOwningOffice.FAGetSelectedItem();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetPropertyAddressInQFE();
                FastDriver.BottomFrame.Done();
                                Thread.Sleep(5000);
                Reports.TestStep = "Validate Owning Office on file homepage";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string ACtual_EscrowOwningOffice = FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetSelectedItem();
                string Actual_TitleOwningOffice = FastDriver.FileHomepage.TitleOwningOfficeOffice.FAGetSelectedItem();
                Support.AreEqualTrim(EscrowOwningOffice, ACtual_EscrowOwningOffice);
                Support.AreEqualTrim(TitleOwningOffice, Actual_TitleOwningOffice);


               
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0002
        /// <summary>
        /// FM3262  Mandatory Data to Create File  
        /// FM5344  Select Service Type(s)  
        ///    The system shall require the user to select at least one Service Type for a file (Title, Escrow). 
        ///    The user may select both Service Types for the same file. 
        ///    Each Service Type has its own occurrence of Owning Office and Production Office. 
        ///    The selected service type must enforce the entry of the owning office.  
        ///    For example, if service type selected is "escrow/title", then both owning offices are required.
        /// </summary>

        [TestMethod]
        public void FMUC0071_REG0002()
        {

            try
            {
                Reports.TestDescription = "BR_FM3262_ER2_ER3_ER4_ER5_ER9_FM5344_FM5356_FM5358: Mandatory Data to Create File.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create Order without Business Source.";
                OpenQFEPage();
                FastDriver.QuickFileEntry.Title.FAClick();
                string IEMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqualTrim("Please enter business source first.", IEMessage);
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();
                OpenQFEPage();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                SetFormType();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(4000);

                Reports.TestStep = @"Validate warning message 'Business Source is required'";
                string Message=FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqualTrim(@"Business Source is required", Message);
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Create order without service type.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                SetServiceType(false, false);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate warning message when tried to Create order without Service Type in QFE.";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Service Type is required", Message);
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();
                //
                Reports.TestStep = "Create order without Business Segment.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);

                Reports.TestStep = "Verify warning message when tried to Create order without Business Segment in QFE.";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Business Segment is required", Message);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Set Business segment";
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemByIndex(1);
                //
                Reports.TestStep = "Create order without Transaction Type.";
                FastDriver.QuickFileEntry.TransactionType.FASelectItemByIndex(0);
                SetPropertyDetailsInQFE();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);

                Reports.TestStep = "Verify warning message when tried to Create order without Transaction segment in QFE.";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Transaction Type is required", Message);
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();
                //
                Reports.TestStep = "Create order without Property State.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"");
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                Reports.TestStep = "Verify warning message when tried to Create order without Property State in QFE.";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Property State is a required field.  Please enter State before saving.", Message);
                //
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                SetPropertyDetailsInQFE();
                //
                Reports.TestStep = "Uncheck the Auto number checkbox.";
                if(FastDriver.QuickFileEntry.AutoNumber.IsSelected())
                FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);


                Reports.TestStep = "Validate the warning message when tried to create filr without entering file number in QFE.";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"File number is required", Message);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                //
                Reports.TestStep = "check the Auto number checkbox and uncheck the product.";
                if (!FastDriver.QuickFileEntry.AutoNumber.IsSelected())
                    FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(true);

                if (FastDriver.QuickFileEntry.ProductTable.FAGetText().Contains(@"*ALTA Expanded (Eagle Loan) Policy"))
                    FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", @"*ALTA Expanded (Eagle Loan) Policy", "#1", TableAction.Off);
                else
                    Reports.StatusUpdate("Given product type is not present in table", false);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);

                Reports.TestStep = "Validate the warning message the Product is not selected in QFE.";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Product Type is required", Message);
                //
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Check the product.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", @"*ALTA Expanded (Eagle Loan) Policy", "#1", TableAction.On);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);

                Reports.TestStep = "Create Order with all data in QFE for verification of owning offices.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNewLenderDetails(@"247");
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1");
                SetNotes();

                Reports.TestStep = "Get Required data from QFE page";
                Dictionary<string,string> PropDetails=FastDriver.QuickFileEntry.GetPropDetailsOnQFEPage;
                Dictionary<string, string> BuyerDetails = FastDriver.QuickFileEntry.GetBuyerDetailsOnQFEPage;
                Dictionary<string, string> SellerDetails = FastDriver.QuickFileEntry.GetSellerDetailsOnQFEPage;
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.FileHomepage.Title.IsSelected().ToString());
                Support.AreEqual(@"True", FastDriver.FileHomepage.Escrow.IsSelected().ToString());
                Support.AreEqual(@"Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem());
                Support.AreEqual(@"Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem());
                string Office = FastDriver.FileHomepage.EscrowOwningOfficeOffice.FAGetSelectedItem();
                Support.AreEqualTrim("True", Office.Contains(AutoConfig.SelectedOfficeName).ToString());
                    Office = FastDriver.FileHomepage.TitleOwningOfficeOffice.FAGetSelectedItem();
                    Support.AreEqualTrim("True", Office.Contains(AutoConfig.SelectedOfficeName).ToString());

                Reports.TestStep = "Verify data on file home page";
                VerifyDataInFileHomePage(PropDetails,BuyerDetails,SellerDetails);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0003
        /// <summary>
        /// FM4380  Log File Open Event  
        ///When a new file is saved, the system shall log an event in the Event/Tracking Log, consisting of the following information:
	    ///Event = [Opened]
	    ///Start Date/Time = the server date/time the file is created
	    ///Completion Date/Time = the server date/time the file is created
	    ///Source = FAST Application
	    ///User = the user's employee username 
	    ///Comment = the user's last name, first name 
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0003()
        {

            try
            {
                Reports.TestDescription = "BR_FM4380: Log File Open Event.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create Order";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNewLenderDetails(@"247");
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1");
                SetNotes();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Verify the Event Log for File created(Event)";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("");
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event",@"[Opened]","Event",TableAction.Click);

                Reports.TestStep = "Verify the Event Log for File created(Source)";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Source", @"FAST Application", "Source", TableAction.Click);
                
                Reports.TestStep = "Verify the Event Log for File created(User)";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"User", AutoConfig.UserName.ToUpper(), "User", TableAction.Click);
                
                Reports.TestStep = "To verify the Start Date and Completed Date is equal to current system date";
                string Expected_Start_Completion_Date = DateTime.Now.ToDateString();
                Expected_Start_Completion_Date = Expected_Start_Completion_Date.Replace("-", "/");

              string ActualStartDate=  FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Opened]", "#2", TableAction.GetText).Message;
                Support.AreEqual("True", ActualStartDate.Contains(Expected_Start_Completion_Date).ToString());
                //
                string ActualCompletionDate = FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Opened]", "#3", TableAction.GetText).Message;
                Support.AreEqual("True", ActualCompletionDate.Contains(Expected_Start_Completion_Date).ToString());
                //Comment = the user's last name, first name

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0004

        [TestMethod]
        public void FMUC0071_REG0004()
        {

            try
            {
                Reports.TestDescription = "BR_FM5348_1_FM7514: Select Additional Role for QFE/QRE Business Parties.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create order with Additional Roles(Seller's Attorney, Buyer's Attorney, Mortgage Broker).";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Attorney", DirectedByAddnRole: @"Buyer's Attorney", AssociatedBPAddnRole: "Mortgage Broker");
                
                Reports.TestStep = "Validate the Additional role for Bus Org(Seller's Attorney, Buyer's Attorney, Mortgage Broker).";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(@"Seller's Attorney", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Buyer's Attorney", FastDriver.FileHomepage.DirectedByAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Mortgage Broker", FastDriver.FileHomepage.AssociateBusinessPartyAddtionalRole.FAGetSelectedItem());
               
                Reports.TestStep = "Validate the Attorney Buyer Additional role.";
                FastDriver.AttorneyDetail.Open();
                Support.AreEqualTrim("HUDLEASE03",FastDriver.AttorneyDetail.GABcodeLabel.FAGetText());

                Reports.TestStep = "Validate the Attorney Seller Additional role.";
                FastDriver.AttorneyDetail.Open(false);
                Support.AreEqualTrim("HUDFLINSR1", FastDriver.AttorneyDetail.GABcodeLabel.FAGetText());

                Reports.TestStep = "Validate the Mortgage Broker Additional Role from QFE.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Thread.Sleep(7000);
                Support.AreEqualTrim("HUDASLNDR1", FastDriver.NewLoan.MortgageBrokerGABlabel.FAGetText());

                Reports.TestStep = "Click on skip button to go to QFE.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Payoff Lender", DirectedByAddnRole: @"Assumption Lender", AssociatedBPAddnRole: @"Outside Escrow Company");
//
                Reports.TestStep = "Validate the Additional role for Bus Org(Payoff Lender, Assumption Lender, Outside Escrow Company).";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(@"Payoff Lender", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Assumption Lender", FastDriver.FileHomepage.DirectedByAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Outside Escrow Company", FastDriver.FileHomepage.AssociateBusinessPartyAddtionalRole.FAGetSelectedItem());

                Reports.TestStep = "Validate the Payoffloan Additional role from QFE";
                FastDriver.PayoffLoanDetails.Open();
                Support.AreEqualTrim("HUDFLINSR1", FastDriver.PayoffLoanDetails.GABcodeLabel.FAGetText());

                Reports.TestStep = "Validate Assumption Loan Additional Role from QFE.";
                FastDriver.AssumptionLoanDetails.Open();
                Support.AreEqualTrim("HUDLEASE03", FastDriver.AssumptionLoanDetails.GABcodeLabel.FAGetText());

                Reports.TestStep = "Validate the OEC Additional Role from QFE.";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqualTrim("HUDASLNDR1", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText());

                Reports.TestStep = "Click on skip button to go to QFE.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Buyer's Real Estate Agent", DirectedByAddnRole: @"Seller's Real Estate Agent", AssociatedBPAddnRole: @"Other Real Estate Agent");
                //
                Reports.TestStep = "Validate the Additional role for Bus Org(Buyer/Seller/Other R.E.Agent).";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(@"Buyer's Real Estate Agent", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Seller's Real Estate Agent", FastDriver.FileHomepage.DirectedByAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Other Real Estate Agent", FastDriver.FileHomepage.AssociateBusinessPartyAddtionalRole.FAGetSelectedItem());

                
                Reports.TestStep = "Validate the RE Agent additional role from QFE(sellers).";
                FastDriver.RealEstateBrokerAgentSummary.Open();
               // FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(@"Agent", "Lease 3 for HUD Testing Name 1", "Agent", TableAction.Click);
                Support.AreEqual("True",FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Lease 3 for HUD Testing Name 1").ToString());

                Reports.TestStep = "Validate the RE Agent additional role from QFE(buyer's and other).";
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("BUYER", "AGENT", "Flood Insurance 1 for HUD Testing Name 1").ToString());
                Support.AreEqual("True",FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("OTHER", "AGENT", "Assumption Lender 1 for HUD Test Name 1").ToString());
                
                Reports.TestStep = "Create order with Additional Roles(Buyer/Seller/Other R.E.Broker).";       
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Buyer's Broker", DirectedByAddnRole: @"Seller's Broker", AssociatedBPAddnRole: @"Other Real Estate Broker");

                Reports.TestStep = "Validate the Additional role for Bus Org(Buyer/Seller/Other R.E.Broker).";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(@"Buyer's Broker", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Seller's Broker", FastDriver.FileHomepage.DirectedByAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Other Real Estate Broker", FastDriver.FileHomepage.AssociateBusinessPartyAddtionalRole.FAGetSelectedItem());

                Reports.TestStep = "Validate the RE Broker additional role from QFE(sellers).";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Lease 3 for HUD Testing Name 1").ToString());
                Reports.TestStep = "Validate the RE Agent additional role from QFE(buyer's and other).";
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("BUYER", "BROKER", "Flood Insurance 1 for HUD Testing Name 1").ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("OTHER", "BROKER", "Assumption Lender 1 for HUD Test Name 1").ToString());

                Reports.TestStep = "Create order with Additional Roles(New Lender, Lenders Attorney,OTC).";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"New Lender", DirectedByAddnRole: @"Lender's Attorney", AssociatedBPAddnRole: @"Outside Title Company");

                Reports.TestStep = "Validate the Additional role for Bus Org(New Lender, Lenders Attorney,OTC)).";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(@"New Lender", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Lender's Attorney", FastDriver.FileHomepage.DirectedByAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Outside Title Company", FastDriver.FileHomepage.AssociateBusinessPartyAddtionalRole.FAGetSelectedItem());

                Reports.TestStep = "Validate OTC Additional role from QFE-1.";
                FastDriver.OTCDetail.Open();
                Support.AreEqualTrim("HUDASLNDR1", FastDriver.OTCDetail.GABcodeLabel.FAGetText());

                Reports.TestStep = "Validate the New Lender/Lenders attorney Additional Role from QFE.";
                FastDriver.NewLoan.Open();
                Support.AreEqualTrim("HUDFLINSR1", FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText());
                FastDriver.NewLoan.RelatedPartiesTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.RelatedPartiesNew);
                Support.AreEqualTrim(@"Attorney- Primary", FastDriver.NewLoan.RelatedPartyRoletype.FAGetSelectedItem());

                Reports.TestStep = "Click on skip button to go to QFE.";
                OpenQFEPage();

                Reports.TestStep = "Create order with Additional Roles(Title Agent).";
                SetBusinessSourceDetails(@"HUDASLNDR1", AdditionalRole: @"Title Agent");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                Dictionary<string, string> PropDetailsQFE = FastDriver.QuickFileEntry.GetPropDetailsOnQFEPage;
                SetBuyerSellerDetails();
                SetNewLenderDetails(@"247");
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1", @"Other Real Estate Broker");
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);


                Reports.TestStep = "Validate OTC Additional role from QFE.";
                FastDriver.OTCDetail.Open();
                Support.AreEqualTrim("HUDASLNDR1", FastDriver.OTCDetail.GABcodeLabel.FAGetText());

                Reports.TestStep = "Validate property tax info details entered from QFE.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Thread.Sleep(7000);
                if (!FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.IsVisible())
                FastDriver.PropertyTaxInfoLegalDesciption.GeneralTab.FAClick();
                Thread.Sleep(3000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
               Dictionary<string,string> PropDetails= FastDriver.PropertyTaxInfoGeneral.GetPropertyDetails();
               
                Reports.TestStep = "Compare property details";
                Support.AreEqual("True", CompareDictionaries(SetProperKeysForComparisonForQFE(PropDetails), SetProperKeysForComparisonForQFE(PropDetailsQFE)).ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0005

        [TestMethod]
        public void FMUC0071_REG0005()
        {

            try
            {
                Reports.TestDescription = "BR_FM5348_1_FM7514_1: Select Additional Role for QFE/QRE Business Parties.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create order with Additional Roles(Lender- Originating Branch,Lender- Mortgage Centre, Mortgage Broker).";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Lender- Originating Branch", DirectedByAddnRole: @"Lender- Mortgage Centre", AssociatedBPAddnRole: @"Mortgage Broker");
                
                Reports.TestStep = "Validate the Additional role for Bus Org(Lender-Originate Branch, Lender-Mortgage Centre).";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Support.AreEqual(@"Lender- Originating Branch", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Lender- Mortgage Centre", FastDriver.FileHomepage.DirectedByAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Mortgage Broker", FastDriver.FileHomepage.AssociateBusinessPartyAddtionalRole.FAGetSelectedItem());

                Reports.TestStep = "Validate the Lender- Originating Branch Additional role.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.RelatedPartiesTab.FAClick();
                Thread.Sleep(7000);
                string role1=FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetSelectedItem).Message;
                Support.AreEqualTrim("Lender- Originating Branch", role1);
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction("ID Code", "HUDFLINSR1", "ID Code", TableAction.Click);

                Reports.TestStep = "Validate Lender- Mortgage Centre Additional role.";
                role1 = FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.GetSelectedItem).Message;
                Support.AreEqualTrim("Lender- Mortgage Centre", role1);
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction("ID Code", "HUDLEASE03", "ID Code", TableAction.Click);

                Reports.TestStep = "Validate the Mortgage Broker Additional Role from QFE.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Thread.Sleep(7000);
                Support.AreEqualTrim("HUDASLNDR1", FastDriver.NewLoan.MortgageBrokerGABlabel.FAGetText());             
               //
                //
                Reports.TestStep = "Create order with Additional Roles(Lender-Signing Location, Lender-Mobile Banker).";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Lender- Signing Location", DirectedByAddnRole: @"Lender- Mobile Banker", AssociatedBPAddnRole: @"");
                
                Reports.TestStep = "Validate the Additional role for Bus Org(Lender-Sign Location, Lender-Mobile Banker).";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"Lender- Signing Location", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
                Support.AreEqual(@"Lender- Mobile Banker", FastDriver.FileHomepage.DirectedByAddtionalRole.FAGetSelectedItem());
               
                Reports.TestStep = "Validate the Related parties additional role from QFE-1.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.RelatedPartiesTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.RelatedPartiesNew);
                role1 = FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetSelectedItem).Message;
                Support.AreEqualTrim("Lender- Signing Location", role1);
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(@"#2", "HUDFLINSR1", "#2", TableAction.Click);
                Reports.TestStep = "Validate the Related parties additional role from QFE-2.";
                role1 = FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.GetSelectedItem).Message;
                Support.AreEqualTrim(@"Lender- Mobile Banker", role1);
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(@"#2", "HUDLEASE03", "#2", TableAction.Click);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0006

        [TestMethod]
        public void FMUC0071_REG0006()
        {

            try
            {
                Reports.TestDescription = "BR_FM5348_2: Valid values for Additional Role.";
                Reports.StatusUpdate("This flow is covered in REG0002", true);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0007

        [TestMethod]
        public void FMUC0071_REG0007()
        {

            try
            {
                Reports.TestDescription = "BR_FM6286_FM6285 : Include Edited Contact Info in Additional Roles/New Lender as Additional Role.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create order to include edited contact info.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem(@"New Lender");  
                Reports.TestStep = "ENter contact info.";
                if (!FastDriver.QuickFileEntry.BusinessSourceEditCont.IsSelected())
                    FastDriver.QuickFileEntry.BusinessSourceEditCont.FASetCheckbox(true);
                Thread.Sleep(1000);
                FastDriver.QuickFileEntry.BusinessSourceBusinessPhone.FASetText(@"222222-2222");
                FastDriver.QuickFileEntry.BusinessSourceBusinessPhoneExtension.FASetText(@"255");
                FastDriver.QuickFileEntry.BusinessSourceBusinessFax.FASetText(@"222222-2222");
                FastDriver.QuickFileEntry.BusinessSourceCellPhone.FASetText(@"222222-2222");
                FastDriver.QuickFileEntry.BusinessSourcePager.FASetText(@"222222-2222");
                FastDriver.QuickFileEntry.BusinessSourceEmailAddress.FASetText(@"Editemail@mail.com");
              
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1");
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                // 
                Reports.TestStep = "Validate the Edited contact details in FHP.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"(222)222-2222", FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue());
                Support.AreEqual(@"255", FastDriver.FileHomepage.BusinessPartyBusPhoneExtension.FAGetValue());
                Support.AreEqual(@"(222)222-2222", FastDriver.FileHomepage.BusinessPartyBusFax.FAGetValue());
                Support.AreEqual(@"(222)222-2222", FastDriver.FileHomepage.BusinessPartyCellPhone.FAGetValue());
                Support.AreEqual(@"(222)222-2222", FastDriver.FileHomepage.BusinessPartyPager.FAGetValue());
                Support.AreEqual(@"Editemail@mail.com", FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue());
                // 
                Reports.TestStep = "Verify the edited contact details from QFE in New Loan.";
                FastDriver.NewLoan.Open();

                Support.AreEqual(@"(222)222-2222", FastDriver.NewLoan.LoanDetailsBusinessPhone.FAGetValue());
                Support.AreEqual(@"255", FastDriver.NewLoan.LoanDetailsBusinessPhoneExtension.FAGetValue());
                Support.AreEqual(@"(222)222-2222", FastDriver.NewLoan.LoanDetailsBusinessFax.FAGetValue());
                Support.AreEqual(@"(222)222-2222", FastDriver.NewLoan.LoanDetailsCellPhone.FAGetValue());
                Support.AreEqual(@"(222)222-2222", FastDriver.NewLoan.LoanDetailsPager.FAGetValue());
                Support.AreEqual(@"Editemail@mail.com", FastDriver.NewLoan.LoanDetailsEmailAddress.FAGetValue());
                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0008

        [TestMethod]
        public void FMUC0071_REG0008()
        {
            try
            {
                Reports.TestDescription = "BR_FM5352 : New Lender as Additional Role.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Select New lender as additional role in Business source and New Lender section.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1", AdditionalRole: @"New Lender");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNewLenderDetails(@"247");
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1");
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);

                Reports.TestStep = "Verify the New lender is created from New Lender section in QFE.";
                FastDriver.NewLoan.Open();
                Support.AreEqual(@"247", FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0009
        /// <summary>
        /// FM5351  Select Additional Roles for QFE/QRE Business Parties  
        ///      If the user selects the same Additional Role for more than one business party on the QFE/QRE, 
        ///      the system shall use the Additional Role to create charge process instances in the following order:
        ///   * If user selects the same Additional Role for Business Source + Directed By + Associated Business Party, 
        ///      system shall create the charge process using Business Source only and shall not create charge processes for Directed By or Associated Business Party.
        ///
        ///   * If user selects the same Additional Role for Directed By + Associated Business Party (not for Business Source),
        ///      system shall create the charge process using Directed By only and shall not create a charge process for Associated Business Party.
        ///
        ///   * If user selects an Additional Role for Associated Business Party (not for Business Source or Directed By),
        ///      system shall create the charge process using Associated Business Party.

        /// </summary>

        [TestMethod]
        public void FMUC0071_REG0009()
        {
            try
            {
                Reports.TestDescription = "BR_FM5351: Select Additional Roles for QFE/QRE Business Parties.";
                // 

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Enter same additional role in Business Source, Directed By and Associated Business Party.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Attorney", DirectedByAddnRole: @"Seller's Attorney", AssociatedBPAddnRole: @"Seller's Attorney");
                // 
                Reports.TestStep = "Validate the Attorney Seller Additional role.";
                FastDriver.AttorneyDetail.Open(false);
                Support.AreEqual(@"HUDFLINSR1", FastDriver.AttorneyDetail.GABcodeLabel.FAGetText());

                // 
                Reports.TestStep = "Enter same additional role in Directed By and Associated Business Party.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"", DirectedByAddnRole: @"Seller's Attorney", AssociatedBPAddnRole: @"Seller's Attorney");

                Reports.TestStep = "Validate the Attorney Seller Additional role when both Directed By and Associated Business Party have same additional role.";
                FastDriver.AttorneyDetail.Open(false);
                Support.AreEqual(@"HUDLEASE03", FastDriver.AttorneyDetail.GABcodeLabel.FAGetText());

                // 
                Reports.TestStep = "Enter additional role in  Associated Business Party only.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"", DirectedByAddnRole: @"", AssociatedBPAddnRole: @"Seller's Attorney");

                // 
                Reports.TestStep = "Validate the Attorney Seller Additional role when only Associated Business Party has additional role.";
                FastDriver.AttorneyDetail.Open(false);
                Support.AreEqual(@"HUDASLNDR1", FastDriver.AttorneyDetail.GABcodeLabel.FAGetText());
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0010

        [TestMethod]
        public void FMUC0071_REG0010()
        {

            try
            {
                Reports.TestDescription = "BR_FM5353: RE Broker and RE Agent as Additional Role.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Business Source Add'l Role=Directed By Add'l Role=Broker. Associated Business Party Add'l Role =Agent.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Broker", DirectedByAddnRole: @"Seller's Broker", AssociatedBPAddnRole: @"Seller's Real Estate Agent");

                // 
                Reports.TestStep = "Validate Broker = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Flood Insurance 1 for HUD Testing Name 1");

                Reports.TestStep = "Validate Agent = Associated Business Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Assumption Lender 1 for HUD Test Name 1");

                Reports.TestStep = "Business Source Add'l Role-Broker Directed By Add'l Role-Agent Associated Business Party Add'l Role-Agent.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Broker", DirectedByAddnRole: @"Seller's Real Estate Agent", AssociatedBPAddnRole: @"Seller's Real Estate Agent");
                //
                Reports.TestStep = "Validate Broker = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Flood Insurance 1 for HUD Testing Name 1");
                
                Reports.TestStep = "Validate Agent = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Lease 3 for HUD Testing Name 1");
                //
                Reports.TestStep = "Business Source Add'l Role-Agent Directed By Add'l Role-Broker Associated Business Party Add'l Role-Broker.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Real Estate Agent", DirectedByAddnRole: @"Seller's Real Estate Agent", AssociatedBPAddnRole: @"Seller's Broker");

                Reports.TestStep = "Validate Broker = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Lease 3 for HUD Testing Name 1");               
                Reports.TestStep = "Validate Agent = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Flood Insurance 1 for HUD Testing Name 1");

                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0011

        [TestMethod]
        public void FMUC0071_REG0011()
        {

            try
            {
                Reports.TestDescription = "BR_FM5353_1: RE Broker and RE Agent as Additional Role.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Business Source Add'l Role-Agent Directed By Add'l Role-Agent Associated Business Party Add'l Role-Broker.";
                CreateQFEWithAdditionalRole(@"Seller's Real Estate Agent", @"Seller's Real Estate Agent", @"Seller's Broker");
                                // 
                Reports.TestStep = "Validate Broker = Associated Business Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Assumption Lender 1 for HUD Test Name 1");
                Reports.TestStep = "Validate Agent = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Flood Insurance 1 for HUD Testing Name 1");
                // 
                // 
                Reports.TestStep = "Business Source Add'l Role-Broker Directed By Add'l Role-Agent Associated Business Party Add'l Role-Broker.";
                CreateQFEWithAdditionalRole( @"Seller's Broker",@"Seller's Real Estate Agent",@"Seller's Broker");
                                // 
                Reports.TestStep = "Validate Broker = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Flood Insurance 1 for HUD Testing Name 1");

                Reports.TestStep = "Validate Agent = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Lease 3 for HUD Testing Name 1");
                // 
                Reports.TestStep = "Business Source Add'l Role-Agent Directed By Add'l Role-Broker Associated Business Party Add'l Role-Agent.";
                CreateQFEWithAdditionalRole(@"Seller's Real Estate Agent", @"Seller's Broker",@"Seller's Real Estate Agent");
                
                // 
                Reports.TestStep = "Validate Broker = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Lease 3 for HUD Testing Name 1");

                Reports.TestStep = "Validate Agent = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Flood Insurance 1 for HUD Testing Name 1");
                // 

                Reports.TestStep = "Business Source Add'l Role-Broker Directed By Add'l Role-Broker Associated Business Party Add'l Role-Nil.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole:@"Seller's Broker", DirectedByAddnRole:@"Seller's Broker");
                
                // 
                Reports.TestStep = "Validate Broker = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Flood Insurance 1 for HUD Testing Name 1");
                // 
                Reports.TestStep = "Business Source Add'l Role-Broker Directed By Add'l Role-Agent Associated Business Party Add'l Role-Nil.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Broker", DirectedByAddnRole: @"Seller's Real Estate Agent");               
                // 
                Reports.TestStep = "Validate Broker = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Flood Insurance 1 for HUD Testing Name 1");
                //
                Reports.TestStep = "Validate Agent = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Lease 3 for HUD Testing Name 1");
                // 
                Reports.TestStep = "Business Source Add'l Role-Agent Directed By Add'l Role-Agent Associated Business Party Add'l Role-Nil.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Real Estate Agent", DirectedByAddnRole: @"Seller's Real Estate Agent");
                // 
                Reports.TestStep = "Validate Agent = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Flood Insurance 1 for HUD Testing Name 1");
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0012

        [TestMethod]
        public void FMUC0071_REG0012()
        {

            try
            {
                Reports.TestDescription = "BR_FM5353_2: RE Broker and RE Agent as Additional Role.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Business Source Add'l Role-Agent Directed By Add'l Role-Broker Associated Business Party Add'l Role-Nil.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Real Estate Agent", DirectedByAddnRole: @"Seller's Broker");
                                // 
                Reports.TestStep = "Validate Broker = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Lease 3 for HUD Testing Name 1");
                //
                Reports.TestStep = "Validate Agent = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Flood Insurance 1 for HUD Testing Name 1");
                //
                Reports.TestStep = "Business Source Add'l Role-Broker Directed By Add'l Role-Nil Associated Business Party Add'l Role-Broker.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Broker", DirectedByAddnRole: @"Seller's Broker");
                               // 
                Reports.TestStep = "Validate Broker = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Flood Insurance 1 for HUD Testing Name 1");
                //
                Reports.TestStep = "Business Source Add'l Role-Broker Directed By Add'l Role-Nil Associated Business Party Add'l Role-Agent.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Broker", AssociatedBPAddnRole: @"Seller's Real Estate Agent");
                //
                Reports.TestStep = "Validate Broker = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Flood Insurance 1 for HUD Testing Name 1");

                Reports.TestStep = "Validate Agent = Associated Business Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Assumption Lender 1 for HUD Test Name 1");
                 //

                Reports.TestStep = "Business Source Add'l Role-Agent Directed By Add'l Role-Nil Associated Business Party Add'l Role-Agent.";
                CreateQFEWithAdditionalRole( @"Seller's Real Estate Agent", @"Seller's Real Estate Agent",@"Seller's Real Estate Agent");
                //
                Reports.TestStep = "Validate Agent = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Flood Insurance 1 for HUD Testing Name 1");
                //
                Reports.TestStep = "Business Source Add'l Role-Agent Directed By Add'l Role-Nil Associated Business Party Add'l Role-Broker.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Seller's Real Estate Agent", AssociatedBPAddnRole: @"Seller's Broker");
                //
                Reports.TestStep = "Validate Broker = Associated Business Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Assumption Lender 1 for HUD Test Name 1");

                Reports.TestStep = "Validate Agent = Business Source Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Flood Insurance 1 for HUD Testing Name 1");

                Reports.TestStep = "Business Source Add'l Role-Nil Directed By Add'l Role-Broker Associated Business Party Add'l Role-Broker.";
                CreateQFEWithAdditionalRole(DirectedByAddnRole: @"Seller's Broker", AssociatedBPAddnRole: @"Seller's Broker");
                //
                Reports.TestStep = "Validate Broker = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Lease 3 for HUD Testing Name 1");
//
                Reports.TestStep = "Business Source Add'l Role-Nil Directed By Add'l Role-Broker Associated Business Party Add'l Role-Agent.";
                CreateQFEWithAdditionalRole(DirectedByAddnRole: @"Seller's Broker", AssociatedBPAddnRole: @"Seller's Real Estate Agent");
               
                Reports.TestStep = "Validate Broker = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Lease 3 for HUD Testing Name 1");
                
                Reports.TestStep = "Validate Agent = Associated Business Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Assumption Lender 1 for HUD Test Name 1");

                Reports.TestStep = "Business Source Add'l Role-Nil Directed By Add'l Role-Agent Associated Business Party Add'l Role-Agent.";
                CreateQFEWithAdditionalRole(DirectedByAddnRole: @"Seller's Real Estate Agent", AssociatedBPAddnRole: @"Seller's Real Estate Agent");

                Reports.TestStep = "Validate Agent = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Lease 3 for HUD Testing Name 1");
                //

                Reports.TestStep = "Business Source Add'l Role-Nil Directed By Add'l Role-Agent Associated Business Party Add'l Role-Broker.";
                CreateQFEWithAdditionalRole(DirectedByAddnRole: @"Seller's Real Estate Agent", AssociatedBPAddnRole: @"Seller's Broker");

                Reports.TestStep = "Validate Agent = Directed By in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "AGENT", "Assumption Lender 1 for HUD Test Name 1");             

                Reports.TestStep = "Validate Broker = Associated Business Party in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.CheckPresenceOfRealEstateAgentOrBroker("SELLER", "BROKER", "Lease 3 for HUD Testing Name 1");


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion Test
        #region Test FMUC0071_REG0013

        [TestMethod]
        public void FMUC0071_REG0013()
        {

            try
            {
                Reports.TestDescription = "BR_FM5354: Outside Title Company and Title Agent as Additional Role.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
               Reports.TestStep = "Business Source Add'l Role-OTC Directed By Add'l Role-OTC Associated Business Party Add'l Role-TA.";
               CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Outside Title Company", DirectedByAddnRole: @"Outside Title Company", AssociatedBPAddnRole: @"Title Agent");

                Reports.TestStep = "Verify instances of Outside Title Company with Business Source from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);

                Reports.TestStep = "Verify instances of Outside Title Company with Associated Business Party from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Assumption Lender 1 for HUD Test Name 1", "#2", TableAction.Click);

                Reports.TestStep = "Business Source Add'l Role-OTC Directed By Add'l Role-TA Associated Business Party Add'l Role-TA.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Outside Title Company", DirectedByAddnRole: @"Title Agent", AssociatedBPAddnRole: @"Title Agent");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Business Source from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Directed By from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Lease 3 for HUD Testing Name 1", "#2", TableAction.Click);

                Reports.TestStep = "Business Source Add'l Role-TA Directed By Add'l Role-TA Associated Business Party Add'l Role-OTC.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Title Agent", DirectedByAddnRole: @"Title Agent", AssociatedBPAddnRole: @"Outside Title Company");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Business Source from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Associated Business Party from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Assumption Lender 1 for HUD Test Name 1", "#2", TableAction.Click);
                //
                //
                Reports.TestStep = "Business Source Add'l Role-TA Directed By Add'l Role-OTC Associated Business Party Add'l Role-OTC.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Title Agent", DirectedByAddnRole: @"Outside Title Company", AssociatedBPAddnRole: @"Outside Title Company");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Business Source from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Directed By from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Lease 3 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                //
                Reports.TestStep = "Business Source Add'l Role-TA Directed By Add'l Role-OTC Associated Business Party Add'l Role-TA.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Title Agent", DirectedByAddnRole: @"Outside Title Company", AssociatedBPAddnRole: @"Title Agent");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Business Source from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Directed By from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Lease 3 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                //
                Reports.TestStep = "Business Source Add'l Role-OTC Directed By Add'l Role-OTC Associated Business Party Add'l Role-Nil.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Outside Title Company", DirectedByAddnRole: @"Outside Title Company");
                FastDriver.OutsideTitleCompanyDetail.Open();
                Support.AreEqualTrim("HUDFLINSR1", FastDriver.OutsideTitleCompanyDetail.IDCode.FAGetText());
                
                //
                Reports.TestStep = "Business Source Add'l Role-OTC Directed By Add'l Role-TA Associated Business Party Add'l Role-Nil.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Outside Title Company", DirectedByAddnRole: @"Title Agent");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Business Source from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Directed By from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Lease 3 for HUD Testing Name 1", "#2", TableAction.Click);
                //

                Reports.TestStep = "Business Source Add'l Role-TA Directed By Add'l Role-TA Associated Business Party Add'l Role-Nil.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Title Agent", DirectedByAddnRole: @"Title Agent");
                
                Reports.TestStep = "Validate OTC Additional role from QFE.";
                FastDriver.OutsideTitleCompanyDetail.Open();
                Support.AreEqualTrim("HUDFLINSR1", FastDriver.OutsideTitleCompanyDetail.IDCode.FAGetText());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0014

        [TestMethod]
        public void FMUC0071_REG0014()
        {

            try
            {
                Reports.TestDescription = "BR_FM5354_1: Outside Title Company and Title Agent as Additional Role.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = @"QFE-1-Business Source Add'l Role-TA Directed By Add'l Role-OTC Associated Business Party Add'l Role-Nil.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Title Agent", DirectedByAddnRole: @"Outside Title Company");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Business Source from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Directed By from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Lease 3 for HUD Testing Name 1", "#2", TableAction.Click);

                Reports.TestStep = @"QFE-2-Business Source Add'l Role-OTC Directed By Add'l Role-Nil Associated Business Party Add'l Role-OTC.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Outside Title Company",AssociatedBPAddnRole: @"Outside Title Company");
                //
                //
                Reports.TestStep = "Validate OTC Additional role from QFE-2.";
                FastDriver.OTCDetail.Open();
                Support.AreEqualTrim("HUDFLINSR1", FastDriver.OTCDetail.GABcodeLabel.FAGetText());
                //
                Reports.TestStep = "Business Source Add'l Role-OTC Directed By Add'l Role-Nil Associated Business Party Add'l Role-TA.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Outside Title Company", AssociatedBPAddnRole: @"Title Agent");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Business Source from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Associated Business Party from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Assumption Lender 1 for HUD Test Name 1", "#2", TableAction.Click);

                Reports.TestStep = "Business Source Add'l Role-TA Directed By Add'l Role-Nil Associated Business Party Add'l Role-TA.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Title Agent", AssociatedBPAddnRole: @"Title Agent");
               
                Reports.TestStep = "Validate OTC Additional role from QFE-2.";
                FastDriver.OTCDetail.Open();
                Support.AreEqualTrim("HUDFLINSR1", FastDriver.OTCDetail.GABcodeLabel.FAGetText());
                
                Reports.TestStep = "Business Source Add'l Role-TA Directed By Add'l Role-Nil Associated Business Party Add'l Role-OTC.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Title Agent", AssociatedBPAddnRole: @"Outside Title Company");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Business Source from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Associated Business Party from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Assumption Lender 1 for HUD Test Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Business Source Add'l Role-Nil Directed By Add'l Role-OTC Associated Business Party Add'l Role-OTC.";
                CreateQFEWithAdditionalRole(DirectedByAddnRole: @"Outside Title Company", AssociatedBPAddnRole: @"Outside Title Company");
                
                Reports.TestStep = "Validate OTC Additional role from QFE-3.";
                FastDriver.OTCDetail.Open();
                Support.AreEqualTrim("HUDLEASE03", FastDriver.OTCDetail.GABcodeLabel.FAGetText());
                
                Reports.TestStep = "Business Source Add'l Role-Nil Directed By Add'l Role-OTC Associated Business Party Add'l Role-TA.";
                CreateQFEWithAdditionalRole(DirectedByAddnRole: @"Outside Title Company", AssociatedBPAddnRole: @"Title Agent");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Associated Business Party from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Assumption Lender 1 for HUD Test Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Directed By from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Lease 3 for HUD Testing Name 1", "#2", TableAction.Click);

                Reports.TestStep = "Business Source Add'l Role-Nil Directed By Add'l Role-TA Associated Business Party Add'l Role-TA.";
                CreateQFEWithAdditionalRole(DirectedByAddnRole: @"Title Agent", AssociatedBPAddnRole: @"Title Agent");
                
                Reports.TestStep = "Validate OTC Additional role from QFE-3.";
                FastDriver.OTCDetail.Open();
                Support.AreEqualTrim("HUDLEASE03", FastDriver.OTCDetail.GABcodeLabel.FAGetText());
               
                Reports.TestStep = "Business Source Add'l Role-Nil Directed By Add'l Role-TA Associated Business Party Add'l Role-OTC.";
                CreateQFEWithAdditionalRole(DirectedByAddnRole: @"Title Agent", AssociatedBPAddnRole: @"Outside Title Company");
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Associated Business Party from QFE.";
                FastDriver.OutsideTitleSummary.Open();
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Assumption Lender 1 for HUD Test Name 1", "#2", TableAction.Click);
                //
                Reports.TestStep = "Verify instances of Outside Title Company with Directed By from QFE.";
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(@"#2", "Lease 3 for HUD Testing Name 1", "#2", TableAction.Click);
                //

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0015

        [TestMethod]
        public void FMUC0071_REG0015()
        {

            try
            {
                Reports.TestDescription = "BR_FM7515: Lender Related Parties as Additional Role.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Lender-Originating Branch as Additional role for both the Business Source and Directed By.";
                CreateQFEWithAdditionalRole(BusinessSourceAddnRole: @"Lender- Originating Branch", DirectedByAddnRole: @"Lender- Originating Branch");                  
                // 
                Reports.TestStep = "Verify the New lender is created from New Lender section in QFE.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.RelatedPartiesTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.RelatedPartiesNew);
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(@"#2", "HUDFLINSR1", "#2", TableAction.Click);
               
                Reports.TestStep = "Lender-Mortgage Centre as Additional role for Directed By and Associated Bus Party.";
                CreateQFEWithAdditionalRole(DirectedByAddnRole: @"Lender- Originating Branch");
                // 
                Reports.TestStep = "Validate the Related parties additional role from QFE-2.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.RelatedPartiesTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.RelatedPartiesNew);
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(@"#2", "HUDLEASE03", "#2", TableAction.Click);
                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_REG0016

        [TestMethod]
        public void FMUC0071_REG0016()
        {

            try
            {
                Reports.TestDescription = "BR_FM5349: Multiple Contacts for QFE/QRE Business Parties.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
                if (!FastDriver.QuickFileEntry.BusinessSourceEditName.IsSelected())
                {
                    FastDriver.QuickFileEntry.BusinessSourceEditName.FASetCheckbox(true);
                }

                FastDriver.QuickFileEntry.BusinessSourceNameEdit.FASetText(@"Adhoc Contact");
                SetDirectedByGABDetails("HUDLEASE03",AdditionalRole: @"Seller's Real Estate Agent");
                FastDriver.QuickFileEntry.DirectedBYAttention.FASelectItem(@"Contact, Lease 3 for HUD");
                SetServiceType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                //
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                AddInstructions();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNewLenderDetails();
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1", @"1234567896");
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Reports.TestStep = "Validate the Adhoc Contact in FHP.";
                Support.AreEqual(@"Adhoc Contact", FastDriver.FileHomepage.BusinessPartyEditName.FAGetValue());
                Support.AreEqual(@"Contact, Lease 3 for HUD", FastDriver.FileHomepage.DirectedBycomboAttention.FAGetSelectedItem());
               
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0017

        [TestMethod]
        public void FMUC0071_REG0017()
        {

            try
            {

                Reports.TestDescription = "BR_FM6063: Select Sub Escrow File Service.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(false,true,true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                //
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                AddInstructions();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNewLenderDetails();
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1", @"1234567896");
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(7000);
                Reports.TestStep = "Validate the Service Type in FHP.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"False", FastDriver.FileHomepage.Title.IsSelected().ToString());
                Support.AreEqual(@"True", FastDriver.FileHomepage.Escrow.IsSelected().ToString());
                Support.AreEqual(@"True", FastDriver.FileHomepage.SubEscrow.IsSelected().ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_REG0018
        /// <summary>
        /// US350016  Hide HUD-1 Statement and GFE Entry on the NAV Tree for Form Type = CD
        /// US350016  Hide HUD-1 Statement and GFE Entry on the NAV Tree for Form Type = CD
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0018()
        {

            try
            {
                Reports.TestDescription = "BR_FM6064_ER15: Require Title or Escrow with Sub Escrow.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(false,false, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                //
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNewLenderDetails();
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1", @"1234567896");
                SetNotes();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create order with Sub escrow service type.";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Please select either Title or Escrow service with Sub Escrow.", Message);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                //
                Reports.TestStep = "Select the Escrow Checkbox.";
                if (!FastDriver.QuickFileEntry.Escrow.IsSelected())
                    FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                //
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Reports.TestStep = "Validate the Service Type in FHP.";
                Support.AreEqual(@"False", FastDriver.FileHomepage.Title.IsSelected().ToString());
                Support.AreEqual(@"True", FastDriver.FileHomepage.Escrow.IsSelected().ToString());
                Support.AreEqual(@"True", FastDriver.FileHomepage.SubEscrow.IsSelected().ToString());

                if (AutoConfig.FormType.Equals("HUD"))
                {
                    Reports.TestStep = "Validate HUD1 statement link for HUD file";
                      Support.AreEqual("True",FastDriver.LeftNavigation.CheckIfLinkIsPresent(@"Home>Order Entry>Escrow Closing>HUD-1 Statement").ToString());
                      Support.AreEqual("False", FastDriver.LeftNavigation.CheckIfLinkIsPresent(@"Home>Order Entry>Escrow Closing>Closing Disclosure").ToString());

                }
                else
                {
                    Reports.TestStep = "Validate Closing Disclosure link for CD file";
                    Support.AreEqual("False", FastDriver.LeftNavigation.CheckIfLinkIsPresent(@"Home>Order Entry>Escrow Closing>HUD-1 Statement").ToString());
                    Support.AreEqual("True", FastDriver.LeftNavigation.CheckIfLinkIsPresent(@"Home>Order Entry>Escrow Closing>Closing Disclosure").ToString());
                }

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0019

        [TestMethod]
        public void FMUC0071_REG0019()
        {

            try
            {
                Reports.TestDescription = "BR_FM5360: Enter Manual File Number.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();

                Reports.TestStep = "Enter file number";
                FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(false);
                FastDriver.QuickFileEntry.FileNumPrefix.FASetText(@"HAF");
                Random r = new Random();
                FastDriver.QuickFileEntry.FileNum.FASetText(r.Next(134567893, 999999999).ToString());
                FastDriver.QuickFileEntry.FileNumSufix.FASetText(@"HAF");
                string FileNum = FastDriver.QuickFileEntry.FileNum.FAGetValue();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();

                for (int i = 0; i < 5; i++)
                {
                    Reports.TestStep = "Attempt "+i+ " to enter unique file number";
                    if (!FastDriver.WebDriver.HandleDialogMessage().Contains("No dialog present"))
                    {
                        FastDriver.QuickFileEntry.WaitForScreenToLoad();
                        if (FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText().Contains("Service File: File Number already exists or reserved"))
                            FastDriver.QuickFileEntry.FileNum.FASetText(r.Next(134567893, 999999999).ToString());
                        FastDriver.BottomFrame.Done();
                        Thread.Sleep(5000);
                    }
                    else
                        break;
                }

                Reports.TestStep = "Validate the Filenum.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"HAF", FastDriver.FileHomepage.FileNumPrefix.FAGetValue().ToString());
                Support.AreEqual(FileNum, FastDriver.FileHomepage.FileNum.FAGetValue().ToString());
                Support.AreEqual(@"HAF", FastDriver.FileHomepage.FileNumSufix.FAGetValue().ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0020
        /// <summary>
        /// FM5361  Auto Numbering Indicator  
        ///   If the user leaves the Auto Number checkbox checked (this is the default value), 
        ///   the system shall automatically generate a file number, optionally including a prefix and/or a suffix. 
        ///   The system shall not display the system-generated file number on the QFE/QRE page.
        ///
        ///   FM5362  File Service Type Determines Auto-generated File Number Prefix and Suffix  
        ///    - If a file is opened with Title Service Type only, the system shall assign the file number prefix and suffix 
        ///       defined for the file's Title Owning Office in Office Setup.
        ///    - If a file is opened with Escrow Service Type only or both Title and Escrow Service Types, 
        ///       the system shall assign the file number prefix and suffix defined for the file's Escrow Owning Office in Office Setup.
        ///    - If the file is originally opened with Title Service Type only and later the user adds Escrow Service Type, 
        ///      then the prefix and suffix shall remain as they were assigned when the user saved the QFE/QRE.
        ///
        ///   FM5369  Select Master File  
        ///   The system shall provide the ability to indicate whether a file is a "Master" file.
        ///
        ///
        ///   US401953 Form Type selection on Quick File Entry (QFE) and Quick Refi Entry
        ///   The system shall allow the user to change the file’s Form Type default of CD (Closing Disclosure) to HUD.
        ///
        ///   FM5370  Default File Underwriter  
        ///   The File Underwriter will be defaulted based on Title Owning office
        ///   User will be able to modify the file underwriter by selecting from a list of active underwriters for the office. 
        ///   The user will not have the option to remove file underwriter (to blank it out).

        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0020()
        {

            try
            {
                Reports.TestDescription = "BR_FM5362_FM5361_FM5369_FM5370: File Service Type Determines Auto generated File Number Prefix and Suffix.";
                Reports.TestStep = "Login to ADM to Get File prefix and sufix from office set up";
                ADMLOGIN();

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                FastDriver.OfficeSummary.Open();
                string  OfficeName1= FastDriver.OfficeSummary.EditOffice("2379"); //JVR office
                FastDriver.OfficeSetupOffice.SetFileNumberSchemaPrefixAndSuffix("HGFD", "ZXCV");
                string[] FNSchemaPS1=FastDriver.OfficeSetupOffice.GetFileNumberSchemaPrefixAndSuffix();
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage();
                //
                FastDriver.OfficeSummary.Open();
                string OfficeName2=FastDriver.OfficeSummary.EditOffice("1487"); //Qa Automation office
                string[] FNSchemaPS2 = FastDriver.OfficeSetupOffice.GetFileNumberSchemaPrefixAndSuffix();
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage();
                //
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                if (!FastDriver.QuickFileEntry.UseAsMasterFile.IsSelected())
                    FastDriver.QuickFileEntry.UseAsMasterFile.FASetCheckbox(true);
                //
                Support.AreEqual("True", FastDriver.QuickFileEntry.AutoNumber.IsSelected().ToString());
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.FileNumPrefix.IsVisible().ToString());
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.FileNum.IsVisible().ToString());
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.FileNumSufix.IsVisible().ToString());
                //
                Support.AreEqual(@"First American Title Insurance Company", FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FAGetSelectedItem());
                FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FASelectItemByIndex(0);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Validate Error message when underwriter is not selected.";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqualTrim("Underwriter is required", Message);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                Reports.TestStep = "Validate the Filenum Prefix and suffix.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.FileNumPrefix.ScrollIntoView();
                Thread.Sleep(2000);
                Support.AreEqual(FNSchemaPS2[0], FastDriver.FileHomepage.FileNumPrefix.FAGetValue());
                Support.AreEqual(FNSchemaPS2[1], FastDriver.FileHomepage.FileNumSufix.FAGetValue());

                Reports.TestStep = "Create an order to verify file number for escrow only file.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(false, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                string[] AllOffices = FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');
                foreach (string Office in AllOffices)
                    if (Office.Contains(OfficeName1))
                    {
                        FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem(Office);
                        Thread.Sleep(5000);
                        FastDriver.QuickFileEntry.WaitForScreenToLoad();
                        break;
                    }
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                //
                Reports.TestStep = "Validate the Filenum Prefix and suffix.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(FNSchemaPS1[0], FastDriver.FileHomepage.FileNumPrefix.FAGetValue());
                Support.AreEqual(FNSchemaPS1[1], FastDriver.FileHomepage.FileNumSufix.FAGetValue());
                //
                Reports.TestStep = "Create an order to verify file number for Title only file.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, false);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                AllOffices=FastDriver.QuickFileEntry.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');
                foreach(string Office in AllOffices)
                if (Office.Contains(OfficeName2))
                {
                    FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem(Office);
                    Thread.Sleep(5000);
                    FastDriver.QuickFileEntry.WaitForScreenToLoad();
                }
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                //
                Reports.TestStep = "Validate the Filenum Prefix and suffix.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(FNSchemaPS2[0], FastDriver.FileHomepage.FileNumPrefix.FAGetValue());
                Support.AreEqual(FNSchemaPS2[1], FastDriver.FileHomepage.FileNumSufix.FAGetValue());
                //
                Reports.TestStep = "Create an order to verify file number for Title and escrow file.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                AllOffices = FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');
                foreach (string Office in AllOffices)
                    if (Office.Contains(OfficeName1))
                    {
                        FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem(Office);
                        Thread.Sleep(5000);
                        FastDriver.QuickFileEntry.WaitForScreenToLoad();
                    }
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                //
                Reports.TestStep = "Validate the Filenum Prefix and suffix.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(FNSchemaPS1[0], FastDriver.FileHomepage.FileNumPrefix.FAGetValue());
                Support.AreEqual(FNSchemaPS1[1], FastDriver.FileHomepage.FileNumSufix.FAGetValue());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_REG0021
        /// <summary>
        /// FM5439: Default Owning Office
        /// FM5373  Default Production Offices  
        ///The system shall populate a default Escrow Production office that is defined for the file's Escrow Owning Office in Office Setup.
        ///Similarly for Title prod office

        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0021()
        {
            try
            {
                Reports.TestDescription = "BR_FM5439 : Default Owning Office. FM5373 Default Production Offices ";
                ADMLOGIN();
                Reports.TestStep = "Get default prod offices from office set up";
                Dictionary<string,string> TitleProdOffices = GetTitleProdOfficesFromOfficeSetUp("1487");
                Dictionary<string, string> EscrowProdOffices = GetEscrowProdOfficesFromOfficeSetUp("1487");
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                Reports.TestStep = "Default escrow owning office"; 
                string EscrowOwningOffice = FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetSelectedItem();
                Support.AreEqual("True", EscrowOwningOffice.Contains(AutoConfig.SelectedOfficeName).ToString());
                //
                Reports.TestStep = "Default Title owning office"; 
                string TitleOwningOffice = FastDriver.QuickFileEntry.TitleOwningOffice.FAGetSelectedItem();
                Support.AreEqual("True", TitleOwningOffice.Contains(AutoConfig.SelectedOfficeName).ToString());
                //
                Reports.TestStep = "Default Title prod office";
                Support.AreEqual("True", FastDriver.QuickFileEntry.TitleProdOfficeTable.FAGetText().Contains(TitleProdOffices["SeqNo1"]).ToString());
                Reports.TestStep = "Default Escrow prod office";
                Support.AreEqual("True", FastDriver.QuickFileEntry.EscrowProdOfficeTable.FAGetText().Contains(EscrowProdOffices["SeqNo1"]).ToString());
                //
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_REG0022
        [TestMethod]
        public void FMUC0071_REG0022()
        {
            try
            {
                Reports.TestDescription = "BR_FM5385_FM5386: Add/Remove production offices at file level.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                string EscrowOwningOffice = FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetSelectedItem();
                Support.AreEqual("True", EscrowOwningOffice.Contains(AutoConfig.SelectedOfficeName).ToString());
                Reports.TestStep = "Click on Add Remove Production offices(Title).";
                FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
                //
                Reports.TestStep = "Select office.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                string EscrowProdOfc = FastDriver.OfficeSelectionDlg.SelectOffice();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Verify the EscrowProductionOffice added.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual("True",FastDriver.QuickFileEntry.EscrowProdOfficeTable.FAGetText().Contains(EscrowProdOfc).ToString());
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                //
                Reports.TestStep = "Remove the Escrow Prod office and validate.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.AddRemoveEscrowProdOffice.FAClick();
                Reports.TestStep = "Unselect office.";
               FastDriver.OfficeSelectionDlg.DeselectOffice(EscrowProdOfc);
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Verify the EscrowProductionOffice removed.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.FileHomepage.EscrowProdOfficeTable.FAGetText().Contains(EscrowProdOfc).ToString());
                Reports.TestStep = "Save the changes.";
                FastDriver.BottomFrame.Save();
                Thread.Sleep(2000);

                Reports.TestStep = "Remove the Title Prod office and validate.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.AddRemoveTitleProdOffice.FAClick();
                
                Reports.TestStep = "Unselect office.";
                string TitleProdOfc = FastDriver.OfficeSelectionDlg.DeselectOffice();

                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Verify the TitleProductionOffice is removed.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.FileHomepage.TitleProdOfficeTable.FAGetText().Contains(TitleProdOfc).ToString());


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0023
        /// <summary>
        /// FM5388  Initial Product Display  
        /// FM5374  Select Products  
        /// FM5389  Display only selected products after adding/removing products  
        /// FM5376  Select One or More Products  
        /// FM5394  Add/Remove Products  
        /// FM5395  Corporate Product List  
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0023()
        {
            try
            {
                Reports.TestDescription = "BR_FM5374_FM5388_FM5389_FM5376_FM5394_FM5394: Select Products.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                
                FastDriver.QuickFileEntry.ProductTable.ScrollIntoView();
                Thread.Sleep(2000);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2",@"*ALTA Homeowners (Eagle Owner) Policy","#2",TableAction.Click);
                
                // 
                Reports.TestStep = "Verify the default products in QFE-2.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", @"*ALTA Standard Owner Policy", "#2", TableAction.Click);
                // 
                Reports.TestStep = "Verify the default products in QFE-3.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", @"*ALTA Extended Owner Policy", "#2", TableAction.Click);
                // 
                Reports.TestStep = "Verify the default products in QFE-4.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", @"*ALTA Residential Plain Language Owners Policy", "#2", TableAction.Click);
                // 
                Reports.TestStep = "Verify the default products in QFE-5.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", @"*ALTA Expanded (Eagle Loan) Policy", "#2", TableAction.Click);               
                // 
                Reports.TestStep = "Verify the default products in QFE-6.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", @"*ALTA Standard Loan Policy", "#2", TableAction.Click);                   
                // 
                Reports.TestStep = "Verify the default products in QFE-7.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", @"*ALTA Extended Loan Policy", "#2", TableAction.Click);               
                // 
                Reports.TestStep = "Verify the default products in QFE-8.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", @"*ALTA Short Form Residential Loan Policy", "#2", TableAction.Click); 
                // 
                Reports.TestStep = "Clear selection.";
                for (int i = 2; i <= FastDriver.QuickFileEntry.ProductTable.GetRowCount(); i++)
                {
                    FastDriver.QuickFileEntry.ProductTable.PerformTableAction(i, 1, TableAction.Off);
                }

                Reports.TestStep = "Click on Add Remove Products.";
                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                //
                Reports.TestStep = "Select Product Abstract.";
                FastDriver.ProductListDlg.WaitScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(@"#2", "Abstract", "#1", TableAction.On); 
                                // 
                Reports.TestStep = "Select Product Agency File Scanning.";
                               FastDriver.ProductListDlg.Table.PerformTableAction(@"#2", "Agency File Scanning", "#1", TableAction.On); 
                FastDriver.DialogBottomFrame.ClickDone();
                // 
                Reports.TestStep = "Validate the product Abstract is added.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", "Abstract", "#2", TableAction.Click); 
               
                // 
                Reports.TestStep = "Validate the product Agency File Scanning is added.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", "Agency File Scanning", "#2", TableAction.Click); 
                
                // 
                Reports.TestStep = "Verify that only selected products are displayed.";
                Support.AreEqual("2",(FastDriver.QuickFileEntry.ProductTable.GetRowCount()-1).ToString()); //subtract 1 to exclude column names row
                Support.AreEqualTrim("Abstract",FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2,2,TableAction.GetText).Message);
                Support.AreEqualTrim("Agency File Scanning", FastDriver.QuickFileEntry.ProductTable.PerformTableAction(3, 2, TableAction.GetText).Message); 
            //
                Reports.TestStep = "Remove Product.";
                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                FastDriver.ProductListDlg.WaitScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(@"#2", "Agency File Scanning", "#1", TableAction.Off);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                //
                Reports.TestStep = "Verify that only selected products are displayed.";
                Support.AreEqual("2", FastDriver.QuickFileEntry.ProductTable.GetRowCount().ToString());
                Support.AreEqualTrim("False", FastDriver.QuickFileEntry.ProductTable.FAGetText().Contains("Agency File Scanning").ToString());
                //
                Reports.TestStep = "Complete order creation.";
                SetBusinessSourceDetails("HUDFLINSR1");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0024

        [TestMethod]
        public void FMUC0071_REG0024()
        {

            try
            {
                Reports.TestDescription = "BR_FM5377_FM5396_FM5397_FM5398_FM5378_FM5379_FM13853: Property.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with business segment residential.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");

                string BusinessSegment=FastDriver.QuickFileEntry.PropertyInformationType.FAGetText();

                //Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteManufactured HomeMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(7000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                // 
                Reports.TestStep = "Validate the property type contains all values.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Thread.Sleep(7000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

               string PropertyType=  FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
               //Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                
                
                Reports.TestStep = "Create an order with business segment Commercial.";
               OpenQFEPage();
               SetBusinessSourceDetails("HUDFLINSR1");
               SetDirectedByGABDetails("HUDLEASE03");
               SetServiceType(true, true);
               SetFormType();
               FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
               SetBlankProgramType();
               FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");

               PropertyType = FastDriver.QuickFileEntry.PropertyInformationType.FAGetText();

               Support.AreEqualTrim(@"Multi Family ResidenceCondominiumAgricultural LandApartment BuildingChurch/Religious FacilityCommercial StructureCommunication SiteConvenience Store/MarketConvention FacilityCo-opEducational FacilityEnergy FacilityEntertainment/TheatreGolf CourseGovernment FacilityHealth Care FacilityHotel/MotelIndustrialOfficePersonal PropertyPetroleum/Oil CompanyPlanned Unit DevelopmentRestaurant/Fast FoodRetailSelf StorageSports Facility/StadiumTimber LandTownhouseTransportation FacilityVacant LandOther", PropertyType.Trim());
               SetPropertyAddressInQFE();
               SetNotes();
               FastDriver.BottomFrame.Done();
               Thread.Sleep(3000);
               // 
               Reports.TestStep = "Validate the property type contains all values.";
               FastDriver.PropertiesSummary.Open();
               FastDriver.PropertiesSummary.Edit.FAClick();
               Thread.Sleep(7000);
               FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

               PropertyType = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
                
                //Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                // 
                
                Reports.TestStep = "Create an order with business segment New Home.";
               OpenQFEPage();
               SetBusinessSourceDetails("HUDFLINSR1");
               SetDirectedByGABDetails("HUDLEASE03");
               SetServiceType(true, true);
               SetFormType();
               FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
               SetBlankProgramType();
               FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("New Home");

               PropertyType = FastDriver.QuickFileEntry.PropertyInformationType.FAGetText();
                //Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteManufactured HomeMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                SetPropertyAddressInQFE();
               SetNotes();
               FastDriver.BottomFrame.Done();
               Thread.Sleep(3000);
                // 
               // 
               Reports.TestStep = "Validate the property type contains all values.";
               FastDriver.PropertiesSummary.Open();
               FastDriver.PropertiesSummary.Edit.FAClick();
               Thread.Sleep(5000);
               FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

               PropertyType = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
               //Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                // 
                
                Reports.TestStep = "Create an order with business segment Subdivision.";
               OpenQFEPage();
               SetBusinessSourceDetails("HUDFLINSR1");
               SetDirectedByGABDetails("HUDLEASE03");
               SetServiceType(true, true);
               SetFormType();
               FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
               SetBlankProgramType();
               FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Subdivision");

               PropertyType = FastDriver.QuickFileEntry.PropertyInformationType.FAGetText();
                //Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteManufactured HomeMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                SetPropertyAddressInQFE();
               SetNotes();
               FastDriver.BottomFrame.Done();
               Thread.Sleep(3000);
                // 
                Reports.TestStep = "Validate the property type contains all values.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Thread.Sleep(5000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                PropertyType = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
                //Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                // 
                Reports.TestStep = "Create an order with business segment Timeshare.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Time Share");

                PropertyType = FastDriver.QuickFileEntry.PropertyInformationType.FAGetText();
                //Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteManufactured HomeMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                // 
                Reports.TestStep = "Validate the property type contains all values.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Thread.Sleep(5000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                PropertyType = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
                //Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                // 
                // 
                Reports.TestStep = "Create an order with business segment Default residential.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Default-Residential");
                PropertyType = FastDriver.QuickFileEntry.PropertyInformationType.FAGetText();
                //Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                Support.AreEqualTrim(@"Single Family ResidenceMulti Family ResidenceCondominiumCo-opFarm w/HomesiteManufactured HomeMobile HomePersonal PropertyPlanned Unit DevelopmentTownhouseVacant LandOther", BusinessSegment.Trim());
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                                Thread.Sleep(5000);
                // 
                Reports.TestStep = "Validate the property type contains all values.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Thread.Sleep(5000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                PropertyType = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
                //Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                // 
                Reports.TestStep = "Create an order with business segment Default-Commercial";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Default-Commercial");

                PropertyType = FastDriver.QuickFileEntry.PropertyInformationType.FAGetText();
                //no Manufactured Home because no Mobil Home
                Support.AreEqualTrim(@"Multi Family ResidenceCondominiumAgricultural LandApartment BuildingChurch/Religious FacilityCommunication SiteConvenience Store/MarketConvention FacilityCo-opEducational FacilityEnergy FacilityEntertainment/TheatreGolf CourseGovernment FacilityHealth Care FacilityHotel/MotelIndustrialOfficePersonal PropertyPetroleum/Oil CompanyPlanned Unit DevelopmentRestaurant/Fast FoodRetailSelf StorageSports Facility/StadiumTimber LandTransportation FacilityVacant LandOther", PropertyType.Trim());
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                                Thread.Sleep(5000);
                // 
                // 
                Reports.TestStep = "Validate the property type contains all values.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Thread.Sleep(5000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                PropertyType = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
                //Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                Support.AreEqualTrim(@"Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other", PropertyType.Trim());
                // 
                            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0025

        [TestMethod]
        public void FMUC0071_REG0025()
        {

            try
            {
                Reports.TestDescription = "BR_FM5364_001: ADM Set up for Sales Rep.";
                                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Dictionary<string, string> BusinessSourceContactName = new Dictionary<string, string>();
                BusinessSourceContactName = CreateNewContactForBusOrg("HUDFLINSR1");
                string[] BusinessSourceSalesRep = ChangeSalesRepDetailsForGABContact("HUDFLINSR1", BusinessSourceContactName["LastName"]);
                //
                Dictionary<string, string> DirectedByContactName = new Dictionary<string, string>();
                DirectedByContactName = CreateNewContactForBusOrg("HUDLEASE03");
                string[] DirectedBySalesRep = ChangeSalesRepDetailsForGABContact("HUDLEASE03", DirectedByContactName["LastName"]);
                //
                Dictionary<string, string> NewLenderInformationContactName = new Dictionary<string, string>();
                NewLenderInformationContactName = CreateNewContactForBusOrg("247");
                string[] NewLenderInformationSalesRep = ChangeSalesRepDetailsForGABContact("247", NewLenderInformationContactName["LastName"]);
                //
                Dictionary<string, string> AssociatedBusinessPartyContactName = new Dictionary<string, string>();
                AssociatedBusinessPartyContactName = CreateNewContactForBusOrg("HUDASLNDR1");
                string[] AssociatedBusinessPartySalesRep = ChangeSalesRepDetailsForGABContact("HUDASLNDR1", AssociatedBusinessPartyContactName["LastName"]);

                Reports.TestStep = "BR_ES13441A: Display Broker Details and sales rep-Broker.";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                Reports.TestStep = "Set Business source and verify Sales rep.";
                SetBusinessSourceDetails("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                Reports.TestStep = @"To validate the Business source's sales rep.";
                FastDriver.QuickFileEntry.BusinessSourceAttention.FASelectItemBySendingKeys(BusinessSourceContactName["LastName"] + ", " + BusinessSourceContactName["FirstName"]);
                //
                Thread.Sleep(2000);
                string[] Act_BusinessSourceSalesRep =new[] { FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem(),FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedItem()};
                Support.AreEqualTrim(Act_BusinessSourceSalesRep[0].Replace(", ", " "), BusinessSourceSalesRep[0]);
                Support.AreEqualTrim(Act_BusinessSourceSalesRep[1].Replace(", ", " "), BusinessSourceSalesRep[1]);
                //
                Reports.TestStep = "Set DirectedBy and verify Sales rep.";
                SetDirectedByGABDetails("HUDLEASE03");
                string[] Act_DirectedBySalesRep= new[] { FastDriver.QuickFileEntry.DirectedBYSalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.DirectedBYSalesRep2.FAGetSelectedItem() };
                FastDriver.QuickFileEntry.DirectedBYAttention.FASelectItem(DirectedByContactName["LastName"] + ", " + DirectedByContactName["FirstName"]);
                Thread.Sleep(4000);
                Support.AreEqualTrim(Act_DirectedBySalesRep[0].Replace(", ", " "), DirectedBySalesRep[0]);
                Support.AreEqualTrim(Act_DirectedBySalesRep[1].Replace(", ", " "), DirectedBySalesRep[1]);
                //
                Reports.TestStep = "Set NewLender and verify Sales rep.";
                SetNewLenderDetails("247");

                FastDriver.QuickFileEntry.NewLenderInformationAttention.FASelectItem(NewLenderInformationContactName["LastName"] + ", " + NewLenderInformationContactName["FirstName"]);
                string[] Act_NewLenderInformationSalesRep = new[] { FastDriver.QuickFileEntry.NewLenderInformationSalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.NewLenderInformationSalesRep2.FAGetSelectedItem() };
                                Support.AreEqualTrim(Act_NewLenderInformationSalesRep[0].Replace(", ", " "), NewLenderInformationSalesRep[0]);
                                Support.AreEqualTrim(Act_NewLenderInformationSalesRep[1].Replace(", ", " "), NewLenderInformationSalesRep[1]);
              //
                Reports.TestStep = "Set AssociatedBusinessParty and verify Sales rep.";
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyAttention.FASelectItem(AssociatedBusinessPartyContactName["LastName"] + ", " + AssociatedBusinessPartyContactName["FirstName"]);
                string[] Act_AssociatedBusinessPartySalesRep = new[] { FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep2.FAGetSelectedItem() };
                Support.AreEqualTrim(Act_AssociatedBusinessPartySalesRep[0].Replace(", ", " "), AssociatedBusinessPartySalesRep[0]);
                Support.AreEqualTrim(Act_AssociatedBusinessPartySalesRep[1].Replace(", ", " "), AssociatedBusinessPartySalesRep[1]);
                //
                SetServiceType(true, true);
                SetFormType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the sales rep for Business parties on file homepage";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string[] Act_FHP_BusinessSourceSalesRep = new[] { FastDriver.FileHomepage.BusinessPartySalesRep1.FAGetSelectedItem(), FastDriver.FileHomepage.BusinessPartySalesRep2.FAGetSelectedItem() };
                Support.AreEqualTrim(Act_FHP_BusinessSourceSalesRep[0].Replace(", "," "), BusinessSourceSalesRep[0]);
                Support.AreEqualTrim(Act_FHP_BusinessSourceSalesRep[1].Replace(", "," "), BusinessSourceSalesRep[1]);
                
                Reports.TestStep = "Validate the sales rep for Directed By on file homepage";
                string[] Act_FHP_DirectedBySalesRep = new[] { FastDriver.FileHomepage.DirectedBySalesRep1.FAGetSelectedItem(), FastDriver.FileHomepage.DirectedBySalesRep2.FAGetSelectedItem() };
                Support.AreEqualTrim(Act_FHP_DirectedBySalesRep[0].Replace(", ", " "), DirectedBySalesRep[0]);
                Support.AreEqualTrim(Act_FHP_DirectedBySalesRep[1].Replace(", ", " "), DirectedBySalesRep[1]);

                //
                Reports.TestStep = "Validate the sales rep for Lender on file homepage";
                string[] Act_FHP_BusinessPartyLenderSalesRep = new[] { FastDriver.FileHomepage.BusinessPartyLenderSalesRep1.FAGetSelectedItem(), FastDriver.FileHomepage.BusinessPartyLenderSalesRep2.FAGetSelectedItem() };

                Support.AreEqualTrim(Act_FHP_BusinessPartyLenderSalesRep[0].Replace(", ", " "), NewLenderInformationSalesRep[0]);
                Support.AreEqualTrim(Act_FHP_BusinessPartyLenderSalesRep[1].Replace(", ", " "), NewLenderInformationSalesRep[1]);

                Reports.TestStep = "Validate the sales rep for Associated Business party on file homepage";
                string[] Act_FHP_AssociateBusinessPartySalesRep = new[] { FastDriver.FileHomepage.AssociateBusinessPartySalesRep1.FAGetSelectedItem(), FastDriver.FileHomepage.AssociateBusinessPartySalesRep2.FAGetSelectedItem() };

                Support.AreEqualTrim(Act_FHP_AssociateBusinessPartySalesRep[0].Replace(", ", " "), NewLenderInformationSalesRep[0]);
                Support.AreEqualTrim(Act_FHP_AssociateBusinessPartySalesRep[1].Replace(", ", " "), NewLenderInformationSalesRep[1]);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }




        #endregion Test
        #region Test FMUC0071_REG0026

        [TestMethod]
        public void FMUC0071_REG0026()
        {
                Reports.TestDescription = "BR_FM5364_FM5424_FM5365_FM5366_FM5367_FM5368_FM5417: Sales Rep Display Format.";
                Reports.StatusUpdate("This flow is covered in REG0025",true);

                
        }
        #endregion Test
        #region Test FMUC0071_REG0027
        /// <summary>
        /// FM5418  Populate Primary Contact's Sales Reps  
        ///   If the business party has a primary business contact in the global address book, the system shall populate the file sales rep fields with the primary contact's 
        ///   Sales Reps when the business party is first selected.
        ///
        ///   The default hierarchy for defaulting the Sales Reps:
        ///   1. Business Source Contact's Sales Reps  (if one or both are available, else use)
        ///   2. Business Source's Sales Reps  (if one or both are available, else)
        ///   FM5419  Populate Another Contact's Sales Reps  
        ///      When the user selects a business party contact, other than the primary business party contact in the Attention field, 
        ///      the system shall populate the sales reps associated with the selected contact in the Sales Rep fields.
        ///      Note:  The system shall populate the Sales Reps associated with the selected contact even if the value 
        ///      of a Sales Rep associated with a File Business Party has been previously modified at the file level.
        ///
        /// FM5421  Display Business Organization's Sales Rep  
        ///If the business party has no primary business contact, the system shall populate the sales reps associated with the Business Organization 
        ///in the Sales Reps field when the business party is first selected.

        ///FM5422  Display Business Organization's Blank Sales Rep  
        ///If the business party has no primary business contact and the business organization has no associated sales reps in the global address book, 
        ///the system shall display a blank value in the Sales Rep fields.
        ///FM5425  Select Blank Sales Rep  
        ///      The user may select a blank entry in the Sales Rep fields.
        ///      FM5426  Sales Rep when Attention is blank  
        ///      When the user selects a blank value in the Attention field, the system shall populate the Bus Org's Sales Reps in the Sales Rep fields.



        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0027()
        {
            try
            {
                Reports.TestDescription = "BR_FM5418_FM5419_FM5421_FM5422_FM5425_FM5426: Populate Primary Contact's Sales Rep.";
                // 
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "FM5418 Set primary contact for Business source and get its Sales rep.";
                string[] BusinessSourceSalesRep=GetSalesRepOfPrimaryContactForGAB("HUDFLINSR1", "Contact");
                Reports.TestStep = "Set primary contact for Directed By and get its Sales rep.";
                string[] DirectedBySalesRepPrimary = GetSalesRepOfPrimaryContactForGAB("HUDLEASE03", "Contact");
                Reports.TestStep = "FM5419 Create new contact for Bus org and get its Sales rep.";
                String Contact = CreateNewContactForBusOrg("HUDLEASE03")["LastName"];
                string[] DirectedBySalesRepOther = GetSalesRepOfPrimaryContactForGAB("HUDLEASE03", Contact);
                //
                Reports.TestStep = "FM5421 Set primary contact as blank for Lender.";
                SetPrimaryContactForGAB("247","");
                Reports.TestStep = "FM5421_FM5426 Get sales rep for lender bus org.";
                string[] NewLenderInformationSalesRep = GetSalesRepDetailsForGAB("247");
                Reports.TestStep = "Set primary contact as blank for Associated Business party";
                SetPrimaryContactForGAB("HUDASLNDR1","");
                Reports.TestStep = "FM5422 Set blank sales rep for Associated business party";
                SetBlankSalesRepForGAB("HUDASLNDR1");                
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Open QFE page";
                OpenQFEPage();
                Reports.TestStep = "Set Business source and verify Sales rep.";
                SetBusinessSourceDetails("HUDFLINSR1");
                #region FM5418
                Reports.TestStep = @"To validate the Business source's sales rep.";
                if (!FastDriver.QuickFileEntry.BusinessSourceAttention.FAGetSelectedItem().Equals("Contact, Flood Insurance 1", StringComparison.CurrentCultureIgnoreCase))
                    FastDriver.QuickFileEntry.BusinessSourceAttention.FASelectItemBySendingKeys("contact");
                //
                Thread.Sleep(2000);
                string[] Act_BusinessSourceSalesRep = new[] { FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedItem() };
                Support.AreEqualTrim(Act_BusinessSourceSalesRep[0].Replace(", ", " "), BusinessSourceSalesRep[0]);
                Support.AreEqualTrim(Act_BusinessSourceSalesRep[1].Replace(", ", " "), BusinessSourceSalesRep[1]);
                #endregion
                #region FM5419
                Reports.TestStep = "Set DirectedBy and verify Sales rep.";
                SetDirectedByGABDetails("HUDLEASE03");
                string[] Act_DirectedBySalesRep = new[] { FastDriver.QuickFileEntry.DirectedBYSalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.DirectedBYSalesRep2.FAGetSelectedItem() };
                Support.AreEqualTrim(Act_DirectedBySalesRep[0].Replace(", ", " "), DirectedBySalesRepPrimary[0]);
                Support.AreEqualTrim(Act_DirectedBySalesRep[1].Replace(", ", " "), DirectedBySalesRepPrimary[1]);             
                #endregion
                #region FM5421_FM5426
                Reports.TestStep = "Set NewLender and verify Sales rep.";
                SetNewLenderDetails("247");
                string[] Act_NewLenderInformationSalesRep = new[] { FastDriver.QuickFileEntry.NewLenderInformationSalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.NewLenderInformationSalesRep2.FAGetSelectedItem() };
                Support.AreEqualTrim(Act_NewLenderInformationSalesRep[0].Replace(", ", " "), NewLenderInformationSalesRep[0]);
                Support.AreEqualTrim(Act_NewLenderInformationSalesRep[1].Replace(", ", " "), NewLenderInformationSalesRep[1]);                    
                #endregion
                #region FM5422_FM5425
                Reports.TestStep = "Set AssociatedBusinessParty and verify Sales rep.";
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1");
                string[] Act_AssociatedBusinessPartySalesRep = new[] { FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep2.FAGetSelectedItem() };
                //
                Support.AreEqualTrim(Act_AssociatedBusinessPartySalesRep[0],"");
                Support.AreEqualTrim(Act_AssociatedBusinessPartySalesRep[1],"");
                //
                Reports.TestStep = "Set sales rep";
                FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep1.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep2.FASelectItemByIndex(1);
                //
                if(!string.IsNullOrEmpty(FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep1.FAGetSelectedItem()))
                {
                    FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep1.FASelectItemByIndex(0);
                }
                //
                if (!string.IsNullOrEmpty(FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep2.FAGetSelectedItem()))
                {
                    FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep2.FASelectItemByIndex(0);
                }
                Reports.TestStep = "FM5425 Validate blank sales rep";
                Support.AreEqualTrim(FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep1.FAGetSelectedItem(), "");
                Support.AreEqualTrim(FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep2.FAGetSelectedItem(), "");
                             
                #endregion
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetServiceType(true, true);
                SetFormType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }


        #endregion Test
        #region Test FMUC0071_REG0028
        /// <summary>
        /// FM5427  Default Bus Org's Sales Rep for Adhoc Attention  
///When the user adds an adhoc Attention by selecting the 'Edit' checkbox and entering a name in the Name field, 
   ///     the system shall populate the Bus Org's Sales Reps in the Sales Rep fields.

        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0028()
        {

            try
            {
                Reports.TestDescription = "BR_FM5427: Default Bus Org's Sales Rep for Adhoc Attention.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Get sales rep for Business source bus org.";
                string[] BusinessSourceSalesRep = GetSalesRepDetailsForGAB("HUDFLINSR1");
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Open QFE page";
                OpenQFEPage();
                Reports.TestStep = "Set Business source and verify Sales rep.";
                SetBusinessSourceDetails("HUDFLINSR1");

                Reports.TestStep = "Default Bus Org's Sales Rep for Adhoc Attention.";
                
                if(!FastDriver.QuickFileEntry.BusinessSourceEditName.IsSelected())
                   FastDriver.QuickFileEntry.BusinessSourceEditName.FAClick();

                FastDriver.QuickFileEntry.BusinessSourceNameEdit.FASetText(@"Adhoc Contact"+FAKeys.Tab);
                //
                string[] Act_BusinessSourceSalesRep = new[] { FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedItem() };
                Support.AreEqualTrim(Act_BusinessSourceSalesRep[0].Replace(", ", " "), BusinessSourceSalesRep[0]);
                Support.AreEqualTrim(Act_BusinessSourceSalesRep[1].Replace(", ", " "), BusinessSourceSalesRep[1]);
                //
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");    
                SetServiceType(true, true);
                SetFormType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0029
        /// <summary>
        /// FM5420  Display Selected Contact's Sales Rep  
        ///   If the business party has a contact in the Attention field and the business contact has no associated sales reps in the global address book, 
        ///   the system shall display a blank value. 
        ///   The system shall not populate the Business Organization's associated sales reps in the Sales Rep fields when only one of the two sales reps has a blank value. 
        ///   The system shall populate the Business Organization's associated sales reps in the Sales Rep fields when both of the sales reps have a blank value.
        ///
        ///   If the Bus Org has a Contact in the Attention field, the system shall populate the Sales Rep fields according to the following rules:
        ///
        ///   1. If Contact has Sales Rep 1 and Sales Rep 2, system populates Contact's Sales Rep 1 and Sales Rep 2.
        ///
        ///   2. If Contact has Sales Rep 1 and no Sales Rep 2, system populates Contact's Sales Rep 1 and Sales Rep 2 is blank.
        ///
        ///   3. If Contact has Sales Rep 2 and no Sales Rep 1, system populates Contact's Sales Rep 2 and Sales Rep 1 is blank.
        ///
        ///   4. If Contact has no Sales Rep 1 and no Sales Rep 2, system populates Bus Org's Sales Rep values (blank or not).
        ///
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0029()
        {

            try
            {
                Reports.TestDescription = "BR_FM5420: Display Selected Contact's Sales Rep.";
                // 

                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Set blank sales rep (both) for the contact of Business source bus org.";
                string[] BusinessSourceContactSalesRep=ChangeSalesRepDetailsForGABContact("HUDFLINSR1", "Contact", true,true);
                Reports.TestStep = "Get changed sales rep for Business source bus org.";
                string[] BusinessSourceSalesRep = GetChangedSalesRepDetailsForGAB("HUDFLINSR1");
                Reports.TestStep = "Set blank sales rep2 for the contact of Directed by bus org.";
               string[] DirectedBySalesRep= ChangeSalesRepDetailsForGABContact("HUDASLNDR2", "Contact", false, true);
               Reports.TestStep = "Set blank sales rep1 for the contact of AssociatedBusinessPartySalesRep bus org.";
               string[]AssociatedBusinessPartySalesRep= ChangeSalesRepDetailsForGABContact("HUDASLNDR3", "Contact", true, false);
                //
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                Reports.TestStep = "Open QFE page";
                OpenQFEPage();
                Reports.TestStep = "Set Business source and verify blank Sales rep.";
                SetBusinessSourceDetails("HUDFLINSR1");
                Reports.TestStep = "If Contact has no Sales Rep 1 and no Sales Rep 2, system populates Bus Org's Sales Rep values ";
                string[] Act_BusinessSourceSalesRep=new[] {FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem(),FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedItem()};
                Support.AreEqualTrim(Act_BusinessSourceSalesRep[0].Replace(", ", " "), BusinessSourceSalesRep[0]);
                Support.AreEqualTrim(Act_BusinessSourceSalesRep[1].Replace(", ", " "), BusinessSourceSalesRep[1]);
                // 
                Reports.TestStep = "Directed By has Sales Rep 2 and no Sales Rep 1.";
                SetDirectedByGABDetails("HUDASLNDR2");
                
                FastDriver.QuickFileEntry.DirectedBYAttention.FASelectItem(@"Contact, Assumption Lender 2");

                string[] Act_DirectedBySalesRep = new[] { FastDriver.QuickFileEntry.DirectedBYSalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.DirectedBYSalesRep2.FAGetSelectedItem() };

                Reports.TestStep = @"If Contact has Sales Rep 1 and no Sales Rep 2, system populates Contact's Sales Rep 1 and Sales Rep 2 is blank.";
                Support.AreEqualTrim(Act_DirectedBySalesRep[0].Replace(", ", " "), DirectedBySalesRep[0]);
                Support.AreEqualTrim(Act_DirectedBySalesRep[1].Replace(", ", " "), DirectedBySalesRep[1]);
                
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetServiceType(true, true);
                SetFormType();
                SetPropertyAddressInQFE();
                //
                Reports.TestStep = "Associated Business party has  Sales Rep 2 and no Sales Rep 1 .";
                SetAssociatedBusinessPartyDetails("HUDASLNDR3");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyAttention.FASelectItem(@"Contact, Assumption Lender 3");
                string[] Act_AssociatedBusinessPartySalesRep = new[] { FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep1.FAGetSelectedItem(), FastDriver.QuickFileEntry.AssociatedBusinessPartySalesRep2.FAGetSelectedItem() };
                Reports.TestStep = @"If Contact has Sales Rep 2 and no Sales Rep 1, system populates Contact's Sales Rep 2 and Sales Rep 1 is blank.";
                Support.AreEqualTrim(Act_AssociatedBusinessPartySalesRep[0].Replace(", ", " "), AssociatedBusinessPartySalesRep[0]);
                Support.AreEqualTrim(Act_AssociatedBusinessPartySalesRep[1].Replace(", ", " "), AssociatedBusinessPartySalesRep[1]);               
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_REG0030

        [TestMethod]
        public void FMUC0071_REG0030()
        {
            
            try
            {
                Reports.TestDescription = "BR_FM5431_FM4129_FM5124: Associate File to Workflow ID/Launch FAST Search.";
                Reports.TestStep = "Login to ADM";

                #region Fast Search Setting
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();
                #endregion

                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Thread.Sleep(100);
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "Template for FMUC0071_REG30";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Short Sale w/Mortgage";
                ProcParams.State = "CA";
                ProcParams.County = "Orange";
                ProcParams.ProcessEvent = "File created with Open status";
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams);

                //FastDriver.RegionalProcessSummary.Open();
                //if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess("Template for FMUC0071_REG30", "Title Production"))
                //{
                //    Reports.StatusUpdate("Create process Template for FMUC0071_REG30", false);
                //}
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with proper address details.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Short Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                Reports.TestStep = "The system shall launch FASTSearch automatically when the service type is Title and property has either the APN or Address 1, AND County AND State";
                SetPropertyDetailsInQFE();
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"SANTA ANA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"Orange");
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                // 
                Reports.TestStep = "Verifying for the Fast Search Initiated event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Fast Search Initiated]", "Event", TableAction.Click);
                // 
                Reports.TestStep = "Verify the source for Fast Search Intitation";
               string Source= FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Fast Search Initiated]",@"Source", TableAction.GetText).Message;
               Support.AreEqualTrim(Source, @"FAST Search Application");
                // 
                Reports.TestStep = "Verify the Event Log for File created(User)";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"User", AutoConfig.UserName.ToUpper(), "User", TableAction.Click);
                //
                Reports.TestStep = "Verify that File ID, SIte ID, Property ID, Title Escrow ID is present in comments";
                string Comments = FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Fast Search Initiated]", @"Comments", TableAction.GetText).Message;
                Support.AreEqualTrim("True", (Comments.Contains("File ID")&&Comments.Contains("Site ID")&&Comments.Contains("Property ID")&&Comments.Contains("Title Escrow ID")).ToString());

                Reports.TestStep = "To verify the Start Date and Completed Date ";
                string Expected_Start_Completion_Date = DateTime.Now.ToDateString();
                Expected_Start_Completion_Date = Expected_Start_Completion_Date.Replace("-", "/");

                string ActualStartDate = FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Fast Search Initiated]", "#2", TableAction.GetText).Message;
                Support.AreEqual("True", ActualStartDate.Contains(Expected_Start_Completion_Date).ToString());
                //
                Reports.TestStep = "Verify the File Work Flow screen is loaded and the best match process template is displayed.";
                FastDriver.FileWorkflow.Open();
                if (!FastDriver.FileWorkflow.CollapseAll.IsSelected())
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 30);
                Reports.TestStep = "Verify that the best match process template is displayed.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.FileWorkflow.CheckIfProcessIsPulled(ProcDetails["ProcessName"]).ToString());
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0071_REG0031
        /// <summary>
        /// FM5432  Sales Reps for Additional Role Business Parties  
        /// When a File Business Party is assigned an Additional Role, the system shall populate its Sales Reps to the corresponding screen created by the Additional Role 
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0031()
        {
            try
            {
                Reports.TestDescription = "BR_FM5432: Sales Reps for Additional Role Business Parties.";
                //
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Set and Get sales rep for the contact of Business source bus org.";
               string[] BusinessSourceSalesRep= ChangeSalesRepDetailsForGABContact("HUDFLINSR1", "Contact");
                //
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = @"Create Order with Seller's Attorney as Additional Role.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1", AdditionalRole: @"Seller's Attorney");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Validate the sales rep from QFE additional role.";
                FastDriver.AttorneyDetail.Open(false);
                string[] Act_BusinessSourceSalesRep=new[] {FastDriver.AttorneyDetail.SalesRep1.FAGetSelectedItem(),FastDriver.AttorneyDetail.SalesRep2.FAGetSelectedItem()};

                    Support.AreEqualTrim(Act_BusinessSourceSalesRep[0].Replace(", "," "), BusinessSourceSalesRep[0]);
                    Support.AreEqualTrim(Act_BusinessSourceSalesRep[1].Replace(", ", " "), BusinessSourceSalesRep[1]);

                // 
                Support.AreEqualTrim("HUDFLINSR1",FastDriver.AttorneyDetail.GABcodeLabel.FAGetText());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0032

        [TestMethod]
        public void FMUC0071_REG0032()
        {

            try
            {
                Reports.TestDescription = "BR_FM6065: Disable Charge Processes in Sub Escrow Files.";
                // 
                //
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create Order";
                CreateFile(false,true,true);
                // 
                Reports.TestStep = "To verify Proration link doesn't exist.";
                bool Presence = FastDriver.LeftNavigation.CheckIfLinkIsPresent("Home>Order Entry>Escrow Charge Processes>Proration");
                Support.AreEqual("False", Presence.ToString());
                // 
                Reports.TestStep = "To verify Adjustments-Off set link doesn't exist.";
                Presence = FastDriver.LeftNavigation.CheckIfLinkIsPresent("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set");
                Support.AreEqual("False", Presence.ToString());
                //
                Reports.TestStep = "Validate the Proration section is disabled for Subescrow file.";
                FastDriver.UtilityDetail.Open();
                Support.AreEqual("False",FastDriver.UtilityDetail.CreditSeller.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.DayofClosePaidbySeller.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.ProrationAmount.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.FromDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.fromInclusive.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.fromProrateDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.BasedOn.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.Per.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.ToDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.toInclusive.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.UtilityDetail.toProrateDate.IsEnabled().ToString());
                                // 
                Reports.TestStep = "Validate that Proration fields are disabled.";
                FastDriver.HomeownerAssociation.Open();
                Support.AreEqual("False", FastDriver.HomeownerAssociation.CheckDetails.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.CreditSeller.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.DayofClosePaidbySeller.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.ProrationAmount.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.FromDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.fromInclusive.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.fromProrate.IsEnabled().ToString());
                //
                Support.AreEqual("False", FastDriver.HomeownerAssociation.BasedOn.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.Per.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.ToDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.toInclusive.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.toProrateDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.ProrationDescription.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.ProrationDescription.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.ProrationBuyerCharge.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.ProrationBuyerCredit.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.ProrationSellerCharge.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.ProrationSellerCredit.IsEnabled().ToString());
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0033

        [TestMethod]
        public void FMUC0071_REG0033()
        {

            try
            {
                Reports.TestDescription = "BR_FM4368_FM4369_FM5434_FM4377_FM4372_FM4381_FM5433_FM4376: Quick Refi File Entry Screen.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Navigate to QRE.";
                FastDriver.QuickRefiFileEntry.OpenQREPage();
                //
                Reports.TestStep = "Enter data to Create Refi Order.";
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickRefiFileEntry.BusinessSourceFind.FAClick();
                Reports.TestStep = "Validate that Directed by section is automatically collapsed";
                Support.AreEqualTrim("False", FastDriver.QuickRefiFileEntry.DirectedByGabCode.IsDisplayed().ToString());
                FastDriver.QuickRefiFileEntry.DirectedByArrowIcon.FAClick();
                Thread.Sleep(2000);
                FastDriver.QuickRefiFileEntry.DirectedByGabCode.FASetText("HUDLEASE03");
                FastDriver.QuickRefiFileEntry.DirectedByFind.FAClick();
                //
                if (!FastDriver.QuickRefiFileEntry.Title.IsSelected())
                    FastDriver.QuickRefiFileEntry.Title.FAClick();
                if (!FastDriver.QuickRefiFileEntry.Escrow.IsSelected())
                    FastDriver.QuickRefiFileEntry.Escrow.FAClick();
                FastDriver.QuickRefiFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickRefiFileEntry.ProgramType.FASelectItemByIndex(0);

                Reports.TestStep = "Vaidate default transaction type for QRE.";
                Support.AreEqualTrim("Refinance", FastDriver.QuickRefiFileEntry.TransactionType.FAGetSelectedItem().ToString());

                Reports.TestStep = "Validate all other transaction types available for REFI file.";
                string TranType=FastDriver.QuickRefiFileEntry.TransactionType.FAGetText();
                Support.AreEqualTrim(@"Construction Disbursement Construction Finance Mtg Mod w/Endorsement Mtg Mod w/Increased Liability Refinance", TranType);
                //
                Reports.TestStep = "FM4381  Quick Refi - Disable Sale Price";
                Support.AreEqualTrim("False", FastDriver.QuickRefiFileEntry.TermsDatesSalesPrice.IsEnabled().ToString());
                //
                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickRefiFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickRefiFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickRefiFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickRefiFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickRefiFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickRefiFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickRefiFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickRefiFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickRefiFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("ALAMEDA");
                //
                Reports.TestStep = "FM4369  Quick Refi  - Buyers section will be relabeled Borrowers section";
                Support.AreEqualTrim("True", FastDriver.QuickRefiFileEntry.Borrower.IsVisible().ToString());
                //
                FastDriver.QuickRefiFileEntry.Borrower1Type.FASelectItem("Individual");
                FastDriver.QuickRefiFileEntry.Borrower1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickRefiFileEntry.Borrower1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickRefiFileEntry.Borrower1SSN.FASetText("123456789");
                FastDriver.QuickRefiFileEntry.Borrower2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickRefiFileEntry.Borrower2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickRefiFileEntry.Borrower2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickRefiFileEntry.Borrower2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickRefiFileEntry.Borrower2SSN.FASetText("123456789");

                //Seller
                Reports.TestStep = "Validate that Seller section is automatically collapsed";
                Support.AreEqualTrim("False", FastDriver.QuickRefiFileEntry.Seller1Type.IsDisplayed().ToString());
                FastDriver.QuickRefiFileEntry.SellersArrowIcon.FAClick();
                Thread.Sleep(1500);
                FastDriver.QuickRefiFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickRefiFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickRefiFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickRefiFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickRefiFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickRefiFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickRefiFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickRefiFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickRefiFileEntry.Seller2SSN.FASetText("987654321");
                Reports.TestStep = "FM5433  Quick Refi  - New Payoff Lender Information";
                Support.AreEqualTrim("Payoff Lender Information", FastDriver.QuickRefiFileEntry.NewPayOffLender.FAGetText());
                FastDriver.QuickRefiFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickRefiFileEntry.NewLenderInformationFind.FAClick();
                Thread.Sleep(3000);
                FastDriver.QuickRefiFileEntry.NewLenderPayoffAmt.FASetText(@"3,333.00");
                FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickRefiFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickRefiFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickRefiFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
                // 
                Dictionary<string, string> PropertyDetailsQFE = FastDriver.QuickRefiFileEntry.GetPropDetailsOnQFEPage;
                Dictionary<string, string> BuyerDetails = FastDriver.QuickRefiFileEntry.GetBuyerDetailsOnQFEPage;
                Dictionary<string, string> SellerDetails = FastDriver.QuickRefiFileEntry.GetSellerDetailsOnQFEPage;
                FastDriver.BottomFrame.Done();
                Thread.Sleep(6000);
                //
                Reports.TestStep = "Navigate to Buyer summary screen and verify the borrower created via QRE.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "Buyer1Firstname Buyer1Lastname", 1, TableAction.Click);
                //
                Reports.TestStep = "Navigate to Buyer2 summary screen and verify the borrower created via QRE.";
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "Buyer2Firstname Buyer2Lastname /Buyer2SpouseName Buyer2Lastname", 1, TableAction.Click);


                Reports.TestStep = "Validate the data from QRE on file home page.";
                FastDriver.FileHomepage.Open();
                VerifyDataInFileHomePage(PropertyDetailsQFE, BuyerDetails, SellerDetails);
                Support.AreEqual(@"True", FastDriver.FileHomepage.Title.IsSelected().ToString());
                Support.AreEqual(@"True", FastDriver.FileHomepage.Escrow.IsSelected().ToString());
                Support.AreEqual(@"Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem());

                Reports.TestStep = "Validate the Payoffloan and payoff amount";
                FastDriver.PayoffLoanDetails.Open();
                Support.AreEqualTrim(@"$3,333.00", FastDriver.PayoffLoanDetails.CheckAmt.FAGetText().ToString());
                Support.AreEqualTrim(@"$3,333.00", FastDriver.PayoffLoanDetails.Payoffamt.FAGetText().ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0034
        /// <summary>
        /// FM6914  BR is removed
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0034()
        {

            try
            {
                Reports.TestDescription = "BR_FM6913: Assign Default 1099-S Classification Value.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                bool exists=CheckExistenceOf1099SActivityDateForOffice(AutoConfig.SelectedOfficeBUID);
                if (!exists)
                    Reports.StatusUpdate("1099s activity date is not set up in ADM -> Office Setup", false);
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Create Order for 1099S with SP above 250000$.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"290,000.00");
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the 1099-S Classification Value Sale Price is over $250,000.00, ";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");
               
                Support.AreEqualTrim( @"1099-S",FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem());

                Reports.TestStep = "Create Order for 1099S with SP= 250000$ and Business segment not equal to New Home.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1", AdditionalRole: @"Seller's Attorney");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"250,000.00");
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                Reports.TestStep = "Validate the N/A Classification Value.";
                Reports.TestStep = "Validate the 1099-S Classification Value Sale Price is over $250,000.00, ";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");

                Support.AreEqualTrim(@"N/A", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem());

                Reports.TestStep = "Create Order for 1099S with SP= 250000$ and Business segment not equal to New Home.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"250,000.00");
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                Reports.TestStep = "Validate the 1099-S Classification Value Sale Price is over $250,000.00, ";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");
                Support.AreEqualTrim(@"N/A", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem());
                //
                Reports.TestStep = "Create Order for 1099S with SP= 10,000,000,000.00$ and Business segment not equal to New Home.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"10,000,000,000.00");
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                Reports.TestStep = "Validate the 1099-S Classification Value";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");
                Support.AreEqualTrim(@"N/A", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem());
                //
                Reports.TestStep = "Create Order for 1099S with SP= 10,000,100,000.00$ and Business segment not equal to New Home.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"10,000,100,000.00");
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                Reports.TestStep = "Validate the 1099-S Classification Value";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");
                Support.AreEqualTrim(@"N/A", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem());
                //
                Reports.TestStep = "Validate the 1099-S Classification Value";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");
                Support.AreEqualTrim(@"N/A", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem());
                //
                Reports.TestStep = "Create Order for 1099S with SP= 10,000,100,000.00$ and Business segment equal to New Home.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"New Home");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"10,000,100,000.00");
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                Reports.TestStep = "Validate the 1099-S Classification Value";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");
                Support.AreEqualTrim(@"N/A", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem());
                //
                Reports.TestStep = "Create Order for 1099S with SP= 230,000.00$ and Business segment equal to New Home.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"New Home");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"230,000.00");
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                Reports.TestStep = "Validate the 1099-S Classification Value";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");
                Support.AreEqualTrim(@"N/A", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem());
                //
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }


        #endregion Test
        #region Test FMUC0071_REG0035

        [TestMethod]
        public void FMUC0071_REG0035()
        {

            try
            {
                Reports.TestDescription = "BR_FM6915 : Select SSN/TIN Format for Trust/Estate Buyers and Sellers.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Enter SSN for Seller while creating order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"New Home");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"10,000,100,000.00");
                SetPropertyDetailsInQFE();
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem(@"Trust/Estate");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText(@"EstNAME1");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText(@"322-22-2222"+FAKeys.Tab);
                FastDriver.QuickFileEntry.TIN.FASetCheckbox(true);
                // 
                Reports.TestStep = "Change SSN to TIN for Seller.";
                Support.AreEqual(@"32-2222222", FastDriver.QuickFileEntry.Seller1SSN.FAGetValue());
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                Reports.TestStep = "Validate the 1099-S Classification Value";
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Trust/Estate");
                FastDriver.BuyerSellerSetup.Trust_Ssn_ViewEdit();
                Support.AreEqualTrim(@"32-2222222", FastDriver.BuyerSellerSetup.TrustSSNtext.FAGetValue());

                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0036
        /// <summary>
        ///  FM9699  Program Type Override   	
        ///   FM9703  Program Type Override Event Log  
        ///   FM9698  Validation Hierarchy  :  The Program Type selection validation will use the following priority;
        ///   1) State, 2) County and 3) 'First new loan liability amount'.	
        ///   FM9700  State Validation   	
        ///   FM9701  County Validation  	
        ///   FM9702  Liability Validation   
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0036()
        {

            try
            {
                Reports.TestDescription = "BRFM9700_FM9701_FM9702_ER23_FM9699_FM9703_FM9704: Filtering File's Program Type dropdown list.";
                // 
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                FastDriver.ProgramTypeSetup.Open();
                string ProgramTypeName = "Sanity_Map_Program_Type_1";
                Dictionary<string, List<string>> ProgramTypeDetails = new Dictionary<string, List<string>>();
                try
                {
                    ProgramTypeDetails = FastDriver.ProgramTypeSetup.GetDetailsofProgramType(ProgramTypeName);
                }
                catch
                {
                    Random num = new Random();
                    ProgramTypeName = "Automation_Test_" + num.Next();
                    if (!FastDriver.ProgramTypeSetup.GetNewProgramType(ProgramTypeName, "2999.12", SearchTypes: new[] { "68-Two Owner Search" }, Products: new[] { "Abstract" }, States: new[] { "CA" }, County: new[] { "ORANGE" }))
                        Support.Fail("Precondition failed");
                    else
                        ProgramTypeDetails = FastDriver.ProgramTypeSetup.GetDetailsofProgramType(ProgramTypeName);

                }
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                Reports.TestStep = "Enter data in qfe with program type.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
               // SetPropertyAddressInQFE();
                Reports.TestStep = "Set TransactionType, New loan liability, State, county different from program type defaults";
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(ProgramTypeDetails["TransactionTypes"][0]);
                Thread.Sleep(3000);

                Reports.TestStep = "Select a programType.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.SelectProgramType(ProgramTypeName);
                Thread.Sleep(2000);
                Reports.TestStep = "Select product.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.Click);
                //
                FastDriver.QuickFileEntry.PropertyState.FASelectItemByIndex(2);
                if (FastDriver.QuickFileEntry.PropertyState.FAGetSelectedItem().Contains(ProgramTypeDetails["States"][0]))
                {
                    FastDriver.QuickFileEntry.PropertyState.FASelectItemByIndex(5);
                }
                string NewLiabilityAmt = (Convert.ToDouble(ProgramTypeDetails["LiabilityAmount"][0]) + 100).ToString();
                FastDriver.QuickFileEntry.TermsDatesNewLoanLiability.FASetText(NewLiabilityAmt);
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "The Program Type selection validation will use the following priority; 1) State, 2) County and 3) 'First new loan liability amount'.";
                string StateValidationMsg = FastDriver.WebDriver.HandleDialogMessage();
                Reports.TestStep = "The Program Type selection validation - State";
                string Message = "The Program Type that you have selected is not available for this property’s state and/or the county.\r\n\r\nPlease change the Program Type.";
                Support.AreEqualTrim(Message, StateValidationMsg);
                Reports.TestStep = "Correct the - State";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(ProgramTypeDetails["States"][0]);
                Reports.TestStep = "Enter random county ";
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Santa Ana");
                //
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "The Program Type selection validation - County";
                string CountyValidationMsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqualTrim(Message, CountyValidationMsg);

                Reports.TestStep = "Correct the - County";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(ProgramTypeDetails["County"][0]);
                //
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "The Program Type selection validation - New loan liability";
                string LiabilityValidationMsg = FastDriver.WebDriver.HandleDialogMessage();
                Message = "The First New Loan Liability Amount is greater than\r\nthe Program Type threshold amount. Please review\r\nthe Program Type selection.";
                Support.AreEqualTrim(Message, LiabilityValidationMsg);
                //
                Reports.TestStep = "Correct the - New loan liability";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesNewLoanLiability.FASetText(ProgramTypeDetails["LiabilityAmount"][0]);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);

                Reports.TestStep = "Enter data in qfe with program type and validate override.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(ProgramTypeDetails["TransactionTypes"][0]);
                Thread.Sleep(2000);
                Reports.TestStep = "Select a programType.";
                FastDriver.QuickFileEntry.SelectProgramType(ProgramTypeName);
                Reports.TestStep = "Set  New loan liability, State different from program type defaults";

                FastDriver.QuickFileEntry.PropertyState.FASelectItemByIndex(2);
                if (FastDriver.QuickFileEntry.PropertyState.FAGetSelectedItem().Contains(ProgramTypeDetails["States"][0]))
                {
                    FastDriver.QuickFileEntry.PropertyState.FASelectItemByIndex(5);
                }
                FastDriver.QuickFileEntry.TermsDatesNewLoanLiability.FASetText(NewLiabilityAmt);
                
                 Reports.TestStep = "Check the Override Checkbox.";
                if (!FastDriver.QuickFileEntry.ProgramTypeOverride.IsSelected())
                    FastDriver.QuickFileEntry.ProgramTypeOverride.FASetCheckbox(true);
                if (!FastDriver.QuickFileEntry.ProductsSelect.IsSelected())
                    FastDriver.QuickFileEntry.ProductsSelect.FASetCheckbox(true);
                Thread.Sleep(4000);

                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                // 
                Reports.TestStep = "Validate the event for Program type override";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Program Type Override]", "Event", TableAction.Click);                
                // 
                Reports.TestStep = "Validate the source for Program type override";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Source", @"File Homepage", "Source", TableAction.Click);     
                // 
                Reports.TestStep = "Validate the comments for Program type override"; 
                string Comments=FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Program Type Override]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", Comments.Contains("Program Type Override").ToString());
                //
                Reports.TestStep = "Verify the user for Program type override";
                string User=FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Program Type Override]", "User", TableAction.GetText).Message;
                Support.AreEqual("True", User.Contains(AutoConfig.UserName.ToUpper()).ToString());
                Reports.TestStep = "To verify the Start Date and Completed Date is equal to current system date";
                string Expected_Start_Completion_Date = DateTime.Now.ToDateString();
                Expected_Start_Completion_Date = Expected_Start_Completion_Date.Replace("-", "/");
                //
                string ActualStartDate = FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Program Type Override]", "#2", TableAction.GetText).Message;
                Support.AreEqual("True", ActualStartDate.Contains(Expected_Start_Completion_Date).ToString());
                //
                string ActualCompletionDate = FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Program Type Override]", "#3", TableAction.GetText).Message;
                Support.AreEqual("True", ActualCompletionDate.Contains(Expected_Start_Completion_Date).ToString());
                 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0037_PH

        [TestMethod]
        public void FMUC0071_REG0037_PH()
        {

            try
            {
                Reports.TestDescription = "BR_ER23_PlaceHolder: Validate the error warning manually";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0038
        /// <summary>
        /// FM9705  Search Type Allowed without Program Type  	5.0 626 Map Program Type
        ///   The system shall allow the user to select a Search Type without a Program Type.
        ///   FM9706  Instructions  	5.0 626 Map Program Type
        ///   The system shall allow the user to select up to 7 instructions from the regional list of instructions. 
        ///   The system shall allow the user to select them without a Program Type.
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0038()
        {
            try
            {
                Reports.TestDescription = "BR_FM9705_FM9706: Search Type Allowed without Program Type /Instructions.";
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                Reports.TestStep = "Select search type and multiple instructions without program type.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Accommodation");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem(@"No Program Type"); 
                Thread.Sleep(2000);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction("#2", @"*ALTA Homeowners (Eagle Owner) Policy", "#2", TableAction.Click);
                Reports.TestStep = "Select the Instruction Type.";

                FastDriver.QuickFileEntry.SearchType.FASelectItemBySendingKeys(0, lastFirst: true);
                FastDriver.SearchTypeDialogDlg.WaitForScreenToLoad();
                if (!FastDriver.SearchTypeDialogDlg.SelectionRadioButton.IsSelected())
                    FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Add Instructions.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.AddRemoveInstructions.FAClick();
                Thread.Sleep(5000);

                Reports.TestStep = "Click on Clear";
                FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
                FastDriver.SelectInstructionsDlg.Clear.FAClick();
                Thread.Sleep(3000);

                Reports.TestStep = "Select Instruction1.";
                FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
                int RowCount = FastDriver.SelectInstructionsDlg.InstructionsTable.GetRowCount();
                bool MoreThan7Instr = false;
                List<string> AllInstructions = new List<string>();
                for (int i = 1; i <= (RowCount < 8 ? RowCount : 8); i++)
                {
                    if (i == 8)
                    {
                        MoreThan7Instr = true;
                        Reports.TestStep = "FM9706  Validate warning message when more than 7 instructions are selected";
                        FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(i, 1, TableAction.On);
                        AllInstructions.Add(FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(i, 2, TableAction.GetText).Message);
                        FastDriver.DialogBottomFrame.ClickDone();
                        string ActualMessage = FastDriver.WebDriver.HandleDialogMessage(false);
                        string ExpectedMessage = @"The maximum number of instructions has been reached for this file.";
                        Support.AreEqualTrim(ActualMessage, ExpectedMessage);
                        FastDriver.WebDriver.HandleDialogMessage(false, false);
                        FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
                        FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(i, 1, TableAction.Off);


                    }
                    else
                    {
                        FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(i, 1, TableAction.On);
                        AllInstructions.Add(FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(i, 2, TableAction.GetText).Message);
                    }
                }
                Reports.StatusUpdate("To verify FM9706 we need more than 7 instructions in SearchInstructionDlg", MoreThan7Instr);
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Validate the instructions.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                string SearchInstructions = FastDriver.QuickFileEntry.SearchInstructions.FAGetText().ToString();
                int Count = 0;
                foreach (string Insr in AllInstructions)
                {
                    if (SearchInstructions.Contains(Insr))
                        Count++;
                }
                Support.AreEqual((AllInstructions.Count-1).ToString(), Count.ToString());
                //
                SetPropertyAddressInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0039

        [TestMethod]
        public void FMUC0071_REG0039()
        {
            try
            {
                Reports.TestDescription = "BR_FM5355_0001: Default Service Type (Role= Title Assistant).ADM and IIS";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee Type to Title Assistant.";
                FastDriver.EmployeeSetup.SelectRoles(new[]{"Title Assistant"});
                FastDriver.BottomFrame.Done();
                                // 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Validate default service type.";
                Support.AreEqual("True", FastDriver.QuickFileEntry.Title.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.Escrow.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.SubEscrow.IsSelected().ToString());
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0040

        [TestMethod,Obsolete]
        public void FMUC0071_REG0040()
        {

            try
            {
                Reports.TestDescription = "BR_FM5355_0002: Default Service Type=Title.";
                Reports.StatusUpdate("This flow is covered in Reg0039", true);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0041

        [TestMethod]
        public void FMUC0071_REG0041()
        {

            try
            {
                Reports.TestDescription = "FM4842_FM4844_FM4832_FM4833_FM5130_FM4845: Default Service Type (Role= Title Officer).";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee Type to Title Officer.";
                FastDriver.EmployeeSetup.SelectRoles(new[] { "Title Officer" });
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Validate default service type.";
                Support.AreEqual("True", FastDriver.QuickFileEntry.Title.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.Escrow.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.SubEscrow.IsSelected().ToString());
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0042

        [TestMethod,Obsolete]
        public void FMUC0071_REG0042()
        {

                Reports.TestDescription = "BR_FM5355_0004: Default Service Type=Title.";
                Reports.StatusUpdate("This flow is covered in REG0041", true);
                

        }
        #endregion Test
        #region Test FMUC0071_REG0043

        [TestMethod]
        public void FMUC0071_REG0043()
        {

            try
            {
                Reports.TestDescription = "BR_FM5355_0005: Default Service Type (Role= Escrow Officer).";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee Type to Escrow Officer.";
                FastDriver.EmployeeSetup.SelectRoles(new[] { "Escrow Officer" });
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Validate default service type.";
                Support.AreEqual("False", FastDriver.QuickFileEntry.Title.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.QuickFileEntry.Escrow.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.SubEscrow.IsSelected().ToString());
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0044

        [TestMethod,Obsolete]
        public void FMUC0071_REG0044()
        {
            
                Reports.TestDescription = "BR_FM5355_0006: Default Service Type=Escrow.";
                Reports.StatusUpdate("This flow is covered in REG0043", true);
               
        }
        #endregion Test
        #region Test FMUC0071_REG0045

        [TestMethod]
        public void FMUC0071_REG0045()
        {

            try
            {
                Reports.TestDescription = "FM5131: Default Service Type (Role= Escrow Assistant).";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee Type to Escrow Assistant.";
                FastDriver.EmployeeSetup.SelectRoles(new[] { "Escrow Assistant" });
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Validate default service type.";
                Support.AreEqual("False", FastDriver.QuickFileEntry.Title.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.QuickFileEntry.Escrow.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.SubEscrow.IsSelected().ToString());
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0046
        [TestMethod]
        public void FMUC0071_REG0046()
        {

            try
            {
                #region DataDependency
                //GAB - HUDFLINSR1 should have contact with name "Contact, Flood Insurance 1"
                #endregion
                Reports.TestDescription = "FM5417  Maintain Sales Rep  .";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                string[] BusinessSourceSalesRep=ChangeSalesRepDetailsForGABContact("HUDFLINSR1","Contact");
                Reports.TestStep = "BR_ES13441A: Display Broker Details and sales rep-Broker.";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create an order with business segment residential.";
                OpenQFEPage();
                Reports.TestStep = "Set Business source and verify Sales rep.";
                SetBusinessSourceDetails("HUDFLINSR1");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetFormType();
                SetPropertyAddressInQFE();
                Reports.TestStep = @"To validate the Business source's sales rep.";
                if (!FastDriver.QuickFileEntry.BusinessSourceAttention.FAGetSelectedItem().Equals("Contact, Flood Insurance 1",StringComparison.CurrentCultureIgnoreCase))
                    FastDriver.QuickFileEntry.BusinessSourceAttention.FASelectItem("Contact, Flood Insurance 1");
                //
                Thread.Sleep(2000);
                string[] Act_BusinessSourceSalesRep =new[] { FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem(),FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedItem()};

                    Support.AreEqualTrim(Act_BusinessSourceSalesRep[0].Replace(", "," "),BusinessSourceSalesRep[0]);
                    Support.AreEqualTrim(Act_BusinessSourceSalesRep[1].Replace(", ", " "), BusinessSourceSalesRep[1]);
               
                Reports.TestStep = @"Change source's sales rep on QFE.";
                FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FASelectItemByIndex(4);
                FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FASelectItemByIndex(4);
               string NewBusinessSourceSalesRep1= FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem();
               string NewBusinessSourceSalesRep2=  FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedItem();
              FastDriver.BottomFrame.Done();
              Thread.Sleep(5000);
              Reports.TestStep = "Validate the sales rep for Business parties on file homepage";
              FastDriver.FileHomepage.WaitForScreenToLoad();
              string[] Act_FHP_BusinessSourceSalesRep = new[] { FastDriver.FileHomepage.BusinessPartySalesRep1.FAGetSelectedItem(), FastDriver.FileHomepage.BusinessPartySalesRep2.FAGetSelectedItem() };

              Support.AreEqualTrim(Act_FHP_BusinessSourceSalesRep[0], NewBusinessSourceSalesRep1);
              Support.AreEqualTrim(Act_FHP_BusinessSourceSalesRep[1], NewBusinessSourceSalesRep2);

              Reports.TestStep = "Login to ADM and validate sales rep details are not affected there";
              ADMLOGIN();
              FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
              string[] BSSalesRepAfterIISChange = GetSalesRepDetailsForGABContact("HUDFLINSR1", "Contact");
              Support.AreEqualTrim(BSSalesRepAfterIISChange[0], BusinessSourceSalesRep[0]);
              Support.AreEqualTrim(BSSalesRepAfterIISChange[1], BusinessSourceSalesRep[1]);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0047

        [TestMethod]
        public void FMUC0071_REG0047()
        {

            try
            {
                Reports.TestDescription = "BR_FM5355_0008: Default Service Type=Escrow.";
                // 
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee Type to Escrow Assistant.";
                FastDriver.EmployeeSetup.SelectRoles(new[] { "Escrow Assistant" });
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Validate default service type (None).";
                Support.AreEqual("False", FastDriver.QuickFileEntry.Title.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.QuickFileEntry.Escrow.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.SubEscrow.IsSelected().ToString());
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetServiceType();
                SetPropertyAddressInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0048

        [TestMethod]
        public void FMUC0071_REG0048()
        {

            try
            {
                Reports.TestDescription = "BR_FM5355_0009: Default Service Type (Role= Sales Rep).";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee Type to Sales Rep.";
                FastDriver.EmployeeSetup.SelectRoles(new[] { "Sales Rep" });
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Validate default service type (None).";
                Support.AreEqual("False", FastDriver.QuickFileEntry.Title.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.Escrow.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.SubEscrow.IsSelected().ToString());
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetServiceType();
                SetPropertyAddressInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0049

        [TestMethod]
        public void FMUC0071_REG0049()
        {

            try
            {
                Reports.TestDescription = "BR_FM5355_0010: Default Service Type=None.";
                Reports.StatusUpdate("This flow is covered in REG0048", true);
               
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0050

        [TestMethod]
        public void FMUC0071_REG0050()
        {

            try
            {
                Reports.TestDescription = "BR_FM5355_0011: Default Service Type (Role= Other).";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee Type to Sales Rep.";
                FastDriver.EmployeeSetup.SelectRoles(new[] { "Other" });
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Validate default service type (None).";
                Support.AreEqual("False", FastDriver.QuickFileEntry.Title.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.Escrow.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.QuickFileEntry.SubEscrow.IsSelected().ToString());
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0051

        [TestMethod]
        public void FMUC0071_REG0051()
        {
                Reports.TestDescription = "BR_FM5355_0012: Default Service Type=None.";
                Reports.StatusUpdate("This flow is covered in REG0050", true);
               
        }
        #endregion Test
        #region Test FMUC0071_REG0052
        /// <summary>
        /// FM5357  Default Business Segment  
         ///   Before the user selects a Service Type on the QFE/QRE screen, the system shall display the Business Segment field with a blank value.
         ///
         ///   If the user selects Title Service Type only, the system shall populate Business Segment with the default Business Segment value 
         ///   defined for the file's Title Owning Office in Office Setup.
         ///
         ///   If the user selects both Title and Escrow Service Types, or Escrow Service Type only, the system shall populate 
         ///   Business Segment with the default Business Segment value defined for the file's Escrow Owning Office in Office Setup.
         ///
         ///   FM5358  Change Business Segment  
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0052()
        {

            try
            {
                Reports.TestDescription = "BR_FM5357_001: Default Business Segment (get value from ADM) run again and validate at IIS.";
                // 
                Reports.TestStep = "Log into ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee role to blank (or other). Prereq for blank business segment";
                FastDriver.EmployeeSetup.DeselectAllRoles();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                Reports.TestStep = "Get default the Business Segment value from Office Set up.";
                string BusinessSegment1 = GetDefaultBusinessSegment(AutoConfig.SelectedOfficeBUID);//Qa AUtomation Office
                string BusinessSegment2 = GetChangedBusinessSegment("2379","Commercial");// check id for JVR office

                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Validate that business segment is blank when no service type is selected.";
                Support.AreEqual("",FastDriver.QuickFileEntry.BusinessSegment.FAGetSelectedItem().Trim());
                // 
                Reports.TestStep = "Validate Business Segment when Title is selected.";
                SetServiceType(true, false,false);
                Support.AreEqualTrim(BusinessSegment1, FastDriver.QuickFileEntry.BusinessSegment.FAGetSelectedItem());
                //
                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true);
                //
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter data to create order and Validate Business Segment when Escrow is selected.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Ensure escrow service type is selected.";
                SetServiceType(false, true,false);
                //
                Reports.TestStep = "Chnage escrow owning office.";
                string[] AllOffices = FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');
                foreach (string Office in AllOffices)
                {
                    if (Office.Contains("JVR Office"))
                    {
                        FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem(Office);
                        Thread.Sleep(5000);
                        FastDriver.QuickFileEntry.WaitForScreenToLoad();
                        break;
                    }
                }

                if (!FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetSelectedItem().Contains("JVR"))
                    Reports.StatusUpdate("Required office is not selected", false);
                Reports.TestStep = "Validate that business segment when escrow service type is selected.";
                Support.AreEqual(BusinessSegment2, FastDriver.QuickFileEntry.BusinessSegment.FAGetSelectedItem().Trim());
                // 
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion Test
        #region Test FMUC0071_REG0053

        [TestMethod]
        public void FMUC0071_REG0053()
        {
            Reports.TestDescription = "BR_FM5357_002: Default Business Segment (verify value in IIS) run again.";
            Reports.StatusUpdate("This flow is covered in REG0052", true);

        }
        #endregion Test
        #region Test FMUC0071_REG0054

        [TestMethod]
        public void FMUC0071_REG0054()
        {
            try
            {
                Reports.TestDescription = "BR_FM5355_0013: Set role back to Escrow and title Officer.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee role to Escrow Officer and Title Officer.";
                FastDriver.EmployeeSetup.SelectRoles(new[] { "Title Officer","Escrow Officer" });
                FastDriver.BottomFrame.Done();
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0055
        /// <summary>
        /// FM5371  Assign Employees by Role (ADM and IIS) 
        /// FM5408  Select Blank Service Officer  
        /// FM5409  Select Blank in Attention Field  
        /// FM5411  Select Same Employee for Service Officer 
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0055()
        {

            try
            {
                Reports.TestDescription = "BR_FM5371_001_FM5408_FM5409_FM5411_FM5375_FM5390_FM5402_FM5393 Assign Employees by Role (Set up in ADM and validate at IIS).";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Create New employee in QA Automation Office.";
                FastDriver.EmployeeSetup.Open();
                FastDriver.EmployeeSearch.New.FAClick();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                Dictionary<string, string> NewEmployeeData = FastDriver.EmployeeSetup.CreateNewEmployee(new[] { "Title Officer", "Escrow Officer" });
                string officer =NewEmployeeData["FirstName"]+" "+ NewEmployeeData["LastName"];
                Reports.TestStep = "Change Title and escrow officer names for gab and get new names.";
                Dictionary<string, string> TitleEscrowOfficersGAB1 = GetChangedTitleEscrowOfficerForGAB("HUDWDINSR1",TitleEscrowOfficer: officer);
                Dictionary<string,string> TitleEscrowOfficersGABContact1= GetChangedTitleEscrowOfficerForGABContact("HUDWDINSR1", "Contact",TitleEscrowOfficer: officer);
                Dictionary<string, string> TitleEscrowOfficersGAB2 = GetChangedTitleEscrowOfficerForGAB("HUDFLINSR1", TitleEscrowOfficer: officer);
                Dictionary<string, string> TitleEscrowOfficersGABContact2 = GetChangedTitleEscrowOfficerForGABContact("HUDFLINSR1", "Contact",TitleEscrowOfficer: officer);
                //
                Reports.TestStep = "Login to IIS";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                Reports.TestStep = "Create order and validate the Title/Escrow Officer/Assistant is populated based on Bus Org.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDWDINSR1");
                Reports.TestStep = "Ensure Title and escrow service type is selected.";
                SetServiceType(true, true, false);
                Reports.TestStep = "Validate Title and escrow officer for GAB.";
                string TitleEscrowOfficer=TitleEscrowOfficersGAB1["TitleOfficer"].Split(' ')[1]+", "+TitleEscrowOfficersGAB1["TitleOfficer"].Split(' ')[0];
                Support.AreEqual(TitleEscrowOfficer, FastDriver.QuickFileEntry.TitleOwningOfficeOfficer.FAGetSelectedItem().Trim());
                Support.AreEqual(TitleEscrowOfficer, FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FAGetSelectedItem().Trim());
                //        
                string TitleEscrowOfficerForContact = TitleEscrowOfficersGABContact1["TitleOfficer"].Split(' ')[1] + ", " + TitleEscrowOfficersGABContact1["TitleOfficer"].Split(' ')[0];
                Reports.TestStep = "Select Attention and validate the Title/Escrow Officer/Assistant r is populated based on Bus Org attention.";
                FastDriver.QuickFileEntry.BusinessSourceAttention.FASelectItem(@"Contact, Wind Insurance 1");
                Support.AreEqual(TitleEscrowOfficerForContact, FastDriver.QuickFileEntry.TitleOwningOfficeOfficer.FAGetSelectedItem().Trim());
                Support.AreEqual(TitleEscrowOfficerForContact, FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FAGetSelectedItem().Trim());
                //
                Reports.TestStep = "Change bus org and validate the Title/Escrow Officer/Assistant is populated based on Owning office.";
                SetBusinessSourceDetails(@"HUDWDINSR1");
                Support.AreEqual(TitleEscrowOfficer, FastDriver.QuickFileEntry.TitleOwningOfficeOfficer.FAGetSelectedItem().Trim());
                Support.AreEqual(TitleEscrowOfficer, FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FAGetSelectedItem().Trim());
                //
                Reports.TestStep = "Change owning office and validate the Title/Escrow Officer/Assistant is blank by default.";
                string[] AllOffices = FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');
                foreach (string Office in AllOffices)
                {
                    if (Office.Contains("JVR Office"))
                    {
                        FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem(Office);
                        Thread.Sleep(5000);
                        FastDriver.QuickFileEntry.WaitForScreenToLoad();
                        break;
                    }
                }
                Support.AreEqual("", FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FAGetSelectedItem().Trim());
                Support.AreEqual("", FastDriver.QuickFileEntry.EscrowOwningOfficeAssistant.FAGetSelectedItem().Trim());

                 AllOffices = FastDriver.QuickFileEntry.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');
                foreach (string Office in AllOffices)
                {
                    if (Office.Contains("JVR Office"))
                    {
                        FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem(Office);
                        Thread.Sleep(5000);
                        FastDriver.QuickFileEntry.WaitForScreenToLoad();
                        break;
                    }
                }
                Support.AreEqual("", FastDriver.QuickFileEntry.TitleOwningOfficeOfficer.FAGetSelectedItem().Trim());
                Support.AreEqual("", FastDriver.QuickFileEntry.TitleOwningOfficeAssistant.FAGetSelectedItem().Trim());

                Reports.TestStep = "Overwrite values for Title/Escrow Officer/Assistant and FM5411  Select Same Employee for Service Officer.";
                FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.EscrowOwningOfficeAssistant.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.TitleOwningOfficeOfficer.FASelectItemByIndex(2);
                FastDriver.QuickFileEntry.TitleOwningOfficeAssistant.FASelectItemByIndex(2);
                //
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0056

        [TestMethod]
        public void FMUC0071_REG0056()
        {

            try
            {
                Reports.TestDescription = "BR_FM5371_002_FM5382_FM5383_FM5400_FM5404_FM5403_FM5405_FM5406_FM5407: Assign Employees by Role (Verify in IIS).";
                Reports.StatusUpdate("This flow is covered in REG0055", true);


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0058_PH

        [TestMethod]
        public void FMUC0071_REG0058_PH()
        {
            try
            {
                Reports.TestDescription = "BR_FM6775_FM6776_FM6777_US352778 PlaceHolder: Valiadate manually";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0059
        /// <summary>
        /// FM7068  Select Default Production Offices from Other Regions  
        /// FM5387  Add Multiple Production Offices  
        /// FM7521  Add/Remove production offices at file level   
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0059()
        {

            try
            {
                Reports.TestDescription = "BR_FM7068_FM5387_FM7521: Select Default Production Offices from Other Regions.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                bool Result=  EligibleForInterRegionalProdOffice("2162","QACAN");
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create Order";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
                Reports.TestStep = "Select escrow prod office and validate on QFE.";

               bool status= AddFirstProdOfficeFromDialog(@"QA-Canada");
               Support.AreEqual("True", status.ToString());
               Reports.TestStep = "Add multiple offices";
               FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();

               status = AddProdOfficeFromDialog("QA Automation Region - DO NOT TOUCH","JVR Office");
               Support.AreEqual("True", status.ToString());
               Reports.TestStep = "Remove escrow prod office";
               FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
               Support.AreEqual("True", RemoveEscrowProdOffice(AutoConfig.SelectedRegionName, "JVR Office").ToString());
                Reports.TestStep = "Complete the order for adding Production offices.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"5000" + FAKeys.Tab);
                SetPropertyDetailsInQFE();
                SetBuyerSellerDetails();
                SetNewLenderDetails(@"247");
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1");
                SetNotes();
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }


        #endregion Test
        #region Test FMUC0071_REG0060
        /// <summary>
        /// FM5423  Default Blank Sales Rep for Ad Hoc Entry  
        /// FM5410  Default Service Officer for Ad Hoc Entry  
        /// 
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0060()
        {

            try
            {
                Reports.TestDescription = "BR_FM5423_FM5410: Default Blank Sales Rep for Ad Hoc Entry.";
                ADMLOGIN();
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee role to Escrow Officer and Title Officer.";
                bool Success = FastDriver.EmployeeSetup.SelectRoles(new[] { "Title Officer", "Escrow Officer" });
                FastDriver.BottomFrame.Done();
                if (!Success)
                    Support.Fail("Required roles are not selected in ADM. Precondition failed");

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Enter data to Create Order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"", WaitCreation: false);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.NewGabRequest();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate the sales rep  for adhoc bus org.";
                Support.AreEqual("", FastDriver.QuickFileEntry.BusinessSourceSalesRep1.FAGetSelectedItem().Trim());
                Support.AreEqual("", FastDriver.QuickFileEntry.BusinessSourceSalesRep2.FAGetSelectedItem().Trim());
                //
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Accommodation");
                SetBlankProgramType();
                //
                string ActualTitleEscrowOfficer = AutoConfig.UserName.Split('\\')[1];
               string ExpectedEscrowOfficer =FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FAGetSelectedItem();
               ExpectedEscrowOfficer = ExpectedEscrowOfficer.Split(',')[1].Trim() + ExpectedEscrowOfficer.Split(',')[0].Trim();
               string ExpectedTitleOfficer = FastDriver.QuickFileEntry.TitleOwningOfficeOfficer.FAGetSelectedItem();
               ExpectedTitleOfficer = ExpectedTitleOfficer.Split(',')[1].Trim() + ExpectedTitleOfficer.Split(',')[0].Trim();
                //
               Reports.TestStep = "Validate title/Escrow officer for adhoc bus org.";
               Support.AreEqual(ExpectedEscrowOfficer, ActualTitleEscrowOfficer,true);
               Support.AreEqual(ExpectedTitleOfficer, ActualTitleEscrowOfficer,true);
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0061

        [TestMethod]
        public void FMUC0071_REG0061()
        {

            try
            {
                Reports.TestDescription = "FM5429_FM8752  : Buyer as an Additional Role(ADM).";
                Reports.StatusUpdate("This flow is already covered in BAT0003", true);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0062

        [TestMethod]
        public void FMUC0071_REG0062()
        {
                   Reports.TestDescription = "FM8751_FM8752: Buyer as an Additional Role(File).";
                                Reports.StatusUpdate("This flow is already covered in BAT0003", true);

        }
        #endregion Test
        #region Test FMUC0071_REG0063
        /// <summary>
        /// FM8752B -Create Link to Wire Instruction
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0063()
        {
            try
            {
                Reports.TestDescription = "FM8752: Copy GAB Information (Coverd in BAT0003) and Create Link to Wire Instruction.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");

                Reports.TestStep = "Click Version button to enable editing of key fields";
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(5000);

                Reports.TestStep = "Set up Email/ Buyer Seller Type for HUDFLINSR1.";
                FastDriver.BusPartyOrgSetUp.BuyerSellerType.FASelectItem(@"Business Entity");
                string BuyerSellerType = FastDriver.BusPartyOrgSetUp.BuyerSellerType.FAGetSelectedItem().Replace(" ", "");
                Thread.Sleep(1000);
                //
                Dictionary<string, string> WireInstructions = new Dictionary<string, string>();
                WireInstructions = FastDriver.BusPartyOrgSetUp.GetChangedWireInstructions();
                //
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Create Order with Buyer as Additional Role.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1", AdditionalRole: @"Buyer");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@"1000" + FAKeys.Tab);
                SetNotes();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Navigate to Buyer summary screen and click on Edit.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", BuyerSellerType, "Type", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate wire details on edit disbursement.";
               bool Result= ValidateWireInstructionsOnEditDisbursement(WireInstructions,@"1,000.00");
               Support.AreEqualTrim("True", Result.ToString());
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }


        #endregion Test
        #region Test FMUC0071_REG0064
        /// <summary>
        /// FM9690  Program Type Components  Covered in BAT0008
        /// FM9691  Program Type Hierarchy  Covered in BAT0008
        /// FM9692  Filtering File's Program Type dropdown list  Covered in BAT0007 and 8
        /// FM9689_FM9697  Program Type, Search Type and Instructions
        ///A FAST Transaction file can only have a single Program Type entry. 
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0064()
        {
           
            try
            {
                #region DataDependency
                string Region = "2161";//Selecting QA canada region for now as it doesnt have program type
                string Office = "2162";//Office should be associated with above region
                #endregion
                Reports.TestDescription = "FM9689_FM9697_FM9690_FM9691_FM9692: Program Type, Search Type and Instructions.";
                Reports.StatusUpdate("BRs - FM9690,FM9691, FM9692 are covered in BAT00007 and BAT0008", true);
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                Reports.TestStep = "Select the region for which Program type is not defined.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(Region);
                FastDriver.ProgramTypeSetup.Open();
                 if(!FastDriver.ProgramTypeSetup.Table.FAGetText().Trim().Equals(""))
                 Support.Fail("Note:Dependency - Selecting QA canada region for now as it doesnt have program type. Select region which does not have prg type.");
                 //
                 Reports.TestStep = "Log into FAST application.";
                 MasterTestClass.PerformRequiredRegistrySettings();
                 IISLOGIN(AutoConfig.UserNameSU,AutoConfig.UserPasswordSU);
                 Reports.TestStep = "Select Canada region for file creation.";
                 FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(Office);
                Reports.TestStep = "Open QFE and validate program type.";
                 OpenQFEPage();
                 SetBusinessSourceDetails(@"", WaitCreation: false);
                 FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                 FastDriver.AddressBookSearchDlg.NewGabRequest(City: "Brooks", State: "AB", Zip: "223271");
                 FastDriver.QuickFileEntry.WaitForScreenToLoad();
                 SetServiceType(true, true);
                 SetFormType();
                 FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Accommodation");
                 //
                 Reports.TestStep = @"Validate that The Program Type section will be grayed out if there are no Program Types available for the region";
                Support.AreEqual("False", FastDriver.QuickFileEntry.ProgramType.IsEnabled().ToString());
                 //
                }            
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0067

        [TestMethod]
        public void FMUC0071_REG0067()
        {
           
            try
            {
                Reports.TestDescription = "ER_1: User has selected an option to cancel a new order.";


                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Create a basic order and click on cancel.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Cancel();
                Thread.Sleep(2000);
                //
                Reports.TestStep = "User has selected an option to cancel a new order in QFE.";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                string exp_Message = "All information will be erased for this new order.\r\nDo you wish to cancel this entry?";
                Support.AreEqualTrim(exp_Message, Message);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0068

        [TestMethod]
        public void FMUC0071_REG0068()
        {
            try
            {
                Reports.TestDescription = "ER_7: User selects a File Note type but does not enter text for the note.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create a basic order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Click on Ok button.";
                String Message=FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqualTrim(@"Error(s) occured. See Message pane.", Message);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                // 
                Reports.TestStep = "Validate the error message for User selects a File Note type but does not enter text for the note.";
                string ErrorPaneText="ServiceFileNote: No text was entered in the Note.";
                Support.AreEqualTrim(ErrorPaneText, FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText());
                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0069

        [TestMethod]
        public void FMUC0071_REG0069()
        {

            try
            {
                Reports.TestDescription = "ER_8: User enters text for a File Note but does not select a Note Type.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create a basic order. Do not select Note Type.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
                FastDriver.BottomFrame.Done();
                Thread.Sleep(2000);
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                // 
                Reports.TestStep = "Validate the error message for not selecting note type.";
                Support.AreEqualTrim("ServiceFileNoteTypeCdID: ServiceFileNoteTypeCdID is required.",FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText());
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0070

        [TestMethod]
        public void FMUC0071_REG0070()
        {
           
            try
            {
                Reports.TestDescription = "ER_10: User has requested a search without entering any search criteria.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Create a basic order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"",WaitCreation:false);
                //
                Reports.TestStep = "Click on Find button.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.Find.FAClick();               
                // 
                Reports.TestStep = "User has requested a search without enter any search criteria in QFE.";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"User must provide at least one search criterion to complete the search.", Message);                
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0071

        [TestMethod]
        public void FMUC0071_REG0071()
        {
            
            try
            {
                Reports.TestDescription = "ER_11: A wildcard is the first character in the search field.";
                // 
                // 
                Reports.TestStep = "Enter wild card and click on Find button.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                // 
                Reports.TestStep = "Open QFE and click find for business source.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"", WaitCreation: false);
                
                Reports.TestStep = "Click on Find button.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText(@"*");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                // 
                Reports.TestStep = "A wildcard is the first character in the search field in QFE.";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Searching with a wild card or a leading wild card has been temporarily disabled.", Message); 
                // 
                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickCancel();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0072

        [TestMethod]
        public void FMUC0071_REG0072()
        {
            try
            {
                Reports.TestDescription = "ER_12_ER_6: Manual file number already exists or is a reserved file number.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                //
                Reports.TestStep = "Enter file number";
                FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(false);
                FastDriver.QuickFileEntry.FileNumPrefix.FASetText(@"HAF");
                Random r = new Random();
                FastDriver.QuickFileEntry.FileNum.FASetText(r.Next(134567893, 999999999).ToString());
                FastDriver.QuickFileEntry.FileNumSufix.FASetText(@"HAF");
                string FileNum = FastDriver.QuickFileEntry.FileNum.FAGetValue();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                for (int i = 0; i < 5; i++)
                {
                    Reports.TestStep = "Attempt " + i + " to enter unique file number";
                    if (!FastDriver.WebDriver.HandleDialogMessage().Contains("No dialog present"))
                    {
                        FastDriver.QuickFileEntry.WaitForScreenToLoad();
                        if (FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText().Contains("Service File: File Number already exists or reserved"))
                            FastDriver.QuickFileEntry.FileNum.FASetText(r.Next(134567893, 999999999).ToString());
                        FastDriver.BottomFrame.Done();
                    }
                    else
                        break;
                }
                //
                Reports.TestStep = "Validate the Filenum.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string FileNumPrefix=FastDriver.FileHomepage.FileNumPrefix.FAGetValue();
                string FileNumSufix=FastDriver.FileHomepage.FileNumPrefix.FAGetValue();
                Support.AreEqual(@"HAF",FileNumPrefix);
                Support.AreEqual(FileNum, FastDriver.FileHomepage.FileNum.FAGetValue().ToString());
                Support.AreEqual(@"HAF", FileNumSufix);
                // 
                Reports.TestStep = "Open QFE page"; 
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetDirectedByGABDetails("HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                //
                Reports.TestStep = "Enter existing Manual file number.";
                FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(false);
                FastDriver.QuickFileEntry.FileNumPrefix.FASetText(FileNumPrefix);

                FastDriver.QuickFileEntry.FileNum.FASetText(FileNum);
                FastDriver.QuickFileEntry.FileNumSufix.FASetText(FileNumSufix);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                // 
                Reports.TestStep = "Validate the error message for existing Manual file number.";
                string Message = "Service File: File Number already exists or reserved.";
                Support.AreEqualTrim(FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText(), Message);
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0073

        [TestMethod]
        public void FMUC0071_REG0073()
        {
           
            try
            {
                Reports.TestDescription = "ER_13: Manual file number is invalid.";
                // 
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order.";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                Reports.TestStep = "Enter invalid Manual file number.";
                FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(false);
                FastDriver.QuickFileEntry.FileNumPrefix.FASetText(@"HAF");

                FastDriver.QuickFileEntry.FileNum.FASetText(@"####");
                FastDriver.QuickFileEntry.FileNumSufix.FASetText(@"HAF");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyDetailsInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                // 
                Reports.TestStep = "Validate the error message for invalid Manual file number.";     
                string Message=@"ServiceFile: A valid file number can only consist of a combination of letters, numbers and dashes.";
                Support.AreEqualTrim(FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText(), Message);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0074

        [TestMethod]
        public void FMUC0071_REG0074()
        {
            
            try
            {
                Reports.TestDescription = "ER_14: The User updates the page and then navigates off the page or the Done button is pressed.";
                // 
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                Reports.TestStep = "Ender date in QFE";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetNotes();
                // 
                Reports.TestStep = "User navigates away after update page.";
                FastDriver.LeftNavigation.ClickHome();
                string Message = FastDriver.WebDriver.HandleDialogMessage(false);
                Support.AreEqual(@"Exit without saving changes?", Message);
                // 
                Reports.TestStep = "Click on Cancel for Exit without save changes.";
                Message = FastDriver.WebDriver.HandleDialogMessage(true,false);
                string Exp_message= "All information will be erased for this new order.\r\nDo you wish to cancel this entry?";
                Support.AreEqualTrim(Exp_message, Message);     
                //
                Reports.TestStep = "Click on ok for Exit without save changes.";
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false);
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqualTrim(Exp_message, Message);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Verify that home screen is loaded.";
                FastDriver.HomePage.WaitForHomeScreen();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0075

        [TestMethod]
        public void FMUC0071_REG0075()
        {
            
            try
            {
                Reports.TestDescription = "ER_16_ER17: When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name.";
                // 
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                Reports.TestStep = "Ender date in QFE";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceEditName.FASetCheckbox(true);
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("True", Message.Contains("Name Field is required when Edit Name Checkbox is selected").ToString());
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                // 
                Reports.TestStep = "Uncheck Edit Name checkbox.";
                FastDriver.QuickFileEntry.BusinessSourceEditName.FASetCheckbox(false);               
                // 
                Reports.TestStep = "Check the Edit checkbox and enter invalid email.";
                FastDriver.QuickFileEntry.BusinessSourceEditCont.FASetCheckbox(true); 
                FastDriver.QuickFileEntry.BusinessSourceEmailAddress.FASetText(@"#######"+FAKeys.Tab);
                // 
                Reports.TestStep = "Verify the Tooltip for invalid email.";
                Support.AreEqual(@"?", FastDriver.QuickFileEntry.BusinessSourceEmailAddress.FAGetValue());
                string Tooltip = FastDriver.QuickFileEntry.BusinessSourceEmailAddress.FAGetAttribute("title");
                string ExpectedHoverText = "Email address is invalid.\r\nValid Examples:\r\n\txyz@abc.com\r\n\txyz@abc.com.uk\r\n\txyz_123@abc.com\r\n\txyz-12.wuv@abc.cnn.edu.uk";
                Support.AreEqual(ExpectedHoverText.Clean(), Tooltip.Clean());
                // 
                Reports.TestStep = "Set email blank.";
                FastDriver.QuickFileEntry.BusinessSourceEmailAddress.FASetText(""+FAKeys.Tab); 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0076

        [TestMethod]
        public void FMUC0071_REG0076()
        {            
            try
            {
                Reports.TestDescription = @"ER_19_ER_20: Selecting Buyer/Seller as an Additional Role without a valid “Buyer/Seller Type”.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDATASTL2");

                Reports.TestStep = "Click Version button to enable editing of key fields";
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(5000);

                Reports.TestStep = "Set up Email/ Buyer Seller Type for HUDATASTL2.";
                FastDriver.BusPartyOrgSetUp.BuyerSellerType.FASelectItem(@"");
                //
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                Reports.TestStep = "Create order and Select Buyer as an Additional Role without a valid “Buyer/Seller Type”.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDATASTL2", AdditionalRole: @"Buyer");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Select Buyer as an Additional Role without a valid “Buyer/Seller Type” in QFE.";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Additional Role (Buyer) does not have a valid GAB Buyer/Seller Type.", Message);
               //
                Reports.TestStep = "Set additional role to Seller.";
                SetBusinessSourceDetails(@"HUDATASTL2", AdditionalRole: @"Seller");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Select Seller as an Additional Role without a valid “Buyer/Seller Type” in QFE.";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Additional Role (Seller) does not have a valid GAB Buyer/Seller Type.", Message);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0077

        [TestMethod]
        public void FMUC0071_REG0077()
        {
           try
            {
                Reports.TestDescription = "ER_21_ER_22: Selecting Buyer as an Additional Role.";

                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                Reports.TestStep = "Select Buyer as additional role for Bus Source and Directed By.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1", AdditionalRole: @"Buyer");
                SetDirectedByGABDetails(@"HUDLEASE03", AdditionalRole: @"Buyer");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Validate warning message.";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Buyer has already been selected as an Additional Role", Message);
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();
                Reports.TestStep = "Select Seller as additional role for Bus Source and Directed By.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1", AdditionalRole: @"Seller");
                SetDirectedByGABDetails(@"HUDLEASE03", AdditionalRole: @"Seller");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Validate warning message.";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Seller has already been selected as an Additional Role", Message);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Select Seller and buyer additional role for Bus Source and Directed By.";
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem(@"Buyer");
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0079_PH

        [TestMethod]
        public void FMUC0071_REG0079_PH()
        {
            try
            {
                Reports.TestDescription = "ER_24_PlaceHolder: Validate manually The Liability Amount for the First New Loan is greater than the Program Type Liability Amount for the Business";
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0080

        [TestMethod]
        public void FMUC0071_REG0080()
        {
            
            try
            {
                Reports.TestDescription = "ER_26: User tries to change a Business Party which has a Reference number specified against it.";
                Reports.TestStep = "Login TO IIS.";
                IISLOGIN();
                Reports.TestStep = "Create order with reference for Bus Source.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1",BSREF:"Reference1");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetNotes();
                Thread.Sleep(2000);
                Reports.TestStep = "Enter other Gab Code in business and click on Find.";
                SetBusinessSourceDetails(@"HUDATASTL2", WaitCreation: false);
                Reports.TestStep = "User tries to change a Business Party which has a Reference number specified against it.";
                string Act_Message = FastDriver.WebDriver.HandleDialogMessage();
                string Exp_Message = "Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?";
                Support.AreEqual("True", Act_Message.Equals(Exp_Message).ToString());          
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion Test
        #region Test FMUC0071_REG0083

        [TestMethod]
        public void FMUC0071_REG0083()
        {
           
            try
            {
                Reports.TestDescription = "FD_01: Field Definitions in Tab Order.";
                // 
                Reports.TestStep = "Login TO IIS.";
                IISLOGIN();
                // 
                Reports.TestStep = "Open QFE page and enter Business Source.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Validate all available Additional Roles for QFE/QRE Business Source";
                string AllAdditionalRoles = FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FAGetText();
                string Exp_AdditionalRoles = @"Assumption Lender Buyer Buyer's Attorney Buyer's Broker Buyer's Real Estate Agent Construction Company/Builder For Sale by Owner Lender's Attorney Lender- Funding Lender- Loan Officer Lender- Mobile Banker Lender- Mortgage Centre Lender- Originating Branch Lender- Processor Lender- Signing Location Miscellaneous Mortgage Broker New Lender Other Real Estate Agent Other Real Estate Broker Outside Escrow Company Outside Title Company Payoff Lender Real Estate Investment Trust Search Vendor Seller Seller's Attorney Seller's Broker Seller's Real Estate Agent Title Agent";
                Support.AreEqualTrim(Exp_AdditionalRoles, AllAdditionalRoles);
                //
                Support.AreEqual(@"0", FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FAGetSelectedIndex().ToString());
                SetServiceType(true, true);
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.SubEscrow.IsSelected().ToString());
                SetFormType();
                Support.AreEqualTrim(@"Residential Commercial New Home Subdivision Time Share Default-Residential Default-Commercial", FastDriver.QuickFileEntry.BusinessSegment.FAGetText());
                Support.AreEqual(@"True", FastDriver.QuickFileEntry.AutoNumber.IsSelected().ToString());
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.FileNumPrefix.IsDisplayed().ToString());
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.FileNum.IsDisplayed().ToString());
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.FileNumSufix.IsDisplayed().ToString());
                
                string TransactionType = @"Accommodation Bulk Sale Construction Disbursement Construction Finance Equity Loan Foreclosure Limited Escrow Mtg Mod w/Endorsement Mtg Mod w/Increased Liability Refinance REO Sale w/Mortgage REO Sale/Cash Sale w/Construction Loan Sale w/Mortgage Sale/Cash Sale/Exchange Search Package Second Mortgage Settlement Statement Only Short Sale w/Mortgage Short Sale/Cash";
                Support.AreEqualTrim(TransactionType.Trim(), FastDriver.QuickFileEntry.TransactionType.FAGetText());
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.UseAsMasterFile.IsSelected().ToString());
                //
                Support.AreEqualTrim(@"No Program Type++View More...", FastDriver.QuickFileEntry.ProgramType.FAGetText());
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.ProgramTypeOverride.IsSelected().ToString());
                Support.AreEqual(@"True", FastDriver.QuickFileEntry.EscrowOwningOfficeAddress.IsDisplayed().ToString());
                Support.AreEqual(@"True", FastDriver.QuickFileEntry.TitleOwningOfficeAddress.IsDisplayed().ToString());
                Support.AreEqualTrim(@"First American Title Insurance Company", FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FAGetSelectedItem());
                //
                Support.AreEqualTrim(@"No Search Type++View More...", FastDriver.QuickFileEntry.SearchType.FAGetText());
                Support.AreEqualTrim(@"Individual Husband/Wife Trust/Estate Business Entity", FastDriver.QuickFileEntry.Buyer1Type.FAGetText());
                //
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem(@"Trust/Estate");
                Support.AreEqual(@"True", FastDriver.QuickFileEntry.SSN.IsSelected().ToString());
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.TIN.IsSelected().ToString());               
                // 
                Reports.TestStep = "Add/Remove the Business Programs.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.QuickFileEntry.AddRemoveBusinessProgrammes.FAClick();
                    Thread.Sleep(7000);
                    FastDriver.SelectBusinessProgramsDlg.SwitchToDialogContentFrame();
                    Thread.Sleep(7000);
                    if (FastDriver.SelectBusinessProgramsDlg.BPTable.IsVisible())
                        break;
                }
                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(1, 1, TableAction.Click);
                string BusinessProgram = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessProgramsTable.PerformTableAction("Business Program Name", BusinessProgram, "Business Program Name", TableAction.Click);

                Reports.TestStep = "Validate all available Additional Roles for QFE/QRE Directed by, Associated Business Party";
                SetDirectedByGABDetails(@"HUDASLNDR1");
                AllAdditionalRoles = FastDriver.QuickFileEntry.DirectedBYAddtionalRole.FAGetText();
                Support.AreEqualTrim(@Exp_AdditionalRoles, AllAdditionalRoles);
                // 
                SetAssociatedBusinessPartyDetails(@"HUDLEASE03");
                AllAdditionalRoles = FastDriver.QuickFileEntry.AssociatedBusinessPartyAddtionalRole.FAGetText();
                Support.AreEqualTrim(@Exp_AdditionalRoles, AllAdditionalRoles);
                //
                Reports.TestStep = "Verify the field values-2.";
                FastDriver.QuickFileEntry.ValidateFieldForLowerOrExactLimit(FastDriver.QuickFileEntry.TermsDatesSalesPrice, @"99,999,999,999.99", @"99,999,999,999.99");
                FastDriver.QuickFileEntry.ValidateFieldForLowerOrExactLimit(FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount, @"99,999,999,999.99", @"99,999,999,999.99");
                FastDriver.QuickFileEntry.ValidateFieldForLowerOrExactLimit(FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt, @"99,999,999,999.99", @"99,999,999,999.99");
                FastDriver.QuickFileEntry.ValidateFieldForLowerOrExactLimit(FastDriver.QuickFileEntry.TermsDatesNewLoanLiability, @"99,999,999,999.99", @"99,999,999,999.99");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem(@"Business Entity");
                Support.AreEqual(@"False", FastDriver.QuickFileEntry.SSN.IsSelected().ToString());
                Support.AreEqual(@"True", FastDriver.QuickFileEntry.TIN.IsSelected().ToString());   
                //
                Support.AreEqualTrim(@"Accounting Engineering EPIC Escrow Other Search Results Title UCC", FastDriver.QuickFileEntry.NoteType.FAGetText());
                //FastDriver.QuickFileEntry.EscrowProdOfficeTable.PerformTableAction(@"Mailing Address", @"50 First American Way Line 2,Smallville,CA,92707", "Mailing Address", TableAction.Click);
                //FastDriver.QuickFileEntry.TitleProdOfficeTable.PerformTableAction(@"Mailing Address", @"50 First American Way Line 2,Smallville,CA,92707", "Mailing Address", TableAction.Click);
                // 
                Reports.TestStep = "Verify the field values-3.";
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(@""+FAKeys.Tab);
                // 
                Reports.TestStep = "Verify for the message after change the sales price.";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Sales price has changed. Do you wish to update liability amount?", Message);              
                // 
                Reports.TestStep = "Verify the field values-5.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount.FASetText(@"" + FAKeys.Tab);
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText(@"" + FAKeys.Tab);
                // 
                Reports.TestStep = "Validate the message for New loan change liability";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"New loan amount has changed. Do you wish to update new loan liability amount?", Message);                
                // 
                Reports.TestStep = "Verify the field values-6.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TermsDatesNewLoanLiability.FASetText(@"" + FAKeys.Tab);
                // 
                Reports.TestStep = "Verify the field values-4.";
                FastDriver.QuickFileEntry.ValidateFieldForUpperLimit(FastDriver.QuickFileEntry.TermsDatesSalesPrice, @"99,999,999,9999.99", @"?");
                FastDriver.QuickFileEntry.ValidateFieldForUpperLimit(FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount, @"99,999,999,9999.99", @"?");
                FastDriver.QuickFileEntry.ValidateFieldForUpperLimit(FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt, @"99,999,999,9999.99", @"?");
                FastDriver.QuickFileEntry.ValidateFieldForUpperLimit(FastDriver.QuickFileEntry.TermsDatesNewLoanLiability, @"99,999,999,9999.99", @"?");
                //
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                // 

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0083_A

        [TestMethod]
        public void FMUC0071_REG0083_A()
        {

            try
            {
                Reports.TestDescription = "FD_02: Project File check Box.";
                #region Fast Search Setting
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();
                #endregion

                Reports.TestStep = "Login TO IIS.";
                IISLOGIN(); 
                Reports.TestStep = "Selecting the office to QA automation Office-DO Not touch";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");                
                Reports.TestStep = "Create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetServiceType(true, true);
                SetFormType();
                Support.AreEqual("False", FastDriver.QuickFileEntry.ProjectFile.IsSelected().ToString());
                FastDriver.QuickFileEntry.ProjectFile.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(2000);

                Reports.TestStep = @"After order creation is complete, FAST shall route Main File data to myFASTNCS directly using a predetermined Event Listener without launching  FAST Search";
                FastDriver.EventTrackingLog.Open();
                Thread.Sleep(10000);
                Support.AreEqual("False",FastDriver.EventTrackingLog.EventTable.FAGetText().Contains(@"[Fast Search Initiated]").ToString());
                Reports.TestStep = @"In case of a failure in rare circumstances, system shall log an Event Log entry indicating failure. ";
                Support.AreEqual("False", FastDriver.EventTrackingLog.EventTable.FAGetText().Contains(@"NCS").ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0086
        /// <summary>
        /// FM5375  Service Assistant Display Format  
        /// FM5390  Default Service Assistant Dependencies  
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0086()
        {
           
            try
            {
                #region DataDependency
                //Business party should have contact having last name as 'Contact'
                #endregion
                Reports.TestDescription = "FM5440 :(ADM) Title/Escrow Office/Assistant Selection.(IIS)Expected Failure in Index Validation :BR_FM5440_002: Assign Employees by Role (Verify in IIS).";
                Reports.StatusUpdate(" FM5375 FM5390 FM5391  FM5392 FM5393", true);
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Create New employee in QA AUtomation Office.";
                FastDriver.EmployeeSetup.Open();
                FastDriver.EmployeeSearch.New.FAClick();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                Dictionary<string, string> NewEmployeeData = FastDriver.EmployeeSetup.CreateNewEmployee(new[] { "Title Assistant", "Escrow Assistant" });
                string officer=NewEmployeeData["LastName"]+", "+ NewEmployeeData["FirstName"];
                      //Reports.TestStep = "Enter Title and escrow Officer for Bus Party.";
                      //Dictionary<string, string> TitleEscrowOfficerForGAB = GetChangedTitleEscrowOfficerForGAB("HUDWDINSR1", TitleEscrowOfficer: officer);
                      //Reports.TestStep = "Enter Title and escrow Officer for Bus Party Contact.";
                      //Dictionary<string, string> TitleEscrowOfficerForGABContact = GetChangedTitleEscrowOfficerForGABContact("HUDWDINSR1", "Contact");
                      // 
                Reports.TestStep = "Check for the role assigned for the fastts\fastqa07 employee in ADM side";
                SearchAndEditEmployeeInfo();
                //                
                Reports.TestStep = "Change the Employee Type to Title Officer.";
                FastDriver.EmployeeSetup.SelectRoles(new[] { "Title Assistant", "Escrow Assistant" });
                FastDriver.BottomFrame.Done();

                     Reports.TestStep = "FM5440 IIs side verification";
                     MasterTestClass.PerformRequiredRegistrySettings();
                     Reports.TestStep = "Login to IIS";
                     IISLOGIN();
                     Reports.TestStep = "Create order and validate the Title/Escrow Officer/Assistant is populated based on Bus Org.";
                     OpenQFEPage();
                     SetBusinessSourceDetails(@"HUDWDINSR1");
                     SetServiceType(true, true);
                     SetFormType();
                     FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                     SetBlankProgramType();
                     //
                     Support.AreEqual(@"QA07, FAST", FastDriver.QuickFileEntry.EscrowOwningOfficeAssistant.FAGetSelectedItem());
                     Support.AreEqual(@"QA07, FAST", FastDriver.QuickFileEntry.TitleOwningOfficeAssistant.FAGetSelectedItem());
                     //
                     FastDriver.QuickFileEntry.EscrowOwningOfficeAssistant.FASelectItem(officer);
                     FastDriver.QuickFileEntry.TitleOwningOfficeAssistant.FASelectItem(officer);
                     // 
                     Reports.TestStep = "Change bus org and validate the Title/Escrow Assistant.";
                     SetBusinessSourceDetails(@"HUDFLINSR1");                    
                     // 
                     Support.AreEqual(officer, FastDriver.QuickFileEntry.EscrowOwningOfficeAssistant.FAGetSelectedItem().ToString());
                     Support.AreEqual(officer, FastDriver.QuickFileEntry.TitleOwningOfficeAssistant.FAGetSelectedItem().ToString());
                     Reports.TestStep = "Change owning office and validate the Title/Escrow Officer/Assistant is blank by default.";
                     string[] AllOffices = FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');
                     foreach (string Office in AllOffices)
                     {
                         if (Office.Contains("JVR Office"))
                         {
                             FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem(Office);
                             Thread.Sleep(5000);
                             FastDriver.QuickFileEntry.WaitForScreenToLoad();
                             break;
                         }
                     }
                     if (!FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetSelectedItem().Contains("JVR"))
                         Reports.StatusUpdate("Required office is not selected", false);
                     Support.AreEqual("0", FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FAGetSelectedIndex().ToString());
                     Support.AreEqual("0", FastDriver.QuickFileEntry.EscrowOwningOfficeAssistant.FAGetSelectedIndex().ToString());
               
                //
                     AllOffices = FastDriver.QuickFileEntry.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');
                     foreach (string Office in AllOffices)
                     {
                         if (Office.Contains("JVR Office"))
                         {
                             FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem(Office);
                             Thread.Sleep(5000);
                             FastDriver.QuickFileEntry.WaitForScreenToLoad();
                             break;
                         }
                     }
                     if (!FastDriver.QuickFileEntry.TitleOwningOffice.FAGetSelectedItem().Contains("JVR"))
                         Reports.StatusUpdate("Required office is not selected", false);
                     Support.AreEqual("0", FastDriver.QuickFileEntry.TitleOwningOfficeAssistant.FAGetSelectedIndex().ToString());
                     Support.AreEqual("0", FastDriver.QuickFileEntry.TitleOwningOfficeOfficer.FAGetSelectedIndex().ToString());
                     SetPropertyAddressInQFE();                    
                     FastDriver.BottomFrame.Done();
                     Thread.Sleep(4000);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0087

        [TestMethod]
        public void FMUC0071_REG0087()
        {

            Reports.TestDescription = "BR_FM5440_002: Assign Employees by Role (Verify in IIS).";
            Reports.StatusUpdate("This flow is covered in REG0086",true);
                

        }
        #endregion Test
        #region Test FMUC0071_REG0088_PH

        [TestMethod]
        public void FMUC0071_REG0088_PH()
        {
            try
            {
                Reports.TestDescription = "FM7520_FM7522_FM7523_FM5395_PlaceHolder: Maintain the sequencing of default production offices at file.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0089_PH

        [TestMethod]
        public void FMUC0071_REG0089_PH()
        {
            try
            {
                Reports.TestDescription = "FM7769_FM7770_FM7771_FM7772_FM7773_FM7774_FM7775_FM7776_...._FM7786_PlaceHolder: Validate Business Source as Agent First.";
                // 
                Reports.TestStep = "Do not Validate the BR's related to AgentNet First as this interface Retired from FAST.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0090_PH

        [TestMethod]
        public void FMUC0071_REG0090_PH()
        {
            try
            {
                Reports.TestDescription = "FM7777_FM7778_FM7779_FM7780_FM7781_FM7782_FM7783_FM7784_FM7785_FM7786_PlaceHolder: Display Required Field Indicators Dynamically for AF Customer O.";
                // 
                // 
                Reports.TestStep = "Do not Validate the BR's related to AgentNet First as this interface Retired from FAST.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0091
        /// <summary>
        /// FM9706  Instructions - This BR is Covered in REG0038
        /// FM9707  Additional Instructions  	(removed from use case doc)
        ///Users can enter up to 350 characters in free form text in the Additional Instructions field in the Search Instruction section. 
        ///This information will be passed to the Search Vendor. 
        /// FM13852 - Removed from Usecase doc
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0091()
        {
            
            try
            {
                Reports.TestDescription = "FM9706: Instructions.";
                Reports.StatusUpdate("FM9706  Instructions - This BR is Covered in REG0038 and FM9707_FM13852 are removed from use case doc", true);
                /* 
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                Reports.TestStep = "Create order to Enter additional instruction details.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Accommodation");
                SetBlankProgramType();
                Reports.TestStep = "Click on Add Instructions.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Thread.Sleep(5000);
                string InputValue253 = "Users can enter up to 250 characters in free form text in the Additional Instructions field in the Search Instruction section. Users can enter up to 250 characters in free form text in the Additional Instructions field in the Search Instruction section.";
                string InputValue250 = "Users can enter up to 250 characters in free form text in the Additional Instructions field in the Search Instruction section Users can enter up to 250 characters in free form text in the Additional Instructions field in the Search Instruction sectio";
                FastDriver.QuickFileEntry.AddInstruction.FASetText(InputValue253 + FAKeys.Tab);
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqualTrim(Message, @"Additional Instructions can have a maximum of 250 characters.");
                Reports.TestStep = "Validate char limit for the field.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.AddInstruction.FASetText(InputValue250 + FAKeys.Tab);
                SetPropertyAddressInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                Reports.TestStep = "Validate e-reg checkbox";
                Support.AreEqual("True", FastDriver.QuickFileEntry.Propertyreg.IsEnabled().ToString());
                FastDriver.QuickFileEntry.Propertyreg.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                 *                  * */
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }


        }
        #endregion Test
        #region Test FMUC0071_REG0092

        [TestMethod]
        public void FMUC0071_REG0092()
        {
            
            try
            {
                Reports.TestDescription = "FM9696 : Edit Auto Selected Fields..";
                // 
                Reports.TestStep = "Login To IIS";
                IISLOGIN();
                Reports.TestStep = "Enter details to create order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                Reports.TestStep = "Select a programType.";
                FastDriver.QuickFileEntry.SelectProgramType(@"BAT_MPT_4");

                Support.AreEqual(@"BAT_MPT_4", FastDriver.QuickFileEntry.ProgramType.FAGetSelectedItem());
               
                Reports.TestStep = "Click on Add/Remove button for Products.";
                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Add Product.";
                FastDriver.ProductListDlg.AddProduct("Agency File Scanning");
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                // 
                Reports.TestStep = "Validate the product is added.";
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(@"#2", "Agency File Scanning", "#2", TableAction.Click); 

                Reports.TestStep = "Select the Search Type.";
                FastDriver.QuickFileEntry.SearchType.FASelectItemBySendingKeys(0, lastFirst: true);
                FastDriver.SearchTypeDialogDlg.WaitForScreenToLoad();
                if (!FastDriver.SearchTypeDialogDlg.SelectionRadioButton.IsSelected())
                    FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select Instructions.";
                string[] Instructions= AddInstructions();
                Reports.TestStep = "Validate that instruction is added";
                Support.AreEqual("True", FastDriver.QuickFileEntry.Instructions.FAGetValue().Contains(Instructions[0]).ToString());
                Support.AreEqual("True", FastDriver.QuickFileEntry.Instructions.FAGetValue().Contains(Instructions[1]).ToString());
                Reports.TestStep = "Provide Other Information to Create Order.";
                SetProgramTypeOverride();
                SetPropertyAddressInQFE();
                SetBuyerSellerDetails();
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0093

        [TestMethod]
        public void FMUC0071_REG0093()
        {
            
            try
            {
                Reports.TestDescription = "FM14547: Show / Enable Request Policy Number Link.";
                // 
                Thread.Sleep(100);
                Reports.TestStep = "Login to ADM and Check the Agentnet Policy number checkbox.";
                ADMLOGIN();
                SetRequestPolicyNumCheckbox(true);
                //
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Create Order with Title and Escrow services.";
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetPropertyAddressInQFE();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);

                Reports.TestStep = "Navigating to Request Policy Number link.";
                Support.AreEqual("True",FastDriver.LeftNavigation.CheckIfLinkIsPresent("Home>Order Entry>Request Policy Number").ToString());

                Reports.TestStep = "FM14548: Hide / Disable Request Policy Number Link.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                Reports.TestStep = "Create Order with Escrow services.";
                SetServiceType(false, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                SetPropertyAddressInQFE();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                Reports.TestStep = "Validating the RPN LINK is not present.";
                Support.AreEqual("False", FastDriver.LeftNavigation.CheckIfLinkIsPresent("Home>Order Entry>Request Policy Number").ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0094
        /// <summary>
        /// FMXXXX(137591) Mark File as an Special attention Required File
        /// FMXXXX(137591)  Event Log for Special Attention information
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0094()
        {

            try
            {
                Reports.TestDescription = "ER_27_137591 Mark File as an Special attention Required File.";
                // 
                ADMLOGIN();
                Reports.TestStep = "Add appropriate activity right for special attention checkbox";
                bool Result = CheckActivityRightInRole("IT - all", "Assign File Special Handling Activity", "1486", "1487");
                Support.AreEqual("True", Result.ToString());
                Thread.Sleep(100);
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                Reports.TestStep = "Enter data in qfe with program type.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                Reports.TestStep = "Select blank programType.";
                SetBlankProgramType();
                Thread.Sleep(2000);
                SetPropertyAddressInQFE();

                Reports.TestStep = "Check the Override Checkbox.";
                if (!FastDriver.QuickFileEntry.SpecialAttentionRequired.IsSelected())
                    FastDriver.QuickFileEntry.SpecialAttentionRequired.FASetCheckbox(true);

                SetNotes();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Validate ER27 for missing special attention text";
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqualTrim("Special attention text required", Message);
                Reports.TestStep = "Enter special attention text";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.SpecialAttentionComment.FASetText("Attention Please!");
                string ActualComment = FastDriver.QuickFileEntry.SpecialAttentionComment.FAGetText();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(4000);
                // 
                Reports.TestStep = "Verify the Event Log for Special Attention(Event)";
                FastDriver.EventTrackingLog.Open();
                if(!FastDriver.EventTrackingLog.EventCategory.FAGetSelectedItem().Equals("File Process"))
                FastDriver.EventTrackingLog.SelectEventCategory("File Process");
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Special Attention]", "Event", TableAction.Click);

                Reports.TestStep = "Verify the Event Log for File created(Source)";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Source", @"FAST Application", "Source", TableAction.Click);

                Reports.TestStep = "Verify the Event Log for File created(User)";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"User", AutoConfig.UserName.ToUpper(), "User", TableAction.Click);

                Reports.TestStep = "To verify the Start Date and Completed Date is equal to current system date";
                string Expected_Start_Completion_Date = DateTime.Now.ToDateString();
                Expected_Start_Completion_Date = Expected_Start_Completion_Date.Replace("-", "/");

                string ActualStartDate = FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Special Attention]", "#2", TableAction.GetText).Message;
                Support.AreEqual("True", ActualStartDate.Contains(Expected_Start_Completion_Date).ToString());
                //
                string ActualCompletionDate = FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Special Attention]", "#3", TableAction.GetText).Message;
                Support.AreEqual("True", ActualCompletionDate.Contains(Expected_Start_Completion_Date).ToString());
                //
                string Comments = FastDriver.EventTrackingLog.EventTable.PerformTableAction(@"Event", @"[Special Attention]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", Comments.Contains(ActualComment).ToString());
                Support.AreEqual("True", Comments.Contains("Special Attention Checked").ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0071_REG0095
        /// <summary>
        /// US496198 - Before Property State is provided on the QRE and QFE and before 'DONE' is selected:
        /// </summary>
        [TestMethod]
        public void FMUC0071_REG0095()
        {

            try
            {
                Reports.TestDescription = "US243162 Select License Information - QFE for Escrow Owning Office.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Get license info for Office";
                List<LicenseInfoParameters> AllLicenses = GetAllLicenseInfoForOffice("1487", "STEST");
                string State = "CA";
                List<string> SettlemntAgentSTLicIdsAll=new List<string>();
                List<string> SettlemntAgentSTLicIdsWithState = new List<string>();
                foreach(LicenseInfoParameters lic in AllLicenses)
                {
                    if (lic.LicenseType.Contains(@"Settlement Agent / Officer") && lic.LicenseStatus.Equals("Active")) //&& !lic.LicenseState.Equals(State))
                        if (!string.IsNullOrEmpty(lic.LicenseType)||!string.IsNullOrEmpty(lic.LicenseId))
                    {
                        SettlemntAgentSTLicIdsAll.Add(lic.LicenseState + ", " + lic.LicenseId);
                    }

                    if (lic.LicenseType.Contains(@"Settlement Agent / Officer") && lic.LicenseStatus.Equals("Active") && lic.LicenseState.Equals(State))
                        if (!string.IsNullOrEmpty(lic.LicenseType) || !string.IsNullOrEmpty(lic.LicenseId))
                    {
                        SettlemntAgentSTLicIdsWithState.Add(lic.LicenseState + ", " + lic.LicenseId);
                    }
                        
                }
                if (SettlemntAgentSTLicIdsAll.Count == 0)
                {
                    Reports.TestStep = "Create new license for Office";
                    LicenseInfoParameters LicenseSettlementAgent = CreateNewLicenseForOffice("1487", "STEST", "CA", @"Settlement Agent / Officer");
                    SettlemntAgentSTLicIdsWithState.Add(LicenseSettlementAgent.LicenseState + ", " + LicenseSettlementAgent.LicenseId);
                }
                //
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Enter data to Create Order.";
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDASLNDR1");
                SetDirectedByGABDetails(@"HUDLEASE03");
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                Reports.TestStep = "Change escrow owning office.";
                string[] AllOffices = FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');
                foreach (string Office in AllOffices)
                {
                    if (Office.Contains(AutoConfig.SelectedOfficeName))
                    {
                        FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem(Office);
                        Thread.Sleep(5000);
                        FastDriver.QuickFileEntry.WaitForScreenToLoad();
                        break;
                    }
                }
                Reports.TestStep = "Validate ST license id for Escrow owning office when state is not selected.";

                foreach (string LicenseId in SettlemntAgentSTLicIdsAll)
                {
                    bool flag = false;
                    if (!LicenseId.Equals(FastDriver.QuickFileEntry.EscrowOwningOfficeSTLicenseId.FAGetSelectedItem()))
                    {
                        foreach (string ID in FastDriver.QuickFileEntry.EscrowOwningOfficeSTLicenseId.FAGetAllTextFromSelect().Split('|'))
                        {
                            if (LicenseId.Equals(ID))
                            {
                                flag = true;
                                Reports.StatusUpdate("Required Value is present as an option is drop down", flag);
                                break;
                            }
                        }
                    }
                    else
                    {
                        flag = true;
                        Reports.StatusUpdate("Required Value is present as an option is drop down", flag);
                        break;
                    }
                }
                Reports.TestStep = "Complete the order.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Validate ST license id for Escrow owning office when state is selected.";
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(State);
                foreach (string LicenseId in SettlemntAgentSTLicIdsWithState)
                {
                    bool flag = false;
                    if (!LicenseId.Equals(FastDriver.QuickFileEntry.EscrowOwningOfficeSTLicenseId.FAGetSelectedItem()))
                    {
                        foreach (string ID in FastDriver.QuickFileEntry.EscrowOwningOfficeSTLicenseId.FAGetAllTextFromSelect().Split('|'))
                        {
                            if (LicenseId.Equals(ID))
                            {
                                flag = true;
                                Reports.StatusUpdate("Required Value is present as an option is drop down", flag);
                                break;
                            }
                        }
                    }
                    else
                    {
                        flag = true;
                        Reports.StatusUpdate("Required Value is present as an option is drop down", flag);
                        break;
                    }

                }
                SetNotes();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }


        #endregion Test
        #region Test FMUC0071_REG0096

        [TestMethod]
        public void FMUC0071_REG0096()
        {
            try
            {
                Reports.TestDescription = "To verify system allows to select Sales Rep1 and Sales Rep2 in QRE";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                #region UI

                Reports.TestStep = "Loginto IIS and create a basic file";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Quick Refi Entry via Home|Order Entry|Quick Refi Entry";
                FastDriver.LeftNavigation.Navigate<QuickRefiFileEntry>("Home>Order Entry>Quick Refi Entry");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();

                Reports.TestStep = "Click on Skip Search button";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();

                Reports.TestStep = "Add a GAB";
                FastDriver.QuickRefiFileEntry.BusinessSourceGABcode.FASetText("242");
                FastDriver.QuickRefiFileEntry.BusinessSourceFind.FAClick();

                Reports.TestStep = "Select Sales Rep1 and Sales Rep2";
                FastDriver.QuickRefiFileEntry.BusinessSourceSalesRep1.FASelectItem("QA02, FAST");
                FastDriver.QuickRefiFileEntry.BusinessSourceSalesRep2.FASelectItem("QA03, FAST");

                Reports.TestStep = "Select the service type Title and Escrow";
                FastDriver.QuickRefiFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickRefiFileEntry.Escrow.FASetCheckbox(true);

                Reports.TestStep = "Select a State";
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");

                Reports.TestStep = "Click on Done button";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify in File Homepage, Sales Rep1 and Sales Rep2 should be displayed as selected in step5";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual("QA02, FAST", FastDriver.FileHomepage.BusinessPartySalesRep1.FAGetSelectedItem().Clean());
                Support.AreEqual("QA03, FAST", FastDriver.FileHomepage.BusinessPartySalesRep2.FAGetSelectedItem().Clean());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion
        #region Test FMUC0071_REG0097

        [TestMethod]
        public void FMUC0071_REG0097()
        {
            try
            {
                Reports.TestDescription = "To verify the Sales Rep1 and Sales Rep2 added from QRE screen are displayed during any Email delivery";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                #region UI

                Reports.TestStep = "Loginto IIS and create a basic file";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Quick Refi Entry via Home|Order Entry|Quick Refi Entry";
                FastDriver.LeftNavigation.Navigate<QuickRefiFileEntry>("Home>Order Entry>Quick Refi Entry");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();

                Reports.TestStep = "Click on Skip Search button";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();

                Reports.TestStep = "Add a GAB";
                FastDriver.QuickRefiFileEntry.BusinessSourceGABcode.FASetText("242");
                FastDriver.QuickRefiFileEntry.BusinessSourceFind.FAClick();

                Reports.TestStep = "Select Sales Rep1 and Sales Rep2";
                FastDriver.QuickRefiFileEntry.BusinessSourceSalesRep1.FASelectItem("QA02, FAST");
                FastDriver.QuickRefiFileEntry.BusinessSourceSalesRep2.FASelectItem("QA03, FAST");

                Reports.TestStep = "Select the service type Title and Escrow";
                FastDriver.QuickRefiFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickRefiFileEntry.Escrow.FASetCheckbox(true);

                Reports.TestStep = "Select a State";
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");

                Reports.TestStep = "Click on Done button";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Balance summary via Home|order Entry|Escrow closing";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select a Delivery method as Email";
                FastDriver.EscrowFileBalanceSummary.Method("Email");
                FastDriver.EscrowFileBalanceSummary.btnDeliver.FAClick();

                Reports.TestStep = "Click on From button";
                FastDriver.EmailDlg.WaitForDialogToLoad();
                FastDriver.EmailDlg.From.FAClick();
                FastDriver.SearchPageDlg.WaitForDialogToLoad();

                Reports.TestStep = "Select Sales Rep1 and click on Finished button";
                string SalesRep1Email = FastDriver.SearchPageDlg.SalesRepTable.PerformTableAction(2, 4, TableAction.GetText).Message;
                FastDriver.SearchPageDlg.SalesRepTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.SearchPageDlg.Finished.FAClick();
                FastDriver.EmailDlg.WaitForDialogToLoad();
                Support.AreEqual(SalesRep1Email, FastDriver.EmailDlg.FromText.FAGetValue().Clean());

                Reports.TestStep = "Click on From button";
                FastDriver.EmailDlg.From.FAClick();
                FastDriver.SearchPageDlg.WaitForDialogToLoad();

                Reports.TestStep = "Select Sales Rep2 and click on Finished button";
                string SalesRep2Email = FastDriver.SearchPageDlg.SalesRepTable.PerformTableAction(3, 4, TableAction.GetText).Message;
                FastDriver.SearchPageDlg.SalesRepTable.PerformTableAction(3, 1, TableAction.On);
                FastDriver.SearchPageDlg.Finished.FAClick();
                FastDriver.EmailDlg.WaitForDialogToLoad();
                Support.AreEqual(SalesRep2Email, FastDriver.EmailDlg.FromText.FAGetValue().Clean());

                Reports.TestStep = "Click on To button";
                FastDriver.EmailDlg.To.FAClick();
                FastDriver.SearchPageDlg.WaitForDialogToLoad();

                Reports.TestStep = "Select Sales Rep1 and Sales Rep2and click on Finished button";
                FastDriver.SearchPageDlg.EmployeeSearchAddressBook.FAClick();
                FastDriver.SearchPageDlg.SalesRepTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.SearchPageDlg.SalesRepTable.PerformTableAction(3, 1, TableAction.On);
                FastDriver.SearchPageDlg.Finished.FAClick();
                FastDriver.EmailDlg.WaitForDialogToLoad();
                Support.AreEqual(SalesRep1Email + ";" + SalesRep2Email, FastDriver.EmailDlg.ToText.FAGetValue().Clean());
                FastDriver.EmailDlg.Cancel.FAClick();

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion 
        #region Test FMUC0071_REG0098: TC824125 A drop-down selection list of 'UW Employee' is added to the Title Owning Office section of the Quick File Entry
        [TestMethod]
        public void FMUC0071_REG0098()
        {
            try
            {
                Reports.TestDescription = "TC824125 A drop-down selection list of 'UW Employee' is added to the Title Owning Office section of the QFE";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Check and setup on UW Employee type on ADM side
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa06";


                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa06");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA06]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa07";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa07");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA07]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Create a FAST file via Home | Order Entry | Quick File Entry";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Enter a GAB and Required info in the Service area";
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                Reports.TestStep = "Verify that UW Employee default to Blank";
                FastDriver.QuickFileEntry.UW_Employee.IsVisible();// add UW_Employee in QuickFileEntry.cs
                Support.AreEqual(true, FastDriver.QuickFileEntry.UW_Employee.FAGetSelectedItem().Contains(""), "Default to Blank");

                Reports.TestStep = "Select an UW Employee";
                FastDriver.QuickFileEntry.UW_Employee.FASelectItem("QA07, FAST");

                Reports.TestStep = "Enter a FULL Property Address: Street address, City, State, Zip, County";
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("123 Testing Ave");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92630");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");

                Reports.TestStep = "Click Done to create file";
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to Event/Tracking Log screen and verify file created.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Opened]"), "File Created");

                Reports.TestStep = "Navigate to File Homepage screen and verify UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem().Contains("QA07, FAST"), "Verify UW Employee");//Add TitleOwnOfficeUWEmployees in FileHomapge.cs

                Reports.TestStep = "Navigate to File Summary screen and verify UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileSummary.TittleOO_UWEmployee.FAGetText().Contains("FAST QA07"), "Verify UW Employee");//Add TittleOO_UWEmployee in FileSummary.cs

            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        #endregion
        #region Test FMUC0071_REG0099: TC824126 A drop-down selection list of 'UW Employee' is added to the Title Owning Office section of the Quick Refi Entry
        [TestMethod]
        public void FMUC0071_REG0099()
        {
            try
            {
                Reports.TestDescription = "TC824126 A drop-down selection list of 'UW Employee' is added to the Title Owning Office section of the Quick Refi Entry";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Check and setup on UW Employee type on ADM side
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa06";


                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa06");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA06]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa07";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa07");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA07]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a FAST file via Home | Order Entry | Quick Refi Entry";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick Refi Entry").ClickSkipSearchButton();
                FastDriver.QuickRefiFileEntry.SwitchToContentFrame();

                Reports.TestStep = "Enter a GAB and Required info in the Service area";
                FastDriver.QuickRefiFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickRefiFileEntry.BusinessSourceFind.FAClick();
                if (!FastDriver.QuickRefiFileEntry.Title.Selected)
                    FastDriver.QuickRefiFileEntry.Title.FAClick();
                if (!FastDriver.QuickRefiFileEntry.Escrow.Selected)
                    FastDriver.QuickRefiFileEntry.Escrow.FAClick();
                FastDriver.QuickRefiFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickRefiFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickRefiFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickRefiFileEntry.FormType_CD.FASetCheckbox(true);

                Reports.TestStep = "Verify that UW Employee default to Blank";
                FastDriver.QuickRefiFileEntry.UW_Employee.IsVisible(); //Add UW_Employee in QuickRefiEntry.cs
                Support.AreEqual(true, FastDriver.QuickRefiFileEntry.UW_Employee.FAGetSelectedItem().Contains(""), "Default to Blank");

                Reports.TestStep = "Select an UW Employee";
                FastDriver.QuickRefiFileEntry.UW_Employee.FASelectItem("QA07, FAST");

                Reports.TestStep = "Enter a FULL Property Address: Street address, City, State, Zip, County";
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("123 Testing Ave");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("92630");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("Orange");

                Reports.TestStep = "Click Done to create file";
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to Event/Tracking Log screen and verify file created.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Opened]"), "File Created");

                Reports.TestStep = "Navigate to File Homepage screen and verify UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem().Contains("QA07, FAST"), "Verify UW Employee");

                Reports.TestStep = "Navigate to File Summary screen and verify UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileSummary>(@"Home>Order Entry>File Summary").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileSummary.TittleOO_UWEmployee.FAGetText().Contains("FAST QA07"), "Verify UW Employee");


            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        #endregion

        #region Test FMUC0071_REG0100

        [TestMethod]
        public void FMUC0071_REG0100()
        {
            try
            {
                Reports.TestDescription = "Verify Manufactured Home value exists in Property Type dropdown on QFE screen";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();

                Reports.TestStep = "Create a file with Transaction Type: Sale w/Morgage, and Business Segment: Residential ";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");

                Reports.TestStep = "Verify Property Type: Manufactured Home exits, and select it";
                if (FastDriver.QuickFileEntry.PropertyInformationType.FAGetText().Clean().Contains(@"Manufactured Home"))
                {
                    Reports.StatusUpdate("Manufactured Home exists", true);
                }
                else Reports.StatusUpdate("Manufactured Home exists", false);

                SetPropertyAddressInQFE();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate Property Type field from Properties/Tax Infor screen contains Manufactured Home value";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Thread.Sleep(3000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                string PropertyType = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
                Support.AreEqual("True", PropertyType.Contains("Manufactured Home").ToString().Clean());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion

        #region Test FMUC0071_REG0101

        [TestMethod]
        public void FMUC0071_REG0101()
        {
            try
            {

                Reports.TestDescription = "Verify Manufactured Home value exists in Property Type dropdown on QRE screen";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();

                Reports.TestStep = "Create a file with Transaction Type: Sale w/Morgage, and Business Segment: Residential ";

                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();

                string BSREF = "";
                string AdditionalRole = "";
                bool WaitCreation = true;

                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickRefiFileEntry.BusinessSourceFind.FAClick();
                if (WaitCreation)
                    FastDriver.QuickRefiFileEntry.WaitCreation(FastDriver.QuickRefiFileEntry.BusinessSourceReference);
                if (!string.IsNullOrEmpty(BSREF))
                    FastDriver.QuickRefiFileEntry.BusinessSourceReference.FASetText(BSREF);
                if (!string.IsNullOrEmpty(AdditionalRole))
                    FastDriver.QuickRefiFileEntry.BusinessSourceAddtionalRole.FASelectItem(AdditionalRole);

                FastDriver.QuickRefiFileEntry.Title.FASetCheckbox(false);
                FastDriver.QuickRefiFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickRefiFileEntry.SubEscrow.FASetCheckbox(true);


                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                if (AutoConfig.FormType.Equals("CD", StringComparison.CurrentCultureIgnoreCase))
                    FastDriver.QuickRefiFileEntry.FormType_CD.FASetCheckbox(true);
                else
                    FastDriver.QuickRefiFileEntry.FormType_HUD.FASetCheckbox(true);
                Thread.Sleep(2000);

                FastDriver.QuickRefiFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");

                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.ProgramType.FASelectItemByIndex(0);
                Thread.Sleep(3000);

                FastDriver.QuickRefiFileEntry.BusinessSegment.FASelectItem("Residential");

                Reports.TestStep = "Verify Property Type: Manufactured Home exits, and select it";
                if (FastDriver.QuickRefiFileEntry.PropertyInformationType.FAGetText().Clean().Contains(@"Manufactured Home"))
                {
                    Reports.StatusUpdate("Manufactured Home exists", true);
                }
                else Reports.StatusUpdate("Manufactured Home exists", false);

                SetPropertyAddressInQFE();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Validate Property Type field from Properties/Tax Info screen contains Manufactured Home value";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Thread.Sleep(3000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                string PropertyType = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
                Support.AreEqual("True", PropertyType.Contains("Manufactured Home").ToString().Clean());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 823701:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Production Office selection Window- QFE/QRE
        //TestCase                                : 850463
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0071_REG0102()
        {

            Reports.TestDescription = "US# 823701: Verify the Display dropdown in the Office Selection webpage (QRE).";

            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
            #endregion

            #region UI Iteration

            Reports.TestStep = "Log into IIS.";
            IISLOGIN();

            Reports.TestStep = "Navigate to QRE";
            FastDriver.QuickRefiFileEntry.OpenQREPage();
            SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
            SetServiceType();
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
            SetFormType();

            Reports.TestStep = "Click on Add Remove Production offices(Escrow) and verify the Display dropdown.";
            FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
            FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
            FastDriver.OfficeSelectionDlg.Display.Exists();
            Support.AreEqualTrim(@"Active|Hidden", FastDriver.OfficeSelectionDlg.Display.FAGetAllTextFromSelect());
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Hidden");
            Playback.Wait(3000);
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Active");
            Playback.Wait(3000);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();


            Reports.TestStep = "Click on Add Remove Production offices(Title) and verify the Display dropdown.";
            FastDriver.QuickFileEntry.AddRemoveTitleProdOffice.FAClick();
            FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
            FastDriver.OfficeSelectionDlg.Display.Exists();
            Support.AreEqualTrim(@"Active|Hidden", FastDriver.OfficeSelectionDlg.Display.FAGetAllTextFromSelect());
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Hidden");
            Playback.Wait(3000);
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Active");
            Playback.Wait(3000);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();


            #endregion UI
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 823701:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Production Office selection Window- QFE/QRE
        //TestCase                                : 850467
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0071_REG0103()
        {

            string OfficeCode1 = "0";
            string OfficeBuid = "0";
            try
            {

                Reports.TestDescription = "US# 823701: Verify  Active and Hidden Offices in Currently Selected Offices section (QRE) which is selected in the Office Selection webpage.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Active flag status as true for office if it's not set";
                    if (FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    FastDriver.OfficeSetupOffice.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    Playback.Wait(1000);
                }


                Reports.TestStep = "Log into IIS.";
                IISLOGIN();

                Reports.TestStep = "Navigate to QRE";
                FastDriver.QuickRefiFileEntry.OpenQREPage();
                SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
                SetServiceType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();

                Reports.TestStep = "Click on Add Remove Production offices(Escrow).";
                FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the active Production offices(Escrow) and verify in the QRE screen.";
                bool status = AddEscrowProdOffice("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Active");
                Support.AreEqual("True", status.ToString());

                Reports.TestStep = "Click on Add Remove Production offices(Title).";
                FastDriver.QuickFileEntry.AddRemoveTitleProdOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the active Production offices(Title) and verify in the QRE screen.";
                bool status1 = AddTitleProdOffice("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Active");
                Support.AreEqual("True", status1.ToString());

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", OfficeCode1, "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                Reports.TestStep = "Set the Close flag status as true for office";
                if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                }
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                Reports.TestStep = "Log into IIS.";
                IISLOGIN();

                Reports.TestStep = "Navigate to QRE";
                FastDriver.QuickRefiFileEntry.OpenQREPage();
                SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
                SetServiceType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();

                Reports.TestStep = "Click on Add Remove Production offices(Escrow).";
                FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the hidden Production offices(Escrow) and verify in the QRE screen.";
                bool status2 = AddEscrowProdOffice("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Hidden");
                Support.AreEqual("True", status2.ToString());

                Reports.TestStep = "Click on Add Remove Production offices(Title).";
                FastDriver.QuickFileEntry.AddRemoveTitleProdOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the hidden Production offices(Title) and verify in the QRE screen.";
                bool status3 = AddTitleProdOffice("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Hidden");
                Support.AreEqual("True", status3.ToString());

                #endregion UI

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        //Team                                       : < SRT Team1>
        //Iteration                                  : <r08.2016>
        //UserStory                                  : <815232> <Direct - Reorder of File Notes in FAST (Quick File Entry)> 
        // TestCase                                  : <All testcases covered as part of the script>
        //Appended By/ Created By                    : <Senthil Kumar Thangavelu>

        #region FMUC0071_REG0104

        [TestMethod]

        public void FMUC0071_REG0104()
        {

            try
            {
                Reports.TestDescription = "System shall Re-Order the File Note.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetServiceType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"#2 First American Way");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"Santa Clara");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"Santa Clara");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem(@"Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText(@"Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText(@"Buyer1Lastname");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem(@"Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText(@"Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText(@"Seller1Lastname");
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.NoteType.FASelectItem("Escrow");
                FastDriver.QuickFileEntry.Notes.FASetText(@"QFE File Note sort order - * # Special character :) !");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                Reports.TestStep = "Navigate to File Note screen and verify the File Note";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.Table.PerformTableAction("Note", @"QFE File Note sort order - * # Special character :) !", "Note", TableAction.Click);
                Playback.Wait(4000);
                //
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion File_Notes_Reorder_QFE


        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r10
        //UserStory                               : User Story 858524:REQ0909373 - NCS - Hide Select Office Names- Introduce blank in TOO/EOO dropdown in QFE/QRE.
        //TestCase                                : 872507
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0071_REG0105()
        {
            string OfficeCode1 = "0";
            string OfficeBuid = "0";
            try
            {
                Reports.TestDescription = "US#858524 : System shall display Blank Office in Escrow and Title office drop down on QFE screen if Office is marked as Hidden (QFE).";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    FastDriver.OfficeSetupOffice.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for the created office.";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }

                Playback.Wait(4000);
                Reports.TestStep = "Log into IIS.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                Reports.TestStep = "Navigate to QFE";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
                SetDirectedByGABDetails("HUDLEASE03", DBRef: @"1234567894");
                SetServiceType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetPropertyAddressInQFE();

                Reports.TestStep = "Verify the default escrow owning office should be blank.";
                if (FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Escrow Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Escrow owning office");
                }

                Reports.TestStep = "Verify the default title owning office should be blank.";
                if (FastDriver.QuickFileEntry.TitleOwningOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.QuickFileEntry.TitleOwningOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Escrow Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.QuickFileEntry.TitleOwningOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Escrow owning office");
                }

                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Reports.TestStep = "Validate a warning Message.";
                Support.AreEqual("Escrow Owning Office is required", FastDriver.WebDriver.HandleDialogMessage());
                Playback.Wait(3000);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Reports.TestStep = "Validate a warning Message.";
                Support.AreEqual("Title Owning Office is required", FastDriver.WebDriver.HandleDialogMessage());
                Playback.Wait(3000);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Click Done to create QFE";
                FastDriver.BottomFrame.Done();
                Playback.Wait(20000);

                #endregion UI
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r10
        //UserStory                               : User Story 858524:REQ0909373 - NCS - Hide Select Office Names- Introduce blank in TOO/EOO dropdown in QFE/QRE.
        //TestCase                                : 872513
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0071_REG0106()
        {
            string OfficeCode1 = "0";
            string OfficeBuid = "0";
            try
            {
                Reports.TestDescription = "US#858524 : System shall display Blank Office in Escrow and Title office drop down on QRE screen if Office is marked as Hidden (QRE).";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(10000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    FastDriver.OfficeSetupOffice.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for the created office.";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }

                Playback.Wait(4000);
                Reports.TestStep = "Log into IIS.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                Reports.TestStep = "Navigate to QRE";
                FastDriver.QuickRefiFileEntry.OpenQREPage();
                SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
                SetServiceType();
                FastDriver.QuickRefiFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem(@"CA");

                Reports.TestStep = "Verify the default escrow owning office should be blank.";
                if (FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Escrow Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Escrow owning office");
                }

                Reports.TestStep = "Verify the default title owning office should be blank.";
                if (FastDriver.QuickRefiFileEntry.TitleOwningOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.QuickRefiFileEntry.TitleOwningOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Escrow Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.QuickRefiFileEntry.TitleOwningOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Escrow owning office");
                }

                Reports.TestStep = "Verify the hidden office should not display in the escrow office dropdown.";
                string[] AllEscrowOffices = FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under escrow owning office.");

                Reports.TestStep = "Verify the hidden office should not display in the title office dropdown.";
                string[] AllTitleOffices = FastDriver.QuickRefiFileEntry.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Title = false;
                foreach (string office in AllTitleOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Title = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Title, "Verify the Hidden Office should not be present under title owning office.");

                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Reports.TestStep = "Validate a warning Message.";
                Support.AreEqual("Escrow Owning Office is required", FastDriver.WebDriver.HandleDialogMessage());
                Playback.Wait(3000);
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FASelectItemByIndex(1);
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Reports.TestStep = "Validate a warning Message.";
                Support.AreEqual("Title Owning Office is required", FastDriver.WebDriver.HandleDialogMessage());
                Playback.Wait(3000);
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.TitleOwningOffice.FASelectItemByIndex(1);
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                Reports.TestStep = "Click Done to create QRE";
                FastDriver.BottomFrame.Done();
                Playback.Wait(20000);

                #endregion UI
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                      : SRT-Team2
        //Iteration                 : r11.2016
        //UserStory                 : User Story 750525:[ROOT CAUSE] INC2555219 Agent FAST Incident - able to pull a CPL the underwriter is NOT FA
        //TestCase                  : 904278, 916198
        //Appended By/ Created By   : Diego Hilario

        [TestMethod]
        public void FMUC0071_REG0107()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Test Case 904278:To Verify US#750525 - CPL visibility on left navigation panel based on Underwritter";

                Reports.TestStep = "Log in to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);

                Reports.TestStep = "Create a basic file with Underwritter different than 'First American Title'";

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad().ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FASelectItem("New Underwriter");
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Ensure Closing Protection Letter link is NOT displayed on the left navigation panel. Navigate to CPL screen";
                Support.AreEqual(false, FastDriver.LeftNavigation.CheckIfLinkIsPresent(@"Home>Order Entry>Closing Protection Letter"), "Verifying CPL link is displayed");

                Reports.TestStep = "Navigate to File Homepage ";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Change the underwritter to 'First American Title'";
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItem("First American Title Insurance Company");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Save the changes on File Homepage screen ";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Ensure Closing Protection Letter link is displayed on the left navigation panel ";
                Support.AreEqual(true, FastDriver.LeftNavigation.CheckIfLinkIsPresent(@"Home>Order Entry>Closing Protection Letter"), "Verifying CPL link is displayed");

                Reports.TestStep = "Navigate to Closing Protection Letter screen ";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Change the Underwriter to any other different than 'First American Title Insurance Company' ";
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItem("New Underwriter");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Save the changes on File Homepage screen ";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Ensure Closing Protection Letter link is NOT displayed on the left navigation panel. Navigate to CPL screen";
                Support.AreEqual(false, FastDriver.LeftNavigation.CheckIfLinkIsPresent(@"Home>Order Entry>Closing Protection Letter"), "Verifying CPL link is displayed");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0071_REG0108()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
                #endregion

                Reports.TestDescription = "Test Case 916198:To Verify US#750525 - CPL visibility on left navigation panel based on Underwriter - User with no CPL Creation Activity rights";

                Reports.TestStep = "Log in to FAST IIS with an user that does NOT have CPL Creation Activity right";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);

                Reports.TestStep = "Create a basic file with Underwritter different than 'First American Title'";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad().ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FASelectItem("New Underwriter");
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Ensure Closing Protection Letter link is NOT displayed on the left navigation panel. Navigate to CPL screen";
                Support.AreEqual(false, FastDriver.LeftNavigation.CheckIfLinkIsPresent(@"Home>Order Entry>Closing Protection Letter"), "Verifying CPL link is not displayed");

                Reports.TestStep = "Navigate to File Homepage ";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Change the underwritter to 'First American Title'";
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItem("First American Title Insurance Company");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Save the changes on File Homepage screen ";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Ensure Closing Protection Letter link is NOT displayed on the left navigation panel ";
                Support.AreEqual(false, FastDriver.LeftNavigation.CheckIfLinkIsPresent(@"Home>Order Entry>Closing Protection Letter"), "Verifying CPL link is not displayed");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0071_REG0109()
        {
            string OfficeCode1 = "0";
            string OfficeBuid = "0";
            try
            {
                Reports.TestDescription = "Verify system is displaying  acive offices which are not hidden in QFE screen.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    FastDriver.OfficeSetupOffice.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for the created office.";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }

                Playback.Wait(4000);
                Reports.TestStep = "Log into IIS.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                Reports.TestStep = "Navigate to QFE";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
                SetDirectedByGABDetails("HUDLEASE03", DBRef: @"1234567894");
                SetServiceType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetPropertyAddressInQFE();

                Reports.TestStep = "Verify the hidden office should not display in the escrow office dropdown.";
                string[] AllEscrowOffices = FastDriver.QuickFileEntry.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under escrow owning office.");

                Reports.TestStep = "Verify the hidden office should not display in the title office dropdown.";
                string[] AllTitleOffices = FastDriver.QuickFileEntry.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Title = false;
                foreach (string office in AllTitleOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Title = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Title, "Verify the Hidden Office should not be present under title owning office.");

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItemByIndex(1);
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Click Done to create QFE";
                FastDriver.BottomFrame.Done();
                Playback.Wait(20000);

                #endregion UI
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r08,r10
        //UserStory                               : User Story 799322:REQ0909373 - NCS - Hide Select Office Names in FAST Office Selection Screens-File side-QFE/QRE/NFE
        //User Story 858524:REQ0909373 - NCS - Hide Select Office Names- Introduce blank in TOO/EOO dropdown in QFE/QRE.
        //TestCase                                : 826639,872513
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0071_REG0110()
        {
            string OfficeCode1 = "0";
            string OfficeBuid = "0";
            try
            {
                Reports.TestDescription = "Verify system is displaying  acive offices which are not hidden in QRE screen.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(10000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    FastDriver.OfficeSetupOffice.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Set the Hidden flag status as true for the created office.";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }

                Playback.Wait(4000);
                Reports.TestStep = "Log into IIS.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(OfficeBuid);

                Reports.TestStep = "Navigate to QRE";
                FastDriver.QuickRefiFileEntry.OpenQREPage();
                SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
                SetServiceType();
                FastDriver.QuickRefiFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem(@"CA");

                Reports.TestStep = "Verify the default escrow owning office should be blank.";
                if (FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Escrow Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Escrow owning office");
                }

                Reports.TestStep = "Verify the default title owning office should be blank.";
                if (FastDriver.QuickRefiFileEntry.TitleOwningOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.QuickRefiFileEntry.TitleOwningOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Escrow Owning office");
                }
                else
                {
                    Support.AreEqual("2", FastDriver.QuickRefiFileEntry.TitleOwningOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Escrow owning office");
                }

                Reports.TestStep = "Verify the hidden office should not display in the escrow office dropdown.";
                string[] AllEscrowOffices = FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Escrow = false;
                foreach (string office in AllEscrowOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Escrow = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Escrow, "Verify the Hidden Office should not be present under escrow owning office.");

                Reports.TestStep = "Verify the hidden office should not display in the title office dropdown.";
                string[] AllTitleOffices = FastDriver.QuickRefiFileEntry.TitleOwningOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_Title = false;
                foreach (string office in AllTitleOffices)
                {
                    if (office.Contains(OfficeCode1))
                    {
                        isPresent_Title = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_Title, "Verify the Hidden Office should not be present under title owning office.");

                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Reports.TestStep = "Validate a warning Message.";
                Support.AreEqual("Escrow Owning Office is required", FastDriver.WebDriver.HandleDialogMessage());
                Playback.Wait(3000);
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.EscrowOwningOffice.FASelectItemByIndex(1);
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Reports.TestStep = "Validate a warning Message.";
                Support.AreEqual("Title Owning Office is required", FastDriver.WebDriver.HandleDialogMessage());
                Playback.Wait(3000);
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.TitleOwningOffice.FASelectItemByIndex(1);
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                Reports.TestStep = "Click Done to create QRE";
                FastDriver.BottomFrame.Done();
                Playback.Wait(20000);

                #endregion UI
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 823701:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Production Office selection Window- QFE/QRE
        //TestCase                                : 850453
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0071_REG0111()
        {

            Reports.TestDescription = "US# 823701: Verify the Display dropdown in the Office Selection webpage (QFE).";

            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
            #endregion

            #region UI Iteration

            Reports.TestStep = "Log into IIS.";
            IISLOGIN();

            Reports.TestStep = "Navigate to QFE";
            OpenQFEPage();
            SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
            SetDirectedByGABDetails("HUDLEASE03", DBRef: @"1234567894");
            SetServiceType();
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
            SetFormType();
            FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");

            Reports.TestStep = "Click on Add Remove Production offices(Escrow) and verify the Display dropdown.";
            FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
            FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
            FastDriver.OfficeSelectionDlg.Display.Exists();
            Support.AreEqualTrim(@"Active|Hidden", FastDriver.OfficeSelectionDlg.Display.FAGetAllTextFromSelect());
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Hidden");
            Playback.Wait(3000);
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Active");
            Playback.Wait(3000);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();

            Reports.TestStep = "Click on Add Remove Production offices(Title) and verify the Display dropdown.";
            FastDriver.QuickFileEntry.AddRemoveTitleProdOffice.FAClick();
            FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
            FastDriver.OfficeSelectionDlg.Display.Exists();
            Support.AreEqualTrim(@"Active|Hidden", FastDriver.OfficeSelectionDlg.Display.FAGetAllTextFromSelect());
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Hidden");
            Playback.Wait(3000);
            FastDriver.OfficeSelectionDlg.Display.FASelectItem("Active");
            Playback.Wait(3000);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();


            #endregion UI
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 823701:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Production Office selection Window- QFE/QRE
        //TestCase                                : 850460
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0071_REG0112()
        {
            string OfficeCode1 = "0";
            string OfficeBuid = "0";

            try
            {

                Reports.TestDescription = "US# 823701: Verify  Active and Hidden Offices in Currently Selected Offices section (QFE) which is selected in the Office Selection webpage.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    FastDriver.OfficeSetupOffice.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeCode1 = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Office Code", TableAction.GetText).Message.ToString();
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    Playback.Wait(1000);
                }

                Playback.Wait(4000);
                Reports.TestStep = "Log into IIS.";
                IISLOGIN();

                Reports.TestStep = "Navigate to QFE";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
                SetDirectedByGABDetails("HUDLEASE03", DBRef: @"1234567894");
                SetServiceType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");

                Reports.TestStep = "Click on Add Remove Production offices(Escrow).";
                FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the active Production offices(Escrow) and verify in the QFE screen.";
                bool status = AddEscrowProdOffice("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Active");
                Support.AreEqual("True", status.ToString());

                Reports.TestStep = "Click on Add Remove Production offices(Title).";
                FastDriver.QuickFileEntry.AddRemoveTitleProdOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the active Production offices(Title) and verify in the QFE screen.";
                bool status1 = AddTitleProdOffice("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Active");
                Support.AreEqual("True", status1.ToString());

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", OfficeCode1, "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                Reports.TestStep = "Set the Close flag status as true for office";
                if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                }
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                Reports.TestStep = "Log into IIS.";
                IISLOGIN();

                Reports.TestStep = "Navigate to QFE";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1", BSREF: @"1234567891");
                SetDirectedByGABDetails("HUDLEASE03", DBRef: @"1234567894");
                SetServiceType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");

                Reports.TestStep = "Click on Add Remove Production offices(Escrow).";
                FastDriver.QuickFileEntry.AddRemoveEscrowProdOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the hidden Production offices(Escrow) and verify in the QFE screen.";
                bool status2 = AddEscrowProdOffice("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Hidden");
                Support.AreEqual("True", status2.ToString());


                Reports.TestStep = "Click on Add Remove Production offices(Title).";
                FastDriver.QuickFileEntry.AddRemoveTitleProdOffice.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add the hidden Production offices(Title) and verify in the QFE screen.";
                bool status3 = AddTitleProdOffice("QA Automation Region - DO NOT TOUCH", "SRT Test Automation Office", "Hidden");
                Support.AreEqual("True", status3.ToString());

                #endregion UI

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        
        #region PrivateMethods
        private void IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);

        }
        //
        private void ADMLOGIN(string UserName = null, string Password = null)
        {
                Reports.TestStep = "Log in to the Admin site";
                UserName = UserName ?? AutoConfig.UserNameSU;
                Password = Password ?? AutoConfig.UserPasswordSU;
                Credentials credentials = new Credentials() { UserName = UserName, Password = Password };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
        }
        //
        private void SearchAndEditEmployeeInfo()
        {
            try
            {
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search an employee and click on Edit.";
                EmployeeSearchParameters ESParams = new EmployeeSearchParameters();
                ESParams.LoginName = AutoConfig.UserName;
                FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.SearchEmployee(ESParams);
                FastDriver.EmployeeSearch.EditEmployee(AutoConfig.UserName.ToUpper());
                
                            }
            catch(Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }
        //
        private bool CheckActivityRightInRole(string RoleName,string ActivityRight,string RegionBUID,string OfficeBUID)
        {

            try
            {
                Reports.TestDescription = "Adding rights to the user.";

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                //
                Reports.TestStep = "Enter userid and search.";
                FastDriver.EmployeeSecurity.Open();
                FastDriver.EmployeeSecurity.SearchAndSelectEmployee(AutoConfig.UserName);
                Thread.Sleep(7000);
               //
                Reports.TestStep = "Expand the Roles.";
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                FastDriver.BusinessUnitRoleAssignment.ExpandTheRoles(RegionBUID, OfficeBUID);      
                return FastDriver.BusinessUnitRoleAssignment.CheckActivityRightInRole(RoleName, ActivityRight);

            }

            catch (Exception e)
            {
                Reports.StatusUpdate(e.Message,false);
                return false;
            }

        }
        //
        public string GetStateOfBusinessAddress()
        {
            string state = "";
            Dictionary<string, string> AddressDetails = FastDriver.OfficeSetupOffice.GetAddressDetails("Business");



            string value = "Success";
            if (!AddressDetails.TryGetValue("Status", out value))
            {
                BusinessOrganizationParameters BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Business";
                BusOrgParams.AddressLine1 = @"Fire Insurance 1 business street 1";
                BusOrgParams.AddressLine2 = @"Fire Insurance 1 business street 2";
                BusOrgParams.AddressLine3 = @"Fire Insurance 1 business street 3";
                BusOrgParams.AddressLine4 = @"Fire Insurance 1 business street 4";
                BusOrgParams.City = @"Fire Insurance 1 business city";
                BusOrgParams.State = "CA";
                BusOrgParams.Zip = @"74081-6545";
                BusOrgParams.County = @"Fire Insurance 1 business county";
                FastDriver.OfficeSetupOffice.SetNewAddressDetails(BusOrgParams);
                state=BusOrgParams.State;
            }
            else
            {
                state = FastDriver.OfficeSetupOffice.State.FAGetSelectedItem();

            }
            return state;
        }
        //
        private bool ValidateWireInstructionsOnEditDisbursement(Dictionary<string, string> WireInstructionsADM, string DisbAmount)
        {
            Dictionary<string, string> WireInstructionsDisb = new Dictionary<string, string>();
            FastDriver.ActiveDisbursementSummary.CheckIfDisbursementExists(DisbAmount);
            FastDriver.ActiveDisbursementSummary.Edit.FAClick();
            WireInstructionsDisb=FastDriver.EditDisbursement.GetWireDetails();
            CompareDictionaries(WireInstructionsDisb, WireInstructionsADM);
            return true;
        }
        private bool AddFirstProdOfficeFromDialog(string Region)
        {
            try
            {
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Region.FASelectItem(Region);
                Thread.Sleep(3000);
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction(1, 1, TableAction.On);
                string OfficeName = FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the ProductionOffice added.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                bool status = false;
                for (int i = 1; i <= FastDriver.QuickFileEntry.EscrowProdOfficeTable.GetRowCount(); i++)
                {
                    string ActualProdOfc = FastDriver.QuickFileEntry.EscrowProdOfficeTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    status = ActualProdOfc.Contains(OfficeName) && ActualProdOfc.Contains(Region);
                    if (status)
                        break;
                }
                return status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //
        private bool AddProdOfficeFromDialog(string Region, string OfficeName)
        {
            try
            {
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Region.FASelectItem(Region);
                Thread.Sleep(3000);
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", OfficeName, "Sel", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the ProductionOffice added.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                bool status = false;
                for (int i = 1; i <= FastDriver.QuickFileEntry.EscrowProdOfficeTable.GetRowCount(); i++)
                {
                    string ActualProdOfc = FastDriver.QuickFileEntry.EscrowProdOfficeTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (AutoConfig.SelectedRegionName.Contains(Region))
                        status = ActualProdOfc.Contains(OfficeName);
                    else
                        status = ActualProdOfc.Contains(OfficeName) && ActualProdOfc.Contains(Region);
                    if (status)
                        break;
                }
                return status;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        //
        private bool RemoveEscrowProdOffice(string Region, string OfficeName)
        {
            try
            {
                Reports.TestStep = "Remove Office.";
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.Region.FASelectItem(Region);
                Thread.Sleep(3000);
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", OfficeName, "Sel", TableAction.Off);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Reports.TestStep = "Validate that Office is removed.";
                bool status = false;
                for (int i = 1; i <= FastDriver.QuickFileEntry.EscrowProdOfficeTable.GetRowCount(); i++)
                {
                    string ActualProdOfc = FastDriver.QuickFileEntry.EscrowProdOfficeTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    status = ActualProdOfc.Contains(OfficeName) && ActualProdOfc.Contains(Region);
                    if (status)
                        break;
                }
                return !status;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
            
        //

        private bool CheckPresenceOrAddRequiredSplInstruction(string Instr, bool isSearchInstr = true, bool isFileProcInstr = true)
        {
            FastDriver.SpecialInstructionsSetup.Open();
            Thread.Sleep(10000);
            if (FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.FAGetText().Contains(Instr))
            {
                string Status = FastDriver.SpecialInstructionsSetup.SpecialInstructionsTable.PerformTableAction("Name", Instr, "Name", TableAction.Click).Status.ToString();
            }
            else 
            {
                if (!FastDriver.SpecialInstructionsSetup.AddNewInstruction(Instr, isSearchInstr, isFileProcInstr))
                    return false;
            }
            return true;
        }
        private bool CreateFile(bool title, bool escrow, bool subescrow = false)
        {
            try
            {
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.File.Services = RequestFactory.GetServices(title, escrow, subescrow);
                 Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(customizableFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                return true;
            }
            catch (Exception)
            {
                try
                {
                    return CreateQFEWithServiceType(title, escrow, subescrow);
                }
                catch (Exception ex)
                {
                    throw new Exception("Unable to create QFE", ex);
                }

            }
        }
        private Dictionary<string,string> GetTitleProdOfficesFromOfficeSetUp(string OfficeBUID)
        {
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
            FastDriver.OfficeSummary.Open();
            FastDriver.OfficeSummary.EditOffice(OfficeBUID);
             return FastDriver.OfficeSetupOffice.GetTitleProdOffices();
        }
        //
        private Dictionary<string, string> GetEscrowProdOfficesFromOfficeSetUp(string OfficeBUID)
        {
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
            FastDriver.OfficeSummary.Open();
            FastDriver.OfficeSummary.EditOffice(OfficeBUID);
            return FastDriver.OfficeSetupOffice.GetEscrowProdOffices();
        }
        //
        private string GetDefaultBusinessSegment(string OfficeBUID)
        {
            FastDriver.OfficeSummary.Open();
            FastDriver.OfficeSummary.EditOffice(OfficeBUID);
            return FastDriver.OfficeSetupOffice.GetDefaultBusinessSegment();

        }
        //
        private bool SetRequestPolicyNumCheckbox(bool status, string OfficeBUID=null)
        {
            OfficeBUID = OfficeBUID ?? AutoConfig.SelectedOfficeBUID;
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
            FastDriver.OfficeSummary.Open();
            FastDriver.OfficeSummary.EditOffice(OfficeBUID);
            return FastDriver.OfficeSetupOffice.SetRequestPolicyNumCheckbox(status);
        }
        private string GetChangedBusinessSegment(string OfficeBUID,string BusinessSegment)
        {
            FastDriver.OfficeSummary.Open();
            FastDriver.OfficeSummary.EditOffice(OfficeBUID);
            BusinessSegment=FastDriver.OfficeSetupOffice.ChangeBusinessSegment(BusinessSegment);
            FastDriver.BottomFrame.Done();
            Thread.Sleep(4000);
            return BusinessSegment;

        }
        //
        private bool EligibleForInterRegionalProdOffice(string OfficeBUID, string RegionCode)
        {
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
            FastDriver.OfficeSummary.Open(RegionCode);
            FastDriver.OfficeSummary.EditOffice(OfficeBUID);
            if (!FastDriver.OfficeSetupOffice.GetIsInterRegionalProdOffice())
                FastDriver.OfficeSetupOffice.SetIsInterRegionalProdOffice();
            return true;
        }
        //
        private LicenseInfoParameters CreateNewLicenseForOffice(string OfficeBUID, string RegionCode, string State, string StateLicenseType, string County = "", string CoLicenseType = "")
        {
            try
            {
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                FastDriver.OfficeSummary.Open(RegionCode);
                FastDriver.OfficeSummary.EditOffice(OfficeBUID);
                Reports.TestStep = "Create New License for Office";
                return FastDriver.OfficeSetupOffice.CreateNewLicense(State, StateLicenseType, County, CoLicenseType);
            }
            catch
            {
                throw;
            }
        }
        //
        private List<LicenseInfoParameters> GetAllLicenseInfoForOffice(string OfficeBUID, string RegionCode)
        {
            try
            {
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                FastDriver.OfficeSummary.Open(RegionCode);
                FastDriver.OfficeSummary.EditOffice(OfficeBUID);
                Reports.TestStep = "Get License for Office";
                return FastDriver.OfficeSetupOffice.GetLicenseInfo();
            }
            catch
            {
                throw;
            }
        }
        //
        private LicenseInfoParameters CreateNewLicenseForGAB(string GAB, string State, string StateLicenseType, string County = "", string CoLicenseType = "")
        {
            try
            {
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                FastDriver.AddressBookSearch.EditGAB(GAB);
                //
                Reports.TestStep = "Create New License for GAB";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(2000);
                return FastDriver.BusPartyOrgSetUp.CreateNewLicense(State, StateLicenseType, County, CoLicenseType);
            }
            catch
            {
                throw;
            }
        }
        private LicenseInfoParameters CreateNewLicenseForGABContact(string GAB, string ContactLastName, string State, string StateLicenseType, string County = "", string CoLicenseType = "")
        {
            try
            {
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                FastDriver.AddressBookSearch.EditGAB(GAB);
                Thread.Sleep(2000);
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB(ContactLastName);
                //
                Reports.TestStep = "Create New License for GAB Contact";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                Thread.Sleep(2000);
                return FastDriver.BusPartyContactSetup.CreateNewLicense(State, StateLicenseType, County, CoLicenseType); ;
            }
            catch
            {
                throw;
            }
        }
        //
        private bool CheckExistenceOf1099SActivityDateForOffice(string OfficeBUID)
        {
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
            FastDriver.OfficeSummary.Open();
            FastDriver.OfficeSummary.EditOffice(OfficeBUID);
            if (string.IsNullOrEmpty(FastDriver.OfficeSetupOffice.ActivityDate1099s.FAGetValue()))
                return false;
            else
                return true;
        }
        private string[] GetSalesRepDetailsForGABContact(string GAB, string ContactLastName)
        {
            string[] SalesRep = new string[2];
            try
            {
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB(GAB);
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB(ContactLastName);
                //
                Reports.TestStep = "Get sales rep";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                Thread.Sleep(2000);
                //FastDriver.BusPartyContactSetup.SalesRep1.FASelectItemByIndex(1);
                SalesRep = new[] { FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem(), FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem() };
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return SalesRep;

        }
        //
        private string[] GetSalesRepDetailsForGAB(string GAB)
        {
            string[] SalesRep = new string[2];
            try
            {
                //Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB(GAB);
                //
                Reports.TestStep = "Get sales rep";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(2000);
                if (string.IsNullOrEmpty(FastDriver.BusPartyOrgSetUp.SalesRep1.FAGetSelectedItem().Trim()))
                FastDriver.BusPartyOrgSetUp.SalesRep1.FASelectItemByIndex(1);
                if (string.IsNullOrEmpty(FastDriver.BusPartyOrgSetUp.SalesRep2.FAGetSelectedItem().Trim()))
                FastDriver.BusPartyOrgSetUp.SalesRep2.FASelectItemByIndex(1);
                SalesRep = new[] { FastDriver.BusPartyOrgSetUp.SalesRep1.FAGetSelectedItem(), FastDriver.BusPartyOrgSetUp.SalesRep2.FAGetSelectedItem() };
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return SalesRep;

        }
        //
        private string[] GetChangedSalesRepDetailsForGAB(string GAB)
        {
            string[] SalesRep = new string[2];
            try
            {
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB(GAB);
                //
                Reports.TestStep = "Get sales rep";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(2000);
                    FastDriver.BusPartyOrgSetUp.SalesRep1.FASelectItemByIndex(3);
                    FastDriver.BusPartyOrgSetUp.SalesRep2.FASelectItemByIndex(4);
                SalesRep = new[] { FastDriver.BusPartyOrgSetUp.SalesRep1.FAGetSelectedItem(), FastDriver.BusPartyOrgSetUp.SalesRep2.FAGetSelectedItem() };
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return SalesRep;

        }
        //
        private Dictionary<string, string> CreateNewContactForBusOrg(string GAB)
        {
            Dictionary<string, string> ContactName = new Dictionary<string, string>();

            try
            {
                //Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";

                FastDriver.AddressBookSearch.EditGAB(GAB);
                //
                Reports.TestStep = "Go to business party contact for the Bus Org.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                Thread.Sleep(2000);
                Reports.TestStep = "To click on New button in Business Party Contacts List.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.New.FAClick();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                ContactName = FastDriver.BusPartyContactSetup.CreateNewContactForBusOrg();         
                return ContactName;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message,false);
                return ContactName;
            }
            
        }
        //
        private string[] GetSalesRepOfPrimaryContactForGAB(string GAB, string ContactLastName)
        {
            string[] Expected_SalesRep = null;
            try
            {
                Thread.Sleep(100);
               // Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB(GAB);

                FastDriver.BusPartyOrgSetUp.PrimaryContact.FASelectItemBySendingKeys(ContactLastName);
                string PrimaryContact = FastDriver.BusPartyOrgSetUp.PrimaryContact.FAGetSelectedItem().Trim().ToString();

                Reports.TestStep = "Go to business party contact for the Bus Org.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                string LastName = PrimaryContact.Split(',')[0];

                FastDriver.BusPartyContactsList.ContactList.PerformTableAction("#3", LastName, "#3", TableAction.Click);
                SetGABContactStatus("Active", GAB);
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");
                //
                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItemByIndex(1);
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItemByIndex(2);
                Reports.TestStep = "Get details";
                Expected_SalesRep = new[] { FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem(), FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem() };

                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return Expected_SalesRep;
        }
        //
        //
        private string[] SetPrimaryContactForGAB(string GAB,string ContactLastName)
        {
            string[] Expected_SalesRep = null;
            try
            {
                Thread.Sleep(100);
                //Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB(GAB);
                if (string.IsNullOrEmpty(ContactLastName))
                    FastDriver.BusPartyOrgSetUp.PrimaryContact.FASelectItemByIndex(0);
                else
                FastDriver.BusPartyOrgSetUp.PrimaryContact.FASelectItemBySendingKeys(ContactLastName);
                string PrimaryContact = FastDriver.BusPartyOrgSetUp.PrimaryContact.FAGetSelectedItem().Trim().ToString();

                //Reports.TestStep = "Go to business party contact for the Bus Org.";
                //FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                //Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                //FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                //string LastName = PrimaryContact.Split(',')[0];

                //FastDriver.BusPartyContactsList.ContactList.PerformTableAction("#3", LastName, "#3", TableAction.Click);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return Expected_SalesRep;
        }
        //
        private string[] SetBlankSalesRepForGAB(string GAB)
        {
            string[] Expected_SalesRep = null;
            try
            {
                //Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB(GAB);
                Thread.Sleep(3000);
                 FastDriver.BusPartyOrgSetUp.SalesRep1.FASelectItemByIndex(0);
                                        FastDriver.BusPartyOrgSetUp.SalesRep2.FASelectItemByIndex(0);
                                        FastDriver.BottomFrame.Done();
                                        Thread.Sleep(5000);
               
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return Expected_SalesRep;
        }
        private string[] ChangeSalesRepDetailsForGABContact(string GAB, string ContactLastName, bool BlankSalesRep1 = false, bool BlankSalesRep2 = false)
        {
            string[] SalesRep = new string[2];
            try
            {
                //Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB(GAB);
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB(ContactLastName);
                //
                Reports.TestStep = "Get sales rep";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                Thread.Sleep(2000);
                if (!BlankSalesRep1)
                {
                    FastDriver.BusPartyContactSetup.SalesRep1.FASelectItemByIndex(1);
                }
                else
                {
                    FastDriver.BusPartyContactSetup.SalesRep1.FASelectItemByIndex(0);
                }
                if (!BlankSalesRep2)
                {
                    FastDriver.BusPartyContactSetup.SalesRep2.FASelectItemByIndex(2);
                }
                else
                {
                    FastDriver.BusPartyContactSetup.SalesRep2.FASelectItemByIndex(0);
                }
                SalesRep = new[] { FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem(), FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem() };

                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return SalesRep;

        }
        //
        //
        private Dictionary<string, string> GetChangedTitleEscrowOfficerForGABContact(string GAB, string ContactLastName, bool BlankTitleOfficer = false, bool BlankEscrowOfficer = false, string TitleEscrowOfficer="")
        {
            Dictionary<string, string> Officers = new Dictionary<string, string>();
            try
            {
                //Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB(GAB);
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB(ContactLastName);
                //
                Reports.TestStep = "Get Title and escrow officer";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                Thread.Sleep(2000);
                if (!BlankTitleOfficer && string.IsNullOrEmpty(TitleEscrowOfficer))
                {
                    FastDriver.BusPartyContactSetup.TitleOfficer.FASelectItemByIndex(2);
                }
                else if (BlankTitleOfficer)
                {
                    FastDriver.BusPartyContactSetup.TitleOfficer.FASelectItemByIndex(0);
                }
                else if (!string.IsNullOrEmpty(TitleEscrowOfficer))
                {
                    FastDriver.BusPartyContactSetup.TitleOfficer.FASelectItem(TitleEscrowOfficer);
                }
                if (!BlankEscrowOfficer && string.IsNullOrEmpty(TitleEscrowOfficer))
                {
                    FastDriver.BusPartyContactSetup.EscrowOfficer.FASelectItemByIndex(3);
                }
                else if (BlankEscrowOfficer)
                {
                    FastDriver.BusPartyContactSetup.EscrowOfficer.FASelectItemByIndex(0);
                }
                else if (!string.IsNullOrEmpty(TitleEscrowOfficer))
                {
                    FastDriver.BusPartyContactSetup.EscrowOfficer.FASelectItem(TitleEscrowOfficer);
                }
                Officers.Add("TitleOfficer", FastDriver.BusPartyContactSetup.TitleOfficer.FAGetSelectedItem());
                Officers.Add("EscrowOfficer",FastDriver.BusPartyContactSetup.EscrowOfficer.FAGetSelectedItem());
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return Officers;

        }
        //
        private Dictionary<string, string> GetChangedTitleEscrowOfficerForGAB(string GAB, bool BlankTitleOfficer = false, bool BlankEscrowOfficer = false,string TitleEscrowOfficer="")
        {
            Dictionary<string, string> Officers = new Dictionary<string, string>();
            try
            {
                //Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB(GAB);
                //
                Reports.TestStep = "Get Title and escrow officer";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Thread.Sleep(2000);
                if (!BlankTitleOfficer && string.IsNullOrEmpty(TitleEscrowOfficer))
                {
                    FastDriver.BusPartyOrgSetUp.TitleOfficer.FASelectItemByIndex(2);
                }
                else if (BlankTitleOfficer)
                {
                    FastDriver.BusPartyOrgSetUp.TitleOfficer.FASelectItemByIndex(0);
                }
                else if(!string.IsNullOrEmpty(TitleEscrowOfficer))
                {
                    FastDriver.BusPartyOrgSetUp.TitleOfficer.FASelectItem(TitleEscrowOfficer);
                }
                if (!BlankEscrowOfficer && string.IsNullOrEmpty(TitleEscrowOfficer))
                {
                    FastDriver.BusPartyOrgSetUp.EscrowOfficer.FASelectItemByIndex(3);
                }
                else if (BlankEscrowOfficer)
                {
                    FastDriver.BusPartyOrgSetUp.EscrowOfficer.FASelectItemByIndex(0);
                }
                else if(!string.IsNullOrEmpty(TitleEscrowOfficer))
                {
                    FastDriver.BusPartyOrgSetUp.EscrowOfficer.FASelectItem(TitleEscrowOfficer);
                }
                Officers.Add("TitleOfficer", FastDriver.BusPartyOrgSetUp.TitleOfficer.FAGetSelectedItem());
                Officers.Add("EscrowOfficer", FastDriver.BusPartyOrgSetUp.EscrowOfficer.FAGetSelectedItem());
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return Officers;

        }
        //
        private void OpenQFEPage()
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
        }
        private bool CreateDetailedQFE()
        {
            try
            {
                OpenQFEPage();
                FastDriver.QuickFileEntry.CreateDetailedFile();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to create QFE", ex);
            }

        }
        private void CreateQFEWithAdditionalRole(string BusinessSourceAddnRole = "", string DirectedByAddnRole = "", string AssociatedBPAddnRole = "")
        {
            try
            {
                OpenQFEPage();
                SetBusinessSourceDetails(@"HUDFLINSR1",AdditionalRole:BusinessSourceAddnRole);
                SetDirectedByGABDetails(@"HUDLEASE03", AdditionalRole: DirectedByAddnRole);
                SetServiceType(true, true);
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(@"Residential");
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                SetPropertyAddressInQFE();
                SetAssociatedBusinessPartyDetails(@"HUDASLNDR1", AdditionalRole: AssociatedBPAddnRole);
                SetNotes();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(7000);
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate("Unable to create QFE with additional role "+ex.Message, false);
            }
        }
        //
        private bool CreateQFEWithServiceType(bool title=false,bool escrow=true, bool subescrow=true)
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            NewFileParameters QFEParams = new NewFileParameters();
            QFEParams = NewFileParameters.GetDefaultParams();

            QFEParams.Title = title;
            QFEParams.Escrow = escrow;
            QFEParams.SubEscrow = subescrow;
            //
            FastDriver.QuickFileEntry.CreateFile(QFEParams);
            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }
            return true;
        }
        //
//
private void SetServiceType(bool Title=true,bool Escrow=true,bool SubEscrow=false)
{
    try
    {
        if (FastDriver.QuickFileEntry.Title.IsSelected()!=Title)
            FastDriver.QuickFileEntry.Title.FASetCheckbox(Title);
        if (FastDriver.QuickFileEntry.Escrow.IsSelected() != Escrow)
            FastDriver.QuickFileEntry.Escrow.FASetCheckbox(Escrow);
        if (FastDriver.QuickFileEntry.SubEscrow.IsSelected() != SubEscrow)
            FastDriver.QuickFileEntry.SubEscrow.FASetCheckbox(SubEscrow);
    }
    catch(Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
    }
}
   
private void SetFormType()
{
    FastDriver.QuickFileEntry.WaitForScreenToLoad();
    if (AutoConfig.FormType.Equals("CD", StringComparison.CurrentCultureIgnoreCase))
        FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
    else
        FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
    Thread.Sleep(2000);

}
//
private void SetDirectedByGABDetails(string GAB, string DBRef = "",string AdditionalRole="", bool WaitCreation = true)
{
    try
    {
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
        FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(GAB);
        FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
        if (WaitCreation)
        FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.DirectedBYReference);
        if (!string.IsNullOrEmpty(DBRef))
            FastDriver.QuickFileEntry.DirectedBYReference.FASetText(DBRef);
        if (!string.IsNullOrEmpty(AdditionalRole))
            FastDriver.QuickFileEntry.DirectedBYAddtionalRole.FASelectItem(AdditionalRole);
    }
    catch (Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
    }
}
        //

private void SetBusinessSourceDetails(string GAB, string BSREF = "",string AdditionalRole="",bool WaitCreation=true)
{
    try
    {
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
    FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(GAB);
    FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
    if (WaitCreation)
    FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceReference);
    if (!string.IsNullOrEmpty(BSREF))
        FastDriver.QuickFileEntry.BusinessSourceReference.FASetText(BSREF);
    if (!string.IsNullOrEmpty(AdditionalRole))
    FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem(AdditionalRole);
        }
    catch(Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
    }
}

private void SetNotes()
{
    FastDriver.QuickFileEntry.WaitForScreenToLoad();
    FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
    FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
}

private void SetAssociatedBusinessPartyDetails(string GAB, string ABPRef = "", string AdditionalRole="",bool WaitCreation=true)
{
    try
    {
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
    FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText(GAB);
    FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
    if (WaitCreation)
    FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.AssociatedBusinessPartyReference);
    if (!string.IsNullOrEmpty(ABPRef))
        FastDriver.QuickFileEntry.AssociatedBusinessPartyReference.FASetText(ABPRef);
    if (!string.IsNullOrEmpty(AdditionalRole))
        FastDriver.QuickFileEntry.AssociatedBusinessPartyAddtionalRole.FASelectItem(AdditionalRole);
    }
    catch (Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
    }
}

private void SetNewLenderDetails(string GAB = "247", string Ref = "", bool WaitCreation = true)
{
    try
    {
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
        FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(GAB);
        FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
        if(WaitCreation)
        FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.NewLenderInformationReference);
        if (!string.IsNullOrEmpty(Ref))
            FastDriver.QuickFileEntry.NewLenderInformationReference.FASetText(Ref);
    }
        
    catch(Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
    }
}

private void SetBuyerSellerDetails()
{
    try
    {
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
        FastDriver.QuickFileEntry.Buyer1Type.FASelectItem(@"Individual");
        FastDriver.QuickFileEntry.Buyer1FirstName.FASetText(@"Buyer1Firstname");
        FastDriver.QuickFileEntry.Buyer1LastName.FASetText(@"Buyer1Lastname");
        FastDriver.QuickFileEntry.Buyer2Type.FASelectItem(@"Husband/Wife");
        FastDriver.QuickFileEntry.Buyer2FirstName.FASetText(@"Buyer2Firstname");
        FastDriver.QuickFileEntry.Buyer2LastName.FASetText(@"Buyer2Lastname");
        FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText(@"Buyer2SpouseName");
        FastDriver.QuickFileEntry.Seller1Type.FASelectItem(@"Individual");
        FastDriver.QuickFileEntry.Seller1FirstName.FASetText(@"Seller1Firstname");
        FastDriver.QuickFileEntry.Seller1LastName.FASetText(@"Seller1Lastname");
        FastDriver.QuickFileEntry.Seller2Type.FASelectItem(@"Husband/Wife");
        FastDriver.QuickFileEntry.Seller2FirstName.FASetText(@"Seller2Firstname");
        FastDriver.QuickFileEntry.Seller2LastName.FASetText(@"Seller2Lastname");
        FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText(@"Seller2SpouseName");
    }
    catch
    {
        throw;
    }
}
private void SetPropertyDetailsInQFE()
{
    try
    {
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
        FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"J305");
        if (FastDriver.QuickFileEntry.PropertyInformationType.FAGetText().Contains(@"Single Family Residence"))
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Single Family Residence");
        else
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemByIndex(1);
        FastDriver.QuickFileEntry.PropertyInformationLot.FASetText(@"Lot1");
        FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText(@"Block1");
        FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText(@"Unit1");
        FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText(@"Prop1APN1");
        FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText(@"9845012345");
        FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"J305");
        FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"JJEJAMQ");
        FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"JJEJAMQ");
        FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
        FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA"); 
        FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"ALAMEDA");
        FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
    }
    catch (Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
    }
}
private void SetProgramTypeOverride(bool status = false)
{
    FastDriver.QuickFileEntry.WaitForScreenToLoad();
    FastDriver.QuickFileEntry.ProgramTypeOverride.FASetCheckbox(status);
    Thread.Sleep(1000);

}
        //
        private void SetBlankProgramType()
        {
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);
            Thread.Sleep(3000);

        }
        //
private void SetPropertyAddressInQFE()
{
    try
    {
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
        FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"J305");
        if (FastDriver.QuickFileEntry.PropertyInformationType.FAGetText().Contains(@"Single Family Residence"))
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Single Family Residence");
        else
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemByIndex(1);
        FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"J305");
        FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"JJEJAMQ");
        FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"JJEJAMQ");
        FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
        FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
        FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"ALAMEDA");
        FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
    }
    catch (Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
    }
}
private string[] AddInstructions(string[] Instructions = null, string AdditionalInstr = "")
{
    try
    { 
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
        FastDriver.QuickFileEntry.AddRemoveInstructions.FAClick();

        Reports.TestStep = "Select Instructions.";
       Instructions= Instructions??new[]{"Regression_Set1_Instruction1","Regression_Set1_Instruction2"};
        FastDriver.SelectInstructionsDlg.WaitForScreenLoad();
        foreach(string Instr in Instructions)
        {
        FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction("#2", Instr, "#1", TableAction.On);
        }
        FastDriver.DialogBottomFrame.ClickDone();
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
        if (!string.IsNullOrEmpty(AdditionalInstr))
        {
            FastDriver.QuickFileEntry.AddInstruction.FASetText(AdditionalInstr);
        }
        
        return Instructions;
    }
    catch (Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
        return new[] { "" };
    }

}
        //
private void VerifyDataInFileHomePage(Dictionary<string, string> PropertyDetailsQFE, Dictionary<string, string> BuyerDetailsQFE, Dictionary<string, string> SellerDetailsQFE)
{
    try
    {
        
        Reports.TestStep = "Verify fields in Filehomepage";

        Dictionary<string, string> PropertyDetailsFHP = new Dictionary<string, string>();
        FastDriver.FileHomepage.WaitForScreenToLoad();
        PropertyDetailsFHP = FastDriver.FileHomepage.GetPropDetails;
        bool Result = CompareDictionaries(PropertyDetailsQFE, PropertyDetailsFHP);  // it will cover verification TransactionType and TermsDatesSalesPrice also
        Support.AreEqual("True", Result.ToString());
        //
        Dictionary<string, string> BuyerDetailsFHP = new Dictionary<string, string>();
        BuyerDetailsFHP = FastDriver.FileHomepage.GetByrDtlsOnFhp;
        Result = CompareDictionaries(BuyerDetailsQFE, BuyerDetailsFHP);
        Support.AreEqual("True", Result.ToString());
        //
        Dictionary<string, string> SellerDetailsFHP = new Dictionary<string, string>();
        SellerDetailsFHP = FastDriver.FileHomepage.GetSelrDtlsOnFhp;
        Result = CompareDictionaries(SellerDetailsQFE, SellerDetailsFHP);
        Support.AreEqual("True", Result.ToString());
        //
        Reports.TestStep = "Verify FileNumber";
        string FHPFileNum=FastDriver.FileHomepage.FileNum.FAGetValue();
        FastDriver.TopFrame.SwitchToTopFrame();
        string Act_FileNum=FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
        Support.AreEqualTrim(FHPFileNum, Act_FileNum);
        FastDriver.FileHomepage.WaitForScreenToLoad();
    }
    catch (Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
    }
}
//
private bool CompareDictionaries(Dictionary<string, string> Dictionary1, Dictionary<string, string> Dictionary2)
{
    bool Result = false;
    try
    {
        int count = 0;

        foreach (var DictionaryItem in Dictionary1)
        {
            string Value = DictionaryItem.Value;
            bool isEqual = Dictionary2.TryGetValue(DictionaryItem.Key, out Value);
            if (isEqual)
            {
                count++;
            }
            else
                Reports.StatusUpdate("Values for Key " + DictionaryItem.Key + " are not matching", false);
        }
        if (count == Dictionary1.Count)
            Result = true;
        else
            Result = false;

        return Result;
    }
    catch (Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
        return Result;
    }
}
        //
private bool ComparePhoneDetails(Dictionary<string, string[]> ADMPhoneDetails, Dictionary<string, string[]> BuyerScreenPhoneDetails)
{
    bool Result = false;
    try
    {
        int count = 0;

        foreach (var DictionaryItem in ADMPhoneDetails)
        {
            string[] Value = DictionaryItem.Value;
            bool isEqual = BuyerScreenPhoneDetails.TryGetValue(DictionaryItem.Key, out Value);
            if (isEqual)
            {
                count++;
            }
            else
                Reports.StatusUpdate("Values for Key " + DictionaryItem.Key + " are not matching", false);
        }
        if (count == ADMPhoneDetails.Count)
            Result = true;
        else
            Result = false;

        return Result;
    }
        catch (Exception ex)
    {
        Reports.StatusUpdate(ex.Message, false);
        return Result;
    }
}
        //
private Dictionary<string, string> SetProperKeysForComparison(Dictionary<string, string> InputDictionary)
{
    Dictionary<string, string> OutputDictionary = new Dictionary<string, string>();
    foreach (var addrEntry in InputDictionary)
    {
        if (addrEntry.Key.Contains("1")&&!(addrEntry.Key.Contains("APN")))
        {
            OutputDictionary.Add("1", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("2") && !(addrEntry.Key.Contains("APN")))
        {
            OutputDictionary.Add("2", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("3"))
        {
            OutputDictionary.Add("3", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("4"))
        {
            OutputDictionary.Add("4", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("City"))
        {
            OutputDictionary.Add("City", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("County"))
        {
            OutputDictionary.Add("County", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Country"))
        {
            OutputDictionary.Add("Country", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("State"))
        {
            OutputDictionary.Add("State", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Zip"))
        {
            OutputDictionary.Add("Zip", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Lot"))
        {
            OutputDictionary.Add("Lot", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Block"))
        {
            OutputDictionary.Add("Block", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Unit"))
        {
            OutputDictionary.Add("Unit", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("APN1"))
        {
            OutputDictionary.Add("APN1", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("APN2"))
        {
            OutputDictionary.Add("APN2", addrEntry.Value);
            continue;
        }
    }
    return OutputDictionary;
}
        //
private Dictionary<string, string> SetProperKeysForComparisonForQFE(Dictionary<string, string> InputDictionary)
{
    Dictionary<string, string> OutputDictionary = new Dictionary<string, string>();

    foreach (var addrEntry in InputDictionary)
    {
        if (addrEntry.Key.Contains("Line1"))
        {
            OutputDictionary.Add("1", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Line2"))
        {
            OutputDictionary.Add("2", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Line3"))
        {
            OutputDictionary.Add("3", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Line4"))
        {
            OutputDictionary.Add("4", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("PropertyCity"))
        {
            OutputDictionary.Add("City", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("County"))
        {
            OutputDictionary.Add("County", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Country"))
        {
            OutputDictionary.Add("Country", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("State"))
        {
            OutputDictionary.Add("State", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Zip"))
        {
            OutputDictionary.Add("Zip", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Lot"))
        {
            OutputDictionary.Add("Lot", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Block"))
        {
            OutputDictionary.Add("Block", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("Unit"))
        {
            OutputDictionary.Add("Unit", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("APN1"))
        {
            OutputDictionary.Add("APN1", addrEntry.Value);
            continue;
        }
        else if (addrEntry.Key.Contains("APN2"))
        {
            OutputDictionary.Add("APN2", addrEntry.Value);
            continue;
        }
    }
    return OutputDictionary;
}
        //
private void SetGABContactStatus(string Status, string GAB)
{

    FastDriver.BusPartyContactsList.WaitForScreenToLoad();
    Reports.TestStep = "BR_ES13445_ADMsetup: Set GAB contact status";
    FastDriver.BusPartyContactsList.ViewChangeStatus.FAClick();
    FastDriver.StatusEdit.WaitForScreenToLoad();

    if (Status.Equals("InActive", StringComparison.InvariantCultureIgnoreCase))
    {
        if (FastDriver.StatusEdit.Deactivate.IsDisplayed())
        {
            FastDriver.StatusEdit.Deactivate.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.WebDriver.HandleDialogMessage();
        }
    }

    else
    {
        if (FastDriver.StatusEdit.Activate.IsDisplayed())
        {
            FastDriver.StatusEdit.Activate.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.WebDriver.HandleDialogMessage();
        }
    }

    FastDriver.BottomFrame.Done();
    FastDriver.BusPartyContactsList.WaitForScreenToLoad();

}
        //

private bool AddEscrowProdOffice(string Region, string OfficeName, string Display)
{
    try
    {
        FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
        FastDriver.OfficeSelectionDlg.Region.FASelectItem(Region);
        Thread.Sleep(3000);
        FastDriver.OfficeSelectionDlg.Display.FASelectItem(Display);
        Thread.Sleep(3000);
        FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", OfficeName, "Sel", TableAction.On);
        FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

        FastDriver.DialogBottomFrame.ClickDone();

        Reports.TestStep = "Verify the ProductionOffice added.";
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
        bool status = false;
        for (int i = 1; i <= FastDriver.QuickFileEntry.EscrowProdOfficeTable.GetRowCount(); i++)
        {
            string ActualProdOfc = FastDriver.QuickFileEntry.EscrowProdOfficeTable.PerformTableAction(i, 1, TableAction.GetText).Message;
            if (AutoConfig.SelectedRegionName.Contains(Region))
                status = ActualProdOfc.Contains(OfficeName);
            else
                status = ActualProdOfc.Contains(OfficeName) && ActualProdOfc.Contains(Region);
            if (status)
                break;
        }
        return status;
    }

    catch (Exception ex)
    {
        throw ex;
    }
}
//
private bool AddTitleProdOffice(string Region, string OfficeName, string Display)
{
    try
    {
        FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
        FastDriver.OfficeSelectionDlg.Region.FASelectItem(Region);
        Thread.Sleep(3000);
        FastDriver.OfficeSelectionDlg.Display.FASelectItem(Display);
        Thread.Sleep(3000);
        FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction("Office Name", OfficeName, "Sel", TableAction.On);
        FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();

        FastDriver.DialogBottomFrame.ClickDone();

        Reports.TestStep = "Verify the ProductionOffice added.";
        FastDriver.QuickFileEntry.WaitForScreenToLoad();
        bool status = false;
        for (int i = 1; i <= FastDriver.QuickFileEntry.TitleProdOfficeTable.GetRowCount(); i++)
        {
            string ActualProdOfc = FastDriver.QuickFileEntry.TitleProdOfficeTable.PerformTableAction(i, 1, TableAction.GetText).Message;
            if (AutoConfig.SelectedRegionName.Contains(Region))
                status = ActualProdOfc.Contains(OfficeName);
            else
                status = ActualProdOfc.Contains(OfficeName) && ActualProdOfc.Contains(Region);
            if (status)
                break;
        }
        return status;
    }

    catch (Exception ex)
    {
        throw ex;
    }
}

        #endregion
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

