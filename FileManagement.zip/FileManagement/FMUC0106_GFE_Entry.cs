﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using OpenQA.Selenium;
using System.Linq;
using System.Collections.Generic;
using FASTWCFHelpers.FastFileService;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0106 : MasterTestClass
    {

        public FMUC0106()
        {
        }

        #region BAT
        [TestMethod]
        public void FMUC0106_BAT0001()
        {
            Reports.TestDescription = "MF_001,BR_FM10863A,BR_FM10848: GFE Entry.";
            try
            {

                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan.NewLoanAmount = 500;
                #endregion

                #region GUI interaction
                IISLOGIN();

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "GFE Entry.";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();
                Support.AreEqual("500.00", FastDriver.GFEEntryLoanTerms.InitialLoanAmount.FAGetText());
                FastDriver.GFEEntryLoanTerms.LoanTermSet("4");
                Support.AreEqual("4", FastDriver.GFEEntryLoanTerms.LoanTerm.FAGetValue());
                FastDriver.GFEEntryLoanTerms.InitialInterestRateSet("10.00000");
                Support.AreEqual("10.00000", FastDriver.GFEEntryLoanTerms.InitialInterestRate.FAGetValue());
                FastDriver.GFEEntryLoanTerms.InitiaMonthlyAmtSet("5,000.00");
                Support.AreEqual("5,000.00", FastDriver.GFEEntryLoanTerms.InitialMonthlyAmount.FAGetValue());
                FastDriver.GFEEntryLoanTerms.CanInterestRateRiseYes("10.00000", "08-18-2012", "2", "1", "5.00000", "1.00000", "80");
                FastDriver.GFEEntryLoanTerms.VerifyCanInterestRateRiseYes("10.00000", "08-18-2012", "2", "1", "5.00000", "1.00000", "80");

                FastDriver.GFEEntryLoanTerms.LoanBalanceRisedYes("1000.00");
                Support.AreEqual("1000.00", FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FAGetValue());
                FastDriver.GFEEntryLoanTerms.MonthlyAmtOwedYes("8-18-2012", "200.00", "2000.00");
                FastDriver.GFEEntryLoanTerms.PrePaymentPenaltyYes("1500.00");
                Support.AreEqual("1500.00", FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FAGetValue());
                FastDriver.GFEEntryLoanTerms.BalancePaymentYes("2000.00", "2");
                FastDriver.GFEEntryLoanTerms.TotalMonthlyAmountYes("2000.00", "500.00");

                FastDriver.GFEEntryGFE.GFETabClick();
                FastDriver.GFEEntryGFE.GFE1Set("40.00");
                Support.AreEqual("40.00", FastDriver.GFEEntryGFE.GFE1.FAGetValue());
                FastDriver.GFEEntryGFE.GFE2Set("50.00");
                Support.AreEqual("50.00", FastDriver.GFEEntryGFE.GFE2.FAGetValue());
                FastDriver.GFEEntryGFE.GFE7GE8andGFE9Set("100.00", "200.00", "300.00", "400.00");
                FastDriver.GFEEntryGFE.VerifyGFE7GE8andGFE9Set("100.00", "200.00", "300.00", "400.00");
                FastDriver.BottomFrame.Done();

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0002()
        {
            Reports.TestDescription = "AF_001,BR_FM10863B: To add GFE amount from Inspection Repair - Pest...To add and verify GFE amount from Inspection Repair - Pest.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion


                #region GUI interaction                

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add GFE amount from Inspection Repair - Pest.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Playback.Wait(200);
                //FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItemBySendingKeys("Inspection Repair - Pest");

                SelectanItemFromCMB("Inspection Repair - Pest");
                Reports.TestStep = "Enter Gab Details in InspectionRepairDetailDlg";

                SetGabtoInspectionRepairDetailDlg("Inspection/Repair - Pest", "220");
                SetGfe6AmttoInspectionRepairDetailDlg("400.00");

                Reports.TestStep = "To verify that GFE amount is added from Inspection Repair - Pest.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("400.00", FastDriver.GFEEntryGFE.GFE6total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE6Table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("400.00", GFEamount);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0003()
        {



            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add GFE amount from Inspection Repair - Septic.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                // FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItem("Inspection/Repair - Septic");
                SelectanItemFromCMB("Inspection Repair - Septic");
                SetGabtoInspectionRepairDetailDlg("Inspection/Repair - Septic", "225");
                FastDriver.InspectionRepairDetailDlg.PaymentDetails.FAClick();

                SetGfeTypeinPaymentDetailDlg(GFEType: "3");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Inspection/Repair - Septic", true, 50);
                FastDriver.InspectionRepairDetailDlg.SwitchToDialogContentFrame();
                SetGfe6AmttoInspectionRepairDetailDlg("600.00");

                Reports.TestStep = "To verify that GFE amount is added from Inspection Repair - Septic.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("600.00", FastDriver.GFEEntryGFE.GFE3total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("600.00", GFEamount);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0004()
        {
            Reports.TestDescription = "AF_003: To add GFE amount from Inspection Repair - Other.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add GFE amount from Inspection Repair - Other.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItem("Inspection/Repair - Other");
                SelectanItemFromCMB("Inspection Repair - Other");
                SetGabtoInspectionRepairDetailDlg("Inspection/Repair - Other", "226");

                FastDriver.InspectionRepairDetailDlg.PaymentDetails.FAClick();
                SetGfeTypeinPaymentDetailDlg(GFEType: "3");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Inspection/Repair - Other", true, 50);
                FastDriver.InspectionRepairDetailDlg.SwitchToDialogContentFrame();
                SetGfe6AmttoInspectionRepairDetailDlg("800.00");

                Reports.TestStep = "To verify that GFE amount is added from Inspection Repair - Other.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("800.00", FastDriver.GFEEntryGFE.GFE3total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("800.00", GFEamount);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0005()
        {
            Reports.TestDescription = "AF_004,BR_FM10863E: To add GFE amount from Miscellaneous Disbursement.";
            Reports.TestDescription = " To add and verify GFE amount from Miscellaneous Disbursement.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add GFE amount from Miscellaneous Disbursement.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItem("Miscellaneous Disbursement");
                SelectanItemFromCMB("Miscellaneous Disbursement");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Miscellaneous Disbursement", true, 50);
                FastDriver.MiscDisbursementDetailDlg.SwitchToDialogContentFrame();
                FastDriver.MiscDisbursementDetailDlg.bpGABcode.FASetText("227");
                FastDriver.MiscDisbursementDetailDlg.Find.FAClick();
                FastDriver.MiscDisbursementDetailDlg.MiscDescription.FASetText("Miscellaneous Disbursement");

                FastDriver.MiscDisbursementDetailDlg.PaymentDetails.FAClick();
                SetGfeTypeinPaymentDetailDlg(GFEType: "3");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Miscellaneous Disbursement", true, 50);
                FastDriver.MiscDisbursementDetailDlg.SwitchToDialogContentFrame();
                FastDriver.MiscDisbursementDetailDlg.MiscGFEcharge.FASetText("1000.00");
                FastDriver.MiscDisbursementDetailDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "To verify that GFE amount is added from Inspection Repair - Miscellaneous.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>(@"Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("1,000.00", FastDriver.GFEEntryGFE.GFE3total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("1,000.00", GFEamount);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0006()
        {
            Reports.TestDescription = "AF_007,BR_FM10863F_FM10864: To add GFE amount from Survey verify GFE amount ";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add GFE amount from Survey";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                // FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItem("Survey");
                SelectanItemFromCMB("Survey");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Survey", true, 50);
                FastDriver.SurveyDetailDlg.SwitchToDialogContentFrame();
                FastDriver.SurveyDetailDlg.GABcode.FASetText("227");
                FastDriver.SurveyDetailDlg.Find.FAClick(); ;
                FastDriver.SurveyDetailDlg.GFE6Amount.FASetText("1200.00");
                FastDriver.SurveyDetailDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "To verify that GFE amount is added from Inspection Repair - Survey.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>(@"Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("1,200.00", FastDriver.GFEEntryGFE.GFE6total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE6Table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("1,200.00", GFEamount);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0007()
        {
            Reports.TestDescription = "AF_005,BR_FM10865: To add GFE amount from New Loan 1 - Lender. and verify GFE amount";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = " To add GFE amount from New Loan 1 - Lender.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItem("New Loan: 1");
                SelectanItemFromCMB("New Loan 1 - Lender");
                FastDriver.NewLoanDlg.WaitForScreenToLoad();
                //FastDriver.NewLoanDlg.SwitchToDialogContentFrame();
                FastDriver.NewLoanDlg.LoanChargesGFE_3NewLoanDlgChargesGFEAmount.FASetText("1400.00");
                FastDriver.NewLoanDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "To verify that GFE amount is added from Inspection Repair - New Loan 1 - Lender..";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>(@"Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("1,400.00", FastDriver.GFEEntryGFE.GFE3total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("1,400.00", GFEamount);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0008()
        {
            Reports.TestDescription = "AF_006,BR_FM10866_FM10864: To add GFE amount from New Loan 1 - Mortgage broker.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add GFE amount from New Loan 1 - Mortgage broker.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItem("New Loan 1 - Mortgage Broker");
                SelectanItemFromCMB("New Loan 1 - Mortgage Broker");
                FastDriver.NewLoanDlg.WaitForScreenToLoad();
                FastDriver.NewLoanDlg.MortgageGABcode.FASetText("220");
                FastDriver.NewLoanDlg.MortgageFind.FAClick(); ;
                FastDriver.NewLoanDlg.MortgageGFE_3MortgageBrokerChargesAmount.FASetText("1600.00");
                FastDriver.NewLoanDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "To verify that GFE amount is added from Inspection Repair -New Loan 1 - Mortgage Broker";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>(@"Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("1,600.00", FastDriver.GFEEntryGFE.GFE3total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("1,600.00", GFEamount);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0009()
        {
            Reports.TestDescription = "AF_008,AF8_BR_FM10864: To add GFE amount from : Insurance – Fire.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add GFE amount from : Insurance – Fire.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem("Insurance - Fire");
                SelectanItemFromGFE11CMB("Insurance - Fire");
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Fire Insurance", "220", "1,800.00");

                Reports.TestStep = "To verify that GFE amount is added from Insurance – Fire.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<GFEEntry>(@"Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("1,800.00", FastDriver.GFEEntryGFE.GFE11total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE11table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("1,800.00", GFEamount);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0010()
        {
            Reports.TestDescription = "AF_009,AF9_BR_FM10864: To add GFE amount from : Insurance – Flood. and verify GFE amount";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = " To add GFE amount from : Insurance – Flood.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem();
                SelectanItemFromGFE11CMB("Insurance - Flood");
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Flood Insurance", "220", "2000.00");

                Reports.TestStep = "To verify that GFE amount is added from Insurance – Flood.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>(@"Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("2,000.00", FastDriver.GFEEntryGFE.GFE11total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE11table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("2,000.00", GFEamount);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0011()
        {
            Reports.TestDescription = "AF_010,BR_FM10864: To add GFE amount from : Insurance – Wind.  verify GFE amount";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = " To add GFE amount from : Insurance – Wind.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                // FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem("Insurance - Wind");
                SelectanItemFromGFE11CMB("Insurance - Wind");
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Wind Insurance", "220", "2200.00");

                Reports.TestStep = "To verify that GFE amount is added from Insurance – Wind.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>(@"Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("2,200.00", FastDriver.GFEEntryGFE.GFE11total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE11table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("2,200.00", GFEamount);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0012()
        {
            Reports.TestDescription = "AF_011,BR_FM10864: To add GFE amount from : Insurance – Earthquake and verify GFE amount";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = " To add GFE amount from : Insurance – Wind.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem("Insurance - Earthquake");
                SelectanItemFromGFE11CMB("Insurance - Earthquake");
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Earthquake Insurance", "220", "2400.00");

                Reports.TestStep = "To verify that GFE amount is added from Insurance – Earthquake.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>(@"Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("2,400.00", FastDriver.GFEEntryGFE.GFE11total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE11table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("2,400.00", GFEamount);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0013()
        {
            Reports.TestDescription = "AF_012,BR_FM10864: To add GFE amount from : Insurance – Other and verify GFE amount";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = " To add GFE amount from : Insurance – Other.";


                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                SelectanItemFromGFE11CMB("Insurance - Other");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Other Insurance", true, 500);
                FastDriver.InsuranceSummaryDlg.SwitchToDialogContentFrame();
                FastDriver.InsuranceSummaryDlg.SummaryNew.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Other Insurance", true, 50);
                FastDriver.InsuranceOtherDlg.SwitchToDialogContentFrame();
                FastDriver.InsuranceOtherDlg.OtherGABcode.FASetText("220");
                FastDriver.InsuranceOtherDlg.OtherFind.FAClick(); ;
                FastDriver.InsuranceOtherDlg.OtherInsurChargeGfeAmount.FASetText("2600.00");
                FastDriver.InsuranceOtherDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "To verify that GFE amount is added from Insurance – Other.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<GFEEntry>(@"Home>Order Entry>GFE Entry");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("2,600.00", FastDriver.GFEEntryGFE.GFE11total.FAGetText());
                string GFEamount = FastDriver.GFEEntryGFE.GFE11table.PerformTableAction(1, 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("2,600.00", GFEamount);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_BAT0014()
        {
            Reports.TestDescription = "AF_001_Val: To verify GFE amount from Inspection Repair - Pest.";
            Reports.StatusUpdate("AF_001_Val: GFE Entry : Functionality has covered in FMUC0106_BAT0002", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0015()
        {
            Reports.TestDescription = "AF_002_Val: To verify GFE amount from Inspection Repair - Septic.";
            Reports.StatusUpdate("AF_002_Val: GFE Entry : Functionality has covered in FMUC0106_BAT0003", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0016()
        {
            Reports.TestDescription = "AF_003_Val: To verify GFE amount from Inspection Repair - Other.";
            Reports.StatusUpdate("AF_003_Val: GFE Entry : Functionality has covered in FMUC0106_BAT0004", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0017()
        {
            Reports.TestDescription = "AF_004_Val: To verify GFE amount from Miscellaneous Disbursement.";
            Reports.StatusUpdate("AF_004_Val: GFE Entry : Functionality has covered in FMUC0106_BAT0005", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0018()
        {
            Reports.TestDescription = "AF_007_Val: To verify GFE amount from Survey.";
            Reports.StatusUpdate("AF_007_Val: GFE Entry : Functionality has covered in FMUC0106_BAT0006", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0019()
        {
            Reports.TestDescription = "AF_005_Val: To verify GFE amount from New Loan 1 - Lender.";
            Reports.StatusUpdate("AF_005_Val: GFE Entry : Functionality has covered in FMUC0106_BAT0007", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0020()
        {
            Reports.TestDescription = "AF_006_Val: To verify GFE amount from New Loan 1 - Mortgage broker.";
            Reports.StatusUpdate("AF_006_Val: Functionality has covered in FMUC0106_BAT0008", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0021()
        {
            Reports.TestDescription = "AF_008_Val: To verify GFE amount from : Insurance – Fire.";
            Reports.StatusUpdate("AF_008_Val: Functionality has covered in FMUC0106_BAT0009", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0022()
        {
            Reports.TestDescription = "AF_009_Val: To verify GFE amount from : Insurance – Flood.";
            Reports.StatusUpdate("AF_009_Val: Functionality has covered in FMUC0106_BAT0010", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0023()
        {
            Reports.TestDescription = "AF_010_Val: To verify GFE amount from : Insurance – Wind.";
            Reports.StatusUpdate("AF_010_Val: Functionality has covered in FMUC0106_BAT0011", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0024()
        {
            Reports.TestDescription = "AF_011_Val: To verify GFE amount from : Insurance – Earthquake.";
            Reports.StatusUpdate("AF_011_Val: Functionality has covered in FMUC0106_BAT0012", true);
        }

        [TestMethod]
        public void FMUC0106_BAT0025()
        {
            Reports.TestDescription = "AF_012_Val: To verify GFE amount from : Insurance – Other.";
            Reports.StatusUpdate("AF_012_Val: Functionality has covered in FMUC0106_BAT0012", true);
        }


        #endregion

        #region REG

        [TestMethod]
        public void FMUC0106_REG0001()
        {
            Reports.TestDescription = "BR_FM10863A: GFE Entry.";
            Reports.StatusUpdate("BR_FM10863A: GFE Entry : Functionality has covered in FMUC0106_BAT0001", true);
        }

        [TestMethod]
        public void FMUC0106_REG0002()
        {
            Reports.TestDescription = "BR_FM10863B: To add and verify GFE amount from Inspection Repair - Pest.";
            Reports.StatusUpdate("BR_FM10863B: GFE Entry : Functionality has covered in FMUC0106_BAT0002", true);
        }

        [TestMethod]
        public void FMUC0106_REG0003()
        {
            Reports.TestDescription = "BR_FM10863C: To add and verify GFE amount from Inspection Repair - Septic.";
            Reports.StatusUpdate("BR_FM10863C: GFE Entry : Functionality has covered in FMUC0106_BAT0003", true);
        }

        [TestMethod]
        public void FMUC0106_REG0004()
        {
            Reports.TestDescription = "BR_FM10863D: To add and verify GFE amount from Inspection Repair - Other.";
            Reports.StatusUpdate("BR_FM10863D: GFE Entry : Functionality has covered in FMUC0106_BAT0004", true);
        }

        [TestMethod]
        public void FMUC0106_REG0005()
        {
            Reports.TestDescription = "BR_FM10863E: To add and verify GFE amount from Miscellaneous Disbursement.";
            Reports.StatusUpdate("BR_FM10863E: GFE Entry : Functionality has covered in FMUC0106_BAT0005", true);
        }

        [TestMethod]
        public void FMUC0106_REG0006()
        {
            Reports.TestDescription = "BR_FM10863F_FM10864: To add and verify GFE amount from Survey.";
            Reports.StatusUpdate("BR_FM10863F_FM10864: GFE Entry : Functionality has covered in FMUC0106_BAT0006", true);
        }

        [TestMethod]
        public void FMUC0106_REG0007()
        {
            Reports.TestDescription = "BR_FM10865: To add and verify GFE amount from New Loan 1 - Lender.";
            Reports.StatusUpdate("BR_FM10865: GFE Entry : Functionality has covered in FMUC0106_BAT0007", true);
        }

        [TestMethod]
        public void FMUC0106_REG0008()
        {
            Reports.TestDescription = "BR_FM10866_FM10864: To add and verify GFE amount from New Loan 1 - Mortgage broker.";
            Reports.StatusUpdate("BR_FM10866_FM10864: Functionality has covered in FMUC0106_BAT0008", true);
        }

        [TestMethod]
        public void FMUC0106_REG0009()
        {
            Reports.TestDescription = "AF8_BR_FM10864: To add and verify GFE amount from : Insurance – Fire.";
            Reports.StatusUpdate("BR_FM10866_FM10864: Functionality has covered in FMUC0106_BAT0009", true);
        }

        [TestMethod]
        public void FMUC0106_REG0010()
        {
            Reports.TestDescription = "AF9_BR_FM10864: To add and verify GFE amount from : Insurance – Flood.";
            Reports.StatusUpdate("BR_FM10866_FM10864: Functionality has covered in FMUC0106_BAT0010", true);
        }

        [TestMethod]
        public void FMUC0106_REG0011()
        {
            Reports.TestDescription = "AF10_BR_FM10864: To add and verify GFE amount from : Insurance – Wind.";
            Reports.StatusUpdate("BR_FM10866_FM10864: Functionality has covered in FMUC0106_BAT0011", true);
        }

        [TestMethod]
        public void FMUC0106_REG0012()
        {
            Reports.TestDescription = "AF11_BR_FM10864: To add and verify GFE amount from : Insurance – Earthquake.";
            Reports.StatusUpdate("BR_FM10866_FM10864: Functionality has covered in FMUC0106_BAT0012", true);
        }

        [TestMethod]
        public void FMUC0106_REG0013()
        {
            Reports.TestDescription = "AF12_BR_FM10864: To add and verify GFE amount from : Insurance – Other.";
            Reports.StatusUpdate("AF12_BR_FM10864:Functionality has covered in FMUC0106_BAT0013", true);
        }

        [TestMethod]
        public void FMUC0106_REG0014()
        {
            Reports.TestDescription = "BR_FM10864: Calculate and Display GFE Total.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Navigate to GFE Entry  ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add GFE amount from Inspection Repair - Pest.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Playback.Wait(200);
                //FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItem("Inspection Repair - Septic",true);
                SelectanItemFromCMB("Inspection Repair - Pest");
                SetGabtoInspectionRepairDetailDlg("Inspection/Repair - Pest", "220");
                FastDriver.InspectionRepairDetailDlg.PaymentDetails.FAClick();
                SetGfeTypeinPaymentDetailDlg(GFEType: "3");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Inspection/Repair - Pest", true, 100);
                FastDriver.InspectionRepairDetailDlg.SwitchToDialogContentFrame();
                SetGfe6AmttoInspectionRepairDetailDlg("100.00");

                Reports.TestStep = "To add GFE amount from Inspection Repair - Septic.";
                FastDriver.GFEEntry.WaitForScreenToLoad();
                SelectanItemFromCMB("Inspection Repair - Septic");
                SetGabtoInspectionRepairDetailDlg("Inspection/Repair - Septic", "220");
                FastDriver.InspectionRepairDetailDlg.PaymentDetails.FAClick();
                SetGfeTypeinPaymentDetailDlg(GFEType: "3");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Inspection/Repair - Septic", true, 500);
                FastDriver.InspectionRepairDetailDlg.SwitchToDialogContentFrame();
                SetGfe6AmttoInspectionRepairDetailDlg("100.00");

                Reports.TestStep = "To add GFE amount from Inspection Repair - Other.";
                FastDriver.GFEEntry.WaitForScreenToLoad();
                SelectanItemFromCMB("Inspection Repair - Other");
                SetGabtoInspectionRepairDetailDlg("Inspection/Repair - Other", "220");
                FastDriver.InspectionRepairDetailDlg.PaymentDetails.FAClick();
                SetGfeTypeinPaymentDetailDlg(GFEType: "6");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Inspection/Repair - Other", true, 100);
                FastDriver.InspectionRepairDetailDlg.SwitchToDialogContentFrame();
                SetGfe6AmttoInspectionRepairDetailDlg("300.00");



                Reports.TestStep = "To add GFE amount from Inspection Repair - Other.";
                FastDriver.GFEEntry.WaitForScreenToLoad();
                SelectanItemFromCMB("Miscellaneous Disbursement");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Miscellaneous Disbursement", true, 50);
                FastDriver.MiscDisbursementDetailDlg.SwitchToDialogContentFrame();
                FastDriver.MiscDisbursementDetailDlg.bpGABcode.FASetText("227");
                FastDriver.MiscDisbursementDetailDlg.Find.FAClick();
                FastDriver.MiscDisbursementDetailDlg.MiscDescription.FASetText("Miscellaneous Disbursement");
                FastDriver.MiscDisbursementDetailDlg.PaymentDetails.FAClick();
                SetGfeTypeinPaymentDetailDlg(GFEType: "6");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Miscellaneous Disbursement", true, 50);
                FastDriver.MiscDisbursementDetailDlg.SwitchToDialogContentFrame();
                FastDriver.MiscDisbursementDetailDlg.MiscGFEcharge.FASetText("400.00");
                FastDriver.MiscDisbursementDetailDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "To add GFE amount from : Insurance – Fire.";
                FastDriver.GFEEntry.WaitForScreenToLoad();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem("Insurance - Fire");
                SelectanItemFromGFE11CMB("Insurance - Fire");
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Fire Insurance", "220", "1800.00");

                Reports.TestStep = " To add GFE amount from : Insurance – Flood.";
                FastDriver.GFEEntry.WaitForScreenToLoad();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem();
                SelectanItemFromGFE11CMB("Insurance - Flood");
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Flood Insurance", "220", "2000.00");

                FastDriver.GFEEntry.WaitForScreenToLoad();
                Reports.TestStep = "To verify the GFE3total.";
                Support.AreEqual("200.00", FastDriver.GFEEntryGFE.GFE3total.FAGetText());

                Reports.TestStep = "To verify the GFE6total.";
                Support.AreEqual("700.00", FastDriver.GFEEntryGFE.GFE6total.FAGetText());

                Reports.TestStep = "To verify the GFE11total.";
                Support.AreEqual("3,800.00", FastDriver.GFEEntryGFE.GFE11total.FAGetText());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0015()
        {
            Reports.TestDescription = "BR_FM10848: Enable fields associated with 'Yes' option.";
            Reports.StatusUpdate("BR_FM10848:Functionality has covered in FMUC0106_BAT0001", true);
        }

        [TestMethod]
        public void FMUC0106_REG0016()
        {
            Reports.TestDescription = "BR_FM10849: Remove details and Disable fields associated with 'Yes' option.";

            try
            {

                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan.NewLoanAmount = 500;
                #endregion

                #region GUI interaction
                IISLOGIN();
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "GFE Entry.";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();
                Support.AreEqual("500.00", FastDriver.GFEEntryLoanTerms.InitialLoanAmount.FAGetText());
                FastDriver.GFEEntryLoanTerms.LoanTermSet("4");
                Support.AreEqual("4", FastDriver.GFEEntryLoanTerms.LoanTerm.FAGetValue());
                FastDriver.GFEEntryLoanTerms.InitialInterestRateSet("10.00000");
                Support.AreEqual("10.00000", FastDriver.GFEEntryLoanTerms.InitialInterestRate.FAGetValue());
                FastDriver.GFEEntryLoanTerms.InitiaMonthlyAmtSet("5,000.00");
                Support.AreEqual("5,000.00", FastDriver.GFEEntryLoanTerms.InitialMonthlyAmount.FAGetValue());
                FastDriver.GFEEntryLoanTerms.CanInterestRateRiseYes("10.00000", "08-18-2012", "2", "1", "5.00000", "1.00000", "80");
                FastDriver.GFEEntryLoanTerms.VerifyCanInterestRateRiseYes("10.00000", "08-18-2012", "2", "1", "5.00000", "1.00000", "80");

                FastDriver.GFEEntryLoanTerms.LoanBalanceRisedYes("1000.00");
                Support.AreEqual("1000.00", FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FAGetValue());
                FastDriver.GFEEntryLoanTerms.MonthlyAmtOwedYes("8-18-2012", "200.00", "2000.00");
                FastDriver.GFEEntryLoanTerms.PrePaymentPenaltyYes("1500.00");
                Support.AreEqual("1500.00", FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FAGetValue());
                FastDriver.GFEEntryLoanTerms.BalancePaymentYes("2000.00", "2");
                FastDriver.GFEEntryLoanTerms.TotalMonthlyAmountYes("2000.00", "500.00");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Remove details and Disable fields associated with 'Yes' option.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryLoanTerms.WaitForScreenToLoad();
                bool IntRestControlEnabledStatus = FastDriver.GFEEntryLoanTerms.CanInterestRateRiseNO;
                Support.AreEqual("False", IntRestControlEnabledStatus.ToString(), "Controls enabled status " + IntRestControlEnabledStatus.ToString());

                bool LoanBalanceControlEnabledStatus = FastDriver.GFEEntryLoanTerms.LoanBalanceRiseNO;
                Support.AreEqual("False", LoanBalanceControlEnabledStatus.ToString(), "Loan Balance Controls enabled status " + LoanBalanceControlEnabledStatus.ToString());

                bool MonthlyAmtOwedControlEnabledStatus = FastDriver.GFEEntryLoanTerms.CanMonthlyAmtOwedNO;
                Support.AreEqual("False", LoanBalanceControlEnabledStatus.ToString(), "Monthly Amt Owed Controls enabled status " + MonthlyAmtOwedControlEnabledStatus.ToString());

                bool PrePaymentPenaltyControlEnabledStatus = FastDriver.GFEEntryLoanTerms.PrePaymentPenaltyNO;
                Support.AreEqual("False", PrePaymentPenaltyControlEnabledStatus.ToString(), "Pre Payment Penalty Controls enabled status " + PrePaymentPenaltyControlEnabledStatus.ToString());

                bool BaloonPaymentControlEnabledStatus = FastDriver.GFEEntryLoanTerms.BaloonPaymentNO;
                Support.AreEqual("False", BaloonPaymentControlEnabledStatus.ToString(), "Baloon Payment Controls enabled status " + BaloonPaymentControlEnabledStatus.ToString());

                bool TotalMonthlyAmountControlEnabledStatus = FastDriver.GFEEntryLoanTerms.TotalMonthlyAmountNO;
                Support.AreEqual("False", TotalMonthlyAmountControlEnabledStatus.ToString(), "Total Monthly Amount Controls enabled status " + TotalMonthlyAmountControlEnabledStatus.ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0017()
        {
            Reports.TestDescription = "BR_FM10850,BR_FM10851: Select items for Monthly Escrow Payment.,Remove items for Monthly Escrow Payment.";
            try
            {

                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan.NewLoanAmount = 500;
                #endregion

                #region GUI interaction

                IISLOGIN();
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Select items for Monthly Escrow Payment.";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "Enter Text into Description4";
                FastDriver.GFEEntryLoanTerms.EscrowAccountMonthlyAmountYes.FAClick();
                FastDriver.GFEEntryLoanTerms.Description4.FASetText("Insurance");

                Reports.TestStep = "Verify PaymentItem4 CHK box is checked";
                Support.AreEqual("true", FastDriver.GFEEntryLoanTerms.PaymentItem4.GetAttribute("Checked").ToString());
                string c = FastDriver.GFEEntryLoanTerms.PaymentItem4.IsSelected().ToString();
                Reports.TestStep = "Clear Text in Description4";
                FastDriver.GFEEntryLoanTerms.Description4.FASetText(" ");
                Reports.TestStep = "Verify PaymentItem4 CHK box is Unchecked";
                Support.AreEqual("False", FastDriver.GFEEntryLoanTerms.PaymentItem4.IsSelected().ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Obsolete]
        public void FMUC0106_REG0018()
        {
            Reports.TestDescription = "BR_FM10851: Select items for Monthly Escrow Payment. ";
            Reports.StatusUpdate("BR_FM10851:Functionality has covered in FMUC0106_REG0018", true);
        }

        [TestMethod]
        public void FMUC0106_REG0019()
        {
            Reports.TestDescription = "BR_FM10850,BR_FM10851: Select items for Monthly Escrow Payment.,Remove items for Monthly Escrow Payment.";
            try
            {


                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan.NewLoanAmount = 500;
                #endregion

                IISLOGIN();
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Verify Default Monthly Escrow Payment.Items Property taxes,Homeowner's insurance ,Flood insurance ";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                FastDriver.GFEEntryLoanTerms.EscrowAccountMonthlyAmountYes.FAClick();

                FastDriver.GFEEntryLoanTerms.Propertytaxes.FASetCheckbox(true);
                Support.AreEqual("True", FastDriver.GFEEntryLoanTerms.Propertytaxes.IsSelected().ToString());

                FastDriver.GFEEntryLoanTerms.Propertytaxes.FASetCheckbox(false);
                Support.AreEqual("False", FastDriver.GFEEntryLoanTerms.Propertytaxes.IsSelected().ToString());

                FastDriver.GFEEntryLoanTerms.Homeownersinsurance.FASetCheckbox(true);
                Support.AreEqual("True", FastDriver.GFEEntryLoanTerms.Homeownersinsurance.IsSelected().ToString());

                FastDriver.GFEEntryLoanTerms.Homeownersinsurance.FASetCheckbox(false);
                Support.AreEqual("False", FastDriver.GFEEntryLoanTerms.Homeownersinsurance.IsSelected().ToString());

                FastDriver.GFEEntryLoanTerms.FloodInsurance.FASetCheckbox(true);
                Support.AreEqual("True", FastDriver.GFEEntryLoanTerms.FloodInsurance.IsSelected().ToString());

                FastDriver.GFEEntryLoanTerms.FloodInsurance.FASetCheckbox(false);
                Support.AreEqual("False", FastDriver.GFEEntryLoanTerms.FloodInsurance.IsSelected().ToString());



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0020()
        {
            Reports.TestDescription = "BR_FM10854: Display of GFE Entry node on NAV tree.";
            Reports.StatusUpdate("FM10854 functionality not N/A ", true);
        }

        [TestMethod]
        public void FMUC0106_REG0021()
        {
            Reports.TestDescription = "BR_FM10855: Do not display GFE Entry Node for Sub-escrow files.";
            try
            {

                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "SEO";
                #endregion

                #region GUI Intreaction
                IISLOGIN();
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "To verify GFE Entry does not exists in the node.";
                FastDriver.LeftFrame.SwitchToLeftNavigationPane();
                Support.AreEqual("0", FastDriver.LeftNavigation.LinkAvailability("GFE Entry").ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0022()
        {

            Reports.TestDescription = "BR_FM12604_FM10858_FM10859: Select Credit, Charge or Zero for Origination Charge.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI intreaction

                Reports.TestStep = "GFE Entry.";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");

                Reports.TestStep = "Click on GFE Tab";
                FastDriver.GFEEntryGFE.GFETabClick();

                Reports.TestStep = "Select Credit for Origination Charge";
                FastDriver.GFEEntryGFE.OriginationCredit.FAClick();
                FastDriver.GFEEntryGFE.GFE1.FASetText("54.00");
                FastDriver.GFEEntryGFE.GFE2.FAClick();

                Reports.TestStep = "validate the adjusted origination charge.";
                Support.AreEqual("-54.00", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText().ToString());

                Reports.TestStep = "Select Charge for Origination Charge";
                FastDriver.GFEEntryGFE.OriginationCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE1.FASetText("54.00");
                FastDriver.GFEEntryGFE.GFE2.FAClick();

                Reports.TestStep = "validate the adjusted origination charge.";
                Support.AreEqual("54.00", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText().ToString());

                Reports.TestStep = "Select Zero for Origination Charge";
                FastDriver.GFEEntryGFE.OriginationZero.FAClick();

                Reports.TestStep = "validate the adjusted origination charge.";
                Support.AreEqual("0.00", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText().ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0106_REG0023()
        {

            Reports.TestDescription = "BR_FM10857_FM10858_FM10859: Select Credit, Charge or Zero Points.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI intreaction

                Reports.TestStep = "GFE Entry.";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");

                Reports.TestStep = "Click on GFE Tab";
                FastDriver.GFEEntryGFE.GFETabClick();

                Reports.TestStep = "Select Credit for points";
                FastDriver.GFEEntryGFE.PointsCredit.FAClick();
                FastDriver.GFEEntryGFE.GFE2.FASetText("54.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Reports.TestStep = "validate the adjusted points";
                Support.AreEqual("-54.00", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText().ToString());

                Reports.TestStep = "Select Charge for points";
                FastDriver.GFEEntryGFE.PointsCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE2.FASetText("54.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Reports.TestStep = "validate the adjusted points";
                Support.AreEqual("54.00", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText().ToString());

                Reports.TestStep = "Select Zero for points";
                FastDriver.GFEEntryGFE.PointsZero.FAClick();

                Reports.TestStep = "validate the adjusted points";
                Support.AreEqual("0.00", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText().ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0024()
        {

            Reports.TestDescription = "BR_FM10858,BR_FM10859: Negative Amount for Credit GFE10. and  Default for Zero Points.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                Reports.TestStep = "Negative Amount for Credit GFE10.";
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");

                Reports.TestStep = "Click on GFE Tab";
                FastDriver.GFEEntryGFE.GFETabClick();
                FastDriver.GFEEntryGFE.InterestCredit.FAClick();

                FastDriver.GFEEntryGFE.GFE10.FASetText("54.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Reports.TestStep = "validate the adjusted origination charge.";
                Support.AreEqual("-54.00", FastDriver.GFEEntryGFE.GFE10.FAGetValue().ToString());

                Reports.TestStep = "Default for Zero Points.";
                FastDriver.GFEEntryGFE.InterestZero.FAClick();
                Support.AreEqual("0.00", FastDriver.GFEEntryGFE.GFE10.FAGetValue().ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Obsolete]
        public void FMUC0106_REG0025()
        {
            Reports.TestDescription = "BR_FM10859: Default for Zero Points.";
            Reports.StatusUpdate("Functionality has covered in FMUC0106_REG0024", true);
        }

        [TestMethod]
        public void FMUC0106_REG0026()
        {


            Reports.TestDescription = "BR_FM10860: Calculate Adjusted Origination Charges (GFE A).";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");

                Reports.TestStep = "Click on GFE Tab";
                FastDriver.GFEEntryGFE.GFETabClick();

                Reports.TestStep = "Calculate Adjusted Origination Charges (GFE A).";
                FastDriver.GFEEntryGFE.OriginationCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE1.FASetText("60.00");
                FastDriver.GFEEntryGFE.GFE2.FASetText("80.00");
                FastDriver.GFEEntryGFE.GFE2.FASetText(FAKeys.Tab);
                Support.IsTrue(FastDriver.GFEEntryGFE.VerifyGFEA, "Adjusted Origination Charges are not equal");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0027()
        {

            Reports.TestDescription = "BR_FM10861: Select Charge Process Types for GFE 3, GFE 6.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion


                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");
                Reports.TestStep = "Select Charge Process Types for GFE #3, GFE #6.";
                FastDriver.GFEEntryGFE.GFETabClick();
                string ProcessType = FastDriver.GFEEntryGFE.GFE3ChgProcessType.FAGetText().ToString();

                Reports.StatusUpdate("Verify:Inspection Repair - Pest", ProcessType.Contains("Inspection Repair - Pest"));
                Reports.StatusUpdate("Verify:Inspection Repair - Septic", ProcessType.Contains("Inspection Repair - Septic"));
                Reports.StatusUpdate("Verify:Inspection Repair - Other", ProcessType.Contains("Inspection Repair - Other"));
                Reports.StatusUpdate("Verify:Miscellaneous Disbursement", ProcessType.Contains("Miscellaneous Disbursement"));
                Reports.StatusUpdate("Verify:New Loan 1 - Lender", ProcessType.Contains("New Loan 1 - Lender"));
                Reports.StatusUpdate("Verify:New Loan 1 - Mortgage Broker", ProcessType.Contains("New Loan 1 - Mortgage Broker"));
                Reports.StatusUpdate("Verify:Survey", ProcessType.Contains("Survey"));

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0106_REG0028()
        {

            Reports.TestDescription = "BR_FM10862: Select Charge Process Types for GFE 11.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");

                Reports.TestStep = "Select Charge Process Types for GFE #11.";

                FastDriver.GFEEntryGFE.GFETabClick();

                string ProcessType = FastDriver.GFEEntryGFE.GFE11ChgProcessType.FAGetText().ToString();

                Reports.StatusUpdate("Verify:Insurance - Fire", ProcessType.Contains("Insurance - Fire"));
                Reports.StatusUpdate("Verify:Insurance - Flood", ProcessType.Contains("Insurance - Flood"));
                Reports.StatusUpdate("Verify:Insurance - Wind", ProcessType.Contains("Insurance - Wind"));
                Reports.StatusUpdate("Verify:Insurance - Earthquake", ProcessType.Contains("Insurance - Earthquake"));
                Reports.StatusUpdate("Verify:Insurance - Other", ProcessType.Contains("Insurance - Other"));

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0106_REG0029()
        {

            Reports.TestDescription = "BR_FM10867: Display additional text for Total Monthly Amount field.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction
                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");

                Reports.TestStep = "Display additional text for Total Monthly Amount field.";
                FastDriver.GFEEntryLoanTerms.EscrowAccountMonthlyAmountYes.FAClick();

                FastDriver.GFEEntryLoanTerms.AdditionalMonthlyEscrowAmount.FASetText("*200");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("* Paid by or through draws from the principal limit", FastDriver.GFEEntryLoanTerms.Additionaltext.FAGetText());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0030()
        {

            Reports.TestDescription = "BT_Reset: Reset.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();
                FastDriver.GFEEntryLoanTerms.LoanTermSet("4");
                FastDriver.GFEEntryLoanTerms.InitialInterestRateSet("10.00000");
                FastDriver.GFEEntryLoanTerms.InitiaMonthlyAmtSet("5,000.00");

                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnReset.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryLoanTerms.SwitchToContentFrame();

                Reports.TestStep = "verify value as after Reset.";
                Support.AreEqual("", FastDriver.GFEEntryLoanTerms.LoanTerm.FAGetValue());
                Support.AreEqual("", FastDriver.GFEEntryLoanTerms.InitialInterestRate.FAGetValue());
                Support.AreEqual("", FastDriver.GFEEntryLoanTerms.InitialMonthlyAmount.FAGetValue());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0031()
        {

            Reports.TestDescription = "BT_AutoSave: AutoSave.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();


                FastDriver.GFEEntryLoanTerms.LoanTermSet("4");
                FastDriver.GFEEntryLoanTerms.InitialInterestRateSet("10.00000");
                FastDriver.GFEEntryLoanTerms.InitiaMonthlyAmtSet("5,000.00");

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "verify values after auto save.";
                Support.AreEqual("4", FastDriver.GFEEntryLoanTerms.LoanTerm.FAGetValue());
                Support.AreEqual("10.00000", FastDriver.GFEEntryLoanTerms.InitialInterestRate.FAGetValue());
                Support.AreEqual("5,000.00", FastDriver.GFEEntryLoanTerms.InitialMonthlyAmount.FAGetValue());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0032()
        {

            Reports.TestDescription = "FD_1: field validation for Loan Term, Initial Interest Rate, initial monthly amount owed for principal.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction


                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation for Loan Term, Initial Interest Rate, initial monthly amount owed for principal for lower range.";
                FastDriver.GFEEntryLoanTerms.LoanTermSet("12");
                FastDriver.GFEEntryLoanTerms.InitialInterestRateSet("111.2222");
                FastDriver.GFEEntryLoanTerms.InitiaMonthlyAmtSet("1234567891.2");
                Support.AreEqual("12", FastDriver.GFEEntryLoanTerms.LoanTerm.FAGetValue());
                Support.AreEqual("111.22220", FastDriver.GFEEntryLoanTerms.InitialInterestRate.FAGetValue());
                Support.AreEqual("1,234,567,891.20", FastDriver.GFEEntryLoanTerms.InitialMonthlyAmount.FAGetValue());

                Reports.TestStep = "field validation for Loan Term, Initial Interest Rate, initial monthly amount owed for principal for exact no of chars.";
                FastDriver.GFEEntryLoanTerms.LoanTermSet("123");
                FastDriver.GFEEntryLoanTerms.InitialInterestRateSet("1111.2222200000001");
                FastDriver.GFEEntryLoanTerms.InitiaMonthlyAmtSet("12345678912.22");
                Support.AreEqual("123", FastDriver.GFEEntryLoanTerms.LoanTerm.FAGetValue());
                Support.AreEqual("1111.22222", FastDriver.GFEEntryLoanTerms.InitialInterestRate.FAGetValue());
                Support.AreEqual("12,345,678,912.22", FastDriver.GFEEntryLoanTerms.InitialMonthlyAmount.FAGetValue());

                Reports.TestStep = "field validation for Loan Term, Initial Interest Rate, initial monthly amount owed for principal for high range.";
                FastDriver.GFEEntryLoanTerms.LoanTermSet("1234");
                FastDriver.GFEEntryLoanTerms.InitialInterestRateSet("11111.222222");
                FastDriver.GFEEntryLoanTerms.InitiaMonthlyAmtSet("123456789123.222");
                Support.AreEqual("", FastDriver.GFEEntryLoanTerms.LoanTerm.FAGetValue());
                Support.AreEqual("?", FastDriver.GFEEntryLoanTerms.InitialInterestRate.FAGetValue());
                Support.AreEqual("", FastDriver.GFEEntryLoanTerms.InitialMonthlyAmount.FAGetValue());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }

        [TestMethod]
        public void FMUC0106_REG0033()
        {

            Reports.TestDescription = "FD_2: field validation for Principal,Interest,Mortgage insurance.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation for Principal,Interest,Mortgage insurance.";
                FastDriver.GFEEntryLoanTerms.InitiaMonthlyAmtSet("12345678912.22");
                Support.AreEqual("12,345,678,912.22", FastDriver.GFEEntryLoanTerms.InitialMonthlyAmount.FAGetValue());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0106_REG0034()
        {
            try
            {

                Reports.TestDescription = "FD_3: field validation for labels in Loan Terms tab.";

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation for labels in Loan Terms tab.";

                string labelvalue = FastDriver.GFEEntryLoanTerms.LoanTermsTable.FAGetText();
                Support.AreEqual("True", labelvalue.Contains("Can loan balance rise?").ToString());
                Support.AreEqual("True", labelvalue.Contains("Can monthly amount owed for principal,").ToString());
                Support.AreEqual("True", labelvalue.Contains("Does loan have a prepayment penalty?").ToString());
                Support.AreEqual("True", labelvalue.Contains("Does loan have a balloon payment?").ToString());
                Support.AreEqual("True", labelvalue.Contains("Total monthly amount owed including").ToString());
                Support.AreEqual("True", labelvalue.Contains("No monthly escrow payment for items,").ToString());


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0035()
        {

            Reports.TestDescription = "FD_4A: field validation for low range.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation for low range.";

                FastDriver.GFEEntryLoanTerms.RateIncrementRiseYes.FAClick();

                FastDriver.GFEEntryLoanTerms.MaxInterestRate.FASetText("111.2222");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FASetText("12345678912");
                FastDriver.GFEEntryLoanTerms.InterestRateAfterPeriod.FASetText("12345678912");
                FastDriver.GFEEntryLoanTerms.ChangedInterestRate.FASetText("123.1111");
                FastDriver.GFEEntryLoanTerms.LowerInterestRate.FASetText("125.4444");
                FastDriver.GFEEntryLoanTerms.HigherInterestRate.FASetText("145.5555");
                FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FAClick();


                Support.AreEqual("111.22220", FastDriver.GFEEntryLoanTerms.MaxInterestRate.FAGetValue().ToString());
                Support.AreEqual("12345678912", FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAGetValue());
                Support.AreEqual("12345678912", FastDriver.GFEEntryLoanTerms.InterestRateAfterPeriod.FAGetValue());
                Support.AreEqual("123.11110", FastDriver.GFEEntryLoanTerms.ChangedInterestRate.FAGetValue());
                Support.AreEqual("125.44440", FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAGetValue());
                Support.AreEqual("145.55550", FastDriver.GFEEntryLoanTerms.HigherInterestRate.FAGetValue());


                FastDriver.GFEEntryLoanTerms.LoanBalanceRiseYes.FAClick();
                FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FASetText("1234567891.1");
                FastDriver.GFEEntryLoanTerms.MaxInterestRate.FAClick();
                Support.AreEqual("1,234,567,891.10", FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FAGetValue());

                FastDriver.GFEEntryLoanTerms.MonthlyAmountRiseYes.FAClick();
                FastDriver.GFEEntryLoanTerms.MonthlyIncrementAmt.FASetText("1234567891.1");
                FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FASetText("1234567899.2");
                FastDriver.GFEEntryLoanTerms.MaxInterestRate.FAClick();

                Support.AreEqual("1,234,567,891.10", FastDriver.GFEEntryLoanTerms.MonthlyIncrementAmt.FAGetValue());
                Support.AreEqual("1,234,567,899.20", FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FAGetValue());

                FastDriver.GFEEntryLoanTerms.PrePaymentYes.FAClick();
                FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FASetText("1234567891.1");
                FastDriver.GFEEntryLoanTerms.MaxInterestRate.FAClick();
                Support.AreEqual("1,234,567,891.10", FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FAGetValue());

                FastDriver.GFEEntryLoanTerms.BalanceloonPaymentYes.FAClick();
                FastDriver.GFEEntryLoanTerms.BalanceloonPaymentMaxAmount.FASetText("1234567891.1");
                FastDriver.GFEEntryLoanTerms.BalancelonPaymentDuePeriod.FASetText("12");
                FastDriver.GFEEntryLoanTerms.MaxInterestRate.FAClick();
                Support.AreEqual("1,234,567,891.10", FastDriver.GFEEntryLoanTerms.BalanceloonPaymentMaxAmount.FAGetValue());
                Support.AreEqual("12", FastDriver.GFEEntryLoanTerms.BalancelonPaymentDuePeriod.FAGetValue());

                FastDriver.GFEEntryLoanTerms.EscrowAccountMonthlyAmountYes.FAClick();
                FastDriver.GFEEntryLoanTerms.AdditionalMonthlyEscrowAmount.FASetText("1234567891.1");
                FastDriver.GFEEntryLoanTerms.AdditionalTotalMonthlyAmt.FASetText("1234567898.7");
                FastDriver.GFEEntryLoanTerms.MaxInterestRate.FAClick();
                Support.AreEqual("1,234,567,891.10", FastDriver.GFEEntryLoanTerms.AdditionalMonthlyEscrowAmount.FAGetValue());
                Support.AreEqual("1,234,567,898.70", FastDriver.GFEEntryLoanTerms.AdditionalTotalMonthlyAmt.FAGetValue());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            // 
        }

        [TestMethod]
        public void FMUC0106_REG0036()
        {


            Reports.TestDescription = "FD_4B: field validation for exact field length.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                FastDriver.GFEEntryLoanTerms.RateIncrementRiseYes.FAClick();

                FastDriver.GFEEntryLoanTerms.MaxInterestRate.FASetText("1111.22222");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FASetText("123456789123");
                FastDriver.GFEEntryLoanTerms.InterestRateAfterPeriod.FASetText("123456789123");
                FastDriver.GFEEntryLoanTerms.ChangedInterestRate.FASetText("1234.11111");
                FastDriver.GFEEntryLoanTerms.LowerInterestRate.FASetText("1254.44444");
                    FastDriver.GFEEntryLoanTerms.HigherInterestRate.FASetText("1456.55555");
                    FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAClick();

                Support.AreEqual("1111.22222", FastDriver.GFEEntryLoanTerms.MaxInterestRate.FAGetValue());
                Support.AreEqual("123456789123", FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAGetValue());
                Support.AreEqual("123456789123", FastDriver.GFEEntryLoanTerms.InterestRateAfterPeriod.FAGetValue());
                Support.AreEqual("1234.11111", FastDriver.GFEEntryLoanTerms.ChangedInterestRate.FAGetValue());               
                Support.AreEqual("1254.44444", FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAGetValue());
               Support.AreEqual("1456.55555", FastDriver.GFEEntryLoanTerms.HigherInterestRate.FAGetValue());

                FastDriver.GFEEntryLoanTerms.LoanBalanceRiseYes.FAClick();
                FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.HigherInterestRate.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FAGetValue());

                FastDriver.GFEEntryLoanTerms.MonthlyAmountRiseYes.FAClick();
                FastDriver.GFEEntryLoanTerms.MonthlyIncrementAmt.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FASetText("12345678999.21");
                FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FAClick();

                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.MonthlyIncrementAmt.FAGetValue());
                Support.AreEqual("12,345,678,999.21", FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FAGetValue());


                FastDriver.GFEEntryLoanTerms.PrePaymentYes.FAClick();
                FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FAGetValue());

                FastDriver.GFEEntryLoanTerms.BalanceloonPaymentYes.FAClick();
                FastDriver.GFEEntryLoanTerms.BalanceloonPaymentMaxAmount.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.BalanceloonPaymentMaxAmount.FAGetValue());
                FastDriver.GFEEntryLoanTerms.BalancelonPaymentDuePeriod.FASetText("123");
                FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FAClick();
                Support.AreEqual("123", FastDriver.GFEEntryLoanTerms.BalancelonPaymentDuePeriod.FAGetValue());

                FastDriver.GFEEntryLoanTerms.EscrowAccountMonthlyAmountYes.FAClick();
                FastDriver.GFEEntryLoanTerms.AdditionalMonthlyEscrowAmount.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.AdditionalTotalMonthlyAmt.FASetText("12345678989.79");
                FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.AdditionalMonthlyEscrowAmount.FAGetValue());
                Support.AreEqual("12,345,678,989.79", FastDriver.GFEEntryLoanTerms.AdditionalTotalMonthlyAmt.FAGetValue());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0037()
        {

            try
            {

                Reports.TestDescription = "FD_4B: field validation for exact field length.";

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction


                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                FastDriver.GFEEntryLoanTerms.RateIncrementRiseYes.FAClick();
                FastDriver.GFEEntryLoanTerms.MaxInterestRate.FASetText("11111.222222");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FASetText("1234567891234");
                FastDriver.GFEEntryLoanTerms.InterestRateAfterPeriod.FASetText("1234567891234");
                FastDriver.GFEEntryLoanTerms.ChangedInterestRate.FASetText("12345.111111");
                FastDriver.GFEEntryLoanTerms.LowerInterestRate.FASetText("12545.444444");
                FastDriver.GFEEntryLoanTerms.HigherInterestRate.FASetText("14567.555555");
                FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FAClick();
                
                Support.AreEqual("?", FastDriver.GFEEntryLoanTerms.MaxInterestRate.FAGetValue());
                Support.AreEqual("123456789123", FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAGetValue());
                Support.AreEqual("123456789123", FastDriver.GFEEntryLoanTerms.InterestRateAfterPeriod.FAGetValue());
                Support.AreEqual("", FastDriver.GFEEntryLoanTerms.ChangedInterestRate.FAGetValue());
                Support.AreEqual("?", FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAGetValue());
                Support.AreEqual("?", FastDriver.GFEEntryLoanTerms.HigherInterestRate.FAGetValue());

                FastDriver.GFEEntryLoanTerms.LoanBalanceRiseYes.FAClick();
                FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FASetText("123456789126.123");
                FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAClick();
                Support.AreEqual("", FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FAGetValue());

                FastDriver.GFEEntryLoanTerms.MonthlyAmountRiseYes.FAClick();
                FastDriver.GFEEntryLoanTerms.MonthlyIncrementAmt.FASetText("123456789123.124");
                FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FASetText("123456789999.213");
                FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAClick();

                Support.AreEqual("?", FastDriver.GFEEntryLoanTerms.MonthlyIncrementAmt.FAGetValue());
                Support.AreEqual("?", FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FAGetValue());

                FastDriver.GFEEntryLoanTerms.PrePaymentYes.FAClick();
                FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FASetText("123456789126.127");
                FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAClick();
                Support.AreEqual("?", FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FAGetValue());


                FastDriver.GFEEntryLoanTerms.BalanceloonPaymentYes.FAClick();
                FastDriver.GFEEntryLoanTerms.BalanceloonPaymentMaxAmount.FASetText("123456789129.123");
                FastDriver.GFEEntryLoanTerms.BalancelonPaymentDuePeriod.FASetText("1234");
                FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAClick();

                Support.AreEqual("?", FastDriver.GFEEntryLoanTerms.BalanceloonPaymentMaxAmount.FAGetValue());
                Support.AreEqual("123", FastDriver.GFEEntryLoanTerms.BalancelonPaymentDuePeriod.FAGetValue());

                FastDriver.GFEEntryLoanTerms.EscrowAccountMonthlyAmountYes.FAClick();
                FastDriver.GFEEntryLoanTerms.AdditionalTotalMonthlyAmt.FASetText("123456789899.798");               
                FastDriver.GFEEntryLoanTerms.AdditionalMonthlyEscrowAmount.FASetText("123456789128.124");
                FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAClick();

                Support.AreEqual("", FastDriver.GFEEntryLoanTerms.AdditionalMonthlyEscrowAmount.FAGetValue());
                Support.AreEqual("", FastDriver.GFEEntryLoanTerms.AdditionalTotalMonthlyAmt.FAGetValue());
                // 
                FastDriver.BottomFrame.Done();
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                // 
                // 
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryLoanTerms.SwitchToContentFrame();
                Reports.TestStep = "Enter the correct value for field validation in low range.";
                FastDriver.GFEEntryLoanTerms.RateIncrementRiseYes.FAClick();

                FastDriver.GFEEntryLoanTerms.MaxInterestRate.FASetText("1111.222222");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FASetText("123456789123");
                FastDriver.GFEEntryLoanTerms.InterestRateAfterPeriod.FASetText("123456789123");
                FastDriver.GFEEntryLoanTerms.ChangedInterestRate.FASetText("1234.111111");
                FastDriver.GFEEntryLoanTerms.LowerInterestRate.FASetText("1254.444444");
                FastDriver.GFEEntryLoanTerms.HigherInterestRate.FASetText("1456.555555");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAClick();

                Support.AreEqual("1111.22222", FastDriver.GFEEntryLoanTerms.MaxInterestRate.FAGetValue());
                Support.AreEqual("123456789123", FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAGetValue());
                Support.AreEqual("123456789123", FastDriver.GFEEntryLoanTerms.InterestRateAfterPeriod.FAGetValue());
                Support.AreEqual("1234.11111", FastDriver.GFEEntryLoanTerms.ChangedInterestRate.FAGetValue());
                Support.AreEqual("1254.44444", FastDriver.GFEEntryLoanTerms.LowerInterestRate.FAGetValue());
                Support.AreEqual("1456.55555", FastDriver.GFEEntryLoanTerms.HigherInterestRate.FAGetValue());

                FastDriver.GFEEntryLoanTerms.LoanBalanceRiseYes.FAClick();
                FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAClick();

                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.LoanBalanceMaxAmt.FAGetValue());

                FastDriver.GFEEntryLoanTerms.MonthlyAmountRiseYes.FAClick();

                FastDriver.GFEEntryLoanTerms.MonthlyIncrementAmt.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FASetText("12345678999.21");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAClick();

                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.MonthlyIncrementAmt.FAGetValue());
                Support.AreEqual("12,345,678,999.21", FastDriver.GFEEntryLoanTerms.MonthlyMaxAmount.FAGetValue());


                FastDriver.GFEEntryLoanTerms.PrePaymentYes.FAClick();

                FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.PrePaymentMaxAmount.FAGetValue());

                FastDriver.GFEEntryLoanTerms.BalanceloonPaymentYes.FAClick();

                FastDriver.GFEEntryLoanTerms.BalanceloonPaymentMaxAmount.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.BalancelonPaymentDuePeriod.FASetText("123");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAClick();

                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.BalanceloonPaymentMaxAmount.FAGetValue());
                Support.AreEqual("123", FastDriver.GFEEntryLoanTerms.BalancelonPaymentDuePeriod.FAGetValue());

                FastDriver.GFEEntryLoanTerms.EscrowAccountMonthlyAmountYes.FAClick();

                FastDriver.GFEEntryLoanTerms.AdditionalMonthlyEscrowAmount.FASetText("12345678912.12");
                FastDriver.GFEEntryLoanTerms.AdditionalTotalMonthlyAmt.FASetText("12345678989.79");
                FastDriver.GFEEntryLoanTerms.InterestRateBeforePeriod.FAClick();

                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryLoanTerms.AdditionalMonthlyEscrowAmount.FAGetValue());
                Support.AreEqual("12,345,678,989.79", FastDriver.GFEEntryLoanTerms.AdditionalTotalMonthlyAmt.FAGetValue());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0038()
        {

            Reports.TestDescription = "FD_5A: field validation-GFE 1 Origination Charge for low range.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation-GFE #1 Origination Charge for low range.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();



                FastDriver.GFEEntryGFE.OriginationCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE1.FASetText("1234567891.12");

                FastDriver.GFEEntryGFE.GFE2.FAClick();
                Support.AreEqual(@"1,234,567,891.12", FastDriver.GFEEntryGFE.GFE1.FAGetValue());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "field validation-Adjusted Origination Charge for low range.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryLoanTerms.WaitForScreenToLoad();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0039()
        {

            Reports.TestDescription = "FD_5B: field validation-GFE 1 Origination Charge for exact range.";

            try
            {


                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();
                Reports.TestStep = "field validation-GFE #1 Origination Charge for exact range.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.OriginationCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE1.FASetText("12345678912.12");
                FastDriver.GFEEntryGFE.GFE2.FAClick();
                Support.AreEqual(@"12,345,678,912.12", FastDriver.GFEEntryGFE.GFE1.FAGetValue());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "field validation-Adjusted Origination Charge for low range.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0040()
        {

            Reports.TestDescription = "FD_5C: field validation-GFE 1 Origination Charge for high range.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation-GFE #1 Origination Charge for high range.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.OriginationCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE1.FASetText("123456789123.12");

                FastDriver.GFEEntryGFE.GFE2.FAClick();
                Support.AreEqual(@"0.00", FastDriver.GFEEntryGFE.GFE1.FAGetValue());

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "field validation-Adjusted Origination Charge for high range.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("0.00", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0041()
        {

            Reports.TestDescription = "FD_5D: field validation-GFE 1 Origination Charge for decimal low range.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();
                Reports.TestStep = "field validation-GFE #1 Origination Charge for decimal low range.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.OriginationCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE1.FASetText("12345678912.1");
                FastDriver.GFEEntryGFE.GFE2.Click();
                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.GFE1.FAGetValue());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "field validation-Adjusted Origination Charge for decimal low range.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0042()
        {

            Reports.TestStep = "field validation-GFE #1 Origination Charge for decimal high range.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation-GFE #1 Origination Charge for decimal high range.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.OriginationCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE1.FASetText("12345678912.123");
                FastDriver.GFEEntryGFE.GFE2.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE1.FAGetValue());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "field validation-Adjusted Origination Charge for decimal low range.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.AdjustedOriginationCharge.FAGetText());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0043()
        {

            Reports.TestDescription = "FD_6A: field validation-GFE 2 Origination Charge for low range.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation-GFE #2 Origination Charge for low range.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.PointsCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE2.FASetText("11");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("11.00", FastDriver.GFEEntryGFE.GFE2.FAGetValue());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0106_REG0044()
        {

            Reports.TestDescription = "FD_6B: field validation-GFE 2 Origination Charge for exact range.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation-GFE #2 Origination Charge for exact range.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();


                FastDriver.GFEEntryGFE.PointsCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE2.FASetText("12345678912.12");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE2.FAGetValue());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0045()
        {

            Reports.TestDescription = "FD_6C: field validation-GFE 2 Origination Charge for high range.";

            try
            {
                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation-GFE #2 Origination Charge for high range.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.PointsCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE2.FASetText("123456789123.12");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("0.00", FastDriver.GFEEntryGFE.GFE2.FAGetValue());

                Reports.TestStep = "Clear out the field.";
                FastDriver.GFEEntryGFE.GFE2.FASetText("");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("0.00", FastDriver.GFEEntryGFE.GFE2.FAGetValue());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0046()
        {

            Reports.TestDescription = "FD_6D: field validation-GFE 2 Origination Charge for decimal low range.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation-GFE #2 Origination Charge for decimal low range.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.PointsCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE2.FASetText("12345678912.1");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.GFE2.FAGetValue());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0047()
        {

            Reports.TestDescription = "FD_6E: field validation-GFE 2 Origination Charge for decimal high range.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "field validation-GFE #2 Origination Charge for decimal high range.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.PointsCharge.FAClick();
                FastDriver.GFEEntryGFE.GFE2.FASetText("12345678912.123");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE2.FAGetValue());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0048()
        {

            Reports.TestDescription = "FD_7A: To add and verify GFE amount from Inspection Repair - Septic-low range.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction


                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add party and click on Payment details in Inspection Repair - Septic.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();

                // FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItem("Inspection/Repair - Septic");
                SelectanItemFromCMB("Inspection Repair - Septic");

                SetGabtoInspectionRepairDetailDlg("Inspection/Repair - Septic", "225");

                FastDriver.InspectionRepairDetailDlg.PaymentDetails.FAClick();
                SetGfeTypeinPaymentDetailDlg(GFEType: "3");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Inspection/Repair - Septic", true, 50);
                FastDriver.InspectionRepairDetailDlg.SwitchToDialogContentFrame();
                FastDriver.InspectionRepairDetailDlg.Description.FASetText("Thisisfortestingfieldlengthofchargedescripti");
                FastDriver.InspectionRepairDetailDlg.BuyerCharge.FAClick();
                Support.AreEqual(@"Thisisfortestingfieldlengthofchargedescripti", FastDriver.InspectionRepairDetailDlg.Description.FAGetValue());

                FastDriver.InspectionRepairDetailDlg.GFE3Amount.FASetText("1,234,567,891.12");
                FastDriver.InspectionRepairDetailDlg.BuyerCharge.FAClick();
                Support.AreEqual(@"1,234,567,891.12", FastDriver.InspectionRepairDetailDlg.GFE3Amount.FAGetValue());
                // 
                BottomFrameDlgDone();
                // 
                // 
                Reports.TestStep = "To verify low range for GFE3 total.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE3total.FAGetText());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }

        [TestMethod]
        public void FMUC0106_REG0049()
        {

            Reports.TestDescription = "FD_7B: To add and verify GFE amount from Inspection Repair - Septic-exact range.";

            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To add party and click on Payment details in Inspection Repair - Septic.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();

                // FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItem("Inspection/Repair - Septic");
                SelectanItemFromCMB("Inspection Repair - Septic");

                SetGabtoInspectionRepairDetailDlg("Inspection/Repair - Septic", "225");

                FastDriver.InspectionRepairDetailDlg.PaymentDetails.FAClick();

                SetGfeTypeinPaymentDetailDlg(GFEType: "3");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Inspection/Repair - Septic", true, 50);
                FastDriver.InspectionRepairDetailDlg.SwitchToDialogContentFrame();


                FastDriver.InspectionRepairDetailDlg.Description.FASetText("Thisisfortestingfieldlengthofchargedescriptio");

                FastDriver.InspectionRepairDetailDlg.BuyerCharge.FAClick();
                Support.AreEqual("Thisisfortestingfieldlengthofchargedescriptio", FastDriver.InspectionRepairDetailDlg.Description.FAGetValue());

                FastDriver.InspectionRepairDetailDlg.GFE3Amount.FASetText("12,345,678,912.12");
                FastDriver.InspectionRepairDetailDlg.BuyerCharge.FAClick();

                Support.AreEqual("12,345,678,912.12", FastDriver.InspectionRepairDetailDlg.GFE3Amount.FAGetValue());
                // 
                BottomFrameDlgDone();
                // 
                // 
                Reports.TestStep = "To verify low range for GFE3 total.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE3total.FAGetText());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }

        [TestMethod]
        public void FMUC0106_REG0050()
        {

            Reports.TestDescription = "FD_8: field validation-GFE 4 and GFE 5 Origination Charge for decimal high range.";
            try
            {

                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To verify low range for GFE #4 and GFE# 5.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.GFE4.FASetText("1234567891.12");
                FastDriver.GFEEntryGFE.GFE5.FASetText("'1234567891.12");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE4.FAGetValue());
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE5.FAGetValue());
                // 
                // 
                Reports.TestStep = "To verify exact range for GFE #4 and GFE# 5.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.GFE4.FASetText("12345678912.12");
                FastDriver.GFEEntryGFE.GFE5.FASetText("12345678912.12");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE4.FAGetValue());
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE5.FAGetValue());
                // 
                // 
                Reports.TestStep = "To verify high range for GFE #4 and GFE# 5.";
                FastDriver.GFEEntryGFE.GFE4.FASetText("123456789123.1");
                FastDriver.GFEEntryGFE.GFE5.FASetText("123456789123.1");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("?", FastDriver.GFEEntryGFE.GFE4.FAGetValue());
                Support.AreEqual("?", FastDriver.GFEEntryGFE.GFE5.FAGetValue());
                // 
                // 
                Reports.TestStep = "To verify low decimal range for GFE #4 and GFE# 5.";
                FastDriver.GFEEntryGFE.GFE4.FASetText("12345678912.1");
                FastDriver.GFEEntryGFE.GFE5.FASetText("12345678912.1");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.GFE4.FAGetValue());
                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.GFE5.FAGetValue());


                Reports.TestStep = "To verify high decimal range for GFE #4 and GFE# 5.";
                FastDriver.GFEEntryGFE.GFE4.FASetText("1234567891.123");                
                FastDriver.GFEEntryGFE.GFE5.FASetText("1234567891.123");
                FastDriver.GFEEntryGFE.GFE1.FAClick();
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE4.FAGetValue());
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE5.FAGetValue());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0106_REG0051()
        {

            Reports.TestDescription = "FD_9: field validation-GFE 6,7,8 and GFE10.";

            try
            {


                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To verify low range for GFE #7,8,9 and GFE# 10.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.GFE7.FASetText("1234567891.12");
                FastDriver.GFEEntryGFE.GFE8.FASetText("1234567891.12");
                FastDriver.GFEEntryGFE.GFE9.FASetText("1234567891.12");
                FastDriver.GFEEntryGFE.GFE10.FASetText("1234567891.12");
                FastDriver.GFEEntryGFE.GFE1.FAClick();

                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE7.FAGetValue());
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE8.FAGetValue());
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE9.FAGetValue());
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE10.FAGetValue());
                // 
                // 
                Reports.TestStep = "To verify exact range for GFE #7,8,9 and GFE# 10.";

                FastDriver.GFEEntryGFE.GFE7.FASetText("12345678912.12");
                FastDriver.GFEEntryGFE.GFE8.FASetText("12345678912.12");
                FastDriver.GFEEntryGFE.GFE9.FASetText("12345678912.12");
                FastDriver.GFEEntryGFE.GFE10.FASetText("12345678912.12");
                FastDriver.GFEEntryGFE.GFE1.FAClick();

                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE7.FAGetValue());
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE8.FAGetValue());
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE9.FAGetValue());
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE10.FAGetValue());
                // 
                // 
                Reports.TestStep = "To verify high range for GFE #7,8,9 and GFE# 10.";

                FastDriver.GFEEntryGFE.GFE7.FASetText("123456789123.1");
                FastDriver.GFEEntryGFE.GFE8.FASetText("123456789123.1");
                FastDriver.GFEEntryGFE.GFE9.FASetText("123456789123.1");
                FastDriver.GFEEntryGFE.GFE10.FASetText("123456789123.1");
                FastDriver.GFEEntryGFE.GFE1.FAClick();

                Support.AreEqual("?", FastDriver.GFEEntryGFE.GFE7.FAGetValue());
                Support.AreEqual("?", FastDriver.GFEEntryGFE.GFE8.FAGetValue());
                Support.AreEqual("?", FastDriver.GFEEntryGFE.GFE9.FAGetValue());
                Support.AreEqual("0.00", FastDriver.GFEEntryGFE.GFE10.FAGetValue());
                // 
                // 
                Reports.TestStep = "To clear the field.";
                FastDriver.GFEEntryGFE.GFE10.FASetText("");
                Support.AreEqual("0.00", FastDriver.GFEEntryGFE.GFE10.FAGetValue());
                // 
                Reports.TestStep = "To verify low decimal range for GFE #7,8,9 and GFE# 10.";

                FastDriver.GFEEntryGFE.GFE7.FASetText("12345678912.1");
                FastDriver.GFEEntryGFE.GFE8.FASetText("12345678912.1");
                FastDriver.GFEEntryGFE.GFE9.FASetText("12345678912.1");
                FastDriver.GFEEntryGFE.GFE10.FASetText("12345678912.1");
                FastDriver.GFEEntryGFE.GFE1.FAClick();

                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.GFE7.FAGetValue());
                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.GFE8.FAGetValue());
                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.GFE9.FAGetValue());
                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.GFE10.FAGetValue());
                // 
                // 
                Reports.TestStep = "To verify high decimal range for GFE #7,8,9 and GFE# 10.";

                FastDriver.GFEEntryGFE.GFE7.FASetText("1234567891.123");
                FastDriver.GFEEntryGFE.GFE8.FASetText("1234567891.123");
                FastDriver.GFEEntryGFE.GFE9.FASetText("1234567891.123");
                FastDriver.GFEEntryGFE.GFE10.FASetText("1234567891.123");
                FastDriver.GFEEntryGFE.GFE1.FAClick();

                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE7.FAGetValue());
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE8.FAGetValue());
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE9.FAGetValue());
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE10.FAGetValue());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0106_REG0052()
        {

            Reports.TestDescription = "FD_10: field validation-GFE11 and GFE Total.";

            try
            {


                #region Create a Basic File
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI interaction

                FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry").WaitForScreenToLoad();

                Reports.TestStep = "To verify low range for GFE11 amount.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Reports.TestStep = "To verify exact range for GFE11 amount.";

                //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem("Insurance - Fire");
                SelectanItemFromGFE11CMB("Insurance - Fire");
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Fire Insurance", "220", "1234567891.12");


                Reports.TestStep = "To verify low range for GFE11 total.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE11total.FAGetText());
                // 
                // 

                Reports.TestStep = "To verify exact range for GFE11 amount.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                SelectanItemFromGFE11CMB("Insurance - Fire");
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Fire Insurance", "220", "12345678912.12");

                

                Reports.TestStep = "To verify low exact for GFE11 total.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("12,345,678,912.12", FastDriver.GFEEntryGFE.GFE11total.FAGetText());

                // 
            

                Reports.TestStep = "To verify high range for GFE11 total.";
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem("Insurance - Fire");
                SelectanItemFromGFE11CMB("Insurance - Fire");
                //FastDriver.GFEEntryGFE.SetInsuranceDetails("Fire Insurance", "220", "123456789123.1");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fire Insurance", true, 500);
                FastDriver.FireInsuranceDlg.SwitchToDialogContentFrame();
                FastDriver.FireInsuranceDlg.InsuranceAgentGABcode.FASetText("220");
                FastDriver.FireInsuranceDlg.InsuranceAgentFind.FAClick();
                FastDriver.FireInsuranceDlg.InsurChargeGfeAmount.FASetText("123456789123.1");
                FastDriver.FireInsuranceDlg.InsuranceAgentGABcode.FAClick();
                Support.AreEqual("?", FastDriver.FireInsuranceDlg.InsurChargeGfeAmount.FAGetValue());

                Reports.TestStep = "To clear GFE11 amount.";                
                FastDriver.FireInsuranceDlg.InsurChargeGfeAmount.FASetText("");
                FastDriver.FireInsuranceDlg.InsuranceAgentGABcode.FAClick();
                Support.AreEqual("", FastDriver.FireInsuranceDlg.InsurChargeGfeAmount.FAGetText());
                FastDriver.FireInsuranceDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();


               
                Reports.TestStep = "To add GFE amount from : Insurance – Fire.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem("Insurance - Fire");
                SelectanItemFromGFE11CMB("Insurance - Fire");
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Fire Insurance", "220", "'12345678912.1");
                //FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "To verify low decimal range for GFE11 total.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("12,345,678,912.10", FastDriver.GFEEntryGFE.GFE11total.FAGetText());


                // 
                Reports.TestStep = "To verify high decimal range for GFE11 amount.";

                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FASelectItem("Insurance - Fire");
                SelectanItemFromGFE11CMB("Insurance - Fire");
                FastDriver.GFEEntryGFE.SetInsuranceDetails("Fire Insurance", "220", "'1234567891.123");

                Reports.TestStep = "To verify high decimal range for GFE11 total.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GFEEntryGFE.SwitchToContentFrame();
                FastDriver.GFEEntryGFE.GFEtab.FAClick();
                Support.AreEqual("1,234,567,891.12", FastDriver.GFEEntryGFE.GFE11total.FAGetText());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0106_REG0053_PH()
        {
            try
            {
                Reports.TestDescription = "BR_FM10853:";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0106_REG0054_PH()
        {
            try
            {
                Reports.TestDescription = "BR_FM10856:";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
               

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region - Recurrent Methods

        private void IISLOGIN(string UserName = null, string Password = null)
        {

            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
        }
        private void CreateBasicFile()
        {

            var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            Reports.TestStep = "Create File using web service.";

            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

        }
        private void SetGabtoInspectionRepairDetailDlg(string WndName, string Gab)
        {
            Reports.TestStep = "Enter Gab Details in InspectionRepairDetailDlg"; 
            FastDriver.InspectionRepairDetailDlg.WaitForScreenToLoad(WndName);
            FastDriver.InspectionRepairDetailDlg.GABcode.FASetText(Gab);
            FastDriver.InspectionRepairDetailDlg.Find.FAClick();

        }

        private void SetGfe6AmttoInspectionRepairDetailDlg(string Gfe6Amt)
        {
            Reports.TestStep = "Gfe6 Amt to InspectionRepairDetailDlg";

            FastDriver.InspectionRepairDetailDlg.GFE6Amount.FASetText(Gfe6Amt);
            FastDriver.InspectionRepairDetailDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
        }

        private void SetGfeTypeinPaymentDetailDlg(string GFEType)
        {
            BrowserWindow wnd = new BrowserWindow();
            wnd.SearchProperties.Add("Name", "FAST", PropertyExpressionOperator.Contains);
            HtmlDocument fraviewdoc = new HtmlDocument(wnd);
            HtmlIFrame frame = new HtmlIFrame(fraviewdoc);
            frame.SearchProperties.Add("Id", "FAFDialog_1_iframe", PropertyExpressionOperator.EqualTo);
            fraviewdoc = new HtmlDocument(frame);
            HtmlIFrame innerframe = new HtmlIFrame(fraviewdoc);
            innerframe.SearchProperties.Add("Id", "fraPageWin", PropertyExpressionOperator.EqualTo);
            HtmlDocument DOC = new HtmlDocument(innerframe);
            HtmlComboBox cmb_chargeprocess = new HtmlComboBox(DOC);
            cmb_chargeprocess.SearchProperties.Add("Id", "cboGFEType", PropertyExpressionOperator.EqualTo);
            Mouse.Click(cmb_chargeprocess);

            UITestControlCollection ListItems = (UITestControlCollection)cmb_chargeprocess.GetProperty("Items");
            foreach (HtmlListItem lItem in ListItems)
            {
                if (lItem.DisplayText.ToString() == GFEType)
                {
                    Mouse.Click(lItem);
                    break;
                }
            }

            HtmlInputButton button = new HtmlInputButton(fraviewdoc);
            button.SearchProperties.Add("Id", "btnDone", PropertyExpressionOperator.EqualTo);
            Mouse.Click(button);
            //FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            //FastDriver.PaymentDetailsDlg.GFEType.FASelectItem(GFEType);
            //FastDriver.DialogBottomFrame.ClickDone();
        }

        private void SelectanItemFromCMB(string ItemValue)
        {

            BrowserWindow wnd = new BrowserWindow();
            wnd.SearchProperties.Add("Name", "FAST", PropertyExpressionOperator.Contains);
            HtmlDocument fraviewdoc = new HtmlDocument(wnd);
            HtmlIFrame frame = new HtmlIFrame(fraviewdoc);
            frame.SearchProperties.Add("Id", "fraView", PropertyExpressionOperator.EqualTo);
            fraviewdoc = new HtmlDocument(frame);
            HtmlIFrame innerframe = new HtmlIFrame(fraviewdoc);
            innerframe.SearchProperties.Add("Id", "fraPageWin", PropertyExpressionOperator.EqualTo);
            HtmlDocument DOC = new HtmlDocument(innerframe);
            HtmlComboBox cmb_chargeprocess = new HtmlComboBox(DOC);
            cmb_chargeprocess.SearchProperties.Add("Id", "tGFE_tGC_FAFDropDownList1", PropertyExpressionOperator.EqualTo);
            Mouse.Click(cmb_chargeprocess);

            UITestControlCollection ListItems = (UITestControlCollection)cmb_chargeprocess.GetProperty("Items");
            foreach (HtmlListItem lItem in ListItems)
            {
                if (lItem.DisplayText.ToString() == ItemValue)
                {
                    Mouse.Click(lItem);
                    break;
                }
            }
            //FastDriver.GFEEntryGFE.GFE3ChgProcessType.FAClick();
            //Keyboard.SendKeys(ItemValue);
            //Keyboard.SendKeys("{ENTER}");

        }

        private void SelectanItemFromGFE11CMB(string ItemValue)
        {

            BrowserWindow wnd = new BrowserWindow();
            wnd.SearchProperties.Add("Name", "FAST", PropertyExpressionOperator.Contains);
            HtmlDocument fraviewdoc = new HtmlDocument(wnd);
            HtmlIFrame frame = new HtmlIFrame(fraviewdoc);
            frame.SearchProperties.Add("Id", "fraView", PropertyExpressionOperator.EqualTo);
            fraviewdoc = new HtmlDocument(frame);
            HtmlIFrame innerframe = new HtmlIFrame(fraviewdoc);
            innerframe.SearchProperties.Add("Id", "fraPageWin", PropertyExpressionOperator.EqualTo);
            HtmlDocument DOC = new HtmlDocument(innerframe);
            HtmlComboBox cmb_chargeprocess = new HtmlComboBox(DOC);
            cmb_chargeprocess.SearchProperties.Add("Id", "tGFE_tGC_FAFDropDownList3", PropertyExpressionOperator.EqualTo);
            Mouse.Click(cmb_chargeprocess);

            UITestControlCollection ListItems = (UITestControlCollection)cmb_chargeprocess.GetProperty("Items");
            foreach (HtmlListItem lItem in ListItems)
            {
                if (lItem.DisplayText.ToString() == ItemValue)
                {
                    Mouse.Click(lItem);
                    break;
                }
            }
            //FastDriver.GFEEntryGFE.GFE3ChgProcessType.FAClick();
            //Keyboard.SendKeys(ItemValue);
            //Keyboard.SendKeys("{ENTER}");

            //FastDriver.GFEEntryGFE.GFE11ChgProcessType.FAClick();
            //Keyboard.SendKeys(ItemValue);
            //Keyboard.SendKeys("{ENTER}");

        }

        private void BottomFrameDlgDone()
        {
            FastDriver.InspectionRepairDetailDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
