﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.Common;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.PageObjects.IIS;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0097 : MasterTestClass
    {

        #region REG

        #region FMUC0097_REG0001
        [TestMethod]
        public void FMUC0097_REG0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Launch FAST View.";

                #region Credentials
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Click on Fast View.";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Verify the default Fast View File search Page Default Data.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FastViewFileSearch.RadFileSearch.IsSelected().ToString(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.Principals.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.OtherParties.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.PropertyAddress.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.PropertyName.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.PropertyLot.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.PropertyTract.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.PropertyParcel.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.PropertySubDivision.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.APNTaxNo.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.County.FAGetText(), true);
                Support.AreEqual(AutoConfig.SelectedRegionName, FastDriver.FastViewFileSearch.Region.FAGetSelectedItem(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.Numbers.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.DateFrom.FAGetText(), true);
                Support.AreEqual("", FastDriver.FastViewFileSearch.DateTo.FAGetText(), true);
                FastDriver.WebDriver.Close();

                Reports.TestStep = "Verify for Fast View link is Enabled.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 200);
                FastDriver.TopFrame.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.TopFrame.FastView.IsEnabled().ToString(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0097_REG0002
        [TestMethod]
        public void FMUC0097_REG0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Toggle between main and 2nd instance.; FM7916  FASTView second instance";

                #region Credentials
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file.";
                string fileNumber = CreateBasicFileWithSpecifiedGAB("HUDFLINSR1");
                System.Threading.Thread.Sleep(10000); // Wait for file to show up on search result

                try
                {
                    Reports.TestStep = "Click on Fast View.";
                    FastDriver.TopFrame.WaitForScreenToLoad();
                    FastDriver.TopFrame.FastView.FAClick();

                    Reports.TestStep = "Enter file Number to Search From Fast View.";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Country.FASelectItem("USA");
                    FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber + FAKeys.Tab);

                    Reports.TestStep = "Click on Find Now.";
                    FastDriver.FastViewFileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 30);
                    FastDriver.FastViewFileSearch.WaitForMessagePaneToLoad();
                }
                catch (Exception)
                {
                    FastDriver.WebDriver.Close(); // Close the FAST View window
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 30);
                    
                    Reports.TestStep = "Second try -- Click on Fast View.";
                    FastDriver.TopFrame.WaitForScreenToLoad();
                    FastDriver.TopFrame.FastView.FAClick();

                    Reports.TestStep = "Second try -- Enter file Number to Search From Fast View.";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Country.FASelectItem("USA");
                    FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber + FAKeys.Tab);

                    Reports.TestStep = "Second try -- Click on Find Now.";
                    FastDriver.FastViewFileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 30);
                    FastDriver.FastViewFileSearch.WaitForMessagePaneToLoad();
                }

                Reports.TestStep = "Open Terms/Dates/Status window";
                FastDriver.FileSearch.SendControlShift("T"); // Open Terms/Dates/Status screen

                Reports.TestStep = "Validate file status is open";
                FastDriver.FastViewFileSearch.WaitForScreenToLoad(FastDriver.TermsDatesStatus.Status);
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem());

                Reports.TestStep = "Close the FAST View window, switch back to FAST main windwow";
                FastDriver.WebDriver.Close(); // Close the FAST View window
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 30);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen on FAST main window, validate file status.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0097_REG0003
        [TestMethod]
        public void FMUC0097_REG0003()
        {
            try
            {
                Reports.TestDescription = "AF3: Exit FAST Main Instance and automatically Exit Open FASTView.";

                #region Credentials
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file.";
                string fileNumber = CreateBasicFileWithSpecifiedGAB("HUDFLINSR1");

                Reports.TestStep = "Click on Fast View.";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Switch to FAST View window";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                

                Reports.TestStep = "Switch to FAST main window, and close the main window";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 30);
                FastDriver.WebDriver.Close(); // Close the FAST main window

                Reports.TestStep = "Validate the FAST View window is also closed";
                Support.AreEqual("False", FastDriver.WebDriver.WindowIsDisplayed("FAST View").ToString(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0097_REG0004
        [TestMethod]
        public void FMUC0097_REG0004()
        {
            try
            {
                Reports.TestDescription = "TFS #162909 Search on Policy Number in FASTView File Search; FM7918  FASTView second instance Login credentials";

                #region Credentials
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file.";
                string fileNumber = CreateBasicFileWithSpecifiedGAB("HUDFLINSR1");

                Reports.TestStep = "Click on Fast View.";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Switch to FAST View window";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();

                Reports.TestStep = "Validate Policy No. radio button exist";
                Support.AreEqual("True", FastDriver.FastViewFileSearch.PolicyNo.IsEnabled().ToString(), true);

                Reports.TestStep = "Validate current user is the same login ID from main FAST instance";
                FastDriver.StatusBarFrame.WaitForFastViewScreenToLoad();
                Support.AreEqual(AutoConfig.UserName, FastDriver.StatusBarFrame.FastViewCurrentUser.FAGetText().Clean(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0097_REG0005
        [TestMethod]
        public void FMUC0097_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM7922  Selection of File in FastView Search results";

                #region Credentials
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file.";
                string fileNumber = CreateBasicFileWithSpecifiedGAB("HUDFLINSR1");
                System.Threading.Thread.Sleep(10000); // Wait for file to show up on search result

                Reports.TestStep = "Click on Fast View.";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Switch to FAST View window, peform search for file created today";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                FastDriver.FASTView.WaitForScreenToLoad();
                FastDriver.FASTView.FileNumber.FASetText(fileNumber.Substring(0, (fileNumber.Length - 1)) + "*");
                FastDriver.FASTView.FromDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.FASTView.ToDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.FASTView.FindNow.FAClick();

                try
                {
                    Reports.TestStep = "Double click on the file created";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 20);
                    FastDriver.FileSearch.SwitchToFastViewContentFrame();
                    FastDriver.FileSearch.WaitCreation(FastDriver.FileSearch.SearchResultTable);
                    FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.DoubleClick);
                }
                catch (Exception ex)
                {
                    Reports.TestStep = "Perform search second time.";
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 20);
                    FastDriver.FASTView.WaitForScreenToLoad();
                    Playback.Wait(5000); //Wait 5 seconds for file to show up on search results
                    FastDriver.FileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 20);
                    FastDriver.FileSearch.SwitchToFastViewContentFrame();
                    FastDriver.FileSearch.WaitCreation(FastDriver.FileSearch.SearchResultTable);
                    FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.DoubleClick);
                }

                Reports.TestStep = "Validate the file number is displayed on the message status bar";
                FastDriver.FastViewFileSearch.WaitForMessagePaneToLoad();
                Support.AreEqual(fileNumber, FastDriver.FastViewFileSearch.FileNumberLabel.FAGetText().Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0097_REG0006
        [TestMethod]
        public void FMUC0097_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM7923  Prevent add/Edit/Delete tasks";

                #region Credentials
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file.";
                string fileNumber = CreateBasicFileWithSpecifiedGAB("HUDFLINSR1");
                System.Threading.Thread.Sleep(10000); // Wait for file to show up on search result

                try
                {
                    Reports.TestStep = "Click on Fast View.";
                    FastDriver.TopFrame.WaitForScreenToLoad();
                    FastDriver.TopFrame.FastView.FAClick();

                    Reports.TestStep = "Enter file Number to Search From Fast View.";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Country.FASelectItem("USA");
                    FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber + FAKeys.Tab);

                    Reports.TestStep = "Click on Find Now.";
                    FastDriver.FastViewFileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 30);
                    FastDriver.FastViewFileSearch.WaitForMessagePaneToLoad();
                }
                catch (Exception)
                {
                    FastDriver.WebDriver.Close(); // Close the FAST View window
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 30);

                    Reports.TestStep = "Second try -- Click on Fast View.";
                    FastDriver.TopFrame.WaitForScreenToLoad();
                    FastDriver.TopFrame.FastView.FAClick();

                    Reports.TestStep = "Second try -- Enter file Number to Search From Fast View.";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Country.FASelectItem("USA");
                    FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber + FAKeys.Tab);

                    Reports.TestStep = "Second try -- Click on Find Now.";
                    FastDriver.FastViewFileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 30);
                    FastDriver.FastViewFileSearch.WaitForMessagePaneToLoad();
                }

                Reports.TestStep = "Open Workflow window";
                FastDriver.FileSearch.SendControlShift("W"); // Open File Workflow screen

                Reports.TestStep = "Validate Add and Delete buttons are disabled";
                FastDriver.FastViewFileSearch.WaitForScreenToLoad(FastDriver.FileWorkflow.Add);
                Support.AreEqual("True", FastDriver.FileWorkflow.Add.IsDisplayed().ToString(), true);
                Support.AreEqual("True", FastDriver.FileWorkflow.Delete.IsDisplayed().ToString(), true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0097_REG0007
        [TestMethod]
        public void FMUC0097_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM7921  Menu options on 2nd Instance";

                #region Credentials
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file.";
                string fileNumber = CreateBasicFileWithSpecifiedGAB("HUDFLINSR1");
                System.Threading.Thread.Sleep(10000); // Wait for file to show up on search result

                try
                {
                    Reports.TestStep = "Click on Fast View.";
                    FastDriver.TopFrame.WaitForScreenToLoad();
                    FastDriver.TopFrame.FastView.FAClick();

                    Reports.TestStep = "Enter file Number to Search From Fast View.";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Country.FASelectItem("USA");
                    FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber + FAKeys.Tab);

                    Reports.TestStep = "Click on Find Now.";
                    FastDriver.FastViewFileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 30);
                    FastDriver.FastViewFileSearch.WaitForMessagePaneToLoad();
                    FastDriver.WebDriver.Manage().Window.Maximize();
                }
                catch (Exception)
                {
                    FastDriver.WebDriver.Close(); // Close the FAST View window
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 30);

                    Reports.TestStep = "Second try -- Click on Fast View.";
                    FastDriver.TopFrame.WaitForScreenToLoad();
                    FastDriver.TopFrame.FastView.FAClick();

                    Reports.TestStep = "Second try -- Enter file Number to Search From Fast View.";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 200);
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Country.FASelectItem("USA");
                    FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber + FAKeys.Tab);

                    Reports.TestStep = "Second try -- Click on Find Now.";
                    FastDriver.FastViewFileSearch.FindNow.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 30);
                    FastDriver.FastViewFileSearch.WaitForMessagePaneToLoad();
                    FastDriver.WebDriver.Manage().Window.Maximize();
                }

                Reports.TestStep = "Open File Summary screen";
                FastDriver.FileSearch.SendControlShift("I"); // Open File Summary screen

                Reports.TestStep = "Validate the Basic File Details from File Summary screen";
                FastDriver.FileSummary.WaitForFastViewScreenToLoad(FastDriver.FileSummary.FileNumber);
                Support.AreEqual(fileNumber, FastDriver.FileSummary.FileNumber.FAGetText());

                Reports.TestStep = "Open Event/Tracking Log screen";
                FastDriver.FileSearch.SendControlShift("E");

                Reports.TestStep = "Validate file event [Opened]";
                FastDriver.FileSummary.WaitForFastViewScreenToLoad(FastDriver.EventTrackingLog.EventTable);
                Support.AreEqual("[Opened]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(4, "FAST Application", 1, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Open File Notes screen";
                FastDriver.FileSearch.SendControlShift("N");

                Reports.TestStep = "Validate file Notes";
                FastDriver.FileSummary.WaitForFastViewScreenToLoad(FastDriver.FileNotes.Table);
                Support.AreEqual("Test File Note", FastDriver.FileNotes.Table.PerformTableAction(2, 1, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Open File Balance Summary Screen screen";
                FastDriver.FileSearch.SendControlShift("B");

                Reports.TestStep = "Validate Escrow File Balance Summary screen is loaded";
                FastDriver.FileSummary.WaitForFastViewScreenToLoad(FastDriver.EscrowFileBalanceSummary.FileBalance);
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());

                Reports.TestStep = "Open View Settlement Statement screen";
                FastDriver.FileSearch.SendControlShift("S");

                try
                {
                    Reports.TestStep = "Validate View Settlement Statement screen is loaded";
                    FastDriver.FileSummary.WaitForFastViewScreenToLoad(FastDriver.ViewSettlementStatement.PrintDeliver);
                    Support.AreEqual("True", FastDriver.ViewSettlementStatement.PrintDeliver.IsDisplayed().ToString(), true);
                }
                catch
                {
                    Reports.TestStep = "Second Try - Open View Settlement Statement screen";
                    FastDriver.FileSearch.SendControlShift("S");
                    Reports.TestStep = "Validate View Settlement Statement screen is loaded";
                    FastDriver.FileSummary.WaitForFastViewScreenToLoad(FastDriver.ViewSettlementStatement.PrintDeliver);
                    Support.AreEqual("True", FastDriver.ViewSettlementStatement.PrintDeliver.IsDisplayed().ToString(), true);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion REG

        #region Private Methods
        private string CreateBasicFileWithSpecifiedGAB(string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };
            customizableFileRequest.File.FileNotes = new FileNote[] 
                    { 
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Test File Note"
                        }
                    };
            
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            
            return File.FileNumber;
        }


        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}