﻿using FASTSelenium.Common;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagement.Tutorial
{
    [CodedUITest]
    public class exercise1 : MasterTestClass
    {
        [TestMethod]
        [Description("Create new basic file in FAST")]
        public void testcase_809107()
        {
            try
            {
                Reports.TestDescription = "Create new basic file in FAST";

                #region FAST Login IIS
                Reports.TestStep = "FAST Login IIS";
                SlaveTestClass.FAST_Login_IIS();
                #endregion

                #region Navigate to Quick File Entry screen
                Reports.TestStep = "Navigate to Quick File Entry screen";
                FastDriver.DuplicateFileSearch.Open();
                #endregion

                #region Click on Skip button
                Reports.TestStep = "Click on Skip button";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                #endregion

                #region Set up Business Source with GAB code = BOA
                Reports.TestStep = "Set up Business Source with GAB code = BOA";
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("BOA");
                #endregion

                #region Define Services: Title + Escrow | Transaction Type: Sale w/Mortgage | Form Type: CD
                Reports.TestStep = "Define Services: Title + Escrow | Transaction Type: Sale w/Mortgage | Form Type: CD";
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                #endregion

                #region Set up Property Address State: CA
                Reports.TestStep = "Set up Property Address State: CA";
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                #endregion

                #region Click on Save/Done button
                Reports.TestStep = "Click on Save/Done button";
                FastDriver.BottomFrame.Save();
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                #endregion

                #region Validate information in Quick File Entry/File Homepage screen
                Reports.TestStep = "Validate information in Quick File Entry/File Homepage screen";
                FastDriver.FileHomepage.Open();
                Support.AreEqual("BOA", FastDriver.FileHomepage.BusinessPartyIDCodeField.FAGetText(), "GAB Code Label");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.Title.IsEnabled().ToString(), "Title Service button state");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.Escrow.IsEnabled().ToString(), "Excrow Service button state");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.Title.GetAttribute("checked").ToUpperFirst(), "Title Service selected");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.Escrow.GetAttribute("checked").ToUpperFirst(), "Escrow Service selected");
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem(), "Transaction Type");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.FormTypeCD.IsEnabled().ToString(), "Form Type CD radiobutton state");
                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.FormTypeCD.GetAttribute("selected").ToUpperFirst(), "Form Type CD selected");
                Support.AreEqual(false.ToString(), FastDriver.FileHomepage.PropertyState.IsEnabled().ToString(), "Property State enabled");
                Support.AreEqual("CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem(), "Property State");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() 
        {
            SlaveTestClass.CloseRelatedProcesses();
            MasterTestClass.CleanupClass(); 
        }
    }
}
