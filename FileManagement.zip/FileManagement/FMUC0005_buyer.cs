﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;

using System;

using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers.Factories;
using System.Collections.Generic;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers;
using System.Linq;
using OpenQA.Selenium;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;
using System.Threading;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0005_Buyer : FASTHelpers
    {

        #region Class Level Objects
        Dictionary<string, string> PropertDictry = new Dictionary<string, string>();
        Dictionary<string, string> ByrDtlstDictry = new Dictionary<string, string>();
        Dictionary<string, string> SelrDtlstDictry = new Dictionary<string, string>();
        Dictionary<string, string> IndvidByrDictry = new Dictionary<string, string>();
        Dictionary<string, string> HuWfAndVestDictry = new Dictionary<string, string>();
        Dictionary<string, string> VestiNSalutDictry = new Dictionary<string, string>();
        Dictionary<string, string> CurAddrDictry = new Dictionary<string, string>();
        Dictionary<string, string> ForwdAdrDictry = new Dictionary<string, string>();
        Dictionary<string, string> CurrPhoDictry = new Dictionary<string, string>();
        Dictionary<string, string> ForwdPhoDictry = new Dictionary<string, string>();
        Dictionary<string, string> AkaDictry = new Dictionary<string, string>();
        Dictionary<string, string> TrstEstByrDictry = new Dictionary<string, string>();
        Dictionary<string, string> BusEntByrDictry = new Dictionary<string, string>();
        Dictionary<string, string> EnablStatsDictry = new Dictionary<string, string>();
        Dictionary<string, string> BusPartyOrgSetUpDictry = new Dictionary<string, string>();

        Dictionary<int, string> MultiColDictry = new Dictionary<int, string>();
        List<Object> DictioList = new List<Object>();
        string ErrsOccredMsg = "Error(s) occured. See Message pane.";

        #endregion

        #region BAT Methods

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0001()
        {
            try
            {

                #region Login And Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                #endregion


                Reports.TestDescription = "MF1: Create Individual Buyer.";
                Reports.TestStep = "Store the data of from file home page and match with other screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                PropertDictry = FastDriver.FileHomepage.GetPropDetails;

                Reports.TestStep = "Enter Buyer details for Individual type.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                BuyerParameters buyer = new BuyerParameters()
                {
                    First = "BuyerFirstName",
                    Middle = "BuyerMiddleName",
                    Last = "BuyerLastName",
                    Suffix = "sufix",
                    SSN = "123-45-6789",
                    IndivdAuthorzdNam = "Buyersign",
                    MaritalStatus = "a single man",
                    Vesting = "as community property",
                    AdditionalVesting = "Additional Vesting",
                    MiscReference1 = "Misc Ref 1",
                    MiscReference2 = "Misc Ref 2",
                    CurrentPhoneNumber = "(991)889-8383",
                    ForwardingPhoneNum = "(991)889-8383"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");

                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);

                Reports.TestStep = "Validate for buyer details for individual.";
                IndvidByrDictry = FastDriver.BuyerSellerSetup.GetIndivByrDtls;
                Support.AreEqual("BuyerFirstName", IndvidByrDictry["Indi First Name"], "Indi First Name");
                Support.AreEqual("BuyerMiddleName", IndvidByrDictry["Indi Middle Name"], "Indi Middle Name");
                Support.AreEqual("BuyerLastName", IndvidByrDictry["Indi Last Name"], "Indi Last Name");
                Support.AreEqual("sufix", IndvidByrDictry["Indi Sufix"], "Indi Sufix");
                Support.AreEqual("123-45-6789", IndvidByrDictry["Indi Ssn"], "Indi Ssn");

                VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;
                Support.AreEqual("a single man", VestiNSalutDictry["Marital Status"], "Marital Status");
                Support.AreEqual("as community property", VestiNSalutDictry["Vesting"], "Vesting");
                Support.AreEqual("Additional Vesting", VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
                Support.AreEqual("Misc Ref 1", VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
                Support.AreEqual("Misc Ref 2", VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");

                Reports.TestStep = "Validate for current address - Individual Buyer details.";
                FastDriver.BuyerSellerSetup.CurrAddrSetToProp();

                CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
                Support.AreEqual(PropertDictry["PropertyBookAddressLine1"], CurAddrDictry["Curr Addr Street 1"], "Curr Addr Street 1");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine2"], CurAddrDictry["Curr Addr Street 2"], "Curr Addr Street 2");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine3"], CurAddrDictry["Curr Addr Street 3"], "Curr Addr Street 3");
                Support.AreEqual(PropertDictry["PropertyAddressBookCity"], CurAddrDictry["Curr Addr City"], "Curr Addr City");
                Support.AreEqual(PropertDictry["PropertyState"], CurAddrDictry["Curr Addr State"], "Curr Addr State");
                Support.AreEqual(PropertDictry["PropertyCounty"], CurAddrDictry["Curr Addr County"], "Curr Addr County");
                Support.AreEqual(PropertDictry["PropertyCountry"], CurAddrDictry["Curr Addr Country"], "Curr Addr Country");

                Reports.TestStep = "Validate for forward address - Individual Buyer details.";
                ForwdAdrDictry = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
                Support.AreEqual(PropertDictry["PropertyBookAddressLine1"], ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine2"], ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine3"], ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
                Support.AreEqual(PropertDictry["PropertyAddressBookCity"], ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
                Support.AreEqual(PropertDictry["PropertyState"], ForwdAdrDictry["Forward Addr State"], "Forward Addr State");
                Support.AreEqual(PropertDictry["PropertyCountry"], ForwdAdrDictry["Forward Addr Country"], "Forward Addr Country");
                Support.AreEqual(PropertDictry["PropertyCounty"], ForwdAdrDictry["Forward Addr County"], "Forward Addr County");

                CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrPhDtls();
                Support.AreEqual("(991)889-8383", CurrPhoDictry["CurrentPhoneNum"], "Current PhoneNum");
                ForwdPhoDictry = FastDriver.BuyerSellerSetup.GetForwdPhDtls;
                Support.AreEqual("(991)889-8383", ForwdPhoDictry["Forwarding PhoneNum"], "Forwarding PhoneNum");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the contact name in Buyer summary screen.";
                this.NavigateActOnBuyr(3, "Buyersign", 1, "", "", 1);

                Reports.TestStep = "Validate the exchange company in Buyer summary screen.";
                this.NavigateActOnBuyr(7, "Exchange Company1 Name 1", 1, "", "", 1);

                Reports.TestStep = "Remove buyer of type husband wife if exists. (To verify full vesting for individual buyer)";
                this.NavigateActOnBuyr(1, "2", 1, "Clear", "", 1);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Get buyers data to validate full vesting";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                string[] TArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Set buyer individual details";
                FastDriver.FileHomepage.SwitchToContentFrame();
                buyer = new BuyerParameters()
                {
                    First = "BuyerFirstChange",
                    Middle = "BuyerMiddleChange",
                    Last = "BuyerLastChange",
                    Suffix = "sufxch",
                    SSN = "888-45-9999",
                    MaritalStatus = "a married man",
                    Vesting = "as joint tenants",
                    AdditionalVesting = "Additional vestin",
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                Reports.TestStep = "Capturing the modified data from Vesting fields";
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                string[] TArrTwo = FastDriver.BuyerVesting.GetAllFieldsValues();

                Reports.TestStep = "Comparing old and new values";
                Assert.AreNotEqual(TArrTwo[0], TArrOne[0]);
                Assert.AreNotEqual(TArrTwo[1], TArrOne[1]);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0002()
        {
            {
                try
                {
                    Reports.TestDescription = "AF11_AF4: 1.View or Modify Buyer SSN/TIN data 2.Edit Non-Sensitive Buyer Information for any Buyer Type.";

                    #region Data Setup And Pre-requisite
                    this.LoginToFast();
                    try
                    {
                        this.CreateFileWithWebSer();
                    }
                    catch (Exception e)
                    {
                        this.CreateFileWithGui();
                        Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                    }

                    FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                    FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                    FastDriver.BuyerSellerSummary.Edit();
                    BuyerParameters buyer = new BuyerParameters()
                    {
                        SSN = "888-45-9999"
                    };
                    FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                    FastDriver.BottomFrame.Done();
                    //Pre-requisite ends here............
                    #endregion

                    Reports.TestStep = "Verifying for[SSN/TIN View] Event";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                    FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                    FastDriver.EventTrackingLog.VerifyEventTableData(2, 1, "[SSN/TIN View]");

                    Reports.TestStep = "Change SSN number and edit non sensitive information.";
                    this.NavigateActOnBuyr(1, "1", 1, "Edit");
                    buyer = new BuyerParameters()
                    {
                        SSN = "413-45-6759"
                    };
                    FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                    Reports.TestStep = "Verifying for[SSN/TIN Edit] Event";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                    FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                    FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[SSN/TIN Edit]");
                }
                catch (Exception ex)
                {
                    FailTest(ex.Message);
                }
            }

        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF1_02: 1.Change set to property to others in Current and forwarding address2. Enter AKA name for buyer individual.";

                #region Login And Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                #endregion

                Reports.TestStep = "Set current address to other and set values to forward and current address.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                BuyerParameters buyer = new BuyerParameters()
                {
                    CurrentStreet1 = "Street1",
                    CurrentStreet2 = "Street2",
                    CurrentStreet3 = "Street3",
                    CurrentCity = "Albany",
                    CurrentZip = "97020",
                    CurrentCounty = "Alameda"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
                Support.AreEqual(buyer.CurrentCity, CurAddrDictry["Curr Addr City"], "Curr Addr City");
                Support.AreEqual(buyer.CurrentZip, CurAddrDictry["Curr Addr Zip"], "Curr Addr Zip");
                Support.AreEqual(buyer.CurrentCounty, CurAddrDictry["Curr Addr County"], "Curr Addr County");

                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                buyer = new BuyerParameters()
                {
                    ForwardStreet1 = "Street1",
                    ForwardStreet2 = "Street2",
                    ForwardStreet3 = "Street3",
                    ForwardState = "CA",
                    ForwardCity = "Albany",
                    ForwardZip = "97020",
                    ForwardCounty = "Alameda"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                Reports.TestStep = "Enter AKA name for buyer individual.";
                FastDriver.BuyerSellerSetup.AKA();
                AkaParameters AkaNameVals = new AkaParameters()
                {
                    Aka = "Binfo",
                    UsedAtSigning = true
                };
                FastDriver.AKANames.SetDetails(AkaNameVals);

                Reports.TestStep = "Validate that AKA name is preserved after edit the entity type and individual.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Husband/Wife");
                FastDriver.BuyerSellerSetup.Spouse1_Aka();
                FastDriver.AKANames.SwitchToContentFrame();
                AkaDictry = FastDriver.AKANames.GetDetails;
                Support.AreEqual(AkaNameVals.Aka, AkaDictry["AKA"], "Aka Name");
                Support.AreEqual(AkaNameVals.UsedAtSigning.ToString().ToUpper(), AkaDictry["UsedatSigning"].ToUpper(), "Used At Signing");
                FastDriver.BottomFrame.Done();

            }

            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF1: Create Husband/Wife Buyer.";
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }

                Reports.TestStep = "Clear existing values and Edit";
                this.NavigateActOnBuyr(1, "1", 1, "Clear", "", 1);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);

                Reports.TestStep = "Refresh Vesting details on Buyer Vesting page";
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();



                Reports.TestStep = "Set Vesting details on Buyer Vesting page";
                this.NavigateActOnBuyr(1, "2", 1, "Edit", "", 1);
                BuyerParameters buyer = new BuyerParameters()
                {
                    Husband1FirstName = "Buyer Husband First",
                    Husband2LastName = "Buyer Husband Last",
                    HusbandSpouseFirstName = "Wife First",
                    HusbandSpouseMiddleName = "Wife Middle Name",
                    HusbandSpouseLastName = "Buyer Husband Last",
                    HusbandSpouseSuffix = "Sufix",
                    HusbandSpouse1SSN = "123-34-5678",
                    HusbAuthzSigNam = "HSSign",
                    HusSpous2TrusteNam = "HSSign2",

                    MaritalStatus = "a married man",
                    Vesting = "as community property",
                    AdditionalVesting = "Additional vesting",
                    Salutation = "Dear Mr. & Mrs. Buyer Husband Last",
                    MiscReference1 = "Misc Ref 1",
                    MiscReference2 = "Misc Ref 2",
                    CurrentPhoneNumber = "(991)889-8383",
                    ForwardingPhoneNum = "(991)889-8383"

                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.SwitchToContentFrame();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "validate Buyer with Hus and Wife Type full details.";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                HuWfAndVestDictry = FastDriver.BuyerSellerSetup.GetHusWfDtlsAuthSign();
                VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;
                CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrPhDtls();
                ForwdPhoDictry = FastDriver.BuyerSellerSetup.GetForwdPhDtls;

                Support.AreEqual(buyer.MaritalStatus, VestiNSalutDictry["Marital Status"], "Marital Status");
                Support.AreEqual(buyer.Vesting, VestiNSalutDictry["Vesting"], "Vesting");
                Support.AreEqual(buyer.AdditionalVesting, VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
                Support.AreEqual(buyer.MiscReference1, VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
                Support.AreEqual(buyer.MiscReference2, VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");
                Support.AreEqual(buyer.CurrentPhoneNumber, CurrPhoDictry["CurrentPhoneNum"], "Current PhoneNum");
                Support.AreEqual(buyer.ForwardingPhoneNum, ForwdPhoDictry["Forwarding PhoneNum"], "Forwarding PhoneNum");

                Support.AreEqual(buyer.Husband1FirstName, HuWfAndVestDictry["Husband1FirstName"], "Husband1FirstName");
                Support.AreEqual(buyer.Husband2LastName, HuWfAndVestDictry["Husband2LastName"], "Husband 2 LastName");
                Support.AreEqual(buyer.HusbandSpouseFirstName, HuWfAndVestDictry["HusbandSpouseFirstName"], "HusbandSpouse FirstName");
                Support.AreEqual(buyer.HusbandSpouseMiddleName, HuWfAndVestDictry["HusbandSpouseMiddleName"], "HusbandSpouse MiddleName");
                Support.AreEqual(buyer.HusbandSpouseLastName, HuWfAndVestDictry["HusbandSpouseLastName"], "HusbandSpouse LastName");
                Support.AreEqual(buyer.HusbandSpouseSuffix, HuWfAndVestDictry["HusbandSpouseSuffix"], "HusbandSpouse Suffix");

                Reports.TestStep = "Validate exchange company for Husband and wife in summary screen.";
                this.NavigateActOnBuyr(7, "Exchange Company1 Name 1", 1, "", "", 1);
                Reports.TestStep = "Validate full vesting";
                this.NavigateActOnBuyr(1, "2", 1, "Edit", "", 1);


                Reports.TestStep = "Get buyers data to validate full vesting";
                string[] HusWifeDetails = FastDriver.BuyerSellerSetup.FormtHusWfDtlsAsStr();
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                string[] VestFieldValues = FastDriver.BuyerVesting.GetAllFieldsValues();
                string One = HusWifeDetails[1].Trim();
                string TwoO = VestFieldValues[1].Trim();
                Support.AreEqual(HusWifeDetails[0].Trim(), VestFieldValues[0].Trim());

                Support.AreEqual(HusWifeDetails[1].Trim(), VestFieldValues[1].Trim());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Refresh functionality in full vesting";
                this.NavigateActOnBuyr(1, "2", 1, "Edit", "", 1);
                buyer = new BuyerParameters()
                {
                    Husband1FirstName = "Husband/Wife Husband Firs",
                    Husband2LastName = "Husband/Wife Husband Las",
                    HusbandSpouseFirstName = "Wife Firs",
                    HusbandSpouseMiddleName = "Wife Middle Nam",
                    HusbandSpouseLastName = "Husband/Wife Husband Las",
                    HusbandSpouseSuffix = "Sfix",
                    HusbandSpouse1SSN = "123-34-5678",
                    MaritalStatus = "a married woman",
                    Vesting = "as joint tenants",
                    AdditionalVesting = "Additional vestin"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                string[] RefreshedData = FastDriver.BuyerSellerSetup.FormtHusWfDtlsAsStr();
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                VestFieldValues = FastDriver.BuyerVesting.GetAllFieldsValues();

                Support.AreEqual(RefreshedData[0], VestFieldValues[0]);
                Support.AreEqual(RefreshedData[1], VestFieldValues[1]);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF2_AF12: 1.Create Trust/Estate Buyer 2.Additional Role Buyer Type is Trust /Estate.";
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }

                BuyerParameters buyer = new BuyerParameters()
                {
                    TrusteeShortNameTwo = "Trust",
                    TrustAuthorizedName = "Trust",
                    TrustDated = "07-10-2012",
                    TrustNumber = "12345678",
                    TrustAuthorizedType = "Other",
                    TrustTitle = "trustTitle",
                    TrustTin = true,
                    Salutation = "Trust",
                    MiscReference1 = "Misc Ref1",
                    MiscReference2 = "Misc Ref2",
                    CurrentStreet1 = "Street1",
                    CurrentStreet2 = "Street2",
                    CurrentStreet3 = "Street3",
                    CurrentCity = "Albany",
                    CurrentZip = "97020",
                    CurrentCounty = "Alameda",
                    CurrentPhoneNumber = "(991)889-8383",
                    ForwardingPhoneNum = "(991)889-8383"
                };
                this.CreateTrustEstBuyr(buyer);
                FastDriver.BuyerSellerSetup.Trust_Tin();
                BuyerParameters buyerTwo = new BuyerParameters()
                {
                    TrustSsnText = "12-3124231",
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyerTwo);

                FastDriver.BuyerSellerSetup.Trust_Tin();
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.SwitchToContentFrame();
                this.EntrDetlsExchCmp("EXCH01");

                Reports.TestStep = "Validate exchange company for Trust Estate in summary screen.";
                this.NavigateActOnBuyr(7, "Exchange Company1 Name 1", 1, "", "", 1);

                Reports.TestStep = "Validate Buyer Trustee or Estate with all details.";
                this.NavigateActOnBuyr(4, "Trust/Estate", 1, "Edit", "", 1);
                TrstEstByrDictry = FastDriver.BuyerSellerSetup.GetTrstestByrDtls();
                CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
                CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrPhDtls();
                ForwdPhoDictry = FastDriver.BuyerSellerSetup.GetForwdPhDtls;
                VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetTrustEstVestSalut;
                Support.AreEqual(buyer.TrusteeShortNameTwo, TrstEstByrDictry["TrusteeShortName"], "Trustee Short Name");
                Support.AreEqual(buyer.TrustAuthorizedName, TrstEstByrDictry["TrustAuthorizedName"], "Trust Authorized Name");
                Support.AreEqual(buyer.TrustAuthorizedType, TrstEstByrDictry["TrustAuthorizedType"], "Trust Authorized Type");
                Support.AreEqual(buyer.TrustDated, TrstEstByrDictry["TrustDated"], "Trust Dated");
                Support.AreEqual(buyer.TrustNumber, TrstEstByrDictry["TrustNumber"], "Trust Number");
                Support.AreEqual(buyerTwo.TrustSsnText, TrstEstByrDictry["TrustSSNtext"], "Trust Ssn Text");
                Support.AreEqual(buyer.CurrentStreet1, CurAddrDictry["Curr Addr Street 1"], "Curr Addr Street 1");
                Support.AreEqual(buyer.CurrentStreet2, CurAddrDictry["Curr Addr Street 2"], "Curr Addr Street 2");
                Support.AreEqual(buyer.CurrentStreet3, CurAddrDictry["Curr Addr Street 3"], "Curr Addr Street 3");
                Support.AreEqual(buyer.CurrentCity, CurAddrDictry["Curr Addr City"], "Curr Addr City");
                Support.AreEqual(buyer.CurrentCounty, CurAddrDictry["Curr Addr County"], "Curr Addr County");
                Support.AreEqual(buyer.Salutation, VestiNSalutDictry["Salutation"], "Salutation");
                Support.AreEqual(buyer.MiscReference1, VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
                Support.AreEqual(buyer.MiscReference2, VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");
                Support.AreEqual(buyer.CurrentPhoneNumber, CurrPhoDictry["CurrentPhoneNum"], "Current PhoneNum");
                Support.AreEqual(buyer.ForwardingPhoneNum, ForwdPhoDictry["Forwarding PhoneNum"], "Forwarding PhoneNum");

                Reports.TestStep = "Attorney in Fact' Unavailable for Trust/Estate Buyer/Seller";
                FastDriver.BuyerSellerSetup.Trust_AuthSignNew();
                string ListValues = FastDriver.BuyerSellerSetup.TrustAuthorizedType.FAGetAllTextFromSelect();
                Support.AreEqual("False", ListValues.Contains("Attorney In Fact").ToString());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF3_AF13: 1. Create Business Entity Buyer 2.Additional Role Buyer Type is Business Entity.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                #endregion

                BuyerParameters buyer = new BuyerParameters()
                {

                    BusinessEntityShortname = "Buyer BusEntity Name",
                    StateofIncorp = "Alaska",
                    EntityType = "Business Trust",
                    BusinessEntitySsn = "534-55-3543"
                };
                this.CreateBusEntBuyr(buyer);

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.SwitchToContentFrame();
                this.EntrDetlsExchCmp("EXCH01");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Reports.TestStep = "Validate Buyer Business Entity and enter all details.";
                BusEntByrDictry = FastDriver.BuyerSellerSetup.GetBusEntByrDtls;
                Support.AreEqual(buyer.BusinessEntityShortname, BusEntByrDictry["BusinessEntityShortname"], "Bus Entity Shortname");
                Support.AreEqual(buyer.StateofIncorp, BusEntByrDictry["StateofIncorp"], "State of Incorp");
                Support.AreEqual(buyer.EntityType, BusEntByrDictry["EntityType"], "Entity Type");
                Support.AreEqual(buyer.BusinessEntitySsn, BusEntByrDictry["BusinessEntitySSN"], "Business Entity Ssn");

                Reports.TestStep = "Validate exchange company for Business Entity in summary screen.";
                this.NavigateActOnBuyr(7, "Exchange Company1 Name 1", 1, "", "", 1);

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF5_01: Change Buyer Type from Individual to Husband/Wife: On disbursement.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                #endregion

                Reports.TestStep = "Deposit a cash more than sales price.";
                DepositParameters DepositParams = new DepositParameters()
            {
                Amount = 6000,
                TypeofFunds = "Cash",
                Description = "Sanity Deposit In Escrow",
                Representing = "Additional Closing Costs",
                ReceivedFrom = "Buyer"
            };
                this.DepositCash(DepositParams);
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);
                this.PrintAll();
            
            //try
            //{
            //    FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 300);
            //}
            //catch
            //{
            //    Reports.StatusUpdate("Delivery might be hanging", false);
            //}
                
            //    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Chang the type from Individual to Husband and wife.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                string ExpVal = "A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may change the payee.";
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Husband/Wife"));

                Reports.TestStep = "Create Buyer Individual and validate the data.";
                BuyerParameters buyer = new BuyerParameters()
                {
                    BuyerType = "Individual",
                    First = "Indiv First",
                    Middle = "Indiv Middle",
                    Last = "Indiv Last",
                    Suffix = "Sufx",
                    SSN = "123-45-6789"
                };
                this.CreateIndiBuyr(buyer);
                this.NavigateActOnBuyr(2, buyer.First + " " + buyer.Middle + " " + buyer.Last + " " + buyer.Suffix, 1, "Edit", "", 1);
                Support.AreEqual(buyer.BuyerType, FastDriver.BuyerSellerSetup.RetrieveBuyerType());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF5_02: Change Buyer Type from Individual to Husband/Wife: without Disbursement.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                #endregion

                Reports.TestStep = "Chang the type from Individual to Husband and wife.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Husband/Wife");

                Reports.TestStep = "Validate that individual changed to Husband and wife.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("Husband/Wife", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                HuWfAndVestDictry = FastDriver.BuyerSellerSetup.GetHusWfDtlsAuthSign(false);
                Support.AreEqual("Buyer1Firstname", HuWfAndVestDictry["Husband1FirstName"], "Husband1FirstName");
                Support.AreEqual("Buyer1Lastname", HuWfAndVestDictry["Husband2LastName"], "Husband 2 LastName");
                Support.AreEqual("", HuWfAndVestDictry["HusbandSpouseFirstName"], "HusbandSpouse FirstName");
                Support.AreEqual("", HuWfAndVestDictry["HusbandSpouseMiddleName"], "HusbandSpouse MiddleName");
                Support.AreEqual("Buyer1Lastname", HuWfAndVestDictry["HusbandSpouseLastName"], "HusbandSpouse LastName");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF6_01: Change Buyer Type from Husband/Wife to Individual: Without disbursement.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                #endregion

                Reports.TestStep = "Change from Husband wife to Individual in BAT0009";
                this.NavigateActOnBuyr(1, "2", 1, "Edit", "", 1);
                string InstanceType = @"Individual";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys(InstanceType);
                Playback.Wait(2000);
                string Message = FastDriver.WebDriver.HandleDialogMessage(false).Clean();
                Reports.TestStep = "Validate warning message is as per EWC#4 and Click on Ok button";
                string ExpVal = "Click OK to convert this principal";
                Support.AreEqual(Message, ExpVal);
                Message = FastDriver.WebDriver.HandleDialogMessage(true).Clean();
                Message = Message.Trim().Replace("\n", String.Empty).Replace("\r", " ");
                ExpVal = "Click OK to convert Spouse 1 into individual Otherwise Click Cancel to convert Spouse 2";
                Support.AreEqual(Message, ExpVal);
                //
                Reports.TestStep = "Validate that Husband wife is changed to Individual.";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("Individual", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                IndvidByrDictry = FastDriver.BuyerSellerSetup.GetIndivByrDtls;
                Support.AreEqual("Buyer2Firstname", IndvidByrDictry["Indi First Name"], "Indi First Name");
                string ActVal = IndvidByrDictry["Indi Middle Name"].ToString();
                Support.AreEqual("", ActVal, "Indi Middle Name");
                ActVal = IndvidByrDictry["Indi Last Name"];
                Support.AreEqual("Buyer2Lastname", ActVal, "Indi Last Name");
                ActVal = IndvidByrDictry["Indi Sufix"];
                Support.AreEqual("", ActVal, "Individual Sufix");
                ActVal = IndvidByrDictry["Indi Ssn"];
                Support.AreEqual("", ActVal, "Individual Ssn");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0010()
        {
            try
            {
                Reports.TestDescription = "AF6_02: Change Buyer Type from Husband/Wife to Individual: On disbursement.";

                #region Login and Create Husband and Wife - File
                this.LoginToFast();
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                    fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                    fileRequest.File.Buyers[0].Type = "Husband and Wife";
                    fileRequest.File.Buyers[0].FirstName = "Hus First Name";
                    fileRequest.File.Buyers[0].LastName = "Hus Last Name";
                    fileRequest.File.Buyers[0].SpouseFirstName = "Wife First Name";
                    fileRequest.File.Buyers[0].SpouseLastName = "Wife Last Name";
                    var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Support.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Support.AreEqual("File was not created.", "File was not created.");
                #endregion

                Reports.TestStep = "Deposit a cash more than sales price for BAT0010";
                DepositParameters DepositParams = new DepositParameters()
                {
                    Amount = 6000,
                    TypeofFunds = "Cash",
                    Description = "Sanity Deposit In Escrow",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Buyer"
                };
                this.DepositCash(DepositParams);

                Reports.TestStep = "Click on Cancel button for BAT0010";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Print All Checks for BAT0010";
                this.PrintAll();
                //if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                //{
                //    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                //    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                //    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //}
                //else
                //{ // Password Confirmation
                //    FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                //}
                //FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Change from Husband wife to Individual for BAT0010";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                string ActVal = FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Individual", true);
                ActVal = ActVal.Trim().Replace("\n", String.Empty).Replace("\r", " ");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                string ExpVal = "A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may change the payee.";
                Support.AreEqual(ActVal, ExpVal);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0011()
        {
            try
            {
                Reports.TestDescription = "AF7: Change Buyer Type from Individual to Trust/Estate or Business Entity.";

                #region Login and Create File by Overwriting
                this.LoginToFast();

                try
                {
                    Reports.TestStep = "Create File using web service.";
                    FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                    fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                    fileRequest.File.Buyers[0].Type = "Individual";
                    fileRequest.File.Buyers[0].FirstName = "Buyer1FN";
                    fileRequest.File.Buyers[0].MiddleName = "Buyer1MN";
                    fileRequest.File.Buyers[0].LastName = "Buyer1LN";
                    fileRequest.File.Buyers[0].SSN = "123-45-6789";
                    var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Support.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Support.AreEqual("File was not created.", "File was not created.");

                #endregion

                Reports.TestStep = "Change from Individual to Trust.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                Support.AreEqual("Click OK to convert this principal", FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Trust/Estate"));
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();

                Reports.TestStep = "Validate that Individual changed to Trust entity.";
                Support.AreEqual("Trust/Estate", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetTrustEstVestSalut;
                TrstEstByrDictry = FastDriver.BuyerSellerSetup.GetTrstestByrDtls(false);
                Support.AreEqual("", VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
                Support.AreEqual("", VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");
                Support.AreEqual("Available", TrstEstByrDictry["TrusteeShortName"], "Trustee Short Name");

                Reports.TestStep = "Create Buyer of type Individual in BAT0011";
                BuyerParameters buyer = new BuyerParameters()
                {
                    BuyerType = "Individual",
                    First = "Buyer1FN",
                    Middle = "Buyer1MN",
                    Last = "Buyer1LN",
                    SSN = "123-45-6789",
                };
                this.CreateIndiBuyr(buyer);

                Reports.TestStep = "Deposit a cash more than sales price in BAT0011.";
                DepositParameters DepositParams = new DepositParameters()
                {
                    Amount = 6000,
                    TypeofFunds = "Cash",
                    Description = "Sanity Deposit In Escrow",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Buyer"
                };
                this.DepositCash(DepositParams);
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);
                this.PrintAll();
                //FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                //if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                //{
                //    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                //    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                //    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //}
                //else
                //{ // Password Confirmation
                //    FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                //}
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Reports.TestStep = "Change from Individual to Trust.";
                this.NavigateActOnBuyr(2, buyer.First + " " + buyer.Middle + " " + buyer.Last, 1, "Edit", "", 1);
                FastDriver.WebDriver.HandleDialogMessage(true, false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0012()
        {
            try
            {
                Reports.TestDescription = "AF8: Clear Buyer.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Support.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Support.AreEqual("File was not created.", "File was not created.");

                #endregion

                Reports.TestStep = "1.Navigate to Buyer summary screen.2. delete an instance.";
                this.NavigateActOnBuyr(1, "1", 1, "Clear", "", 1);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "1.Validate that buyer name is replaced by available.";
                this.NavigateActOnBuyr(2, "Available", 1, "", "", 1);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0013()
        {
            try
            {
                Reports.TestDescription = "AF9: Modify Address for Country other than USA or Canada.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Support.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Support.AreEqual("File was not created.", "File was not created.");

                #endregion

                Reports.TestStep = "Create an instance with different Country other than USA and Canada.";
                BuyerParameters buyer = new BuyerParameters()
                {
                    BuyerType = "Individual",
                    First = "BuyerFirstName",
                    Last = "BuyerFirstName",
                    CurrentSetToOthr = true,
                    Suffix = "Sufx",
                    SSN = "123-45-6789",
                    CurrentStreet1 = "Street1",
                    CurrentStreet2 = "Street2",
                    CurrentStreet3 = "Street3",
                    CurrentCountry = "ALBANIA",
                };
                this.CreateIndiBuyr(buyer);
                Reports.TestStep = "Validate that property fields are disabled on select other country.";
                CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
                EnablStatsDictry = FastDriver.BuyerSellerSetup.GetCurAddrEnabld;
                Support.AreEqual(buyer.CurrentStreet1, CurAddrDictry["Curr Addr Street 1"], "Curr Addr Street 1");
                Support.AreEqual(buyer.CurrentStreet2, CurAddrDictry["Curr Addr Street 2"], "Curr Addr Street 2");
                Support.AreEqual(buyer.CurrentStreet3, CurAddrDictry["Curr Addr Street 3"], "Curr Addr Street 3");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr City"], "Curr Addr City");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr State"], "Curr Addr State");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr Zip"], "Curr Addr Zip");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr County"], "Curr Addr County");


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_Buyer_BAT0014()
        {
            try
            {

                Reports.TestDescription = "AF10: Full Vesting.";
                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Support.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Support.AreEqual("File was not created.", "File was not created.");

                #endregion

                Reports.TestStep = "Enter vesting information in Title Production tab.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad().ClickTitleProdTab();
                PropertyAddressParameters PropInfoDtls = new PropertyAddressParameters()
                {
                    Vesting = "BuyerVesting"
                };
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad().FillTitlProdDetls(PropInfoDtls);
                FastDriver.PropertyTaxInfoTitleProd.ClickExcReqInfSave();

                Reports.TestStep = "Validate the Full vest details before edit.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                string[] ArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                string ExpVal = "Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname";
                Support.AreEqual(ExpVal, ArrOne[0]);
                ExpVal = "Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname";
                Support.AreEqual(ExpVal, ArrOne[1]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Full vest details.";
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                BuyerVestingParameters ByrVestg = new BuyerVestingParameters()
                {
                    Names = "Edited Name in Vesting screen",
                    CompleteVesting = "Edited Complete vesting in Vesting screen"
                };
                FastDriver.BuyerVesting.FillFields(ByrVestg);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Full vest details after edit.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                ArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                Support.AreEqual(ByrVestg.Names, ArrOne[0]);
                Support.AreEqual(ByrVestg.CompleteVesting, ArrOne[1]);

                Reports.TestStep = "Click on Copy Title Vest button in vest screen.";
                FastDriver.BuyerVesting.ClickCopyTitlVestg();

                Reports.TestStep = "Validate that vesting information is same as that of Title production.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Title Vesting", true, 5);
                FastDriver.TitleVestingDlg.SwitchToDialogContentFrame();
                ArrOne[0] = FastDriver.TitleVestingDlg.TitleVesting.FAGetValue();
                FastDriver.TitleVestingDlg.Done.FAClick();

                Reports.TestStep = "Validate the Vest information appears as from Copy Title Vest.";
                Support.AreEqual(ArrOne[0], PropInfoDtls.Vesting);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region REG Methods
        [TestMethod]
        public void FMUC0005B_REG0001()
        {
            try
            {

                Reports.TestDescription = "BR_FM324_1972_EW1_607_325_604_2905_FM1973_FM1979: 1. Mandatory Information 2.Indicate Buyer or Seller 3.Indicate Buyer/Seller Type.";
                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");

                #endregion

                Reports.TestStep = "Create Buyer of type Individual.";
                BuyerParameters buyer = new BuyerParameters()
                {
                    BuyerType = "Individual",
                    First = "Buyer1FN",
                    Middle = "Buyer1MN",
                    Last = "Buyer1LN",
                    SSN = "123-45-6789"
                };
                this.CreateIndiBuyr(buyer);

                Reports.TestStep = "Create Buyer with Hus and Wife Type.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                buyer = new BuyerParameters()
                {
                    BuyerType = "Husband/Wife",
                    HusbandSpouseSuffix = "sufix"
                };
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, buyer.BuyerType, false);
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                Reports.TestStep = "Validate error/Warning for mandatory data EWC#1 when Last name for both Husband and wife is not present";
                FastDriver.BottomFrame.Done();
                Support.AreEqual(ErrsOccredMsg, FastDriver.WebDriver.HandleDialogMessage(true, true));
                string ExpVal = "LastName: FirstName or LastName is Required.";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.BuyerSellerError.FAGetText().Trim());

                Reports.TestStep = "FM2118 Default Spouse Last Name on Buyers screen";
                buyer = new BuyerParameters()
                {
                    Husband1FirstName = "Buyer Husband First",
                    Husband2LastName = "Buyer Husband Last",
                    HusbandSpouseFirstName = "Wife First",
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                Support.AreEqual("Buyer Husband Last", FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue().Trim());

                Reports.TestStep = "Enter exchange company details - Reg0001";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Buyer Trustee or Estate.";
                buyer = new BuyerParameters()
                {
                    TrusteeShortNameTwo = "Buyer Trust Name",
                };
                this.CreateTrustEstBuyr(buyer);
                Reports.TestStep = "Enter exchange company details - Reg0001 - Trustee Buyer";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Buyer Trustee";
                this.NavigateActOnBuyr(4, "Trust/Estate", 1, "Edit", "", 1);
                Support.AreEqual("Trust/Estate", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                TrstEstByrDictry = FastDriver.BuyerSellerSetup.GetTrstestByrDtls(false);
                Support.AreEqual(buyer.TrusteeShortNameTwo, TrstEstByrDictry["TrusteeShortName"], "Trustee Short Name");
                Support.AreEqual(buyer.TrusteeShortNameTwo, TrstEstByrDictry["TrusteeName"], "Trustee Name");

                Reports.TestStep = "Create Buyer Business Entity - Reg0001";
                buyer = new BuyerParameters()
                {

                    BusinessEntityShortname = "Buyer BusEntity Name",
                    StateofIncorp = "Alaska",
                    EntityType = "Business Trust",
                    BusinessEntitySsn = "53-4553543"
                };
                this.CreateBusEntBuyr(buyer);
                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.SwitchToContentFrame();
                this.EntrDetlsExchCmp("EXCH01");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();

                Reports.TestStep = "Validate the error warn for mandatory data.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Individual");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("432-42-3424");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "save Changes without Bus Party.";

                Reports.TestStep = "Click on Ok button.";
                Support.AreEqual(ErrsOccredMsg, FastDriver.WebDriver.HandleDialogMessage(true, true));
                buyer = new BuyerParameters()
               {
                   First = "BuyerFirstName",
                   Middle = "BuyerMiddleName",
                   Last = "BuyerLastName"
               };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0002()
        {
            try
            {
                Reports.TestDescription = "BR_FM4209_339_EW3_EW2_605_FM1989: 1.Add, Edit, Delete, View info 2. Change Buyer/Seller Type 3. Delete Buyer or Seller.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");
                #endregion

                Reports.TestStep = "1.Navigate to Buyer summary screen.2. delete an instance.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.SwitchToContentFrame();
                this.EntrDetlsExchCmp("EXCH01");

                this.NavigateActOnBuyr(1, "1", 1, "Clear", "", 1);

                Reports.TestStep = "Delete a buyer instance.";
                string ExpVal = "Are you sure you want to delete Buyer1Firstname  Buyer1Lastname ?";
                Support.AreEqual(ExpVal, FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "Validate the exchange company in Buyer summary screen.";
                MultiColDictry.Add(4, "Individual");
                MultiColDictry.Add(7, "Exchange Company1 Name 1");
                FastDriver.BuyerSellerSummary.VerifyMultplColValues(1, MultiColDictry);

                Reports.TestStep = "Change the type from Individual to Husband and wife.";
                ExpVal = "Click OK to convert this principal";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Husband/Wife"));
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual("Husband/Wife", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                HuWfAndVestDictry = FastDriver.BuyerSellerSetup.GetHusWfDtlsAuthSign(false);
                Support.AreEqual("Buyer1Firstname", HuWfAndVestDictry["Husband1FirstName"], "Husband1 First Name");
                Support.AreEqual("Buyer1Lastname", HuWfAndVestDictry["Husband2LastName"], "Husband 2 Last Name");
                Support.AreEqual("", HuWfAndVestDictry["HusbandSpouseFirstName"], "HusbandSpouse First Name");
                Support.AreEqual("", HuWfAndVestDictry["HusbandSpouseMiddleName"], "HusbandSpouse MiddleName");
                Support.AreEqual("Buyer1Lastname", HuWfAndVestDictry["HusbandSpouseLastName"], "HusbandSpouse LastName");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_FM770_2907_2070_334_627_628_608: Validate all functionality related to Trust entity.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");
                #endregion

                Reports.TestStep = "Select Current Address in Set to Other in Current and edit the address.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                FastDriver.BuyerSellerSetup.ForwdAddrSetToPropty();
                BuyerParameters buyer = new BuyerParameters()
                {
                    CurrentStreet1 = "#",
                    CurrentStreet2 = "Street1Other",
                    CurrentStreet3 = "Street2Other",
                    CurrentCity = "#",
                    CurrentCounty = "#"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                Reports.TestStep = "Validate the buyer as Husband and wife in summary screen.";
                this.NavigateActOnBuyr(1, "2", 1, "Edit", "", 1);

                Reports.TestStep = "Select Forward address to Set to Currents.";
                FastDriver.BuyerSellerSetup.ForwdAddrSetToCurr();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate multiple husband and wife in summary screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                buyer = new BuyerParameters()
                {
                    BuyerType = "Husband/Wife",
                    Husband1FirstName = "Buyer Husband First",
                    Husband2LastName = "Buyer Husband Last",
                    HusbandSpouseFirstName = "Wife First",
                };
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "Buyer Husband First Buyer Husband Last /Wife First Buyer Husband Last", 1, TableAction.Click, "", 1);

                Reports.TestStep = "Create Buyer Trustee or Estate and enter all details.";
                buyer = new BuyerParameters()
               {

                   Salutation = "Trust",
                   MiscReference1 = "Misc Ref1",
                   MiscReference2 = "Misc Ref2",
                   CurrentStreet1 = "Street1",
                   CurrentStreet2 = "Street2",
                   CurrentStreet3 = "Street3",
                   CurrentCity = "Albany",
                   CurrentZip = "97020",
                   CurrentCounty = "Alameda",
                   CurrentPhoneNumber = "(991)889-8383",
                   ForwardingPhoneNum = "(991)889-8383",
                   TrusteeShortNameTwo = "Buyer Trust Name",
                   TrustDated = "07-10-2012",
                   TrustNumber = "12345678",
               };
                this.CreateTrustEstBuyr(buyer);
                FastDriver.BuyerSellerSetup.Trust_Tin();
                BuyerParameters BuyerTwo = new BuyerParameters()
                {
                    TrustSsnText = "12-3124231",
                    TrustAuthorizedName = "Trust",
                    TrustAuthorizedType = "Other",
                    TrustTitle = "trustTitle"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(BuyerTwo);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.SwitchToContentFrame();
                this.EntrDetlsExchCmp("EXCH01");

                Reports.TestStep = "Enter Full vest details.";
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                BuyerVestingParameters ByrVestg = new BuyerVestingParameters()
                {
                    Names = "Edited Name in Vesting screen",
                    CompleteVesting = "Edited Complete vesting in Vesting screen"
                };
                FastDriver.BuyerVesting.FillFields(ByrVestg);
                FastDriver.BottomFrame.Done();

                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                string[] ArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                Support.AreEqual(ByrVestg.Names, ArrOne[0]);
                Support.AreEqual(ByrVestg.CompleteVesting, ArrOne[1]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Buyer Trustee or Estate with all details.";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual("Trust/Estate", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetTrustEstVestSalut;
                CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
                TrstEstByrDictry = FastDriver.BuyerSellerSetup.GetTrstestByrDtls();

                Support.AreEqual(buyer.Salutation, VestiNSalutDictry["Salutation"], "Salutation");
                Support.AreEqual(buyer.MiscReference1, VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
                Support.AreEqual(buyer.MiscReference2, VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");

                Support.AreEqual(buyer.CurrentStreet1, CurAddrDictry["Curr Addr Street 1"], "Curr Addr Street 1");
                Support.AreEqual(buyer.CurrentStreet2, CurAddrDictry["Curr Addr Street 2"], "Curr Addr Street 2");
                Support.AreEqual(buyer.CurrentStreet3, CurAddrDictry["Curr Addr Street 3"], "Curr Addr Street 3");
                Support.AreEqual(buyer.CurrentCity, CurAddrDictry["Curr Addr City"], "Curr Addr City");
                Support.AreEqual(buyer.CurrentZip, CurAddrDictry["Curr Addr Zip"], "Curr Addr Zip");
                Support.AreEqual(buyer.CurrentCounty, CurAddrDictry["Curr Addr County"], "Curr Addr County");

                Support.AreEqual(buyer.TrusteeShortNameTwo, TrstEstByrDictry["TrusteeShortName"], "Trustee Short Name");
                Support.AreEqual(buyer.TrustDated, TrstEstByrDictry["TrustDated"], "Trust Dated");
                Support.AreEqual(buyer.TrustNumber, TrstEstByrDictry["TrustNumber"], "Trust Number");

                Reports.TestStep = "Validate first phone type as Home and second as Business for buyer as Individual.";
                this.NavigateActOnBuyr(4, "Individual", 1, "Edit", "", 1);
                Support.AreEqual("Home Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem());
                Support.AreEqual("Business Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem());

                Reports.TestStep = "Validate that Set to current is disabled in forward address when set to property is selected in Current Address.";
                EnablStatsDictry = FastDriver.BuyerSellerSetup.GetForwdAddrEnabld;
                Support.AreEqual("True", EnablStatsDictry["Forward Addr SetToCurrent"], "Forward Addr SetToCurrent");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr Street 1"], "Forward Addr Street 1");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr Street 2"], "Forward Addr Street 2");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr Street 3"], "Forward Addr Street 3");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr City"], "Forward Addr City");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr State"], "Forward Addr State");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr County"], "Forward Addr County");

                Reports.TestStep = "Validate error/Warning for mandatory data";
                this.NavigateActOnBuyr(4, "Trust/Estate", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.ClearTrusteeShortNam();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                Support.AreEqual(ErrsOccredMsg, FastDriver.WebDriver.HandleDialogMessage(true, true));
                string ExpVal = "Trust Name is Required!";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.BuyerSellerError.FAGetText().Trim());
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Buyer Trust Name");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_FM768_TFS3449_2915: Default max char Short Name-Expected failure for trust name, FM609: Change TIN To SSN";
                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");

                #endregion

                Reports.TestStep = "Enter more than 80 character in Trust entity and tab out";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Trust/Estate");
                CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrPhDtls();
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneNum"], "Current PhoneNum");
                Support.AreEqual("", CurrPhoDictry["CurrentHomePhoneNumExtn"], "Current PhoneNum Extn");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneFive"], "Current Bus Fax");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneFiveExtn"], "CurrentBusFaxExtn");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneSeven"], "Current E-Mail");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneFour"], "CurrentCellular");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneFourExtn"], "CurrentCellularExtn");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneThree"], "CurrentPager");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneThreeExtn"], "CurrentPagerExtn");

                FastDriver.BuyerSellerSetup.ClearTrusteeShortNam();
                string MoreThan81Chars = "enter more than eighty characters in the short name text field. Enter more and more...";
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText(MoreThan81Chars);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FireEvent("onchange");

                Reports.TestStep = "Validate that the first forty is present in trust short name";
                Support.AreEqual("Trust/Estate", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                string ExpVal = "enter more than eighty characters in the short name text field. Enter more and m";
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue());

                Reports.TestStep = "FM609 - Change from SSN to TIN for Trust/Estate";
                FastDriver.BuyerSellerSetup.Trust_Ssn();
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("111111111");
                FastDriver.BuyerSellerSetup.TrustSsn_TabOut();
                Support.AreEqual("111-11-1111", FastDriver.BuyerSellerSetup.TrustSSNtext.FAGetValue());
                FastDriver.BuyerSellerSetup.Trust_Tin();
                Support.AreEqual("11-1111111", FastDriver.BuyerSellerSetup.TrustSSNtext.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter more than 80 character in Business entity and tab out";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Business Entity");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText(MoreThan81Chars);
                FastDriver.BuyerSellerSetup.BusEntyShrtNam_TabOut();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FireEvent("onchange");

                Reports.TestStep = "Validate that the first forty is present in Business entity short name";
                Support.AreEqual("Business Entity", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAGetValue());

                Reports.TestStep = "FM609 - Change from SSN to TIN for business entity";
                FastDriver.BuyerSellerSetup.BusEnty_Ssn();
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("111111111");
                FastDriver.BuyerSellerSetup.BusEntySsn_TabOut();
                Support.AreEqual("111-11-1111", FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue());
                FastDriver.BuyerSellerSetup.BusEnty_Tin();
                Support.AreEqual("11-1111111", FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0005()
        {
            try
            {
                Reports.TestDescription = "BR_FM2909_2911_2913_2914_335_621_620_FM2906_FM595: Validate all functionality related to business entity";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    Reports.TestStep = "Create File using web service by overwriting some values";
                    FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                    fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                    var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");
                #endregion



                BuyerParameters buyer = new BuyerParameters()
                {
                    BusinessEntityShortname = "Buyer BusEntity Name",
                    StateofIncorp = "Alaska",
                    EntityType = "Business Trust",
                    BusinessEntitySsn = "53-4553543"
                };
                this.CreateBusEntBuyr(buyer);
                this.NavigateActOnBuyr(4, "BusinessEntity", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                BuyerVestingParameters ByrVestg = new BuyerVestingParameters()
                {
                    Names = "Edited Name in Vesting screen",
                    CompleteVesting = "Edited Complete vesting in Vesting screen"
                };
                FastDriver.BuyerVesting.FillFields(ByrVestg);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Buyer Business Entity and enter all details.";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual("Business Entity", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                BusEntByrDictry = FastDriver.BuyerSellerSetup.GetBusEntByrDtls;
                Support.AreEqual("Buyer BusEntity Name", BusEntByrDictry["BusinessEntityShortname"], "Bus Entity Shortname");
                Support.AreEqual("Alaska", BusEntByrDictry["StateofIncorp"], "State of Incorp");
                Support.AreEqual("Business Trust", BusEntByrDictry["EntityType"], "Entity Type");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter more than 40 characters to Trust Estate name.";
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Trust/Estate");
                CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrPhDtls();
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneNum"], "Current PhoneNum");
                Support.AreEqual("", CurrPhoDictry["CurrentHomePhoneNumExtn"], "Current PhoneNum Extn");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneFive"], "Current Bus Fax");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneFiveExtn"], "CurrentBusFaxExtn");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneFour"], "CurrentCellular");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneFourExtn"], "CurrentCellularExtn");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneThree"], "CurrentPager");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneThreeExtn"], "CurrentPagerExtn");
                Support.AreEqual("", CurrPhoDictry["CurrentPhoneSeven"], "Current E-Mail");



                FastDriver.BuyerSellerSetup.ClearTrusteeShortNam();
                string MoreThan81Chars = "enter more than eighty characters in the short name text field. Enter more and more...";
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText(MoreThan81Chars);
                FastDriver.BuyerSellerSetup.TrusteeShortName_TabOut();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FireEvent("onchange");

                Reports.TestStep = "Validate that Default max char Short Name.";
                string ExpVal = "enter more than eighty characters in the short name text field. Enter more and m";
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue());

                Reports.TestStep = "Validate that trust Estate name is preserved.";
                FastDriver.BuyerSellerSetup.ClearTrusteeShortNam();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Edit trust shortname");
                FastDriver.BuyerSellerSetup.TrusteeShortName_TabOut();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FireEvent("onchange");
                FastDriver.BuyerSellerSetup.TrusteeName.FAClick();
                Support.AreNotEqual("Edit trust shortname", FastDriver.BuyerSellerSetup.TrusteeName.FAGetValue());

                Reports.TestStep = "Validate first phone type as Home and second as Business for buyer as Trust Estate.";
                this.NavigateActOnBuyr(4, "Trust/Estate", 1, "Edit", "", 1);
                Support.AreEqual("Home Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem());
                Support.AreEqual("Business Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem());

                Reports.TestStep = "Enter more than 40 characters to Business Entity name.";
                this.NavigateActOnBuyr(4, "BusinessEntity", 1, "Edit", "", 1);

                ExpVal = "enter more than 40 characters allowed in the Trust name";
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText(ExpVal);
                FastDriver.BuyerSellerSetup.BusEntyShrtNam_TabOut();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FireEvent("onchange");

                Reports.TestStep = "Validate first phone type as Business and second as Business Fax for buyer as Business Entity.";
                Support.AreEqual("Business Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem());
                Support.AreEqual("Business Fax", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem());

                Reports.TestStep = "Validate error/Warning for mandatory data for Business Entity";
                this.NavigateActOnBuyr(4, "BusinessEntity", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.ClearBusEntyShortName();
                FastDriver.BottomFrame.Done();
                Support.AreEqual(ErrsOccredMsg, FastDriver.WebDriver.HandleDialogMessage(true, true));
                ExpVal = "Business Entity: A business entity name must be entered.";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.BuyerSellerError.FAGetText().Trim());
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Bus ent shortname");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR_622_4290_4291_FM1975_FM4284_FM336_FM4287_FM618: Entity Authorized Signature.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");

                #endregion

                Reports.TestStep = "Creating Business Entity";
                BuyerParameters buyer = new BuyerParameters()
                {
                    BusinessEntityShortname = "Buyer BusEntity Name",
                    StateofIncorp = "Alaska",
                    EntityType = "Business Trust",
                    BusinessEntitySsn = "53-4553543"
                };
                this.CreateBusEntBuyr(buyer);
                this.NavigateActOnBuyr(4, "BusinessEntity", 1, "Edit", "", 1);
                string ExpVal = "enter more than 40 characters allowed in the Trust name";
                FastDriver.BuyerSellerSetup.ClearBusEntyShortName();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText(ExpVal);
                FastDriver.BuyerSellerSetup.BusEntyShrtNam_TabOut();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FireEvent("onchange");

                Reports.TestStep = "Click on Signature button.";
                FastDriver.BuyerSellerSetup.Signatures.FAClick();
                FastDriver.BuyerSellerEntitySignatures.WaitForScreenToLoad();
                BuyrSellrEntySignParameters parms = new BuyrSellrEntySignParameters()
                {
                    NameofEntity = "Business Entity",
                    EntityType = "Business Trust",
                    StateOfIncorp = "Alaska",
                    AuthSignsNameOne = "Business Authorized Signature",
                    AuthSignsCorpTitleOne = "Corp Title",
                    ByNameOfEntity = "Entity Name",
                    ByStateOfIncorp = "Alaska",
                    ByEntityType = "Business Trust",
                    ByContactName = "Contact Name",
                    ByEntyAuthSignName = "Entity Authorized Signature Name",
                    ByEntyAuthSignTitlCorp = "Entity Authorized Signature Title Corp",

                };
                FastDriver.BuyerSellerEntitySignatures.NameofEntity.FASetText(parms.NameofEntity);
                FastDriver.BuyerSellerEntitySignatures.StateOfIncorp.FASelectItem(parms.StateOfIncorp);
                FastDriver.BuyerSellerEntitySignatures.Entitytype.FASelectItem(parms.EntityType);
                FastDriver.BuyerSellerEntitySignatures.NewAuthorized.FAClick();
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FASetText(parms.AuthSignsNameOne);
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FASetText(parms.AuthSignsCorpTitleOne);
                FastDriver.BuyerSellerEntitySignatures.NewNameofEntity.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByNameOfEntity.FASetText(parms.ByNameOfEntity);
                FastDriver.BuyerSellerEntitySignatures.ByStateOfIncorp.FASelectItem(parms.ByStateOfIncorp);
                FastDriver.BuyerSellerEntitySignatures.ByEntityType.FASelectItem(parms.ByEntityType);
                FastDriver.BuyerSellerEntitySignatures.ByContactName.FASetText(parms.ByContactName);
                FastDriver.BuyerSellerEntitySignatures.ApplyNameofEntity.FAClick();
                FastDriver.BuyerSellerEntitySignatures.NewAuthorizedSignature.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FASetText(parms.ByEntyAuthSignName);
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FASetText(parms.ByEntyAuthSignTitlCorp);

                Reports.TestStep = "Validate the data entered as authorized signature for Business Entity.";
                Support.AreEqual(parms.NameofEntity, FastDriver.BuyerSellerEntitySignatures.NameofEntity.FAGetText());
                Support.AreEqual(parms.EntityType, FastDriver.BuyerSellerEntitySignatures.Entitytype.FAGetSelectedItem());
                Support.AreEqual(parms.StateOfIncorp, FastDriver.BuyerSellerEntitySignatures.StateOfIncorp.FAGetSelectedItem());

                Support.AreEqual(parms.AuthSignsNameOne, FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FAGetValue());
                Support.AreEqual(parms.AuthSignsCorpTitleOne, FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FAGetValue());

                Support.AreEqual(parms.ByNameOfEntity, FastDriver.BuyerSellerEntitySignatures.ByNameOfEntity.FAGetValue());
                Support.AreEqual(parms.ByStateOfIncorp, FastDriver.BuyerSellerEntitySignatures.ByStateOfIncorp.FAGetSelectedItem());
                Support.AreEqual(parms.ByEntityType, FastDriver.BuyerSellerEntitySignatures.ByEntityType.FAGetSelectedItem());
                Support.AreEqual(parms.ByContactName, FastDriver.BuyerSellerEntitySignatures.ByContactName.FAGetValue());

                FastDriver.BuyerSellerEntitySignatures.ApplyNameofEntity.FAClick();
                Support.AreEqual(parms.ByEntyAuthSignName, FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FAGetValue());
                Support.AreEqual(parms.ByEntyAuthSignTitlCorp, FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0007()
        {
            try
            {
                Reports.TestDescription = "BR_5155_5156: Prevent deletion or changing of buyer type once issued.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");

                #endregion

                Reports.TestStep = "Deposit a cash more than sales price.";
                DepositParameters DepositParams = new DepositParameters()
                {
                    Amount = 6000,
                    TypeofFunds = "Cash",
                    Description = "Sanity Deposit In Escrow",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Buyer"
                };
                this.DepositCash(DepositParams);
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);
                this.PrintAll();
                Reports.TestStep = "1.Navigate to Buyer summary screen.2. delete an instance.";
                this.NavigateActOnBuyr(1, "1", 1, "Clear", "", 1);

                Reports.TestStep = "Delete a buyer seller instance when disbursement is issued.";
                string ExpVal = "A disbursement has been issued for this payee. Please void the disbursement, and then you may change the payee.";
                Support.AreEqual(ExpVal, FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Chang the type from Individual to Husband and wife.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                Reports.TestStep = "Delete a buyer seller instance when disbursement is issued.";
                ExpVal = "A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may change the payee.";
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Husband/Wife"));

                Reports.TestStep = "Create Buyer Individual and validate the data.";
                BuyerParameters buyer = new BuyerParameters()
                {
                    BuyerType = "Individual",
                    Suffix = "sufix"
                };
                Reports.TestStep = "Enter suffix";
                this.CreateIndiBuyr(buyer);

                Reports.TestStep = "Validate error/Warning for mandatory data";
                FastDriver.BottomFrame.Done();
                Support.AreEqual(ErrsOccredMsg, FastDriver.WebDriver.HandleDialogMessage(true, true));
                ExpVal = "LastName: FirstName or LastName is Required.";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.BuyerSellerError.FAGetText().Trim());
                buyer = new BuyerParameters()
                {
                    First = "Indi FirstName"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0008()
        {
            try
            {
                Reports.TestDescription = "BR_FM1985_330_337_338_8060: Validate the vesting and spell check functionality.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");

                #endregion

                Reports.TestStep = "Enter vesting information in Title Production tab.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad().ClickTitleProdTab();
                PropertyAddressParameters PropInfoDtls = new PropertyAddressParameters()
                {
                    Vesting = "BuyerVesting"
                };
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad().FillTitlProdDetls(PropInfoDtls);
                FastDriver.PropertyTaxInfoTitleProd.ClickExcReqInfSave();

                Reports.TestStep = "Validate the Full vest details before edit.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                string[] ArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                string ExpVal = "Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname";
                Support.AreEqual(ExpVal, ArrOne[0]);
                ExpVal = "Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname";
                Support.AreEqual(ExpVal, ArrOne[1]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Full vest details.";
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                BuyerVestingParameters ByrVestg = new BuyerVestingParameters()
                {
                    Names = "Edited Name in Vesting screen",
                    CompleteVesting = "Edited Complete vesting in Vesting screen"
                };
                FastDriver.BuyerVesting.FillFields(ByrVestg);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Full vest details after edit.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                ArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                Support.AreEqual(ByrVestg.Names, ArrOne[0]);
                Support.AreEqual(ByrVestg.CompleteVesting, ArrOne[1]);

                Reports.TestStep = "Click on Copy Title Vest button in vest screen.";
                FastDriver.BuyerVesting.ClickCopyTitlVestg();

                Reports.TestStep = "Validate that vesting information is same as that of Title production.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Title Vesting", true, 5);
                FastDriver.TitleVestingDlg.SwitchToDialogContentFrame();
                ArrOne[0] = FastDriver.TitleVestingDlg.TitleVesting.FAGetValue();
                FastDriver.TitleVestingDlg.Done.FAClick();

                Reports.TestStep = "Validate the Vest information appears as from Copy Title Vest.";
                Support.AreEqual(ArrOne[0], PropInfoDtls.Vesting);

                Reports.TestStep = "Validate spell check functionaliy for Individual";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BuyerVesting.SwitchToContentFrame();
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                ByrVestg = new BuyerVestingParameters()
                {
                    Names = "Speling",
                    CompleteVesting = "Speling"
                };
                this.EnterSpelling("Names", ByrVestg, "Spelling", "Individual");
                this.ValidateNewSpelling("Names", "Spelling", "Individual");
                this.EnterSpelling("CompleteVesting", ByrVestg, "Spelling", "Individual");
                this.ValidateNewSpelling("CompleteVesting", "Spelling", "Individual");

                Reports.TestStep = "Validate spell check functionaliy for Husband Wife";
                this.NavigateActOnBuyr(1, "2", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                this.EnterSpelling("Names", ByrVestg, "Spelling", "Husband Wife");
                this.ValidateNewSpelling("Names", "Spelling", "Husband Wife");
                this.EnterSpelling("CompleteVesting", ByrVestg, "Spelling", "Husband Wife");
                this.ValidateNewSpelling("CompleteVesting", "Spelling", "Husband Wife");

                Reports.TestStep = "Validate spell check functionaliy for Business Entity";
                BuyerParameters buyer = new BuyerParameters()
                {

                    BusinessEntityShortname = "Buyer BusEntity Name",
                    StateofIncorp = "Alaska",
                    EntityType = "Business Trust",
                    BusinessEntitySsn = "53-4553543"
                };
                this.CreateBusEntBuyr(buyer);
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                this.EnterSpelling("Names", ByrVestg, "Spelling", "Bus Entity");
                this.ValidateNewSpelling("Names", "Spelling", "Bus Entity");
                this.EnterSpelling("CompleteVesting", ByrVestg, "Spelling", "Bus Entity");
                this.ValidateNewSpelling("CompleteVesting", "Spelling", "Bus Entity");

                Reports.TestStep = "Validate spell check functionaliy for Trust Estate";
                buyer = new BuyerParameters()
                {
                    TrusteeShortNameTwo = "Trust",
                    TrustAuthorizedName = "Trust",
                    TrustDated = "07-10-2012",
                    TrustNumber = "12345678",
                    TrustAuthorizedType = "Other",
                    TrustTitle = "trustTitle",
                    TrustTin = true,
                    Salutation = "Trust",
                    MiscReference1 = "Misc Ref1",
                    MiscReference2 = "Misc Ref2",
                };
                this.CreateTrustEstBuyr(buyer);
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                this.EnterSpelling("Names", ByrVestg, "Spelling", "TrustEstate");
                this.ValidateNewSpelling("Names", "Spelling", "TrustEstate");
                this.EnterSpelling("CompleteVesting", ByrVestg, "Spelling", "Trust Estate");
                this.ValidateNewSpelling("CompleteVesting", "Spelling", "Trust Estate");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0009()
        {
            try
            {

                Reports.TestDescription = "BR_FM331_332_333_603_765_766: Validate the marital status and salutation functionality.";

                #region Login and Create File by Overwriting Some Values
                this.LoginToFast();
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                    fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                    fileRequest.File.Buyers[0].Type = "Individual";
                    fileRequest.File.Buyers[0].FirstName = "Buyer1FN";
                    fileRequest.File.Buyers[0].MiddleName = "Buyer1MN";
                    fileRequest.File.Buyers[0].LastName = "Buyer1LN";
                    fileRequest.File.Buyers[0].SSN = "123-45-1111";
                    var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");

                #endregion

                Reports.TestStep = "Validate the Vest information, marital status and salutation for buyer as type individual.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                BuyerParameters buyer = new BuyerParameters()
                {
                    SSN = "123-45-6789",
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                Support.AreEqual(buyer.SSN, FastDriver.BuyerSellerSetup.txtSSN.FAGetValue());

                List<string> MaritalStatsVals = new List<string>();
                MaritalStatsVals.Add("(marital status to be determined)");
                MaritalStatsVals.Add("a married man");
                MaritalStatsVals.Add("a married woman");
                MaritalStatsVals.Add("a registered domestic partner");
                MaritalStatsVals.Add("a single man");
                MaritalStatsVals.Add("a single person");
                MaritalStatsVals.Add("a single woman");
                MaritalStatsVals.Add("a widow");
                MaritalStatsVals.Add("a widower");
                MaritalStatsVals.Add("an unmarried man");
                MaritalStatsVals.Add("an unmarried person");
                MaritalStatsVals.Add("an unmarried woman");
                MaritalStatsVals.Add("as registered domestic partners");
                MaritalStatsVals.Add("husband and wife");
                MaritalStatsVals.Add("married spouses");
                MaritalStatsVals.Add("wife and husband");

                string[] MaritalStatsArr = FastDriver.BuyerSellerSetup.MaritalStatus.FAGetAllTextFromSelect().Split('|');
                this.ComparListAndArray(MaritalStatsVals, MaritalStatsArr);

                List<string> VestListValues = new List<string> 
                         {
                                      "(vesting to be determined)", "as community property","as community property with right of survivorship",
                                      "as her sole and separate property","as his sole and separate property","as joint tenants",
                                      "as joint tenants with right of survivorship","as survivorship marital property","as tenant in severalty",
                                      "as tenants by the entirety","as tenants by the entirety, with the common law rights of survivorship",
                                      "as tenants in common","not as tenants in common","not as tenants in common, but with rights of survivorship"
                        };
                string[] VestingDtls = FastDriver.BuyerSellerSetup.Vesting.FAGetAllTextFromSelect().Split('|');
                this.ComparListAndArray(VestListValues, VestingDtls);

                Reports.TestStep = "Create Buyer with Hus and Wife Type.";
                buyer = new BuyerParameters()
                {
                    Husband1FirstName = "Buyer Husband First",
                    Husband2LastName = "Buyer Husband Last",
                    HusbandSpouseFirstName = "Wife First",
                    HusbandSpouseMiddleName = "Wife Middle Name",
                    HusbandSpouseLastName = "Buyer Husband Last",
                    HusbandSpouseSuffix = "Sufix",
                    HusbandSpouse1SSN = "123-34-5678",
                    MaritalStatus = "a married man",
                    Vesting = "as community property",
                    AdditionalVesting = "Additional vesting",
                    Salutation = "Dear Mr. & Mrs. Buyer Husband Last",
                    MiscReference1 = "Misc Ref 1",
                    MiscReference2 = "Misc Ref 2",
                };
                this.CreateHusWifBuyr(buyer);

                MaritalStatsArr = FastDriver.BuyerSellerSetup.MaritalStatus.FAGetAllTextFromSelect().Split('|');
                this.ComparListAndArray(MaritalStatsVals, MaritalStatsArr);

                HuWfAndVestDictry = FastDriver.BuyerSellerSetup.GetHusWfDtlsAuthSign(false);
                VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;

                VestingDtls = FastDriver.BuyerSellerSetup.Vesting.FAGetAllTextFromSelect().Split('|');
                this.ComparListAndArray(VestListValues, VestingDtls);

                Support.AreEqual(buyer.Husband1FirstName, HuWfAndVestDictry["Husband1FirstName"], "Husband1FirstName");
                Support.AreEqual(buyer.Husband2LastName, HuWfAndVestDictry["Husband2LastName"], "Husband 2 LastName");
                Support.AreEqual(buyer.HusbandSpouseFirstName, HuWfAndVestDictry["HusbandSpouseFirstName"], "HusbandSpouse FirstName");
                Support.AreEqual(buyer.HusbandSpouseMiddleName, HuWfAndVestDictry["HusbandSpouseMiddleName"], "HusbandSpouse MiddleName");
                Support.AreEqual(buyer.HusbandSpouseLastName, HuWfAndVestDictry["HusbandSpouseLastName"], "HusbandSpouse LastName");
                Support.AreEqual(buyer.HusbandSpouseSuffix, HuWfAndVestDictry["HusbandSpouseSuffix"], "HusbandSpouse Suffix");
                Support.AreEqual(buyer.HusbandSpouse1SSN, HuWfAndVestDictry["HusbandSpous1SSN"], "HusbandSpouse 1 Ssn");

                Support.AreEqual(buyer.Vesting, VestiNSalutDictry["Vesting"], "Vesting");
                Support.AreEqual(buyer.AdditionalVesting, VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
                Support.AreEqual(buyer.Salutation, VestiNSalutDictry["Salutation"], "Salutation");
                Support.AreEqual(buyer.MiscReference1, VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
                Support.AreEqual(buyer.MiscReference2, VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0010()
        {
            try
            {
                Reports.TestDescription = "BR_FM602_601_600_2120_610_598_FM328: Phone Information, Salutation and misc reference number.";

                #region Login and Create File by Overwriting
                this.LoginToFast();
                try
                {
                    Reports.TestStep = "Create File using web service by overwriting some values.";
                    FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                    fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                    fileRequest.File.Buyers[0].Type = "Individual";
                    fileRequest.File.Buyers[0].FirstName = "Indiv First";
                    fileRequest.File.Buyers[0].MiddleName = "Indiv Middle";
                    fileRequest.File.Buyers[0].LastName = "Indiv Last";
                    fileRequest.File.Buyers[0].Suffix = "Sufx";
                    fileRequest.File.Buyers[0].SSN = "123-45-6789";
                    var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);


                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");

                #endregion


                Reports.TestStep = "Get the data of from file home page and match with other screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                PropertDictry = FastDriver.FileHomepage.GetPropDetails;

                Reports.TestStep = "Validate all supported phone types  exist in drop down for current and forwarding phone type for Individual";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                string[] AllPhTypItmsExpVals = { "Business Phone", "Business Fax", "E-Mail", "Pager", "Cellular", "Home Phone", "Home Fax", "CF Notification" };
                string[] PhValArr = { "Home Phone", "Business Phone", "Pager", "Cellular", "Business Fax", "Home Fax", "E-Mail" };
                BuyerParameters ByrCurPhGeneric = new BuyerParameters()
                {
                    CurrentPhoneNumber = "1111111111",
                    CurrentPhoneTwo = "1111111111",
                    CurrentPhoneThree = "1111111111",
                    CurrentPhoneFour = "1111111111",
                    CurrentPhoneFive = "1111111111",
                    CurrentPhoneSix = "1111111111",
                    CurrentPhoneSeven = "abc@ijk.com",

                    //Extensions
                    CurrentPhExtn = "1111111111",
                    CurrentPhTwoExtn = "1111111111",
                    CurrentPhThreeExtn = "1111111111",
                    CurrentPhFourExtn = "1111111111",
                    CurrentPhFiveExtn = "1111111111",
                    CurrentPhSixExtn = "1111111111",
                    CurrentPhSevenExtn = "True",
                };

                this.VerfyPhListItmsAndSelectdItms(AllPhTypItmsExpVals, "Individual");
                FastDriver.BuyerSellerSetup.SetCurrPhones(ByrCurPhGeneric);
                FastDriver.BuyerSellerSetup.SetCurrPhonesExtns(ByrCurPhGeneric);

                Reports.TestStep = "Validate all supported phone types  exist in drop down for current and forwarding phone type for Husband Wife";
                BuyerParameters buyer = new BuyerParameters()
                {
                    Husband1FirstName = "Buyer Husband First",
                    Husband2LastName = "Buyer Husband Last",
                    HusbandSpouseFirstName = "Wife First",
                    HusbandSpouseMiddleName = "Wife Middle Name",
                    HusbandSpouseLastName = "Buyer Husband Last",
                    HusbandSpouseSuffix = "Sufix",
                    HusbandSpouse1SSN = "123-34-5678",

                };
                this.CreateHusWifBuyr(buyer);
                this.VerfyPhListItmsAndSelectdItms(AllPhTypItmsExpVals, "Husband/Wife");
                FastDriver.BuyerSellerSetup.SetCurrPhones(ByrCurPhGeneric);
                FastDriver.BuyerSellerSetup.SetCurrPhonesExtns(ByrCurPhGeneric);

                Reports.TestStep = "Validate all supported phone types  exist in drop down for current and forwarding phone type for Trust Estate";
                buyer = new BuyerParameters()
                {
                    TrusteeShortNameTwo = "Trust",
                    TrustAuthorizedName = "Trust",
                    TrustDated = "07-10-2012",
                    TrustNumber = "12345678",
                    TrustAuthorizedType = "Other",
                    TrustTitle = "trustTitle",
                };
                this.CreateTrustEstBuyr(buyer);
                this.VerfyPhListItmsAndSelectdItms(AllPhTypItmsExpVals, "TrustEstate");
                FastDriver.BuyerSellerSetup.SetCurrPhones(ByrCurPhGeneric);
                FastDriver.BuyerSellerSetup.SetCurrPhonesExtns(ByrCurPhGeneric);

                Reports.TestStep = "Validate all supported phone types exist in drop down for current and forwarding phone type for Business Entity";
                string[] BusEntPhValArr = { "Business Phone", "Business Fax", "E-Mail", "Cellular", "Pager", "Home Phone", "Home Fax", "CF Notification" };
                buyer = new BuyerParameters()
                {
                    BusinessEntityShortname = "Buyer BusEntity Name",
                    StateofIncorp = "Alaska",
                    EntityType = "Business Trust",
                    BusinessEntitySsn = "53-4553543",

                    CurrentPhoneNumber = "1111111111",
                    CurrentPhoneTwo = "1111111111",
                    CurrentPhoneThree = "abc@ijk.com",
                    CurrentPhoneFour = "1111111111",
                    CurrentPhoneFive = "1111111111",
                    CurrentPhoneSix = "1111111111",
                    CurrentPhoneSeven = "1111111111",
                    //Extensions
                    CurrentPhExtn = "1111111111",
                    CurrentPhTwoExtn = "1111111111",
                    CurrentPhThreeExtn = "True",
                    CurrentPhFourExtn = "1111111111",
                    CurrentPhFiveExtn = "1111111111",
                    CurrentPhSixExtn = "1111111111",
                    CurrentPhSevenExtn = "1111111111",
                };
                this.CreateBusEntBuyr(buyer);
                this.VerfyPhListItmsAndSelectdItms(BusEntPhValArr, "Business Entity");
                FastDriver.BuyerSellerSetup.SetCurrPhones(buyer);
                FastDriver.BuyerSellerSetup.SetCurrPhonesExtns(buyer);
                string ErrValOne = "(???)???-????";
                string ErrValTwo = "?";
                this.NavigateActOnBuyr(4, "Trust/Estate", 4, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("Business Phone", "111", ErrValOne, buyer.CurrentPhoneNumber, "(111)111-1111");
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("Business Fax", "111", ErrValOne, buyer.CurrentPhoneNumber, "(111)111-1111");
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("E-Mail", "abc", ErrValTwo, "abc@ijk.com", "abc@ijk.com");
                FastDriver.BottomFrame.Done();
                this.NavigateActOnBuyr(4, "Trust/Estate", 4, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("Pager", "111", ErrValOne, buyer.CurrentPhoneNumber, "(111)111-1111");
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("Cellular", "111", ErrValOne, buyer.CurrentPhoneNumber, "(111)111-1111");
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("Home Phone", "111", ErrValOne, buyer.CurrentPhoneNumber, "(111)111-1111");
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("Home Fax", "111", ErrValOne, buyer.CurrentPhoneNumber, "(111)111-1111");

                Reports.TestStep = "Validate phone type Home and Business for buyer as Individual.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                Support.AreEqual("Home Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem());
                Support.AreEqual("Business Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem());

                Reports.TestStep = "Validate first phone type as Home and second as Business for buyer as Husband and wife.";
                this.NavigateActOnBuyr(4, "Husband/Wife", 1, "Edit", "", 1);
                Support.AreEqual("Home Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem());
                Support.AreEqual("Business Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem());

                Reports.TestStep = "Enter Buyer details for Individual type - Second Time";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                buyer = new BuyerParameters()
               {
                   First = "BuyerFirstName",
                   Middle = "BuyerMiddleName",
                   Last = "BuyerLastName",
                   Suffix = "sufix",
                   SSN = "123-45-6789",
                   IndivdAuthorzdNam = "Buyersign",
                   MaritalStatus = "a single man",
                   Vesting = "as community property",
                   AdditionalVesting = "Additional vesting",
                   MiscReference1 = "Misc Ref 1",
                   MiscReference2 = "Misc Ref 2",
                   CurrentPhoneNumber = "(991)889-8383",
                   ForwardingPhoneNum = "(991)889-8383"
               };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");

                Reports.TestStep = "Validate for buyer details for individual.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                IndvidByrDictry = FastDriver.BuyerSellerSetup.GetIndivByrDtls;
                Support.AreEqual(buyer.First, IndvidByrDictry["Indi First Name"], "Indi First Name");
                Support.AreEqual(buyer.Middle, IndvidByrDictry["Indi Middle Name"], "Indi Middle Name");
                Support.AreEqual(buyer.Last, IndvidByrDictry["Indi Last Name"], "Indi Last Name");
                Support.AreEqual(buyer.Suffix, IndvidByrDictry["Indi Sufix"], "Indi Sufix");
                Support.AreEqual(buyer.SSN, IndvidByrDictry["Indi Ssn"], "Indi Ssn");

                VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;
                Support.AreEqual(buyer.MaritalStatus, VestiNSalutDictry["Marital Status"], "Marital Status");
                Support.AreEqual(buyer.Vesting, VestiNSalutDictry["Vesting"], "Vesting");
                Support.AreEqual(buyer.AdditionalVesting, VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
                Support.AreEqual(buyer.MiscReference1, VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
                Support.AreEqual(buyer.MiscReference2, VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");

                FastDriver.BuyerSellerSetup.CurrAddrSetToProp();
                CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
                Support.AreEqual(PropertDictry["PropertyBookAddressLine1"], CurAddrDictry["Curr Addr Street 1"], "Curr Addr Street 1");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine2"], CurAddrDictry["Curr Addr Street 2"], "Curr Addr Street 2");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine3"], CurAddrDictry["Curr Addr Street 3"], "Curr Addr Street 3");
                Support.AreEqual(PropertDictry["PropertyAddressBookCity"], CurAddrDictry["Curr Addr City"], "Curr Addr City");
                Support.AreEqual(PropertDictry["PropertyState"], CurAddrDictry["Curr Addr State"], "Curr Addr State");
                Support.AreEqual(PropertDictry["PropertyCounty"], CurAddrDictry["Curr Addr County"], "Curr Addr County");


                ForwdAdrDictry = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
                Support.AreEqual(PropertDictry["PropertyBookAddressLine1"], ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine2"], ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine3"], ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
                Support.AreEqual(PropertDictry["PropertyAddressBookCity"], ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
                Support.AreEqual(PropertDictry["PropertyState"], ForwdAdrDictry["Forward Addr State"], "Forward Addr State");
                Support.AreEqual(PropertDictry["PropertyCounty"], ForwdAdrDictry["Forward Addr County"], "Forward Addr County");

                CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrPhDtls();
                Support.AreEqual(buyer.CurrentPhoneNumber, CurrPhoDictry["CurrentPhoneNum"], "Current PhoneNum");
                ForwdPhoDictry = FastDriver.BuyerSellerSetup.GetForwdPhDtls;
                Support.AreEqual(buyer.ForwardingPhoneNum, ForwdPhoDictry["Forwarding PhoneNum"], "Forwarding PhoneNum");
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0011()
        {
            try
            {
                Reports.TestDescription = "BR_FM1988_767_342: Property Address Unchanged-EXPECTED FAILURE.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");

                #endregion

                Reports.TestStep = "Set current address to other and set values to forward and current address.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Street1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Street2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Street3");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Albany");
                Support.AreEqual("Albany", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("97020");
                Support.AreEqual("97020", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Alameda");
                Support.AreEqual("Alameda", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue());

                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText("Street1");
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText("Street2");
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText("Street3");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Alameda");
                Support.AreEqual("Street1", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
                Support.AreEqual("Street2", FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue());
                Support.AreEqual("Street3", FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue());
                Support.AreEqual("Albany", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue());
                Support.AreEqual("CA", FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem());
                Support.AreEqual("97020", FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue());
                Support.AreEqual("Alameda", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue());

                Reports.TestStep = "Validate the set to other property reflects in buyer screen.";
                Support.AreEqual("Street1", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
                Support.AreEqual("Street2", FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
                Support.AreEqual("Street3", FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
                Support.AreEqual("Albany", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue());
                Support.AreEqual("97020", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
                Support.AreEqual("Alameda", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue());
                EnablStatsDictry = FastDriver.BuyerSellerSetup.GetForwdAddrEnabld;
                Support.AreEqual("True", EnablStatsDictry["Forward Addr SetToCurrent"], "Forward Addr SetToCurrent");

                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText("Street1");
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText("Street2");
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText("street3");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Alameda");

                Reports.TestStep = "Change Current Address to Set To Property and validate it is enabled.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                if (FastDriver.BuyerSellerSetup.IsRadButtnSelectd("CurrentSetToProperty") != "True")
                    FastDriver.BuyerSellerSetup.CurrAddrSetToProp();
                EnablStatsDictry = FastDriver.BuyerSellerSetup.GetCurAddrEnabld;
                Support.AreEqual("False", EnablStatsDictry["Curr Addr Street 1"], "Curr Addr Street 1");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr Street 2"], "Curr Addr Street 2");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr Street 3"], "Curr Addr Street 3");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr City"], "Curr Addr City");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr State"], "Curr Addr State");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr Zip"], "Curr Addr Zip");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr County"], "Curr Addr County");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0012()
        {
            try
            {
                Reports.TestDescription = "BR_6623_6624_6625_6629_6626_6627_6630_6631_6632_6633_6634_6635,BR_612_6622_2119__6641_EW8";

                #region Login and Create File using FAST GUI
                this.LoginToFast();
                this.CreateFileWithGui();
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");

                #endregion

                Reports.TestStep = "Get the data of from file home page and match with other screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                PropertDictry = FastDriver.FileHomepage.GetPropDetails;

                Reports.TestStep = "Validate that Set to property is set as default and property is linked to buyer screen.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.IsRadButtnSelectd("ForwardngSetToProperty"), "Forwrd SetToProperty Selected");
                ForwdAdrDictry = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
                Support.AreEqual(PropertDictry["PropertyBookAddressLine1"], ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine2"], ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine3"], ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
                Support.AreEqual(PropertDictry["PropertyAddressBookCity"], ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
                Support.AreEqual(PropertDictry["PropertyState"], ForwdAdrDictry["Forward Addr State"], "Forward Addr State");
                Support.AreEqual(PropertDictry["PropertyCounty"], ForwdAdrDictry["Forward Addr County"], "Forward Addr County");

                Reports.TestStep = "Set current address to other and set values to forward and current address.";
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Street1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Street2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("street3");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Albany");
                Support.AreEqual("Albany", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("97020");
                Support.AreEqual("97020", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Alameda");
                Support.AreEqual("Alameda", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText("Street1");
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText("Street2");
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText("street3");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Alameda");
                Support.AreEqual("Street1", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
                Support.AreEqual("Street2", FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue());
                Support.AreEqual("street3", FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue());
                Support.AreEqual("Albany", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue());
                Support.AreEqual("CA", FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem());
                Support.AreEqual("97020", FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue());
                Support.AreEqual("Alameda", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue());

                Reports.TestStep = "Validate the set to other property reflects in buyer screen.";
                Support.AreEqual("Street1", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue(), "Street1");
                Support.AreEqual("Street2", FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue(), "Street2");
                Support.AreEqual("street3", FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue(), "Street3");
                Support.AreEqual("Albany", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue());
                Support.AreEqual("97020", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
                Support.AreEqual("Alameda", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue());
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.IsRadButtnSelectd("ForwardingSetToOther"));
                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText("Street1");
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText("Street2");
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText("street3");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Alameda");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change Forward Address to Set to Property and validate the property is linked to buyer screen.";
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click, "", 1);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.ForwdAddrSetToPropty();
                ForwdAdrDictry = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
                Support.AreEqual(PropertDictry["PropertyBookAddressLine1"], ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine2"], ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine3"], ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
                Support.AreEqual(PropertDictry["PropertyAddressBookCity"], ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
                Support.AreEqual(PropertDictry["PropertyState"], ForwdAdrDictry["Forward Addr State"], "Forward Addr State");
                Support.AreEqual(PropertDictry["PropertyCounty"], ForwdAdrDictry["Forward Addr County"], "Forward Addr County");

                Reports.TestStep = "Change Forward Address to Set To Others and validate property does not change.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                Support.AreEqual(PropertDictry["PropertyBookAddressLine1"], ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine2"], ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine3"], ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
                Support.AreEqual(PropertDictry["PropertyAddressBookCity"], ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
                Support.AreEqual(PropertDictry["PropertyState"], ForwdAdrDictry["Forward Addr State"], "Forward Addr State");
                Support.AreEqual(PropertDictry["PropertyCounty"], ForwdAdrDictry["Forward Addr County"], "Forward Addr County");

                Reports.TestStep = "Enter different address.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("#");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("#");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("#");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("#");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Get the data of from file home page and match with other screen.";
                PropertDictry = FastDriver.FileHomepage.GetPropDetails;

                Reports.TestStep = "Select Forward address as set to current.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.ForwdAddrSetToCurr();
                ForwdAdrDictry = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
                Support.AreEqual("Street1", ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
                Support.AreEqual("Street2", ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
                Support.AreEqual("street3", ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
                Support.AreEqual("Albany", ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
                Support.AreEqual("Alameda", ForwdAdrDictry["Forward Addr County"], "Forward Addr County");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change Forward Address to Set to Property and validate the property is linked to buyer screen.";
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click, "", 1);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText("Street1");
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText("Street2");
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText("street3");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Albany");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("97020");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Alameda");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter incompatible values to instance which is an IBA beneficiary.";
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click, "", 1);
                FastDriver.BuyerSellerSummary.Edit();
                BuyerParameters buyer = new BuyerParameters()
                {
                    First = "Z<>$#:'/+-=().,_&",
                    SSN = "413-45-6759"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                Reports.TestStep = "Change the Forward Address to set to Others and validate the address.";
                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText("J305");
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText("JJEJAMQ");
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText("JJEJAMQ");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("ALBANY");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("ALAMEDA");
                Support.AreEqual("J305", FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue(), "Forward Addr Street 1");
                Support.AreEqual("JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue(), "Forward Addr Street 2");
                Support.AreEqual("JJEJAMQ", FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue(), "Forward Addr Street 3");
                Support.AreEqual("ALBANY", FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue(), "Forward Addr City");
                Support.AreEqual("ALAMEDA", FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue(), "Forward Addr County");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Current Address in Set to Other in Current and edit the address.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("#");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Street1Other");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Street2Other");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("#");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("#");

                Reports.TestStep = "Select Forward address to Set to Currents.";
                FastDriver.BuyerSellerSetup.ForwdAddrSetToCurr();

                Reports.TestStep = "Select Current address to Set to Property.";
                FastDriver.BuyerSellerSetup.CurrAddrSetToProp();

                Reports.TestStep = "Change of Address in Buyer Seller screen.";
                string ExpVal = "The Forwarding Address is linked to Current Address.  Selecting 'Set to Property' for the Current Address will change the existing Forwarding Address to the Property Address and the system will change the Forwarding Address link  from 'Set to Current' to 'Set to Property'.";
                Support.AreEqual(ExpVal, FastDriver.WebDriver.HandleDialogMessage(true, true), "Warning address on Current Addrs section");

                //REG 13 Starts
                Reports.TestStep = "Validate that Set to property is set as default and property is linked to buyer screen - 2nd Time";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.IsRadButtnSelectd("ForwardngSetToProperty"), "Forwrd SetToProperty Selected");
                ForwdPhoDictry = FastDriver.BuyerSellerSetup.GetForwdPhDtls;

                Reports.TestStep = "Validate that Set to current is disabled in forward address when set to property is selected in Current Address.";
                if (FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAGetAttribute("Selected").ToString() != "true")
                    FastDriver.BuyerSellerSetup.CurrAddrSetToProp();
                EnablStatsDictry = FastDriver.BuyerSellerSetup.GetCurAddrEnabld;
                Support.AreEqual("False", EnablStatsDictry["Curr Addr Street 1"], "Curr Addr Street 1");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr Street 2"], "Curr Addr Street 2");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr Street 3"], "Curr Addr Street 3");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr City"], "Curr Addr City");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr State"], "Curr Addr State");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr Zip"], "Curr Addr Zip");
                Support.AreEqual("False", EnablStatsDictry["Curr Addr County"], "Curr Addr County");

                EnablStatsDictry = FastDriver.BuyerSellerSetup.GetForwdAddrEnabld;
                Support.AreEqual("False", EnablStatsDictry["Forward Addr SetToCurrent"], "Forward Addr SetToCurrent");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr Street 1"], "Forward Addr Street 1");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr Street 2"], "Forward Addr Street 2");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr Street 3"], "Forward Addr Street 3");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr City"], "Forward Addr City");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr State"], "Forward Addr State");
                Support.AreEqual("False", EnablStatsDictry["Forward Addr County"], "Forward Addr County");

                Reports.TestStep = "REG 13 - Create an order with Transaction type as REFINANCE.";
                this.CreateFileWithGui(false);

                Reports.TestStep = "REG 13 - Get the data of from file home page and match with other screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                PropertDictry = FastDriver.FileHomepage.GetPropDetails;

                Reports.TestStep = "REG 13 - Validate that Property is set to default Property when transaction type is Refinance.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);

                if (FastDriver.BuyerSellerSetup.IsRadButtnSelectd("CurrentSetToProperty").ToString() != "True")
                    Reports.StatusUpdate("CurrentSetToProperty", false, "Selected", "Radio button", "", Reports.Result(false), "");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine1"], FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue(), "Street1");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine2"], FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue(), "Street2");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine3"], FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue(), "Street3");
                Support.AreEqual(PropertDictry["PropertyAddressBookCity"], FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue());
                Support.AreEqual(PropertDictry["PropertyState"], FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem());
                Support.AreEqual(PropertDictry["PropertyCounty"], FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue());


                if (FastDriver.BuyerSellerSetup.IsRadButtnSelectd("ForwardngSetToProperty").ToString() != "True")
                    Reports.StatusUpdate("ForwardngSetToProperty", false, "Selected", "Radio button", "", Reports.Result(false), "");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine1"], FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue(), "Street1");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine2"], FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue(), "Street2");
                Support.AreEqual(PropertDictry["PropertyBookAddressLine3"], FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue(), "Street3");
                Support.AreEqual(PropertDictry["PropertyAddressBookCity"], FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue());
                Support.AreEqual(PropertDictry["PropertyState"], FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem());
                Support.AreEqual(PropertDictry["PropertyCounty"], FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Obsolete]
        public void FMUC0005B_REG0013()
        {
            try
            {
                Reports.TestDescription = "BR_612_6622_2119__6641_EW8: Buyer screen Address functionality.";
                Reports.StatusUpdate("BR_612_6622_2119__6641_EW8 (Covered in FMUC0005B_REG0012).", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0014()
        {
            try
            {
                Reports.TestDescription = "BR_FM341: Adding multiple AKA name.";

                #region Login and Create File
                this.LoginToFast();
                try
                {
                    Reports.TestStep = "Create File using web service by overwriting some values";
                    FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                    fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                    fileRequest.File.Buyers[0].Type = "Individual";
                    fileRequest.File.Buyers[0].FirstName = "BuyerFirstName";
                    fileRequest.File.Buyers[0].MiddleName = "BuyerMiddleName";
                    fileRequest.File.Buyers[0].LastName = "BuyerLastName";
                    fileRequest.File.Buyers[0].Suffix = "sufix";
                    fileRequest.File.Buyers[0].SSN = "123-45-6789";
                    var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed.");
                #endregion

                Reports.TestStep = "Enter Buyer details for Individual type.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                BuyerParameters buyer = new BuyerParameters()
                {
                    IndivdAuthorzdNam = "Buyersign",
                    MaritalStatus = "a single man",
                    Vesting = "as community property",
                    AdditionalVesting = "Additional vesting",
                    MiscReference1 = "Misc Ref 1",
                    MiscReference2 = "Misc Ref 2",
                    CurrentPhoneNumber = "(991)889-8383",
                    ForwardingPhoneNum = "(991)889-8383"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter AKA name for buyer individual.";
                Reports.TestStep = "Add multiple AKA name.";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.AKA();
                AkaParameters AkaNameVals = new AkaParameters()
                {
                    Aka = "Binfo",
                    UsedAtSigning = true,
                    AkaTwo = "Fname1"
                };
                FastDriver.AKANames.SetDetails(AkaNameVals, 2);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0015()
        {
            try
            {
                Reports.TestDescription = "BR_FM9195_11501_11503_11506_11508: Validate the functionality of IBA beneficiary as buyer:EXPECTED FAILURE TFS139117";

                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion

                Reports.TestStep = "To enter the first property address in Property tax screen.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("45 Bluejay");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Irvine");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Orange");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("92707");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Deposit a cash more than sales price.";
                DepositParameters DepositParams = new DepositParameters()
                {
                    Amount = 6000,
                    TypeofFunds = "Cash",
                    Description = "Sanity Deposit In Escrow",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Buyer"
                };
                this.DepositCash(DepositParams);
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary, 10);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Select buyer as beneficiary.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad(timeout: 15);
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Prevent add IBA beneficiaries if required values are miss.";
                string ExpVal = "Selected buyer/seller does not have one or more   of the following required fields: -SSN/TIN, -Short Name, -First Name, -Last Name, -Current Address Line1, -Current Address City, -Current Address State, -Current Address ZipCode";
                string ActVal = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual(ActVal.Trim().Replace("\n", String.Empty).Replace("\r", " "), ExpVal);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Enter Buyer details for Individual type.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                BuyerParameters buyer = new BuyerParameters()
                {
                    First = "BuyerFirstName",
                    Middle = "BuyerMiddleName",
                    Last = "BuyerLastName",
                    Suffix = "sufix",
                    SSN = "123-45-6789",
                    IndivdAuthorzdNam = "Buyersign",
                    MaritalStatus = "a single man",
                    Vesting = "as community property",
                    AdditionalVesting = "Additional vesting",
                    MiscReference1 = "Misc Ref 1",
                    MiscReference2 = "Misc Ref 2",
                    CurrentPhoneNumber = "(991)889-8383",
                    ForwardingPhoneNum = "(991)889-8383"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Set current address to other and set values to forward and current address.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                buyer = new BuyerParameters()
                {
                    CurrentStreet1 = "Street1",
                    CurrentStreet2 = "Street2",
                    CurrentStreet3 = "Street3",
                    CurrentCity = "Albany",
                    CurrentState = "CA",
                    CurrentZip = "97020",
                    CurrentCounty = "Alameda",
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
                Support.AreEqual(buyer.CurrentStreet1, CurAddrDictry["Curr Addr Street 1"], "Curr Addr Street 1");
                Support.AreEqual(buyer.CurrentStreet2, CurAddrDictry["Curr Addr Street 2"], "Curr Addr Street 2");
                Support.AreEqual(buyer.CurrentStreet3, CurAddrDictry["Curr Addr Street 3"], "Curr Addr Street 3");
                Support.AreEqual(buyer.CurrentCity, CurAddrDictry["Curr Addr City"], "Curr Addr City");
                Support.AreEqual(buyer.CurrentState, CurAddrDictry["Curr Addr State"], "Curr Addr State");
                Support.AreEqual(buyer.CurrentZip, CurAddrDictry["Curr Addr Zip"], "Curr Addr Zip");
                Support.AreEqual(buyer.CurrentCounty, CurAddrDictry["Curr Addr County"], "Curr Addr County");

                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                buyer = new BuyerParameters()
                {
                    ForwardStreet1 = "Street1",
                    ForwardStreet2 = "Street2",
                    ForwardStreet3 = "Street3",
                    ForwardState = "CA",
                    ForwardCity = "Albany",
                    ForwardZip = "97020",
                    ForwardCounty = "Alameda"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                ForwdAdrDictry = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
                Support.AreEqual(buyer.ForwardStreet1, ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
                Support.AreEqual(buyer.ForwardStreet2, ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
                Support.AreEqual(buyer.ForwardStreet3, ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
                Support.AreEqual(buyer.ForwardState, ForwdAdrDictry["Forward Addr State"], "Forward Addr State");
                Support.AreEqual(buyer.ForwardCity, ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
                Support.AreEqual(buyer.ForwardZip, ForwdAdrDictry["Forward Addr Zip"], "Forward Addr Zip");
                Support.AreEqual(buyer.ForwardCounty, ForwdAdrDictry["Forward Addr County"], "Forward Addr County");

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary - 2nd time";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary, 10);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Select buyer as beneficiary.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad(timeout: 15);
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter the IBA bank";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.SwitchToContentFrame();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.IBABanks.FASelectItem("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.SwitchToContentFrame();
                //  Enter amount in Transaction tab
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Transactions);
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab().WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "1.Navigate to Buyer summary screen.2. delete an instance.";
                this.NavigateActOnBuyr(1, "1", 1, "Clear", "", 1);

                Reports.TestStep = "Validate that buyer seller instance cannot be removed if it is an IBA beneficiary.";
                ExpVal = "The party is an IBA Beneficiary and cannot be removed from the file.";
                Support.AreEqual(ExpVal, FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Add, edit and view info in the instance.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                buyer = new BuyerParameters()
                {
                    First = "Buyer edit Firstname",
                    SSN = "413-45-6759"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select reason to change entity type.";
                FastDriver.ReasonforchangeDlg.WaitForDialogToLoad();
                FastDriver.ReasonforchangeDlg.SetFields("Other", "Test");
                FastDriver.ReasonforchangeDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Chang the type from Individual to Husband and wife.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                ActVal = FastDriver.BuyerSellerSetup.ChangeInstanceType(2, "Husband/Wife");

                Reports.TestStep = "User tries to change buyer type.";
                string[] TempArr = ActVal.Split('#');
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();

                Reports.TestStep = "Validate warning message is as per EWC#4 and Click on Ok button";

                if (!(TempArr[0].Equals(ExpVal)))
                    Reports.StatusUpdate("Changing buyer type should be restricted. Bug 139117", false);
                else
                    Reports.StatusUpdate("Changing buyer type was restricted. Bug 139117 should be closed.", true);

                Reports.TestStep = "Create Buyer Trustee or Estate.";
                buyer = new BuyerParameters()
                {
                    TrusteeShortNameTwo = "Buyer Trust Name",
                };
                this.CreateTrustEstBuyr(buyer);

                Reports.TestStep = "Enter exchange company details - Reg0015 - Trustee Buyer";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.SwitchToContentFrame();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select reason to change entity  type.";
                if (FastDriver.WebDriver.WindowIsDisplayed("Reason for Change"))
                {
                    FastDriver.ReasonforchangeDlg.WaitForDialogToLoad();
                    FastDriver.ReasonforchangeDlg.SwitchToDialogContentFrame();
                    FastDriver.ReasonforchangeDlg.SetFields("Other", "Test");
                    FastDriver.ReasonforchangeDlg.ClickOk();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0016()
        {
            try
            {
                Reports.TestDescription = "BR_FM11511_EW10: Validate that Prevent Save of XML- incompatible characters for an IBA Bene";

                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }

                this.CreateFileWithGui();

                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed."); ;
                #endregion

                Reports.TestStep = "To enter the first property address in Property tax screen.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "45 Bluejay",
                    StreetLine2 = "",
                    StreetLine3 = "",
                    City = "Irvine",
                    County = "Orange",
                    Zip = "92707"
                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Deposit a cash more than sales price.";
                DepositParameters DepositParams = new DepositParameters()
                {
                    Amount = 6000,
                    TypeofFunds = "Cash",
                    Description = "Sanity Deposit In Escrow",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Buyer"
                };
                this.DepositCash(DepositParams);
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Select an instance from buyer screen";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                Reports.TestStep = "Enter invalid or incompatible values to instance which is an IBA beneficiary.";
                BuyerParameters buyer = new BuyerParameters()
                {
                    First = "~ ` ! @ ^  * [ { ] }",
                    Middle = "BuyerMiddleName",
                    SSN = "413-45-6759"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Husband Wife with incompatible characters.";
                buyer = new BuyerParameters()
                {
                    Husband1FirstName = "Z<>$#:'/+-=().,_&",
                    Husband2LastName = "A~!%^*{}[]",
                    HusbandSpouseFirstName = "Z<>$#:'/+-=().,_&",
                    HusbandSpouseLastName = "A~!%^*{}[]",
                };
                this.NavigateActOnBuyr(1, "2", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Trust Estate with incompatible characters.";
                buyer = new BuyerParameters()
                {
                    TrusteeShortNameTwo = "Z<>$#:'/+-=().,_&"
                };
                this.CreateTrustEstBuyr(buyer);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Business Entity with incompatible characters.";
                buyer = new BuyerParameters()
                {
                    BusinessEntityShortname = "Z<>$#:'/+-=().,_&"
                };
                this.CreateBusEntBuyr(buyer);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                ValidateXmlError(1, "~ ` ! @ ^ * [ { ] }Buyer1Lastname");
                ValidateXmlError(2, "Z<>$#:'/+-=().,_&A~!%^*{}[]");
                ValidateXmlError(3, "Z<>$#:'/+-=().,_&", 3);
                ValidateXmlError(4, "Z<>$#:'/+-=().,_&", 4);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0017_PH()
        {

            try
            {
                Reports.TestDescription = "FM9108_FM9109_PlaceHolder: PlaceHolder:Validate manually that For individual and Husband and wife can have only single authorized signature";// // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0018()
        {
            try
            {
                Reports.TestDescription = "BR_FM9095_9097_9098_9099_9100_9106_9103_9105_FM9107_FM9096_FM9112: Validate the functionality of Exchange company and Authorized signature_Expected Failure";
                string FormType = AutoConfig.FormType;

                #region Login and Create File
                this.LoginToFast();

                //Issue - TaxIds not shown in the UI with WebService file creation
                /**
                var filerequest = this.GetDetailedCreateFileDefaultRequest();                
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(filerequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                **/
                this.CreateFileWithGui();

                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FirstFileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FirstFileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FirstFileNumber + "", "File was created with " + FirstFileNumber + "");
                else
                    Assert.AreEqual("File was not created", "File was not created. Failed."); ;
                #endregion
                if (FormType.Equals("HUD"))
                {
                    FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                    FastDriver.FileFees.HUD.FASetCheckbox(true);
                }

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                PropertDictry = FastDriver.FileHomepage.GetPropDetails;
                Support.AreEqual("Sale w/Mortgage", PropertDictry["TransactionType"], "Transaction Type");
                Support.AreEqual("5,000.00", PropertDictry["TermsDatesPrice"], "Terms Dates Price");
                Support.AreEqual("J305", PropertDictry["PropertyName"], "Property Name");
                Support.AreEqual("Single Family Residence", PropertDictry["PropertyType"], "PropertyType");
                Support.AreEqual("Lot1", PropertDictry["PropertyLotName"], "PropertyLotName");
                Support.AreEqual("Block1", PropertDictry["PropertyBlock"], "PropertyBlock");
                Support.AreEqual("Unit1", PropertDictry["PropertyUnit"], "PropertyUnit");
                Support.AreEqual("Prop1APN1", PropertDictry["PropertyPropTaxAPN1"], "PropertyPropTaxAPN1");
                Support.AreEqual("9845012345", PropertDictry["PropertyPropTaxAPN2"], "PropertyPropTaxAPN2");
                Support.AreEqual("J305", PropertDictry["PropertyBookAddressLine1"], "PropertyBookAddressLine1");
                Support.AreEqual("JJEJAMQ", PropertDictry["PropertyBookAddressLine2"], "PropertyBookAddressLine2");
                Support.AreEqual("JJEJAMQ", PropertDictry["PropertyBookAddressLine3"], "PropertyBookAddressLine3");
                Support.AreEqual("ALBANY", PropertDictry["PropertyCity"], "PropertyCity");
                Support.AreEqual("CA", PropertDictry["PropertyState"], "Property State");
                Support.AreEqual("ALAMEDA", PropertDictry["PropertyCounty"], "PropertyCounty");

                ByrDtlstDictry = FastDriver.FileHomepage.GetByrDtlsOnFhp;
                Support.AreEqual("Individual", ByrDtlstDictry["Buyer1Type"], "Buyer1Type");
                Support.AreEqual("Buyer1Firstname", ByrDtlstDictry["Buyer1FirstName"], "Buyer1Firstname");
                Support.AreEqual("Buyer1Lastname", ByrDtlstDictry["Buyer1LastName"], "Buyer1Lastname");
                Support.AreEqual("Husband/Wife", ByrDtlstDictry["Buyer2Type"], "Buyer2Type");
                Support.AreEqual("Buyer2Firstname", ByrDtlstDictry["Buyer2FirstName"], "Buyer2FirstName");
                Support.AreEqual("Buyer2SpouseName", ByrDtlstDictry["Buyer2SpouseFirstName"], "Buyer2SpouseFirstName");
                Support.AreEqual("Buyer2Lastname", ByrDtlstDictry["Buyer2SpouseLastName"], "Buyer2SpouseLastName");


                SelrDtlstDictry = FastDriver.FileHomepage.GetSelrDtlsOnFhp;
                Support.AreEqual("Individual", SelrDtlstDictry["Seller1Type"], "Seller1Type");
                Support.AreEqual("Seller1Firstname", SelrDtlstDictry["Seller1FirstName"], "Seller1Firstname");
                Support.AreEqual("Seller1Lastname", SelrDtlstDictry["Seller1LastName"], "Seller1Lastname");
                Support.AreEqual("Husband/Wife", SelrDtlstDictry["Seller2Type"], "Seller2Type");
                Support.AreEqual("Seller2Firstname", SelrDtlstDictry["Seller2FirstName"], "Seller2Firstname");
                Support.AreEqual("Seller2SpouseName", SelrDtlstDictry["Seller2SpouseFirstName"], "Seller2SpouseFirstName");
                Support.AreEqual("Seller2Lastname", SelrDtlstDictry["Seller2SpouseLastName"], "Seller2SpouseLastName");

                Reports.TestStep = "Enter Buyer details for Individual type.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                BuyerParameters buyer = new BuyerParameters()
                {
                    First = "BuyerFirstName",
                    Middle = "BuyerMiddleName",
                    Last = "BuyerLastName",
                    Suffix = "sufix",
                    SSN = "123-45-6789",
                    IndivdAuthorzdNam = "Buyersign",
                    MaritalStatus = "a single man",
                    Vesting = "as community property",
                    AdditionalVesting = "Additional Vesting",
                    MiscReference1 = "Misc Ref 1",
                    MiscReference2 = "Misc Ref 2",
                    CurrentPhoneNumber = "(991)889-8383",
                    ForwardingPhoneNum = "(991)889-8383"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");

                Reports.TestStep = "Create Buyer with Hus and Wife Type full details and validate the data.";
                this.NavigateActOnBuyr(1, "2", 1, "Edit", "", 1);
                buyer = new BuyerParameters()
                {
                    MaritalStatus = "a married man",
                    Vesting = "as community property",
                    AdditionalVesting = "Additional vesting",
                    Salutation = "Dear Mr. & Mrs. Buyer Husband Last",
                    MiscReference1 = "Misc Ref 1",
                    MiscReference2 = "Misc Ref 2",
                    CurrentPhoneNumber = "(991)889-8383",
                    ForwardingPhoneNum = "(991)889-8383",
                    Husband1FirstName = "Buyer Husband First",
                    Husband2LastName = "Buyer Husband Last",
                    HusbandSpouseFirstName = "Wife First",
                    HusbandSpouseMiddleName = "Wife Middle Name",
                    HusbandSpouseLastName = "Buyer Husband Last",
                    HusbandSpouseSuffix = "Sufix",
                    HusbandSpouse2SSN = "123-34-5678",
                    HusbAuthzSigNam = "HSSign",
                    HusSpous2TrusteNam = "HSSign2"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);
                FastDriver.BuyerSellerSetup.Husband_Authzdrop();
                Support.AreEqual("Attorney In Fact", FastDriver.BuyerSellerSetup.Husbandspouse1TrusteeType.FAGetSelectedItem(), "Husbandspouse1 TrusteeType");
                Support.AreEqual("Attorney In Fact", FastDriver.BuyerSellerSetup.Husbandspouse2TrusteeType.FAGetSelectedItem(), "Husbandspouse2 TrusteeType");
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();

                Reports.TestStep = "Set an exchange company id from Global address book.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");

                Reports.TestStep = "Create Buyer Trustee or Estate.";
                buyer = new BuyerParameters()
                {
                    TrusteeShortNameTwo = "Buyer Trust Name",
                };
                this.CreateTrustEstBuyr(buyer);

                Reports.TestStep = "Enter exchange company details - Trustee Buyer";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Buyer Business Entity.";
                buyer = new BuyerParameters()
                {
                    BusinessEntityShortname = "Buyer BusEntity Name",
                    BusinessEntitySsn = "53-4553543"
                };
                this.CreateBusEntBuyr(buyer);
                Reports.TestStep = "Enter exchange company details - Trustee Buyer";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Second Order with GUI";
                this.CreateFileWithGui();
                if (FormType.Equals("HUD"))
                {
                    FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                    FastDriver.FileFees.HUD.FASetCheckbox(true);
                }
                Reports.TestStep = "Selecting Buyer and seller.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FirstFileNumber + FAKeys.Tab);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);
                FastDriver.StarterReference.SellersData.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Validate the exchange company in Buyer summary screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                Dictionary<int, string> DictOb = new Dictionary<int, string>();
                DictOb.Add(4, "Individual");
                DictOb.Add(7, "Exchange Company1 Name 1");
                FastDriver.BuyerSellerSummary.VerifyMultplColValues(1, DictOb);
                DictOb.Clear();

                Reports.TestStep = "Validate exchange company for Husband and wife in summary screen.";
                DictOb.Add(4, "Husband/Wife");
                DictOb.Add(7, "Exchange Company1 Name 1");
                FastDriver.BuyerSellerSummary.VerifyMultplColValues(2, DictOb);
                DictOb.Clear();

                Reports.TestStep = "Validate exchange company for Trust Estate in summary screen.";
                DictOb.Add(4, "Trust/Estate");
                DictOb.Add(7, "Exchange Company1 Name 1");
                FastDriver.BuyerSellerSummary.VerifyMultplColValues(3, DictOb);
                DictOb.Clear();

                Reports.TestStep = "Validate exchange company for Business Entity in summary screen.";
                DictOb.Add(4, "BusinessEntity");
                DictOb.Add(7, "Exchange Company1 Name 1");
                FastDriver.BuyerSellerSummary.VerifyMultplColValues(4, DictOb);

                Reports.TestStep = "Deposit a cash more than sales price.";
                DepositParameters DepositParams = new DepositParameters()
                {
                    Amount = 6000,
                    TypeofFunds = "Cash",
                    Description = "Sanity Deposit In Escrow",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Buyer"
                };
                this.DepositCash(DepositParams);
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Validate that exchange company name appears in Active Disbursement screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Exchange Company1 Name 1 Exchange Compan", 8, TableAction.Click, "", 1);

                if (FormType == "HUD")
                {
                    FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Home>Order Entry>Escrow Closing>HUD-1 Statement");
                    Support.AreEqual("True", FastDriver.HUD1PrintOptions.BorrowerName.FAGetValue().Contains("Exchange Company1 Name 1 as Qualified Intermediary").ToString(), "ExComp Name");
                    Reports.TestStep = "Validate in PDF that exchange company name appears.";
                    FastDriver.HUD1PrintOptions.Combined.FASetCheckbox(false);
                    FastDriver.HUD1PrintOptions.BuyerOnly.FASetCheckbox(true);
                    FastDriver.HUD1PrintOptions.BuyerOnlySignature.FASetCheckbox(true);

                    Reports.TestStep = "Perform Preview delivery.";
                    FastDriver.HUD1PrintOptions.Method.FASelectItemBySendingKeys("Preview");
                    FastDriver.HUD1PrintOptions.Deliver.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                }
                Reports.TestStep = "Print All Checks.";
                this.PrintAll();
                //   if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                //{
                //    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                //    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                //    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //}
                //else
                //{ // Password Confirmation
                //    FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                //}
                //    FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate that on issue a disbursement exchange company cannot be deleted.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                Support.AreEqual("False", FastDriver.ExchangeCompany.Find.IsEnabled().ToString(), "Find Button on Exch Comp page");
                try
                {
                    Support.AreEqual("False", FastDriver.BottomFrame.btnDelete.IsDisplayed().ToString(), "Delete Button on Bottom frame");
                }
                catch (Exception e)
                {

                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0019()
        {
            try
            {
                Reports.TestDescription = "BR_FM10684: Prevent Changing the Buyer type when invoiced with STatus final";

                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception e)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");

                #endregion

                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99");

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "2.99"); FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Invoice Fees for file event.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();

                Reports.TestStep = "Set on final button in Invoice screen.";
                Support.AreEqual(@"True", FastDriver.InvoiceFees.Final.Enabled.ToString(), "Verify whether the Final element is enabled.");
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Deselect invoice fees/Uninvoiced.";
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.Off);

                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Display Name as Buyer or Seller.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileaddressBookRadio);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio1);
                FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Create an invoice/Select Final option.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction("#5", "UNINVOICED", "#6", TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                Support.AreEqual(@"True", FastDriver.InvoiceFees.Final.Enabled.ToString(), "Verify whether the Final element is enabled.");
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "1.Navigate to Buyer summary screen.2. delete an instance.";
                this.NavigateActOnBuyr(1, "1", 1, "Clear", "", 1);

                Reports.TestStep = "Validate that Final invoiced buyer cannot be modified.";
                string ExpVal = "This File Business party cannot be modified since there is a Final or Final Adjusted invoice associated to this party. The File Business Party can be modified the next business day after the invoice is canceled";
                Support.AreEqual(ExpVal, FastDriver.WebDriver.HandleDialogMessage(true, true).Trim());

                Reports.TestStep = "Chang the type from Individual to Husband and wife.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Husband/Wife").Trim());
                try
                {
                    FastDriver.LeftNavigation.ClickHome();
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 8);
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 8);
                }
                catch (Exception e)
                {
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 8);
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                }
                Reports.TestStep = "Deselect the buyer instance.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction("#5", "FINAL", "#6", TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.Off);

                Reports.TestStep = "Validate FinalADJ Status.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction("#1", "Buyer1Firstname Buyer1Lastname", "#6", TableAction.Click);
                FastDriver.InvoiceFees.History.FAClick();

                Reports.TestStep = "1.Navigate to Buyer summary screen.2. delete an instance.";
                this.NavigateActOnBuyr(1, "1", 1, "Clear", "", 1);
                Support.AreEqual(ExpVal, FastDriver.WebDriver.HandleDialogMessage(true, true).Trim());

                Reports.TestStep = "Chang the type from Individual to Husband and wife - 2nd time";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                Support.AreEqual(ExpVal, FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Husband/Wife").Trim());
                try
                {
                    FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers");
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 8);
                }
                catch (Exception e)
                {
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 8);
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0020()
        {
            try
            {
                Reports.TestDescription = "ADM Site  - BR_FM8754_8755_8756_8757_8758_8759_8760_8761_8762_pre: Validate the GAB and wire inSTruction functionality-precondition";//: EXPECTED FAILUE and SHOW STOPPER                
                #region Login to Adm
                this.LoginToAdm();
                var newBussOrg = new BusinessOrganizationParameters()
                {
                    IDCode = "BUYATTRNY"
                };
                #endregion
                Reports.TestStep = "Select a buyer gab id and click on find button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.WaitForScreenToLoad().SearchAddressBook(newBussOrg.IDCode);
                FastDriver.AddressBookSearch.SwitchToContentFrame();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("Status", "Active", "Status", TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Select Buyer type as Trust estate and enter wire instruction.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                var BusOrg = new BusinessOrganizationParameters()
                {
                    BuyerSellerType = "Trust/Estate",
                    ABANumber = "41256718909787",
                    BankName = "test bank name",
                    BankAddress = "test address 1 test address 2",
                    AccountNumber = "41256718909787",

                };
                FastDriver.BusPartyOrgSetUp.BuyerSellerType.FASelectItemBySendingKeys(BusOrg.BuyerSellerType);
                FastDriver.BusPartyOrgSetUp.ABANumber.FASetText(BusOrg.ABANumber);
                FastDriver.BusPartyOrgSetUp.BankName.FASetText(BusOrg.BankName);
                FastDriver.BusPartyOrgSetUp.BankAddress.FASetText(BusOrg.BankAddress);
                FastDriver.BusPartyOrgSetUp.AccountNumber.FASetText(BusOrg.AccountNumber);
                BusPartyOrgSetUpDictry = FastDriver.BusPartyOrgSetUp.GetDetails;
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0021()
        {
            Reports.TestDescription = "FAST Site - BR_FM8754_8755_8756_8757_8758_8759_8760_8761_8762_pre: Validate the GAB and wire inSTruction functionality-precondition";//: EXPECTED FAILUE and SHOW STOPPER                            

            #region Login and Create File using Web Services
            this.LoginToFast();
            try
            {

                Reports.TestStep = "Create File using web service by overwriting some values.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[] 
                    { 
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BUYATTRNY"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        }                       
                    };
                fileRequest.File.Buyers[0].Type = "Trust/Estate";
                fileRequest.File.Buyers[0].Name = "Buyer1Trustname";
                fileRequest.File.Buyers[0].SSN = "123-45-6789";

                fileRequest.File.Buyers[1].Type = "Business Entity";
                fileRequest.File.Buyers[1].Name = "Buyer2EntityName";
                fileRequest.File.Buyers[1].SSN = "123-45-4567";

                fileRequest.File.Sellers[0].Type = "Trust/Estate";
                fileRequest.File.Sellers[0].Name = "Seller1TrustName";
                fileRequest.File.Sellers[0].TIN = "98-7654321";

                fileRequest.File.Sellers[1].Type = "Business Entity";
                fileRequest.File.Sellers[1].Name = "Seller2EntityName";
                fileRequest.File.Sellers[1].TIN = "23-4567891";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            }
            catch (Exception e)
            {
                this.CreateFileWithGui();
                Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
            }
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
            string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
            if (FileNumber.Length > 3)
                Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
            else
                Assert.AreEqual("File was not created.", "File was not created.");
            #endregion

            Reports.TestStep = "Enter a gab code which has buyer type as trust Estate.";
            FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association");

            Reports.TestStep = "Create a new instance of Homeowner Association";
            FastDriver.HomeownerAssociation.SwitchToContentFrame();
            FastDriver.HomeownerAssociation.FindGABCode("BUYATTRNY");
            double SellrChg = 10.00;
            double BuyrChg = 10.00;
            double Totl = SellrChg + BuyrChg;
            FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: "Transfer Fee", buyerCharge: BuyrChg, sellerCharge: SellrChg);

            Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
            FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
            string TotalVal = Totl.ToString() + ".00";
            Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, TotalVal, 1, TableAction.GetText).Message.Trim());
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#7", TotalVal, "#3", TableAction.Click);
            FastDriver.ActiveDisbursementSummary.Edit.FAClick();

            Reports.TestStep = "Validate that Wire instructions are same as in business party org setup.";
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys(@"Wire");

            Support.AreEqual("412567189", FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue());
            Support.AreEqual("test bank name", FastDriver.EditDisbursement.ReceivingBankName.FAGetValue());
            Support.AreEqual("test address 1 test address 2", FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue());
            Support.AreEqual("41256718909787", FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue());
            Support.AreEqual("41256718909787", FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FAGetValue());
            FastDriver.BottomFrame.Save();
        }

        [TestMethod]
        public void FMUC0005B_REG0022()
        {
            try
            {

                #region Pre-requisite
                this.LoginAndAddRole("Refresh Workflow Process");
                #endregion

                Reports.TestDescription = "BR_ProactiveNotificationPreconditionset1: Proactive Notification Phase i:Precondition";
                this.LoginToAdm();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Select a buyer gab id and click on find button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                var newBussOrg = new BusinessOrganizationParameters()
                {
                    IDCode = "HUDFLINSR1"
                };
                FastDriver.AddressBookSearch.WaitForScreenToLoad().SearchAddressBook(newBussOrg.IDCode);
                FastDriver.AddressBookSearch.SwitchToContentFrame();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("#7", newBussOrg.IDCode, "#7", TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.LeftNavigation.Navigate<EmployeeSearch>(@"Home>System Maintenance>Employee Setup").WaitForScreenToLoad();
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                var employee = new EmployeeSearchParameters() { FirstName = @"FAST", LastName = "QA07" };
                FastDriver.EmployeeSearch.SearchEmployee(employee);
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(2, employee.FirstName + " " + employee.LastName, 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Change the Employee Type to Sales Rep.";
                FastDriver.EmployeeSetup.EmployeeTypes.FASelectItemBySendingKeys("Sales Rep");
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search an employee and click on Edit.";
                FastDriver.LeftNavigation.Navigate<EmployeeSearch>(@"Home>System Maintenance>Employee Setup").WaitForScreenToLoad();
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchEmployee(employee);
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(2, employee.FirstName + " " + employee.LastName, 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Make email address blank.";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                FastDriver.EmployeeSetup.EmailTypeEmailID.FASetText("");
                Keyboard.SendKeys("%O");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search an employee and click on Edit - 2nd time";
                FastDriver.LeftNavigation.Navigate<EmployeeSearch>(@"Home>System Maintenance>Employee Setup").WaitForScreenToLoad();
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchEmployee(employee);
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(2, employee.FirstName + " " + employee.LastName, 1, TableAction.Click);
                FastDriver.EmployeeSearch.Edit.FAClick();

                Reports.TestStep = "Enter the Employee Setup Email details and notification type as Task.";
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                FastDriver.EmployeeSetup.EmailTypeEmailID.FASetText("testProactivenotification@abc.com");
                FastDriver.EmployeeSetup.EmailTypeNotificationType.FASelectItemBySendingKeys("Task");
                FastDriver.EmployeeSetup.PhonesNotification.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Regional Process Summary and select a template.";
                try
                {
                    FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
                }
                catch (Exception e)
                {
                    FailTest("Appropriate rights are not assigned to the user to get the link -Regional Process Summary.");
                }

                Reports.TestStep = "Select a process and click Edit button";
                FastDriver.RegionalProcessSummary.SelectProcessFromSummaryTable(1, "AUTO_DONOT_TOUCH_StandardTemplateForSanity", 1, TableAction.Click);

                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add/Remove button for Process Event Selection.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Unselect the Process.";
                FastDriver.ProcessEventSelectionDlg.EscrowServiceAdded.FASetCheckbox(false);
                FastDriver.ProcessEventSelectionDlg.EscrowServiceRemoved.FASetCheckbox(false);
                FastDriver.ProcessEventSelectionDlg.FilecreatedwithOpenstatus.FASetCheckbox(false);
                FastDriver.ProcessEventSelectionDlg.TitleServiceAdded.FASetCheckbox(false);

                Reports.TestStep = "Select Process as Finalized and Adjusted invoice.";
                FastDriver.ProcessEventSelectionDlg.Final_AdjustedInvoice.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Select a task and click on Refresh button.";
                try
                {
                    FastDriver.LeftNavigation.Navigate<PendingRefreshSummary>(@"Home>System Maintenance>Process Setup>Pending Refresh Summary").WaitForScreenToLoad();
                    FastDriver.PendingRefreshSummary.WaitForScreenToLoad();
                }
                catch (Exception e)
                {
                    FailTest("Appropriate rights are not assigned to the user to get the link - Pending Refresh Summary.");
                }

                Reports.TestStep = "Click on Refresh.";
                FastDriver.PendingRefreshSummary.RefreshProcess.FAClick();

                Reports.TestStep = "Navigate to Pending Refresh Summary.";
                FastDriver.PendingRefreshSummary.WaitForRefeshComplete(300);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Obsolete]
        public void FMUC0005B_REG0023()
        {
            try
            {
                Reports.TestDescription = "BR_ProactiveNotificationPreconditionset2: Proactive Notification Phase 2:Edit an existing Process template and select Finalize a invoice";
                Reports.StatusUpdate("BR_ProactiveNotificationPreconditionset2 - Covered in FMUC0005B_REG0022.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0024()
        {

                Reports.TestDescription = "BR_ProactiveNotification:Precondition";
                Reports.StatusUpdate("Pre-condition for REG0025. Included in the same", true);

        }

        [TestMethod]
        public void FMUC0005B_REG0025()
        {
            try
            {
                Reports.TestDescription = "BR_FM12983_FM12995_FM12996_FM12989_FM13123: Validate the Notification functionality";
              
                #region Pre-requisite ADM setup
                string TaskName = "Auto_DONOTTOUCH_For_FMUC0005_1";
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "Auto_DONOTTOUCH_Prono_For_FMUC0005";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = "Search Package";
                ProcParams.State = "CA";
                ProcParams.County = "Imperial";
                ProcParams.ProcessEvent = "First Invoice Finalized";
                ProcParams.Tasks = new[] { TaskName };

                TaskTemplateParameters TaskParams = new TaskTemplateParameters();
                TaskParams.TaskName = TaskName;
                TaskParams.FBPRoles = new[] { "Buyer", "Seller", "Invoice To Party" };
                TaskParams.MessageTemplate = "PROMSG1";
                TaskParams.TaskCategory = "Post Closing";
                TaskParams.TaskStatus = "Started";
                TaskParams.DeliveryMethod = "Email";
                TaskParams.PublicTask = true;
                FAST_Login_ADM(true,1486);
               
                //
                Reports.TestStep = "Check stale process.";
                bool RecentlyCreated = FastDriver.RegionalProcessSummary.CheckIfFreshProcess(ProcParams.ProcessName);
                //
                if (!RecentlyCreated)
                {
                    Reports.TestStep = "Navigate to Task Template selection screen";
                    FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Home>System Maintenance>Process Setup>Task Templates").WaitForScreenToLoad();
                    Reports.TestStep = "Create Task.";
                    CreateTaskAndSetNotificationDetails(TaskParams);
                    Reports.TestStep = "Create process and associate task to it";
                    FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams, TaskParams);
                }

                #endregion
                
                this.LoginToFast();
                string FileNumber = CreateFile(TransactionType: "SEARCH");
                  //

                Reports.TestStep = "Navigate to Buyer screen and click on Edit";
                this.NavigateActOnBuyr(4, "Individual", 1, "Edit", "", 1);

                Reports.TestStep = "Enter Current Email address and validate that notification is checked by default.";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItemBySendingKeys("E-Mail");
                Playback.Wait(4000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.CurrentPhoneNumber);
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("Email@abc.com" + FAKeys.Tab);
                Support.AreEqual("true", FastDriver.BuyerSellerSetup.CurrentPhoneNotification.GetAttribute("checked").ToString());

                Reports.TestStep = "Enter first fee in Title and escrow.";
                this.NavigatAndEnterFee("New Home Rate (Title Only)", "1.99", "2.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Set on final button in Invoice screen.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                Support.AreEqual(@"True", FastDriver.InvoiceFees.Final.Enabled.ToString(), "Verify whether the Final element is enabled.");
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction("#5", "UNINVOICED", "#6", TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.InvoiceFees.Final.FAClick();
                Playback.Wait(20000);
                Reports.TestStep = "Start the task.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.ClickStartTaskCheckboxForTask(ProcParams.ProcessName, ProcParams.Tasks[0]);
                FastDriver.FileWorkflow.ClickApply();
                Dictionary<string, DateTime> DeliveryTime = new Dictionary<string, DateTime>();
                DeliveryTime["StartTime"] = DateTime.Now;
                DeliveryTime["CompletionTime"] = DateTime.Now;
                Reports.TestStep = @"Navigate to Event/Tracking Log, validate refresh event";
                string Event = "[Notification via Email Successful]";
                WaitForEventToGetRecorded(Event);
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateSourceForEvent(Event, "FAST Automated Notification").ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateStartDateForEvent(Event, DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateCompletionDateForEvent(Event, DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateUserNameForEvent(Event, @"FAST QA07").ToString());
                string Comment = FastDriver.EventTrackingLog.GetCommentForEvent(Event);
                Support.AreEqualTrim("True", Comment.Contains("Recipients: Buyer1FirstName Buyer1LastName").ToString());
                Support.AreEqualTrim("True", Comment.Contains("Documents: Invoice").ToString());
                Support.AreEqualTrim("True", Comment.Contains(FileNumber).ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0026()
        {
            try
            {
                Reports.TestDescription = "BR_FM13118_FM12990_FM13120: 1.Validate that when email address is removed then notification checkbox should hide";

                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {

                    this.CreateFileWithWebSer();
                }
                catch (Exception)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("File was created using GUI.", "", "", "", "Web Services Failed", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion

                Reports.TestStep = "Navigate to Buyer screen and click on Edit";
                this.NavigateActOnBuyr(4, "Individual", 1, "Edit", "", 1);

                Reports.TestStep = "Enter Current Email address and validate that notification is checked by default.";
                this.ChagPhTypToEmalOrBusFax();

                Reports.TestStep = "Navigate to Buyer screen and click on Edit";
                this.NavigateActOnBuyr(4, "Individual", 1, "Edit", "", 1);

                Reports.TestStep = "Change current phone type to any other type than email";
                this.ChagPhTypToPager();

                Reports.TestStep = "Uncheck the notification checkbox manually";
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.EmailNotification.IsDisplayed().ToString());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0027()
        {
            try
            {
                Reports.TestDescription = "BR_FM13121: Validate the Display Enable Notification Checkbox on Fax Number Entry";

                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("File was created using GUI.", "", "", "", "Web Services Failed", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion

                Reports.TestStep = "Navigate to Buyer screen and click on Edit";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                this.ChagPhTypToEmalOrBusFax("Business Fax");
                Reports.TestStep = "Uncheck the notification checkbox manually";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.CurrentPhoneNotification.FASetCheckbox(false);

                Reports.TestStep = "BR_FM12986: Hide Enable Notification Box for Change to Non-Email/Fax Type - Starts here...";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber6.FAClick();
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber6.FASetText("");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentPhoneNotification.IsSelected().ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Obsolete]
        public void FMUC0005B_REG0028()
        {
            try
            {
                Reports.TestDescription = "BR_FM12986: Hide Enable Notification Box for Change to Non-Email/Fax Type";
                Reports.StatusUpdate("BR_FM12986 (Covered in FMUC0005B_REG0027).", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0029()
        {
            try
            {
                Reports.TestDescription = ".";

                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("File was created using GUI.", "", "", "", "Web Services Failed", "", Reports.Result(false), "");
                }

                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FirstFileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FirstFileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FirstFileNumber + "", "File was created with " + FirstFileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion

                Reports.TestStep = "Navigate to Buyer screen and click on Edit";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                this.ChagPhTypToEmalOrBusFax();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating 2nd file with web services";
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("2nd File was created using GUI.", "", "", "", "Web Services Failed", "", Reports.Result(false), "");
                }

                Reports.TestStep = "Select the Buyer items for copy.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                FastDriver.StarterReference.StarterFileNumber.FASetText(FirstFileNumber + FAKeys.Tab);
                FastDriver.StarterReference.SelectFileItems.FASetCheckbox(true);
                FastDriver.StarterReference.BuyersData.FASetCheckbox(true);

                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Navigate to Buyer screen and click on Edit";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber6.FAClick();
                Support.AreEqual("Email@abc.com", FastDriver.BuyerSellerSetup.CurrentPhoneNumber6.FAGetValue());
                Support.AreEqual("true", FastDriver.BuyerSellerSetup.EmailNotification.GetAttribute("checked").ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0030()
        {
            try
            {
                Reports.TestDescription = "FM9736_FM9737_Precondition: Add a new employed by in regional level";

                Reports.TestStep = "Login to Adm";
                this.LoginToAdm();
                string FormType = AutoConfig.FormType;

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Click on select displayed by in buyer and click on add employed by button";

                if (FormType.Equals("CD"))
                    FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST");
                else if (FormType.Equals("HUD"))
                    FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>AUTOCD");

                if (!(FastDriver.ProcessingRegionSetup.DisplayInBuyer.Selected))
                    FastDriver.ProcessingRegionSetup.DisplayInBuyer.FASetCheckbox(true);

                if (!(FastDriver.ProcessingRegionSetup.DisplayInSeller.Selected))
                    FastDriver.ProcessingRegionSetup.DisplayInSeller.FASetCheckbox(true);

                string EmplName = "FAST QA07 - Test";
                if (FastDriver.ProcessingRegionSetup.EmployedByTable.Text.Contains(EmplName))
                {
                    this.ActivateEmployee(EmplName);
                }
                else
                {
                    //If Employee does not exist, adding new....
                    Reports.TestStep = "Employee does not exist, adding new.";
                    FastDriver.ProcessingRegionSetup.EmployedByAddNew.FAClick();
                    FastDriver.ProcessingRegionSetup.SwitchToContentFrame();
                    FastDriver.ProcessingRegionSetup.EmployedByName.FASetText(EmplName);
                    FastDriver.BottomFrame.Done();
                    FastDriver.ProcessingRegionSetup.SwitchToContentFrame();
                }
                this.ActivateEmployee(EmplName);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0031()
        {
            try
            {
                Reports.TestDescription = "FM9736_FM9737: Validate that same employed by is appearing in buyer screen";

                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("File was created using GUI.", "", "", "", "Web Services Failed", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion

                Reports.TestStep = "Navigate to Buyer screen and click on Edit";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                string ActVal = FastDriver.BuyerSellerSetup.EmployedBy.FAGetAllTextFromSelect();
                string UserOne = "Fast qa07 - Test";
                string UserTwo = "FAST QA07 - Test";
                if ( ActVal.Contains(UserOne) )
                    Support.AreEqual("True", FastDriver.BuyerSellerSetup.EmployedBy.FAGetAllTextFromSelect().Contains("Fast qa07 - Test").ToString());
                else if(ActVal.Contains(UserTwo))
                    Support.AreEqual("True", FastDriver.BuyerSellerSetup.EmployedBy.FAGetAllTextFromSelect().Contains("FAST QA07 - Test").ToString());
                else
                    Support.AreEqual("False", "In Employed By list box - no value found with either "+UserOne+" - or  - "+UserTwo+"");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0032()
        {
            try
            {
                Reports.TestDescription = "FM9736_FM9737_Postcondition: Remove the added employed by value from regional level";

                this.LoginToAdm();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Remove the added employed by";
                string FormType = AutoConfig.FormType;
                if (FormType.Equals("CD"))
                    FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST");
                else if (FormType.Equals("HUD"))
                    FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>AUTOCD");

                if(FastDriver.ProcessingRegionSetup.EmployedByTable.Text.Contains("Fast qa07 - Test"))
                FastDriver.ProcessingRegionSetup.EmployedByTable.PerformTableAction("Employed By", "Fast qa07 - Test", "Employed By", TableAction.Click);
                else if (FastDriver.ProcessingRegionSetup.EmployedByTable.Text.Contains("FAST QA07 - Test"))
                    FastDriver.ProcessingRegionSetup.EmployedByTable.PerformTableAction("Employed By", "FAST QA07 - Test", "Employed By", TableAction.Click);

                FastDriver.ProcessingRegionSetup.EmployedByName.FASetText("#");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0033()
        {
            try
            {
                Reports.TestDescription = "FieldDefinations: Validating field definations in Buyer screen";
                string StateListValues = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
                string CountryListValues = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
                string ActVal;
                string TempVal;


                #region Login and Create File using Web Services
                this.LoginToFast();

                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("File was created using GUI.", "", "", "", "Web Services Failed", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion


                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                FastDriver.TopFrame.FileNumberEditBox.FASetText("62947" + FAKeys.Tab);
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();

                Reports.TestStep = "Select Current Address in Set to Other in Current and edit the address.";
                this.NavigateActOnBuyr(1, "1", 1, "", "", 1);
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                this.SendKeys("%E");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("#");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Street1Other");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Street2Other");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("#");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("#");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the hot key action for Search functionality.";
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                Reports.TestStep = "Sending key- Alt+N.";
                this.SendKeys("%N");
                Reports.TestStep = "Sending key- Alt+E.";
                this.SendKeys("%E");

                Reports.TestStep = "Validate newly added Entity Type Corporate in Address Book search.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(windowName: "Address Book Buyer/Seller Search");
                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem("Corporate");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate fields for type Individual lower bound.";
                this.ValidatIndivLowrBound();

                Reports.TestStep = "Validate fields for type Individual upper bound.";
                this.ValidatIndivUpprBound();

                Reports.TestStep = "Validate fields for type Individual exact value.";
                this.ValidatIndivExactVal(StateListValues, CountryListValues);


                Reports.TestStep = "Select Current Address in Set to Other in Current and edit the address.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                BuyerParameters buyer = new BuyerParameters()
                {
                    CurrentStreet1 = "#",
                    CurrentStreet2 = "Street1Other",
                    CurrentStreet3 = "Street2Other",
                    CurrentCity = "#",
                    CurrentCounty = "#"
                };
                FastDriver.BuyerSellerSetup.BuyerDetails(buyer);

                Reports.TestStep = "Validate fields for type husband and wife lower bound.";
                this.ValidatHusWifLowrBound();

                Reports.TestStep = "Validate fields for type husband and wife upper bound.";
                Support.AreEqual("Husband/Wife", FastDriver.BuyerSellerSetup.RetrieveBuyerType());

                TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452";
                FastDriver.BuyerSellerSetup.Salutation.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Salutation.FAGetValue());
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());

                TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());


                ActVal = FastDriver.BuyerSellerSetup.CurrentState.FAGetText();
                Support.AreEqual(StateListValues, ActVal);
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
                Support.AreEqual("23234-4244", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
                ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();
                Support.AreEqual(CountryListValues, ActVal);

                TempVal = "DHGd775689$!@1reet34";
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue());
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue());
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue());
                FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FAGetValue());
                FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue());

                TempVal = "12345";
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FAGetValue());

                TempVal = "43444234234";
                FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual("434-44-2342", FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FAGetValue());

                Reports.TestStep = "Validate fields for type husband and wife exact value.";
                Support.AreEqual("Husband/Wife", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
                TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452";
                FastDriver.BuyerSellerSetup.Salutation.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Salutation.FAGetValue());
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());


                TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());

                TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^$";
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());

                ActVal = FastDriver.BuyerSellerSetup.CurrentState.FAGetText();
                Support.AreEqual(StateListValues, ActVal);
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
                Support.AreEqual("23234-4244", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());

                ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();
                Support.AreEqual(CountryListValues, ActVal);

                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue());
                Support.AreEqual(StateListValues, FastDriver.BuyerSellerSetup.ForwardingState.FAGetText());
                TempVal = "23234-4244";
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue());
                ActVal = FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetText();
                Support.AreEqual(CountryListValues, ActVal);


                TempVal = "DHGd775689$!@1reet34";
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue());
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue());
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue());
                FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FAGetValue());
                FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue());

                TempVal = "12345";
                FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FAGetValue());

                TempVal = "434-44-2342";
                FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual("434-44-2342", FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FAGetValue());


                Reports.TestStep = "Select Current Address in Set to Other in Current and edit the address.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("#");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Street1Other");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Street2Other");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("#");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("#");

                Reports.TestStep = "Navigate to Buyers page";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Business Entity", false);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Buyer BusEntity Name");
                FastDriver.BuyerSellerSetup.Salutation.FASetText("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452");
                Support.AreEqual("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452", FastDriver.BuyerSellerSetup.Salutation.FAGetValue());

                TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet345";
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());

                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());

                ActVal = FastDriver.BuyerSellerSetup.CurrentState.FAGetText();
                Support.AreEqual(StateListValues, ActVal);
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
                Support.AreEqual("23234-4244", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
                ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();
                Support.AreEqual(CountryListValues, ActVal);

                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue());
                Support.AreEqual(StateListValues, FastDriver.BuyerSellerSetup.ForwardingState.FAGetText());
                TempVal = "23234-4244";
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue());
                ActVal = FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetText();
                Support.AreEqual(CountryListValues, ActVal);

                TempVal = "AA AE Alaska Alabama AP Arkansas American Samoa Arizona California Colorado Connecticut District Of Columbia Delaware Florida Federated States Of Micronesia Georgia Guam Hawaii Iowa Idaho Illinois Indiana Kansas Kentucky Louisiana Massachusetts Maryland Maine Marshall Islands Michigan Minnesota Missouri Northern Mariana Islands Mississippi Montana North Carolina North Dakota Nebraska New Hampshire New Jersey New Mexico Nevada New York Ohio Oklahoma Oregon Pennsylvania Puerto Rico Palau Rhode Island South Carolina South Dakota Tennessee Texas Utah Virginia Virgin Islands Vermont Washington Wisconsin West Virginia Wyoming";
                ActVal = FastDriver.BuyerSellerSetup.StateofIncorp.FAGetText();
                Support.AreEqual(TempVal, ActVal);
                TempVal = "Business Trust Corporation General Partnership Joint Venture Limited Liability Company Limited Liability Partnership Limited Partnership Non-Profit Corporation Other Professional Corporation";
                ActVal = FastDriver.BuyerSellerSetup.EntityType.FAGetText();
                Support.AreEqual(TempVal, ActVal);
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("3424" + FAKeys.Tab);
                Support.AreEqual("??-???????", FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue());


                Reports.TestStep = "Validate fields for Business entity type upper bound.";
                this.ValidateBusEntyUprBond();

                Reports.TestStep = "Select Current Address in Set to Other in Current and edit the address.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("#");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Street1Other");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Street2Other");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("#");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("#");

                Reports.TestStep = "Validate fields for Trust Estate type Lower bound.";
                FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Trust/Estate");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual("Trust/Estate", FastDriver.BuyerSellerSetup.RetrieveBuyerType());

                TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452";
                FastDriver.BuyerSellerSetup.Salutation.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Salutation.FAGetValue());
                FastDriver.BuyerSellerSetup.MiscRef1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
                FastDriver.BuyerSellerSetup.MiscRef2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());

                FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
                TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());


                ActVal = FastDriver.BuyerSellerSetup.CurrentState.FAGetText();
                Support.AreEqual(StateListValues, ActVal);
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
                Support.AreEqual("23234-4244", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
                ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();
                Support.AreEqual(CountryListValues, ActVal);

                FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
                TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue());
                FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue());
                Support.AreEqual(StateListValues, FastDriver.BuyerSellerSetup.ForwardingState.FAGetText());
                TempVal = "23234-4244";
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue());
                ActVal = FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetText();
                Support.AreEqual(CountryListValues, ActVal);

                TempVal = "qwertyui opasdad da dadadweq c 23f23v234";
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue());

                TempVal = "434-44-2342";
                FastDriver.BuyerSellerSetup.TrustNumber.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.TrustNumber.FAGetValue());
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.TrustSSNtext.FAGetValue());

                TempVal = "qwwetqeqw rqwyeqreu etqwiteiq teqwieuq12";
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.SwitchToContentFrame(); //Refresh
                FastDriver.BuyerSellerSetup.TrustAuthorizedName.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.TrustAuthorizedName.FAGetValue());
                TempVal = "Administrator Co-Trustee Executor Other Personal Representative Successor Trustee Trustee";
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.TrustAuthorizedType.FAGetText());

                TempVal = "qwerty 12338 qawsedrf 906820hgj iqwhgbsada 3424423424 retdsfaeqeqhgnn";
                FastDriver.BuyerSellerSetup.TrustTitle.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.TrustTitle.FAGetValue());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0034()
        {
            try
            {
                Reports.TestDescription = "EW4: Validate error warning condition for change of buyer type from husband to individual";

                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("File was created using GUI.", "", "", "", "Web Services Failed", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion

                Reports.TestStep = "Chang from Husband wife to Individual.";
                this.NavigateActOnBuyr(4, "Husband/Wife", 1, "Edit", "", 1);
                string InstanceType = @"Individual";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys(InstanceType);
                Playback.Wait(2000);
                string Message = FastDriver.WebDriver.HandleDialogMessage(false).Clean();
                Reports.TestStep = "Validate warning message is as per EWC#4 and Click on Ok button";
                string ExpVal = "Click OK to convert this principal";
                Support.AreEqual(Message, ExpVal);
                Message = FastDriver.WebDriver.HandleDialogMessage(true).Clean();
                Message = Message.Trim().Replace("\n", String.Empty).Replace("\r", " ");
                ExpVal = "Click OK to convert Spouse 1 into individual Otherwise Click Cancel to convert Spouse 2";
                Support.AreEqual(Message, ExpVal);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0035_PH()
        {

            try
            {
                Reports.TestDescription = "FM7893_FM7894_PlaceHolder: PlaceHolder:Related To Ten Interface";// 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0005B_REG0036_PH()
        {

            try
            {
                Reports.TestDescription = "IF13217_IF13218_IF14028_IF14084_PlaceHolder: PlaceHolder:Related To FAMOS";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0005B_REG0037_PH()
        {
            try
            {
                Reports.TestDescription = "FM9113_PlaceHolder: Validate that 'Attorney in Fact' Unavailable for Business Entity and trust entity Buyer/Seller";
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0038()
        {
            try
            {
                Reports.TestDescription = "FD:Additional vesting";

                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("File was created using GUI.", "", "", "", "Web Services Failed", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion

                Reports.TestStep = "Navigate to Buyer summary screen and click on Edit.";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);

                Reports.TestStep = "Validate fields for text field Additional Vesting lower bound.";
                string TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452342 vhg!@12354535353453 hgjghjgjgjg dtsdtet345rwrww";
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue());


                Reports.TestStep = "Validate fields for text field Additional Vesting upper bound.";
                TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452342 vhg!@12354535353453 hgjghjgjgjg dtsdtet345rwrwww1";
                string TempValTwo = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452342 vhg!@12354535353453 hgjghjgjgjg dtsdtet345rwrwww";
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText(TempVal + FAKeys.Tab);
                Support.AreEqual(TempValTwo, FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue());

                Reports.TestStep = "Validate fields for text field Additional Vesting exact value.";
                FastDriver.BuyerSellerSetup.AdditionalVesting.FASetText(TempValTwo + FAKeys.Tab);
                Support.AreEqual(TempValTwo, FastDriver.BuyerSellerSetup.AdditionalVesting.FAGetValue());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0039()
        {
            try
            {
                Reports.TestDescription = "FM9102  Identify Exchange Company with its Buyer or Seller";
                Reports.TestStep = "FM9102  Identify Exchange Company with its Buyer or Seller : Precondition (Create required phrase and template)";
                LoginToAdm();
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Dictionary<string, string> TemplateDetails = FastDriver.TemplateMaintenanceInformation.CreateNewDocumentTemplate("Buyer", new List<string> { "BXCNAME", "BXCNAME", "BXCNAME", "BXCNAME", "BUNAME", "BUNAME", "BUNAME", "BUNAME" });
                #region Login and Create File using Web Services
                this.LoginToFast();
                try
                {
                    this.CreateFileWithWebSer();
                }
                catch (Exception)
                {
                    this.CreateFileWithGui();
                    Reports.UpdateDebugLog("File was created using GUI.", "", "", "", "Web Services Failed", "", Reports.Result(false), "");
                }
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion


                Reports.TestStep = "Navigate to Buyer summary screen and create/edit the instance.";
                this.NavigateActOnBuyr(4, "Individual", 1, "Edit", "", 1);

                Reports.TestStep = "Edit buyer type individual to add exchange company";
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                Reports.TestStep = "Set an exchange company id from Global address book for Individual.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Remove buyer of type husband wife if exists. (To verify full vesting for individual buyer)";

                Reports.TestStep = "Edit buyer type Husband/Wife to add exchange company";
                this.NavigateActOnBuyr(4, "Husband/Wife", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                Reports.TestStep = "Set an exchange company id from Global address book for Husband/Wife.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create buyer Trust/Estate and add exchange company to it";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Trust/Estate", false);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Buyer Trust Name" + FAKeys.Tab);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                Reports.TestStep = "Set an exchange company id from Global address book for Trust Estate.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Create buyer Business entity and add exchange company to it";
                BuyerParameters buyer = new BuyerParameters()
                {

                    BusinessEntityShortname = "Buyer BusEntity Name",
                    StateofIncorp = "Alaska",
                    EntityType = "Business Trust",
                    BusinessEntitySsn = "53-4553543"
                };
                this.CreateBusEntBuyr(buyer);
                FastDriver.BuyerSellerSetup.Exchange_Company();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                Reports.TestStep = "Set an exchange company id from Global address book for Bus Entity.";
                FastDriver.ExchangeCompany.ClickFind();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "EXCH01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Document Repository - click Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.WaitForScreenToLoad();                
                FastDriver.DocumentRepository.AddGeneric.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();

                Reports.TestStep = "Select template created in ADM & click on save button.";
                FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
                FastDriver.AdHocDocuments.TemplateType.FASelectItem(@"Escrow Instruction");
                FastDriver.AdHocDocuments.State.FASelectItemByIndex(0);
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(TemplateDetails["TemplateDescription"]);
                FastDriver.AdHocDocuments.FindNow.FAClick();

                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", TemplateDetails["TemplateDescription"], "Description", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Thread.Sleep(3000);
                Reports.TestStep = "Navigate to document repository and Edit saved doc.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateDetails["TemplateDescription"], "Name", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify the Phrase name and Business Contacts for the Business source.";
                FastDriver.DocumentPreparationwin.WaitForElementToLoad(FastDriver.DocumentPreparationwin.PhraseTable);
                string ValOne = "Buyer Name(s)";
                string ActVal = FastDriver.DocumentPreparationwin.PhraseTable.PerformTableAction(2, ValOne, 3, TableAction.GetText, startOffRow: 1).Message.Trim();
                Support.AreEqual("Buyer1Firstname Buyer1Lastname", ActVal);
                ActVal = FastDriver.DocumentPreparationwin.PhraseTable.PerformTableAction(2, ValOne, 3, TableAction.GetText, startOffRow: 2).Message.Trim();
                Support.AreEqual("Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname", ActVal);                

                Support.AreEqual(FastDriver.DocumentPreparationwin.VerifyTextInTable(3,ValOne).ToString(),FastDriver.DocumentPreparationwin.VerifyValueInTable(3,"Buyer Trust Name").ToString());
                Support.AreEqual(FastDriver.DocumentPreparationwin.VerifyTextInTable(4, ValOne).ToString(), FastDriver.DocumentPreparationwin.VerifyValueInTable(4, "Buyer BusEntity Name").ToString());
                
                ValOne = "Buyer Exchange Company: Name (Lines 1-2)";
                string ValTwo = "Exchange Company1 Name 1,Exchange Company1 Name 2";
                ActVal = FastDriver.DocumentPreparationwin.PhraseTable.PerformTableAction(2, ValOne, 3, TableAction.GetText, startOffRow: 1).Message.Trim();
                Support.AreEqual(ValTwo, ActVal);
                ActVal = FastDriver.DocumentPreparationwin.PhraseTable.PerformTableAction(2, ValOne, 3, TableAction.GetText, startOffRow: 2).Message.Trim();
                Support.AreEqual(ValTwo, ActVal);
                ActVal = FastDriver.DocumentPreparationwin.PhraseTable.PerformTableAction(2, ValOne, 3, TableAction.GetText, startOffRow: 3).Message.Trim();
                Support.AreEqual(ValTwo, ActVal);
                ActVal = FastDriver.DocumentPreparationwin.PhraseTable.PerformTableAction(2, ValOne, 3, TableAction.GetText, startOffRow: 4).Message.Trim();
                Support.AreEqual(ValTwo, ActVal);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0040()
        {
            try
            {
                Reports.TestDescription = "Validate full vesting for Trust estate and Business entity and CF Notification: EXPECTED TO FAIL Bugs 638021 638014";
                string TrusteeShortNameOne = "Buyer Trust Name";
                string TrustDate = "07-10-2012";

                #region Login and Create File using with UI
                this.LoginToFast();

                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                try
                {
                    FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                this.CreateBasicFile();

                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                if (FileNumber.Length > 3)
                    Assert.AreEqual("File was created with " + FileNumber + "", "File was created with " + FileNumber + "");
                else
                    Assert.AreEqual("File was not created.", "File was not created.");
                #endregion

                Reports.TestStep = "Create Buyer Trustee or Estate and enter all details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Trust/Estate", false);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText(TrusteeShortNameOne + FAKeys.Tab);
                FastDriver.BuyerSellerSetup.TrustDated.FASetText(TrustDate + FAKeys.Tab);

                Reports.TestStep = "Validate full vesting";
                Reports.TestStep = "Get buyers data to validate full vesting";
                this.NavigateActOnBuyr(4, "Trust/Estate", 4, "Edit", "", 1);
                Reports.TestStep = "Get buyers data to validate full vesting";
                string TrustEstFullVesting = TrusteeShortNameOne + ", dated " + Convert.ToDateTime(TrustDate).ToString("MMMM d, yyyy");
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.ClickRefreshShort();
                string[] TArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                Support.AreEqual(TArrOne[0], TrustEstFullVesting);
                Support.AreEqual(TArrOne[1], TrustEstFullVesting);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Refresh functionality in full vesting Bug# 638014";
                this.NavigateActOnBuyr(4, "Trust/Estate", 4, "Edit", "", 1);
                BuyerParameters buyer = new BuyerParameters()
                {
                    TrusteeShortNameTwo = "Buyer Trust Nam",
                    TrustDated = "08-10-2012"
                };
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText(buyer.TrusteeShortNameTwo + FAKeys.Tab);
                FastDriver.BuyerSellerSetup.TrustDated.FASetText(buyer.TrustDated + FAKeys.Tab);
                string TrustShrtNameTwo = FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue();
                string TrustDtdTwo = FastDriver.BuyerSellerSetup.TrustDated.FAGetValue();
                TrustEstFullVesting = TrustShrtNameTwo + ", dated " + Convert.ToDateTime(TrustDtdTwo).ToString("MMMM d, yyyy");
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                TArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                Support.AreEqual(TrustEstFullVesting, TArrOne[0]);
                Support.AreEqual(TrustEstFullVesting, TArrOne[1]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate CF notofication type for trust/estate";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                string ErrValOne = "(???)???-????";
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("CF Notification", "111", ErrValOne, "1111111111", "(111)111-1111");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentPhoneNotification.IsDisplayed().ToString());
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                if (FastDriver.WebDriver.WaitForAlertToExist(10))
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    Reports.StatusUpdate("Error occured for CF notifcation phone type", false);
                }
                Reports.TestStep = "Remove buyer of type Trust/Estate if exists. (To verify full vesting for BusinessEntity buyer)";
                this.NavigateActOnBuyr(4, "Trust/Estate", 1, "Clear", "", 1);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Remove full vesting buyer of type Trust/Estate if exists. (To verify full vesting for BusinessEntity buyer)";
                this.NavigateActOnBuyr(4, "Trust/Estate", 1, "Edit", "", 1);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(4, "Trust/Estate", 4, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Buyer Business Entity and enter all details.";
                buyer = new BuyerParameters()
                {

                    BusinessEntityShortname = "Buyer BusEntity Name",
                    StateofIncorp = "Alaska",
                    EntityType = "Business Trust",
                    BusinessEntitySsn = "53-4553543"
                };
                this.CreateBusEntBuyr(buyer);

                Reports.TestStep = "Get buyers data to validate full vesting";
                string BusEntFullVesting = buyer.BusinessEntityShortname + ", an " + buyer.StateofIncorp + " " + buyer.EntityType.ToLower();
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                TArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                Support.AreEqual(BusEntFullVesting, TArrOne[0]);
                Support.AreEqual(BusEntFullVesting, TArrOne[1]);
                FastDriver.BottomFrame.Done();
                buyer = new BuyerParameters()
                {

                    BusinessEntityShortname = "Buyer BusEntity Nam",
                    StateofIncorp = "Alabama",
                    EntityType = "Corporation"
                };
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText(buyer.BusinessEntityShortname + FAKeys.Tab);
                FastDriver.BuyerSellerSetup.StateofIncorp.FASelectItem(buyer.StateofIncorp);
                FastDriver.BuyerSellerSetup.EntityType.FASelectItem(buyer.EntityType);
                BusEntFullVesting = buyer.BusinessEntityShortname + ", an " + buyer.StateofIncorp + " " + buyer.EntityType.ToLower();
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.WaitForScreenToLoad();
                FastDriver.BuyerVesting.ClickRefreshFull();
                FastDriver.BuyerVesting.ClickRefreshShort();
                TArrOne = FastDriver.BuyerVesting.GetAllFieldsValues();
                Support.AreEqual(BusEntFullVesting, TArrOne[0]);
                Support.AreEqual(BusEntFullVesting, TArrOne[1]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate phone types CF Notification. Expected to fail";
                Reports.TestStep = "Validate CF notofication type for Business Entity";
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("CF Notification", "111", ErrValOne, "1111111111", "(111)111-1111");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentPhoneNotification.IsDisplayed().ToString());
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                if (FastDriver.WebDriver.WaitForAlertToExist(20))
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    Reports.StatusUpdate("Error occured for CF notifcation phone type", false);
                }

                Reports.TestStep = "Create Buyer of type Individual.";
                buyer = new BuyerParameters()
                {
                    BuyerType = "Individual",
                    First = "Buyer1FN",
                    Middle = "Buyer1MN",
                    Last = "Buyer1LN",
                    SSN = "123-45-6789",
                };
                this.CreateIndiBuyr(buyer);

                Reports.TestStep = "Validate phone types CF Notification. Expected to fail";
                Reports.TestStep = "Validate CF notofication type for Individual";
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("CF Notification", "111", ErrValOne, "1111111111", "(111)111-1111");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentPhoneNotification.IsDisplayed().ToString());
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                if (FastDriver.WebDriver.WaitForAlertToExist(20))
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    Reports.StatusUpdate("Error occured for CF notifcation phone type", false);
                }

                Reports.TestStep = "Create Buyer of type Husband/Wife .";
                this.NavigateActOnBuyr(1, "1", 1, "Edit", "", 1);
                FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Husband/Wife");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();

                Reports.TestStep = "Validate CF notofication type for Husband/Wife";
                FastDriver.BuyerSellerSetup.SelctPhonListEntrVal("CF Notification", "111", ErrValOne, "1111111111", "(111)111-1111");
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentPhoneNotification.IsDisplayed().ToString());
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                if (FastDriver.WebDriver.WaitForAlertToExist(20))
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    Reports.StatusUpdate("Error occured for CF notifcation phone type", false);
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0005B_REG0041()//SRT
        {
            try
            {

                Reports.TestDescription = "TC_737856_US_698858 - ROOT CAUSE FIX--FAST - File 2092444/ Buyers Menu / Terri Blewett  / Internal System Error";
                #region datasetup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log Into Fast Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new basic file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Buyer screen";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

                Reports.TestStep = "Select Individual Buyer Type and enter First and Last name";
                Reports.TestStep = "On Current Phones section, select Home Phone for the first dropdown list on Type column";
                Reports.TestStep = "Enter random number on Number column next to Home Phone ";
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("1234567891");

                Reports.TestStep = "Click on Done button";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the created buyer and click on Edit button";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.DoubleClick);

                Reports.TestStep = "On the Current Phones section, select CF Notification for the first dropdown list on Type column";
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem("CF Notification");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

                Reports.TestStep = "Add valid e-mail on Number column next to CF Notification";
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("test@firstam.com");

                Reports.TestStep = "Click on Done button ";
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the created buyer and click on Edit button";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

                Reports.TestStep = "On Current Phones, ensure CF Notification is selected for the last row on Type column";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneType7.FAGetSelectedItem().Contains("CF Notification").ToString(), "Verifying CF Notification is selected");

                Reports.TestStep = "Ensure previously added E-mail is displayed on Number column next to CF Notification";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.CurrentPhoneNumber7.FAGetValue().Contains("test@firstam.com").ToString(), "Verifying CF Notification e-mail is added");


            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }


        //Team                           :  SRT-Team2
        //Iteration                      :  r09
        //UserStory                      :  User Story 830371: N-issue: EVAL03 - Release 10.5 - Elements are not displaying correctly after selecting CF Notification on Buyers/Sellers screen.
        // TestCase                      :  852331
        //Appended By/ Created By        :  Diego Hilario

        [TestMethod]
        public void FMUC0005B_REG0042()
        {
            try
            {
                Reports.TestDescription = "To Verify US# 830371 - Ext. field to update correctly after changing Current/Forwarding Phones type - Buyer";

                Reports.TestStep = "Log in to FAST IIS";
                LoginToFast();

                Reports.TestStep = "Create a basic file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Buyer/Seller screen and add First and Last names on Buyer/Seller Details section ";

                FastDriver.BuyerSellerSummary.Open(true);
                FastDriver.BuyerSellerSummary.EditBuyerSeller("Individual");

                Reports.TestStep = "On Current Phones section, select CF Notification on the dropdown menu for the first row";
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem("CF Notification");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Playback.Wait(2000);

                Reports.TestStep = "Ensure Ext. textbox is removed for the first row ";
                Support.AreEqual(false, FastDriver.BuyerSellerSetup.CurrentPhoneOneExtnTxt.Exists(), "Verifying Ext. textbox is removed");

                Reports.TestStep = "On first row, change the Type back to Home Phone";
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem("Home Phone");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Playback.Wait(2000);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.CurrentPhoneOneExtnTxt.Exists(), "Verifying Ext. textbox is displayed");

                Reports.TestStep = "Perform steps 4-6 for Forwarding Phones section using E-mail type instead of CF Notification";

                Reports.TestStep = "On Current Phones section, select CF Notification on the dropdown menu for the first row";
                FastDriver.BuyerSellerSetup.ForwardingPhoneType.FASelectItem("E-Mail");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Playback.Wait(2000);

                Reports.TestStep = "Ensure Ext. textbox is removed for the first row ";
                Support.AreEqual(false, FastDriver.BuyerSellerSetup.ForwardingExtension.Exists(), "Verifying Ext. textbox is removed");

                Reports.TestStep = "On first row, change the Type back to Home Phone";
                FastDriver.BuyerSellerSetup.ForwardingPhoneType.FASelectItem("Home Phone");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Playback.Wait(2000);
                Support.AreEqual(true, FastDriver.BuyerSellerSetup.ForwardingExtension.Exists(), "Verifying Ext. textbox is displayed");

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }




        #endregion
        #region Private Methods

        private void ValidateAgain(string FileNumber)
        {
            Playback.Wait(5000);
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
            FastDriver.EventTrackingLog.SelectEventCategory("Notifications");
            Support.AreEqual(@"True", FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Notification via Email Successful]").ToString());
            int RowCount = FastDriver.EventTrackingLog.EventTable.GetRowCount();

            for (int RowNumber = 1; RowNumber <= RowCount; RowNumber++)
            {
                string ColmData = FastDriver.EventTrackingLog.EventTable.PerformTableAction(RowNumber, 5, TableAction.GetText).Message.Clean();
                if (ColmData.Contains("Recipients: Buyer1Firstname Buyer1Lastname") && ColmData.Contains("Documents: Invoice") && ColmData.Contains(FileNumber))
                    break;
                if (RowNumber == RowCount)
                {
                    Reports.UpdateDebugLog("Verify Text in Event Table ", "", "File Number in table", "Text- ", FileNumber, "", Reports.Result(false), "");
                    Assert.AreEqual("Test Failed", "Test Failed - Look at Results.XML for detailed report.");
                }
            }
        }
        private void ValidatIndivExactVal(string StateListValues, string CountryListValues)
        {
            Support.AreEqual("Individual", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
            string TempVal = "DHGd775689$!@1reet34";
            FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
            FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue());
            FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());
            FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText("12345" + FAKeys.Tab);
            Support.AreEqual("12345", FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue());
            FastDriver.BuyerSellerSetup.txtSSN.FASetText("434-44-2342" + FAKeys.Tab);
            Support.AreEqual("434-44-2342", FastDriver.BuyerSellerSetup.txtSSN.FAGetValue());

            TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452";
            FastDriver.BuyerSellerSetup.Salutation.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Salutation.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());

            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());


            string ActVal = FastDriver.BuyerSellerSetup.CurrentState.FAGetText();
            Support.AreEqual(StateListValues, ActVal);
            FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
            Support.AreEqual("23234-4244", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
            ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();
            Support.AreEqual(CountryListValues, ActVal);

            FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue());
            Support.AreEqual(StateListValues, FastDriver.BuyerSellerSetup.ForwardingState.FAGetText());
            TempVal = "23234-4244";
            FastDriver.BuyerSellerSetup.ForwardingZip.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue());
            ActVal = FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetText();
            Support.AreEqual(CountryListValues, ActVal);

        }

        private void ValidatHusWifLowrBound()
        {
            FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Husband/Wife");
            FastDriver.BuyerSellerSetup.SwitchToContentFrame();
            Support.AreEqual("Husband/Wife", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
            FastDriver.BuyerSellerSetup.Salutation.FASetText("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452");
            Support.AreEqual("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452", FastDriver.BuyerSellerSetup.Salutation.FAGetValue());

            string TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet345";
            FastDriver.BuyerSellerSetup.MiscRef1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());

            FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());
            TempVal = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentState.FAGetText());
            TempVal = "23234-4244";
            FastDriver.BuyerSellerSetup.CurrentZip.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
            TempVal = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
            string ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();

            FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue());
            TempVal = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingState.FAGetText());
            TempVal = "23234-4244";
            FastDriver.BuyerSellerSetup.ForwardingZip.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue());

            TempVal = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
            ActVal = FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetText();
            Support.AreEqual(TempVal, ActVal);

            TempVal = "DHGd775689$!@1reet34";
            FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue());

            TempVal = "DHGd775689$!@";
            FastDriver.BuyerSellerSetup.Husband2LastName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue());
            FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue());
            FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseMiddleName.FAGetValue());
            FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue());
            TempVal = "1234";
            FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.HusbandSpouseSuffix.FAGetValue());
            TempVal = "3424";
            FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual("???-??-????", FastDriver.BuyerSellerSetup.HusbandSpouse2SSN.FAGetValue());

        }
        private void ValidateBusEntyUprBond()
        {
            Support.AreEqual("Business Entity", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
            string TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452";
            FastDriver.BuyerSellerSetup.Salutation.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Salutation.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());

            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());

            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^$";
            FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());

            TempVal = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
            string ActVal = FastDriver.BuyerSellerSetup.CurrentState.FAGetText();
            Support.AreEqual(TempVal, ActVal);
            FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
            Support.AreEqual("23234-4244", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
            TempVal = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
            ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();
            Support.AreEqual(TempVal, ActVal);
            FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("43-4442342" + FAKeys.Tab);
            Support.AreEqual("43-4442342", FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue());

            Reports.TestStep = "Validate fields for Business entity type exact bound.";
            Support.AreEqual("Business Entity", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
            TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452";
            FastDriver.BuyerSellerSetup.Salutation.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Salutation.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());


            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());

            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^$";
            FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());

            TempVal = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
            ActVal = FastDriver.BuyerSellerSetup.CurrentState.FAGetText();
            Support.AreEqual(TempVal, ActVal);
            FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
            Support.AreEqual("23234-4244", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
            TempVal = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
            ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();
            Support.AreEqual(TempVal, ActVal);


            FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue());
            TempVal = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingState.FAGetText());
            TempVal = "23234-4244";
            FastDriver.BuyerSellerSetup.ForwardingZip.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue());
            TempVal = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
            ActVal = FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetText();
            Support.AreEqual(TempVal, ActVal);
            FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("43-4442342" + FAKeys.Tab);
            Support.AreEqual("43-4442342", FastDriver.BuyerSellerSetup.BusinessEntitySSN.FAGetValue());

        }
        private void SendKeys(string KeysCombination)
        {
            Keyboard.SendKeys(KeysCombination);
            Playback.Wait(2000);
        }
        private void ValidatIndivLowrBound()
        {
            FastDriver.BuyerSellerSetup.SwitchToContentFrame();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Individual");
            Support.AreEqual("Individual", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
            string TempVal = "DHGd775689$!@";
            FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
            FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue());
            FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());
            FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText("12345" + FAKeys.Tab);
            Support.AreEqual("12345", FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue());
            FastDriver.BuyerSellerSetup.txtSSN.FASetText("434-44-2342" + FAKeys.Tab);
            Support.AreEqual("434-44-2342", FastDriver.BuyerSellerSetup.txtSSN.FAGetValue());
            FastDriver.BuyerSellerSetup.Salutation.FASetText("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452" + FAKeys.Tab);
            Support.AreEqual("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452", FastDriver.BuyerSellerSetup.Salutation.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef1.FASetText("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet345" + FAKeys.Tab);
            Support.AreEqual("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet345", FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef2.FASetText("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet345" + FAKeys.Tab);
            Support.AreEqual("2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet345", FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrAddrSetToOthr();
            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());

            TempVal = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
            string ActVal = FastDriver.BuyerSellerSetup.CurrentState.FAGetText();
            Support.AreEqual(TempVal, ActVal);
            FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
            Support.AreEqual("23234-4244", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
            TempVal = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
            ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();
            Support.AreEqual(TempVal, ActVal);
        }
        private void ValidatIndivUpprBound()
        {

            Support.AreEqual("Individual", FastDriver.BuyerSellerSetup.RetrieveBuyerType());
            string TempVal = "DHGd775689$!@1reet34";
            FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
            FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.IndividualMiddleName.FAGetValue());
            FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());
            FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText("12345" + FAKeys.Tab);
            Support.AreEqual("12345", FastDriver.BuyerSellerSetup.IndividualSuffix.FAGetValue());
            FastDriver.BuyerSellerSetup.txtSSN.FASetText("434-44-2342" + FAKeys.Tab);
            Support.AreEqual("434-44-2342", FastDriver.BuyerSellerSetup.txtSSN.FAGetValue());

            TempVal = "2342 vhg!@12354535353453 hgjghjgjgjg dtsdtet3452";
            FastDriver.BuyerSellerSetup.Salutation.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.Salutation.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef1.FAGetValue());
            FastDriver.BuyerSellerSetup.MiscRef2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.MiscRef2.FAGetValue());

            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.CurrentStreet4.FAGetValue());
            TempVal = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
            string ActVal = FastDriver.BuyerSellerSetup.CurrentState.FAGetText();
            Support.AreEqual(TempVal, ActVal);
            FastDriver.BuyerSellerSetup.CurrentZip.FASetText("23234-4244" + FAKeys.Tab);
            Support.AreEqual("23234-4244", FastDriver.BuyerSellerSetup.CurrentZip.FAGetValue());
            TempVal = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
            ActVal = FastDriver.BuyerSellerSetup.CurrentCountry.FAGetText();
            Support.AreEqual(TempVal, ActVal);

            FastDriver.BuyerSellerSetup.ForwdAddrSetToOthr();
            TempVal = "ghkdjrjky2i5729571957395!#$%%^#&^";
            FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet2.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet3.FAGetValue());
            FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingStreet4.FAGetValue());
            TempVal = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingState.FAGetText());
            TempVal = "23234-4244";
            FastDriver.BuyerSellerSetup.ForwardingZip.FASetText(TempVal + FAKeys.Tab);
            Support.AreEqual(TempVal, FastDriver.BuyerSellerSetup.ForwardingZip.FAGetValue());

            TempVal = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
            ActVal = FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetText();
            Support.AreEqual(TempVal, ActVal);


        }
        private void ActivateEmployee(string EmpName)
        {
            Reports.TestStep = "Activating Employee.";
            string FormType = AutoConfig.FormType;
            if (FormType.Equals("CD"))
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST");
            else if (FormType.Equals("HUD"))
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>AUTOCD");


            string FirstColVal = FastDriver.ProcessingRegionSetup.EmployedByTable.PerformTableAction(2, EmpName, 1, TableAction.GetText).Message.Trim();
            if (FirstColVal.Equals("Inactive"))
            {
                FastDriver.ProcessingRegionSetup.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.WaitForScreenToLoad();
                Reports.TestStep = "Activate the region.";
                FastDriver.StatusEdit.Activate.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.BottomFrame.Done();
            }

        }
        private void ChagPhTypToEmalOrBusFax(string PhType = "E-Mail")
        {
            FastDriver.BuyerSellerSetup.CurrentPhoneType.FAClick();
            Playback.Wait(1000);
            if (PhType.Equals("E-Mail"))
            {
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem("E-Mail");
                Playback.Wait(3000);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("Email@abc.com");
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual("true", FastDriver.BuyerSellerSetup.CurrentPhoneNotification.GetAttribute("checked").ToString());
            }
            else if (PhType.Equals("Business Fax"))
            {
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.CurrentPhoneType.FASelectItem("Business Fax");
                Playback.Wait(3000);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FASetText("(714)800-1570");
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.CurrentExtension.FAClick();
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.CurrentPhoneNotification.IsSelected().ToString());
            }
        }
        private void ChagPhTypToPager()
        {
            FastDriver.BuyerSellerSetup.CurrentPhoneType6.FAClick();
            Playback.Wait(1500);
            FastDriver.BuyerSellerSetup.CurrentPhoneType6.FASelectItem(@"Pager");
            Playback.Wait(2000);//Page refresh
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.BuyerSellerSetup.SwitchToContentFrame();
            FastDriver.BuyerSellerSetup.CurrentPhoneNumber6.FASetText(@"1234567890");
            Playback.Wait(3000);//Page refresh
            FastDriver.BuyerSellerSetup.SwitchToContentFrame();
        }


        private void NavigatAndEnterFee(string FeeDescr, string BuyrChg, string SellrChg)
        {
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeDescr, "Sel", TableAction.On);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeDescr, "Buyer Charge", TableAction.SetText, BuyrChg);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeDescr, "Seller Charge", TableAction.SetText, SellrChg);
        }

        public void LoginAndAddRole(string RoleName)
        {
            try
            {
                Reports.TestDescription = "Adding rights to the user.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Enter userid and search.";
                FastDriver.LeftNavigation.Navigate<EmployeeSearch>(@"Home>System Maintenance>Security Maintenance>Employee Security").WaitForScreenToLoad();

                FastDriver.EmployeeSearch.LoginName.FASetText("fastts\\fastqa07");
                FastDriver.EmployeeSearch.SearchNow.FAClick();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction("User Name", "FAST QA07", "User Name", TableAction.DoubleClick);

                Reports.TestStep = "Expand the Roles.";
                FastDriver.RoleBusinessUnitAssignment.WaitForScreenToLoad();
                FastDriver.WebDriver.FindElements(By.TagName("img")).FirstOrDefault(p => p.GetAttribute("src").Contains("collapse.gif")).FAClick();
                FastDriver.RoleBusinessUnitAssignment.BusinessUnits.PerformTableAction("BUID", "1486", "Code", TableAction.Click);
                FastDriver.RoleBusinessUnitAssignment.AddRemoveRoles.FAClick();

                Reports.TestStep = "Select Corporate Administrator";
                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", RoleName, "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the presence of office Security Manager role.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 25);
                FastDriver.RoleBusinessUnitAssignment.WaitForScreenToLoad();
                FastDriver.RoleBusinessUnitAssignment.AssignedRoles.PerformTableAction("Role Name", RoleName, "Role Name", TableAction.Click);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                if (FastDriver.WebDriver.WindowIsDisplayed("Track Change History"))
                {
                    FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                    FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("531");
                    FastDriver.TrackChangeHistoryDialog.UserNotes.FASetText("Adding roles");
                    FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();
                }

                #endregion
            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        private void LoginToAdm(bool IsSuperUser = false)
        {
            var credentials = new Credentials();
            if (!(IsSuperUser))
            {
                credentials.UserName = AutoConfig.UserName;
                credentials.Password = AutoConfig.UserPassword;
            }
            else if (IsSuperUser)
            {
                credentials.UserName = AutoConfig.UserNameSU;
                credentials.Password = AutoConfig.UserPasswordSU;
            }
            Reports.TestStep = "Log into ADM application.";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
        }

        private void ValidateXmlError(int Counter, string BuyerName, [Optional]int RowInstcNum)
        {
            if (Counter == 1)
            {
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
            }
            FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad(timeout: 15);
            FastDriver.SelectIBABeneficiaryDlg.PerformTableOperation(2, BuyerName, 1, TableAction.Click, "", RowInstcNum);
            FastDriver.DialogBottomFrame.ClickDone();

            Reports.TestStep = "Prevent Save for XML-incompatible Special Characters in IBA transaction- " + BuyerName;
            string ExpVal = "Selected buyer/seller details contain xml incompatible characters.  Please modify the details or select other buyer/seller.";
            string ActVal = FastDriver.WebDriver.HandleDialogMessage(false, true).Trim().Replace("\n", String.Empty).Replace("\r", " ");
            Support.AreEqual(ExpVal, ActVal);
            FastDriver.WebDriver.HandleDialogMessage(true, false);
        }
        private void CreateFileWithGui(bool Qfe = true)
        {
            Reports.TestStep = "Create File using FAST GUI.";
            if (Qfe)
            {
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                try
                {
                    FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateStandardFile();

            }
            else
            {
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick Refi Entry").WaitForScreenToLoad();
                try
                {
                    FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.CreateStandardFile();
            }
        }

        private void VerfyPhListItmsAndSelectdItms(string[] ValsArr, string BuyerType)
        {
            this.RetrvComparPhListItems(ValsArr);
            this.VerifyCurrPhSelectedItms(BuyerType);
        }

        private void VerifyCurPhoTextValues(string[] CurPhVals)
        {
            CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrPhDtls();
            Support.AreEqual(CurPhVals[0], CurrPhoDictry["CurrentPhoneNum"], "Current PhoneNum");
            Support.AreEqual(CurPhVals[1], CurrPhoDictry["CurrentPhoneTwo"], "CurrentPhoneTwo");
            Support.AreEqual(CurPhVals[2], CurrPhoDictry["CurrentPhoneThree"], "CurrentPhoneThree");
            Support.AreEqual(CurPhVals[3], CurrPhoDictry["CurrentPhoneFour"], "CurrentPhoneFour");
            Support.AreEqual(CurPhVals[4], CurrPhoDictry["CurrentPhoneFive"], "CurrentPhoneFive");
            Support.AreEqual(CurPhVals[5], CurrPhoDictry["CurrentPhoneSix"], "CurrentPhoneSix");
            Support.AreEqual(CurPhVals[6], CurrPhoDictry["CurrentPhoneSeven"], "CurrentPhoneSeven");
        }

        private void VerifyCurrPhExtns(string[] CurPhExtnVals)
        {
            Support.AreEqual(CurPhExtnVals[0], CurrPhoDictry["CurrentHomePhoneNumExtn"], "CurrentHomePhoneNumExtn");
            Support.AreEqual(CurPhExtnVals[1], CurrPhoDictry["CurrentPhoneTwoExtn"], "CurrentPhoneTwoExtn");
            Support.AreEqual(CurPhExtnVals[2], CurrPhoDictry["CurrentPhoneThreeExtn"], "CurrentPhoneThreeExtn");
            Support.AreEqual(CurPhExtnVals[3], CurrPhoDictry["CurrentPhoneFourExtn"], "CurrentPhoneFourExtn");
            Support.AreEqual(CurPhExtnVals[4], CurrPhoDictry["CurrentPhoneFiveExtn"], "CurrentPhoneFiveExtn");
            Support.AreEqual(CurPhExtnVals[5], CurrPhoDictry["CurrentPhoneSixExtn"], "CurrentPhoneSixExtn");
            Support.AreEqual(CurPhExtnVals[6], CurrPhoDictry["CurrentPhoneSevenExtn"], "CurrentPhoneSevenExtn");

        }

        public void VerifyCurrPhSelectedItms(string BuyerType = "")
        {
            if (BuyerType != "Business Entity")
            {
                Support.AreEqual("Home Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem()); //Home Phone                
                Support.AreEqual("Business Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem());//Bus Phone
                Support.AreEqual("Pager", FastDriver.BuyerSellerSetup.CurrentPhoneType2PagrOrEmail.FAGetSelectedItem());//Pager
                Support.AreEqual("Cellular", FastDriver.BuyerSellerSetup.CurrentPhoneType3Cellular.FAGetSelectedItem());//Cellular
                Support.AreEqual("Business Fax", FastDriver.BuyerSellerSetup.CurrentPhoneType4BusFaxOrPager.FAGetSelectedItem());
                Support.AreEqual("Home Fax", FastDriver.BuyerSellerSetup.CurrentPhoneType5HomeFaxOrHomePhon.FAGetSelectedItem());
                Support.AreEqual("E-Mail", FastDriver.BuyerSellerSetup.CurrentPhoneType6EmailOrPagrOrHomFax.FAGetSelectedItem());
            }
            else
            {
                Support.AreEqual("Business Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetSelectedItem()); //Home Phone                
                Support.AreEqual("Business Fax", FastDriver.BuyerSellerSetup.CurrentPhoneType1.FAGetSelectedItem());//Bus Phone
                Support.AreEqual("E-Mail", FastDriver.BuyerSellerSetup.CurrentPhoneType2PagrOrEmail.FAGetSelectedItem());//Pager
                Support.AreEqual("Cellular", FastDriver.BuyerSellerSetup.CurrentPhoneType3Cellular.FAGetSelectedItem());//Cellular
                Support.AreEqual("Pager", FastDriver.BuyerSellerSetup.CurrentPhoneType4BusFaxOrPager.FAGetSelectedItem());
                Support.AreEqual("Home Phone", FastDriver.BuyerSellerSetup.CurrentPhoneType5HomeFaxOrHomePhon.FAGetSelectedItem());
                Support.AreEqual("Home Fax", FastDriver.BuyerSellerSetup.CurrentPhoneType6EmailOrPagrOrHomFax.FAGetSelectedItem());
            }

        }
        //
        private string CreateFile(int SalesPrice = 0, bool title = true, bool escrow = true, bool subescrow = false, string TransactionType = "SALE", string NewLender = "BOA")
        {
            try
            {
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.File.Services = RequestFactory.GetServices(title, escrow, subescrow);
                customizableFileRequest.File.TransactionTypeObjectCD = TransactionType;
                customizableFileRequest.File.Properties = new Property[]
                    {
                        new Property()
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    State = "CA",
                                    City = "Calexico",
                                    County = "Imperial",
                                    Country = "USA"
                                }
                            }
                        }
                    };
                customizableFileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[] 
                    { 
                         new FASTWCFHelpers.FastFileService.BuyerSeller() 
                        {
                            FirstName = "Buyer1FirstName",
                            LastName = "Buyer1LastName",
                            EntityTypeID = 48,
                            Type = "Individual",
                        },
                         new FASTWCFHelpers.FastFileService.BuyerSeller() 
                        {
                            FirstName = "Buyer2FirstName",
                            LastName = "Buyer2LastName",
                            SpouseFirstName= "Buyer2SpouseName",
                            EntityTypeID = 48,
                            Type = "Husband And Wife",
                        }
                        
                    };
                customizableFileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[] 
                    {
                        new FASTWCFHelpers.FastFileService.BuyerSeller() 
                        {
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1LastName",
                            EntityTypeID = 48,
                            Type = "Individual"
                        },
                         new FASTWCFHelpers.FastFileService.BuyerSeller() 
                        {
                            FirstName = "Seller2FirstName",
                            LastName = "Seller2LastName",
                            SpouseFirstName= "Seller2SpouseName",
                            EntityTypeID = 48,
                            Type = "Husband And Wife"
                        }
                        
                    };
                customizableFileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    LoanNumber = "LOAN1234567890",
                    NewLoanAmount = 5000.00m,
                    LiabilityAmount = 5000.00m,
                    BenMortgageeTextID = 0,
                    FileBusinessParty = new FileBusinessParty
                    {
                        Name = "Nhat Nguyen",
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId(NewLender),
                    },
                    LoanTypeCdID = 0,
                    FundDate = DateTime.Today
                };
                if (SalesPrice != 0)
                    customizableFileRequest.File.SalesPriceAmount = SalesPrice;
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(customizableFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                return fileNumber;
            }
            catch (Exception)
            {
                try
                {
                    return CreateQFEWithSalesDetails(SalesPrice, title, escrow, subescrow, TransactionType);
                }
                catch (Exception ex)
                {
                    throw new Exception("Unable to create QFE", ex);
                }

            }
        }
        private string CreateQFEWithSalesDetails(int SalesPrice = 0, bool title = true, bool escrow = true, bool subescrow = false, string TransationType = "SALE")
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            NewFileParameters QFEParams = new NewFileParameters();
            QFEParams = NewFileParameters.GetDefaultParams();
            QFEParams.Title = title;
            QFEParams.Escrow = escrow;
            QFEParams.SubEscrow = subescrow;
            switch (TransationType)
            {
                case "SALE":
                    TransationType = "Sale w/Mortgage";
                    break;
                case "ACCOMODAT":
                    TransationType = "Accommodation";
                    break;
                case "BULK":
                    TransationType = "Bulk Sale";
                    break;
                case "CD":
                    TransationType = "Construction Disbursement";
                    break;
                case "CON":
                    TransationType = "Construction Loan";
                    break;
                case "LOAN":
                    TransationType = "Equity Loan";
                    break;
                case "FORECLOSE":
                    TransationType = "Foreclosure";
                    break;
                case "LTDESCROW":
                    TransationType = "Limited Escrow";
                    break;
                case "SM":
                    TransationType = "Second Mortgage";
                    break;
                case "CASH":
                    TransationType = "Sale/Cash";
                    break;
                case "SEARCH":
                    TransationType = "Search Package";
                    break;
                    
            }
            QFEParams.TransactionType = TransationType;
            if (SalesPrice != 0)
                QFEParams.TermsDatesSalesPrice = SalesPrice.ToString();
            QFEParams.PropertyInformationName = "J305";
            QFEParams.PropertyInformationType = "Single Family Residence";
            QFEParams.PropertyInformationLot = "Lot1";
            QFEParams.PropertyInformationBlock = "Block1";
            QFEParams.PropertyInformationUnit = "Unit1";
            QFEParams.PropertyPropTaxAPN1 = "Prop1APN1";
            QFEParams.PropertyPropTaxAPN2 = "9845012345";
            QFEParams.PropertyBookAddrLin1 = "J305";
            QFEParams.PropertyBookAddrLin2 = "JJEJAMQ";
            QFEParams.PropertyBookAddrLin3 = "JJEJAMQ";
            QFEParams.PropertyCity = "ALBANY";
            QFEParams.PropertyState = "CA";
            QFEParams.PropertyZipCode = "12345";
            QFEParams.PropertyCounty = "ALAMEDA";
            FastDriver.QuickFileEntry.CreateFile(QFEParams);
            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }
            Thread.Sleep(5000);
            FastDriver.FileHomepage.WaitForScreenToLoad();
            FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.FileNum, true);
            return FastDriver.FileHomepage.FileNum.FAGetValue();
        }
        //
        private void WaitForEventToGetRecorded(string Event)
        {
            for (int i = 0; i < 10; i++)
            {
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Notifications");
                Thread.Sleep(5000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad(FastDriver.EventTrackingLog.EventTable);
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                if (!FastDriver.EventTrackingLog.EventTable.FAGetText().Contains(Event))
                    Thread.Sleep(5000);
                else break;
            }
        }
        //
        private void RetrvComparPhListItems(string[] ExpValArry)
        {
            string[] ForwPhTypItmsActual = FastDriver.BuyerSellerSetup.ForwardingPhoneType.FAGetAllTextFromSelect().Split('|');
            string[] CurrPhTypItmsActual = FastDriver.BuyerSellerSetup.CurrentPhoneType.FAGetAllTextFromSelect().Split('|');
            this.CompareTwoArrays(ForwPhTypItmsActual, ExpValArry);
            this.CompareTwoArrays(CurrPhTypItmsActual, ExpValArry);
        }

        private void CompareTwoArrays(string[] ArrOne, string[] ArrTwo)
        {
            for (int Counter = 0; Counter <= ArrOne.Length - 1; Counter++)
            {
                if (ArrOne[Counter] != "")
                {
                    if (!(ArrTwo.Contains(ArrOne[Counter])))
                    {
                        Reports.UpdateDebugLog("Comparing Arrays", "", "Array Value", "Value not found-> ", ArrOne[Counter].ToString(), "", Reports.Result(false), "");
                        Support.AreEqual("Not found Value  -" + ArrOne[Counter].ToString(), "Not found Value-" + ArrOne[Counter].ToString());
                    }
                    else
                    {
                        Reports.UpdateDebugLog("Comparing Arrays", "", "Array Value", "Value found-> ", ArrOne[Counter].ToString(), "", Reports.Result(true), "");
                        Support.AreEqual("Found Value " + ArrOne[Counter].ToString(), "Found Value " + ArrOne[Counter].ToString());
                    }
                }
            }
        }

        private void ComparListAndArray(List<string> Lone, string[] StrArr)
        {
            Lone.Sort();
            for (int Counter = 0; Counter < Lone.Count; Counter++)
            {
                if (!(StrArr.Contains(Lone[Counter])))
                {
                    Reports.UpdateDebugLog("Verify Marital Status list box", "", "List Values", "List Values", Lone[Counter].ToString(), "", Reports.Result(false), "");
                    Support.AreEqual("Not found Value  -" + Lone[Counter].ToString(), "Not found Value-" + Lone[Counter].ToString());
                }
                else
                {
                    Reports.UpdateDebugLog("Verify Marital Status list box", "", "List Values", "List Values", Lone[Counter].ToString(), "", Reports.Result(true), "");
                    Support.AreEqual("Found Value" + Lone[Counter].ToString(), "Found Value" + Lone[Counter].ToString());

                }
            }
        }

        private void EnterSpelling(string NamesOrComplVesting, BuyerVestingParameters ByrVestg, string TextVal, string Byr)
        {
            FastDriver.BuyerVesting.ClickRefreshFull();
            FastDriver.BuyerVesting.ClickRefreshShort();
            if (NamesOrComplVesting.Equals("Names"))
                FastDriver.BuyerVesting.Names.FASetText(ByrVestg.Names);
            else
                FastDriver.BuyerVesting.CompleteVesting.FASetText(ByrVestg.CompleteVesting);

            if (NamesOrComplVesting.Equals("Names"))
            {
                FastDriver.BuyerVesting.CheckSpellingNameRelations.FAClick();
            }
            else
                FastDriver.BuyerVesting.CheckSpellingCompVest.FAClick();

            Reports.TestDescription = "Entering Spelling on Spell Dialog for - " + Byr;
            FastDriver.SpellingErrorDialog.CorrectSpelling(correctedtext: TextVal);
            FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.BuyerVesting.SwitchToContentFrame();
        }

        private void ValidateNewSpelling(string NamesOrComplVesting, string NewSpelling, string Byr)
        {
            Reports.TestDescription = "Validating New Spelling for - " + Byr;
            FastDriver.BuyerVesting.SwitchToContentFrame();
            string[] VestingValues = FastDriver.BuyerVesting.GetAllFieldsValues();
            if (NamesOrComplVesting.Equals("Names"))
                Support.AreEqual(VestingValues[0].Trim(), NewSpelling);
            else
                Support.AreEqual(VestingValues[1].Trim(), NewSpelling);
        }


        private void CreateIndiBuyr(BuyerParameters byr)
        {
            Reports.TestStep = "Enter the Details for Buyer type Individual";
            FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.btnNew.FAClick();
            FastDriver.BuyerSellerSetup.ChangeInstanceType(0, byr.BuyerType, false);
            FastDriver.BuyerSellerSetup.BuyerDetails(byr);

        }
        private void DepositCash(DepositParameters Deposit)
        {
            FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
            FastDriver.DepositInEscrow.Deposit(Deposit);
            FastDriver.BottomFrame.Save();
        }
        private void PrintAll(bool ClickOnDeliver = true, bool ExpectingPwdConfDialg = true)
        {
            Reports.TestStep = "Print All Checks in PrintAll method";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
            FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
            FastDriver.PrintChecks.WaitForScreenToLoad();
            PerformDelivery("Print", FastDriver.PrintChecks);
            //if (ClickOnDeliver)
            //{
            //    try
            //    {
            //        FastDriver.PrintChecks.Deliver.FAClick();

            //        if (FastDriver.WebDriver.HandleDialogMessage(true, true, 5).Contains("SDN search"))
            //        {
            //            FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 5);
            //            FastDriver.PrintDlg.ClickCancel();
            //            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            //            FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

            //            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
            //            FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
            //            FastDriver.PrintChecks.SwitchToContentFrame();
            //            FastDriver.PrintChecks.Deliver.FAClick();
            //        }
            //    }
            //    catch
            //    {
            //        FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
            //        FastDriver.PrintChecks.SwitchToContentFrame();
            //        FastDriver.PrintChecks.Deliver.FAClick();
            //        if (FastDriver.WebDriver.HandleDialogMessage(true, true, 5).Contains("SDN search"))
            //        {
            //            FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 5);
            //            FastDriver.PrintDlg.ClickCancel();
            //            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            //            FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);
            //            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
            //            FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
            //            FastDriver.PrintChecks.SwitchToContentFrame();
            //            FastDriver.PrintChecks.Deliver.FAClick();
            //        }
            //    }
            //}
            ////FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
            //FastDriver.PrintDlg.SelectPrinter(@"text_file_printer");
            //FastDriver.PrintDlg.ClickPrint();
        }
        private void HandlPwdConfirDiag(string Reason, string LossExplnatn)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation", true, 7);
            FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
            FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem(Reason);
            FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText(LossExplnatn);
            FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);
            Reports.TestStep = "Click on Done in PasswordConfirmationDlg in PrintAll method.";
            FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
        }
        private void NavigateActOnBuyr(int ColToSrchIndex, string ColValue, int ColToClick, string ActionName = null, string Value = "", int StartingRowNum = 1)
        {
            FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(ColToSrchIndex, ColValue, ColToClick, TableAction.Click, Value, StartingRowNum);
            if (ActionName != null)
            {
                if (ActionName.Equals("Edit"))
                {
                    FastDriver.BuyerSellerSummary.Edit();
                }
                else if (ActionName.Equals("Clear"))
                {
                    FastDriver.BuyerSellerSummary.ClickClear();
                }
            }
        }

        private void CreateTrustEstBuyr(BuyerParameters byr)
        {
            FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.btnNew.FAClick();
            FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Trust/Estate", false);
            FastDriver.BuyerSellerSetup.BuyerDetails(byr);
        }
        private void CreateBusEntBuyr(BuyerParameters byr)
        {
            FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.btnNew.FAClick();
            FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Business Entity", false);
            FastDriver.BuyerSellerSetup.BuyerDetails(byr);
        }

        private void CreateHusWifBuyr(BuyerParameters byr)
        {
            FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.btnNew.FAClick();
            FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Husband/Wife", false);
            FastDriver.BuyerSellerSetup.BuyerDetails(byr);
        }

        private void EntrDetlsExchCmp(string IdCode)
        {
            FastDriver.ExchangeCompany.WaitForScrenToLoad();
            Reports.TestStep = "Set an exchange company id from Global address book.";
            FastDriver.ExchangeCompany.ClickFind();
            FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: IdCode);
            FastDriver.ExchangeCompany.SwitchToContentFrame();
            FastDriver.BottomFrame.Done();
        }
        private void LoginToFast()
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
        }
        private void CreateFileWithWebSer(bool UseLocalMethod = false)
        {
            CreateFileRequest fileRequest = new CreateFileRequest();

            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();


            Reports.TestStep = "Create File using web service.";
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }
        private void ClearDictionraies(List<Object> DictLst)
        {
            foreach (Dictionary<string, string> Dobj in DictLst)
                if (Dobj.Count > 0)
                {
                    Dobj.Clear();
                }
        }

        private CreateFileRequest GetDetailedCreateFileDefaultRequest()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    SalesPriceAmount = 5000.00m,
                    LiabilityAmount = 3000.00m,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[] 
                    { 
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"), //
                            RoleTypeObjectCD = "BUSSOURCE" 
                        } 
                    },
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            Tract = "Tract",
                            Building = "Building",
                            Book = "Book",
                            Page = "Page",
                            Section = "section",
                            Township = "Township",
                            Range = "Range",
                            Parcel = "Parcel",
                            Condominium = "Subdivision1",
                            PropertyTypeObjectCD = "SF",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                }
                            },
                            Taxes = new FASTWCFHelpers.FastFileService.Taxes[]
                            {
                                new FASTWCFHelpers.FastFileService.Taxes()
                                {
                                    TaxID = "Prop1APN1",
                                    GenTaxCheck = false,
                                    TotalInstallmentTax = 500

                                },
                                new FASTWCFHelpers.FastFileService.Taxes()
                                {
                                    TaxID = "9845012345",
                                    TaxYear = "2006-2007",
                                    GenTaxCheck = false,
                                    TotalInstallmentTax = 0
                                }
                            }                        
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband and Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband and Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2Lastname"
                        }
                    },
                    NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                    {
                        LoanNumber = "WCF_DefaultLoanNumber",
                        NewLoanAmount = 5000.00m,
                        LiabilityAmount = 5000.00m,
                        BenMortgageeTextID = 0,
                        FileBusinessParty = new FileBusinessParty
                        {
                            Name = "Nhat Nguyen",
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        },
                        LoanTypeCdID = 0,
                        FundDate = DateTime.Today
                    },
                    FileNotes = new FileNote[] 
                    { 
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
            };
            #endregion


        }  // En od of method
        //
        private string CreateTaskAndSetNotificationDetails(TaskTemplateParameters TaskParams)
        {
            try
            {
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelection.Categories.PerformTableAction("Task Category", TaskParams.TaskCategory, "Task Category", TableAction.Click);
                FastDriver.TaskTemplateSelection.WaitCreation(FastDriver.TaskTemplateSelection.TasksForTable);
                if (FastDriver.TaskTemplateSelection.TasksForTable.FAGetText().Contains(TaskParams.TaskName))
                {
                    Reports.TestStep = "Delete the task if exists already.";
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(3, TaskParams.TaskName, 3, TableAction.Click);
                    FastDriver.TaskTemplateSelection.Remove.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                Reports.TestStep = "Create task.";
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelection.New.FAClick();
                Thread.Sleep(3000);
                string lastRow = (string)FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount().ToString();
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(1, lastRow, 3, TableAction.Click);
                Playback.Wait(3000);
                if (string.IsNullOrEmpty(TaskParams.TaskName))
                {
                    TaskParams.TaskName = Support.RandomString("AAZZ");
                }
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(1, lastRow, 3, TableAction.SetText, TaskParams.TaskName);
                //
                Playback.Wait(2000);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelection.Categories.PerformTableAction("Task Category", TaskParams.TaskCategory, "Task Category", TableAction.Click);
                FastDriver.TaskTemplateSelection.WaitCreation(FastDriver.TaskTemplateSelection.TasksForTable);
                //
                Reports.TestStep = "Select the newly created Task.";
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(3, TaskParams.TaskName, 3, TableAction.Click);
                Thread.Sleep(3000);
                FastDriver.TaskTemplateSelection.Notification.FAClick();
                //
                Reports.TestStep = "Enter mandatory details";
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.TaskStatus.FASelectItem(TaskParams.TaskStatus);
                FastDriver.NotificationSetup.DeliveryMethod.FASelectItem(TaskParams.DeliveryMethod);
                //
                Reports.TestStep = "Click on File Roles.";
                FastDriver.NotificationSetup.FileRoles.FAClick();
                Reports.TestStep = @"Select FBP roles";
                if (TaskParams.FBPRoles.Count() > 0)
                foreach (string role in TaskParams.FBPRoles)
                {
                    SelectRolesInFBProlesDlg(role);
                }
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                //Reports.TestStep = "Enter Recipient.";
                //FastDriver.NotificationSetup.WaitForScreenToLoad();
                //FastDriver.NotificationSetup.TaskEmailAddresses.FAClick();
                //FastDriver.NotificationEmailAddressesDlg.WaitForScreenToLoad();
                //FastDriver.NotificationEmailAddressesDlg.Name1.FASetText("Rasika");
                //FastDriver.NotificationEmailAddressesDlg.Email1.FASetText("rjahagirdar@firstam.com");
                //;

                //Reports.TestStep = "Click on Done in Dialog Box.";
                //FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter subject line";
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.SubjectLine.FASetText("Proactive notification for FBP Roles");

                //Reports.TestStep = "Select Sender.";
                //FastDriver.NotificationSetup.AvailabeSender.FASelectItem("Escrow Officer");
                Reports.TestStep = "Select Designed Sender.";
                FastDriver.NotificationSetup.AvailabeSender.FASelectItem("Designated Sender");

                Reports.TestStep = "Click on right direction.";
                FastDriver.NotificationSetup.RightDirectionArrow.FAClick();

                Reports.TestStep = "Enter Name for designated sender.";
                FastDriver.NotificationSetup.DesignatedSenderName.FASetText("Designated sender name");
                FastDriver.NotificationSetup.DesignatedSenderEmailAddress.FASetText("designated@firstam.com");
                //
                Reports.TestStep = "Click on Message Template Select.";
                FastDriver.NotificationSetup.Select.FAClick();
                Reports.TestStep = "Select the message template.";
                FastDriver.MessageTemplateSelectionDlg.SelectMessageTemplate(TaskParams.MessageTemplate);


                Reports.TestStep = "Save.";
                FastDriver.BottomFrame.Save();
                
                Reports.TestStep = "Validate that Invoice appears under documents table.";
                FastDriver.NotificationSetup.WaitForScreenToLoad();
                FastDriver.NotificationSetup.DocumentsTable.PerformTableAction("Document Name", "Invoice", "Document Name", TableAction.Click);

                //Reports.TestStep = "Validate that the document is attached";
                //FastDriver.NotificationSetup.WaitForScreenToLoad();
                //Support.AreEqual("2", FastDriver.NotificationSetup.DocumentsTable.GetRowCount().ToString());



                FastDriver.BottomFrame.Done();
                Thread.Sleep(4000);
                return TaskParams.TaskName;
            }
            catch
            {
                throw;
            }

        }
        //
        private bool SelectRolesInFBProlesDlg(string Role)
        {
            string Status = "";
            FastDriver.SelectFBPRolesDlg.WaitForScreenToLoad();
            if (FastDriver.SelectFBPRolesDlg.Table.FAGetText().Contains(Role))
            {
                Status = FastDriver.SelectFBPRolesDlg.Table.PerformTableAction(2, Role, 1, TableAction.On).Status.ToString();
                if (Status == "Success")
                    return true;
            }
            return false;

        }

        private void CreateBasicFile()
        {
            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
            FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("sale w/mortgage");
            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
            FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }
        }

        private int RetIndex(string ExpectVal)
        {
            string AllValues = FastDriver.FileHomepage.TransactionType.FAGetAllTextFromSelect();
            string[] Arra = AllValues.Split('|');
            int Counter = 0;
            foreach (var ArrCellVal in Arra)
            {
                if (ArrCellVal.Equals(ExpectVal))
                    return Counter;
                Counter++;
            }
            return 0;
        }



        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

