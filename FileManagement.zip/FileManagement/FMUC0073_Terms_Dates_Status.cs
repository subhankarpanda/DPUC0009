﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;


namespace FileManagement
{
    [CodedUITest]
    public class FMUC0073_Terms_Dates_Status : MasterTestClass
    {
        #region BAT

        #region FMUC0073_BAT0001
        [TestMethod]
        public void FMUC0073_BAT0001()
        {
            try
            {
                Reports.TestDescription = "AF1: Login TO FAST Application and create a file and Reset vales on TDS.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen and change file status, sale price, liability, settlement date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.TermsDatesStatus.Status.FASelectItemBySendingKeys("Closed");
                FastDriver.TermsDatesStatus.LegacyFile.FASetCheckbox(true);
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("100000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("100000" + FAKeys.Tab);

                Reports.TestStep = "Click Reset button and verify all values are reset.";
                FastDriver.BottomFrame.Reset();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "File Status");
                Support.AreEqual("False", FastDriver.TermsDatesStatus.LegacyFile.IsSelected().ToString(), "Legacy File Checkbox");
                Support.AreEqual("", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue(), "Sale Price");
                Support.AreEqual("", FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue(), "First Owner's Policy Liability");
                Support.AreEqual("", FastDriver.TermsDatesStatus.SettlementDate.FAGetValue(), "Settlement Date");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_BAT0002
        [TestMethod]
        public void FMUC0073_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_AF3: Selects RestrictAutomaticUpdates checkbox and verifies eicon on the title bar";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen and select Restrict Automatic Updates checkbox.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.RestrictAutomaticUpdates.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Reload Terms/Dates/Status screen and check e Icon.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SwitchToTitleFrame();
                Support.AreEqual("True", FastDriver.TitleFrame.eIcon.IsDisplayed().ToString(), "E icon displayed");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_BAT0003
        [TestMethod]
        public void FMUC0073_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF1_AF3: Save the Data on TDS Screen.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen and change file status, sale price, liability, settlement date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.TermsDatesStatus.Status.FASelectItemBySendingKeys("Closed");
                FastDriver.TermsDatesStatus.LegacyFile.FASetCheckbox(true);
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("100000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("100000" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Reload the Terms/Dates/Status screen and change status to Open In Error.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.Status.FASelectItemBySendingKeys("Open In Error");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Event/Tracking Log and valiate the 'Open in error' event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual("[Open in error]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(), "Open in error event");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_BAT0004
        [TestMethod]
        public void FMUC0073_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF4: Select the Co-Insurance checkbox.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen and select Co-Insurance checkbox.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.Co_Insurance.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Reload the Terms/Dates/Status screen and validate Co-Insurance checkbox is checked.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.TermsDatesStatus.Co_Insurance.IsSelected().ToString(), "Co-Insurance checkbox");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_BAT0005
        [TestMethod]
        public void FMUC0073_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF2: Restrict Automatic Updates by External System.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST ADM application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Select 'Wells Fargo' as Corporate Parent for the GAB.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText("HUDFLINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItemBySendingKeys("Wells Fargo");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a new payoff loan instance.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("HUDFLINSR1");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Reload the screen and validate Restric Demand Updates checkbox is enabled.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PayoffLoanDetails.RestrictDemandUpdates.IsEnabled().ToString(), "Restrict Demand Updates Enabled");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Terms/Dates/Status screen and select Restrict Automatic Updates checkbox.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.RestrictAutomaticUpdates.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Payoff Loan screen and validate Restrict Demand Updates is disabled.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.PayoffLoanDetails.RestrictDemandUpdates.IsEnabled().ToString(), "Restrict Demand Updates Disabled");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion


        #region NCS r12.2015
        #region FMCU0073_BAT0006_NCS
        //add test methods here by using the 'testms' snippet
        [TestMethod]
        public void FMUC0073_BAT0006_NCS()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "-User Story 380706: Terms/Dates/Status New features validation: Edit SP/OPL button, Additional Sale Price Fields, Total Sale Price label";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                //Reports.TestStep = "Navigate to a region and office with the Feature 5 permission.";

                //FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedOfficeBUID);

                Reports.TestStep = "Create File with Commercial business type.";

                #region Through UI
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                #region Through WS
                /*           
                FastDriver.TopFrame.SearchFileByFileNumber(RequestFactory.NCSCreateCommercialFilewAmounts().File.FileNumber);
                  */
                #endregion

                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad().SwitchToContentFrame();

                Reports.TestStep = "Verify the Edit SP/OPL button is displayed in the Terms/Dates/Status screen";

                Support.AreEqual("true", FastDriver.TermsDatesStatus.Edit_SP_OPL.Exists().ToString(), true);

                Reports.TestStep = "Verify the SP/OPL pop up dialog is opened after clicking the Edit SP/OPL button.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Support.AreEqual("True", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SP_OPL_Dlg_Frame.Exists().ToString(), true);

                Reports.TestStep = "Verify that no message is displayed when Sale Price Description is entered without Sale Price Amount.";
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Test Change 1");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText(" ");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                string a = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("No dialog present", a);
                //Support.AreEqual("False", FastDriver.IEMessageDlg.IEAlertMessage.Exists().ToString());

                Reports.TestStep = "Verify that message is displayed when Sale Price Amount is entered without Sale Price Description.";

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText(" ");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("100000");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Description can not be blank", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());

                Reports.TestStep = "Verify that Total Sale Price is displayed updated in File Homepage after updated in Terms/Dates/Status.";

                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Test Change 1");
                Keyboard.SendKeys("{TAB}");
                string Dlg_TotalSP1 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.TotalSalePrice.FAGetValue();
                string ScndSPriceText1 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().ToString();
                string ScndSAmount1 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FAGetValue();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(timeout: 30).ToString().Clean(), true);


                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.SwitchToContentFrame();

                string TDS_SalePrice = FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue().ToString();

                FastDriver.TermsDatesStatus.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(TDS_SalePrice, FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().ToString(), true);

                Reports.TestStep = "Verify that Total Sale Price is displayed updated in File Summary after updated in Terms/Dates/Status.";

                FastDriver.LeftNavigation.Navigate<FileSummary>("Home>Order Entry>File Summary").WaitForScreenToLoad();

                Support.AreEqual(TDS_SalePrice, FastDriver.FileSummary.SalesPrice.FAGetText().FormatAsMoney(), true);


                Reports.TestStep = "verify Starter/Ref. for Total Sale Price; User Story 629699 coverage.";

                #region Through UI
                FastDriver.FileSummary.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                FastDriver.TopFrame.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<StarterReference>("Home>Order Entry>Starter/Ref.").WaitForScreenToLoad().SwitchToContentFrame();

                FastDriver.StarterReference.StarterFileNumber.FASetText(fileNum);

                FastDriver.StarterReference.AllFileItems.FAClick();
                FastDriver.StarterReference.CopyNow.FAClick();
                Playback.Wait(9000);

                //Navitage to Terms/Date/Status screen and compare.
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 15);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Support.AreEqual(Dlg_TotalSP1, FastDriver.SalePrice_OwnerPolicyLiabilityDlg.TotalSalePrice.FAGetValue().ToString().Clean());
                Support.AreEqual(ScndSPriceText1, FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().ToString().Clean());
                Support.AreEqual(ScndSAmount1, FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FAGetValue().ToString().Clean());

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickCancel();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion 
        #region FMCU0073_BAT0007_NCS
        [TestMethod]
        public void FMUC0073_BAT0007_NCS()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Editable labels for different considerations/Sale Price on the TDS screen";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Reports.TestStep = "Navigate to a region and office with the Feature 5 permission.";

                //FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedOfficeBUID);

                Reports.TestStep = "Create File with Commercial business type.";

                #region Through UI
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Verify the SP/OPL pop up dialog is opened after clicking the Edit SP/OPL button and verify default values for the five Sale Price fields.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 15);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Support.AreEqual("True", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SP_OPL_Dlg_Frame.Exists().ToString(), true);

                #region default values checks
                //Labels
                Support.AreEqual("First Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue());
                Support.AreEqual("Second Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue());
                Support.AreEqual("Third Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue());
                Support.AreEqual("Fourth Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue());
                Support.AreEqual("Fifth Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue());

                //Amounts                
                Support.AreEqual("0.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FAGetValue());
                Support.AreEqual("0.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FAGetValue());
                Support.AreEqual("0.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FAGetValue());
                Support.AreEqual("0.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FAGetValue());

                //Total
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.TotalSalePrice.Enabled.ToString());
                #endregion

                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields- Alphabets";
                #region Alphabets checks
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields- Numeric";
                #region Numeric checks
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields- Alphanumerics";
                #region Alphanumerics checks
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields- Special characters";
                #region Special characters checks

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields - Alphanumeric with Special characters";
                #region Alphanumeric with Special characters check

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify message pop up for invalid Special Characters input in the description fields";
                #region invalid Special Characters checks

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("!");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("First Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("@");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Second Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("^");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("Third Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("`");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("Fourth Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("{");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("Fifth Sale Price");


                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("}");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("First Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("[");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Second Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("]");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("Third Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("|");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("Fourth Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("~");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("Fifth Sale Price");

                #endregion

                Reports.TestStep = "Verify that input of mixed characters in the description fields gives invalid message pop up - Alphanumeric with invalid Special characters";
                #region Alphanumeric and Special characters with invalid characters checks

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("A0<!");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("First Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("@b1>");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Second Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("C2*^");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("Third Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("E4${");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("Fourth Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("}d3%");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("Fifth Sale Price");


                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("f5#[");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("First Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("G:]");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Second Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("~h7;");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("Third Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("|iI8'");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("Fourth Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("K+lL`");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("Fifth Sale Price");

                #endregion


                Reports.TestStep = "Verify that total amount equals the sum of all Sale Price Amounts.";
                #region Sum All Amounts

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("100000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText("200000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FASetText("300000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FASetText("400000");
                Keyboard.SendKeys("{TAB}");

                string amt1 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceAmount.FAGetValue();
                string amt2 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FAGetValue();
                string amt3 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FAGetValue();
                string amt4 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FAGetValue();
                string amt5 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FAGetValue();

                decimal amtsum = decimal.Parse(amt1) + decimal.Parse(amt2) + decimal.Parse(amt3) + decimal.Parse(amt4) + decimal.Parse(amt5);
                string totalamt = amtsum.ToString("#,#.00");

                Support.AreEqual(totalamt, FastDriver.SalePrice_OwnerPolicyLiabilityDlg.TotalSalePrice.FAGetValue());
                #endregion
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(timeout: 30).ToString().Clean(), true);


                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);


                Reports.TestStep = "Verify if system displays Sale Price/Owner's Policy Liabilities webpage dialog for HUD file";
                #region HUD file
                Reports.TestStep = "Change File Format to HUD";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

                FastDriver.FileFees.HUD.FAClick();
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();


                Reports.TestStep = "Verify that the elipse button is displayed instead of the Edit SP/OPL button in the Terms/Dates/Status screen for file type HUD ";
                Support.AreEqual("...", FastDriver.TermsDatesStatus.Edit_SP_OPL.FAGetText());

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Verify that the Sale price fields are not displayed for HUD file.";
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.Exists().ToString());

                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                Reports.TestStep = "Verify if system displays Sale Price/Owner's Policy Liabilities webpage dialog for Refinance file";
                #region Refinance file

                Reports.TestStep = "Change File Format to CD and Transaction type to refinance";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

                FastDriver.FileFees.CD.FAClick();
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("R");
                Playback.Wait(2000);
                //Keyboard.SendKeys("{TAB}");               
                Support.AreEqual("The sale price and all seller charges and credits will be removed, Continue?", FastDriver.WebDriver.HandleDialogMessage(timeout: 15).ToString().Clean());


                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Verify that the elipse button is displayed instead of the Edit SP/OPL button in the Terms/Dates/Status screen for file type HUD ";
                Support.AreEqual("...", FastDriver.TermsDatesStatus.Edit_SP_OPL.FAGetText());

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Verify that the Sale price fields are not displayed for Refinance file.";
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.Exists().ToString());
                FastDriver.DialogBottomFrame.ClickCancel();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region NCS r08.2016
        #region FMCU0073_BAT0006_NCS
        //add test methods here by using the 'testms' snippet
        [TestMethod]
        public void US814221_TC832282()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "User Story 814221: REQ0991048- Total Sale Price becomes enabled upon removing the break down in the webpage.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File with Commercial business type and add values to Sales Price and  First New Loan fields.";

                #region Through UI
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion
                
                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad().SwitchToContentFrame();

                Reports.TestStep = "Click the Edit SP/OPL button to open the SP/OPL  dialog box.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Add  2nd, 3rd,4th and 5th Sale price breakdowns.";
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("100000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText("200000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FASetText("300000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FASetText("400000");                
                               

                Reports.TestStep = "Close the dialog and verify the Total Sale Price textbox is disabled.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(timeout: 30).ToString().Clean(), true);

                FastDriver.DialogBottomFrame.SwitchToContentFrame();
                Support.AreEqual(false, FastDriver.TermsDatesStatus.SalesPriceAmount.IsEnabled(), "Confirm Total Sales Price textbox is desabled.");
                                

                Reports.TestStep = "Open the SP/OPL dialog box again and clear the 1st Sale price; then close and confirm Total Sale Price textbox is still disabled.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceAmount.FASetText("0");
                Keyboard.SendKeys("{TAB}");

                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(timeout: 30).ToString().Clean(), true);
                FastDriver.DialogBottomFrame.SwitchToContentFrame();
                Support.AreEqual(false, FastDriver.TermsDatesStatus.SalesPriceAmount.IsEnabled(), "Confirm Total Sales Price textbox is desabled.");
                                
                Reports.TestStep = "Open the SP/OPL dialog box again and clear the rest of the Sale prices; then close and confirm Total Sale Price textbox is enabled.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("0");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText("0");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FASetText("0");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FASetText("0");
                Keyboard.SendKeys("{TAB}");

                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));
                
                FastDriver.DialogBottomFrame.SwitchToContentFrame();
                Support.AreEqual(true, FastDriver.TermsDatesStatus.SalesPriceAmount.IsEnabled(), "Confirm Total Sales Price textbox is enabled.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion 
        #endregion

        #endregion

        #region REG

        #region FMUC0073_REG0001
        [TestMethod]
        public void FMUC0073_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM536: Enter/Update File Status; FM4878: Change File Status; FM538: Change Status Closed to Open";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, validate file status = Open.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "File Status = Open");

                Reports.TestStep = "Change file status to Cancelled, reload the screen, and validate value is saved.";
                FastDriver.TermsDatesStatus.Status.FASelectItemBySendingKeys("Cancelled");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "File Status = Cancelled");

                Reports.TestStep = "Change file status to Closed, reload the screen, and validate value is saved.";
                FastDriver.TermsDatesStatus.Status.FASelectItemBySendingKeys("Closed");
                FastDriver.BottomFrame.Done();
                Support.AreEqual("If the status is Closed, the Settlement Date is required.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20), "Validate Warning Message");
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Closed", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "File Status = Closed");

                Reports.TestStep = "Change file status from Closed to Open, reload the screen, and validate value is saved.";
                FastDriver.TermsDatesStatus.Status.FASelectItemBySendingKeys("Open");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "File Status = Open");

                Reports.TestStep = "Change file status to Open in Error, reload the screen, and validate value is saved.";
                FastDriver.TermsDatesStatus.Status.FASelectItemBySendingKeys("Open In Error");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open In Error", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "File Status = Open In Error");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0002
        [TestMethod]
        public void FMUC0073_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM6438: Set Status Time; FM537: Enter File Status Date; FM2841: Modify File Status Date; FM539: Current or Past Status Date; FM4528: Future Status Date";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, validate Status Date is populated with today's date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.TermsDatesStatus.StatusDate.FAGetValue(), "Status Date");

                Reports.TestStep = "Validate Status Time is read only";
                Support.AreEqual("True", FastDriver.TermsDatesStatus.StatusTime.IsReadOnly().ToString(), "Status Time");
                
                Reports.TestStep = "Change file status to Cancelled, and set Status Date to a past date.";
                FastDriver.TermsDatesStatus.Status.FASelectItemBySendingKeys("Cancelled");
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.AddDays(-1).ToDateString() + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Reload the screen, validate Status Date saved, change status to Open, validate Satus Date is changed to today's date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                //Support.AreEqual(DateTime.Now.AddDays(-1).ToDateString(), FastDriver.TermsDatesStatus.StatusDate.FAGetValue(), "Status Date = Yesterday's Date");
                FastDriver.TermsDatesStatus.Status.FASelectItemBySendingKeys("Open");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.TermsDatesStatus.StatusDate.FAGetValue(), "Status Date = Today's Date");

                Reports.TestStep = "Change Status Date to a future date and validate warning message.";
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.AddDays(3).ToDateString());
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Status Change Date cannot be future date!", FastDriver.WebDriver.HandleDialogMessage(true, true, 20), "Validate Warning Message");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0003
        [TestMethod]
        public void FMUC0073_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM678: Enter Sale Price; FM4529: QFE Sales Price; FM2994: Recalc RE Comm on % ";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)100000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen, enter commission percentage.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText("6" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to Terms/Dates/Status screen, changed the sale price.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("200,000.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), "Commission Update Message");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen, validate commission amount has changed.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.CommissionAmount);
                Support.AreEqual("12,000.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue(), "Commission Amount");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0004
        [TestMethod]
        public void FMUC0073_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM569  Generate Open Date Read Only; FM685  Enter Estimated Days to Close; FM571  Calculate Est. Settlement Date; FM572  Copy Est. Settlement Date to Prorate Date; FM681  Update Prorate As Of Date";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, validate Open Date is read only and populated with today's date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                //Support.AreEqual("True", FastDriver.TermsDatesStatus.OpenDate.IsReadOnly().ToString(), "Open Date Read Only");
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.TermsDatesStatus.OpenDate.FAGetText(), "Open Date");

                Reports.TestStep = "Enter Est. Days to Close and validate Prorate as of date, Est. Settlement Date, and Disbursement Date";
                FastDriver.TermsDatesStatus.EstimattedDaysToClose.FASetText("1" + FAKeys.Tab);
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Prorate As of Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20), "Warning Message: Prorate As of Date");
                FastDriver.ProrationDateChangedDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();
                Support.AreEqual("The Prorate As of Date has changed. Would you like to update the Disbursement Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20), "Warning Message: Disbursement Date");
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Funding Date for Loans?", FastDriver.WebDriver.HandleDialogMessage(true, true, 20), "Warning Message: Funding Date for Loans");
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.AddDays(1).ToDateString(), FastDriver.TermsDatesStatus.ProrateAsOf.FAGetValue(), "Prorate as of");
                Support.AreEqual(DateTime.Now.AddDays(1).ToDateString(), FastDriver.TermsDatesStatus.EstimattedSettlementDate.FAGetValue(), "Est. Settlement Date");
                Support.AreEqual(DateTime.Now.AddDays(1).ToDateString(), FastDriver.TermsDatesStatus.DisbursementDate.FAGetValue(), "Disbursement Date");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0005
        [TestMethod]
        public void FMUC0073_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM10073  Ability to capture second new loan information; FM4531  Update Liability Amount from New Loan Screen; Hide Sale Price for Refi/Loan Transactions.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Add a second loan to the file";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItemBySendingKeys("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100,000.00" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("HUDFLINSR1" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, validate First & Second New Loan amount.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("5,000.00", FastDriver.TermsDatesStatus.FirstNewLoan.FAGetValue(), "First New Loan");
                Support.AreEqual("5,000.00", FastDriver.TermsDatesStatus.FirstNewLoanLiability.FAGetValue(), "First New Loan Liability");
                Support.AreEqual("100,000.00", FastDriver.TermsDatesStatus.SecondNewLoan.FAGetValue(), "Second New Loan");
                Support.AreEqual("100,000.00", FastDriver.TermsDatesStatus.SecondNewLoanLiability.FAGetValue(), "Second New Loan Liability");
                Support.AreEqual("False", FastDriver.TermsDatesStatus.SalesPriceAmount.IsEnabled().ToString(), "Sale Price Enabled?");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0006
        [TestMethod]
        public void FMUC0073_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM3001: Generate Fee Date.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Fee Entry screen and add a fee to the file.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 4, TableAction.SetText, "10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Make a deposit into the file.";
                #region Deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Perform Fee Transfer.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Change File Status", true, 20);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, validate Fee Date";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.TermsDatesStatus.FeeDate.FAGetValue(), "Fee Date");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0007
        [TestMethod]
        public void FMUC0073_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM3005  Enter File Complete Date; FM6433  Change TC Issued Date; FM6434  Change Days To Expiration Date; FM6435  Set TC Expiration Date";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, enter File Complete date";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.FileCompleteDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                Support.AreEqual("The File Complete Date has changed. Would you like to update the Settlement Date?", FastDriver.WebDriver.HandleDialogMessage(true, true, 20), "Update Settlemetn Date Message");

                Reports.TestStep = "Reload Terms/Dates/Status screen and validate Settlement Date and File Complete Date";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.TermsDatesStatus.SettlementDate.FAGetValue(), "File Complete Date");
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.TermsDatesStatus.FileCompleteDate.FAGetValue(), "File Complete Date");

                Reports.TestStep = "Validate Days to Expiration Date default value = 16";
                Support.AreEqual("16", FastDriver.TermsDatesStatus.DaystoExpirationdate.FAGetValue(), "Days to Expiration Date default value");

                Reports.TestStep = "Calculate TC Expiration Date from TC Issued Date + Days to Expiration Date.";
                FastDriver.TermsDatesStatus.DaystoExpirationdate.FASetText("3" + FAKeys.Tab);
                FastDriver.TermsDatesStatus.TCIssuedDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                Support.AreEqual(DateTime.Now.AddDays(3).ToDateString(), FastDriver.TermsDatesStatus.TCExpirationDate.FAGetValue(), "TC Expiration Date");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0008
        [TestMethod]
        public void FMUC0073_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM6437: Set Order Received Date; FM6436: Set Order Received Time; FM6571: Prompt to Modify and Reissue 1099-S Form; FM6572: Prompt to Mark 1099-S Ready for Extract; FM6924: Allow 1099-S Messages for Activity Date and 1099-S Seller ";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Sellers[0].SSN = "111-11-1111";
                fileRequest.File.Sellers[0].LastName1099S = "1099S";
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, set order received date/time";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.OrderRecievedDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.OrderRecievedTime.FASetText("09:00 AM PST" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Sellers screen, set 1099-S Classification";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItemBySendingKeys("1099-S" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to 1099-S screen, create a new 1099-S";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("200,000.00" + FAKeys.Tab);
                FastDriver._1099S.ActiveReadyForExtract.FASetCheckbox(true);
                FastDriver._1099S.ActiveAddress.FASetText("2 First American Way" + FAKeys.Tab);
                FastDriver._1099S.ActiveCity.FASetText("Santa Ana" + FAKeys.Tab);
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("CA");
                FastDriver._1099S.ActiveZip.FASetText("92704" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, validate Order Received Date/Time.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.TermsDatesStatus.OrderRecievedDate.FAGetValue(), "Order Received Date");
                Support.AreEqual("09:00 AM", FastDriver.TermsDatesStatus.OrderRecievedTime.FAGetValue().Substring(0, 8), "Order Received Time");

                Reports.TestStep = "Change Settlement date, validate update 1099-S message";
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.AddDays(1).ToDateString() + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                Support.AreEqual("The Ready for Extract flag has been removed for one or more 1099-S records. Please update each 1099-S record and print the 1099-S form for the seller.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20), "Update 1099-S message");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0009
        [TestMethod]
        public void FMUC0073_REG0009()
        {
            try
            {
                Reports.TestDescription = "BR_FM6573_FM6574: Disable Ready for Extract & Prompt to Create 1099-S Record.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Sellers[0].SSN = "111-11-1111";
                fileRequest.File.Sellers[0].LastName1099S = "1099S";
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, set order received date/time";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Sellers screen, set 1099-S Classification";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItemBySendingKeys("1099-S" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to 1099-S screen, create a new 1099-S";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("200,000.00" + FAKeys.Tab);
                FastDriver._1099S.ActiveReadyForExtract.FASetCheckbox(true);
                FastDriver._1099S.ActiveAddress.FASetText("2 First American Way" + FAKeys.Tab);
                FastDriver._1099S.ActiveCity.FASetText("Santa Ana" + FAKeys.Tab);
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("CA");
                FastDriver._1099S.ActiveZip.FASetText("92704" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, remove sale price and settlemt date";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("0.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                Reports.TestStep = "Navigate to 1099-S screen, validate Ready For Extract is disabled and unchecked";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver._1099S.ActiveReadyForExtract.IsSelected().ToString(), "Ready For Extract Checked");
                // Same behavior in production
                //Support.AreEqual("False", FastDriver._1099S.ActiveReadyForExtract.IsEnabled().ToString(), "Ready For Extract Disabled");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0010
        [TestMethod]
        public void FMUC0073_REG0010()
        {
            try
            {
                Reports.TestDescription = "BR_FM6575_FM6925: Warn for Sale Price Over 1099-S Proceeds Limit & Prevent 1099-S Messages if No 1099-S Seller.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Sellers[0].SSN = "111-11-1111";
                fileRequest.File.Sellers[0].LastName1099S = "1099S";
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Sellers screen, set 1099-S Classification";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItemBySendingKeys("1099-S" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, set Sale Price over the maximum limit allowed.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("9,999,999,9990.99" + FAKeys.Tab);
                Support.AreEqual("Sale Price exceeds maximum for regular 1099-S creation. Please create a manual 1099-S for the seller.", FastDriver.WebDriver.HandleDialogMessage(false, true, 20), "Sale price exceeds max. limit warning");
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                Reports.TestStep = "Navigate to Sellers screen, remove 1099-S Classification";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItemBySendingKeys("N/A" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, remove sale price.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("" + FAKeys.Tab);
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20), "Update Liability Amount Message");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0011
        [TestMethod]
        public void FMUC0073_REG0011()
        {
            try
            {
                Reports.TestDescription = "FM7560: Terms/Dates/Status in second instance of FAST.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(5000);

                Reports.TestStep = "Open FastView from top frame";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Search for the previously created file.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 20);
                FastDriver.FASTView.WaitForScreenToLoad();
                FastDriver.FASTView.FromDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.FASTView.ToDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.FASTView.FindNow.FAClick();
                this.WaitForFastViewScreenToLoad();

                try
                {
                    FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, File.FileNumber, 1, TableAction.Click);
                }
                catch (Exception ex)
                {
                    Reports.TestStep = "Perform search second time.";
                    Playback.Wait(5000); //Wait 5 seconds for file to show up on search results
                    FastDriver.FileSearch.FindNow.FAClick();
                    this.WaitForFastViewScreenToLoad();
                    FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, File.FileNumber, 1, TableAction.Click);
                }

                FastDriver.FileSearch.Select.FAClick();
                FastDriver.FileSearch.SendControlShift("t");

                Reports.TestStep = "Validate sale price";
                FastDriver.TermsDatesStatus.WaitForFastViewScreenToLoad();
                Support.AreEqual("200,000.00", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue(), "Sale Price");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0012
        [TestMethod]
        public void FMUC0073_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM10534: Chang Sale Price/Liability after fees have been calculated; FM10533: Prevent Parameter Changes";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.SalesPriceAmount = (decimal)300000;
                fileRequest.File.NewLoan.NewLoanAmount = (decimal)200000;
                fileRequest.File.NewLoan.LiabilityAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Add fees to file";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItemByIndex(1);
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItemBySendingKeys("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("10" + FAKeys.Tab);
                FastDriver.CalculateFees.RecordingFeesConsiderationAmount.FASetText("200000.00" + FAKeys.Tab);
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();
                FastDriver.CalculateFees.ClickNext();
                FastDriver.CalculateFees.ClickNext();
                FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.SummaryTable);
                string[] fee1 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(2, "", "Buyer");
                string[] fee2 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(3, "", "Buyer");
                string[] fee3 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(4, "", "Buyer");
                string[] fee4 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(5, "", "Buyer");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change sale price/liability amount.";
                if (AutoConfig.FormType == "HUD") // HUD form change from Terms/Dates/Status screen
                {
                    FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                    FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("400,000.00" + FAKeys.Tab);
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                    //Support.AreEqual("Changing the Sales Price, Loan Amount or Liability Amounts will result in automatic recalculation of impacted fees if no override exists. If override exists there will be no auto-recalculation and impacted fees will be removed.", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Recalculate fees warning");
                    // Release 10.7
                    Support.AreEqual("Changing the Loan Amount or Liability Amount will result in the recalculation of impacted fees.", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Recalculate fees warning");
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                    FastDriver.BottomFrame.Done();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                }
                else // CD form change from New Loan screen
                {
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("400,000.00" + FAKeys.Tab);
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                    //Support.AreEqual("Changing the Sales Price, Loan Amount or Liability Amounts will result in automatic recalculation of impacted fees if no override exists. If override exists there will be no auto-recalculation and impacted fees will be removed.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), "Recalculate fees warning");
                    // Release 10.7
                    Support.AreEqual("Changing the Loan Amount or Liability Amount will result in the recalculation of impacted fees.", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Recalculate fees warning");
                    
                    FastDriver.BottomFrame.Done();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                }

                Reports.TestStep = "Navigate to Fee Entry screen, validate fees are recalculated";
                try
                {
                    FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                }
                catch
                {
                    FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                }
                
                Support.AreNotEqual(fee1[1], FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", fee1[0], "Buyer Charge", TableAction.GetText).Message, "Title Fee");
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingandTaxTable);
                Support.AreNotEqual(fee2[1], FastDriver.FileFees.RecordingandTaxTable.PerformTableAction("Description", fee2[0], "Buyer Charge", TableAction.GetText).Message, "Recording Fee Deed 1");
                Support.AreNotEqual(fee3[1], FastDriver.FileFees.RecordingandTaxTable.PerformTableAction("Description", fee3[0], "Buyer Charge", TableAction.GetText).Message, "Recording Fee Deed 2");
                Support.AreNotEqual(fee4[1], FastDriver.FileFees.RecordingandTaxTable.PerformTableAction("Description", fee4[0], "Buyer Charge", TableAction.GetText).Message, "Recording Fee Deed 3");

                Reports.TestStep = "Make a deposit into the file.";
                #region Deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 20000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Perform Fee Transfer.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Change File Status", true, 20);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);

                Reports.TestStep = "Change sale price/liability amount.";
                if (AutoConfig.FormType == "HUD") // HUD form change from Terms/Dates/Status screen
                {
                    FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                    FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("500,000.00" + FAKeys.Tab);
                    Support.AreEqual("1st New Loan Liability Amount is associated with a fee that has been disbursed.Liability Amount Information cannot be modified. Cancel Issued Disbursements before proceeding with changes.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), "Prevent change sale price");
                    FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                    Support.AreEqual("400,000.00", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue(), "Sale Price Remain");
                    FastDriver.BottomFrame.Done();
                }
                else // CD form change from New Loan screen
                {
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500,000.00" + FAKeys.Tab);
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                    Support.AreEqual("1st New Loan Liability Amount is associated with a fee that has been disbursed.Liability Amount Information cannot be modified. Cancel Issued Disbursements before proceeding with changes.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), "Prevent change sale price");
                    FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                    Support.AreEqual("400,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue(), "Liability Amount Remain");
                    FastDriver.BottomFrame.Done();
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0013
        [TestMethod]
        public void FMUC0073_REG0013()
        {
            try
            {
                Reports.TestDescription = "FM13585: Prevent change of Sale Price and Liability Amount";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.SalesPriceAmount = (decimal)300000;
                fileRequest.File.NewLoan.NewLoanAmount = (decimal)200000;
                fileRequest.File.NewLoan.LiabilityAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Add fees to file";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItemByIndex(1);
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItemBySendingKeys("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("10" + FAKeys.Tab);
                FastDriver.CalculateFees.RecordingFeesConsiderationAmount.FASetText("200000.00" + FAKeys.Tab);
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();
                FastDriver.CalculateFees.ClickNext();
                FastDriver.CalculateFees.ClickNext();
                FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.SummaryTable);
                string[] fee1 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(2, "", "Buyer");
                string[] fee2 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(3, "", "Buyer");
                string[] fee3 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(4, "", "Buyer");
                string[] fee4 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(5, "", "Buyer");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Perform split fee";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State").WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payee Search", true, 20);
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FABResultsTable.PerformTableAction(2, 1, TableAction.On);
                string payeeName = FastDriver.PayeeSearchDlg.FABResultsTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.SpliFeeImage(1).FAClick();
                Playback.Wait(1500);
                FastDriver.SplitFeeDisbursements.SelectPayee(2).FASelectItemBySendingKeys(payeeName);
                FastDriver.SplitFeeDisbursements.SplitPercent(2).FASetText("50");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Change sale price/liability amount.";
                if (AutoConfig.FormType == "HUD") // HUD form change from Terms/Dates/Status screen
                {
                    FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                    FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("400,000.00" + FAKeys.Tab);
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                    //Support.AreEqual("Changing the Sales Price, Loan Amount or Liability Amounts will result in automatic recalculation of impacted fees if no override exists. If override exists there will be no auto-recalculation and impacted fees will be removed.", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Recalculate fees warning");
                    //Release 10.7
                    Support.AreEqual("Changing the Loan Amount or Liability Amount will result in the recalculation of impacted fees.", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Recalculate fees warning");
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                    FastDriver.BottomFrame.Done();
                }
                else // CD form change from New Loan screen
                {
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("400,000.00" + FAKeys.Tab);
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                    //Support.AreEqual("Changing the Sales Price, Loan Amount or Liability Amounts will result in automatic recalculation of impacted fees if no override exists. If override exists there will be no auto-recalculation and impacted fees will be removed.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), "Recalculate fees warning");
                    //Release 10.7
                    Support.AreEqual("Changing the Loan Amount or Liability Amount will result in the recalculation of impacted fees.", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Recalculate fees warning");
                    FastDriver.BottomFrame.Done();
                }


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0014
        [TestMethod]
        public void FMUC0073_REG0014()
        {
            try
            {
                Reports.TestDescription = "EW8_EW9: Error warn for when broker check issued & increase and decrease the sales price.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.SalesPriceAmount = (decimal)300000;
                fileRequest.File.NewLoan.NewLoanAmount = (decimal)200000;
                fileRequest.File.NewLoan.LiabilityAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create an REB instance with commission amount and seller charge.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText("6" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                string payeeName = FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAGetText();

                Reports.TestStep = "Make a deposit into the file.";
                #region Deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 100000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Print the commission check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, payeeName, 8, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Change sale price/liability amount.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("400,000.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Sale Price has changed warning");
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), "Check has been issued warning");
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0015
        [TestMethod]
        public void FMUC0073_REG0015()
        {
            try
            {
                Reports.TestDescription = @"Verify Error/Warning messages for Refinance files";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Create a file

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.SalesPriceAmount = (decimal)300000;
                fileRequest.File.NewLoan.NewLoanAmount = (decimal)200000;
                fileRequest.File.NewLoan.LiabilityAmount = (decimal)200000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion


                #region Enter values in TDS Screen
                Reports.TestStep = "Enter values in TDS Screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.EstimattedDaysToClose.FASetText("34" + FAKeys.Tab);
                var TempDate = DateTime.Today.AddDays(Int32.Parse("34"));
                if (TempDate.ToString("dddd") == "Saturday" || TempDate.ToString("dddd") == "Sunday")
                {
                    FastDriver.WeekendWarning.WaitForScreenToLoad();
                    if (TempDate.DayOfWeek.ToString() == "Sunday")
                    {
                        FastDriver.WeekendWarning.rdoSunday.FAClick();
                    }
                    else
                    {
                        FastDriver.WeekendWarning.rdoSaturday.FAClick();
                    }
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Prorate As of Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Est. Settlement Date has changed warning");
                if (TempDate.ToString("dddd") == "Saturday" || TempDate.ToString("dddd") == "Sunday")
                {
                    FastDriver.WeekendWarning.WaitForScreenToLoad();
                    if (TempDate.DayOfWeek.ToString() == "Sunday")
                    {
                        FastDriver.WeekendWarning.rdoSunday.FAClick();
                    }
                    else
                    {
                        FastDriver.WeekendWarning.rdoSaturday.FAClick();
                    }
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                Support.AreEqual("The Prorate As of Date has changed. Would you like to update the Disbursement Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Prorate As of Date has changed warning");
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Funding Date for Loans?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Est. Settlement Date has changed warning");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.ClosingAppointmentDate1.FASetText((DateTime.Today.AddDays(Convert.ToInt32(2)).Date.ToDateString()) + FAKeys.Tab);
                FastDriver.TermsDatesStatus.ClosingAppointmentDate2.FASetText((DateTime.Today.AddDays(Convert.ToInt32(3)).Date.ToDateString()) + FAKeys.Tab);
                FastDriver.TermsDatesStatus.OrderRecievedDate.FASetText((DateTime.Today.AddDays(Convert.ToInt32(4)).Date.ToDateString()) + FAKeys.Tab);
                FastDriver.TermsDatesStatus.DateofContract.FASetText((DateTime.Today.AddDays(Convert.ToInt32(5)).Date.ToDateString()) + FAKeys.Tab);
                FastDriver.TermsDatesStatus.FeeDate.FASetText((DateTime.Today.AddDays(Convert.ToInt32(10)).Date.ToDateString()) + FAKeys.Tab);
                FastDriver.TermsDatesStatus.ClosingAppointmentTime1.FASetText("12:12 PM");
                FastDriver.TermsDatesStatus.ClosingAppointmentTime2.FASetText("12:12 PM");
                FastDriver.TermsDatesStatus.OrderRecievedTime.FASetText("12:12 PM");
                FastDriver.TermsDatesStatus.DateofContractAcceptance.FASetText((DateTime.Today.AddDays(Convert.ToInt32(6)).Date.ToDateString()) + FAKeys.Tab);
                FastDriver.TermsDatesStatus.SettlementDate.FASetText((DateTime.Today.AddDays(Convert.ToInt32(7)).Date.ToDateString()) + FAKeys.Tab);
                FastDriver.TermsDatesStatus.FileCompleteDate.FASetText((DateTime.Today.AddDays(Convert.ToInt32(8)).Date.ToDateString()) + FAKeys.Tab);
                Support.AreEqual("The File Complete Date has changed. Would you like to update the Settlement Date?", FastDriver.WebDriver.HandleDialogMessage(false, false, 20).Clean(), "File Complete Date has changed warning");
                FastDriver.TermsDatesStatus.TCIssuedDate.FASetText((DateTime.Today.AddDays(Convert.ToInt32(9)).Date.ToDateString()) + FAKeys.Tab);
                FastDriver.TermsDatesStatus.StatusDate.FASetText((DateTime.Today.AddDays(Convert.ToInt32(-1)).Date.ToDateString()) + FAKeys.Tab);
                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.TermsDatesStatus.PropertyValue.FASetText("23233.45" + FAKeys.Tab);
                }
                #endregion

                #region Verify the values on AutoSave
                Reports.TestStep = "Navigate away and verify if the values are autosaved.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("34", FastDriver.TermsDatesStatus.EstimattedDaysToClose.FAGetValue().ToString());
                string EstDate = DateTime.Today.AddDays(Convert.ToInt32(34)).Date.ToDateString();
                Support.AreEqual(EstDate, FastDriver.TermsDatesStatus.EstimattedSettlementDate.FAGetValue().ToString());
                Support.AreEqual(EstDate, FastDriver.TermsDatesStatus.ProrateAsOf.FAGetValue().ToString());
                Support.AreEqual(EstDate, FastDriver.TermsDatesStatus.DisbursementDate.FAGetValue().ToString());
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(2)).Date.ToDateString()), FastDriver.TermsDatesStatus.ClosingAppointmentDate1.FAGetValue().ToString());
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(3)).Date.ToDateString()), FastDriver.TermsDatesStatus.ClosingAppointmentDate2.FAGetValue().ToString());
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(4)).Date.ToDateString()), FastDriver.TermsDatesStatus.OrderRecievedDate.FAGetValue().ToString());
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(5)).Date.ToDateString()), FastDriver.TermsDatesStatus.DateofContract.FAGetValue().ToString());
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(10)).Date.ToDateString()), FastDriver.TermsDatesStatus.FeeDate.FAGetValue().ToString());
                Support.AreEqual("12:12 PM", FastDriver.TermsDatesStatus.ClosingAppointmentTime1.FAGetValue().ToString().Trim());
                Support.AreEqual("12:12 PM", FastDriver.TermsDatesStatus.ClosingAppointmentTime2.FAGetValue().ToString().Trim());
                Support.AreEqual("12:12 PM", FastDriver.TermsDatesStatus.OrderRecievedTime.FAGetValue().ToString().Trim().Substring(0, 8));
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(6)).Date.ToDateString()), FastDriver.TermsDatesStatus.DateofContractAcceptance.FAGetValue().ToString());
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(7)).Date.ToDateString()), FastDriver.TermsDatesStatus.SettlementDate.FAGetValue().ToString());
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(8)).Date.ToDateString()), FastDriver.TermsDatesStatus.FileCompleteDate.FAGetValue().ToString());
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(9)).Date.ToDateString()), FastDriver.TermsDatesStatus.TCIssuedDate.FAGetValue().ToString());
                Support.AreEqual((DateTime.Today.AddDays(Convert.ToInt32(-1)).Date.ToDateString()), FastDriver.TermsDatesStatus.StatusDate.FAGetValue().ToString(), "Status Date is not getting saved. Defect is logged TFS# 740449. Please refer the defect");
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("23,233.45", FastDriver.TermsDatesStatus.PropertyValue.FAGetValue().ToString());
                }
                #endregion

                #region Update estimated days to close in TDS Screen and click on Done button
                Reports.TestStep = "Update estimated days to close in TDS Screen";
                FastDriver.TermsDatesStatus.EstimattedDaysToClose.FASetText("54" + FAKeys.Tab);
                TempDate = DateTime.Today.AddDays(Int32.Parse("54"));
                EstDate = DateTime.Today.AddDays(Convert.ToInt32(54)).Date.ToDateString();
                Support.AreEqual("Would you like to update the Estimated Settlement Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Est. Settlement Date has changed warning");
                if (TempDate.ToString("dddd") == "Saturday" || TempDate.ToString("dddd") == "Sunday")
                {
                    FastDriver.WeekendWarning.WaitForScreenToLoad();
                    if (TempDate.DayOfWeek.ToString() == "Sunday")
                    {
                        FastDriver.WeekendWarning.rdoSunday.FAClick();
                    }
                    else
                    {
                        FastDriver.WeekendWarning.rdoSaturday.FAClick();
                    }
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Prorate As of Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Est. Settlement Date has changed warning");
                if (TempDate.ToString("dddd") == "Saturday" || TempDate.ToString("dddd") == "Sunday")
                {
                    FastDriver.WeekendWarning.WaitForScreenToLoad();
                    if (TempDate.DayOfWeek.ToString() == "Sunday")
                    {
                        FastDriver.WeekendWarning.rdoSunday.FAClick();
                    }
                    else
                    {
                        FastDriver.WeekendWarning.rdoSaturday.FAClick();
                    }
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                Support.AreEqual("The Prorate As of Date has changed. Would you like to update the Disbursement Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Prorate As of Date has changed warning");
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Funding Date for Loans?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Est. Settlement Date has changed warning");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Reload TDS screen and verify the updated values.
                Reports.TestStep = "Reload TDS screen and verify the updated values.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("54", FastDriver.TermsDatesStatus.EstimattedDaysToClose.FAGetValue().ToString());
                Support.AreEqual(EstDate, FastDriver.TermsDatesStatus.EstimattedSettlementDate.FAGetValue().ToString());
                Support.AreEqual(EstDate, FastDriver.TermsDatesStatus.ProrateAsOf.FAGetValue().ToString());
                Support.AreEqual(EstDate, FastDriver.TermsDatesStatus.DisbursementDate.FAGetValue().ToString());
                #endregion

                #region Verify weekend warning message.
                Reports.TestStep = "Verify weekend warning message.";
                var date = DateTime.Now;
                string nextSunday = date.AddDays(7 - (int)date.DayOfWeek).ToDateString();
                FastDriver.TermsDatesStatus.EstimattedSettlementDate.FASetText(nextSunday + FAKeys.Tab);
                FastDriver.WeekendWarning.WaitForScreenToLoad();
                Support.AreEqual("Est. Settlement Date falls on a Sunday.", FastDriver.WeekendWarning.RescissionNotice.Text.Clean());
                FastDriver.WeekendWarning.rdoMonday.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Prorate As of Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Est. Settlement Date has changed warning");
                Support.AreEqual("The Prorate As of Date has changed. Would you like to update the Disbursement Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Prorate As of Date has changed warning");
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Funding Date for Loans?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Est. Settlement Date has changed warning");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify the updated values in TDS Screen.
                Reports.TestStep = "Verify the updated values in TDS Screen.";
                string nextMonday = date.AddDays(8 - (int)date.DayOfWeek).ToDateString();
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(nextMonday, FastDriver.TermsDatesStatus.EstimattedSettlementDate.FAGetValue().ToString());
                Support.AreEqual(nextMonday, FastDriver.TermsDatesStatus.ProrateAsOf.FAGetValue().ToString());
                Support.AreEqual(nextMonday, FastDriver.TermsDatesStatus.DisbursementDate.FAGetValue().ToString());
                #endregion

                #region Verify weekend warning message for Prorate As of Date.
                Reports.TestStep = "Verify weekend warning message for Prorate As of Date.";
                date = date.AddDays(Convert.ToInt32(7));
                nextSunday = date.AddDays(6 - (int)date.DayOfWeek).ToDateString();
                FastDriver.TermsDatesStatus.ProrateAsOf.FAClick();
                FastDriver.TermsDatesStatus.ProrateAsOf.FASendKeys(nextSunday+FAKeys.Tab);
                 FastDriver.WeekendWarning.WaitForScreenToLoad();
                 Support.AreEqual("Prorate As Of Date falls on a Saturday.", FastDriver.WeekendWarning.RescissionNotice.Text.Clean());
                FastDriver.WeekendWarning.rdoMonday.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("The Prorate As of Date has changed. Would you like to update the Disbursement Date?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Prorate As of Date has changed warning");
                #endregion

                #region Verify the updated values in TDS Screen.
                Reports.TestStep = "Verify the updated values in TDS Screen";
                nextMonday = date.AddDays(8 - (int)date.DayOfWeek).ToDateString();
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(nextMonday, FastDriver.TermsDatesStatus.ProrateAsOf.FAGetValue().ToString());
                Support.AreEqual(nextMonday, FastDriver.TermsDatesStatus.DisbursementDate.FAGetValue().ToString());
                #endregion

                #region Verify Future Status date warning message.
                Reports.TestStep = "Verify Future Status date warning message.";
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.AddDays(Convert.ToInt32(2)).ToDateString() + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                if (AutoConfig.FormType == "HUD")
                    Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(false, true, 20), "Sales Price date message");
                Support.AreEqual("Status Change Date cannot be future date!", FastDriver.WebDriver.HandleDialogMessage(false, true, 20).Clean(), "Status Future date message");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.TermsDatesStatus.StatusDate.FAGetValue().ToString());
                #endregion

                #region Verify Fee issued warning message.
                Reports.TestStep = "Add fees to file";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItemByIndex(1);
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItemBySendingKeys("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("10" + FAKeys.Tab);
                FastDriver.CalculateFees.RecordingFeesConsiderationAmount.FASetText("200000.00" + FAKeys.Tab);
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();
                FastDriver.CalculateFees.ClickNext();
                Playback.Wait(2000);
                FastDriver.CalculateFees.ClickNext();
                FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.SummaryTable);
                string[] fee1 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(2,"","Buyer");
                FastDriver.CalculateFees.SelectFeeFromSummaryTable(2, "Buyer", "Permitted Rate Reduction","100.56");
                string[] fee2 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(3,"", "Buyer");
                FastDriver.CalculateFees.SelectFeeFromSummaryTable(3, "Buyer", "Permitted Rate Reduction", "100.56");
                string[] fee3 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(4,"", "Buyer");
                FastDriver.CalculateFees.SelectFeeFromSummaryTable(4, "Buyer", "Permitted Rate Reduction", "100.56");
                string[] fee4 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(5,"", "Buyer");
                FastDriver.CalculateFees.SelectFeeFromSummaryTable(5, "Buyer", "Permitted Rate Reduction", "100.56");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change sale price/liability amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("23,233.45", FastDriver.NewLoan.PropertyValue.FAGetValue());
                    Support.AreEqual("True", FastDriver.NewLoan.EstimatedPropertyValue.IsSelected().ToString());
                    FastDriver.NewLoan.PropertyValue.FASetText("657343");
                    FastDriver.NewLoan.AppraisedPropertyValue.FAClick();
                }
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("400,000.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20, true);
                //Change in 10.7 release, new dialog
                FastDriver.FACCRecalculationConfirmDlg.WaitForScreenToLoad();
                Support.AreEqual("Changing the Loan Amount or Liability Amount will result in the Recalculation of Impacted fees. If Calculated Rates have override details, system can recalculate or remove overridden fees. What would you like to do?", FastDriver.FACCRecalculationConfirmDlg.MessageText.FAGetText().Clean(), "Recalculate fees warning");
                FastDriver.FACCRecalculationConfirmDlg.RecalculateFees.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Navigate to Fee Entry screen, validate fees are recalculated";
                try
                {
                    FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                }
                catch
                {
                    FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                }

                Support.AreEqual("True", FastDriver.FileFees.SelectCheckbox.IsSelected().ToString());
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingandTaxTable);
                Support.AreEqual("True", FastDriver.FileFees.SelectRecording1.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.FileFees.SelectRecording2.IsSelected().ToString());
                #endregion

                if (AutoConfig.FormType == "CD")
                {
                    #region Perform delivery in CD Screen
                    Reports.TestStep = "Perform delivery in CD Screen";
                    FastDriver.ClosingDisclosure.Open();
                    FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                    FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString());
                    FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText(DateTime.Today.AddDays(Convert.ToInt32(3)).ToDateString());
                    FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText(DateTime.Today.AddDays(Convert.ToInt32(5)).ToDateString());
                    FastDriver.ClosingDisclosure.DateRecievedAck.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.DateRecievedText.FASetText(DateTime.Today.AddDays(Convert.ToInt32(6)).ToDateString());
                    FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Print");
                    FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                    FastDriver.PrintDlg.WaitForScreenToLoad();
                    FastDriver.PrintDlg.Print.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow("Print", 60);
                    #endregion

                    #region Verify CD Dates in TDS section
                    Reports.TestStep = "Verify CD Dates in TDS section";
                    FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                    Support.AreEqual("657,343.00", FastDriver.TermsDatesStatus.PropertyValue.FAGetValue());
                    Support.AreEqual("True", FastDriver.TermsDatesStatus.AppraisedPropValue.IsSelected().ToString());
                    Support.AreEqual("True",FastDriver.TermsDatesStatus.DeliveryTypeOther.IsSelected().ToString());
                    Support.AreEqual(DateTime.Today.ToDateString(),FastDriver.TermsDatesStatus.DateIssuedtxt.FAGetValue());
                    Support.AreEqual(DateTime.Today.AddDays(Convert.ToInt32(5)).ToDateString(), FastDriver.TermsDatesStatus.DisbursementDatetxt.FAGetValue());
                    Support.AreEqual(DateTime.Today.AddDays(Convert.ToInt32(6)).ToDateString(), FastDriver.TermsDatesStatus.ReceivedDate.FAGetValue());
                    Support.AreEqual(DateTime.Today.AddDays(Convert.ToInt32(3)).ToDateString(), FastDriver.TermsDatesStatus.ClosingDate.FAGetValue());
                    Support.AreEqual("True", FastDriver.TermsDatesStatus.DateReceivedAck.IsSelected().ToString());
                    #endregion
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0073_REG0016
        [TestMethod]
        //Team                                    : ServReq-Galaxy
        //Iteration                               : r04
        //UserStory                               : User Story 673027:REQ0834263 - Republic - When liability amounts are changed, recalculate all fees instead of remove
        //TestCase                                : 731638
        //Appended By/ Created By                 : Sheetal Gothi
        public void FMUC0073_REG0016()
        {
            try
            {
                #region data setup
                string val = string.Empty;
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[] 
                    { 
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        }
                    };
                fileRequest.File.Products = new FASTWCFHelpers.FastFileService.Product[]
                {
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 1321,
                    },
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 1320,
                    },

                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 884,
                    },
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 886,
                    },

                };
                #endregion

                Reports.TestDescription = "Remove the policies for whom the override reason is associated on click of remove all option";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //FastDriver.TopFrame.SearchFileByFileNumber("40623");
                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Setting an amount to  Owner Liablity.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("5000" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);
                val = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                //Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", val);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "In Fee entry screen Select All fee checkbox & Click on Calculate Fees button.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad(FastDriver.FileFees.AllFees);
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees..";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.TitleFeesTitlePolicy);
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Standard Owner Policy");

                Reports.TestStep = "Click on Add on Title Policy..";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();

                Reports.TestStep = "Calculate Recording Fee.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesRecordingDocument);
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItemBySendingKeys("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("33");
                FastDriver.CalculateFees.RecordingFeesConsiderationAmount.FASetText("500.00");

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Add Endorsement Fee.";
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();

                Reports.TestStep = "Select Endorsement Fee.";
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();
                string strFACCEndorsementFees = FastDriver.FACCEndorsementsDlg.SelectEndorsementName.FAGetText().Clean();
                Reports.StatusUpdate("Using FACC Endorsement Fee: " + strFACCEndorsementFees, true);
                FastDriver.FACCEndorsementsDlg.SelectEndorsement.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select View More option.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItem("++View More");
                FastDriver.CalculateFees.SummaryFastFeeDescription.Click();
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASendKeys("+" + FAKeys.Tab);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable);
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction("#2", "ALTA Residential - Plain Language (1341.87)", "#1", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Descriptions For the Fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItem("ALTA Residential - Plain Language (1341.87)");
                FastDriver.CalculateFees.SummaryChargeTo.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryOverrideReason.FASelectItem("Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryOverrideAmount.FASetText("200.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);
                FastDriver.CalculateFees.SummarySplitPercentage.FASetText("50.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);

                FastDriver.CalculateFees.SummaryFastFeeDescription2.FASelectItemByIndex(1);
                FastDriver.CalculateFees.SummaryChargeTo2.FASelectItem("Seller");
                FastDriver.CalculateFees.SummaryOverrideReason2.FASelectItem("Permitted Rate Reduction");

                Reports.TestStep = "Create charge for buyer with Deed";
                FastDriver.CalculateFees.SummaryFastFeeDescription3.Click();
                FastDriver.CalculateFees.SummaryFastFeeDescription3.FASendKeys("+" + FAKeys.Tab);
                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem("Recording Fee - Mortgage");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable);
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction("#2", "Record Mortgage - 1", "#1", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SummaryChargeTo3.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryOverrideReason3.FASelectItem("Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryFastFeeDescription4.FASelectItem("Record Deed");
                FastDriver.CalculateFees.SummaryChargeTo4.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryFastFeeDescription5.FASelectItem("Record Deed");
                FastDriver.CalculateFees.SummaryChargeTo5.FASelectItem("Buyer");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for the calculated Transfer tax.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary").WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "DEED - Recording Fee", "Calculated Rate", TableAction.GetText).Message;
                Support.AreEqual("111.00", val, "DEED - Recording Fee calculated rate");

                Reports.TestStep = "Verifying for the calculated Transfer tax.";
                val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "DEED - Documentary Transfer Tax", "Calculated Rate", TableAction.GetText).Message;
                Support.AreEqual("0.55", val, "DEED - Documentary Transfer Tax calculated rate");

                Reports.TestStep = "Verifying for the calculated Transfer tax.";
                val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "DEED - Town Transfer Tax", "Calculated Rate", TableAction.GetText).Message;
                Support.AreEqual("5.75", val, "DEED - Town Transfer Tax calculated rate");

                #region "FACC Recalculate Fees"

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("111111111" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);

                Reports.TestStep = "Verify for the message after change the sales price.";
                val = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", val);
                Playback.Wait(2000);
                FastDriver.FACCRecalculationConfirmDlg.WaitForScreenToLoad();
                FastDriver.FACCRecalculationConfirmDlg.Recalculate.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Validate:Changing the Sales Price or Liability Amounts will result in the Recalculation of Impacted fees. If  Calculated Rates have override details, system can recalculate or remove overridden fees. What would you like to do?";
                var value = FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                Support.AreEqual("Recalculation of fees will result in removal of override reason, override amount and split $ amount. Fees will be recalculated.", value);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for the calculated Transfer tax after changing the Sales Price amount on TDS.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary").WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "ALTA Owner Policy", "Override Reason", TableAction.GetSelectedItem).Message;
                Support.AreEqual("", val, "ALTA Owner Policy - FACC Override reason got removed");
                Support.AreEqual("50.00", FastDriver.CalculateFees.SummarySplitPercentage.FAGetValue().Clean(), "SplitPercentage1");
                val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "DEED - Town Transfer Tax", "Calculated Rate", TableAction.GetText).Message;
                Support.AreEqual("5.75", val, "DEED - Town Transfer Tax calculated rate");
                val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "DEED - Recording Fee", "Calculated Rate", TableAction.GetText).Message;
                Support.AreEqual("111.00", val, "DEED - Recording Fee calculated rate");
                val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "DEED - Documentary Transfer Tax", "Calculated Rate", TableAction.GetText).Message;
                Support.AreEqual("0.55", val, "DEED - Documentary Transfer Tax calculated rate");

                #endregion



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0073_REG0017
        [TestMethod]
        //Team                                    : Automation
        //UserStory                               :User Story 380706,556817,568779,572610-Additional Sale Price Fields on the TDS Screen- Functionality
        //Appended By/ Created By                 : Pradeep
        public void FMUC0073_REG0017()
        {
            try
            {
                Reports.TestStep = "User Story 556817:Editable labels for different considerations/Sale Price on the TDS screen";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Create a file

                Reports.TestStep = "Create a new file with loan";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "Commercial";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
               


                #region Enter values in TDS Screen
                Reports.TestStep = "Enter values in TDS Screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Verify the Total Sales Price lable is displaying";
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                Support.AreEqual("Total Sale Price:", FastDriver.TermsDatesStatus.SalesPriceLabel.FAGetText());

                Reports.TestStep = "Verify the Total Sales Price field is enable";
                Support.AreEqual("True", FastDriver.TermsDatesStatus.SalesPriceAmount.Enabled.ToString());

                 Reports.TestStep = "Verify the Edit SP/OPL button";
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.TermsDatesStatus.Edit_SP_OPL.Exists().ToString());

                Reports.TestStep = "Verify the Sales price/Owner's policy liability dialog";
                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Done is disable";
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                Support.AreEqual("False", FastDriver.DialogBottomFrame.btnDone.Enabled.ToString());

                Reports.TestStep = "Verify the default text in default sales price text fields";
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.WaitForScreenToLoad();
                Support.AreEqual("First Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue());
                Support.AreEqual("Second Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue());
                Support.AreEqual("Third Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue());
                Support.AreEqual("Fourth Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue());
                Support.AreEqual("Fifth Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue());

                Reports.TestStep = "Verify the Boundary values of the sales price text fields";
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("123456789009876543211234567890098765432112345678901");
                Support.AreEqual("12345678900987654321123456789009876543211234567890", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("123456789009876543211234567890098765432112345678901");
                Support.AreEqual("12345678900987654321123456789009876543211234567890", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("123456789009876543211234567890098765432112345678901");
                Support.AreEqual("12345678900987654321123456789009876543211234567890", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("123456789009876543211234567890098765432112345678901");
                Support.AreEqual("12345678900987654321123456789009876543211234567890", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("123456789009876543211234567890098765432112345678901");
                Support.AreEqual("12345678900987654321123456789009876543211234567890", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue());
                
                Reports.TestStep = "Verify the warming messages";
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.WaitForScreenToLoad();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("200");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("!");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText("99999999999999999");
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Please correct invalid data entered.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.WaitForScreenToLoad();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText("9");
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Description can not be blank", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.WaitForScreenToLoad();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("sales2");
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.WaitForScreenToLoad();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("sales3");

                Reports.TestStep = "Verify the Total Sales Price amt";
                Support.AreEqual("5,209.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.TotalSalePrice.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(false,true);
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Total sales prince in TDS screen";
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                Support.AreEqual("5,209.00", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue());

                Reports.TestStep = "Verify the Total Sales Price field is disable";
                Support.AreEqual("False", FastDriver.TermsDatesStatus.SalesPriceAmount.Enabled.ToString());

                Reports.TestStep = "Verify the Edit SP/OPL button color has changed to blue";
                Support.AreEqual("True", FastDriver.TermsDatesStatus.Edit_SP_OPL.GetAttribute("style").Contains("background-color: rgb").ToString());
              
                    #endregion
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

     

        #region Custom Methods
        public void StoreFileNum()
        {
            FastDriver.QuickFileEntry.SwitchToTopFrame();
            string fileNum1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
            
        }

        private void WaitForFastViewScreenToLoad()
        {
            FastDriver.FASTView.SwitchToFastViewContentFrame();
            FastDriver.FASTView.WaitCreation(FastDriver.FASTView.SearchResultTable);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
        public object nextSunday { get; set; }
    }
}