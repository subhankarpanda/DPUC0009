﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace FileManagement
{
    public partial class FPUC0012 : MasterTestClass
    {
        #region REG
        [TestMethod]
        public void FPUC0012_REG0069_70_71()
        {
            try
            {
                Reports.TestDescription = "6593_6594_9765_Precondition_FP11674: Add a successor task and path / 6593_6594_9765_6666_6665: Validate that successor task functionality /  9766: Reset File Workflow Screen Refresh of Successor Tasks.";

                #region Create Process Template for TestCase
                WorkflowProcessTemplateInformation process = CreateNewProcessTemplate_Class3("FPUC0012_REG0069", transactionType: "Short Sale/Cash");
                #endregion

                #region Login & Create File
                this.PerformCommonSteps(ReportName: "11642: Validate event log for failed successor task added.", loginType: "");
                #endregion

                #region Navigate to FWF
                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);
                #endregion

                #region Start a task
                string tableID = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Reports.TestStep = "Start a task " + process.Tasks.First(t => t.Status == "Start").Name;
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.On);
                #endregion

                #region Validate Successor Task is Waived and Completed
                Reports.TestStep = "Validate Successor Task is Waived and Completed";
                Support.AreEqual("False", FastDriver.FileWorkflow.Waivedimage.Exists().ToString().Clean(), "Validating.");
                Support.AreEqual("False", FastDriver.FileWorkflow.Completeimage.Exists().ToString().Clean(), "Validating.");
                #endregion

                #region Click on Apply Button
                Reports.TestStep = "Click on Apply Button.";
                FastDriver.BottomFrame.Apply();
                Playback.Wait(5000);
                #endregion

                #region Click on Event Log
                Reports.TestStep = "Click on Event Log.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();
                #endregion

                #region Validate Process Type and Username
                Reports.TestStep = "Validate Process Type and Username.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual("Workflow", FastDriver.EventTrackingLogDlg.EventCategory.FAGetSelectedItem().Clean(), "Validate that EventCategory is: Workflow");
                string currentDate = DateTime.Today.ToString("M/d/yyyy");
                Support.AreEqual("True", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 2, TableAction.GetText).Message.Contains(currentDate).ToString().Clean(), "Validate");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click on Reset
                FastDriver.BottomFrame.Reset();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FPUC0012_REG0069_70_71, couldn't be completed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0073_74_75_76()
        {
            try
            {
                Reports.TestDescription = "11642_Precondition: Add a process to a successor task / 11642: Validate event log for failed successor task added";

                #region Create Process Template for TestCase
                WorkflowProcessTemplateInformation process = CreateNewProcessTemplate_Class3("FPUC0012_REG0069", transactionType: "Short Sale/Cash");
                #endregion

                #region Login & Create File
                this.PerformCommonSteps(ReportName: "11642: Validate event log for failed successor task added.", loginType: "");
                #endregion

                #region Navigate to FWF
                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);
                #endregion

                #region Start a task
                string tableID = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Reports.TestStep = "Start a task " + process.Tasks.First(t => t.Status == "Start").Name;
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.On);
                #endregion

                #region Validate Successor Task is Waived and Completed
                Reports.TestStep = "Validate Successor Task is Waived and Completed";
                Support.AreEqual("False", FastDriver.FileWorkflow.Waivedimage.Exists().ToString().Clean(), "Validating.");
                Support.AreEqual("False", FastDriver.FileWorkflow.Completeimage.Exists().ToString().Clean(), "Validating.");
                #endregion

                #region Click on Apply Button
                Reports.TestStep = "Click on Apply Button.";
                FastDriver.BottomFrame.Apply();
                Playback.Wait(5000);
                #endregion

                #region Click on Event Log Button
                Reports.TestStep = "Click on Event Log Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();
                #endregion

                #region Validate Process Type and Username
                Reports.TestStep = "Validate Process Type and Username.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual("Workflow", FastDriver.EventTrackingLogDlg.EventCategory.FAGetSelectedItem().Clean(), "Validate that EventCategory is: Workflow");
                string currentDate = DateTime.Today.ToString("M/d/yyyy");
                Support.AreEqual("True", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 2, TableAction.GetText).Message.Contains(currentDate).ToString().Clean(),
                                 "Validating that User column is: today's date.");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FPUC0012_REG0073, couldn't be completed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0078_79()
        {
            try
            {
                Reports.TestDescription = "11641_Precondition: Add a process to successor task / 11641_FP11689_FP11690: Validate event log for successsful successor task added";

                #region Create Process Template for TestCase
                WorkflowProcessTemplateInformation process = CreateNewProcessTemplate_Class3("FPUC0012_REG0078", transactionType: "Short Sale/Cash");
                #endregion

                #region Basic Step
                PerformCommonSteps(ReportName: "", loginType: "ADM");
                #endregion

                #region Navigate to Region Level
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                #endregion

                #region Navigate to Regional Process Summary
                Reports.TestStep = "Navigate to Regional Process Sumary and select a template.";
                FastDriver.RegionalProcessSummary.Open();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, process.Name, 1, TableAction.Click);
                #endregion

                #region Click on Edit Button
                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();
                #endregion
                
                #region Remove Path.
                Reports.TestStep = "Add Successor Path and Task.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, process.Tasks.First(t => t.Status == "Start").Name, 2, TableAction.Click);
                Playback.Wait(500);
                FastDriver.RegionalProcessEdit.ViewEditSuccessors.FAClick();
                FastDriver.SuccessorSetupDlg.WaitForScreenToLoad();
                FastDriver.SuccessorSetupDlg.Remove.FAClick();
                Playback.Wait(500);
                FastDriver.SuccessorSetupDlg.AddPath.FAClick();
                Playback.Wait(500);
                FastDriver.SuccessorSetupDlg.Task1.FASelectItemByIndex(3);
                FastDriver.SuccessorSetupDlg.Status1.FASelectItem("Waive");
                FastDriver.SuccessorSetupDlg.TaskSuccProcessType.FASelectItem("Title Production");
                FastDriver.SuccessorSetupDlg.Done.FAClick();
                #endregion

                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter the Notes
                Reports.TestStep = "Enter the Notes.";
                FastDriver.NotesEntryDlg.WaitForScreenToLoad();
                FastDriver.NotesEntryDlg.Notes.FASetText("Details1.");
                FastDriver.NotesEntryDlg.Done.FAClick();
                #endregion

                #region Select a task and click on Refresh button
                Reports.TestStep = "Select a task click on Refresh button.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(process.Name);
                FastDriver.WebDriver.Quit();
                #endregion

                #region Login & Create File
                this.PerformCommonSteps(ReportName: "11641_FP11689_FP11690: Validate event log for successsful successor task added", loginType: "");
                #endregion

                #region Navigate to FWF
                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);
                #endregion

                #region Start a task
                string tableID = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Reports.TestStep = "Start a task " + process.Tasks.First(t => t.Status == "Start").Name;
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.On);
                #endregion

                #region Click on Apply Button
                Reports.TestStep = "Click on Apply Button.";
                FastDriver.BottomFrame.Apply();
                Playback.Wait(500);
                #endregion

                #region Click on Event Log Button
                Reports.TestStep = "Click on Event Log Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();
                #endregion

                #region Validate Process Type and Username
                Reports.TestStep = "Validate Process Type and Username.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual("Workflow", FastDriver.EventTrackingLogDlg.EventCategory.FAGetSelectedItem().Clean(), "Validate that EventCategory is: Workflow");
                Support.AreEqual("[Successor Process Added]", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(),
                                 "Validating that FirstColumn is: [Successor Process Added]");
                Support.AreEqual("True", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Contains("Process Type: Title Production").ToString().Clean(),
                                 "Verifying that the column Comments has: Description: Process Type: Title Production.");
                FASTHelpers.KeyboardSendKeys("%{F4}");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FPUC0012_REG0078_79, couldn't be completed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0080_81()
        {
            try
            {
                Reports.TestDescription = "11642_Precondition: Add a process to a successor task / 11642: Validate event log for failed successor task added";

                #region Create Process Template for TestCase
                WorkflowProcessTemplateInformation process = CreateNewProcessTemplate_Class3("FPUC0012_REG0078", transactionType: "Short Sale/Cash");
                #endregion

                #region Basic Step
                PerformCommonSteps(ReportName: "", loginType: "ADM");
                #endregion

                #region Navigate to Region Level
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                #endregion

                #region Navigate to Regional Process Summary and select a template.
                Reports.TestStep = "Navigate to Regional Process Sumary and select a template.";
                FastDriver.RegionalProcessSummary.Open();
                #endregion

                #region Navigate to Regional Process Summary
                Reports.TestStep = "Navigate to Regional Process Summary.";
                FastDriver.RegionalProcessSummary.Open();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, process.Name, 1, TableAction.Click);
                #endregion

                #region Click on Edit Button
                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();
                #endregion
                
                #region Remove Path.
                Reports.TestStep = "Add Successor Path and Task.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, process.Tasks.First(t => t.Status == "Start").Name, 2, TableAction.Click);
                Playback.Wait(500);
                FastDriver.RegionalProcessEdit.ViewEditSuccessors.FAClick();
                FastDriver.SuccessorSetupDlg.WaitForScreenToLoad();
                FastDriver.SuccessorSetupDlg.Remove.FAClick();
                Playback.Wait(500);
                FastDriver.SuccessorSetupDlg.AddPath.FAClick();
                Playback.Wait(500);
                FastDriver.SuccessorSetupDlg.Task1.FASelectItemByIndex(1);
                FastDriver.SuccessorSetupDlg.Status1.FASelectItem("Start");
                FastDriver.SuccessorSetupDlg.TaskSuccProcessType.FASelectItem("Cancellation");
                FastDriver.SuccessorSetupDlg.Done.FAClick();
                #endregion

                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter the Notes
                Reports.TestStep = "Enter the Notes.";
                FastDriver.NotesEntryDlg.WaitForScreenToLoad();
                FastDriver.NotesEntryDlg.Notes.FASetText("Details1.");
                FastDriver.NotesEntryDlg.Done.FAClick();
                #endregion

                #region Select a task and click on Refresh button
                Reports.TestStep = "Select a task click on Refresh button.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(process.Name);
                FastDriver.WebDriver.Quit();
                #endregion

                #region Login & Create File
                this.PerformCommonSteps(ReportName: "11641_FP11689_FP11690: Validate event log for successsful successor task added", loginType: "");
                #endregion

                #region Navigate to FWF
                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);
                #endregion

                #region Start a task
                string tableID = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Reports.TestStep = "Start a task " + process.Tasks.First(t => t.Status == "Start").Name;
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableID).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.On);
                #endregion

                #region Click on Apply Button
                Reports.TestStep = "Click on Apply Button.";
                FastDriver.BottomFrame.Apply();
                Playback.Wait(500);
                #endregion

                #region Click on Event Log Button
                Reports.TestStep = "Click on Event Log Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();
                #endregion

                #region Validate for failed successor task
                Reports.TestStep = "Validate for failed successor task.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual("Workflow", FastDriver.EventTrackingLogDlg.EventCategory.FAGetSelectedItem().Clean(), "Validate that EventCategory is: Workflow");
                Support.AreEqual("[Successor Process Failed]", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(),
                                 "Validating that FistColumn is: [Successor Process Failed]");
                Support.AreEqual("True", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Contains("Description: No matching process added for the selected process type.").ToString().Clean(),
                                 "Verifying that the column Comments has: Description: No matching process added for the selected process type.");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 4, TableAction.GetText).Message.Clean(), "Validate that Event column is: FAST Application.");
                Support.AreEqual("", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean(), "Validating that User column is: blank.");
                string currentDate = DateTime.Today.ToString("M/d/yyyy");
                Support.AreEqual("True", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 2, TableAction.GetText).Message.Contains(currentDate).ToString().Clean(),
                                 "Validating that User column is: today's date.");
                FASTHelpers.KeyboardSendKeys("%{F4}");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FPUC0012_REG0080, couldn't be completed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0083_84()
        {
            try
            {
                Reports.TestDescription = "11642_Precondition: Add a process to a successor task / 11642: Validate event log for failed successor task added";

                #region Create Process Template for TestCase
                WorkflowProcessTemplateInformation process = CreateNewProcessTemplate_Class3("FPUC0012_REG0078", transactionType: "Short Sale/Cash");
                #endregion

                #region Basic Step
                PerformCommonSteps(ReportName: "", loginType: "ADM");
                #endregion

                #region Navigate to Region Level
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                #endregion

                #region Navigate to Regional Process Summary and select a template.
                Reports.TestStep = "Navigate to Regional Process Sumary and select a template.";
                FastDriver.RegionalProcessSummary.Open();
                #endregion

                #region Navigate to Regional Process Summary
                Reports.TestStep = "Navigate to Regional Process Summary.";
                FastDriver.RegionalProcessSummary.Open();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, process.Name, 1, TableAction.Click);
                #endregion

                #region Click on Edit Button
                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();
                #endregion

                /* Removing Template Tasks */
                #region Remove All Tasks
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.Remove.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                #endregion

                /* Adding Sanity Tasks */
                #region Import Tasks from Sanity Template
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.Import.FAClick();
                FastDriver.ImportTasksfromProcessTemplateDlg.WaitForScreenToLoad();
                FastDriver.ImportTasksfromProcessTemplateDlg.TemplateTable.PerformTableAction(1, "AUTO_DONOT_TOUCH_StandardTemplateForSanity", 1, TableAction.Click);
                FastDriver.ImportTasksfromProcessTemplateDlg.Select.FAClick();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                #endregion

                #region Making task Inactive & click on Select workgroup
                Reports.TestStep = "Making task Inactive & click on Select workgroup.";
                FastDriver.RegionalProcessEdit.Inactive.FASetCheckbox(true);
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                #endregion

                #region Click on View More
                Reports.TestStep = "Click on View More.";
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
                #endregion

                #region Select the workgroup Accounting.
                Reports.TestStep = "Select the Workgroup Accounting.";
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem("Accounting");
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                #endregion

                #region Select the checkbox
                Reports.TestStep = "Select the checkbox.";
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, "Accounting", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Click on  Select workgroup
                Reports.TestStep = "Click on Select workgroup.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                #endregion

                #region Click on View More
                Reports.TestStep = "Click on View More.";
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
                #endregion

                #region Select the workgroup Accounting.
                Reports.TestStep = "Select the Workgroup Accounting.";
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem("1099");
                FastDriver.WorkGroupSelectionDlg.Select.FAClick();
                #endregion

                #region Select the checkbox
                Reports.TestStep = "Select the checkbox.";
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, "1099", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter the Notes
                Reports.TestStep = "Enter the Notes.";
                FastDriver.NotesEntryDlg.WaitForScreenToLoad();
                FastDriver.NotesEntryDlg.Notes.FASetText("Edited Selection Criteria.");
                FastDriver.NotesEntryDlg.Done.FAClick();
                #endregion

                #region Select a task and click on Refresh button
                Reports.TestStep = "Select a task click on Refresh button.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(process.Name);
                FastDriver.WebDriver.Quit();
                #endregion

                #region Login & Create File
                this.PerformCommonSteps(ReportName: "11641_FP11689_FP11690: Validate event log for successsful successor task added", loginType: "");
                #endregion

                #region Navigate to FWF
                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);
                #endregion

                #region Validate File Workflow Screen and validate Service Removed
                Reports.TestStep = "Validate File Workflow Screen and validate Service Removed.";
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction(1, 2, TableAction.Click);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FPUC0012_REG0083, couldn't be completed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0085_86()
        {
            try
            {
                Reports.TestDescription = "9757_9760_Precondion: Adding multiple  production center. / 9757_9760_9762_9761_6649_EW22: Validate that multiple office are appearing in file workflow";

                #region Create Process Template for TestCase
                WorkflowProcessTemplateInformation process = CreateNewProcessTemplate_Class3("FPUC0012_REG0078", transactionType: "Short Sale/Cash", addSuccessor: false);
                #endregion

                #region Basic Step
                PerformCommonSteps(ReportName: "", loginType: "ADM");
                #endregion

                #region Navigate to Region Level
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                #endregion

                #region Navigate to Regional Process Summary and select a template.
                Reports.TestStep = "Navigate to Regional Process Sumary and select a template.";
                FastDriver.RegionalProcessSummary.Open();
                #endregion

                #region Navigate to Regional Process Summary
                Reports.TestStep = "Navigate to Regional Process Summary.";
                FastDriver.RegionalProcessSummary.Open();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, process.Name, 1, TableAction.Click);
                #endregion

                #region Click on Edit Button
                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();
                #endregion

                #region Remove All Tasks
                Reports.TestStep = "Remove All Tasks.";
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.Remove.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                #endregion

                #region Import Tasks from Sanity Template
                Reports.TestStep = "Adding Sanity Tasks.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.Import.FAClick();
                FastDriver.ImportTasksfromProcessTemplateDlg.WaitForScreenToLoad();
                FastDriver.ImportTasksfromProcessTemplateDlg.TemplateTable.PerformTableAction(1, "AUTO_DONOT_TOUCH_StandardTemplateForSanity", 1, TableAction.Click);
                FastDriver.ImportTasksfromProcessTemplateDlg.Select.FAClick();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                #endregion

                #region Click on Inactive Checkbox
                Reports.TestStep = "Click on Inactive Checkbox";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.Inactive.FAClick();
                #endregion

                #region Select task office as Production center and click on production button
                Reports.TestStep = "Select task office as Production center and click on production button";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskOffice.FASelectItem("Production Center");
                FastDriver.RegionalProcessEdit.ProdCentreEllipse.FAClick();
                #endregion

                #region Select first and second center
                Reports.TestStep = "Select first and second center.";
                FastDriver.SelectProductionCentersWebpageDialogDlg.WaitForScreenToLoad();
                FastDriver.SelectProductionCentersWebpageDialogDlg.SelectProductionCentersTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.SelectProductionCentersWebpageDialogDlg.SelectProductionCentersTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter the Notes
                Reports.TestStep = "Enter the Notes.";
                FastDriver.NotesEntryDlg.WaitForScreenToLoad();
                FastDriver.NotesEntryDlg.Notes.FASetText("Details1.");
                FastDriver.NotesEntryDlg.Done.FAClick();
                #endregion

                #region Select a task and click on Refresh button
                Reports.TestStep = "Select a task click on Refresh button.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(process.Name);
                FastDriver.WebDriver.Quit();
                #endregion

                #region Login & Create File
                this.PerformCommonSteps(ReportName: "11641_FP11689_FP11690: Validate event log for successsful successor task added", loginType: "");
                #endregion

                #region Navigate to FWF
                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);
                #endregion

                #region Validate that multiple task office appears
                Playback.Wait(2000);
                Reports.TestStep = "Validate that multiple task office appears.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                string taskOffice = FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "ADEC-ITI-BILL-FULL", 6, TableAction.GetText).Message;
                Reports.StatusUpdate("Task office: " + taskOffice, true);
                Support.AreEqual("True", taskOffice.Contains("Multiple").ToString().Clean(), "Validating value: Multiple.");
                #endregion

                #region Click on Task Office button
                Reports.TestStep = "Click on Task Office button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "ADEC-ITI-BILL-FULL", 7, TableAction.Click);
                #endregion

                #region Select the Task Office
                Reports.TestStep = "Select the Task Office.";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.PerformTableAction(1, "Escrow Owning", 1, TableAction.Click);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();
                #endregion

                #region Highlight the Started Task
                Reports.TestStep = "Highlight the Started Task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "ADEC-ITI-BILL-FULL", 5, TableAction.Click);
                #endregion

                #region Click on Details Button
                Reports.TestStep = "Click on Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();
                #endregion

                #region Click on Manual Activation Button
                Reports.TestStep = "Click on Manual Activation Button.";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.ManualActivation.FAClick();
                #endregion

                #region Validate Message for Manual Activation
                Reports.TestStep = "Validate Message for Manual Activation.";
                Support.AreEqual("Please complete your selection of Task Office in order to activate this task.", FastDriver.WebDriver.HandleDialogMessage(), "Validating Message");
                #endregion

                #region Select a Workgroup
                Reports.TestStep = "Select a Workgroup";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.TaskOffice.FAClick();
                FastDriver.TaskDetails.Workgroup.FAClick();
                #endregion

                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.TaskDetails.ManualActivation.FAClick();
                #endregion

                #region Complete first task
                Reports.TestStep = "Complete first task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Process.PerformTableAction(5, "ADEC-ITI-BILL-FULL", 2, TableAction.On);
                FastDriver.BottomFrame.Apply();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FPUC0012_REG0085, couldn't be completed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0087()
        {
            try
            {
                Reports.TestDescription = "FP11696: For a task, Task Event Status and Trigger Status cannot be same";

                #region Create Process Template for TestCase
                WorkflowProcessTemplateInformation Process = CreateNewProcessTemplate_Class3("FPUC0012_REG0069", transactionType: "Short Sale/Cash");
                #endregion

                #region Basic Step
                PerformCommonSteps(ReportName: "", loginType: "ADM");
                #endregion

                #region Navigate to Region Level
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                #endregion

                #region Navigate to Regional Process Summary and select a template.
                Reports.TestStep = "Navigate to Regional Process Sumarry and select a template.";
                FastDriver.RegionalProcessSummary.Open();
                #endregion

                #region Navigate to Regional Process Summary
                Reports.TestStep = "Navigate to Regional Process Summary.";
                FastDriver.RegionalProcessSummary.Open();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, Process.Name, 1, TableAction.Click);
                #endregion

                #region Click on Edit Button
                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();
                #endregion

                #region Enter Trigger State and tas state as same
                Reports.TestStep = "Enter Trigger State and tas state as same.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TiggerStatus.FASelectItem("Complete");
                FastDriver.RegionalProcessEdit.TaskEventAction.FASelectItem("Complete");
                Playback.Wait(1000);
                #endregion

                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                #region When trigger state and task state is same
                Reports.TestStep = "When trigger state and task state is same";
                Support.AreEqual("Trigger Status and Task Event Action cannot be the same.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false), "Validating the message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FPUC0012_REG0087, couldn't be completed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0091_92_93()
        {
            try
            {
                Reports.TestDescription = "9757_9760_Postcondition: Make directing status as blank and remove production center.";

                #region Create Process Template for TestCase
                WorkflowProcessTemplateInformation Process = CreateNewProcessTemplate_Class3("FPUC0012_REG0069", transactionType: "Short Sale/Cash");
                #endregion

                #region Basic Step
                PerformCommonSteps(ReportName: "", loginType: "ADM");
                #endregion

                #region Navigate to Region Level
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");
                #endregion

                #region Navigate to Regional Process Summary and select a template.
                Reports.TestStep = "Navigate to Regional Process Sumarry and select a template.";
                FastDriver.RegionalProcessSummary.Open();
                #endregion

                #region Navigate to Regional Process Summary
                Reports.TestStep = "Navigate to Regional Process Summary.";
                FastDriver.RegionalProcessSummary.Open();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, Process.Name, 1, TableAction.Click);
                #endregion

                #region Click on Edit Button
                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();
                #endregion

                //Changing To Production Center so, the message can appear on change to Escrow Office:
                #region Select task office as Production center and click on production button
                Reports.TestStep = "Select task office as Production center and click on production button";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskOffice.FASelectItem("Production Center");
                FastDriver.RegionalProcessEdit.ProdCentreEllipse.FAClick();
                #endregion

                #region Select first and second center
                Reports.TestStep = "Select first center.";
                FastDriver.SelectProductionCentersWebpageDialogDlg.WaitForScreenToLoad();
                FastDriver.SelectProductionCentersWebpageDialogDlg.SelectProductionCentersTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Click on Done
                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter the Notes
                Reports.TestStep = "Enter the Notes.";
                FastDriver.NotesEntryDlg.WaitForScreenToLoad();
                FastDriver.NotesEntryDlg.Notes.FASetText("Details1.");
                FastDriver.NotesEntryDlg.Done.FAClick();
                #endregion

                #region Select a task and click on Refresh button
                Reports.TestStep = "Select a task click on Refresh button.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(Process.Name);
                #endregion

                #region Navigate to Regional Process Summary and select a template.
                Reports.TestStep = "Navigate to Regional Process Sumarry and select a template.";
                FastDriver.RegionalProcessSummary.Open();
                #endregion

                #region Navigate to Regional Process Summary
                Reports.TestStep = "Navigate to Regional Process Summary.";
                FastDriver.RegionalProcessSummary.Open();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, Process.Name, 1, TableAction.Click);
                #endregion

                #region Click on Edit Button
                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.Edit.FAClick();
                #endregion

                //Back to the test case
                #region Select Task Office: Escrow Owning Office.
                Reports.TestStep = "Select Task Office: Escrow Owning Office.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskOffice.FASelectItem("Escrow Owning Office");
                Support.AreEqual("Changing the Task Office will remove the Production Center Selections. Do you want to proceed?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Validating message.");
                #endregion

                #region Clicl on Workgroup
                Reports.TestStep = "Click on Workgroup";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                #endregion

                #region Deselect 2 Groups
                Reports.TestStep = "Deselect 2 Groups.";
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(1, 1, TableAction.Off);
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, 1, TableAction.Off);
                //sssFastDriver.WorkgroupSelectDlg.SelGrp.FASetCheckbox(false);
                //FastDriver.WorkgroupSelectDlg.SelGrp2.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Selecting 2nd directing status blank
                Reports.TestStep = "Selecting 2nd directing status blank";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.Directingstatus.FASelectItemByIndex(0);
                #endregion

                #region Uncheck inactive Checkbox
                Reports.TestStep = "Uncheck inactive Checkbox.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.Inactive.FASetCheckbox(false);
                #endregion

                #region Select a Task
                Reports.TestStep = "Select a task.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, Process.Tasks.First(t => t.Status == "Start").Name, 2, TableAction.Click);
                Playback.Wait(1000);
                #endregion

                #region Click on Workgroup
                Reports.TestStep = "Click on Workgroup";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                #endregion

                #region Uncheck first checkbox
                Reports.TestStep = "Uncheck first checkbox.";
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(1, 1, TableAction.Off);
                #endregion

                #region Click on Done in Dialog Box
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Select a Task
                Reports.TestStep = "Select a task.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, Process.Tasks.First(t => t.Status == "Complete").Name, 2, TableAction.Click);
                Playback.Wait(1000);
                #endregion

                #region Click on Workgroup
                Reports.TestStep = "Click on Workgroup";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                #endregion

                #region Uncheck first checkbox
                Reports.TestStep = "Uncheck first checkbox.";
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(1, 1, TableAction.Off);
                #endregion

                #region Click on Done in a Dialog Box
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Validate the presence of Elegible Priority Process checkbox
                Reports.TestStep = "Validate the presence of Eligible Priority process checkbox.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
                #endregion

                #region Click on Add/Remove button for Process Event Selection
                Reports.TestStep = "Click on Add/Remove button for Process Event Selection.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
                Playback.Wait(1000);
                #endregion

                #region Unselect the Home/Warranty Process
                Reports.TestStep = "Unselect the HomeWarranty Process.";
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProcessEventSelectionDlg.HomeWarranty.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Click on Done
                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter the Notes
                Reports.TestStep = "Enter the Notes.";
                FastDriver.NotesEntryDlg.WaitForScreenToLoad();
                FastDriver.NotesEntryDlg.Notes.FASetText("Details1.");
                FastDriver.NotesEntryDlg.Done.FAClick();
                #endregion

                #region Select a task and click on Refresh button
                Reports.TestStep = "Select a task click on Refresh button.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(Process.Name);
                FastDriver.WebDriver.Quit();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FPUC0012_REG0091, couldn't be completed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0095_96_97_98_99()
        {
            try
            {
                #region Login & Create File
                this.PerformCommonSteps(ReportName: "FD: / FD_Specificbutton_EW3: Validate the specific button / FD_Specificbutton_1: validate hotkey action for task template selecion dialog /FD_Fileworkflowscreen: Validate the fielddefination for fileworkflow screen /FD_Taskcomment: Task Comment Edit Dialog Box ", loginType: "");
                #endregion

                #region Navigate to FWF
                Reports.TestStep = "Navigate to FWF.";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                Playback.Wait(2000);
                #endregion

                Reports.TestStep = "Validate the hotkey action for event log.";
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.Exists().ToString().Clean(), "Validate that the button exists.");
                FASTHelpers.KeyboardSendKeys("%V");

                Reports.TestStep = "Click on Done in Dialog Box";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the hotkey action for file info";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.Exists().ToString().Clean(), "Validate that the button exists.");
                FASTHelpers.KeyboardSendKeys("%I");

                Reports.TestStep = "Click on Continue.";
                FastDriver.FileSummaryDlg.WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.FileSummaryDlg.Continue.FAClick();

                Reports.TestStep = "Validate the hotkey action for Add process.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.Exists().ToString().Clean(), "Validate that the button exists.");
                FASTHelpers.KeyboardSendKeys("%P");

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Highlight the completed task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Process.PerformTableAction(4, 5, TableAction.Click);

                Reports.TestStep = "Validate the hotkey action for U button";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.Exists().ToString().Clean(), "Validate that the button exists.");
                FASTHelpers.KeyboardSendKeys("%U");

                Reports.TestStep = "Highlight the started task.";
                FastDriver.FileWorkflow.Process.PerformTableAction(4, 5, TableAction.Click);

                Reports.TestStep = "Validate the hotkey action for Down button.";
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.Exists().ToString().Clean(), "Validate that the button exists.");
                FASTHelpers.KeyboardSendKeys("%W");

                Reports.TestStep = "Hightlight the completed task.";
                FastDriver.FileWorkflow.Process.PerformTableAction(4, 5, TableAction.Click);

                Reports.TestStep = "Validate the hotkey action for Add task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.Exists().ToString().Clean(), "Validate that the button exists.");
                FASTHelpers.KeyboardSendKeys("%A");

                Reports.TestStep = "Click on Cancel";
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                Playback.Wait(3000);
                FASTHelpers.KeyboardSendKeys("^Q");

                Reports.TestStep = "Validate the hotkey action for New task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.Exists().ToString().Clean(), "Validate that the button exists.");
                FASTHelpers.KeyboardSendKeys("%N");
                FASTHelpers.KeyboardSendKeys("{TAB}");

                Reports.TestStep = "Validate the hotkey action for Remove task.";
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.Exists().ToString().Clean(), "Validate that the button exists.");
                FASTHelpers.KeyboardSendKeys("%R");

                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Select view more office in assigned to list.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Process.PerformTableAction(1, 11, TableAction.Click);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.SelAssgTo.FASelectItem("++View Offices...");

                Reports.TestStep = "Validate the Hotkey action for Select.";
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                Playback.Wait(1000);
                FASTHelpers.KeyboardSendKeys("%S");

                Reports.TestStep = "Validate message for selection of employee office.";
                Support.AreEqual("Error: No Employee was selected.", FastDriver.WebDriver.HandleDialogMessage(), "Validating the message.");

                Reports.TestStep = "Validate the hotkey action for Cancel.";
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("%C");

                Reports.TestStep = "Click on Add Process Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                Playback.Wait(1000);
                FastDriver.FileWorkflow.AddProcess.FAClick();

                Reports.TestStep = "Select the Process";
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, "Title Production", 1, TableAction.Click);
                FASTHelpers.KeyboardSendKeys("^D");

                Reports.TestStep = "Highlight the started task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Process.PerformTableAction(1, 5, TableAction.Click);

                Reports.TestStep = "Click on Add Task Button";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Validate hotkey action for select task.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                Playback.Wait(4000);
                FASTHelpers.KeyboardSendKeys("%S");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate hotkey action for check all.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                Playback.Wait(4000);
                FASTHelpers.KeyboardSendKeys("%A");

                Reports.TestStep = "Validate hotkey action for cancel button.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                Playback.Wait(4000);
                FASTHelpers.KeyboardSendKeys("%C");

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Validate hotkey action for cancel button.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                Playback.Wait(4000);
                FASTHelpers.KeyboardSendKeys("%M");

                Reports.TestStep = "Validate Exact";
                FastDriver.AddNewMiscellaneousTaskDlg.WaitForScreenToLoad();
                FastDriver.AddNewMiscellaneousTaskDlg.Name.FASetText("enter 25 maximum of text validate the content 32689545");
                Support.AreEqual("enter 25 maximum of text validate the content 32689545", FastDriver.AddNewMiscellaneousTaskDlg.Name.FAGetValue().Clean(), "Validating the message.");
                FastDriver.AddNewMiscellaneousTaskDlg.Done.FAClick();

                Reports.TestStep = "Check the collapse checkbox and check active only checkbox validate the process category";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.IsDisplayed().ToString().Clean(), "Validating that button exists.");
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(true);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("All|Open Order|Title|Escrow|EPIC|Post Closing", FastDriver.FileWorkflow.ProcessCategory.FAGetAllTextFromSelect().ToString().Clean(), "Validating select content.");
                FastDriver.FileWorkflow.HideWaive.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Waive.FASetCheckbox(true);

                Reports.TestStep = "Uncheck the checkboxes.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileWorkflow.EventLog.Exists().ToString().Clean(), "Validate that the button exists.");
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("All|Open Order|Title|Escrow|EPIC|Post Closing", FastDriver.FileWorkflow.ProcessCategory.FAGetAllTextFromSelect().ToString().Clean(), "Validating select content.");
                FastDriver.FileWorkflow.HideWaive.FASetCheckbox(true);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                //FastDriver.FileWorkflow.Waive.FASetCheckbox(false);

                Reports.TestStep = "Click on Task Comment button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Process1.PerformTableAction(1, 12, TableAction.Click);

                Reports.TestStep = "Validate upper boundary of task comment.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534");
                Support.AreEqual("test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534",
                    FastDriver.TaskCommentEditDlg.InternalComment.FAGetValue().Clean(), "Validating content of Internal Comment.");
                FastDriver.TaskCommentEditDlg.Comment.FASetText("test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534");
                Support.AreEqual("test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534",
                    FastDriver.TaskCommentEditDlg.InternalComment.FAGetValue().Clean(), "Validating content of Internal Comment.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Delete the comment.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.Comment.FASetText(" ");

                Reports.TestStep = "Validate for lower boundary";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound");
                Support.AreEqual("test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound",
                    FastDriver.TaskCommentEditDlg.InternalComment.FAGetValue().Clean(), "Validating content of Internal Comment.");
                FastDriver.TaskCommentEditDlg.Comment.FASetText("test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534");
                Support.AreEqual("test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound 1348723573457349534934953453475344534534 test comment upper bound",
                    FastDriver.TaskCommentEditDlg.InternalComment.FAGetValue().Clean(), "Validating content of Internal Comment.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                //Reports.TestStep = "Click on Reset";
                //FastDriver.BottomFrame.Reset();
            }
            catch (Exception ex)
            {
                FailTest("The test FPUC0012_REG0095, couldn't be completed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0100()
        {
            //Combined: FPUC0012_BAT0100; FPUC0012_REG0101

            try
            {
                Reports.TestDescription = "FD_Reminder: Validate field defination for alerts and reminder; FD: Collapse All check box";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyUserName = "QA07, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();

                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All and Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Click on new button";
                FastDriver.FileWorkflow.New.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.PendingReminderTable);

                Reports.TestStep = "Validate the filed defination for visibility, Creator, and Notify date and note";
                Support.AreEqual("Reminder", FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 1, TableAction.GetSelectedItem).Message, "Visibility");
                Support.AreEqual(MyUserNameFormatted, FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 2, TableAction.GetText).Message, "Creator");
                Support.AreEqual(string.Empty, FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message, "Notify Date");
                Support.AreEqual(string.Empty, FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean(), "Note");

                Reports.TestStep = "Enter Notify Date and Note, click Apply button";
                string noteText = "enter 255 characters in note enter 255 characters in note enter 255 characters in note enter 255 characters in note enter 255 characters in note enter 255 characters in noteenter 255 characters in note enter 255 characters in note enter 255 character 432e";
                FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 3, TableAction.SetText, DateTime.Now.AddDays(2).ToDateString());
                FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 4, TableAction.SetText, noteText);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Validate the filed defination for visibility, Creator, and Notify date and note";
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.PendingReminderTable);
                Support.AreEqual("Reminder", FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 1, TableAction.GetSelectedItem).Message, "Visibility");
                Support.AreEqual(MyUserNameFormatted, FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 2, TableAction.GetText).Message, "Creator");
                Support.AreEqual(DateTime.Now.AddDays(2).ToDateString(), FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message, "Notify Date");
                Support.AreEqual(noteText, FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 4, TableAction.GetText).Message, "Note");

                Reports.TestStep = "Enter more than 255 characters in note field, validate error message";
                string invalidNoteText = "enter 255 characters in note enter 255 characters in note enter 255 characters in note enter 255 characters in note enter 255 characters in note enter 255 characters in noteenter 255 characters in note enter 255 characters in note enter 255 character 432echaracters in note enter 255 characters in noteenter 255 characters in note enter 255 characters in note enter 255 character ";
                FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 4, TableAction.SetText, invalidNoteText);
                FastDriver.BottomFrame.Apply();
                Support.AreEqual("Warning! Reminder Note was truncated to 255 characters", FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true).Clean());

                Reports.TestStep = "Validate note is actually truncated";
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.PendingReminderTable);
                Support.AreEqual(noteText, FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, 4, TableAction.GetText).Message, "Note");

                #region Verify that system will not expand waived process

                Reports.TestStep = "Waived a process, validate waived process is not expanded";
                FastDriver.FileWorkflow.Open();

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    Thread.Sleep(5000);
                    FastDriver.FileWorkflow.Open();

                    return FastDriver.FileWorkflow.CheckIfProcessIsPulled(MyProcessName);
                }, 30);

                FastDriver.FileWorkflow.CheckPriorityWaive_Process(MyProcessName, checkPriority: false, checkWaive: true);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.Open();
                Support.AreEqual(true, FastDriver.FileWorkflow.IsProcessCollapsed(MyProcessName), "Process is not expanded");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        [TestMethod]
        public void FPUC0012_REG0101()
        {
            //Combined: FPUC0012_BAT0102; FPUC0012_REG0103; FPUC0012_REG0104; FPUC0012_REG0105; FPUC0012_REG0106; FPUC0012_REG0107; FPUC0012_REG0109

            try
            {
                Reports.TestDescription = "FP14227: Flag a Process as Priority Process; FP14227_FD: Check the priority check Box";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyUserName = "QA07, FAST";
                string MyUserNameFormatted = MyUserName.Split(',')[1].Trim() + " " + MyUserName.Split(',')[0].Trim();
                string MyPriorityProcessName = "AUTO_DONOTTOUCH_Template Setup Maintenan";

                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All and Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Check the priority checkbox, validate the Priority checkbox is checked";
                FastDriver.FileWorkflow.CheckPriorityWaive_Process(MyPriorityProcessName, checkPriority: true, checkWaive: false);
                Support.AreEqual(true, FastDriver.FileWorkflow.IsPriorityProcessChecked(MyPriorityProcessName), "Priority Process Checked");

                Reports.TestStep = "Validate the priority checkbox is not available for process: " + MyProcessName;
                Support.AreEqual(false, FastDriver.FileWorkflow.IsPriorityProcess(MyProcessName), "Priority Process Is not Available");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        [TestMethod]
        public void FPUC0012_REG0102()
        {
            //Combined: FPUC0012_REG0111; FPUC0012_REG0112; FPUC0012_REG0113

            try
            {
                Reports.TestDescription = "FP11640: Event Log for manual Add Process Failure; FP11641: Event Log for adding successor process; FP11641: Event Log for adding successor process";

                #region data setup
                string MyActiveTask = "ADEC-ITI-BILL-FULL";
                string MyInactiveTask = "ADEC-ITI-BILL-FULL-SP";
                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = @"Navigate to Properties/Tax Info screen and change the to California address";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "1", 1, TableAction.DoubleClick);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "Santa Ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Click Add Process button";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.AddProcess.FAClick();

                Reports.TestStep = "Add 'Title Production' process to the file";
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, "Activity Log", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Validate the successor task is inactive";
                Support.AreEqual(true, FastDriver.FileWorkflow.IsTaskDisabled(MyInactiveTask), "Task is inactive");

                Reports.TestStep = "Start the first task, validate the successor task is activated";
                FastDriver.FileWorkflow.PeformActionOnTask(MyActiveTask, TableAction.On, 1);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.FileWorkflow.IsTaskDisabled(MyInactiveTask), "Task is active");

                Reports.TestStep = "Click Event Log button, validate event logs";
                FastDriver.FileWorkflow.EventLog.FAClick();
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.AreEqual(@"Task: " + MyInactiveTask, FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Task Auto Activated]", 5, TableAction.GetText).Message.Clean(), "[Task Auto Activated]");
                Support.AreEqual(@"Description: No matching process added for the selected process type. Process Type: Activity Log", FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, "[Manual Process Failed]", 5, TableAction.GetText).Message.Clean(), "[Manual Process Failed]");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        [TestMethod]
        public void FPUC0012_REG0103()
        {
            //Combined: FPUC0012_REG0114, FPUC0012_REG0115

            try
            {
                Reports.TestDescription = "FP8939: Display Processes as Collapsed; FP14228: Priority Flag for Completed and Waived Processes";

                #region data setup

                PropertyAddressParameters MyGoodAddr = new PropertyAddressParameters()
                {
                    StreetLine1 = "123 First Street",
                    State = "CA",
                    County = "AMADOR",
                    City = "AMADOR CITY"
                };

                string MyProcessName = "AUTO_DONOTTOUCH_FPUC0012_TASKS";
                string MyProcessName2 = "AUTO_DONOTTOUCH_Template Setup Maintenan";
                string MyProcessType = "1099";
                string MyTaskName1 = "Start Task When Deliver Document";
                string MyTaskName2 = "Task 2";
                string MyTaskName3 = "Task 3";
                string MyTaskName4 = "Task Inactive";
                #endregion

                #region Validate if process exist on ADM, if not create it

                Reports.TestStep = "Log into ADM site";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary screen; check if process exist, if not create it";
                FastDriver.RegionalProcessSummary.Open();

                if (!FastDriver.RegionalProcessSummary.CheckAvailabilityOfProcess(MyProcessName, MyProcessType))
                    this.CreateNewProcessAndTasks(processName: MyProcessName, taskName: MyTaskName1, taskEvent: true);
                else
                    FastDriver.WebDriver.Quit();

                #endregion

                Reports.TestStep = "Log into FAST application.";
                this.LoginFastFileSite();

                Reports.TestStep = "Create a file using the web service";
                string FileNumber = this.CreateBasicFileWithSpecifiedGABAndAddress(MyGoodAddr);

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Collapse All & Active Only checkboxes";
                FastDriver.FileWorkflow.Open();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                Reports.TestStep = "Manually activate " + MyTaskName4;
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName4, TableAction.Click, 5);
                FastDriver.FileWorkflow.Details.FAClick();
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad();
                FastDriver.TaskDetailsDlg.WorkGroupTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.TaskDetailsDlg.ManualActivation.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Commplete all tasks under process " + MyProcessName;
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName1, TableAction.On, 2);
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName2, TableAction.On, 2);
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName3, TableAction.On, 2);
                FastDriver.FileWorkflow.PeformActionOnTask(MyTaskName4, TableAction.On, 2);

                Reports.TestStep = "Waive process " + MyProcessName2;
                FastDriver.FileWorkflow.CheckPriorityWaive_Process(MyProcessName2, checkPriority: false, checkWaive: true);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);

                Reports.TestStep = "Validate both processes are collapsed";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Open();
                Support.AreEqual(true, FastDriver.FileWorkflow.IsProcessCollapsed(MyProcessName), "Process is collapsed " + MyProcessName);
                Support.AreEqual(true, FastDriver.FileWorkflow.IsProcessCollapsed(MyProcessName2), "Process is collapsed " + MyProcessName2);

                Reports.TestStep = "The priority process checkbox is disabled for waived process";
                Support.AreEqual(false, FastDriver.FileWorkflow.IsPriorityProcessEnabled(MyProcessName), "Priority checkbox is disabled " + MyProcessName);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region Private Mehtods
        private void Login(string Description = "", string Type = "", bool IsInitialStep = true)
        {
            if (IsInitialStep)
            {
                Reports.TestDescription = Description;
            }

            Reports.TestStep = "Login FAST application";

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            if (Type.Equals("ADM"))
            {
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            }
            else
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
        }

        private void CreatingFileForTemplate()
        {
            try
            {
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "YOLO";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "YOLO";
                fileRequest.File.NewLoan.LiabilityAmount = 5000;
                fileRequest.File.SalesPriceAmount = 5000;
                fileRequest.File.NewLoan.NewLoanAmount = 5000;
                fileRequest.File.BusinessSegmentObjectCD = FASTWCFHelpers.DataObjects.BusinessSegmentOCD.Residential;
                fileRequest.File.TransactionTypeObjectCD = FASTWCFHelpers.DataObjects.TransactionTypeOCD.ShortSaleCash;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DIRECTEDBY"
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "NEWLDR"
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                        RoleTypeObjectCD = "ASSOTDPTY"
                    }
                };

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
            }
            catch (Exception e)
            {
                throw new Exception("Creating file with WebService Failed. " + e.Message.ToString());
            }
        }

        private void PerformCommonSteps(string ReportName, string loginType = "", bool emptyCache = false, bool UseDefaultCreateFileMethod = true, int SalesPriceValue = 260000)
        {
            #region Login
            this.Login(ReportName, loginType);
            #endregion

            #region BaseState
            if (emptyCache)
            {
                Reports.TestStep = "Deleting Cache";
                Support.DeleteCacheCookies();
            }
            #endregion

            #region Quick File Entry
            if (loginType != "ADM")
            {
                CreatingFileForTemplate();
            }
            #endregion
        }

        private WorkflowProcessTemplateInformation CreateNewProcessTemplate_Class3(string testCaseName, string transactionType, bool addSuccessor = true, bool addTaskEvents = false)
        {
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            var processTemplate = new WorkflowProcessTemplateInformation
            {
                Type = "1099",
                Name = "FPUC0012_" + Support.RandomString("AAZNZNNA"),
                WorkGroupName = "Accounting",
                Tasks = new List<WorkflowProcessTask>()
            };
            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "FPUC0012_TASK_Start", Status = "Start" });
            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "FPUC0012_TASK_Complete", Status = "Complete" });
            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "FPUC0012_TASK_Waive", Status = "Waive" });
            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "FPUC0012_TASK_Inactive", Status = "Inactive" });

            Reports.TestStep = "Create new template";
            Reports.StatusUpdate("Creating new template", true);

            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            Reports.TestStep = "Navigate to Region Level.";
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID("1486");
            FastDriver.HomePage.WaitForHomeScreen();

            Reports.TestStep = "Navigate to Regional Process Summary.";
            FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.New.FAClick();

            Reports.TestStep = "Enter Process basic info.";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.ProcessType.FASelectItem(processTemplate.Type);
            FastDriver.RegionalProcessEdit.ProcessName.FASetText(processTemplate.Name);
            FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
            FastDriver.RegionalProcessEdit.Description.FASetText("Selenium001");

            Reports.TestStep = "Enter process template selection criteria.";
            FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.TranType.FASelectItem(transactionType);
            FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();
            FastDriver.StateSelectionDlg.WaitForScreenToLoad();
            FastDriver.StateSelectionDlg.Clear.FAClick();
            FastDriver.StateSelectionDlg.table.PerformTableAction(2, "CA", 1, TableAction.On);
            FastDriver.StateSelectionDlg.Select.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();
            FastDriver.CountySelectionDlg.WaitForScreenToLoad();
            FastDriver.CountySelectionDlg.Clear.FAClick();
            FastDriver.CountySelectionDlg.Table.PerformTableAction(2, "YOLO", 1, TableAction.On);
            FastDriver.CountySelectionDlg.Select.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.AddRemoveCity.FAClick();
            FastDriver.CitySelectionDlg.WaitForScreenToLoad();
            FastDriver.CitySelectionDlg.Clear.FAClick();
            FastDriver.CitySelectionDlg.CityTable.PerformTableAction(2, "YOLO", 1, TableAction.On);
            FastDriver.CitySelectionDlg.Select.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.Done.FAClick();

            Reports.TestStep = "Enter process event selection criteria.";

            Reports.TestStep = "Enter process template tasks.";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
            FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
            FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "File created with Open status", 1, TableAction.On);
            FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "Home Warranty", 1, TableAction.On);
            FastDriver.DialogBottomFrame.ClickDone();

            Reports.TestStep = "Enter process template tasks.";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.Add.FAClick();
            FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
            foreach (var task in processTemplate.Tasks)
            {
                if (FastDriver.TaskTemplateSelectionDlg.TasksForTable.FAGetText().Contains(task.Name))
                {
                    //if the task already exists add it to the template
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, task.Name, 5, TableAction.SelectItem, "Yes");
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, task.Name, 4, TableAction.SetText, task.Name);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, task.Name, 2, TableAction.On);
                }
                else
                {
                    //if the task doesn't exist, create it and add it
                    int rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                    FastDriver.TaskTemplateSelectionDlg.New.FAClick();
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        //continue when new row is added
                        return rowCount < FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                    }, timeout: 20, idleInterval: 2);
                    rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();//get last row count to add new task info

                    Reports.TestStep = "Add info for new task.";//add new tasks using static task name
                    FastDriver.TaskTemplateSelectionDlg.WaitCreation(FastDriver.TaskTemplateSelectionDlg.TasksForTable);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 3, TableAction.SetText, task.Name);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 5, TableAction.SelectItem, "Yes");
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 4, TableAction.SetText, task.Name);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 2, TableAction.On);
                }
            }
            FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();

            Reports.TestStep = "Edit added tasks.";
            foreach (var task in processTemplate.Tasks)
            {
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, task.Name, 2, TableAction.Click);

                Reports.TestStep = "Add a workgroup";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem(processTemplate.WorkGroupName);
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, processTemplate.WorkGroupName, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                if (addSuccessor && task.Status == "Start")
                {
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.Directingstatus1.FASelectItem(task.Status);
                    FastDriver.RegionalProcessEdit.ViewEditSuccessors1.FAClick();

                    Reports.TestStep = "Add a successor task and path";
                    FastDriver.SuccessorSetupDlg.WaitForScreenToLoad();
                    FastDriver.SuccessorSetupDlg.AddTask.FAClick();
                    Playback.Wait(250);
                    FastDriver.SuccessorSetupDlg.TaskDetailsTable.PerformTableAction(1, 1, TableAction.SelectItemByIndex, "2");
                    FastDriver.SuccessorSetupDlg.TaskDetailsTable.PerformTableAction(1, 2, TableAction.SelectItem, "Waive");
                    FastDriver.SuccessorSetupDlg.TaskDetailsTable.PerformTableAction(2, 1, TableAction.SelectItemByIndex, "0");
                    FastDriver.SuccessorSetupDlg.TaskDetailsTable.PerformTableAction(2, 2, TableAction.SelectItem, "Complete");
                    FastDriver.SuccessorSetupDlg.Done.FAClick();
                }

                if (addTaskEvents)
                {
                    Reports.TestStep = "Give the Task Event details";
                    if (task.Status == "Start" || task.Status == "Complete")
                    {
                        FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                        FastDriver.RegionalProcessEdit.Directingstatus1.FASelectItemByIndex(0);
                        FastDriver.RegionalProcessEdit.TaskEventAction.FASelectItem("Start");
                        Playback.Wait(250);
                        FastDriver.RegionalProcessEdit.SelTaskEvent.FASelectItem("Document Delivered");
                        FastDriver.RegionalProcessEdit.TaskEventSetup.FAClick();

                        Reports.TestStep = "Select the Email delivery option";
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.WaitForScreenToLoad();
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.DeliveryMethods.FASelectItem("EMAIL");
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.Add.FAClick();

                        Reports.TestStep = "Select the Template type and find the docs.";
                        FastDriver.DocumentDeliverySelectionDlg.WaitForScreenToLoad();
                        FastDriver.DocumentDeliverySelectionDlg.TemplateType.FASelectItem("Endorsement/Guarantee");
                        FastDriver.DocumentDeliverySelectionDlg.State.FASelectItem("CA");
                        FastDriver.DocumentDeliverySelectionDlg.TemplateDescription.FASetText("ALTA Endorsement 10-06 (Assignment)-N");
                        FastDriver.DocumentDeliverySelectionDlg.FindNow.FAClick();
                        Playback.Wait(500);
                        FastDriver.DocumentDeliverySelectionDlg.SearchResultsTable.PerformTableAction(3, "ALTA Endorsement 10-06 (Assignment)-N", 1, TableAction.On);
                        FastDriver.DocumentDeliverySelectionDlg.SelectTemplates.FAClick();
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.WaitForScreenToLoad();
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.Done.FAClick();
                    }
                    if (task.Status == "Waive")
                    {
                        //FastDriver.RegionalProcessEdit.Directingstatus1.FASelectItemByIndex(0);
                        FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                        FastDriver.RegionalProcessEdit.TaskEventAction.FASelectItem("Waive");
                        Playback.Wait(250);
                        FastDriver.RegionalProcessEdit.SelTaskEvent.FASelectItem("Field Changed");
                        FastDriver.RegionalProcessEdit.TaskEventSetup.FAClick();

                        Reports.TestStep = "Select task event";
                        FastDriver.FieldChangedTaskEventSetupDlg.WaitForScreenToLoad();
                        FastDriver.FieldChangedTaskEventSetupDlg.Add.FAClick();
                        Playback.Wait(500);
                        FastDriver.FieldChangedTaskEventSetupDlg.WaitForScreenToLoad(FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable);
                        FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable.PerformTableAction(1, 1, TableAction.SelectItem, "Title Report Effective Date");
                        FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable.PerformTableAction(1, 2, TableAction.SelectItem, "EQ");
                        FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable.PerformTableAction(1, 3, TableAction.SetText, "01-01-01");
                        FastDriver.FieldChangedTaskEventSetupDlg.Done.FAClick();
                    }
                }
            }
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Select the created process name from the Regional Process Summary table.";
            FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processTemplate.Name, 1, TableAction.Click);

            Reports.TestStep = "Change the status.";
            FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
            FastDriver.StatusEdit.WaitForScreenToLoad();
            FastDriver.StatusEdit.Activate.FAClick();

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage();

            Reports.TestStep = "Navigate to Pending Refresh Summary.";
            FastDriver.PendingRefreshSummary.RefreshTemplate(processTemplate.Name);
            FastDriver.WebDriver.Quit();

            return processTemplate;
        }

        #endregion
    }
}