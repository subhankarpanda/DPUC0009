﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;
using System.Linq;
using FASTWCFHelpers.FastFileService;
using System.Threading;


namespace FileManagement
{

    /// <summary>
    /// Summary description for FMUC0004_Maintain_File_Property_Information
    /// </summary>
    [CodedUITest]

    public class FMUC0004 : MasterTestClass
    {

        #region BAT

        #region Test FMUC0004_BAT0001

        /// <summary>
        /// MF1: Add New Property Name, Address, Legal Description and Tax Information.
        /// </summary>

        [TestMethod]
        public void FMUC0004_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Add New Property Name, Address, Legal Description and Tax Information.";

                #region Data Setup
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Verify the file creation
                Reports.TestStep = "Verify the file creation in file home page screen";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "verify property and other  details";
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().Trim(), true);
                Support.AreEqual("J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Trim(), true);
                Support.AreEqual("Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Trim(), true);
                Support.AreEqual("Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Trim(), true);
                Support.AreEqual("Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Trim(), true);
                Support.AreEqual("J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Trim(), true);
                Support.AreEqual("ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Trim(), true);
                Support.AreEqual("CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Trim(), true);




                Reports.TestStep = "verify buyer details";
                Support.AreEqual("Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("Buyer1FirstName", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Trim(), true);
                Support.AreEqual("Buyer1LastName", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("Buyer2FirstName", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Trim(), true);
                Support.AreEqual("Buyer2LastName", FastDriver.FileHomepage.Buyer2LastName.FAGetValue().Trim(), true);
                Support.AreEqual("Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Trim(), true);
                Support.AreEqual("Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Trim(), true);





                Reports.TestStep = "verify seller details";
                Support.AreEqual("Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("Seller1FirstName", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Trim(), true);
                Support.AreEqual("Seller1LastName", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Trim(), true);
                Support.AreEqual("Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("Seller2FirstName", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Trim(), true);
                Support.AreEqual("Seller2LastName", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Trim(), true);
                Support.AreEqual("Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Trim(), true);
                Support.AreEqual("Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Trim(), true);


                #endregion

                #region Create new property
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "s1",
                    StreetLine2 = "s2",
                    StreetLine3 = "s3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                #endregion

                #region Validate the new property details
                Reports.TestStep = "Validate the new property details in General tab";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Support.AreEqual("s1", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Trim(), true);
                Support.AreEqual("s2", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Trim(), true);
                Support.AreEqual("s3", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Trim(), true);
                Support.AreEqual("santa ana", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Trim(), true);
                Support.AreEqual("CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("Orange", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Trim(), true);

                Reports.TestStep = "Validate the new property details in Legal description";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Support.AreEqual("lot1", FastDriver.PropertyTaxInfoLegal.Lot.FAGetValue().Trim(), true);
                Support.AreEqual("block1", FastDriver.PropertyTaxInfoLegal.Block.FAGetValue().Trim(), true);
                Support.AreEqual("unit1", FastDriver.PropertyTaxInfoLegal.Unit.FAGetValue().Trim(), true);


                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0004_BAT0002
        /// <summary>
        /// AF1: Modify Property.
        /// AF2: Delete Property Address.
        /// </summary>

        [TestMethod]

        public void FMUC0004_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Modify Property, AF2: Delete Property Address";

                #region Data Setup
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Create new property
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                #endregion

                #region Validate the new property details
                Reports.TestStep = "Validate the  property details in General tab";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Support.AreEqual("street1", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Trim(), true);
                Support.AreEqual("street2", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Trim(), true);
                Support.AreEqual("street3", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Trim(), true);
                Support.AreEqual("santa ana", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Trim(), true);
                Support.AreEqual("CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("Orange", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Trim(), true);

                Reports.TestStep = "Validate the  property details in Legal description";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Support.AreEqual("lot1", FastDriver.PropertyTaxInfoLegal.Lot.FAGetValue().Trim(), true);
                Support.AreEqual("block1", FastDriver.PropertyTaxInfoLegal.Block.FAGetValue().Trim(), true);
                Support.AreEqual("unit1", FastDriver.PropertyTaxInfoLegal.Unit.FAGetValue().Trim(), true);


                #endregion

                #region Edit the property details
                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and edit the details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "street1", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("1 First American way");
                PropertyAddressParameters NewInfo = new PropertyAddressParameters()
                {

                    StreetLine1 = "1 First American way",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(NewInfo);


                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var NewAddressInfo = new PropertyAddressParameters()
                {

                    Lot = "newlot1",
                    Block = "newblock1",
                    Unit = "newunit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(NewAddressInfo);
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                #endregion

                #region Validate the edited fields
                Reports.TestStep = "validate the edited details in general tab";
                Support.AreEqual("1 First American way", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().Trim(), true);
                Support.AreEqual("1 First American way", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Trim(), true);
                Support.AreEqual("street2", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Trim(), true);
                Support.AreEqual("street3", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Trim(), true);
                Support.AreEqual("santa ana", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Trim(), true);
                Support.AreEqual("CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("Orange", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Trim(), true);


                Reports.TestStep = "validate the edited details in legal description tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Support.AreEqual("newlot1", FastDriver.PropertyTaxInfoLegal.Lot.FAGetValue().Trim(), true);
                Support.AreEqual("newblock1", FastDriver.PropertyTaxInfoLegal.Block.FAGetValue().Trim(), true);
                Support.AreEqual("newunit1", FastDriver.PropertyTaxInfoLegal.Unit.FAGetValue().Trim(), true);
                #endregion

                #region Delete property address
                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Select the entry and click on remove";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "1 First American way", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Validate the Removed Property instance.";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_BAT0003
        [TestMethod, Obsolete]

        public void FMUC0004_BAT0003()
        {
            Reports.TestDescription = "AF2: Delete Property Address(Covered in FMUC0004_BAT0002)";
            Reports.StatusUpdate("Covered in FMUC0004_BAT0002", true);
        }

        #endregion

        #region Test FMUC0004_BAT0004
        /// <summary>
        /// AF3: Direct Entry of Address When Country Not USA or CANADA.
        /// </summary>

        [TestMethod]

        public void FMUC0004_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF3: Direct Entry of Address When Country Not USA or CANADA";

                #region Data Setup
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Create new property
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("J305");
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "J305",
                    StreetLine2 = "JJEJAMQ",
                    StreetLine3 = "JJEJAMQ",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                #endregion

                #region Validate the new property details
                Reports.TestStep = "Validate the  property details in General tab";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Trim(), true);
                Support.AreEqual("santa ana", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Trim(), true);
                Support.AreEqual("CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("Orange", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Trim(), true);

                Reports.TestStep = "Validate the  property details in Legal description";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Support.AreEqual("lot1", FastDriver.PropertyTaxInfoLegal.Lot.FAGetValue().Trim(), true);
                Support.AreEqual("block1", FastDriver.PropertyTaxInfoLegal.Block.FAGetValue().Trim(), true);
                Support.AreEqual("unit1", FastDriver.PropertyTaxInfoLegal.Unit.FAGetValue().Trim(), true);
                #endregion

                #region Change the country and verify
                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and edit the details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCountry.FASelectItemBySendingKeys("INDIA");
                while (FastDriver.WebDriver.WaitForAlertToExist(10) == true)
                {
                    FastDriver.WebDriver.HandleDialogMessage(false, true);

                }

                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Verify that city, county, state and zip fields are disabled ";
                Support.AreEqual("False", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.IsEnabled().ToString(), true);
                Support.AreEqual("False", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.IsEnabled().ToString(), true);
                Support.AreEqual("False", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.IsEnabled().ToString(), true);
                Support.AreEqual("False", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.IsEnabled().ToString(), true);

                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_BAT0005

        /// <summary>
        /// AF5: Add and/or Edit Search Instructions.
        /// </summary>

        [TestMethod]

        public void FMUC0004_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF5: Add and/or Edit Search Instructions";

                #region Data Setup
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion


                #region Edit the property details
                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and edit the details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.PropertyTaxInfoGeneral.GeneralSearchType.FASelectItemBySendingKeys("++View More");
                FastDriver.SearchTypeDialogDlg.WaitForScreenToLoad();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                //FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Select the Instruction.";
                FastDriver.PropertyTaxInfoGeneral.GeneralAddRemoveInstructions.Highlight();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddRemoveInstructions.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Instruction Dialog");
                FastDriver.SelectInstructionsDlg.SwitchToDialogContentFrame();
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(2, 1, TableAction.On, "Regression_Set1_Instruction1", true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();

                #endregion



            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0004_BAT0006_PH

        /// <summary>
        /// AF4_PlaceHolder: Update Title Production Information from FASTSearch/Service Partner Interface.
        /// </summary>

        [TestMethod]

        public void FMUC0004_BAT0006_PH()
        {
            try
            {
                Reports.TestDescription = "AF4_PlaceHolder: Update Title Production Information from FASTSearch/Service Partner Interface.";
                Reports.TestStep = "Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_BAT0007_PH

        /// <summary>
        /// AF6_PlaceHolder: Advance Search Instructions.
        /// </summary>
        [TestMethod]

        public void FMUC0004_BAT0007_PH()
        {
            try
            {
                Reports.TestDescription = "AF6_PlaceHolder: Advance Search Instructions.";
                Reports.TestStep = "Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_BAT0008_PH
        /// <summary>
        /// AF7_PlaceHolder: Update Property via Client Web Service XML from Service Partner.
        /// </summary>

        [TestMethod]

        public void FMUC0004_BAT0008_PH()
        {
            try
            {
                Reports.TestDescription = "AF7_PlaceHolder: Update Property via Client Web Service XML from Service Partner.";
                Reports.TestStep = "Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion


        #endregion

        #region REG

        #region FMUC0004_REG0001
        /// <summary>
        /// FM310_FM314_FM4147_EW24: Multiple Properties in a File, Assign Sequence No.
        /// </summary>

        [TestMethod]

        public void FMUC0004_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM310_FM314_FM4147_EW24: Multiple Properties in a File, Assign Sequence No.";
                #region Data Setup
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                //#region Create File using Web services
                //Reports.TestStep = "Create File using web service.";
                //string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                //#endregion

                #region Create file using GUI
                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem());
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetValue());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue());
                Support.AreEqual(@"Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue());
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue());
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue());
                Support.AreEqual(@"Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetValue());
                Support.AreEqual(@"9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetValue());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue());
                Support.AreEqual(@"CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem());
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue());
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue());
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue());
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue());
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue());
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue());
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetValue());
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue());
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue());
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue());
                #endregion

                #region Validate property tax info details
                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and validate the property/tax info details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Validate property fields";

                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().Trim(), true);
                Support.AreEqual("Single Family Residence", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Trim(), true);
                Support.AreEqual("ALBANY", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Trim(), true);
                Support.AreEqual("CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("ALAMEDA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Trim(), true);

                Reports.TestStep = "Validate legal description fields";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                Support.AreEqual("Lot1", FastDriver.PropertyTaxInfoLegal.Lot.FAGetValue().Trim(), true);
                Support.AreEqual("Block1", FastDriver.PropertyTaxInfoLegal.Block.FAGetValue().Trim(), true);
                Support.AreEqual("Unit1", FastDriver.PropertyTaxInfoLegal.Unit.FAGetValue().Trim(), true);

                Reports.TestStep = "Navigate to Tax Tab and click on Done";
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "Prop1APN1", 1, TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                #endregion

                #region Create new property
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("J305");
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the error msg when no fee is associated with property.";
                string ErrMsg = FastDriver.WebDriver.HandleDialogMessage(true, true).Trim().ToString();
                Support.AreEqual("Please associate appropriate fees with the property state by navigating to Split Fees/Assign State screen.", ErrMsg, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0002_PH

        /// <summary>
        /// FM10527_FM10528_1_EW12_EW13: Prevent Parameter Changes, Automatic Removal of Calculated Fees.
        /// </summary>

        [TestMethod]

        public void FMUC0004_REG0002_PH()
        {
            try
            {
                Reports.TestDescription = "FM10527_FM10528_EW12_EW13: Prevent Parameter Changes, Automatic Removal of Calculated Fees.";

                #region
                string CD_FeesName = "Eagle Lender Policy - 1";
                string HUD_FeesName = "1064_Title_Lender_Policy";
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Enter charges to New loan.
                Reports.TestStep = "Enter charges to New loan.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("300000000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                #endregion

                #region In Fee entry screen Select All fee checkbox & Click on Calculate Fees button.
                Reports.TestStep = "In Fee entry screen Select All fee checkbox & Click on Calculate Fees button.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();
                Thread.Sleep(10000);

                Reports.TestStep = "Select a Fee and click on next.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAdd);
                FastDriver.CalculateFees.SelectTitleProduct(@"ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.PerformAddTitleProducts();

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("3");
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select for FAST Fee description - View More.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.ClickNext();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryFastFeeDescription.Click();
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASendKeys("+" + FAKeys.Tab);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable);
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.FileFeesDlg.FeesTable.PerformTableAction("Description", CD_FeesName, "Sel", TableAction.On);
                }
                else
                {
                    FastDriver.FileFeesDlg.FeesTable.PerformTableAction("Description", HUD_FeesName, "Sel", TableAction.On);
                }
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Select for FAST Fee description ( Recording Fee ) - View More.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryFastFeeDescription2.Click();
                FastDriver.CalculateFees.SummaryFastFeeDescription2.FASendKeys("+" + FAKeys.Tab);

                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem("Recording Fee - Deed");
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText("Record Deed");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable);
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction("Description", "Record Deed", "Sel", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryChargeTo.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryChargeTo2.FASelectItem("Buyer");

                FastDriver.CalculateFees.SummaryFastFeeDescription3.FASelectItem("Record Deed");
                FastDriver.CalculateFees.SummaryChargeTo3.FASelectItem("Buyer");

                FastDriver.CalculateFees.SummaryFastFeeDescription4.FASelectItem("Record Deed");
                FastDriver.CalculateFees.SummaryChargeTo4.FASelectItem("Buyer");
                #endregion

                #region Click on Fee Transfer Button After selection of Payee.
                Reports.TestStep = "Click on Fee Transfer Button After selection of Payee.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                // HandleOverdraftConfirmationOrPasswordConfirmationDialog();

                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Cancel issued disbursements before proceeding with parameter changes.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Void Disbursement");
                FastDriver.VoidDlg.ClickOk();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                #endregion

                #region Navigate to property tax info screen and modify the City, Validate that calculated fee amounts for Recording & Transfer Taxes are removed.
                Reports.TestStep = "Navigate to property tax info screen and modify the City.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAClick(); // FASetText("ChangeCity");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASendKeys("ChangeCity" + FAKeys.Tab);

                Reports.TestStep = "Verify the error message when Change City after issue calculated fee.";
                string ExpErrMsg = "Changing the City will result in removal of all calculated Recording and Transfer Tax fees. Do you wish to continue?";
                string ActualMsg = FastDriver.WebDriver.HandleDialogMessage(true, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg.Trim(), ActualMsg, true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate that calculated fee amounts for Recording & Transfer Taxes are removed when the city is changed";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription); ;
                Support.AreEqual("false", FastDriver.CalculateFees.SummaryFastFeeDescription2.IsDisplayed().ToString().Trim().ToLower(), true);
                Support.AreEqual("false", FastDriver.CalculateFees.SummaryFastFeeDescription2.IsDisplayed().ToString().Trim().ToLower(), true);
                Support.AreEqual("false", FastDriver.CalculateFees.SummaryFastFeeDescription2.IsDisplayed().ToString().Trim().ToLower(), true);
                #endregion

                Reports.TestStep = "Navigate to property tax info screen and modify the State.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASendKeys("GA" + FAKeys.Tab); //FASelectItem("GA" + FAKeys.Tab);

                Reports.TestStep = "Verify the error message1 when state is changed after issue calculated fee.";
                string ExpErrMsg1 = "Changing State will result in the removal or replacements of the ST License ID";
                string ActualMsg1 = FastDriver.WebDriver.HandleDialogMessage(false, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg1.Trim(), ActualMsg1, true);

                Reports.TestStep = "Verify the error message2 when state is changed after issue calculated fee.";
                string ExpErrMsg2 = "Changing the State or County will result in removal of all calculated fees. Do you wish to continue?";
                string ActualMsg2 = FastDriver.WebDriver.HandleDialogMessage(true, false, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg2.Trim(), ActualMsg2, true);

                FastDriver.BottomFrame.Save();


                Reports.TestStep = "Navigate to property tax info screen and modify the County / Country.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASendKeys("Fulton" + FAKeys.Tab); //FASetText("Fulton" + FAKeys.Tab);

                Reports.TestStep = "Verify the error message1 when state is changed after issue calculated fee.";
                string ExpErrMsg3 = "Changing the State or County will result in removal of all calculated fees. Do you wish to continue?";
                string ActualMsg3 = FastDriver.WebDriver.HandleDialogMessage(true, false, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg3.Trim(), ActualMsg3, true);

                FastDriver.BottomFrame.Save();

            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0003

        /// <summary>
        /// FM10528_2: Automatic Removal of Calculated Fees.
        /// </summary>
        /// 
        [TestMethod]

        public void FMUC0004_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM10528_2: Automatic Removal of Calculated Fees. - Covered in REG0002.";
                Reports.StatusUpdate("FM10528_2: Automatic Removal of Calculated Fees. - Covered in REG0002.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0004_REG0004

        /// <summary>
        /// FM10960_FM10962_EW16_EW2: Edit Property associated with finalized Policy.
        /// </summary>
        /// 
        [TestMethod]

        public void FMUC0004_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM10960_FM10961_FM10962_EWC15_EWC16: Edit Property associated with finalized Policy.";

                #region DataSetup
                var value = "";
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create new properties
                // Additional Property 1
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property2");
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo = new PropertyAddressParameters()
                {

                    Lot = "l1",
                    Block = "b1",
                    Unit = "u1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the error msg";
                string ErrMsg = FastDriver.WebDriver.HandleDialogMessage(true, true).Trim().ToString();
                Support.AreEqual("Please associate appropriate fees with the property state by navigating to Split Fees/Assign State screen.", ErrMsg, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                // Additional property 2

                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property3");
                PropertyAddressParameters Info1 = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "persey",
                    State = "GA",
                    County = "Fulton",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo1 = new PropertyAddressParameters()
                {

                    Lot = "l1",
                    Block = "b1",
                    Unit = "u1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo1);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the error msg";
                string ErrMsg1 = FastDriver.WebDriver.HandleDialogMessage(true, true).Trim().ToString();
                Support.AreEqual("Please associate appropriate fees with the property state by navigating to Split Fees/Assign State screen.", ErrMsg1, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                #endregion

                #region Create Documnets

                Reports.TestStep = "Create a Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                CreateDocument("Title Reports", "Automation Test Title Report", "Automation Test Title Report", "CA");

                Reports.TestStep = "Select the Title Report Document and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); //(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Title Reports", "Type", TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Title report.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
                Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.EffectiveDate.FASetText(@"06-20-2012");
                FastDriver.DocumentInfo.Save.FAClick();
                Thread.Sleep(3000);

                Reports.TestStep = "Verify Document Information for Title report.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
                Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
                Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.EffectiveDate.FAGetValue().Clean());

                Reports.TestStep = "Create a second document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); //(FastDriver.DocumentRepository.AddDocRep);
                CreateDocument("Lender Policy", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "CA", multipleDocs: true);

                Reports.TestStep = "Select the Owner Policy and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Lender Policy.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
                Support.AreEqual(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(@"06-20-2012");
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                Thread.Sleep(3000);

                Reports.TestStep = "Verify Document Information for Lender Policy.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
                Support.AreEqual(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerEffectiveDate);
                Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FAGetValue().Clean());
                #endregion

                #region Select the Lender Policy and associate the properties.

                Reports.TestStep = "Select the Lender Policy and associate the properties.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.Properties);
                FastDriver.DocumentRepository.Properties.PerformTableAction("Property Name", "J305", "Sel", TableAction.On);
                FastDriver.DocumentRepository.Properties.PerformTableAction("Property Name", "Property2", "Sel", TableAction.On);
                FastDriver.DocumentRepository.Properties.PerformTableAction("Property Name", "Property3", "Sel", TableAction.On);
                FastDriver.DocumentRepository.InfoSave.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Finalize Document.

                Reports.TestStep = "Select the Lender Policy and Click on Edit for finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Thread.Sleep(2000);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Thread.Sleep(2000);
                value = FastDriver.WebDriver.HandleDialogMessage();
                if (value == "Policy Number/Guarantee Number is required to finalize the document.")
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                    FastDriver.DocumentRepository.Info.FAClick();
                    FastDriver.DocumentRepository.WaitForElementToLoad(FastDriver.DocumentRepository.Save);
                    //Fixed Policy number issue : 16 Feb 2015
                    if (FastDriver.DocumentRepository.CheckPolicyNo.Exists())
                    {
                        if (!FastDriver.DocumentRepository.CheckPolicyNo.Selected)
                            FastDriver.DocumentRepository.CheckPolicyNo.FASetCheckbox(true);
                        if (FastDriver.DocumentRepository.AssignNum.Enabled)
                            FastDriver.DocumentRepository.AssignNum.FAClick();
                    }
                    else
                    {
                        FastDriver.DocumentRepository.PolicyNumber.FASetText(@"FILE1235");
                    }
                    FastDriver.DocumentRepository.Save.FAClick();
                    FastDriver.BottomFrame.Done();
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Thread.Sleep(2000);
                    FastDriver.DocumentPreparation.WaitForScreenToLoad();
                    Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Thread.Sleep(2000);
                }
                else if (value.Contains("Dialog not present"))
                {
                    Thread.Sleep(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Thread.Sleep(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Thread.Sleep(2000);
                }

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Thread.Sleep(2500);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);

                #endregion

                #region Validate that property details cannot be changed/removed when assocaited with finalized policy.

                Reports.TestStep = "Navigate to property tax info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Validate the warning message when State is being tried for change whose property is associated with finalized policy.";
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASendKeys("GA" + FAKeys.Tab);    //FASelectItem("GA" + FAKeys.Tab);
                string ExpErrMsg1 = "Property is associated with finalized Policy, Endorsement or Guarantee. State and County Information cannot be modified.";
                string ActualMsg1 = FastDriver.WebDriver.HandleDialogMessage(false, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg1.Trim(), ActualMsg1, true);

                Reports.TestStep = "Validate the warning message when County is being tried for change whose property is associated with  finalized policy.";
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASendKeys("Fulton" + FAKeys.Tab);//FASetText("Fulton" + FAKeys.Tab);
                string ExpErrMsg2 = "Property is associated with finalized Policy, Endorsement or Guarantee. State and County Information cannot be modified.";
                string ActualMsg2 = FastDriver.WebDriver.HandleDialogMessage(true, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg2.Trim(), ActualMsg2, true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the warning when, property which is associated with finalized policy is tried removing.";
                Reports.TestStep = "Navigate to property tax info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", "Property2", "Property Name", TableAction.Click);
                FastDriver.PropertiesSummary.Remove.FAClick();
                string ExpErrMsg3 = "Selected Property is associated with a finalized Policy, Endorsement or Guarantee.\r\n\r\n\t Property cannot be removed.";
                string ActualMsg3 = FastDriver.WebDriver.HandleDialogMessage(true, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg3.Trim(), ActualMsg3, true);
                #endregion

                #region Unfinalize the document

                Reports.TestStep = "Select the Lender Policy and Click on Edit for Unfinalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Thread.Sleep(2000);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad(FastDriver.DocumentPreparationMenu.menuDocument);
                Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");

                Reports.TestStep = "Unfinalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Unfinalized");

                Reports.TestStep = "Verify Unfinalized Document Data.";
                Support.AreEqual(@"Unfinalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Thread.Sleep(2500);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);
                #endregion

                #region Validate that property which is associated with unfinalized policy can be removed.

                Reports.TestStep = "Validate that property which is associated with unfinalized policy can be removed.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", "Property2", "Property Name", TableAction.Click);
                FastDriver.PropertiesSummary.Remove.FAClick();
                string ExpErrMsg4 = "Do you wish to delete the selected property?";
                string ActualMsg4 = FastDriver.WebDriver.HandleDialogMessage(false, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg4.Trim(), ActualMsg4, true);

                string ExpErrMsg5 = "Selected Property State is associated with a Policy, Endorsement or Guarantee which contains License information. The License information will be removed from the Policy, Endorsement or Guarantee Info tab.";
                string ActualMsg5 = FastDriver.WebDriver.HandleDialogMessage(true, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg5.Trim(), ActualMsg5, true);

                Reports.TestStep = "Validate that the deleted property is deselected in info tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.PolicyNumber);
                for (int i = 1; i <= FastDriver.DocumentRepository.Properties.GetRowCount(); i++)
                {
                    string Property = FastDriver.DocumentRepository.Properties.PerformTableAction(i, 2, TableAction.GetText).Message.ToString();
                    if (Property == "Property2")
                    {
                        string PropertyStatus = FastDriver.DocumentRepository.Properties.PerformTableAction("PropertyName", Property, "Sel", TableAction.GetAttribute, "checked").Message.ToString();
                        if (PropertyStatus == "False")
                        {
                            Reports.StatusUpdate("The deleted property is not selected in info tab of Lender policy.", true);
                        }
                        else
                        {
                            Reports.StatusUpdate("The deleted property is selected in info tab of Lender policy.", false);
                        }
                    }
                    else
                    {
                        Reports.StatusUpdate("The deleted property is not available in info tab of Lender policy: N Issue - Bug Number: 887686.", false);
                    }
                }

                //string PropertiesTable = FastDriver.DocumentRepository.Properties.GetAttribute("InnerText").ToString();
                //if (PropertiesTable.Contains("Property2").ToString() == "True")
                //{
                //    Support.AreEqual("False", FastDriver.DocumentRepository.Properties.PerformTableAction("Property Name", "Property2", "Sel", TableAction.GetAttribute, "checked").Message.ToString(), true);
                //}
                //else
                //{
                //    Reports.StatusUpdate("The deleted property is not available in info tab of Lender policy: N Issue - Bug Number: .", false);
                //}
                #endregion
            }

            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0004_REG0005

        /// <summary>
        /// FM11637_FM11638_EWC18: Do not allow changing & removing state of first property address.
        /// </summary>
        /// 
        [TestMethod]

        public void FMUC0004_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM11637_FM11638_EWC17_EWC18: Do not allow changing & removing state of first property address.";

                #region DataSetup
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                if (AutoConfig.FormType == "HUD")
                {
                    #region Create File using Web services
                    Reports.TestStep = "Create File using web service.";
                    FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                    fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                    fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                    fileRequest.File.TransactionTypeObjectCD = "SALE";

                    var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                    #endregion

                    #region Create new properties
                    // Additional Property 1
                    Reports.TestStep = "Navigate to Properties/Tax Info screen";
                    FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                    FastDriver.PropertiesSummary.SwitchToContentFrame();

                    Reports.TestStep = "Click on New and navigate to General tab ";
                    FastDriver.PropertiesSummary.New.FAClick();
                    FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                    FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                    FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                    FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                    Reports.TestStep = "Enter the property details";
                    FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property2");
                    PropertyAddressParameters Info = new PropertyAddressParameters()
                    {
                        StreetLine1 = "street1",
                        StreetLine2 = "street2",
                        StreetLine3 = "street3",
                        City = "santa ana",
                        State = "CA",
                        County = "Orange",

                    };
                    FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                    Reports.TestStep = "Navigate to Legal description Tab";
                    FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                    Reports.TestStep = "Enter the details";
                    var addressInfo = new PropertyAddressParameters()
                    {

                        Lot = "l1",
                        Block = "b1",
                        Unit = "u1"

                    };
                    FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                    FastDriver.BottomFrame.Save();

                    Reports.TestStep = "Verify the error msg";
                    string ErrMsg = FastDriver.WebDriver.HandleDialogMessage(true, true).Trim().ToString();
                    Support.AreEqual("Please associate appropriate fees with the property state by navigating to Split Fees/Assign State screen.", ErrMsg, true);
                    FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                    #endregion

                    #region Add a loan instance
                    FastDriver.NewLoan.Open();
                    FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("FHA");
                    FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000" + FAKeys.Tab);

                    Reports.TestStep = "Verify the IE message and click on OK button.";
                    FastDriver.WebDriver.HandleDialogMessage(timeout: 3);

                    Reports.TestStep = "Enter GAB code 247";
                    FastDriver.NewLoan.FindGABCode("247");
                    #endregion

                    #region Add itemized orgination charges and choose it for disbursement.
                    Reports.TestStep = "Enter Itemized origination charges.";
                    FastDriver.NewLoan.Open();
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesOriginationChargebuyercharge.FASetText("100");
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.Highlight();

                    //FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(3, 1, TableAction.SetText, "Charges");
                    //FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(2, 3, TableAction.Click);
                    //FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(2, 3, TableAction.SetText, "50.00");
                    //FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(2, 4, TableAction.Click);

                    FastDriver.NewLoan.LoanChargesItemizedOriginationCharges_Description.FASetText("Charges" + FAKeys.Tab);
                    FastDriver.NewLoan.LoanChargesItemizedOriginationCharges_BuyerCharge.FASetText("50.00");

                    FastDriver.NewLoan.LoanChargesItemizedOriginationCharges_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys(@"POC");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                    Reports.TestStep = "Choose the charge for Disbursemnet.";
                    FastDriver.NewLoan.Open();
                    FastDriver.NewLoan.ClickChargesTab();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                    FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                    FastDriver.NewLoanDisbursements.Charges2.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    #endregion

                    #region Select a pending check & disburse it.
                    Reports.TestStep = "Select a pending check & disburse it.";
                    FastDriver.ActiveDisbursementSummary.Open();
                    FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "50.00", "Amount", TableAction.Click);
                    FastDriver.ActiveDisbursementSummary.Print.FAClick();
                    FastDriver.PrintChecks.WaitForScreenToLoad(FastDriver.PrintChecks.Deliver);
                    FastDriver.PrintChecks.Deliver.FAClick();
                    FastDriver.PrintDlg.ValidatePrinterConfig();

                    Reports.TestStep = "SendPrint.";
                    FastDriver.PrintDlg.SendPrint();

                    Reports.TestStep = "Handle Password Confirmation Dialog.";
                    FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                    FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 200);
                    #endregion

                    #region Verify for error messages for change of state or removal of property for Check issued with Itemized charges
                    Reports.TestStep = "Navigate to property tax info screen";
                    FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                    FastDriver.PropertiesSummary.SwitchToContentFrame();
                    FastDriver.PropertiesSummary.Edit.FAClick();
                    FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                    Reports.TestStep = "Validate the warning message when State is being tried for change whose property is associated with Check issued.";
                    FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAClick();
                    FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASendKeys("GA" + FAKeys.Tab);
                    string ExpErrMsg1 = "State of the Property address cannot be edited as a check has been issued for the Itemized Loan Charges.";
                    string ActualMsg1 = FastDriver.WebDriver.HandleDialogMessage(true, true, 10).ToString().Trim();
                    Support.AreEqual(ExpErrMsg1.Trim(), ActualMsg1, true);
                    FastDriver.BottomFrame.Done();
                    
                    Reports.TestStep = "Navigate to property tax info screen";
                    FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                    FastDriver.PropertiesSummary.SwitchToContentFrame();
                    // FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", "Property2", "Property Name", TableAction.Click);
                    FastDriver.PropertiesSummary.Remove.FAClick();

                    Reports.TestStep = "Validate the warning message when property is tried removing which associated with Check issued.";
                    string ExpErrMsg2 = "Property address cannot be removed as a check has been issued for the Itemized Loan Charges.";
                    string ActualMsg2 = FastDriver.WebDriver.HandleDialogMessage(true, true, 10).ToString().Trim();
                    Support.AreEqual(ExpErrMsg2.Trim(), ActualMsg2, true);
                    #endregion
                }
                else
                {
                    Reports.StatusUpdate("This is applicable only for HUD file.", true);
                }

            }

            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0004_REG0006

        /// <summary>
        /// FM4149_FM311_FM320_FM4190_FM2713: Mandatory information, Allow Multiple Street Addresses.
        /// FM584_FM586_FM585_FM587_FM4882_FM4216_FM4881_FM589: Initiate Fast Search, Prevent duplicate Fast Search.
        /// FM9648_FM9649: Search Type and Instructions
        /// </summary>
        /// 
        [TestMethod]

        public void FMUC0004_REG0006()
        {
            try
            {

                Reports.TestDescription = "FM4149_FM311_FM320_FM4190_FM2713: Mandatory information, Allow Multiple Street Addresses.";

                #region Fast Search Setting
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();
                #endregion

                #region Data Setup
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create file using GUI
                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.FileHomepage.SwitchToContentFrame();
                Support.AreEqual(@"Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem());
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetValue());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetValue());
                Support.AreEqual(@"Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue());
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue());
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue());
                Support.AreEqual(@"Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetValue());
                Support.AreEqual(@"9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetValue());
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue());
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue());
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue());
                Support.AreEqual(@"CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem());
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue());
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue());
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue());
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue());
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue());
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue());
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue());
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetValue());
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue());
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue());
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue());
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue());
                #endregion


                #region  property tax info details
                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and validate the property/tax info details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Validate property fields";

                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().Trim(), true);
                Support.AreEqual("Single Family Residence", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Trim(), true);
                Support.AreEqual("JJEJAMQ", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Trim(), true);
                Support.AreEqual("ALBANY", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Trim(), true);
                Support.AreEqual("CA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Trim(), true);
                Support.AreEqual("ALAMEDA", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Trim(), true);

                Reports.TestStep = "Enter comments";
                FastDriver.PropertyTaxInfoGeneral.GeneralComments.FASetText("This Property Belongs To FAI");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxInfoGeneral.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and validate the property/tax info details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Tax Tab";
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                Thread.Sleep(1000);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("9845012345");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("2010-2011");
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "9845012345", 1, TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASetText("9999999999");
                Keyboard.SendKeys(FAKeys.TabAway);

                FastDriver.PropertyTaxInfoAnnualTax.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();

                Reports.TestStep = "Verify the street1 default name";
                Support.AreEqual("J305", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Trim(), true);

                Reports.TestStep = "Validate for property tax info details.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "Prop1APN1", 1, TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Initiate Fast Search and Prevent duplicate Fast Search

                Reports.TestStep = "Navigate to property tax info screen & delete Zip code.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxInfoGeneral.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();


                Reports.TestStep = "Initiate FAST search";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralFASTSearch.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(10) == true)
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for the Fast Search Initiated event and submission and completion log.";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    Reports.StatusUpdate("-- RETRYING - Fast Search Initiated --  ", true);
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                    return FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Fast Search Initiated]");
                }, timeout: 240, idleInterval: 10);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    Reports.StatusUpdate("-- RETRYING - FS Request Submitted -- ", true);
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                    return FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[FS Request Submitted]");
                }, timeout: 240, idleInterval: 10);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    Reports.StatusUpdate("-- RETRYING - FS Request Completed -- ", true);
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                    return FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[FS Request Completed]");
                }, timeout: 600, idleInterval: 10);

                #endregion


                #region Search Type and Instructions
                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and edit the details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.PropertyTaxInfoGeneral.GeneralSearchType.FASelectItemBySendingKeys("++View More");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Select the Instruction.";
                FastDriver.PropertyTaxInfoGeneral.GeneralAddRemoveInstructions.Highlight();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddRemoveInstructions.FAClick();


                FastDriver.WebDriver.WaitForWindowAndSwitch("Instruction Dialog");
                FastDriver.SelectInstructionsDlg.SwitchToDialogContentFrame();
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(2, 1, TableAction.On, "Regression_Set1_Instruction1", true);
                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(3, 1, TableAction.On, "Regression_Set1_Instruction2", true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();


                Reports.TestStep = "Validating for the additional instructions boundary value.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAdditionalInstructions.FASetText("asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg45698asdfg4569a");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxInfoGeneral.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();


                Reports.TestStep = "Navigate to property tax info screen & enter invalid phrase code.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.ClickTitleProdTab();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.FASetText("ABCD/XYZ");
                FastDriver.PropertyTaxInfoTitleProd.ExceptionRequestInformationSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                string ErrorMsg = FastDriver.PropertyTaxInfoTitleProd.ErrorMessage.FAGetText().Clean();
                Support.AreEqual("Exception Phrase(s) ABCD/XYZ is(are) Invalid!", ErrorMsg.Trim(), true);
                #endregion



            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0007

        [TestMethod, Obsolete]

        public void FMUC0004_REG0007()
        {
            Reports.TestDescription = "FM584_FM586_FM585_FM587_FM4882_FM4216_FM4881_FM589: Initiate Fast Search, Prevent duplicate Fast Search - Covered in FMUC0004_REG0006";
            Reports.StatusUpdate("Covered in FMUC0004_REG0006", true);
        }

        #endregion

        #region Test FMUC0004_REG0008
        [TestMethod, Obsolete]
        public void FMUC0004_REG0008()
        {
            Reports.TestDescription = "FM9648_FM9649: Search Type and Instructions - Covered in FMUC0004_REG0006";
            Reports.StatusUpdate("Covered in FMUC0004_REG0006", true);
        }

        #endregion

        #region Test FMUC0004_REG0009
        /// <summary>
        /// FM675_FM322_FM591_FM592_FM4148_FM869_FM6880_FM6880_FM4150: Select Attached Legal Reference, County phrase & abbreviated legal description.
        /// </summary>
        ///
        [TestMethod]
        public void FMUC0004_REG0009()
        {
            try
            {

                Reports.TestDescription = "FM675_FM322_FM591_FM592_FM4148_FM869_FM6880_FM6880_FM4150: Select Attached Legal Reference, County phrase & abbreviated legal description.";


                #region Data Setup
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion
                #region Create new property
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("street1");
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo = new PropertyAddressParameters()
                {

                    Lot = "l1",
                    Block = "b1",
                    Unit = "u1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the error msg";
                string ErrMsg = FastDriver.WebDriver.HandleDialogMessage(true, true).Trim().ToString();
                Support.AreEqual("Please associate appropriate fees with the property state by navigating to Split Fees/Assign State screen.", ErrMsg, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "enter valid phrase code.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoGeneral.ClickTitleProdTab();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.FASetText("TRNS/TBUY");
                FastDriver.PropertyTaxInfoTitleProd.ExceptionRequestInformationSave.FAClick();

                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                // FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegal.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoLegal.AbbreviatedLegalDescriptionCountyPhrase.FASelectItemByIndex(1);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxInfoLegal.AbbreviatedLegalDescriptionRefresh.FAClick();

                string WrnMsg = FastDriver.WebDriver.HandleDialogMessage().ToString().Trim();
                Support.AreEqual("True", WrnMsg.Contains("The Abbreviated Legal Description has changed").ToString());
                Support.AreEqual("True", WrnMsg.Contains("Would you like to replace the Complete Legal Description with the refreshed Abbreviated Legal Description?").ToString());

                FastDriver.PropertyTaxInfoLegal.SwitchToContentFrame();
                FastDriver.BottomFrame.Save();


                Reports.TestStep = "Validate for the saved values in Abbreviated Legal description section.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();
                FastDriver.PropertyTaxInfoLegal.WaitForScreenToLoad();
                string comments = FastDriver.PropertyTaxInfoLegal.AbbrLegalDesciptionComments.FAGetValue().ToString();
                Support.AreEqual("True", comments.Contains("Lot Lot1, Tract No. , in the County of San Bernardino, State of California, as per plat recorded in book  of Maps, page , records of said county").ToString());
                Support.AreEqual("True", comments.Contains("Lot Lot1, Tract No. , in the County of San Bernardino, State of California, as per plat recorded in").ToString());
                Support.AreEqual("True", comments.Contains("page , records of said county.").ToString());

                comments = FastDriver.PropertyTaxInfoLegal.CompleteLegalDescriptionComments.FAGetValue().ToString();
                Support.AreEqual("True", comments.Contains("Lot Lot1, Tract No. , in the County of San Bernardino, State of California, as per plat recorded in").ToString());
                Support.AreEqual("True", comments.Contains("page , records of said county.").ToString());

                FastDriver.PropertyTaxInfoLegal.TitleProductionTab.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptionsRegion.FASelectItemBySendingKeys("QA SANDPOINTE REGION");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                FastDriver.PropertyTaxInfoTitleProd.SwitchToContentFrame();

                FastDriver.PropertyTaxInfoTitleProd.ClickExcReqInfSave();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptionsRegion.FASelectItemBySendingKeys("QA Automation Region - DO NOT TOUCH");
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.ExceptionDocuments.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "navigate to property tax info & Delete 2nd property added.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "street1", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoGeneral.GeneralRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0010
        /// <summary>
        /// FM4160_FM4442_FM4157_FM4440_FM4211_FM4151_FM594_FM4441_FM4159_FM4152_FM4154_FM4153_FM4880: Calculate Net Value, Enter Tax Year, Sum of Installments.
        /// </summary>
        ///
        [TestMethod, Obsolete]

        public void FMUC0004_REG0010()
        {
            try
            {
                Reports.TestDescription = "Covered in FMUC0004_REG0011B and REG0021";
                Reports.StatusUpdate("Covered in FMUC0004_REG0011B and REG0021", true);

            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0011
        /// <summary>
        /// FM6563_FM6564_FM6927: Prompt to Modify and Reissue 1099-S Form.
        /// </summary>
        ///
        [TestMethod]

        public void FMUC0004_REG0011()
        {
            try
            {
                Reports.TestDescription = "FM6563_FM6564_FM6927: Prompt to Modify and Reissue 1099-S Form.";

                #region Data Setup
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add Tax ID APN.
                Reports.TestStep = "Add Tax ID APN.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("Prop1APN1");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                #endregion

                #region Enter Seller Details with 1099 S details.
                Reports.TestStep = "Enter Seller Details with 1099 S details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Sellers");
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.WaitCreation(FastDriver.BuyerSellerSummary.btnEdit);
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Name", "Seller1FirstName Seller1Lastname", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItem("1099-S");
                FastDriver.BuyerSellerSetup.txtSSN.FASetText("111-11-1111");
                FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Populate Settlement Date.";
                FastDriver.TermsDatesStatus.Open();
                string SetDate = DateTime.Today.AddDays(Convert.ToInt32("-2")).ToDateString();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(SetDate);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to 1099-S screen and Create Ad-Hoc.
                Reports.TestStep = "Navigate to 1099-S screen and Create Ad-Hoc.";
                FastDriver._1099S.Open();
                int Rows = FastDriver._1099S.RecordSummaryTable.GetRowCount();
                if (Rows == 0)
                {
                    FastDriver._1099S.AdHoc.FAClick();
                    FastDriver._1099S.WaitForScreenToLoad(FastDriver._1099S.GrossProceedDollor);
                }
                FastDriver._1099S.CreateAdHoc("5000.00");
                #endregion

                Reports.TestStep = "Validate the 1099s warning message when Property address details are changed.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Street2");
                FastDriver.BottomFrame.Save();
                string Exp1099msg1 = "Please update the 1099-S record and print the 1099-S form for the seller.";
                Support.AreEqual(Exp1099msg1, FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString().Trim(), true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City2");
                FastDriver.BottomFrame.Save();
                string Exp1099msg2 = "Please update the 1099-S record and print the 1099-S form for the seller.";
                Support.AreEqual(Exp1099msg2, FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString().Trim(), true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("County2");
                FastDriver.BottomFrame.Save();
                string Exp1099msg3 = "Please update the 1099-S record and print the 1099-S form for the seller.";
                Support.AreEqual(Exp1099msg3, FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString().Trim(), true);

                Reports.TestStep = "Validate the 1099s warning message when Legal Description / Tax APN is changed.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Alameda");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.AbbrLegalDesciptionComments.FASetText("AbbrLegalDesciptionComments2");
                FastDriver.BottomFrame.Save();
                string Exp1099msg4 = "Please update the 1099-S record and print the 1099-S form for the seller.";
                Support.AreEqual(Exp1099msg4, FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString().Trim(), true);

                Reports.TestStep = "Validate the 1099s warning message when Legal Description / Tax APN is changed.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "Prop1APN1", 1, TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASendKeys("Prop1APN1");
                FastDriver.BottomFrame.Save();
                string Exp1099msg5 = "Please update the 1099-S record and print the 1099-S form for the seller.";
                Support.AreEqual(Exp1099msg5, FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString().Trim(), true);

                Reports.TestStep = "Validate the 1099s alert image and the message for 1099 s in File workflow.";
                FastDriver.FileWorkflow.Open();
                for (int i = 1; i <= FastDriver.FileWorkflow.MessagesTable.GetRowCount(); i++)
                {
                    string RowData = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(i, 4, TableAction.GetText).Message.ToString();
                    if (RowData == "1099-S data has changed. Please update and reprint 1099-S.")
                    {
                        Reports.StatusUpdate("The message -- 1099-S data has changed. Please update and reprint 1099-S. -- appears.", true);
                    }
                    else
                    {
                        if (i == FastDriver.FileWorkflow.MessagesTable.GetRowCount())
                        {
                            Reports.StatusUpdate("The message -- 1099-S data has changed. Please update and reprint 1099-S. -- does not appear.", false);
                        }
                    }
                }

                #region FM6564 --- Prompt to Mark 1099-S Ready for Extract
                Reports.TestStep = "Navigate to 1099-S screen and check Ready for Extract checkbox.";
                FastDriver._1099S.Open();
                FastDriver._1099S.ActiveReadyForExtract.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate that 1099s alert is not present in File Workflow.";
                FastDriver.FileWorkflow.Open();
                for (int j = 1; j <= FastDriver.FileWorkflow.MessagesTable.GetRowCount(); j++)
                {
                    string RowData = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(j, 4, TableAction.GetText).Message.ToString();
                    if (RowData == "1099-S data has changed. Please update and reprint 1099-S.")
                    {
                        Reports.StatusUpdate("The message -- 1099-S data has changed. Please update and reprint 1099-S. -- appears.", false);
                    }
                    else
                    {
                        if (j == FastDriver.FileWorkflow.MessagesTable.GetRowCount())
                        {
                            Reports.StatusUpdate("The message -- 1099-S data has changed. Please update and reprint 1099-S. -- does not appear.", true);
                        }
                    }
                }

                Reports.TestStep = "Validate the 1099s Ready for Extract warning message when Property Address (Street/City/Country/State) is changed.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Street11");
                FastDriver.BottomFrame.Save();
                string Actual1099msg6 = FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                string Exp1099msg6 = "The Ready for Extract flag has been removed for one or more 1099-S records. Please update each 1099-S record and print the 1099-S form for the seller.";
                Support.AreEqual(Exp1099msg6, Actual1099msg6.Trim(), true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to 1099S screen and verify ready for extract check box unchecked.";
                FastDriver._1099S.Open();
                string ReadyForExtractstatus = FastDriver._1099S.ActiveReadyForExtract.IsSelected().ToString();//FastDriver._1099S.ActiveReadyForExtract.FAGetAttribute("Checked");
                Support.AreEqual("false", ReadyForExtractstatus, true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0011B_PH
        /// <summary>
        /// Validating for 255 Characters in Comments section
        /// </summary>
        ///
        [TestMethod]
        public void FMUC0004_REG0011B_PH()
        {
            try
            {
                Reports.TestDescription = "Validating for 255 Characters in Comments section";

                #region Data Setup
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Validate for more than 255 characters to Comments section.

                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and edit the details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Validate for more than 255 characters to Comments section.";

                FastDriver.PropertyTaxInfoGeneral.GeneralComments.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU256257258259260");
                Keyboard.SendKeys(FAKeys.TabAway);
                string ErrMsg = FastDriver.WebDriver.HandleDialogMessage().ToString();
                Support.AreEqual("Comments can have a maximum of 255 characters.", ErrMsg, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Validate for 255 characters";
                FastDriver.PropertyTaxInfoGeneral.GeneralComments.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.PropertyTaxInfoGeneral.GeneralComments.FAGetValue().Trim().ToString(), true);
                FastDriver.PropertyTaxInfoGeneral.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0012
        /// <summary>
        /// FM6926,FM6926_2: Prevent 1099-S Messages if No Activity Date.
        /// </summary>
        ///
        [TestMethod]
        public void FMUC0004_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM6926: Prevent 1099-S Messages if No Activity Date.";

                #region DATA SETUP
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to IIS side and create file
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create new property
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("J305");
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "J305",
                    StreetLine2 = "JJEJAMQ",
                    StreetLine3 = "JJEJAMQ",
                    City = "santa ana",
                    State = "CA",
                    Zip = "92707",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the error msg";
                string ErrMsg = FastDriver.WebDriver.HandleDialogMessage(true, true).Trim().ToString();
                Support.AreEqual("Please associate appropriate fees with the property state by navigating to Split Fees/Assign State screen.", ErrMsg, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                #region Add Tax ID APN.
                Reports.TestStep = "Add Tax ID APN.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("Prop1APN1");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                #endregion

                #endregion

                #region Login to ADM and remove 1099-S Activity Date
                Reports.TestStep = "Login to FAST ADM ";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Remove 1099-S Activity Date ";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").SwitchToContentFrame();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OfficeSetupOffice.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Prevent 1099-S Messages if No Activity Date.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                Reports.TestStep = "Enter file number and click on Find";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and edit the details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to property tax info screen & delete Zip code to validate there are no 1099s messages since there is no activity date.";
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "Prop1APN1", 1, TableAction.Click);

                FastDriver.PropertyTaxInfoAnnualTax.GeneralTab.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxInfoGeneral.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();

                #endregion

                #region Login to ADM and reset 1099-S Activity Date
                Reports.TestStep = "Login to FAST ADM ";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Reset 1099-S Activity Date ";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").SwitchToContentFrame();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("02-02-2012");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OfficeSetupOffice.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0013

        [TestMethod, Obsolete]
        public void FMUC0004_REG0013()
        {
            Reports.TestDescription = "(BR Covered in FMUC0004_REG0012)";
            Reports.StatusUpdate("BR Covered in FMUC0004_REG0012", true);
        }
        #endregion

        #region Test FMUC0004_REG0014
        /// <summary>
        /// FM6928  Prevent 1099-S Messages if No 1099-S Seller  
        /// </summary>
        ///
        [TestMethod]

        public void FMUC0004_REG0014()
        {
            try
            {
                Reports.TestDescription = "FM6928  Prevent 1099-S Messages if No 1099-S Seller  ";

                #region DATA SETUP
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to IIS side and create file
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create new property
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("J305");
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "J305",
                    StreetLine2 = "JJEJAMQ",
                    StreetLine3 = "JJEJAMQ",
                    City = "santa ana",
                    State = "CA",
                    Zip = "92707",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the error msg";
                string ErrMsg = FastDriver.WebDriver.HandleDialogMessage(true, true).Trim().ToString();
                Support.AreEqual("Please associate appropriate fees with the property state by navigating to Split Fees/Assign State screen.", ErrMsg, true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                #region Add Tax ID APN.
                Reports.TestStep = "Add Tax ID APN.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("Prop1APN1");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                #endregion

                #endregion

                #region Login to ADM and enter 1099-S Activity Date
                Reports.TestStep = "Login to FAST ADM ";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Remove 1099-S Activity Date ";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").SwitchToContentFrame();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("7/12/2010");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OfficeSetupOffice.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Prevent 1099-S Messages if No Activity Date.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                Reports.TestStep = "Enter file number and click on Find";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search");
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.Country.FASelectItem("USA");
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and edit the details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();


                Reports.TestStep = "Navigate to property tax info screen ";
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "Prop1APN1", 1, TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASetText("99999999999.99");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxInfoAnnualTax.GeneralTab.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxInfoGeneral.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0015

        [TestMethod, Obsolete]

        public void FMUC0004_REG0015()
        {
            Reports.TestDescription = "(FM6926_4: 1099-S Messages after entering Activity Date.BR Covered in FMUC0004_REG0011)";
            Reports.StatusUpdate("FM6926_4: 1099-S Messages after entering Activity Date. BR Covered in FMUC0004_REG0011", true);
        }

        #endregion

        #region Test FMUC0004_REG0016
        /// <summary>
        /// FM9073_FM9074_FM9075_EWC6_EWC7: Enabled Property Tax Info - Title Production tab.
        /// </summary>
        ///
        [TestMethod]

        public void FMUC0004_REG0016()
        {
            try
            {
                Reports.TestDescription = "FM9073_FM9074_FM9075: Enabled Property Tax Info - Title Production tab.";

                #region Data Setup
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create a new property
                // Reports.TestStep = "Create new property.";
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("street1");
                PropertyAddressParameters Info1 = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info1);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var AddrInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(AddrInfo);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                #endregion

                Reports.TestStep = "Navigate to property tax info screen & enter invalid phrase code.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.ClickTitleProdTab();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.FASetText("ABCD/XYZ");
                FastDriver.PropertyTaxInfoTitleProd.ExceptionRequestInformationSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                string ErrorMsg = FastDriver.PropertyTaxInfoTitleProd.ErrorMessage.FAGetText().Clean();
                Support.AreEqual("Exception Phrase(s) ABCD/XYZ is(are) Invalid!", ErrorMsg.Trim(), true);


                Reports.TestStep = "Navigate to property tax info screen & enter valid phrase code.";
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.FASetText("TRNS/TBUY");
                FastDriver.PropertyTaxInfoTitleProd.ClickExcReqInfSave();

                Reports.TestStep = "Validate the warning message When user plan to insert phrase codes from another region, upon selecting the other region.";
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptionsRegion.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptionsRegion.FASendKeys("QA SANDPOINTE REGION" + FAKeys.Tab);  //FASelectItem(@"QA SANDPOINTE REGION" + FAKeys.Tab);
                string ActualErrMsgForRegionChange = FastDriver.WebDriver.HandleDialogMessage(true, false, 5);
                string ExpErrMsgForRegionChange = "You may enter phrase codes from one region only.\r\nDo you want to change all codes previously entered to the new Source Region?";
                Support.AreEqual(ExpErrMsgForRegionChange.Trim(), ActualErrMsgForRegionChange.Trim(), true);

                Reports.TestStep = "Validate for Source- Automation Region & exception phrase code.";
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.SelectedRegionName, FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptionsRegion.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual(@"TRNS/TBUY", FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.FAGetText().ToString().Trim(), true);
                FastDriver.PropertyTaxInfoTitleProd.ClickExcReqInfSave();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();

                #region Add 2 or more exception phrase code from 2 or more regions.
                Reports.TestStep = "Click on button Exception Documents in Title Production Tab.";
                FastDriver.PropertyTaxInfoTitleProd.ExceptionDocuments.FAClick();
                Thread.Sleep(10000);
                Thread.Sleep(2000);
                Keyboard.SendKeys("%p");
                Thread.Sleep(2000);
                Keyboard.SendKeys("p");
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

                Reports.TestStep = "Select exception pharse for QA SANDPOINTE REGION in Phrase select dialog.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad(FastDriver.PhraseSelectDlg.ViewText);
                FastDriver.PhraseSelectDlg.Source.FASelectItem("QA SANDPOINTE REGION");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Exception Phrase");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.Click);
                string QASandpointeRegionExcptnPhrase = FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToString();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate multiple regions and exception phrase codes in title production tab.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TitleProductionTab.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                string ExpRegions = FastDriver.PropertyTaxInfoTitleProd.ExceptionSourceRegion.FAGetText().ToString().Trim();
                Support.AreEqual("Multiple Regions", ExpRegions, true);
                string ExpPhrase = FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.FAGetValue().ToString().Trim();
                Support.AreEqual(@"TRNS/TBUY,#/" + QASandpointeRegionExcptnPhrase, ExpPhrase, true);

                Reports.TestStep = "Validate that source region and exception phrase code text box is disabled.";
                Support.AreEqual("false", FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.IsEnabled().ToString().ToLower().Trim(), true);
                FastDriver.PropertyTaxInfoTitleProd.ExceptionSourceRegion.Highlight();
                Support.AreEqual("false", FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptionsRegion.IsEnabled().ToString().ToLower().Trim(), true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0004_REG0017
        /// <summary>
        /// EWC4: Error warning conditions.
        /// </summary>
        ///
        [TestMethod]

        public void FMUC0004_REG0017()
        {
            try
            {
                Reports.TestDescription = "EWC2_EWC3_EWC4_EWC5_EWC6: Error warning conditions.";

                #region Data Setup
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region create new property
                Reports.TestStep = "Create new property.";
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("street1");
                PropertyAddressParameters Info1 = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info1);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var AddrInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(AddrInfo);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();


                Reports.TestStep = "Select the entry and edit the details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("Prop1APN1");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                #endregion

                #region Error warning conditions

                #region EWC4
                Reports.TestStep = "Navigate to Properties/Tax Info General Tab";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();


                Reports.TestStep = "Select the entry and validate the EW4 message when Removal is tried.";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "street1", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoGeneral.GeneralRemove.FAClick();
                string ErrWarnMsg4 = FastDriver.WebDriver.HandleDialogMessage(true, false).ToString().Trim();
                string ExpErrWarnMsg4 = "Do you wish to delete Address: street1 street2 street3 , santa ana, CA,";
                Support.AreEqual(ExpErrWarnMsg4.Trim(), ErrWarnMsg4.Trim(), true);

                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region EWC3
                Reports.TestStep = "Navigate to Properties/Tax Info Tax Tab.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and validate the EW3 message when Removal is tried.";
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable.PerformTableAction("Tax No/APN", "Prop1APN1", "Tax No/APN", TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.Remove.FAClick();
                string ErrWarnMsg3 = FastDriver.WebDriver.HandleDialogMessage(true, false).ToString().Trim();
                string ExpErrWarnMsg3 = "Do you wish to delete Tax/APN No.Prop1APN1?";
                Support.AreEqual(ExpErrWarnMsg3.Trim(), ErrWarnMsg3.Trim(), true);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                #endregion

                #region EWC5
                Reports.TestStep = "Navigate to Properties/Tax Info Legal Description Tab.";
                FastDriver.PropertyTaxInfoAnnualTax.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and validate the EW5 message when Refresh is tried.";
                FastDriver.PropertyTaxInfoLegalDesciption.AbbreviatedLegalDescriptionRefresh.FAClick();
                string ErrWarnMsg5 = FastDriver.WebDriver.HandleDialogMessage(true, false).ToString().Trim();
                string ExpErrWarnMsg5 = "The Abbreviated Legal Description has changed.\r\nWould you like to replace the Complete Legal Description with the refreshed Abbreviated Legal Description?";
                Support.AreEqual(ExpErrWarnMsg5.Trim(), ErrWarnMsg5.Trim(), true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region EW6
                Reports.TestStep = "Navigate to Properties/Tax Info General Tab";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Validate for 255 characters to Comments section.";
                FastDriver.PropertyTaxInfoGeneral.GeneralComments.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU" + FAKeys.Tab);
                Thread.Sleep(2000);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.PropertyTaxInfoGeneral.GeneralComments.FAGetText().ToString().Trim(), true);

                Reports.TestStep = "Validate the warning message when more than 255 characters are entered for Comments Section.";
                FastDriver.PropertyTaxInfoGeneral.GeneralComments.FASetText("");
                FastDriver.PropertyTaxInfoGeneral.GeneralComments.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUabcdefghijklmnopqrstuvywxyz" + FAKeys.Tab);
                string ErrWarnMsg6 = FastDriver.WebDriver.HandleDialogMessage(true, true).ToString().Trim();
                string ExpErrWarnMsg6 = "Comments can have a maximum of 255 characters.";
                Support.AreEqual(ExpErrWarnMsg6.Trim(), ErrWarnMsg6.Trim(), true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralComments.FASetText("");
                FastDriver.PropertyTaxInfoGeneral.GeneralComments.FASetText("This Property Belongs To FAI");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region EW7
                Reports.TestStep = "Navigate to Properties/Tax Info General Tab";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Condominium");
                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();

                Reports.TestStep = "Validate for 255 characters to Subdivision/Condo section.";
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASetText("");
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWX" + FAKeys.Tab);
                Thread.Sleep(2000);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWX", FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FAGetText().ToString().Trim(), true);

                Reports.TestStep = "Validate the warning message when more than 255 characters are entered for Subdivision/Condo field.";
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASetText("");
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                string SubDiivisionErr = FastDriver.PropertyTaxInfoLegalDesciption.ErrorMasg.FAGetText().ToString();
                if (SubDiivisionErr == "Subdivision/Condominium cannot be more than 255 characters long")
                {
                    Reports.StatusUpdate("Warning Message: --Subdivision/Condominium cannot be more than 255 characters long-- appears as expected.", true);
                }
                else
                {
                    Reports.StatusUpdate("Warning Message: --Subdivision/Condominium cannot be more than 255 characters long-- does not appear as expected.", false);
                }
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASetText("");
                FastDriver.BottomFrame.Done();
                #endregion

                #region EW8
                Reports.TestStep = "Navigate to Properties/Tax Info General Tab";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();

                Reports.TestStep = "Validate for Tax year as 2000.";
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable.PerformTableAction("Tax No/APN", "Prop1APN1", "Tax No/APN", TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("2000");
                Thread.Sleep(2000);
                Support.AreEqual("2000", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FAGetValue().ToString().Trim(), true);

                Reports.TestStep = "Validate for Tax year as 2000 - 2001.";
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText(@"2000-2001");
                Thread.Sleep(2000);
                Support.AreEqual(@"2000-2001", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FAGetValue().ToString().Trim(), true);

                Reports.TestStep = "Validate the warning message when Tax year is 200.";
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("200");
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                string TaxYearErrorMsg = FastDriver.PropertyTaxInfoAnnualTax.ErrorMsg.FAGetText().ToString().Trim();
                if (TaxYearErrorMsg == "Tax Year: TaxYear format is invalid. Please enter a single year, such as 1999, or a 1 year span using a dash, such as 1999-2000.")
                {
                    Reports.StatusUpdate("Warning Message: --Tax Year: TaxYear format is invalid. Please enter a single year, such as 1999, or a 1 year span using a dash, such as 1999-2000.-- appears as expected.", true);
                }
                else
                {
                    Reports.StatusUpdate("Warning Message: --Tax Year: TaxYear format is invalid. Please enter a single year, such as 1999, or a 1 year span using a dash, such as 1999-2000.- does not appear as expected.", false);
                }

                Reports.TestStep = "Validate the warning message when Tax year is 2000-2002.";
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("2000-2002");
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                string TaxYearErrorMsg2 = FastDriver.PropertyTaxInfoAnnualTax.ErrorMsg.FAGetText().ToString().Trim();
                if (TaxYearErrorMsg2 == "Tax Year: TaxYear format is invalid. Please enter a single year, such as 1999, or a 1 year span using a dash, such as 1999-2000.")
                {
                    Reports.StatusUpdate("Warning Message: --Tax Year: TaxYear format is invalid. Please enter a single year, such as 1999, or a 1 year span using a dash, such as 1999-2000.-- appears as expected.", true);
                }
                else
                {
                    Reports.StatusUpdate("Warning Message: --Tax Year: TaxYear format is invalid. Please enter a single year, such as 1999, or a 1 year span using a dash, such as 1999-2000.- does not appear as expected.", false);
                }
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("2000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region EWC19
                Reports.TestStep = "Navigate to Properties/Tax Info Tax Tab.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Entry of Address Country Other Than USA or CANADA.";
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCountry.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCountry.FASendKeys("INDIA" + FAKeys.Tab);

                Reports.TestStep = "Validate the warning message -- Itemized Origination Charges will be removed. Do you wish to continue?";
                string ErrWarnMsg = FastDriver.WebDriver.HandleDialogMessage(true, false).ToString().Trim();
                string ExpErrWarnMsg = "Itemized Origination Charges will be removed. Do you wish to continue?";
                FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(ExpErrWarnMsg.Trim(), ErrWarnMsg.Trim(), true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate max value for Tax No/APN
                Reports.TestStep = "Navigate to Properties/Tax Info Tax Tab.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and validate the EW3 message when Removal is tried.";
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable.PerformTableAction("Tax No/APN", "Prop1APN1", "Tax No/APN", TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASetText(@"9999999999999.99" + FAKeys.Tab);
                string AnnualTaxInstallmentAmount = FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FAGetValue().Trim();
                Support.AreEqual("?", AnnualTaxInstallmentAmount, true);
                FastDriver.BottomFrame.Reset();
                FastDriver.BottomFrame.Done();
                #endregion

                #endregion

            }

            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }

        }
        #endregion

        #region Test FMUC0004_REG0018

        /// <summary>
        /// FieldDefinitions: Verifying for Field definitions.
        /// </summary>
        ///
        [TestMethod]
        public void FMUC0004_REG0018()
        {
            try
            {
                Reports.TestDescription = "Verifying for Field definitions.";

                #region Data Setup
                var PropertyInfoName = string.Empty;
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                Reports.TestStep = "Save the Poperty information Name from FHP.";
                FastDriver.FileHomepage.Open();
                PropertyInfoName = FastDriver.FileHomepage.PropertyName.FAGetValue().ToString().Trim();
                #endregion

                #region
                Reports.TestStep = "Navigate to PTI screen & Verify for the field definitions fields.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", PropertyInfoName, "Property Name", TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralTab.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Fields def for General tab.";

                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.Clear();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJ" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHI", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().ToString().Trim(), true);

                string PropertyTypePTIactual = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText().ToString().Trim();
                //string PropertyTypePTIexpected = "Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other";
                string PropertyTypePTIexpected = "Single Family Residence Multi Family Residence Condominium Agricultural Land Apartment Building Church/Religious Facility Commercial Structure Communication Site Convenience Store/Market Convention Facility Co-op Educational Facility Energy Facility Entertainment/Theatre Farm w/Homesite Golf Course Government Facility Health Care Facility Hotel/Motel Industrial Manufactured Home Mobile Home Office Personal Property Petroleum/Oil Company Planned Unit Development Restaurant/Fast Food Retail Self Storage Sports Facility/Stadium Timber Land Townhouse Transportation Facility Vacant Land Other";
                Support.AreEqual(PropertyTypePTIexpected.Trim(), PropertyTypePTIactual.Trim(), true);

                Support.AreEqual("ALBANY", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().ToString().Trim(), true);

                string StatesPTIactual = FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetText().ToString().Trim(); ;
                string StatesPTIexpected = "AA AE AK AL AP AR AS AZ CA CO CT DC DE FL FM GA GU HI IA ID IL IN KS KY LA MA MD ME MH MI MN MO MP MS MT NC ND NE NH NJ NM NV NY OH OK OR PA PR PW RI SC SD TN TX UT VA VI VT WA WI WV WY";
                Support.AreEqual(StatesPTIexpected.Trim(), StatesPTIactual.Trim(), true);

                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.Clear();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASendKeys("111111111" + FAKeys.Tab);
                Support.AreEqual(@"11111-1111", FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FAGetValue().ToString().Trim(), true);

                string CountryPTIactual = FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCountry.FAGetText().ToString().Trim(); ;
                string CountryPTIexpected = "USA CANADA AFGHANISTAN ALBANIA ALGERIA AMERICANSAMOA ANDORRA ANGOLA ANGUILLA ANTARCTICA ANTIGUA AND BARBUDA ARGENTINA ARMENIA ARUBA ASHMORE AND CARTIER ISLANDS AUSTRALIA AUSTRIA AZERBAIJAN BAHAMAS BAHRAIN BAKER ISLAND BANGLADESH BARBADOS BASSAS DA INDIA BELGIUM BELIZE BENIN BERMUDA BHUTAN BOLIVIA BONAIRE BOSNIA AND HERZEGOVINA BOTSWANA BOUVET ISLAND BRAZIL BRITISH INDIAN OCEAN TERRITORY BRITISH VIRGIN ISLANDS BRUNEI BULGARIA BURKINA FASO BURUNDI CAMBODIA CAMEROON CAPE VERDE CAYMAN ISLANDS CENTRAL AFRICAN REPUBLIC CHAD CHILE CHINA CHRISTMAS ISLAND CLIPPERTON ISLAND COCOS (KEELING) ISLANDS COLOMBIA COMOROS CONGO, DEMOCRATIC REPUBLIC OF THE COOK ISLANDS CORAL SEA ISLANDS COSTA RICA CROATIA CURACAO CYPRUS CZECH REPUBLIC DENMARK DJIBOUTI DOMINICA DOMINICAN REPUBLIC EAST TIMOR ECUADOR EGYPT EL SALVADOR EQUATORIAL GUINEA ERITREA ESTONIA ETHIOPIA EUROPA ISLAND FALKLAND ISLANDS (ISLAS MALVINAS) FAROE ISLANDS FIJI FINLAND FRANCE FRENCH GUIANA FRENCH POLYNESIA FRENCH SOUTHERN AND ANTARCTIC LANDS GABON GAMBIA, THE GAZA STRIP GERMANY GHANA GIBRALTAR GLORIOSO ISLANDS GREECE GREENLAND GRENADA GUADELOUPE GUATEMALA GUERNSEY GUINEA GUINEA-BISSAU GUYANA HAITI HEARD ISLAND AND MCDONALD ISLANDS HOLY SEE (VATICAN CITY) HONDURAS HONG KONG HOWLAND ISLAND HUNGARY ICELAND INDIA INDONESIA IRELAND ISRAEL ITALY JAMAICA JAN MAYEN JAPAN JARVIS ISLAND JERSEY JOHNSTON ATOLL JORDAN JUAN DE NOVA ISLAND KAZAKHSTAN KENYA KINGMAN REEF KIRIBATI KUWAIT KYRGYZSTAN LAOS LATVIA LESOTHO LIBERIA LIECHTENSTEIN LITHUANIA LUXEMBOURG MACAU MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF MADAGASCAR MALAWI MALAYSIA MALDIVES MALI MALTA MAN, ISLE OF MARTINIQUE MAURITANIA MAURITIUS MAYOTTE MEXICO MICRONESIA, FEDERATED STATES OF MIDWAY ISLANDS MOLDOVA MONACO MONGOLIA MONTSERRAT MOROCCO MOZAMBIQUE NAMIBIA NAURU NAVASSA ISLAND NEPAL NETHERLANDS NETHERLANDS ANTILLES NEW CALEDONIA NEW ZEALAND NICARAGUA NIGER NIGERIA NIUE NORFOLK ISLAND NORWAY OMAN PAKISTAN PALMYRA ATOLL PANAMA PAPUA NEW GUINEA PARACEL ISLANDS PARAGUAY PERU PHILIPPINES PITCAIRN ISLANDS POLAND PORTUGAL PUERTO RICO QATAR REUNION ROMANIA RUSSIA RWANDA SABA SAINT HELENA SAINT KITTS AND NEVIS SAINT LUCIA SAINT PIERRE AND MIQUELON SAINT VINCENT AND THE GRENADINES SAMOA SAN MARINO SAO TOME AND PRINCIPE SAUDI ARABIA SENEGAL SERBIA AND MONTENEGRO SEYCHELLES SIERRA LEONE SINGAPORE SINT EUSTATIUS SINT MAARTEN SLOVAKIA SLOVENIA SOLOMON ISLANDS SOUTH AFRICA SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS SOUTH KOREA SPAIN SPRATLY ISLANDS SRI LANKA ST. BARTHELEMY ST. MARTIN SURINAME SVALBARD SWAZILAND SWEDEN SWITZERLAND TAIWAN TAJIKISTAN TANZANIA THAILAND TOGO TOKELAU TONGA TRINIDAD AND TOBAGO TROMELIN ISLAND TUNISIA TURKEY TURKMENISTAN TURKS AND CAICOS ISLANDS TUVALU U.S. VIRGIN ISLANDS UGANDA UKRAINE UNITED ARAB EMIRATES UNITED KINGDOM URUGUAY UZBEKISTAN VANUATU VENEZUELA VIETNAM WAKE ISLAND WALLIS AND FUTUNA WEST BANK WESTERN SAHARA ZAMBIA";
                Support.AreEqual(CountryPTIexpected.Trim(), CountryPTIactual.Trim(), true);

                Reports.TestStep = "Fields def for Legal Description Tab.";

                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoLegalDesciption.Lot.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912ABCD" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Block.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Block.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Unit.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912ABCD" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Tract.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Tract.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Building.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Building.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Building.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Book.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Book.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Book.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Page.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Page.FASendKeys("ABCDEFGHIJQWQERHSADKBKBA" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJ", FastDriver.PropertyTaxInfoLegalDesciption.Page.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Section.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Section.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Section.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.TownShip.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Range.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Range.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.Range.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Parcel.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Phase.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Phase.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912ABCD" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912", FastDriver.PropertyTaxInfoLegalDesciption.Phase.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.GovtLotNo.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.GovtLotNo.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.GovtLotNo.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Borough.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Borough.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912ABCD" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912", FastDriver.PropertyTaxInfoLegalDesciption.Borough.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.Province.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.Province.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912ABCD" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912", FastDriver.PropertyTaxInfoLegalDesciption.Province.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.CountyParish.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.CountyParish.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912ABCD" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD12345678912345678912", FastDriver.PropertyTaxInfoLegalDesciption.CountyParish.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.RecordingBook.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.RecordingBook.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.RecordingBook.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.RecordingPage.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.RecordingPage.FASendKeys("ABCDEFGHIJQWQERHSADKBKBA" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJ", FastDriver.PropertyTaxInfoLegalDesciption.RecordingPage.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapNo.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapNo.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapNo.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingBook.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingBook.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingBook.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingPage.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingPage.FASendKeys("ABCDEFGHIJQWQERHSADKBKBA" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJ", FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingPage.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingMapNo.Clear();
                FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingMapNo.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDardfasdfadsa" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRST", FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingMapNo.FAGetValue().ToString().Trim(), true);

                Reports.TestStep = "Fields def for Tax Tab.";

                FastDriver.PropertyTaxInfoLegalDesciption.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASendKeys("ABCDEFGHIJKLMNOPQRSTABCDERTYUI123456456789025AETERF" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTABCDERTYUI123456456789025", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASendKeys(@"2009-2010" + FAKeys.Tab);
                Support.AreEqual(@"2009-2010", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.FASendKeys("ABCDEFGHIJKLMNOPQRSTABCDERTYUI123456456" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTABCDERTYUI", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo1.FASendKeys("ABCDEFGHIJKLMNOPQRSTABCDERTYUI123456456" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTABCDERTY", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo2.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo2.FASendKeys("ABCDEFGHIJKLMNOPQRSTABCDERTYUI123456456" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTABCDERTY", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo2.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo3.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo3.FASendKeys("ABCDEFGHIJKLMNOPQRSTABCDERTYUI123456456" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTABCDERTY", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo3.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo4.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo4.FASendKeys("ABCDEFGHIJKLMNOPQRSTABCDERTYUI123456456" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTABCDERTY", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo4.FAGetValue().ToString().Trim(), true);

                string AnnualTaxStatus1actual = FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus1.FAGetText().ToString().Trim(); ;
                string AnnualTaxStatus1expected = "ARREARS CANCELLED DEFAULTED REDEEMED PAYABLE OPEN DUE INACTIVE NOTAXDUE Not Billed OVERPAID REFUND PAID PAIDWPEN DELINQUENT UNKNOWN";
                Support.AreEqual(AnnualTaxStatus1expected.Trim(), AnnualTaxStatus1actual.Trim(), true);

                string AnnualTaxStatus2actual = FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus2.FAGetText().ToString().Trim(); ;
                string AnnualTaxStatus2expected = "ARREARS CANCELLED DEFAULTED REDEEMED PAYABLE OPEN DUE INACTIVE NOTAXDUE Not Billed OVERPAID REFUND PAID PAIDWPEN DELINQUENT UNKNOWN";
                Support.AreEqual(AnnualTaxStatus2expected.Trim(), AnnualTaxStatus2actual.Trim(), true);

                string AnnualTaxStatus3actual = FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus3.FAGetText().ToString().Trim(); ;
                string AnnualTaxStatus3expected = "ARREARS CANCELLED DEFAULTED REDEEMED PAYABLE OPEN DUE INACTIVE NOTAXDUE Not Billed OVERPAID REFUND PAID PAIDWPEN DELINQUENT UNKNOWN";
                Support.AreEqual(AnnualTaxStatus3expected.Trim(), AnnualTaxStatus3actual.Trim(), true);

                string AnnualTaxStatus4actual = FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus4.FAGetText().ToString().Trim(); ;
                string AnnualTaxStatus4expected = "ARREARS CANCELLED DEFAULTED REDEEMED PAYABLE OPEN DUE INACTIVE NOTAXDUE Not Billed OVERPAID REFUND PAID PAIDWPEN DELINQUENT UNKNOWN";
                Support.AreEqual(AnnualTaxStatus4expected.Trim(), AnnualTaxStatus4actual.Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate1.FASendKeys(@"11/13/2012" + FAKeys.Tab);
                Support.AreEqual(@"11/13/2012", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate2.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate2.FASendKeys(@"11/13/2012" + FAKeys.Tab);
                Support.AreEqual(@"11/13/2012", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate2.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate3.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate3.FASendKeys(@"11/13/2012" + FAKeys.Tab);
                Support.AreEqual(@"11/13/2012", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate3.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate4.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate4.FASendKeys(@"11/13/2012" + FAKeys.Tab);
                Support.AreEqual(@"11/13/2012", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate4.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASendKeys(@"12,345,689,741.25" + FAKeys.Tab);
                Support.AreEqual(@"12,345,689,741.25", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FAGetValue().ToString().Trim(), true);

                Thread.Sleep(5000);
                // FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInterest1.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInterest1.FASetText(@"12,345,689,741.25", false);
                Support.AreEqual(@"12,345,689,741.25", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInterest1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPenality1.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPenality1.FASetText(@"12,345,689,741.25", false);
                Support.AreEqual(@"12,345,689,741.25", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPenality1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxpartialPaymentAmount1.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxpartialPaymentAmount1.FASetText(@"12,345,689,741.25", false);
                Support.AreEqual(@"12,345,689,741.25", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxpartialPaymentAmount1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDatePaid1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDatePaid1.FASendKeys(@"11/13/2012" + FAKeys.Tab);
                Support.AreEqual(@"11/13/2012", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDatePaid1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDelinquentDate1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDelinquentDate1.FASendKeys(@"11/13/2012" + FAKeys.Tab);
                Support.AreEqual(@"11/13/2012", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDelinquentDate1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPaymentGoodThroughDate1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPaymentGoodThroughDate1.FASendKeys(@"11/13/2012" + FAKeys.Tab);
                Support.AreEqual(@"11/13/2012", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPaymentGoodThroughDate1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase1.FASendKeys("1234567894454564" + FAKeys.Tab);
                Support.AreEqual("1234567894", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase2.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase2.FASendKeys("1234567894454564" + FAKeys.Tab);
                Support.AreEqual("1234567894", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase2.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase3.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase3.FASendKeys("1234567894454564" + FAKeys.Tab);
                Support.AreEqual("1234567894", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase3.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase4.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase4.FASendKeys("1234567894454564" + FAKeys.Tab);
                Support.AreEqual("1234567894", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase4.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxAssesmentDate1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxAssesmentDate1.FASendKeys(@"11/13/2012" + FAKeys.Tab);
                Support.AreEqual(@"11/13/2012", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxAssesmentDate1.FAGetValue().ToString().Trim(), true);

                Thread.Sleep(5000);
                // FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue1.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue1.FASetText(@"99,999,999,999.999", false);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue2.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue2.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue2.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue3.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue3.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue3.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue4.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue4.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue4.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue1.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue2.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue2.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue2.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue3.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue3.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue3.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue4.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue4.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue4.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue1.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue2.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue2.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue2.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue3.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue3.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue3.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue4.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue4.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue4.FAGetValue().ToString().Trim(), true);

                Support.AreEqual(@"199,999,999,999.98", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxNetValue1.FAGetValue().ToString().Trim(), true);
                Support.AreEqual(@"199,999,999,999.98", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxNetValue2.FAGetValue().ToString().Trim(), true);
                Support.AreEqual(@"199,999,999,999.98", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxNetValue3.FAGetValue().ToString().Trim(), true);
                Support.AreEqual(@"199,999,999,999.98", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxNetValue4.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner1.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner1.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner1.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner2.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner2.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner2.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner3.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner3.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner3.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner4.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner4.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner4.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther11.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther11.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther11.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther12.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther12.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther12.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther13.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther13.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther13.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther14.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther14.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther14.FAGetValue().ToString().Trim(), true);

                Thread.Sleep(5000);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                if (FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.FAGetValue().ToString().Trim() == "0.00")
                {
                    FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.Clear();
                    FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                }

                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther22.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther22.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther22.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther23.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther23.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther23.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther24.Clear();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther24.FASendKeys(@"99,999,999,999.999" + FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther24.FAGetValue().ToString().Trim(), true);

                FastDriver.BottomFrame.Reset();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Validate short cut keys for New and Remove in Tax Tab.";
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                Keyboard.SendKeys("%N");
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("123445487" + FAKeys.Tab);

                Keyboard.SendKeys("%R");

                Reports.TestStep = "Confirm Remove.";
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Fields def for Title production tab.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", PropertyInfoName, "Property Name", TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TitleProductionTab.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad(FastDriver.PropertyTaxInfoTitleProd.TitleProductionPlanEffactiveDate);

                FastDriver.PropertyTaxInfoTitleProd.TitleProductionPlanEffactiveDate.FASendKeys(@"11-13-2012" + FAKeys.Tab);
                Support.AreEqual(@"11-13-2012", FastDriver.PropertyTaxInfoTitleProd.TitleProductionPlanEffactiveDate.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoTitleProd.TitleProductionAmendUpdateDetails.Clear();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionAmendUpdateDetails.FASendKeys("ASDFG12365ASDFG12365ASDFG12365ASDFG12365ADFS" + FAKeys.Tab);
                Support.AreEqual("ASDFG12365ASDFG12365ASDFG12365ASDFG12365", FastDriver.PropertyTaxInfoTitleProd.TitleProductionAmendUpdateDetails.FAGetValue().ToString().Trim(), true);

                FastDriver.PropertyTaxInfoTitleProd.TitleProductionTitleMortgageInsuranceClause.Clear();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionTitleMortgageInsuranceClause.FASendKeys("ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASD" + FAKeys.Tab);
                Support.AreEqual("ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASDFG12365ASD", FastDriver.PropertyTaxInfoTitleProd.TitleProductionTitleMortgageInsuranceClause.FAGetValue().ToString().Trim(), true);

                Support.AreEqual("true", FastDriver.PropertyTaxInfoTitleProd.TitleProductionEstateInterest.IsEnabled().ToString().Trim().ToLower(), true);
                Support.AreEqual("true", FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.IsEnabled().ToString().Trim().ToLower(), true);
                Support.AreEqual("true", FastDriver.PropertyTaxInfoTitleProd.TitleProductionRequirements.IsEnabled().ToString().Trim().ToLower(), true);
                Support.AreEqual("true", FastDriver.PropertyTaxInfoTitleProd.TitleProductionInformationalNotes.IsEnabled().ToString().Trim().ToLower(), true);

                FastDriver.PropertyTaxInfoTitleProd.ExceptionRequestInformationSave.FAClick();
                Thread.Sleep(5000);

                Reports.TestStep = "Fields def for buttons in General tab.";
                FastDriver.PropertyTaxInfoTitleProd.GeneralTab.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Keyboard.SendKeys("%S");
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                Keyboard.SendKeys("%N");
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Street new");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("ALBANY");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("CA");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("ALAMEDA");
                Keyboard.SendKeys("%R");
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.BottomFrame.Reset();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                Keyboard.SendKeys("%R");
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }

        }

        #endregion

        #region Test FMUC0004_REG0019

        /// <summary>
        /// FM13285_FM13589_EWC22: Prevent Parameter Changes ( FINAL/FINALDJ Invoice).
        /// </summary>
        ///
        [TestMethod]
        public void FMUC0004_REG0019()
        {
            try
            {
                Reports.TestDescription = "FM13285_FM13589_EWC22: Prevent Parameter Changes ( FINAL/FINALDJ Invoice).";

                #region Data Setup
                string CD_FeesName = "Eagle Lender Policy - 1";
                string HUD_FeesName = "1064_Title_Lender_Policy";
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion


                #region Enter charges to New loan.
                Reports.TestStep = "Enter charges to New loan.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("300000000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                #endregion

                #region In Fee entry screen Select All fee checkbox & Click on Calculate Fees button.
                Reports.TestStep = "In Fee entry screen Select All fee checkbox & Click on Calculate Fees button.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();
                Thread.Sleep(10000);

                Reports.TestStep = "Select a Fee and click on next.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesAdd);
                FastDriver.CalculateFees.SelectTitleProduct(@"ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.PerformAddTitleProducts();

                Reports.TestStep = "Calculate Recording Fee Deed.";
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Deed");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("3");
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select for FAST Fee description - View More.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.ClickNext();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryFastFeeDescription.Click();
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASendKeys("+" + FAKeys.Tab);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable);
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.FileFeesDlg.FeesTable.PerformTableAction("Description", CD_FeesName, "Sel", TableAction.On);
                }
                else
                {
                    FastDriver.FileFeesDlg.FeesTable.PerformTableAction("Description", HUD_FeesName, "Sel", TableAction.On);
                }
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Select for FAST Fee description ( Recording Fee ) - View More.";
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryFastFeeDescription2.Click();
                FastDriver.CalculateFees.SummaryFastFeeDescription2.FASendKeys("+" + FAKeys.Tab);

                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem("Recording Fee - Deed");
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText("Record Deed");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable);
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction("Description", "Record Deed", "Sel", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryChargeTo.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryChargeTo2.FASelectItem("Buyer");

                FastDriver.CalculateFees.SummaryFastFeeDescription3.FASelectItem("Record Deed");
                FastDriver.CalculateFees.SummaryChargeTo3.FASelectItem("Buyer");

                FastDriver.CalculateFees.SummaryFastFeeDescription4.FASelectItem("Record Deed");
                FastDriver.CalculateFees.SummaryChargeTo4.FASelectItem("Buyer");
                #endregion

                Reports.TestStep = "check the first fee.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                if (FastDriver.InvoiceFees.FeeSummarygrid.Selected.ToString() == "False")
                {
                    FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);
                }

                string Enb = FastDriver.InvoiceFees.Final.Enabled.ToString();
                if (Enb == "True")
                {
                    FastDriver.InvoiceFees.Final.Click();
                }
                else
                {
                    Support.AreEqual("False", FastDriver.InvoiceFees.Final.Enabled.ToString());
                }
                //////////////////////////////////////////////////////////////
                #region Validate the message for change of property address.
                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and validate the property/tax info details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASendKeys("Test" + FAKeys.Tab);

                string ExpErrMsg = "Property is associated with a fee that is part of FINAL/FINALADJ invoice. City information cannot be modified.";
                string ActualMsg = FastDriver.WebDriver.HandleDialogMessage(true, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg.Trim(), ActualMsg, true);
                FastDriver.BottomFrame.Save();

                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASendKeys("GA" + FAKeys.Tab);

                Reports.TestStep = "Validate that when Property is associated with a fee that is part of finalized invoice, State and County Information cannot be modified";
                string ExpErrMsg1 = "Property is associated with a fee that is part of finalized invoice. State and County Information cannot be modified.";
                string ActualMsg1 = FastDriver.WebDriver.HandleDialogMessage(false, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg1.Trim(), ActualMsg1, true);
                FastDriver.BottomFrame.Save();
                #endregion
                //FastDriver.PropertyTaxInfoGeneral.ClickTitleProdTab();
                //FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                //FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptionsRegion.FASelectItemBySendingKeys(AutoConfig.SelectedRegionName);
                //Keyboard.SendKeys(FAKeys.TabAway);

                //FastDriver.PropertyTaxInfoTitleProd.GeneralTab.FAClick();
                //FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                //FastDriver.WebDriver.HandleDialogMessage();
                //FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                //FastDriver.BottomFrame.Reset();


            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }

        }

        #endregion

        #region Test FMUC0004_REG0020_PH

        [TestMethod]

        public void FMUC0004_REG0020_PH()
        {
            Reports.TestDescription = "FM4191: FASTSearch Site ID.";
            Reports.StatusUpdate("Test case Description and implementation seems to be irrelevent. Consider this test case as N/A", false);
        }
        #endregion

        #region Test FMUC0004_REG0021

        [TestMethod]

        public void FMUC0004_REG0021()
        {
            try
            {
                Reports.TestDescription = "FM13588_FM13590_EWC14: Retain State for Disbursed Fees, Delete a Property.";

                #region Data Setup
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion


                Reports.TestStep = "Enter file number and click on Find";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);


                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry");

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99"); //There are three hidden columns between buyers and sellers charge columns
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "2.99"); //There are three hidden columns between buyers and sellers charge columns
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Active Disbursement Summary screeen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickCancel();

                #region Create another new property without any associated fee.
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("s1");
                PropertyAddressParameters Info = new PropertyAddressParameters()
                {
                    StreetLine1 = "s1",
                    StreetLine2 = "s2",
                    StreetLine3 = "s3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var addressInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                // FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(addressInfo);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                #endregion

                Reports.TestStep = "Navigate to properties/tax info summary screen, Delete 2nd property added.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "s1", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Delete property and validate the error message.";
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Remove.FAClick();
                string ActualErr = FastDriver.WebDriver.HandleDialogMessage(true, true).ToString().Trim(); ;
                string ExpErr = "Property State is associated with a Fee and cannot be deleted.";
                Support.AreEqual(ExpErr, ActualErr, true);

                Reports.TestStep = "Create new property.";
                Reports.TestStep = "Navigate to Properties/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on New and navigate to General tab ";
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.SwitchToContentFrame();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Reports.TestStep = "Enter the property details";
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("street1");
                PropertyAddressParameters Info1 = new PropertyAddressParameters()
                {
                    StreetLine1 = "street1",
                    StreetLine2 = "street2",
                    StreetLine3 = "street3",
                    City = "santa ana",
                    State = "CA",
                    County = "Orange",

                };
                FastDriver.PropertyTaxInfoGeneral.FillPropertyGeneralInfoForm(Info1);

                Reports.TestStep = "Navigate to Legal description Tab";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Enter the details";
                var AddrInfo = new PropertyAddressParameters()
                {

                    Lot = "lot1",
                    Block = "block1",
                    Unit = "unit1"

                };
                FastDriver.PropertyTaxInfoLegal.FillPropertyLegalInfoForm(AddrInfo);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Navigate to properties/tax info summary screen, Delete 2nd property added.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "street1", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Remove.FAClick();
                Support.AreEqual("Do you wish to delete the selected property?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                ////////////////////////////////////
                //FastDriver.PropertyTaxInfoLegal.ClickTaxTab();
                //FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                //FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                //FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                //FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("Prop1APN1");
                //Keyboard.SendKeys(FAKeys.TabAway);
                ///////////////////////////////////
                //FastDriver.BottomFrame.Save();
                //FastDriver.WebDriver.HandleDialogMessage(true, true);
                //FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                //Reports.TestStep = "Add Tax Information.";
                //FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                //FastDriver.PropertiesSummary.SwitchToContentFrame();

                //FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "street1", 2, TableAction.Click);
                //FastDriver.PropertiesSummary.Edit.FAClick();
                //FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                //FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                //FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();

                //FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "Prop1APN1", 1, TableAction.Click);
                //FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();

                //FastDriver.PropertyTaxInfoAnnualTax.Remove.FAClick();
                //Support.AreEqual("Do you wish to delete Tax/APN No.Prop1APN1?", FastDriver.WebDriver.HandleDialogMessage(true, true).ToString());

                //FastDriver.PropertyTaxInfoAnnualTax.SwitchToContentFrame();
                //FastDriver.PropertyTaxInfoAnnualTax.GeneralTab.FAClick();
                //FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                //FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("");
                //Keyboard.SendKeys(FAKeys.TabAway);
                //FastDriver.PropertyTaxInfoGeneral.SwitchToBottomFrame();
                //FastDriver.BottomFrame.Save();
                //FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                //FastDriver.BottomFrame.Done();


            }

            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }

        }

        #endregion

        #region Test FMUC0004_REG0022_PH

        [TestMethod]
        public void FMUC0004_REG0022_PH()
        {

            Reports.TestDescription = "10527_10528_13285_13197_13199_13200_6879_8059_4218_13201_13202_13203_13204_13205_7892_IF13196: Update Property via Client Web Service XML from Service Partner.";
            Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
            Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

        }
        #endregion

        #region Test FMUC0004_REG0023_PH
        [TestMethod]

        public void FMUC0004_REG0023_PH()
        {
            Reports.TestDescription = "13206_13207_13208_13209_13825_13826_8054_8055_8056_8057_8058_13210_13211_13212_13213_13214_13215: Populate Complete Legal Description from ATP Results.";
            Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
            Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
        }

        #endregion

        #region Test FMUC0004_REG0024
        /// <summary>
        /// FD:Pay at Close hot key action
        /// </summary>
        [TestMethod]

        public void FMUC0004_REG0024()
        {
            try
            {
                Reports.TestDescription = "FD:Pay at Close hot key action";

                #region DATA SETUP
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add Tax ID APN.
                Reports.TestStep = "Add Tax ID APN.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("Prop1APN1");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                #endregion

                #region Validate that by default the pay to close button is disabled
                Reports.TestStep = "Navigate to properties/tax info summary screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the entry and edit the details";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();


                Reports.TestStep = "Navigate to property tax info screen ";
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "Prop1APN1", 1, TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();

                Reports.TestStep = "check the Disabled status of PayAtClose";//Correct the step, commented out the old and add new
                string PayAtCloseEnableStatus = FastDriver.PropertyTaxInfoAnnualTax.PayAtClose.IsEnabled().ToString();
                Support.AreEqual("False", PayAtCloseEnableStatus, true);

                Reports.TestStep = "Enter due date, status, tax year and check the generate tax check";
                FastDriver.PropertyTaxInfoAnnualTax.GenerateTaxCheck.FASetCheckbox(true);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("2010-2011");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus1.FASelectItemBySendingKeys("ARREARS");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus2.FASelectItemBySendingKeys("ARREARS");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus3.FASelectItemBySendingKeys("ARREARS");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus4.FASelectItemBySendingKeys("ARREARS");

                string FutDate = DateTime.Today.AddDays(Convert.ToInt32("2")).ToDateString();

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate1.FASetText(FutDate);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate2.FASetText(FutDate);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate3.FASetText(FutDate);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate4.FASetText(FutDate);

                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASetText("500");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount2.FASetText("500");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount3.FASetText("500");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount4.FASetText("500");
                FastDriver.PropertyTaxInfoAnnualTax.GenerateTaxCheck.FASetCheckbox(true);
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the pay to close is enabled";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
               
                FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "Prop1APN1", 1, TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();

                //commented out the old and add new
                Support.AreEqual(true, FastDriver.PropertyTaxInfoAnnualTax.PayAtClose.IsEnabled(), "true"); 
                
                //PayAtCloseEnableStatus = FastDriver.PropertyTaxInfoAnnualTax.PayAtClose.IsEnabled().ToString();
                //Support.AreEqual("True", PayAtCloseEnableStatus, true);
                Support.AreEqual("2,000.00", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTotalInstallmentTax.FAGetValue().ToString().Trim());
                #endregion

            }

            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0004_REG0025

        /// <summary>
        /// FM14768  FASTSearch Result with No Tax Year  
        /// </summary>
        /// 
        [TestMethod]

        public void FMUC0004_REG0025()
        {
            try
            {
                Reports.TestDescription = "FM14768: FASTSearch Result with No Tax Year.";

                #region DataSetup
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File without property using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add Tax ID APN.
                Reports.TestStep = "Add Tax ID APN.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("TestAPN1");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                #endregion

                #region Verifying for the Fast Search Completed event
                Reports.TestStep = "Click on GeneralTab FASTSearch field";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralFASTSearch.FAClick();
                Reports.StatusUpdate("Clicked on GeneralFASTSearch field.", true);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

                Reports.TestStep = "Verifying for the Fast Search Completed event";
                FastDriver.EventTrackingLog.Open();
                for (int i = 1; i <= 10; i++)
                {
                    string EventStatus = FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToString().Trim();
                    if (EventStatus == "[FS Request Completed]")
                    {
                        Reports.StatusUpdate("FASTSearch returns a result with no APN and no Tax Year For APN without Tax year.", true);
                        break;
                    }
                    else
                    {
                        Thread.Sleep(20000);
                        if (i == 10)
                        {
                            Reports.StatusUpdate("FASTSearch does not return a result with no APN and no Tax Year For APN without Tax year.", false);
                        }
                        FastDriver.EventTrackingLog.Open();
                    }
                }
                //string EventTrack = FastDriver.EventTrackingLog.EventTable.FAGetText().ToString();
                //int count = 1;
                //while (EventTrack.Contains(@"[FS Request Completed]").ToString() == "False")
                //{
                //    Thread.Sleep(30000);
                //    FastDriver.EventTrackingLog.Open();
                //    string EventTrack2 = FastDriver.EventTrackingLog.EventTable.GetAttribute("InnerText").ToString();
                //    if (EventTrack2.Contains(@"[FS Request Completed]").ToString() == "True")
                //    {
                //        string SearchComments = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", @"[FS Request Submitted]", "Comments", TableAction.GetAttribute, "value").Message.ToString();
                //        // Check in Detail this
                //        if (SearchComments.Contains("").ToString() == "False")
                //        {
                //            Reports.StatusUpdate("FASTSearch returns a result with no APN and no Tax Year For APN without Tax year.", true);
                //        }
                //        else
                //        {
                //            Reports.StatusUpdate("FASTSearch returns a result with APN and Tax Year For APN without Tax year.", false);
                //        }
                //        break;
                //    }
                //    count++;
                //    if (count > 10)
                //    {
                //        Reports.StatusUpdate("Even after 5 minutes the Search request was not finished", false);
                //        break;
                //    }
                //}
                #endregion

                #region Verify that the TaxNo/APN is genertaed in Tax tab.
                Reports.TestStep = "Verify that the TaxNo/APN is genertaed in Tax tab.";
                Reports.TestStep = "Click on GeneralTab FASTSearch field";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.PerformActionOnSummaryTable(1, "TestAPN1", 1, TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                Support.AreEqual("TestAPN1", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FAGetValue().ToString().Trim(), true);

                #endregion

            }

            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0004_REG0026

        /// <summary>
        /// FM9650_IF13207_IF13206,FM9651,FM9652
        /// </summary>
        /// 
        [TestMethod]

        public void FMUC0004_REG0026()
        {
            try
            {
                Reports.TestDescription = "IF13207_IF13206.";

                #region DataSetup
                #endregion

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File without property using Web services
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region IF13206_APN Required
                Reports.TestStep = "IF13206_APN Required";
                Reports.TestStep = "Click on GeneralTab FASTSearch field";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.New);
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("2015");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.FASetText("19768");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo1.FASetText("55");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus1.FASelectItem("ARREARS");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate1.FASetText(DateTime.Today.AddDays(1).ToDateString());
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASetText("100");
                FastDriver.BottomFrame.Save();

                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                Support.AreEqual(@"Tax: A Tax ID/APN is required to save tax data.", FastDriver.PropertyTaxInfoAnnualTax.ErrorMsg.FAGetText().ToString().Trim(), true);
                #endregion

                #region IF13207_Multiple APNs
                Reports.TestStep = "Create APN 1";
                CreateAPN("9541");

                Reports.TestStep = "Create APN 2";
                FastDriver.PropertyTaxSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                CreateAPN("9542");

                Reports.TestStep = "Create APN 3";
                FastDriver.PropertyTaxSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                CreateAPN("9543");
                #endregion

                FastDriver.PropertyTaxSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, "J305", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable.PerformTableAction(@"Tax No/APN", "9541", @"Tax No/APN", TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable.PerformTableAction(@"Tax No/APN", "9542", @"Tax No/APN", TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable.PerformTableAction(@"Tax No/APN", "9543", @"Tax No/APN", TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);

            }

            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0004_REG0027
        /// <summary>
        /// FM14542_Prevent State Change if Policy Numbers Assigned or Unassigned,FM7791_Unincorporated
        /// </summary>
        /// 
        [TestMethod]
        public void FMUC0004_REG0027()
        {
            try
            {
                Reports.TestDescription = "FM14542_Prevent State Change if Policy Numbers Assigned or Unassigned,FM7791_Unincorporated ";

                #region Data Setup
                var value = string.Empty;
                #endregion

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #region Create file
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                Reports.TestStep = "FM14542_Creates a New Loan and and AgentNet policy number.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddRemoveProducts.FAClick();
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Extended Loan Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Small Loan");
                if (FastDriver.WebDriver.WaitForAlertToExist(10) == true)
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"500" + FAKeys.Tab);
                while (FastDriver.WebDriver.WaitForAlertToExist(10) == true)
                {
                    FastDriver.WebDriver.HandleDialogMessage(false, true);
                }
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText(@"500" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();


                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();

                try
                {
                    IWebElement element = FastDriver.WebDriver.FindElement(By.LinkText("Request Policy Number"));

                }
                catch (Exception)
                {
                    ADMLOGIN();
                    FastDriver.SecuritySelectRegionOffice.Open();
                    FastDriver.SecuritySelectRegionOffice.EnterBUID(@"1486");

                    Reports.TestStep = "Selects an Office and Click on New.";
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem(@"Active");
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction(2, "7878", 2, TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();

                    Reports.TestStep = "Checking for the Request Policy number Checkbox.";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.ANPolicyNumber.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    IISLOGIN();

                }
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber1);
                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number").WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem(@"First American Title Insurance Company");
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem(@"DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.WebDriver.FindElements(By.TagName("span")).FirstOrDefault(i => i.Text == "*ALTA Extended Loan Policy").FAClick();
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                if (FastDriver.RequestPolicyNumber.RequestNumber.IsEnabled().ToString().ToLower() == "true")
                {
                    FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                }
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RequestPolicyNumber.WaitForScreenToLoad();
                string RPNpolicy = FastDriver.RequestPolicyNumber.Table.PerformTableAction(1, 7, TableAction.GetText).Message.ToString();

                #region Create Documnets

                Reports.TestStep = "Create a Document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                CreateDocument("Title Reports", "Automation Test Title Report", "Automation Test Title Report", "CA");

                Reports.TestStep = "Select the Title Report Document and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); //(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Title Reports", "Type", TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Title report.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
                Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.EffectiveDate.FASetText(@"06-20-2012");
                FastDriver.DocumentInfo.Save.FAClick();
                Thread.Sleep(3000);

                Reports.TestStep = "Verify Document Information for Title report.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.DocumentDescription);
                Support.AreEqual(@"Automation Test Title Report", FastDriver.DocumentInfo.DocumentDescription.FAGetValue().Clean());
                Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.EffectiveDate.FAGetValue().Clean());

                Reports.TestStep = "Create a second document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); //(FastDriver.DocumentRepository.AddDocRep);
                CreateDocument("Lender Policy", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", "CA", multipleDocs: true);

                Reports.TestStep = "Select the Owner Policy and Click on Info Tab.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();

                Reports.TestStep = "Enter Document Information for Lender Policy.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
                Support.AreEqual(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FASetText(@"06-20-2012");
                FastDriver.DocumentInfo.TitlePolicyInfoSave.FAClick();
                Thread.Sleep(3000);

                Reports.TestStep = "Verify Document Information for Lender Policy.";
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerDescription);
                Support.AreEqual(@"LALTERNATE FLOW 3 - QTP - DO NOT TOUCH", FastDriver.DocumentInfo.LenderOwnerDescription.FAGetValue().Clean());
                FastDriver.DocumentInfo.WaitForScreenToLoad(FastDriver.DocumentInfo.LenderOwnerEffectiveDate);
                Support.AreEqual(@"06-20-2012", FastDriver.DocumentInfo.LenderOwnerEffectiveDate.FAGetValue().Clean());
                #endregion

                #region Finalize Document.

                Reports.TestStep = "Select the Lender Policy and Click on Edit for finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.AddDocRep);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                Thread.Sleep(2000);
                FastDriver.DocumentPreparationMenu.WaitForScreenToLoad();
                Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Thread.Sleep(2000);
                value = FastDriver.WebDriver.HandleDialogMessage();
                if (value == "Policy Number/Guarantee Number is required to finalize the document.")
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                    FastDriver.DocumentRepository.Info.FAClick();
                    FastDriver.DocumentRepository.WaitForElementToLoad(FastDriver.DocumentRepository.Save);
                    //Fixed Policy number issue : 16 Feb 2015
                    if (FastDriver.DocumentRepository.CheckPolicyNo.Exists())
                    {
                        if (!FastDriver.DocumentRepository.CheckPolicyNo.Selected)
                            FastDriver.DocumentRepository.CheckPolicyNo.FASetCheckbox(true);
                        if (FastDriver.DocumentRepository.AssignNum.Enabled)
                            FastDriver.DocumentRepository.AssignNum.FAClick();
                    }
                    else
                    {
                        FastDriver.DocumentRepository.PolicyNumber.FASetText(@"FILE1235");
                    }
                    FastDriver.DocumentRepository.Save.FAClick();
                    FastDriver.BottomFrame.Done();
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Lender Policy", "Type", TableAction.Click);
                    FastDriver.DocumentRepository.Edit.FAClick();
                    Thread.Sleep(2000);
                    FastDriver.DocumentPreparation.WaitForScreenToLoad();
                    Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Thread.Sleep(1000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Thread.Sleep(2000);
                }
                else if (value.Contains("Dialog not present"))
                {
                    Thread.Sleep(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("%o");
                    Thread.Sleep(2000); //must explicitely wait, no way to dynamically wait for these
                    Keyboard.SendKeys("z");
                    Thread.Sleep(2000);
                }

                Reports.TestStep = "Finalize Document.";
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                FastDriver.DocPrepTextEditorDlg.Note.FASetText(@"Finalized");

                Reports.TestStep = "Verify Finalized Document Data.";
                Support.AreEqual(@"Finalized", FastDriver.DocPrepTextEditorDlg.Note.FAGetValue().Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Thread.Sleep(2500);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 25);

                #endregion

                Reports.TestStep = "Changing the State on Property page";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASendKeys("GA" + FAKeys.Tab);

                Reports.TestStep = "Verify the error message1 when state is changed.";
                string ExpErrMsg1 = "File has AgentNet Policy Numbers. Please void all policy numbers and then you can change Property State.";
                string ActualMsg1 = FastDriver.WebDriver.HandleDialogMessage(false, true, 10).ToString().Trim();
                Support.AreEqual(ExpErrMsg1.Trim(), ActualMsg1, true);
            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }

        }


        #endregion

        #region Test FMUC0004_REG0028

        /// <summary>
        /// FM11637_FM11638_EWC18: Do not allow changing & removing state of first property address.
        /// </summary>
        /// 
        [TestMethod]

        public void FMUC0004_REG0028()
        {
            try
            {
                Reports.TestDescription = "PlaceHolders: FM7791,FM4218,FM6879,,FM9651,FM9652: These flows are not automated.";
                Reports.StatusUpdate("PlaceHolders: FM7791,FM4218,FM6879,,FM9651,FM9652: These flows are not automated.", false);
            }
            catch (Exception ex)
            {
                FailTest("Test Method failed due to " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0004_REG0029

        [TestMethod]
        public void FMUC0004_REG0029()
        {
            try
            {
                Reports.TestDescription = "To test Bug#756676 - Verify Property/Tax Info, Title Production tab Save button is working Fine.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion
                #region Working UI

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File.";
                createBasicFile();

                Reports.TestStep = "Navigate to Property/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();

                Reports.TestStep = "Click on Edit button";
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Title Production tab";
                FastDriver.PropertyTaxInfoGeneral.TitleProductionTab.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();

                Reports.TestStep = "Complete Exceptions/Requirements/Informational Notes fields (*E/1, *B/1 ; R/7; INFO/11) respectevely";
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.FASetText("*E/1,*B/1");
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionRequirements.FASetText("R/7");
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionInformationalNotes.FASetText("INFO/11");

                Reports.TestStep = "Click on Save button";
                FastDriver.PropertyTaxInfoTitleProd.ExceptionRequestInformationSave.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Property/Tax Info screen";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();

                Reports.TestStep = "Click on Edit button";
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Title Production tab";
                FastDriver.PropertyTaxInfoGeneral.TitleProductionTab.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();

                Reports.TestStep = "Verified Exceptions/Requirements/Informational Notes Codes as expected";
                Support.AreEqual("*E/1,*B/1", FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.FAGetValue().Clean());
                Support.AreEqual("R/7", FastDriver.PropertyTaxInfoTitleProd.TitleProductionRequirements.FAGetValue().Clean());
                Support.AreEqual("INFO/11", FastDriver.PropertyTaxInfoTitleProd.TitleProductionInformationalNotes.FAGetValue().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #endregion

        #region TC804131 ADM side: Offices setup, added a NEW check box titled "Launch Fast Search on Open Order", default to "checked", with the ability for Admins to uncheck at their discretion
        [TestMethod]
        public void FMUC0004_REG0030()
        {
            int fileID = 0;
            try
            {
                Reports.TestDescription = "ADM side: Offices setup, added a NEW check box titled Launch Fast Search on Open Order, default to checked, with the ability for Admins to uncheck at their discretion";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();

                #region UI Iteration

                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                               
                Reports.TestStep = "Navigate to Home Regions and to the tetsing office";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Reports.TestStep = "Select an Office";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                Reports.TestStep = "Set the Launch Fast Search on Open Order checkbox back to default as checked";
                if (!FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.Selected) ;
                FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Home Regions and to the tetsing office";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                Reports.TestStep = " Validate that a Launch Fast Search on Open Order checkbox is added to the office set-up screen for all regions and that it is enabled";
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.IsEnabled();//Launch_Fast_Search_on_Open_Order in OfficeSeup.cs
                FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.IsSelected();
                Support.AreEqual(true, FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.IsEnabled(), "Launch Fast Search on Open Order checkbox is enabled");

                Reports.TestStep = "Uncheck the Launch Fast Search on Open Order checkbox";
                FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select an Office";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();

                Reports.TestStep = " Launch Fast Search on Open Order checkbox is not checked";
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                Support.AreEqual(false, FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.IsSelected(), "Launch Fast Search on Open Order checkbox is not checked");

                Reports.TestStep = "Set the Launch Fast Search on Open Order checkbox back to default as checked";
                FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select an Office";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();

                Reports.TestStep = " Validate that a Launch Fast Search on Open Order checkbox is added to the office set-up screen for all regions and that it is defaulted to checked";
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.IsEnabled();
                FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.IsSelected();
                Support.AreEqual(true, FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.IsSelected(), "Launch Fast Search on Open Order checkbox is checked");

                //Test Case 804155:File side QFE: If "Launch Fast Search on Open Order" is CHECKED FAST, evoke FASTSearch when a user enters in those required criterias
                Reports.TestStep = "File side QFE: If Launch Fast Search on Open Order is CHECKED FAST, evoke FASTSearch when a user enters in those required criterias";
                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileID = (int)FileService.CreateFile(fileRequest).FileID;
                var File = FileService.GetOrderDetails(fileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Event/Tracking Log screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();

                Reports.TestStep = "Verify that there is [Fast Search Initiated] that evoked at the same time with [Opened] order";
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fast Search Initiated]", 5, TableAction.GetText).Message.Clean().Contains("FASTSearch Request Initiated. FAST File ID=").ToString());
                #endregion
            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion

              
        
        #region TC804158 File side QFE: If "Launch Fast Search on Open Order" is UNCHECKED FAST does not evoke FASTSearch when a user enters in those required criterias
        [TestMethod]
        public void FMUC0004_REG0031()
        {
            int fileID = 0;
            try
            {
                Reports.TestDescription = "File side QFE: If Launch Fast Search on Open Order is UNCHECKED FAST does not evoke FASTSearch when a user enters in those required criterias";

                #region Fast Search Setting
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();
                #endregion

                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();

                #region UI Iteration

                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Home Regions and to the tetsing office";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                Reports.TestStep = "Uncheck the Launch Fast Search on Open Order checkbox";
                if (FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.Selected) ;
                FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();

                Reports.TestStep = " verify launch fast search on open order checkbox is not checked";
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                Support.AreEqual(false, FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.IsSelected(), "launch fast search on open order checkbox is not checked");


                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileID = (int)FileService.CreateFile(fileRequest).FileID;
                var File = FileService.GetOrderDetails(fileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Event/Tracking Log screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();

                Reports.TestStep = "Verify that there is NO [Fast Search Initiated] that evoked at the same time with [Opened] order";
                Support.AreEqual(false, FastDriver.EventTrackingLog.EventTable.StringExistOnTable("Fast Search Initiated"), "NO [Fast Search Initiated] that evoked at the same time with [Opened] order");
                //TC804167 Unchecking the "Launch Fast Search on Open Order" that has no impact on all other search capabilities in FAST.

                Reports.TestStep = "TC804167 Unchecking the Launch Fast Search on Open Order that has no impact on all other search capabilities in FAST.";
                Reports.TestStep = "Nav to Properties/Tax Info to launch FASTSearch";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertyName1.FAClick();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralFASTSearch.FAClick();


                Reports.TestStep = "Navigate to Event/Tracking Log screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();

                Reports.TestStep = "Verify that there is [Fast Search Initiated] that evoked at the same time with [Opened] order";
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fast Search Initiated]", 5, TableAction.GetText).Message.Clean().Contains("FASTSearch Request Initiated. FAST File ID=").ToString());

                #endregion
            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion
              

        #region FMUC0004_REG0034

        [TestMethod]
        public void FMUC0004_REG0034()
        {
            try
            {
                Reports.TestDescription = "US795534_TC854593: Verify Manufactured Home value exists in Property Type dropdown on Property Tax Info screen";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();

                Reports.TestStep = "Create a file with Transaction Type: Sale w/Morgage, and Business Segment: Residential ";
                OpenQFEPage();
                SetBusinessSourceDetails("HUDFLINSR1");
                SetServiceType(true, true);
                SetFormType();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem(@"Sale w/Mortgage");
                SetBlankProgramType();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");

                Reports.TestStep = "Verify Property Type: Manufactured Home exists and select it";
                if (FastDriver.QuickFileEntry.PropertyInformationType.FAGetText().Clean().Contains(@"Manufactured Home"))
                {
                    Reports.StatusUpdate("Manufactured Home exists", true);
                }
                else Reports.StatusUpdate("Manufactured Home exists", false);

                //Reports.TestStep = "Select Property Type: Manufactured Home and click on Done";
                //FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Manufactured Home");

                SetPropertyAddressInQFE();
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //
                Reports.TestStep = "Validate Property Type field from Properties/Tax Infor screen contains Manufactured Home value";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Thread.Sleep(3000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                string PropertyType = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetText();
                Support.AreEqual("True", PropertyType.Contains("Manufactured Home").ToString().Clean());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion

        #region Private Methods

        private void CreateAPN(string APNID)
        {
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText(APNID);
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("2015");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.FASetText("19768");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo1.FASetText("55");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus1.FASelectItem("ARREARS");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate1.FASetText(DateTime.Today.AddDays(1).ToDateString());
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FASetText("100");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInterest1.FASetText("50");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPenality1.FASetText("50");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxpartialPaymentAmount1.FASetText("40");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxAssesmentDate1.FASetText(DateTime.Today.AddDays(1).ToDateString());
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue1.FASetText("1000");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue1.FASetText("100");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue1.FASetText("100");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner1.FASetText("100");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther11.FASetText("100");
            FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.FASetText("100");
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        private void IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            UserName = UserName ?? AutoConfig.UserNameSU;
            Password = Password ?? AutoConfig.UserPasswordSU;
            Credentials credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

        }

        private void CreateDocument(string templateType, string templateName, string templateDescription, string state, bool multipleDocs = false)
        {

            if (FastDriver.DocumentRepository.Add.IsDisplayed().ToString() == "False")
            {
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
            }
            if (!multipleDocs)
                FastDriver.DocumentRepository.Add.FAClick();
            else
                FastDriver.DocumentRepository.Add.FAClick();
            Reports.TestStep = "Add Document to Document Repository screen.";
            FastDriver.AdHocDocuments.WaitForScreenToLoad();
            FastDriver.AdHocDocuments.Source.FASelectItem(@"Both");
            FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys(templateType);
            FastDriver.AdHocDocuments.TemplateDescription.FASetText(templateDescription);
            if (state != null)
                FastDriver.AdHocDocuments.State.FASelectItem(state);

            Reports.TestStep = "validate the data entered in Adhoc Documents.";
            Support.value = FastDriver.AdHocDocuments.Source.FAGetSelectedItem();
            if (Support.value == null)
                Support.value = "";
            Support.AreEqual(@"Both", Support.value);
            Support.value = FastDriver.AdHocDocuments.TemplateType.FAGetSelectedItem(); ;
            if (Support.value == null)
                Support.value = "";
            Support.AreEqual(templateType, Support.value);
            Support.AreEqual(templateDescription, FastDriver.AdHocDocuments.TemplateDescription.FAGetValue().Clean());
            FastDriver.AdHocDocuments.FindNow.FAClick();
            FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Description", templateName, "Description", TableAction.Click);
            FastDriver.AdHocDocuments.CreateSave.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

        }
        public void createBasicFile()
        {
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("242");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
            FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
            FastDriver.QuickFileEntry.SelectTransactionType("Refinance");
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.BottomFrame.Done();
        }


        private void OpenQFEPage()
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
        }

        private void SetBusinessSourceDetails(string GAB, string BSREF = "", string AdditionalRole = "", bool WaitCreation = true)
        {
            try
            {
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(GAB);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                if (WaitCreation)
                    FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceReference);
                if (!string.IsNullOrEmpty(BSREF))
                    FastDriver.QuickFileEntry.BusinessSourceReference.FASetText(BSREF);
                if (!string.IsNullOrEmpty(AdditionalRole))
                    FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem(AdditionalRole);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }

        private void SetServiceType(bool Title = true, bool Escrow = true, bool SubEscrow = false)
        {
            try
            {
                if (FastDriver.QuickFileEntry.Title.IsSelected() != Title)
                    FastDriver.QuickFileEntry.Title.FASetCheckbox(Title);
                if (FastDriver.QuickFileEntry.Escrow.IsSelected() != Escrow)
                    FastDriver.QuickFileEntry.Escrow.FASetCheckbox(Escrow);
                if (FastDriver.QuickFileEntry.SubEscrow.IsSelected() != SubEscrow)
                    FastDriver.QuickFileEntry.SubEscrow.FASetCheckbox(SubEscrow);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }

        private void SetFormType()
        {
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            if (AutoConfig.FormType.Equals("CD", StringComparison.CurrentCultureIgnoreCase))
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
            else
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            Thread.Sleep(2000);

        }

        private void SetBlankProgramType()
        {
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);
            Thread.Sleep(3000);

        }

        private void SetPropertyAddressInQFE()
        {
            try
            {
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText(@"J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem(@"Manufactured Home");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText(@"J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText(@"JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText(@"JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText(@"ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(@"ALAMEDA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }
}
