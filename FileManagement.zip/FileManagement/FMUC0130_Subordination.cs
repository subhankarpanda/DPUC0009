﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using System.Runtime.Serialization;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0130_Subordination: MasterTestClass
    {

        #region BAT

        #region FMUC0130_BAT/REG
        [TestMethod]
        public void FMUC0130_BAT0001_BAT0002_BAT0003__REG0001_REG0002_REG0003()
        {
            try
            {
                Reports.TestDescription = "Main Course: Create New Subordination Instance" +
                    "Alternate Course 1- Create Additional New Subordination Instance" +
                    "Alternate Course 2- Edit a Subordination Instance" +
                    "BR-Create Subordination Instance" +
                    "BR-Multiple Subordination Instances for a File" +
                    "BR-Modify Subordination Instance";
               
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Subordination";
                FastDriver.Subordination.Open();
                Reports.TestStep = "Create first instance of Subordination";
                FastDriver.Subordination.GabCode.FASetText("HUDFLINSR1)");
                FastDriver.Subordination.Find.FAClick();
                Support.AreEqual("1", FastDriver.Subordination.Position.FAGetValue());
                FastDriver.Subordination.ResponsibleParty.FASetText("RES PARTY1");
                string Lnum = Support.RandomString("NANANA");
                FastDriver.Subordination.LoanNumber.FASetText(Lnum);
                FastDriver.Subordination.LoanAmount.FASetText("25,000.00");
                FastDriver.Subordination.SubordinationOrderDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderAssignmentDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubRecordedDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderInstrument.FASetText("22");
                FastDriver.Subordination.SubLenderBook.FASetText("22");
                FastDriver.Subordination.SubLenderPage.FASetText("22");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Subordination summary page is loaded";
                FastDriver.Subordination_Summary.Open();
                String BusOrg1 = FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 2, TableAction.GetText).Message.Trim();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1",BusOrg1);
                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryEdit.FAClick();
                Reports.TestStep = "Validate first instance of Subordination";
                Support.AreEqual("HUDFLINSR1", FastDriver.Subordination.GaBCodeLabel.FAGetText());
                Support.AreEqual("RES PARTY1", FastDriver.Subordination.ResponsibleParty.FAGetValue());
                Support.AreEqual(Lnum, FastDriver.Subordination.LoanNumber.FAGetValue());
                Support.AreEqual("25,000.00", FastDriver.Subordination.LoanAmount.FAGetValue());
                Support.AreEqual("04-26-2017", FastDriver.Subordination.SubordinationOrderDate.FAGetValue());
                Support.AreEqual("04-26-2017", FastDriver.Subordination.SubLenderAssignmentDate.FAGetValue());
                Support.AreEqual("04-26-2017", FastDriver.Subordination.SubRecordedDate.FAGetValue());
                Support.AreEqual("22", FastDriver.Subordination.SubLenderInstrument.FAGetValue());
                Support.AreEqual("22", FastDriver.Subordination.SubLenderBook.FAGetValue());
                Support.AreEqual("22", FastDriver.Subordination.SubLenderPage.FAGetValue());



                Reports.TestStep = "Click on New button in Subordination page to create second instance";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.New();
                FastDriver.Subordination.SwitchToContentFrame();
                Reports.TestStep = "Create second instance of Subordination";
                FastDriver.Subordination.GabCode.FASetText("HUDERINSR1)");
                FastDriver.Subordination.Find.FAClick();
                Support.AreEqual("1", FastDriver.Subordination.Position.FAGetValue());
                FastDriver.Subordination.ResponsibleParty.FASetText("RES PARTY2");
                string Lnum1 = Support.RandomString("NANANA");
                FastDriver.Subordination.LoanNumber.FASetText(Lnum1);
                FastDriver.Subordination.LoanAmount.FASetText("15,000.00");
                FastDriver.Subordination.SubordinationOrderDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderAssignmentDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubRecordedDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderInstrument.FASetText("23");
                FastDriver.Subordination.SubLenderBook.FASetText("23");
                FastDriver.Subordination.SubLenderPage.FASetText("23");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Subordination summary page is loaded and click on second instance";


                FastDriver.Subordination_Summary.Open();
                String BusOrg2 = FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(3, 2, TableAction.GetText).Message.Trim();
                Support.AreEqual("Earthquake Ins. 1 for HUD Testing Name 1", BusOrg2);
                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryEdit.FAClick();

                Reports.TestStep = "Validate second instance of Subordination";
                Support.AreEqual("HUDERINSR1", FastDriver.Subordination.GaBCodeLabel.FAGetText());
                Support.AreEqual("RES PARTY2", FastDriver.Subordination.ResponsibleParty.FAGetValue());
                Support.AreEqual(Lnum1, FastDriver.Subordination.LoanNumber.FAGetValue());
                Support.AreEqual("15,000.00", FastDriver.Subordination.LoanAmount.FAGetValue());
                Support.AreEqual("04-26-2017", FastDriver.Subordination.SubordinationOrderDate.FAGetValue());
                Support.AreEqual("04-26-2017", FastDriver.Subordination.SubLenderAssignmentDate.FAGetValue());
                Support.AreEqual("04-26-2017", FastDriver.Subordination.SubRecordedDate.FAGetValue());
                Support.AreEqual("23", FastDriver.Subordination.SubLenderInstrument.FAGetValue());
                Support.AreEqual("23", FastDriver.Subordination.SubLenderBook.FAGetValue());
                Support.AreEqual("23", FastDriver.Subordination.SubLenderPage.FAGetValue());
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit second instance of Subordination";
                FastDriver.Subordination_Summary.Open();
                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryEdit.FAClick();
                FastDriver.Subordination.WaitForScreenToLoad();
                FastDriver.Subordination.LoanAmount.FASetText("35,000.00");
                FastDriver.Subordination.SubordinationOrderDate.FASetText("05-26-2017");
                FastDriver.Subordination.SubLenderAssignmentDate.FASetText("05-26-2017");
                FastDriver.Subordination.SubRecordedDate.FASetText("05-26-2017");
                FastDriver.Subordination.SubLenderInstrument.FASetText("26");
                FastDriver.Subordination.SubLenderBook.FASetText("26");
                FastDriver.Subordination.SubLenderPage.FASetText("26");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                FastDriver.Subordination_Summary.Open();
                Reports.TestStep = "Subordination summary page is loaded";
                Reports.TestStep = "Select the second instance and click on Edit and verify the changes are saved";

                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryEdit.FAClick();
                Reports.TestStep = "Validate the edited data";
                Support.AreEqual("35,000.00", FastDriver.Subordination.LoanAmount.FAGetValue());
                Support.AreEqual("05-26-2017", FastDriver.Subordination.SubordinationOrderDate.FAGetValue());
                Support.AreEqual("05-26-2017", FastDriver.Subordination.SubLenderAssignmentDate.FAGetValue());
                Support.AreEqual("05-26-2017", FastDriver.Subordination.SubRecordedDate.FAGetValue());
                Support.AreEqual("26", FastDriver.Subordination.SubLenderInstrument.FAGetValue());
                Support.AreEqual("26", FastDriver.Subordination.SubLenderBook.FAGetValue());
                Support.AreEqual("26", FastDriver.Subordination.SubLenderPage.FAGetValue());





            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0130_BAT0003__REG0004_ERR_WARNING02()
        {
            try
            {
                Reports.TestDescription = "BR-Delete Subordination Instance  " +
                                          "Alternate Course 3: Delete a Subordination Instance" +
                                          "Error Warning-On Subordination Summary screen, user selects Clear button.";
               
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Subordination";
                FastDriver.Subordination.Open();
                Reports.TestStep = "Create first instance of Subordination";
                FastDriver.Subordination.GabCode.FASetText("HUDFLINSR1)");
                FastDriver.Subordination.Find.FAClick();
                Support.AreEqual("1", FastDriver.Subordination.Position.FAGetValue());
                FastDriver.Subordination.ResponsibleParty.FASetText("RES PARTY1");
                string Lnum = Support.RandomString("NANANA");
                FastDriver.Subordination.LoanNumber.FASetText(Lnum);
                FastDriver.Subordination.LoanAmount.FASetText("25,000.00");
                FastDriver.Subordination.SubordinationOrderDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderAssignmentDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubRecordedDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderInstrument.FASetText("22");
                FastDriver.Subordination.SubLenderBook.FASetText("22");
                FastDriver.Subordination.SubLenderPage.FASetText("22");

                Reports.TestStep = "Create second Instance";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.New();
                FastDriver.Subordination.SwitchToContentFrame();
                FastDriver.Subordination.GabCode.FASetText("HUDERINSR1)");
                FastDriver.Subordination.Find.FAClick();
                Support.AreEqual("1", FastDriver.Subordination.Position.FAGetValue());
                FastDriver.Subordination.ResponsibleParty.FASetText("RES PARTY1");
                string Lnum3 = Support.RandomString("NANANA");
                FastDriver.Subordination.LoanNumber.FASetText(Lnum3);
                FastDriver.Subordination.LoanAmount.FASetText("25,000.00");
                FastDriver.Subordination.SubordinationOrderDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderAssignmentDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubRecordedDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderInstrument.FASetText("22");
                FastDriver.Subordination.SubLenderBook.FASetText("22");
                FastDriver.Subordination.SubLenderPage.FASetText("22");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
              
                Reports.TestStep = "Subordination summary page is loaded";
                FastDriver.Subordination_Summary.Open();

                Reports.TestStep = "Select the first Instance instance and click on Delete";

                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryClear.FAClick();
                Reports.TestStep = "Click on OK in the message Dialog";
                string Act_Message = FastDriver.WebDriver.HandleDialogMessage(true);
                string Exp_Message = "Are you sure you want to delete Flood Insurance 1 for HUD Testing Name 1 ?";
                Support.AreEqual("True", Act_Message.Equals(Exp_Message).ToString());

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.Subordination_Summary.WaitForScreenToLoad();

                String Avail= FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2,2, TableAction.GetText).Message.Trim();
                Support.AreEqual("Available", Avail);

                Reports.TestStep = "Select the second Instance instance and click on Delete";
                
                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryClear.FAClick();
                Reports.TestStep = "Click on Cancel in the message Dialog";
                string Act_Message1 = FastDriver.WebDriver.HandleDialogMessage(true,false);
                string Exp_Message1 = "Are you sure you want to delete Earthquake Ins. 1 for HUD Testing Name 1 ?";
                Support.AreEqual(Act_Message1,Exp_Message1);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.Subordination_Summary.WaitForScreenToLoad();
                String Avail1 = FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(3, 2, TableAction.GetText).Message.Trim();
                Support.AreEqual("Earthquake Ins. 1 for HUD Testing Name 1", Avail1);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


         [TestMethod]
        public void FMUC0130_ERR_WARNING_01_03()
        {
            try

            {

                Reports.TestStep = "Error / Warning Conditions 01- On the Subordination screen, user selects Done button without entering/selecting a Sub Lender." +
                                    "User has made screen updates and presses the “Reset” button  before saving changes to an existing subordination.";


                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Subordination";
                FastDriver.Subordination.Open();
                Reports.TestStep = "Create first instance of Subordination without GAB code and click on Done";
                FastDriver.Subordination.LoanAmount.FASetText("25,000.00");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Validate the message when no GAB Code is added";

                string Act_Message_Gcode = FastDriver.WebDriver.HandleDialogMessage(true);
                string Exp_Message_Gcode = "Error(s) occured. See Message pane";
                Support.AreEqual("True", Act_Message_Gcode.Equals(Exp_Message_Gcode).ToString());
                
                //Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                //Reports.TestStep = "Click on Ok button.";
                FastDriver.Subordination.SwitchToContentFrame();

                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Enter Data for GAB and click on RESET";
                FastDriver.Subordination.GabCode.FASetText("HUDFLINSR1)");
                FastDriver.Subordination.Find.FAClick();
                FastDriver.Subordination.WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.Subordination.Position.FAGetValue());
                FastDriver.Subordination.ResponsibleParty.FASetText("RES PARTY1");
                string Lnum3 = Support.RandomString("NANANA");
                FastDriver.Subordination.LoanNumber.FASetText(Lnum3);
                FastDriver.Subordination.LoanAmount.FASetText("25,000.00");
                FastDriver.Subordination.SubordinationOrderDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderAssignmentDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubRecordedDate.FASetText("04-26-2017");
                FastDriver.Subordination.SubLenderInstrument.FASetText("22");
                FastDriver.Subordination.SubLenderBook.FASetText("22");
                FastDriver.Subordination.SubLenderPage.FASetText("22");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Subordination summary page is loaded";
                FastDriver.Subordination_Summary.Open();
                String BusOrg1 = FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 2, TableAction.GetText).Message.Trim();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1", BusOrg1);
                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryEdit.FAClick();

                Reports.TestStep = "Edit the data for first instance of Subordination";
                FastDriver.Subordination.GabCode.FASetText("HUDERINSR1)");
                FastDriver.Subordination.Find.FAClick();
                Support.AreEqual("1", FastDriver.Subordination.Position.FAGetValue());
                FastDriver.Subordination.ResponsibleParty.FASetText("RES PARTY2");
                string Lnum1 = Support.RandomString("NANANA");
                FastDriver.Subordination.LoanNumber.FASetText(Lnum1);
                FastDriver.Subordination.LoanAmount.FASetText("15,000.00");
                FastDriver.Subordination.SubordinationOrderDate.FASetText("05-26-2017");
                FastDriver.Subordination.SubLenderAssignmentDate.FASetText("05-26-2017");
                FastDriver.Subordination.SubRecordedDate.FASetText("05-26-2017");
                FastDriver.Subordination.SubLenderInstrument.FASetText("23");
                FastDriver.Subordination.SubLenderBook.FASetText("23");
                FastDriver.Subordination.SubLenderPage.FASetText("23");

                Reports.TestStep = "Click on Reset Button";

                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Reset();
                string Act_Message_Reset = FastDriver.WebDriver.HandleDialogMessage(true);
                string Exp_Message_Reset = "Cancel without saving changes?";
                Support.AreEqual("True", Act_Message_Reset.Equals(Exp_Message_Reset).ToString());


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.Subordination.WaitForScreenToLoad();
                
                Reports.TestStep = "Validate data is set to previous value on click of Reset Button";
                Support.AreEqual("HUDFLINSR1", FastDriver.Subordination.GaBCodeLabel.FAGetText());
                Support.AreEqual("RES PARTY1", FastDriver.Subordination.ResponsibleParty.FAGetValue());
                Support.AreEqual(Lnum3, FastDriver.Subordination.LoanNumber.FAGetValue());
                Support.AreEqual("25,000.00", FastDriver.Subordination.LoanAmount.FAGetValue());
                Support.AreEqual("04-26-2017", FastDriver.Subordination.SubordinationOrderDate.FAGetValue());
                Support.AreEqual("04-26-2017", FastDriver.Subordination.SubLenderAssignmentDate.FAGetValue());
                Support.AreEqual("04-26-2017", FastDriver.Subordination.SubRecordedDate.FAGetValue());
                Support.AreEqual("22", FastDriver.Subordination.SubLenderInstrument.FAGetValue());
                Support.AreEqual("22", FastDriver.Subordination.SubLenderBook.FAGetValue());
                Support.AreEqual("22", FastDriver.Subordination.SubLenderPage.FAGetValue());
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        #endregion

        
        #endregion BAT

        #region REG

        
               
        
        
       

        #endregion REG

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}