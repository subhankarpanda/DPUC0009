﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FileManagement
{
    public partial class FPUC0012 : MasterTestClass
    {
        [TestMethod]
        public void FPUC0012_REG0022()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                Reports.TestDescription = "4752_5000_4753: Task Warnings functionality";

                var process = CreateProcessTemplate("FPUC0012_REG0022");

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight the task.";
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).IsDisplayed(), "Template is shown");
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click);

                Reports.TestStep = "Validate the warning for due date";
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction(4, "Overdue Task: " + process.Tasks.First(t => t.Status == "Complete").Name, 1, TableAction.On);

                Reports.TestStep = "Validate that the warning is deleted";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(1000);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.IsTrue(!FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains(process.Tasks.First(t => t.Status == "Complete").Name), "Alert is deleted");

                Reports.TestStep = "Highlight the Inactive task.";
                tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).IsDisplayed(), "Template is shown");
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Inactive").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Enter due date";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.DueDate.FASetText(DateTime.Today.ToDateString(trim: true));
                FastDriver.TaskDetails.WarnDate.FASetText("" + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.TaskDetails.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate the presence of warning for Inactive task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains(process.Tasks.First(t => t.Status == "Inactive").Name), "MessagesTable contains inactive task name");

                Reports.TestStep = "Highlight the completed task.";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Click on AddMisc Button.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.AddMisc.FAClick();

                Reports.TestStep = "Add Misc Task.";
                FastDriver.AddNewMiscellaneousTaskDlg.WaitForScreenToLoad();
                FastDriver.AddNewMiscellaneousTaskDlg.Name.FASetText("MiscTaskTest");
                FastDriver.AddNewMiscellaneousTaskDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify the Misc Task added.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "MiscTaskTest", 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Enter due date";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.DueDate.FASetText(DateTime.Today.AddBusinessDays(1).ToDateString(trim: true));
                FastDriver.TaskDetails.WarnDate.FASetText(DateTime.Today.ToDateString(trim: true) + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.TaskDetails.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Validate the presence of warning for Misc task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains("MiscTaskTest"), "MessagesTable contains 'MiscTaskTest'");

                Reports.TestStep = "Validate that updating the Warn date does not affect other alerts";
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction(4, "Warning for Task: MiscTaskTest", 4, TableAction.Click);
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction(4, "Overdue Task: " + process.Tasks.First(t => t.Status == "Inactive").Name, 4, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0023_24_25()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                Reports.TestDescription = "EW1_EW4_EW10_EW12_EW13 / FP31133_EW11_EW18_EW14_EW16_EW17: Validate the error warning conditions";

                var process = CreateProcessTemplate("FPUC0012_REG0023_24_25");

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Verify the File Work Flow screen is loaded and the best match process template is displayed.";
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).IsDisplayed(), "Template is shown");

                Reports.TestStep = "Enter comments and click cancel.";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 12, TableAction.Click);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("New note in File workflow");
                FastDriver.TaskCommentEditDlg.Cancel.FAClick();

                Reports.TestStep = "Validate the message when Comment is entered without saving";
                Support.AreEqual("Save Task Comment before exiting?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Highlight the completed task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Click on Select task button";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.SelectTasksIIS.FAClick();

                Reports.TestStep = "Validate the message when task is not selected";
                Support.AreEqual("No Tasks are checked to Select", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click on cancel button";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Click on cancel";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Highlight the Waived task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Waive").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Enter invalid warn date";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.WarnDate.FASetText("12" + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.TaskDetails.Done.FAClick();

                Reports.TestStep = "Validate message for invalid data in warn date";
                Support.AreEqual("Date is Invalid", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter previous warn date";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.WarnDate.FASetText(DateTime.Today.AddBusinessDays(-2).ToDateString(trim: true) + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.TaskDetails.Done.FAClick();

                Reports.TestStep = "Validate message for Lesser warn date";
                Support.AreEqual("Error! Warn Date must be current date or greater", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter previous due date";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.DueDate.FASetText(DateTime.Today.AddBusinessDays(-2).ToDateString(trim: true) + FAKeys.Tab);
                FastDriver.TaskDetails.WarnDate.FASetText(DateTime.Today.AddBusinessDays(1).ToDateString(trim: true) + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.TaskDetails.Done.FAClick();

                Reports.TestStep = "Validate message for Lesser Due date";
                Support.AreEqual("Error! Due Date must be current date or greater", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter Invalid due date";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.DueDate.FASetText("12" + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.TaskDetails.Done.FAClick();

                Reports.TestStep = "Validate message for invalid data in warn date";
                Support.AreEqual("Date is Invalid", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter due date";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.DueDate.FASetText(DateTime.Today.ToDateString(trim: true) + FAKeys.Tab);
                FastDriver.TaskDetails.WarnDate.FASetText(FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.TaskDetails.Done.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "REG24: FP31133_EW11_EW18_EW14_EW16_EW17";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight the started task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Up Button.";
                FastDriver.FileWorkflow.Up.FAClick();

                Reports.TestStep = "Validate message when the task is moved up";
                Support.AreEqual("Cannot move this row up", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Click on AddMisc Button.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.AddMisc.FAClick();

                Reports.TestStep = "Click on done button.";
                FastDriver.AddNewMiscellaneousTaskDlg.WaitForScreenToLoad();
                FastDriver.AddNewMiscellaneousTaskDlg.Done.FAClick();

                Reports.TestStep = "Validate the message when no task name is entered";
                Support.AreEqual("Task Name was not entered", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Add Misc Task.";
                FastDriver.AddNewMiscellaneousTaskDlg.WaitForScreenToLoad();
                FastDriver.AddNewMiscellaneousTaskDlg.Name.FASetText("MiscTaskTest");
                FastDriver.AddNewMiscellaneousTaskDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify the Misc Task added.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "MiscTaskTest", 5, TableAction.Click);

                Reports.TestStep = "Verify the Assigned to Populated with Unassigned";
                Support.AreEqual("Unassigned", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "MiscTaskTest", 10, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Click On Remove Button.";
                FastDriver.FileWorkflow.RemoveTask.FAClick();

                Reports.TestStep = "Validate the message for deletion of misc task";
                Support.AreEqual("Delete the Selected Task?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click On Up Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Up.FAClick();

                Reports.TestStep = "validate message when up or down button is clicked without selecting a task";
                Support.AreEqual("Please select a Task Row", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click On Down Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.Down.FAClick();

                Reports.TestStep = "validate message when up or down button is clicked without selecting a task";
                Support.AreEqual("Please select a Task Row", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "REG25: Select last task in the process and validate it cannot be moved down.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Inactive").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Down Button.";
                FastDriver.FileWorkflow.Down.FAClick();

                Reports.TestStep = "Validate message when the task is moved up";
                Support.AreEqual("Cannot move this row down", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.HomePage.WaitForHomeScreen();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0026_27_28()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                Reports.TestDescription = "3123_3126_3127_3128_EW6_EW5_EW7_EW8_EW9_19_3113: Validating functionality on Pending File Reminders and Alerts / 3124_3114 validation: Validate that alert appear in MFT screen and in File workflow. / 3114_validation: Validate that the alert is deleted";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                Playback.Wait(2000);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                Playback.Wait(2000);

                Reports.TestStep = "FP3112_ Click on new button and create Alerts";
                FastDriver.FileWorkflow.New.FAClick();

                Reports.TestStep = "Select reminder and enter notify date and note";
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.Visibility);
                FastDriver.FileWorkflow.Visibility.FASelectItem("Reminder");
                FastDriver.FileWorkflow.NotifyDate.FASetText(DateTime.Today.AddBusinessDays(1).ToDateString(trim: true));
                FastDriver.FileWorkflow.Note.FASetText("Set a reminder");

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "EW_5 Verify the Error Warning 'Please Select Row to Delete'";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.RemoveRemainder.FAClick();
                Support.AreEqual("Please Select Row to Delete", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "FP3111_2 Validate the reminder is added";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("Reminder", FastDriver.FileWorkflow.Visibility.FAGetSelectedItem().Clean());
                Support.AreEqual(DateTime.Today.AddBusinessDays(1).ToDateString(), FastDriver.FileWorkflow.NotifyDate.FAGetValue().Clean());
                Support.AreEqual("Set a reminder", FastDriver.FileWorkflow.Note.FAGetValue().Clean());

                Reports.TestStep = "Select reminder and enter notify date and note";
                FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(2, "FAST QA07", 2, TableAction.Click);
                FastDriver.FileWorkflow.Visibility.FASelectItem("Reminder");
                FastDriver.FileWorkflow.NotifyDate.FASetText(DateTime.Today.AddBusinessDays(1).ToDateString(trim: true));
                FastDriver.FileWorkflow.Note.FASetText("Set a reminder");

                Reports.TestStep = "Remove the reminder";
                FastDriver.FileWorkflow.RemoveRemainder.FAClick();

                Reports.TestStep = "In Pending Reminders and Alerts, user selects a Reminder or Alert and clicks the Delete button";
                Support.AreEqual("Delete selected File Reminder or Alert?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Remove the reminder";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.RemoveRemainder.FAClick();

                Reports.TestStep = "In Pending Reminders and Alerts, click on the Remove button when there are no Reminders or alerts";
                Support.AreEqual("No File Reminders are Available", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click on new button";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.New.FAClick();

                Reports.TestStep = "Select alert and enter notify date and note";
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.Visibility);
                FastDriver.FileWorkflow.Visibility.FASelectItem("Alert");
                FastDriver.FileWorkflow.NotifyDate.FASetText(DateTime.Today.ToDateString(trim: true));
                FastDriver.FileWorkflow.Note.FASetText("Set an alert");
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Click on new button";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.New.FAClick();

                Reports.TestStep = "Enter a reminder without a notify date";
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.Visibility);
                FastDriver.FileWorkflow.Visibility.FASelectItem("Reminder");
                FastDriver.FileWorkflow.NotifyDate.FASetText(FAKeys.Tab);
                FastDriver.FileWorkflow.Note.FASetText("Set a reminder");

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();

                Reports.TestStep = "User does not enter a notify date";
                Support.AreEqual("Error! A valid Reminder Date is required", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter a reminder without a note";
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.Visibility);
                FastDriver.FileWorkflow.Visibility.FASelectItem("Reminder");
                FastDriver.FileWorkflow.NotifyDate.FASetText(DateTime.Today.ToDateString(trim: true));
                FastDriver.FileWorkflow.Note.FASetText(FAKeys.Tab);

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();

                Reports.TestStep = "User does not enter note";
                Support.AreEqual("Error! Reminder Note is required", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter a reminder with invalid date";
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.Visibility);
                FastDriver.FileWorkflow.Visibility.FASelectItem("Reminder");
                FastDriver.FileWorkflow.NotifyDate.FASetText(DateTime.Today.AddBusinessDays(-2).ToDateString(trim: true));
                FastDriver.FileWorkflow.Note.FASetText("Set a reminder");

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();

                Reports.TestStep = "User enter lesser notify date";
                Support.AreEqual("Error! Reminder Date must be current date or greater", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Select Alert and enter notify date and note";
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.Visibility);
                FastDriver.FileWorkflow.Visibility.FASelectItem("Alert");
                FastDriver.FileWorkflow.NotifyDate.FASetText(DateTime.Today.ToDateString(trim: true));
                string alertName = "Set a reminder from Alert: " + Support.RandomString("QAErPnufXf");
                FastDriver.FileWorkflow.Note.FASetText(alertName);

                Reports.TestStep = "REG27: Navigate to MFT.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();

                Reports.TestStep = "Verify alerts in MFT.";
                FastDriver.MyFASTToday.AlertUser.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.AlertType.FASelectItem("All");
                Playback.Wait(1000);
                FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction(5, alertName, 5, TableAction.Click);

                Reports.TestStep = "Navigate to FWF.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                Playback.Wait(2000);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                Playback.Wait(2000);

                Reports.TestStep = "Validate that the alert is displayed in Fileworkflow and Delete the Alert";
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("#4", alertName, "Del?", TableAction.On);

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Deleted Alert id Displaying My Fast Today";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();

                Reports.TestStep = "Verify alerts in MFT.";
                FastDriver.MyFASTToday.AlertUser.FASelectItem("QA07, FAST");
                FastDriver.MyFASTToday.AlertType.FASelectItem("All");
                Playback.Wait(1000);
                Support.IsTrue(!FastDriver.MyFASTToday.SummaryAlertsTable.FAGetText().Contains(alertName), "Alert is deleted from table");

                Reports.TestStep = "REG28: 3114_validation: Validate that the alert is deleted.";
                Support.IsTrue(!FastDriver.MyFASTToday.AlertType.FAGetText().Contains(alertName), "Alert type list does not contain alert name");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0030_31_32_33_34_35_36_37_38()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                Reports.TestDescription = "7097_7101: Select Alerts Assigned To An Employee / 7102: Service Added/Removed/Owning-Office Changed Alerts Type / EVENT LOG [3997_4728: Task Started | 4730: Start Assignment | 4731: Task Complete | 4734: Task Waived | 6424: Waiving File Task | 11639: Nanual Add Process Success | 11640: Manual Add Process failure]";

                var process = CreateProcessTemplate("FPUC0012_REG0030_31_32_33_34_35_36_37_38");

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to MFT.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();

                Reports.TestStep = "Validate alerts can be Unassigned, assigned to any Employee in the current office, or assigned to the Current Office";
                Support.IsTrue(FastDriver.MyFASTToday.AlertUser.FAGetDropdownOptions().Count > 3, "Alert user list contains more than 3 users");
                Support.IsTrue(FastDriver.MyFASTToday.AlertUser.FAGetText().Contains("Unassigned"), "Alert user list contains Unassigned");
                Support.IsTrue(FastDriver.MyFASTToday.AlertUser.FAGetText().Contains("QA07, FAST"), "Alert user list contains QA07, FAST");
                Support.IsTrue(FastDriver.MyFASTToday.AlertUser.FAGetText().Contains("Current Office"), "Alert user list contains Current Office");

                //Reports.TestStep = "Validate the Unassigned task Alert is displayed in MyFast Today";
                //FastDriver.MyFASTToday.AlertUser.FASelectItem("Unassigned");
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                //FastDriver.MyFASTToday.WaitForScreenToLoad();
                //FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction(5, "Overdue Task: " + process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Assign the task to the current user.";
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 11, TableAction.Click);
                FastDriver.FileWorkflow.SelAssgTo.FASelectItem("QA07, FAST");

                Reports.TestStep = "Verify current user is selected.";
                Support.AreEqual("QA07, FAST", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 10, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Navigate to MFT.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();

                Reports.TestStep = "Validate the system display Over Due Task alerts assigned to the current user";
                FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction(5, "Overdue Task: " + process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click);

                Reports.TestStep = "Validate the system display Over Due Task alerts created by employees from the the current office";
                FastDriver.MyFASTToday.AlertUser.FASelectItem("Current Office");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction(5, "Overdue Task: " + process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click);

                Reports.TestStep = "REG31: 7102: Service Added, Service Removed/Owning Office Changed Alerts Type.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad(FastDriver.FileHomepage.ChangeOO);
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                Playback.Wait(500);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Validate the escrow remove message";
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "Escrow Service Removed", "Message", TableAction.Click);

                Reports.TestStep = "REG32: 3997_4728: Task Started Event Log.";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Start the task.";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.On);

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Highlight the Started task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Validate the Activated Date.";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.TaskDetails.ActivatedDate.FAGetText().Contains(DateTime.Today.ToDateString()), "ActivatedDate contains today's date");

                Reports.TestStep = "Validate the Started Date.";
                Support.IsTrue(FastDriver.TaskDetails.StartedDate.FAGetText().Contains(DateTime.Today.ToDateString()), "StartedDate contains today's date");

                Reports.TestStep = "Validate the FirstAssgDate.";
                Support.IsTrue(FastDriver.TaskDetails.FirstAssgDate.FAGetText().Contains(DateTime.Today.ToDateString()), "FirstAssgDate contains today's date");

                Reports.TestStep = "Click on Done.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click On Event Log Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();

                Reports.TestStep = "Verify the event log for Task Started.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Contains("[Task Started and Assigned]"), "Validate last event is Task Started");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Contains(process.Tasks.First(t => t.Status == "Start").Name), "Confirm task name is " + process.Tasks.First(t => t.Status == "Start").Name);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.LeftNavigation.ClickHome();

                Reports.TestStep = "REG33: 4730: Start Assignment Event Log.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Change the assigned employee.";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 11, TableAction.Click);
                FastDriver.FileWorkflow.SelAssgTo.FASelectItemByIndex(0);

                Reports.TestStep = "Verify employee changed.";
                Support.AreNotEqual("QA07, FAST", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 10, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Click On Event Log Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();

                Reports.TestStep = "Verify the event log for Reassign task.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Contains("[Task Owner Assigned]"), "Validate last event is Task Owner Assigned");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Contains(process.Tasks.First(t => t.Status == "Start").Name), "Confirm task name is " + process.Tasks.First(t => t.Status == "Start").Name);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "REG34: 4731: Task Complete Event Log.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Complete the task.";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 2, TableAction.On);

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Highlight the Completed task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Validate the Completed date.";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.TaskDetails.CompletedDate.FAGetText().Contains(DateTime.Today.ToDateString()), "CompletedDate contains today's date");

                Reports.TestStep = "Click on Done.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click On Event Log Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();

                Reports.TestStep = "Verify the event log for Reassign task.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Contains("[Task Completed]"), "Validate last event is Task Completed");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Contains(process.Tasks.First(t => t.Status == "Complete").Name), "Confirm task name is " + process.Tasks.First(t => t.Status == "Complete").Name);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "REG35: 4734: Task Waived Event Log.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Waive the task.";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Waive").Name, 3, TableAction.On);

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                Playback.Wait(500);

                Reports.TestStep = "Highlight the Completed task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Waive").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Validate the Waived date.";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.TaskDetails.WaivedDate.FAGetText().Contains(DateTime.Today.ToDateString()), "WaivedDate contains today's date");

                Reports.TestStep = "Click on Done.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click On Event Log Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();

                Reports.TestStep = "Verify the event log for Reassign task.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Contains("[Task Waived]"), "Validate last event is Task Waived");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Contains(process.Tasks.First(t => t.Status == "Waive").Name), "Confirm task name is " + process.Tasks.First(t => t.Status == "Waive").Name);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "REG36: 6424: Event Log Entry for Waiving File Task.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Change file status From Open to Open in error.";
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().Clean());
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open In Error");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Click On Event Log Button.";
                FastDriver.FileWorkflow.EventLog.FAClick();

                Reports.TestStep = "Verify the event log for Waived Task.";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Contains("[File Tasks Waived]"), "Validate last event is File Tasks Waived");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Contains("Outstanding File Tasks Waived"), "Confirm comments contain Outstanding File Tasks Waived");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "REG37: 11639: Event Log for manual Add Process Success.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                int processCount = FastDriver.FileWorkflow.ProcessTable.GetRowCount(thisTableOnly: true);
                FastDriver.FileWorkflow.AddProcess.FAClick();

                Reports.TestStep = "Select the Process.";
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, process.Type, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Verify the Process Added.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual((processCount + 1).ToString(), FastDriver.FileWorkflow.ProcessTable.GetRowCount(thisTableOnly: true).ToString(), "Process count");

                Reports.TestStep = "Click On Event Log Button.";
                FastDriver.FileWorkflow.EventLog.FAClick();

                Reports.TestStep = "Verify the event log for Add Process and Start and Compltetion dates and Who added thid process";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Contains("[Manual Process Added]"), "Validate last event is Manual Process Added");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 2, TableAction.GetText).Message.Contains(DateTime.Today.ToDateString(slash: true)), @"Validate event Start Date is today");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 3, TableAction.GetText).Message.Contains(DateTime.Today.ToDateString(slash: true)), @"Validate event Complete Date is today");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 4, TableAction.GetText).Message.Contains(@"FAST Application"), @"Validate event source is FAST Application");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Contains("Process Type: " + process.Type), "Validate comments contain process type " + process.Type);
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 6, TableAction.GetText).Message.Contains(@"FASTTS\FASTQA07"), @"Validate event user is FASTTS\FASTQA07");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "REG38: 11640: Event Log for manual Add Process failure.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Click On Add Process Button.";
                processCount = FastDriver.FileWorkflow.ProcessTable.GetRowCount(thisTableOnly: true);
                FastDriver.FileWorkflow.AddProcess.FAClick();

                Reports.TestStep = "Select the Process.";
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, "Cancellation", 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click On Event Log Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.EventLog.FAClick();

                Reports.TestStep = "Validate event log for failed process added";
                FastDriver.EventTrackingLogDlg.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Contains("[Manual Process Failed]"), "Validate last event is Manual Process Failed");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 2, TableAction.GetText).Message.Contains(DateTime.Today.ToDateString(slash: true)), @"Validate event Start Date is today");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 3, TableAction.GetText).Message.Contains(DateTime.Today.ToDateString(slash: true)), @"Validate event Complete Date is today");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 4, TableAction.GetText).Message.Contains(@"FAST Application"), @"Validate event source is FAST Application");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Contains("Process Type: Cancellation"), "Validate comments contain process type Cancellation");
                Support.IsTrue(FastDriver.EventTrackingLogDlg.EventTable.PerformTableAction(1, 6, TableAction.GetText).Message.Contains(@"FASTTS\FASTQA07"), @"Validate event user is FASTTS\FASTQA07");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0039_40_41_42_43_44_45_46()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                Reports.TestDescription = "9011: Save Changes Before Adding a New Process / 9005_4738: Add a Task Comment / 9006_9007: Task Comments Not Editable when Process Completed and user will be able to view the comment / 8929_8930: Calculate Status of a Process Calculate Process Status Active / 8931: Calculate Process Status Started / 8932_FP8737: Calculate Process Status Completed / REG45: 8933_8934_9021_8939: Calculate Process Status Waived / 8938: Allow Duplicate Processes";

                var process = CreateProcessTemplate("FPUC0012_REG0039_40_41_42_43_44_45_46");

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Start the task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.On);

                Reports.TestStep = "Click On Add Process Button.";
                int processCount = FastDriver.FileWorkflow.ProcessTable.GetRowCount(thisTableOnly: true);
                FastDriver.FileWorkflow.AddProcess.FAClick();

                Reports.TestStep = "Select the Process.";
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, process.Type, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate that task is started and green checkbox appears";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").IsDisplayed(), "Green checkbox icon is displayed");

                Reports.TestStep = "REG40: 9005_4738: Add a Task Comment";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 12, TableAction.Click);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("New note in File workflow");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Validate comment in File Notes";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.IsTrue(FastDriver.FileNotes.Table.FAGetText().Contains("New note in File workflow"), "File Notes table contains task comment text");

                Reports.TestStep = "REG41 - 9006_9007: Task Comments Not Editable when Process Completed and user will be able to view the comment.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Activate the Inactive task manually";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Inactive").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Click on Manual Activation Button.";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.ManualActivation.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Complete a process";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 2, TableAction.On);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 2, TableAction.On);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Waive").Name, 2, TableAction.On);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Inactive").Name, 2, TableAction.On);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Click on Task Comment button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 12, TableAction.Click);

                Reports.TestStep = "Text is disabled";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.TaskCommentEditDlg.InternalComment.IsEnabled(), "Internal Comment IsEnabled");
                FastDriver.TaskCommentEditDlg.Cancel.FAClick();

                Reports.TestStep = "Validate that the text is present";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                var cell = FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 12, TableAction.GetCell).Element;
                Support.AreEqual("New note in File workflow", cell.FAGetAttribute("title").Clean(), "Comment Cell help text");
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "REG42: 8929_8930: Calculate Status of a Process Calculate Process Status Active";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Calculate the 'Status' of a Process Template ";
                tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Support.AreEqual("Process Active", FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + " #divStatus").FAGetText().Clean(), "Process Status");

                Reports.TestStep = "REG43: 8931: Calculate Process Status Started.";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "FP3111_6 Click on AddMisc Button.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.AddMisc.FAClick();

                Reports.TestStep = "Add Misc Task.";
                FastDriver.AddNewMiscellaneousTaskDlg.WaitForScreenToLoad();
                FastDriver.AddNewMiscellaneousTaskDlg.Name.FASetText("MiscTaskTest");
                FastDriver.AddNewMiscellaneousTaskDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify the Misc Task added.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "MiscTaskTest", 5, TableAction.Click);

                Reports.TestStep = "Start the misc task";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "MiscTaskTest", 1, TableAction.On);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Click On Remove Button.";
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.Process);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "MiscTaskTest", 5, TableAction.Click);
                FastDriver.FileWorkflow.RemoveTask.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Validate that Process status is started";
                Support.AreEqual("Process Started", FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + " #divStatus").FAGetText().Clean(), "Process Status");
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "REG44: 8932_FP8737: Calculate Process Status Completed";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Activate the Inactive task manually";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Inactive").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Click on Manual Activation Button.";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.ManualActivation.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Complete a process";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 2, TableAction.On);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 2, TableAction.On);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Waive").Name, 2, TableAction.On);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Inactive").Name, 2, TableAction.On);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Validate that the process is completed";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("Process Completed", FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + " #divStatus").FAGetText().Clean(), "Process Status");

                Reports.TestStep = "FP8737_Waive Checkbox is disabled for already Completed Process";
                if (!FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).IsDisplayed())
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + " #pExpCol").FAClick();
                Playback.Wait(500);
                Support.AreEqual(false, FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsEnabled(), "Complete task waive checkbox is disabled");
                Support.AreEqual(false, FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsEnabled(), "Start task waive checkbox is disabled");
                Support.AreEqual(false, FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Waive").Name, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsEnabled(), "Waive task waive checkbox is disabled");
                Support.AreEqual(false, FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Inactive").Name, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsEnabled(), "Inactive task waive checkbox is disabled");
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "REG45: 8933_8934_9021_8939: Calculate Process Status Waived";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Start a task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.On);

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Waive a process";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + "_chkWaive").FASetCheckbox(true);
                Playback.Wait(200);
                FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + "_chkWaive").FASetCheckbox(false);
                Playback.Wait(200);
                Support.AreEqual(false, FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + "_chkWaive").IsSelected(), "Verify process not set to be waived");
                FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + "_chkWaive").FASetCheckbox(true);

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Verify the process is waived.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("Process Waived", FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + " #divStatus").FAGetText().Clean(), "Process Status");

                Reports.TestStep = "Validate the Waive Checkbox is Checked and Disabled.";
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + "_chkWaive").IsSelected(), "ChkWaive IsSelected");
                Support.AreEqual(false, FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + "_chkWaive").IsEnabled(), "ChkWaive IsEnabled");

                Reports.TestStep = "Verify the Started Task Status has changed to Waive";
                if (!FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).IsDisplayed())
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#" + FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name, true) + " #pExpCol").FAClick();
                Playback.Wait(500);
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").IsDisplayed(), "Started task is waived");

                Reports.TestStep = "Verify the user able to Move the task Up or Down";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click);
                Playback.Wait(200);
                Support.AreEqual(false, FastDriver.FileWorkflow.Up.IsEnabled(), "Up IsEnabled");
                Support.AreEqual(false, FastDriver.FileWorkflow.Down.IsEnabled(), "Down IsEnabled");

                Reports.TestStep = "Verify the user able to Add Task";
                Support.AreEqual(false, FastDriver.FileWorkflow.AddTask.IsEnabled(), "AddTask IsEnabled");

                Reports.TestStep = "REG46: 8938: Allow Duplicate Processes";
                FastDriver.FileWorkflow.AddProcess.FAClick();

                Reports.TestStep = "Select the Process.";
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, "1099", 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Validate that the duplicate process are added";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.FileWorkflow.ProcessTable.FAGetText().CountOccurrences(process.Name).ToString(), "Process count");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0047()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                Reports.TestDescription = "FP12651: Delete Due Date";

                var process = CreateProcessTemplate("FPUC0012_REG0047");

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight the completed task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Click on AddMisc Button.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.AddMisc.FAClick();

                Reports.TestStep = "Add Misc Task.";
                FastDriver.AddNewMiscellaneousTaskDlg.WaitForScreenToLoad();
                FastDriver.AddNewMiscellaneousTaskDlg.Name.FASetText("MiscTaskTest");
                FastDriver.AddNewMiscellaneousTaskDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify the Misc Task added.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "MiscTaskTest", 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Enter due date";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.DueDate.FASetText(DateTime.Today.ToDateString(trim: true) + FAKeys.Tab);
                FastDriver.TaskDetails.WarnDate.FASetText(FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.TaskDetails.Done.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Highlight the Mis task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, "MiscTaskTest", 5, TableAction.Click);

                Reports.TestStep = "Click On Details Button.";
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Click on Due date";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                FastDriver.TaskDetails.Cleardatetime.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Validate that due date is not appearing";
                FastDriver.TaskDetails.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.TaskDetails.DueDate.FAGetText().Clean(), "DueDate");
                FastDriver.TaskDetails.Done.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0051_52_54_55()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.ShortSaleCash);
                #endregion

                Reports.TestDescription = "9015_Validation: Validate that successor task is not addded / 9016_4740_9017_4739_9020: Add Successor Task / 8941: Add a Task when Selected Process has become Inactive";

                var process = CreateDetailedProcessTemplate("FPUC0012_REG0051_52_54_55", addSuccessor: true, addTaskEvents: false);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight the Started task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 5, TableAction.Click);

                Reports.TestStep = "Add Direct Task";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Select task from Process Template.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(2, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.On);
                FastDriver.AddTasksfromProcessTemplateScreenDlg.Select.FAClick();

                Reports.TestStep = "Verify Successor task is not added when Directing task is added to the FileWork Flow";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).FAGetText().CountOccurrences(process.Tasks.First(t => t.Status == "Complete").Name).ToString(), "Complete task count");

                Reports.TestStep = "REG52: 9016_4740_9017_4739_9020: Add Successor Task";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight the task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                int currentRow = FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 5, TableAction.Click).CurrentRow + 1;

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Select task from Process Template.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.SelectTasksFromProcessTemplateTable.PerformTableAction(2, process.Tasks.First(t => t.Status == "Complete").Name, 1, TableAction.On);
                FastDriver.AddTasksfromProcessTemplateScreenDlg.Select.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "9016: Verify the Direct Task is not added to the FileWork flow when user add Successor Task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).FAGetText().CountOccurrences(process.Tasks.First(t => t.Status == "Start").Name).ToString(), "Start task count");

                Reports.TestStep = "9017_4739: Verify the task is added after the original Complete task and it is in Active status";
                Support.IsTrue(FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(currentRow + 1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsEnabled(), "Complete is enabled");

                Reports.TestStep = "Add Task from Process Template.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Select the Tasks to add in FWF.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TaskTable.PerformTableAction(3, process.Tasks.First(t => t.Status == "Waive").Name, 2, TableAction.On);
                FastDriver.TaskTemplateSelectionDlg.SelectTasksIIS.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "9020: System should save all changes after selecting new tasks.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "4740: Verify system allows the user to add one or more Task from a Category ";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).FAGetText().CountOccurrences(process.Tasks.First(t => t.Status == "Waive").Name).ToString(), "Start task count");
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "REG54: 8941: Add a Task when Selected Process has become Inactive";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID("1486");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary.";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, process.Name, 1, TableAction.Click);

                Reports.TestStep = "Change the status.";
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.WaitForScreenToLoad();
                FastDriver.StatusEdit.Deactivate.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Wait for process to refresh.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(process.Name);
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(60000);
                Reports.StatusUpdate("Wait 60 seconds for the process to be deactivated.", true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight the Started task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 5, TableAction.Click);

                Reports.TestStep = "Add Task";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Verify the warning message.";
                Support.AreEqual(true, FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Contains("The Process Template for the task you selected is currently inactive"), "Validate warning text");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.HomePage.WaitForHomeScreen();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0060_61_63_64_65_66_67_68()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.ShortSaleCash);
                #endregion

                Reports.TestDescription = "AF7_6595_6596: Task Event Automation / 6427: Update Task Status Based On Field Changed Task Event / 6597: Direction Of Task Status Updates / 6429: Update Status On Active Tasks / 6428: No Update On Task Status";

                var process = CreateDetailedProcessTemplate("FPUC0012_REG0060_61_63_64_65_66_67_68", addSuccessor: true, addTaskEvents: true);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create a document.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.Add);
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add Document to Document Repository screen.";
                FastDriver.AdHocDocuments.AddDocument("Both", "Endorsement/Guarantee", "ALTA Endorsement 10-06 (Assignment)-N", null);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Select the Endorsement Document and Click on Edit for finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.DocumentsTable);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA Endorsement 10-06 (Assignment)-N", 4, TableAction.Click);
                FastDriver.DocumentRepository.Details.FAClick();
                FastDriver.DocumentDetailsScreen.WaitForScreenToLoad();
                int docID = int.Parse(FastDriver.DocumentDetailsScreen.DocID.FAGetText().Clean());
                int fileID = int.Parse(FastDriver.DocumentDetailsScreen.FileID.FAGetText().Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.FinalizeDocumentUsingWebService(fileID, docID);

                Reports.TestStep = "Verify document status is Finalized";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                Support.AreEqual("Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Endorsement/Guarantee", 9, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Navigate to Document repository";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA Endorsement 10-06 (Assignment)-N", 4, TableAction.Click);

                Reports.TestStep = "Email the checks.";
                FastDriver.Delivery.Perform(FADeliveryMethod.Email);

                Reports.TestStep = "Select to and click on email delivery.";
                FastDriver.EmailDlg.WaitForScreenToLoad();
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo);
                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - " + AutoConfig.FASTHomeURL);
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Email);
                Playback.Wait(20000);
                Reports.StatusUpdate("Wait 20 seconds for the task to get started.", true);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Validate that the 'Start' task is started";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Support.IsTrue(FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").IsDisplayed(), "Task is started");

                Reports.TestStep = "REG63: 6427: Update Task Status Based On Field Changed Task Event";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add Document to Document Repository screen.";
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.AddDocument("Both", "Title Reports", "23192", "CA");
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Select the Title Reports Document and Click on Edit for finalize.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "23192", 4, TableAction.Click);
                FastDriver.DocumentRepository.Info.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.EffectiveDate);
                FastDriver.DocumentRepository.EffectiveDate.FASetText("01-01-01");
                FastDriver.DocumentRepository.btnInfoSave.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(20000);
                Reports.StatusUpdate("Wait 20 seconds for the Waive task to be waived.", true);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Validate that the 'Waive' task is Waived";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Support.IsTrue(FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Waive").Name, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").IsDisplayed(), "Task is Waived");

                Reports.TestStep = "REG64: 6597: Direction Of Task Status Updates";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Complete a task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 2, TableAction.On);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Verify task is completed";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").IsDisplayed(), "Task is started");

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add the ALTA Endorsement 10-06 (Assignment)-N Endorsement Document by create edit.";
                FastDriver.AdHocDocuments.AddDocument("Both", "Endorsement/Guarantee", "ALTA Endorsement 10-06 (Assignment)-N", null);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Select the Endorsement Document and Click on Edit for finalize.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA Endorsement 10-06 (Assignment)-N", 4, TableAction.Click);
                FastDriver.DocumentRepository.Details.FAClick();
                FastDriver.DocumentDetailsScreen.WaitForScreenToLoad();
                docID = int.Parse(FastDriver.DocumentDetailsScreen.DocID.FAGetText().Clean());
                fileID = int.Parse(FastDriver.DocumentDetailsScreen.FileID.FAGetText().Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.FinalizeDocumentUsingWebService(fileID, docID);

                Reports.TestStep = "Verify document status is Finalized";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                Support.AreEqual("Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Endorsement/Guarantee", 9, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Navigate to Document repository";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "ALTA Endorsement 10-06 (Assignment)-N", 4, TableAction.Click);

                Reports.TestStep = "Email the checks.";
                FastDriver.Delivery.Perform(FADeliveryMethod.Email);

                Reports.TestStep = "Select to and click on email delivery.";
                FastDriver.EmailDlg.WaitForScreenToLoad();
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo);
                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - " + AutoConfig.FASTHomeURL);
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Email);
                Playback.Wait(20000);
                Reports.StatusUpdate("Wait 20 seconds and see if the task status has changed.", true);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Verfiy the task Status has not changed";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Complete").Name, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").IsDisplayed(), "Task is started");
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "REG65: 6429: Update Status On Active Tasks";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID("1486");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Regional Process Summary.";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();

                Reports.TestStep = "Click on Edit Button.";
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, process.Name, 1, TableAction.Click);
                FastDriver.RegionalProcessSummary.Edit.FAClick();

                Reports.TestStep = "Setup Field changed task even with task status as Start";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskEventAction.FASelectItem("Start");
                FastDriver.RegionalProcessEdit.SelTaskEvent.FASelectItem("Field Changed");
                FastDriver.RegionalProcessEdit.TaskEventSetup.FAClick();

                Reports.TestStep = "Enter Task Event setup";
                FastDriver.FieldChangedTaskEventSetupDlg.WaitForScreenToLoad();
                FastDriver.FieldChangedTaskEventSetupDlg.Add.FAClick();
                Playback.Wait(500);
                FastDriver.FieldChangedTaskEventSetupDlg.WaitForScreenToLoad(FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable);
                FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable.PerformTableAction(1, 1, TableAction.SelectItem, "Account Servicing Candidate");
                FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable.PerformTableAction(1, 2, TableAction.SelectItem, "EQ");
                FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable.PerformTableAction(1, 3, TableAction.SetText, "12345");
                FastDriver.FieldChangedTaskEventSetupDlg.Done.FAClick();

                Reports.TestStep = "Click Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Notes.";
                FastDriver.NotesEntryDlg.EnterNote("Edited the Selection Criteria").Done.FAClick();

                Reports.TestStep = "Wait for process to refresh.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(process.Name);
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "REG66: cont. 6429 Update Status On Active Tasks";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan Details Screen.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Enter values to New Loan screen.";
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASelectItem("123456");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                Playback.Wait(20000);
                Reports.StatusUpdate("Wait 20 seconds for the task to get started.", true);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Validate that task is started and green checkbox appears";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                Support.IsTrue(FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").IsDisplayed(), "Task is started");

                Reports.TestStep = "REG67: 6428: No Update On Task Status";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Complete the task";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 2, TableAction.On);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                Playback.Wait(500);

                Reports.TestStep = "Verify task is completed";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").IsDisplayed(), "Task is Completed");

                Reports.TestStep = "Navigate to New Loan Details Screen.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Enter values to New Loan screen.";
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASelectItem("123456");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "REG68: Verify task status is still Complete (not Started)";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").IsDisplayed(), "Task is still completed, haven't changed to Started");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0122()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                Reports.TestDescription = "US530614: Search Funtionality for Task Comments (including Comment Codes) in File Workflow and My FAST Today";

                var process = CreateProcessTemplate("FPUC0012_REG0104");
                var taskWithComments = CreateTaskWithComments();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight a task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Select the task with comments.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, taskWithComments.Name, 3, TableAction.Click);
                FastDriver.TaskTemplateSelectionDlg.SelectTasksIIS.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Open comments for newly added task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 12, TableAction.Click);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);

                Reports.TestStep = "Open Find window (CTRL+F).";
                FastDriver.TaskCommentEditDlg.FAControlKeyPress("F");

                Reports.TestStep = "TFS#606187: Validate CTRL-F search functionality is introduced in Task Comments Webpage dialog of File Workflow screen.";
                FastDriver.FindDlg.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FindDlg.TextToFind.IsDisplayed(), "Find IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.FindNext.IsDisplayed(), "Next IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.Cancel.IsDisplayed(), "CloseFind IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.MatchCase.IsDisplayed(), "MatchCase IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.MatchWholeWord.IsDisplayed(), "MatchWholeWord IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.Up.IsDisplayed(), "Up IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.Down.IsDisplayed(), "Down IsDisplayed");

                Reports.TestStep = "TFS#606847: Verify the Cancel button functionality in Find dialog box of File Workflow Task Comments screen.";
                Support.AreEqual(false, FastDriver.FindDlg.FindNext.IsEnabled(), "Next IsEnabled");
                FastDriver.FindDlg.Cancel.FAClick();
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);

                Reports.TestStep = "Open Find window (CTRL+F).";
                FastDriver.TaskCommentEditDlg.FAControlKeyPress("F");

                Reports.TestStep = "TFS#606070: Validate the search functionality in Task Comments screen of File Workflow using Find Next button.";
                FastDriver.FindDlg.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.FindDlg.FindNext.IsEnabled(), "Next IsEnabled");
                FastDriver.FindDlg.TextToFind.FASetText("fpuc0012" + FAKeys.Tab);
                Support.AreEqual(true, FastDriver.FindDlg.FindNext.IsEnabled(), "Next IsEnabled");
                FastDriver.FindDlg.FindNext.FAClick();
                FastDriver.FindDlg.Cancel.FAClick();
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);
                Support.AreEqual("FPUC0012", FastDriver.WebDriver.Execute<string>("return window.getSelection().toString();"), "Selected text (match)");

                Reports.TestStep = "TFS#606250: Validate the search functionality in Task Comments screen of File Workflow using Find Next button with Match whole word only checkbox checked.";
                FastDriver.TaskCommentEditDlg.FAControlKeyPress("F");
                FastDriver.FindDlg.WaitForScreenToLoad();
                FastDriver.FindDlg.MatchWholeWord.FASetCheckbox(true);
                FastDriver.FindDlg.TextToFind.FASetText("whole" + FAKeys.Tab);
                FastDriver.FindDlg.FindNext.FAClick();
                FastDriver.FindDlg.Cancel.FAClick();
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);
                var element = FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea");
                Support.AreEqual("WHOLE", FastDriver.WebDriver.Execute<string>("return arguments[0].value.substring(arguments[0].selectionStart, arguments[0].selectionEnd);", args: element), "Selected text (match)");

                Reports.TestStep = "TFS#606260: Validate the search functionality in Task Comments screen of File Workflow using Find Next button with Match case checkbox checked.";
                FastDriver.TaskCommentEditDlg.FAControlKeyPress("F");
                FastDriver.FindDlg.WaitForScreenToLoad();
                FastDriver.FindDlg.MatchCase.FASetCheckbox(true);
                FastDriver.FindDlg.TextToFind.FASetText("MATCH CASE" + FAKeys.Tab);
                FastDriver.FindDlg.FindNext.FAClick();
                FastDriver.FindDlg.Cancel.FAClick();
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);
                element = FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea");
                Support.AreEqual("MATCH CASE", FastDriver.WebDriver.Execute<string>("return arguments[0].value.substring(arguments[0].selectionStart, arguments[0].selectionEnd);", args: element), "Selected text (match)");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0123()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                Reports.TestDescription = "US530614: Search Funtionality for Task Comments (including Comment Codes) in File Workflow and My FAST Today";

                var process = CreateProcessTemplate("FPUC0012_REG0105");
                var taskWithComments = CreateTaskWithComments();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight a task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Select the task with comments.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, taskWithComments.Name, 3, TableAction.Click);
                FastDriver.TaskTemplateSelectionDlg.SelectTasksIIS.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                
                Reports.TestStep = "Assign the task to FAST QA06 user.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 11, TableAction.Click);
                FastDriver.FileWorkflow.SelAssgTo.FAClick();
                FastDriver.FileWorkflow.SelAssgTo.FASendKeys("+" + FAKeys.Tab);
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad(FastDriver.EmployeeSelectionbyOfficeDlg.EmployeeList);
                FastDriver.EmployeeSelectionbyOfficeDlg.EmployeeList.FASelectItem("QA06, FAST");
                FastDriver.EmployeeSelectionbyOfficeDlg.Select.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Navigate to MFT screen and open the task comments scren.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA06, FAST");
                FastDriver.MyFASTToday.FilterTaskCategory.FASelectItem("Open Order");
                int rowCount = FastDriver.MyFASTToday._ActiveTasksTable.GetRowCount();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    return rowCount < FastDriver.MyFASTToday._ActiveTasksTable.GetRowCount(); //continue when new row is added
                }, timeout: 30, idleInterval: 1);
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(5, taskWithComments.Name, 12, TableAction.Click);

                Reports.TestStep = "TFS#619031: Validate CTRL-F search functionality is introduced in Task Comments Webpage dialog of My Fast Today screen.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);
                FastDriver.TaskCommentEditDlg.FAControlKeyPress("F");
                FastDriver.FindDlg.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FindDlg.TextToFind.IsDisplayed(), "Find IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.FindNext.IsDisplayed(), "Next IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.Cancel.IsDisplayed(), "CloseFind IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.MatchCase.IsDisplayed(), "MatchCase IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.MatchWholeWord.IsDisplayed(), "MatchWholeWord IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.Up.IsDisplayed(), "Up IsDisplayed");
                Support.AreEqual(true, FastDriver.FindDlg.Down.IsDisplayed(), "Down IsDisplayed");

                Reports.TestStep = "TFS#619040: Verify the Cancel button functionality in Find dialog box of My Fast Today Task Comments screen.";
                Support.AreEqual(false, FastDriver.FindDlg.FindNext.IsEnabled(), "Next IsEnabled");
                FastDriver.FindDlg.Cancel.FAClick();
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);

                Reports.TestStep = "Open Find window (CTRL+F).";
                FastDriver.TaskCommentEditDlg.FAControlKeyPress("F");

                Reports.TestStep = "TFS#619037: Validate the search functionality in Task Comments screen of My Fast Today using Find Next button.";
                FastDriver.FindDlg.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.FindDlg.FindNext.IsEnabled(), "Next IsEnabled");
                FastDriver.FindDlg.TextToFind.FASetText("fpuc0012" + FAKeys.Tab);
                Support.AreEqual(true, FastDriver.FindDlg.FindNext.IsEnabled(), "Next IsEnabled");
                FastDriver.FindDlg.FindNext.FAClick();
                FastDriver.FindDlg.Cancel.FAClick();
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);
                Support.AreEqual("FPUC0012", FastDriver.WebDriver.Execute<string>("return window.getSelection().toString();"), "Selected text (match)");

                Reports.TestStep = "TFS#619038: Validate the search functionality in Task Comments screen of My Fast Today using Find Next button with Match whole word only checkbox checked.";
                FastDriver.TaskCommentEditDlg.FAControlKeyPress("F");
                FastDriver.FindDlg.WaitForScreenToLoad();
                FastDriver.FindDlg.MatchWholeWord.FASetCheckbox(true);
                FastDriver.FindDlg.TextToFind.FASetText("whole" + FAKeys.Tab);
                FastDriver.FindDlg.FindNext.FAClick();
                FastDriver.FindDlg.Cancel.FAClick();
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);
                var element = FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea");
                Support.AreEqual("WHOLE", FastDriver.WebDriver.Execute<string>("return arguments[0].value.substring(arguments[0].selectionStart, arguments[0].selectionEnd);", args: element), "Selected text (match)");

                Reports.TestStep = "TFS#619039: Validate the search functionality in Task Comments screen of My Fast Today using Find Next button with Match case checkbox checked.";
                FastDriver.TaskCommentEditDlg.FAControlKeyPress("F");
                FastDriver.FindDlg.WaitForScreenToLoad();
                FastDriver.FindDlg.MatchCase.FASetCheckbox(true);
                FastDriver.FindDlg.TextToFind.FASetText("MATCH CASE" + FAKeys.Tab);
                FastDriver.FindDlg.FindNext.FAClick();
                FastDriver.FindDlg.Cancel.FAClick();
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(element: FastDriver.TaskCommentEditDlg.TaskCommentTable, switchToContentFrame: true);
                element = FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea");
                Support.AreEqual("MATCH CASE", FastDriver.WebDriver.Execute<string>("return arguments[0].value.substring(arguments[0].selectionStart, arguments[0].selectionEnd);", args: element), "Selected text (match)");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FPUC0012_REG0124()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                Reports.TestDescription = "US530614: Search Funtionality for Task Comments (including Comment Codes) in File Workflow and My FAST Today";

                var process = CreateProcessTemplate("FPUC0012_REG0106");
                var taskWithComments = CreateTaskWithComments();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight a task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Select the task with comments.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, taskWithComments.Name, 3, TableAction.Click);
                FastDriver.TaskTemplateSelectionDlg.SelectTasksIIS.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Select the newly added task then select Assigned To as FAST QA06 user from the dropdown";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 11, TableAction.Click);
                FastDriver.FileWorkflow.SelAssgTo.FASendKeys("+" + FAKeys.Tab);
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad(FastDriver.EmployeeSelectionbyOfficeDlg.EmployeeList);
                FastDriver.EmployeeSelectionbyOfficeDlg.EmployeeList.FASelectItem("QA06, FAST");
                FastDriver.EmployeeSelectionbyOfficeDlg.Select.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "TFS#619142: Validate for the maximum length(255 charaters) of Comment code description in Task Comments Webpage dialog of File Workflow screen";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 12, TableAction.Click);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(switchToContentFrame: true);
                FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.SetText, "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at pulvinar magna. Etiam finibus et turpis id fringilla. Sed congue luctus malesuada. Donec accumsan quis ipsum ac tincidunt. Nam convallis ultricies diam. Sed aliquet hendrerit sagittis el.");
                Support.AreEqual("255", FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea").FAGetValue().Length.ToString(), "Verifying maximum amount of characters allowed.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "TFS#619206: To Verify tooltip of Comment Code Description is displayed Correctly in File Workflow screen.";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 12, TableAction.GetCell).Element.FAMoveToElement();
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 12, TableAction.GetCell).Element.FAGetAttribute("title").Contains("Lorem ipsum dolor sit amet"), "Verifying tool tip text.");

                Reports.TestStep = "Attempt to exceed the maximum length (255 charaters) of Comment code description in Task Comments Webpage dialog of File Workflow screen";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 12, TableAction.Click);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(switchToContentFrame: true);
                FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.SetText, "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at pulvinar magna. Etiam finibus et turpis id fringilla. Sed congue luctus malesuada. Donec accumsan quis ipsum ac tincidunt. Nam convallis ultricies diam. Sed aliquet hendrerit sagittis e123456.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 12, TableAction.Click);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(switchToContentFrame: true);
                Support.AreEqual("255", FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea").FAGetValue().Length.ToString(), "Verifying maximum amount of characters allowed.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Click on Apply button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to My Fast Today screen, search for the newly created task";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>("My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA06, FAST");
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, taskWithComments.Name, 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Select the task and Click on Task Comment icon for the same task";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(4, fileNumber, 12, TableAction.Click);

                Reports.TestStep = "TFS#619143: Validate for the maximum length(255 charaters) of Comment code description in Task Comments Webpage dialog of My Fast Today Screen";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(switchToContentFrame: true);
                FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.SetText, "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at pulvinar magna. Etiam finibus et turpis id fringilla. Sed congue luctus malesuada. Donec accumsan quis ipsum ac tincidunt. Nam convallis ultricies diam. Sed aliquet hendrerit sagittis el.");
                Support.AreEqual("255", FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea").FAGetValue().Length.ToString(), "Verifying maximum amount of characters allowed.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "TFS#619217: To Verify tooltip of Comment Code Description is displayed Correctly in My Fast Today screen.";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(4, fileNumber, 12, TableAction.GetCell).Element.FAMoveToElement();
                Support.AreEqual(true, FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(4, fileNumber, 12, TableAction.GetCell).Element.FAGetAttribute("title").Contains("Lorem ipsum dolor sit amet"), "Verifying tool tip text.");

                Reports.TestStep = "Attempt to exceed the maximum length (255 charaters) of Comment code description in Task Comments Webpage dialog of My Fast Today screen";
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(4, fileNumber, 12, TableAction.Click);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(switchToContentFrame: true);
                FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.SetText, "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at pulvinar magna. Etiam finibus et turpis id fringilla. Sed congue luctus malesuada. Donec accumsan quis ipsum ac tincidunt. Nam convallis ultricies diam. Sed aliquet hendrerit sagittis e123456.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Verify tooltip of Comment Code Description is displayed Correctly in My Fast Today screen";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(4, fileNumber, 12, TableAction.Click);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(switchToContentFrame: true);
                Support.AreEqual("255", FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea").FAGetValue().Length.ToString(), "Verifying maximum amount of characters allowed.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.WebDriver.Quit();
                
                taskWithComments = CreateTaskWithComments(modifiable: false);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight a task.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, process.Tasks.First(t => t.Status == "Start").Name, 5, TableAction.Click);

                Reports.TestStep = "Click On Add Task Button.";
                FastDriver.FileWorkflow.AddTask.FAClick();

                Reports.TestStep = "Click on View More.";
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();

                Reports.TestStep = "Select the task with comments.";
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, taskWithComments.Name, 3, TableAction.Click);
                FastDriver.TaskTemplateSelectionDlg.SelectTasksIIS.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Select the newly added task then select Assigned To as FASt QA06 from the dropdown";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 11, TableAction.Click);
                FastDriver.FileWorkflow.SelAssgTo.FASendKeys("+" + FAKeys.Tab);
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad(FastDriver.EmployeeSelectionbyOfficeDlg.EmployeeList);
                FastDriver.EmployeeSelectionbyOfficeDlg.EmployeeList.FASelectItem("QA06, FAST");
                FastDriver.EmployeeSelectionbyOfficeDlg.Select.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "TFS#619228: Field is readonly when Modifiable option is checked (File Workflow).";
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(5, taskWithComments.Name, 12, TableAction.Click);
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(switchToContentFrame: true);
                Support.AreEqual(true, FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea").IsReadOnly(), "Verify that field is read only.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Click on Apply button.";
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to My Fast Today screen, search for the newly created task";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>("My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.FilterEmployee.FASelectItem("QA06, FAST");
                FastDriver.MyFASTToday.TaskRegion.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();
                FastDriver.TaskNameSelection.WaitForScreenToLoad();
                FastDriver.TaskNameSelection.TaskTable.PerformTableAction(2, taskWithComments.Name, 1, TableAction.On);
                FastDriver.TaskNameSelection.Select.FAClick();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Select the task and Click on Task Comment icon for the same task";
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(4, fileNumber, 12, TableAction.Click);

                Reports.TestStep = "TFS#619229: Field is readonly when Modifiable option is checked (My Fast Today).";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(switchToContentFrame: true);
                Support.AreEqual(true, FastDriver.TaskCommentEditDlg.TaskCommentTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "textarea").IsReadOnly(), "Verify that field is read only.");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FPUC0012_REG125()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = GetCustomFileRequest(FASTWCFHelpers.DataObjects.TransactionTypeOCD.SaleCash);
                #endregion

                var process = CreateProcessTemplate("FPUC0012_REG0125");

                Reports.TestDescription = "Bug 806107: 10.5_UAT_INC2850387: Due date and times locks up";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to FWF.";
                OpenFileWorkflow(process.Name);

                Reports.TestStep = "Highlight a task and click on Task Details";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                string tableId = FastDriver.FileWorkflow.GetWorkFlowTableID(process.Name);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(1, 4, TableAction.Click);
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Access the Task Details and set a Due Date";
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad(element: FastDriver.TaskDetailsDlg.DueDate);
                FastDriver.TaskDetailsDlg.DueDate.FASetText(DateTime.Now.AddBusinessDays(8).ToDateString());
                FastDriver.TaskDetailsDlg.Done.FAClick();

                Reports.TestStep = "Click on Task Details once more.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(1, 4, TableAction.Click);
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Access the Task Details and clear a Due Date";
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad(element: FastDriver.TaskDetailsDlg.DueDate);
                FastDriver.TaskDetailsDlg.ClearDueDateandTime.FAClick();
                FastDriver.TaskDetailsDlg.Done.FAClick();

                Reports.TestStep = "Click on Task Details once more.";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, tableId).PerformTableAction(1, 4, TableAction.Click);
                FastDriver.FileWorkflow.Details.FAClick();

                Reports.TestStep = "Access the Task Details and clear a Due Date";
                FastDriver.TaskDetailsDlg.WaitForScreenToLoad(element: FastDriver.TaskDetailsDlg.DueDate);
                FastDriver.TaskDetailsDlg.DueDate.FASetText(DateTime.Now.AddBusinessDays(8).ToDateString());
                FastDriver.TaskDetailsDlg.Done.FAClick();

                Reports.TestStep = "Verify that Done button closed window and is displaying the File Workflow screen";
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileWorkflow.Details.IsDisplayed(), "Verifying that Task Details modal window is closed.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        /// <summary>
        /// Creates a new Process Template.
        /// </summary>
        /// <param name="testCaseName"></param>
        /// <returns>An instance of ProcessTemplateInformation with the data of the newly created Process Template.</returns>
        private WorkflowProcessTemplateInformation CreateProcessTemplate(string testCaseName, string transactionType = "Sale/Cash")
        {
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            var processTemplate = new WorkflowProcessTemplateInformation
            {
                Type = "1099",
                Name = "FPUC0012_Regression_Automation_DO_NOT_TOUCH",
                WorkGroupName = "Accounting",
                Tasks = new List<WorkflowProcessTask>()
            };
            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "FPUC0012_TASK_Start", Status = "Start" });
            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "FPUC0012_TASK_Complete", Status = "Complete" });
            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "FPUC0012_TASK_Waive", Status = "Waive" });
            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "FPUC0012_TASK_Inactive", Status = "Inactive" });

            Reports.TestStep = "Create new template";
            Reports.StatusUpdate(string.Format("Create new template for {0}.", testCaseName), true);

            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            Reports.TestStep = "Navigate to Region Level.";
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);
            FastDriver.HomePage.WaitForHomeScreen();

            Reports.TestStep = "Navigate to Regional Process Summary.";
            FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();

            Reports.TestStep = "Verify if process template is created.";
            if (FastDriver.RegionalProcessSummary.ProcessSummaryTable.FAGetText().Contains(processTemplate.Name))
            {
                Reports.StatusUpdate("Process template is already created.", true);

                Reports.TestStep = "Ensure template is Active";
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processTemplate.Name, 1, TableAction.Click);
                if (FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processTemplate.Name, 4, TableAction.GetText).Message.Clean() == "Active")
                {
                    Reports.StatusUpdate("Template is Active.", true);
                }
                else
                {
                    Reports.StatusUpdate("Template is Inactive.", true);

                    Reports.TestStep = "Change the template status to Active.";
                    FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                    FastDriver.StatusEdit.WaitForScreenToLoad();
                    FastDriver.StatusEdit.Activate.FAClick();

                    Reports.TestStep = "Click on Ok button.";
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                    Reports.TestStep = "Click on Ok button.";
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                    Reports.TestStep = "Click on Ok button.";
                    FastDriver.WebDriver.HandleDialogMessage();

                    Reports.TestStep = "Navigate to Pending Refresh Summary and refresh the template.";
                    FastDriver.PendingRefreshSummary.RefreshTemplate(processTemplate.Name);
                }

                FastDriver.WebDriver.Quit();
            }
            else
            {
                Reports.StatusUpdate("Process template is not created, create a new one.", true);
                FastDriver.RegionalProcessSummary.New.FAClick();

                Reports.TestStep = "Enter Process basic info.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessType.FASelectItem(processTemplate.Type);
                FastDriver.RegionalProcessEdit.ProcessName.FASetText(processTemplate.Name);
                FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
                FastDriver.RegionalProcessEdit.Description.FASetText("Selenium001");

                Reports.TestStep = "Enter process template selection criteria.";
                FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.TranType.FASelectItem(transactionType);
                FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction(2, "CA", 1, TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                FastDriver.CountySelectionDlg.Table.PerformTableAction(2, "YOLO", 1, TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.AddRemoveCity.FAClick();
                FastDriver.CitySelectionDlg.WaitForScreenToLoad();
                FastDriver.CitySelectionDlg.Clear.FAClick();
                FastDriver.CitySelectionDlg.CityTable.PerformTableAction(2, "YOLO", 1, TableAction.On);
                FastDriver.CitySelectionDlg.Select.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.Done.FAClick();

                Reports.TestStep = "Enter process event selection criteria.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "File created with Open status", 1, TableAction.On);
                FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "Home Warranty", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter process template tasks.";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.Add.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                foreach (var task in processTemplate.Tasks)
                {
                    if (FastDriver.TaskTemplateSelectionDlg.TasksForTable.FAGetText().Contains(task.Name))
                    {
                        //if the task already exists add it to the template
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, task.Name, 5, TableAction.SelectItem, "Yes");
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, task.Name, 4, TableAction.SetText, task.Name);
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, task.Name, 2, TableAction.On);
                    }
                    else
                    {
                        //if the task doesn't exist, create it and add it
                        int rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                        FastDriver.TaskTemplateSelectionDlg.New.FAClick();
                        FastDriver.WebDriver.WaitForActionToComplete(() =>
                        {
                            //continue when new row is added
                            return rowCount < FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                        }, timeout: 20, idleInterval: 2);
                        rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();//get last row count to add new task info

                        Reports.TestStep = "Add info for new task.";//add new tasks using static task name
                        FastDriver.TaskTemplateSelectionDlg.WaitCreation(FastDriver.TaskTemplateSelectionDlg.TasksForTable);
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 3, TableAction.SetText, task.Name);
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 5, TableAction.SelectItem, "Yes");
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 4, TableAction.SetText, task.Name);
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 2, TableAction.On);
                    }
                }
                FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();

                Reports.TestStep = "Edit added tasks.";
                foreach (var task in processTemplate.Tasks)
                {
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, task.Name, 2, TableAction.Click);
                    if (task.Status == "Complete")
                        FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, task.Name, 3, TableAction.SelectItem, "After Open Date");
                    else if (task.Status == "Inactive")
                    {
                        FastDriver.RegionalProcessEdit.Inactive.FAClick();
                        FastDriver.RegionalProcessEdit.TaskEventAction.FASelectItem("Start");
                        FastDriver.RegionalProcessEdit.SelTaskEvent.FASelectItem("Date Down");
                    }
                    else
                    {
                        FastDriver.RegionalProcessEdit.TaskEventAction.FASelectItem(task.Status);
                        FastDriver.RegionalProcessEdit.SelTaskEvent.FASelectItem("Date Down");
                        if (task.Status == "Start")
                        {
                            FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                            FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                            FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
                            FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                            FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem(processTemplate.WorkGroupName);
                            FastDriver.WorkgroupSelectionDlg.Select.FAClick();
                            FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                            FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, processTemplate.WorkGroupName, 1, TableAction.On);
                            FastDriver.DialogBottomFrame.ClickDone();
                        }
                    }
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the created process name from the Regional Process Summary table.";
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processTemplate.Name, 1, TableAction.Click);

                Reports.TestStep = "Change the status.";
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.WaitForScreenToLoad();
                FastDriver.StatusEdit.Activate.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to Pending Refresh Summary.";
                FastDriver.PendingRefreshSummary.RefreshTemplate(processTemplate.Name);
                FastDriver.WebDriver.Quit();
            }
            return processTemplate;
        }

        /// <summary>
        /// Creates a new Process Template.
        /// </summary>
        /// <param name="testCaseName"></param>
        /// <returns>An instance of ProcessTemplateInformation with the data of the newly created Process Template.</returns>
        private WorkflowProcessTemplateInformation CreateDetailedProcessTemplate(string testCaseName, bool addSuccessor = true, bool addTaskEvents = false)
        {
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            var processTemplate = new WorkflowProcessTemplateInformation
            {
                Type = "1099",
                Name = "FPUC0012_" + Support.RandomString("AAZNZNNA"),
                WorkGroupName = "Accounting",
                Tasks = new List<WorkflowProcessTask>()
            };

            Reports.TestStep = "Create new template";
            Reports.StatusUpdate(string.Format("Create new template for {0}.", testCaseName), true);

            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            Reports.TestStep = "Navigate to Region Level.";
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID("1486");
            FastDriver.HomePage.WaitForHomeScreen();

            Reports.TestStep = "Navigate to Regional Process Summary.";
            FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.New.FAClick();

            Reports.TestStep = "Enter Process basic info.";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.ProcessType.FASelectItem(processTemplate.Type);
            FastDriver.RegionalProcessEdit.ProcessName.FASetText(processTemplate.Name);
            FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
            FastDriver.RegionalProcessEdit.Description.FASetText("Selenium001");

            Reports.TestStep = "Enter process template selection criteria.";
            FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.TranType.FASelectItem("Short Sale/Cash");
            FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();
            FastDriver.StateSelectionDlg.WaitForScreenToLoad();
            FastDriver.StateSelectionDlg.Clear.FAClick();
            FastDriver.StateSelectionDlg.table.PerformTableAction(2, "CA", 1, TableAction.On);
            FastDriver.StateSelectionDlg.Select.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();
            FastDriver.CountySelectionDlg.WaitForScreenToLoad();
            FastDriver.CountySelectionDlg.Clear.FAClick();
            FastDriver.CountySelectionDlg.Table.PerformTableAction(2, "YOLO", 1, TableAction.On);
            FastDriver.CountySelectionDlg.Select.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.AddRemoveCity.FAClick();
            FastDriver.CitySelectionDlg.WaitForScreenToLoad();
            FastDriver.CitySelectionDlg.Clear.FAClick();
            FastDriver.CitySelectionDlg.CityTable.PerformTableAction(2, "YOLO", 1, TableAction.On);
            FastDriver.CitySelectionDlg.Select.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.Done.FAClick();

            Reports.TestStep = "Enter process event selection criteria.";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
            FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
            FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "File created with Open status", 1, TableAction.On);
            FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "Home Warranty", 1, TableAction.On);
            FastDriver.DialogBottomFrame.ClickDone();

            Reports.TestStep = "Enter process template tasks.";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.Add.FAClick();
            FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
            for (int i = 1; i <= 3; i++)
            {
                processTemplate.Tasks.Add(new WorkflowProcessTask()); //add a new task to the list

                Playback.Wait(500);
                string status = "";
                switch (i)
                {
                    case 1:
                        status = "Start";
                        break;
                    case 2:
                        status = "Complete";
                        break;
                    case 3:
                        status = "Waive";
                        break;
                    case 4:
                        status = "Inactive";
                        break;
                }
                processTemplate.Tasks.Last().Status = status; //set the task status based in the order
                processTemplate.Tasks.Last().Name = "FPUC0012_TASK_" + i.ToString() + "_" + status; //set the task name based on order + status

                Playback.Wait(2000);
                if (FastDriver.TaskTemplateSelectionDlg.TasksForTable.FAGetText().Contains(processTemplate.Tasks.Last().Name))
                {
                    //if the task already exists add it to the template
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, processTemplate.Tasks.Last().Name, 5, TableAction.SelectItem, "Yes");
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, processTemplate.Tasks.Last().Name, 4, TableAction.SetText, processTemplate.Tasks.Last().Name);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, processTemplate.Tasks.Last().Name, 2, TableAction.On);
                }
                else
                {
                    //if the task doesn't exist, create it and add it
                    int rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                    FastDriver.TaskTemplateSelectionDlg.New.FAClick();
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        //continue when new row is added
                        return rowCount < FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
                    }, timeout: 20, idleInterval: 2);
                    rowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();//get last row count to add new task info

                    Reports.TestStep = "Add info for new task.";//add new tasks using static task name
                    FastDriver.TaskTemplateSelectionDlg.WaitCreation(FastDriver.TaskTemplateSelectionDlg.TasksForTable);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 3, TableAction.SetText, processTemplate.Tasks.Last().Name);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 5, TableAction.SelectItem, "Yes");
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 4, TableAction.SetText, processTemplate.Tasks.Last().Name);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(rowCount, 2, TableAction.On);
                }
            }
            FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();

            Reports.TestStep = "Edit added tasks.";
            foreach (var task in processTemplate.Tasks)
            {
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(2, task.Name, 2, TableAction.Click);

                Reports.TestStep = "Add a workgroup";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem(processTemplate.WorkGroupName);
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, processTemplate.WorkGroupName, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                if (addSuccessor && task.Status == "Start")
                {
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.Directingstatus1.FASelectItem(task.Status);
                    FastDriver.RegionalProcessEdit.ViewEditSuccessors1.FAClick();

                    Reports.TestStep = "Add a successor task and path";
                    FastDriver.SuccessorSetupDlg.WaitForScreenToLoad();
                    FastDriver.SuccessorSetupDlg.AddTask.FAClick();
                    Playback.Wait(250);
                    FastDriver.SuccessorSetupDlg.TaskDetailsTable.PerformTableAction(1, 1, TableAction.SelectItemByIndex, "0");
                    FastDriver.SuccessorSetupDlg.TaskDetailsTable.PerformTableAction(1, 2, TableAction.SelectItem, "Start");
                    FastDriver.SuccessorSetupDlg.TaskDetailsTable.PerformTableAction(2, 1, TableAction.SelectItemByIndex, "1");
                    FastDriver.SuccessorSetupDlg.TaskDetailsTable.PerformTableAction(2, 2, TableAction.SelectItem, "Start");
                    FastDriver.SuccessorSetupDlg.Done.FAClick();
                }

                if (addTaskEvents)
                {
                    Reports.TestStep = "Give the Task Event details";
                    if (task.Status == "Start" || task.Status == "Complete")
                    {
                        FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                        FastDriver.RegionalProcessEdit.Directingstatus1.FASelectItemByIndex(0);
                        FastDriver.RegionalProcessEdit.TaskEventAction.FASelectItem("Start");
                        Playback.Wait(250);
                        FastDriver.RegionalProcessEdit.SelTaskEvent.FASelectItem("Document Delivered");
                        FastDriver.RegionalProcessEdit.TaskEventSetup.FAClick();

                        Reports.TestStep = "Select the Email delivery option";
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.WaitForScreenToLoad();
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.DeliveryMethods.FASelectItem("EMAIL");
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.Add.FAClick();

                        Reports.TestStep = "Select the Template type and find the docs.";
                        FastDriver.DocumentDeliverySelectionDlg.WaitForScreenToLoad();
                        FastDriver.DocumentDeliverySelectionDlg.TemplateType.FASelectItem("Endorsement/Guarantee");
                        FastDriver.DocumentDeliverySelectionDlg.State.FASelectItem("CA");
                        FastDriver.DocumentDeliverySelectionDlg.TemplateDescription.FASetText("ALTA Endorsement 10-06 (Assignment)-N");
                        FastDriver.DocumentDeliverySelectionDlg.FindNow.FAClick();
                        Playback.Wait(500);
                        FastDriver.DocumentDeliverySelectionDlg.SearchResultsTable.PerformTableAction(3, "ALTA Endorsement 10-06 (Assignment)-N", 1, TableAction.On);
                        FastDriver.DocumentDeliverySelectionDlg.SelectTemplates.FAClick();
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.WaitForScreenToLoad();
                        FastDriver.DocumentDeliveryTaskEventSetupDlg.Done.FAClick();
                    }
                    if (task.Status == "Waive")
                    {
                        //FastDriver.RegionalProcessEdit.Directingstatus1.FASelectItemByIndex(0);
                        FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                        FastDriver.RegionalProcessEdit.TaskEventAction.FASelectItem("Waive");
                        Playback.Wait(250);
                        FastDriver.RegionalProcessEdit.SelTaskEvent.FASelectItem("Field Changed");
                        FastDriver.RegionalProcessEdit.TaskEventSetup.FAClick();

                        Reports.TestStep = "Select task event";
                        FastDriver.FieldChangedTaskEventSetupDlg.WaitForScreenToLoad();
                        FastDriver.FieldChangedTaskEventSetupDlg.Add.FAClick();
                        Playback.Wait(500);
                        FastDriver.FieldChangedTaskEventSetupDlg.WaitForScreenToLoad(FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable);
                        FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable.PerformTableAction(1, 1, TableAction.SelectItem, "Title Report Effective Date");
                        FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable.PerformTableAction(1, 2, TableAction.SelectItem, "EQ");
                        FastDriver.FieldChangedTaskEventSetupDlg.FieldChangeTable.PerformTableAction(1, 3, TableAction.SetText, "01-01-01");
                        FastDriver.FieldChangedTaskEventSetupDlg.Done.FAClick();
                    }
                }
            }
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Select the created process name from the Regional Process Summary table.";
            FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processTemplate.Name, 1, TableAction.Click);

            Reports.TestStep = "Change the status.";
            FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
            FastDriver.StatusEdit.WaitForScreenToLoad();
            FastDriver.StatusEdit.Activate.FAClick();

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage();

            Reports.TestStep = "Navigate to Pending Refresh Summary.";
            FastDriver.PendingRefreshSummary.RefreshTemplate(processTemplate.Name);
            FastDriver.WebDriver.Quit();

            return processTemplate;
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetCustomFileRequest(string trasnType)
        {
            var req = RequestFactory.GetDetailedCreateFileDefaultRequest();
            req.File.TransactionTypeObjectCD = trasnType;
            req.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                };
            req.File.Properties[0].PropertyAddress[0].Country = "USA";
            req.File.Properties[0].PropertyAddress[0].State = "CA";
            req.File.Properties[0].PropertyAddress[0].County = "YOLO";
            req.File.Properties[0].PropertyAddress[0].City = "YOLO";
            req.File.NewLoan.LiabilityAmount = 5000;
            req.File.SalesPriceAmount = 5000;
            req.File.NewLoan.NewLoanAmount = 5000;

            return req;
        }

        private WorkflowProcessTask CreateTaskWithComments(bool modifiable = true)
        {
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            WorkflowProcessTask task = new WorkflowProcessTask { Name = "FPUC0012_Task_With_Comments", Status = "Start", CommentCodes = new List<TaskComment>() };
            task.CommentCodes.Add(new TaskComment
            {
                Code = "FPUC0012_D",
                Description = "match case MATCH CASE wholeword WHOLE WORD fpuc0012."
            });

            Reports.TestStep = "Creating a new task with comments for FPUC0012";
            Reports.StatusUpdate("Creating a new task with comments for FPUC0012.", true);

            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            Reports.TestStep = "Navigate to Region Level.";
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);
            FastDriver.HomePage.WaitForHomeScreen();

            Reports.TestStep = "Navigate to Comment Codes.";
            FastDriver.LeftNavigation.Navigate<CommentCodes>(@"Home>System Maintenance>Process Setup>Comment Codes").WaitForScreenToLoad();

            Reports.TestStep = "Create comment code if it's not created.";
            if (FastDriver.CommentCodes.CommentCodeTable.FAGetText().Contains(task.CommentCodes.First().Code))
            {
                Reports.StatusUpdate("Comment code is already created, skipping creation.", true);

                // reset comment description if it's not the expected text
                if (FastDriver.CommentCodes.CommentCodeTable.PerformTableAction(3, task.CommentCodes.First().Code, 4, TableAction.GetText).Message.Clean() != task.CommentCodes.First().Description)
                {
                    FastDriver.CommentCodes.CommentCodeTable.PerformTableAction(3, task.CommentCodes.First().Code, 3, TableAction.Click);
                    FastDriver.CommentCodes.Edit.FAClick();
                    Playback.Wait(250);
                    FastDriver.CommentCodes.CommentCodeTable.PerformTableAction(3, task.CommentCodes.First().Code, 4, TableAction.SetText, task.CommentCodes.First().Description);
                }

                FastDriver.CommentCodes.CommentCodeTable.PerformTableAction(3, task.CommentCodes.First().Code, 3, TableAction.Click);
                FastDriver.CommentCodes.Edit.FAClick();
                Playback.Wait(250);
                FastDriver.CommentCodes.CommentCodeTable.PerformTableAction(3, task.CommentCodes.First().Code, 6, modifiable ? TableAction.On : TableAction.Off);
                FastDriver.BottomFrame.Save();
            }
            else
            {
                Reports.StatusUpdate("Comment code not created, creating it...", true);

                Reports.TestStep = "Enter comment code information.";
                int rowCount = FastDriver.CommentCodes.CommentCodeTable.GetRowCount();
                FastDriver.CommentCodes.New.FAClick();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    return rowCount < FastDriver.CommentCodes.CommentCodeTable.GetRowCount(); //continue when new row is added
                }, timeout: 30, idleInterval: 1);
                rowCount = FastDriver.CommentCodes.CommentCodeTable.GetRowCount();
                FastDriver.CommentCodes.CommentCodeTable.PerformTableAction(rowCount, 3, TableAction.SetText, task.CommentCodes.First().Code);
                FastDriver.CommentCodes.CommentCodeTable.PerformTableAction(rowCount, 4, TableAction.SetText, task.CommentCodes.First().Description);
                FastDriver.CommentCodes.CommentCodeTable.PerformTableAction(rowCount, 5, TableAction.SelectItem, "Active");
                FastDriver.CommentCodes.CommentCodeTable.PerformTableAction(rowCount, 6, modifiable ? TableAction.On : TableAction.Off);
                FastDriver.BottomFrame.Save();
            }

            Reports.TestStep = "Navigate to Task Templates.";
            FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Home>System Maintenance>Process Setup>Task Templates").WaitForScreenToLoad(element: FastDriver.TaskTemplateSelection.TasksForTable);

            Reports.TestStep = "Create task if it's not in Tasks table.";
            if (FastDriver.TaskTemplateSelection.TasksForTable.FAGetText().Contains(task.Name))
            {
                Reports.StatusUpdate("Task is already created and available.", true);

                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(3, task.Name, 9, TableAction.Click);
                FastDriver.CommentCodeDlg.WaitForScreenToLoad(element: FastDriver.CommentCodeDlg.CommentCodeRequired);
                FastDriver.CommentCodeDlg.CommentCodeTable.PerformTableAction(2, task.CommentCodes.First().Code, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad(FastDriver.TaskTemplateSelection.TasksForTable);
            }
            else
            {
                Reports.StatusUpdate("Task is not available, need to create it.", true);
                FastDriver.TaskTemplateSelection.CreateNewTask(task: task, publicTask: true, addCommentCodes: true);
            }

            FastDriver.WebDriver.Quit();
            return task;
        }

        private void OpenFileWorkflow(string processName)
        {
            FastDriver.WebDriver.WaitForActionToComplete(() =>
            {
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                Playback.Wait(2000);

                return FastDriver.FileWorkflow.ProcessTable.FAGetText().Contains(processName);
            }, timeout: 120, idleInterval: 20);
        }
    }
}