﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
//using AutoIt;
using System.Linq;
using System.Collections.Generic;
using System.Threading;

namespace FileManagement
{
    /// <summary>
    /// Summary description for FMUC0010_Maintain_File_notes
    /// </summary>
    [CodedUITest]
    public class FMUC0010 : MasterTestClass
    {
        #region BAT

        #region Test FMUC0010_BAT0001

        [TestMethod]
        public void FMUC0010_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Add a Note.";

                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();                
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Validate the new note created is present.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.Table.PerformTableAction(1, "create a new note", 2, TableAction.Click);

                #endregion GUI interaction


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_BAT0002
        [TestMethod]
        public void FMUC0010_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Append a note.";
                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Click on the new note created is present.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.Table.PerformTableAction(1, "create a new note", 2, TableAction.Click);

                Reports.TestStep = "Append a Note.";
                FastDriver.FileNotes.Append.Click();
                FastDriver.FileNotesEditor.AddNote("Append a new note");
                FastDriver.FileNotesEditor.CheckSpelling.Click();
                Playback.Wait(10000);

                Reports.TestStep = "Validate spell check complete text.";
                Support.AreEqual("Spelling check complete", FastDriver.WebDriver.HandleDialogMessage(false));

                Reports.TestStep = "Click on Done in dialog box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("SMSSpellChecker");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("SMSSpellChecker", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate append note created is present.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

                this.VerifySubString(FastDriver.FileNotes.TaskNotes.FAGetText().ToString(), "Append a new note");

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_BAT0003
        [TestMethod]
        public void FMUC0010_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF2: Preview Notes.";
                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Click on the new note created is present.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.Table.PerformTableAction(1, "create a new note", 2, TableAction.Click);

                Reports.TestStep = "Append a Note.";
                FastDriver.FileNotes.Append.Click();
                FastDriver.FileNotesEditor.AddNote("Append a new note");
                FastDriver.FileNotesEditor.CheckSpelling.Click();

                Reports.TestStep = "Validate spell check complete text.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Done in dialog box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("SMSSpellChecker");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("SMSSpellChecker", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate append note created is present.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

                this.VerifySubString(FastDriver.FileNotes.TaskNotes.FAGetText().ToString(), "Append a new note");
                FastDriver.FileNotes.TaskNotes.Click();

                Reports.TestStep = "navigate to the File Notes.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

                Reports.TestStep = "Select All Notes Click on Preview";
                FastDriver.FileNotes.NotesType.FASelectItem("All Notes");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.TaskNotes.FAClick();
                FastDriver.FileNotes.Preview.FAClick();

                Reports.TestStep = "Validate preview notes.";
                FastDriver.FileNotes.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.FileNotes.TitlePreview.Exists().ToString());
                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_BAT0004A
        [TestMethod]
        public void FMUC0010_BAT0004A()
        {
            try
            {
                Reports.TestDescription = "Precondition: Validate for Task is enabled.";
                Reports.StatusUpdate("This flow is covered in BAT0004C", true);


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_BAT0004B
        [TestMethod]
        public void FMUC0010_BAT0004B()
        {
            try
            {
                Reports.TestDescription = "Dependency Flow: Process for Manual Activation, if Task is not in Activate status";
                Reports.StatusUpdate("This flow is covered in BAT0004C",true);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_BAT0004C
        [TestMethod]
        public void FMUC0010_BAT0004C()
        {
            try
            {
                Reports.TestDescription = "AF6: Copied Task Comments to File Notes via Workflow.";
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FMUC0010_FileNotes_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = @"REO Sale/Cash";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent = "File created with Open status";
                ProcParams.Tasks = new[] { "FMUC0010_FileNotes1","FMUC0010_FileNotes2" };
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams);
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Create a basic file";
                string FileNumber = CreateQFEWithDetails(TransactionType: @"REO Sale/Cash");

                Reports.TestStep = "Navigate to file workflow.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Check if Process Name exists.";
                Support.AreEqual("True", FastDriver.FileWorkflow.CheckIfProcessIsPulled("FMUC0010_FileNotes_Template").ToString());
                //if (FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "2", 3, TableAction.GetAttribute, "selected").Message != "true")
                //{

                //    Reports.TestStep = "Select the process.";
                //    Support.AreEqual("ADEC-ITI-BILL-FULL-SP", FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "2", 5, TableAction.GetText).Message);
                //    FastDriver.FileWorkflow.ProcessActiveTable(4, "2", 5, TableAction.Click);

                //    Reports.TestStep = "Click On Details Button.";
                //    FastDriver.FileWorkflow.Details.FAClick();

                //    Reports.TestStep = "Click On Manual Activation.";
                //    FastDriver.TaskDetails.WaitForScreenToLoad();
                //    FastDriver.TaskDetails.ClickManualActivation();

                //    Reports.TestStep = "Validate for Task is activated.";
                //    FastDriver.FileWorkflow.WaitForScreenToLoad();
                //    Support.AreEqual("true", FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "2", 3, TableAction.GetAttribute, "selected").Message);

                //}

                Reports.TestStep = "Copied Task Comments to File Notes via Workflow.";
                FastDriver.FileWorkflow.OpenTaskCommentDlgForTask("FMUC0010_FileNotes_Template", "FMUC0010_FileNotes1", FileNumber);

                Reports.TestStep = "Copied Task Comments to File Notes via Workflow.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.Comment.FASetText("New note in File workflow",true);
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                //
                Reports.TestStep = "navigate to the File Notes.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                Reports.TestStep = "Validate workflow notes in File notes.";
                this.VerifySubString(FastDriver.FileNotes.Table.FAGetText().ToString(), "New note in File workflow");

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0010_BAT0005()
        {
            try
            {
                Reports.TestDescription = "Dependency Flow: Process for Manual Activation, if Task is not in Activate status";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                //  String Date;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "navigate to the File Notes.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

                Reports.TestStep = "Validate workflow notes in File notes.";
                string x = FastDriver.FileNotes.FileNotesGrid.FAGetText().ToString();
                Support.AreEqual(FastDriver.FileNotes.FileNotesGrid.FAGetText().ToString(), "Notes Data including - * # Specialcharacter :) !");
               
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion  
        #region Test FMUC0010_BAT0007_PH

        [TestMethod]
        public void FMUC0010_BAT0007_PH()
        {
            try
            {
                Reports.TestDescription = "AF4_Placeholder: NON Automated Flow: View TEN Search File Notes.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0010_BAT0008_PH

        [TestMethod]
        public void FMUC0010_BAT0008_PH()
        {
            try
            {
                Reports.TestDescription = "AF5_Placeholder: NON Automated Flow: Preview/Append/ Add New Note –Specific to Client Web interface to FAST.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #endregion BAT
        #region REG

        #region Test FMUC0010_REG0001

        [TestMethod]
        public void FMUC0010_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM855_FM1650_1_FM4526_1: Spell Check Note Text.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var newNote = new NewFileNoteParameters()
                {
                    NoteType = "Title",
                    FontName = "Times New Roman",
                    FontSize = "3",
                    NoteText = "Reg Finl notezz"
                };
                
                #endregion

                #region GUI interaction
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Validate note type.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("All Notes", FastDriver.FileNotes.NotesType.FAGetSelectedItem());

                Reports.TestStep = "Create a file note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad().New.FAClick();

                Reports.TestStep = "Entering without any text.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad().NoteType.FASelectItem("Title");
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.TreeView.FindElement(OpenQA.Selenium.By.LinkText("Home")).FAClick();

                Reports.TestStep = "No text entered in file notes.";
                Support.AreEqual("No text was entered in the Note", FastDriver.WebDriver.HandleDialogMessage(false));
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad().New.FAClick();

                Reports.TestStep = "Add a note SpellCheck.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad().AddNote(newNote).CheckSpelling.FAClick();

                Reports.TestStep = "Ignore the Spelling.";
                FastDriver.SpellingErrorDialog.WaitForScreeToLoad().Ignore.FAClick();

                Reports.TestStep = "Check the Spelling.";
                FastDriver.SpellingErrorDialog.NewSpelling.FASetText("Spelling");
                FastDriver.SpellingErrorDialog.Change.FAClick();

                Reports.TestStep = "Ignore the Spelling.";
                FastDriver.SpellingErrorDialog.Ignore.FAClick();

                Reports.TestStep = "Spell check complete.";
                Support.AreEqual("Spelling check complete", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Click on Done in dialog box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("SMSSpellChecker");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("SMSSpellChecker", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the new spelling modified is present.";
                Playback.Wait(5000);

                CheckValueInTable(1, 2, "Reg Spelling notezz");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0010_REG0002

        [TestMethod]
        public void FMUC0010_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM1651_FM1650_2: Capture Create User info and Mandatory Information.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Add a Note.";
                this.AddNoteFromNavigation("Title", "Times New Roman", "3", "Title", "create a new note");

                Reports.TestStep = "navigate to the File Notes.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Validate creation user info.";
                Support.AreEqual("FAST QA07", FastDriver.FileNotes.Table.PerformTableAction(1, "create a new note", 2, TableAction.GetText).Message);
                string dTodayDate = DateTime.Today.ToUniversalTime().AddHours(8).ToString("MM/dd/yyyy");
                string xx = DateTime.Today.ToUniversalTime().Date.ToString();

                Reports.TestStep = "Validate creation date info.";
                this.VerifySubString(FastDriver.FileNotes.Table.PerformTableAction(1, "create a new note", 3, TableAction.GetText).Message, dTodayDate);

              #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0010_REG0003

        [TestMethod]
        public void FMUC0010_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM7626: View File Notes in FAST View.";

                #region data setup
                var credentials = new Credentials() 
                {
                    UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword
                };

                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Enter a new note in Fast View";
                };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();                
                #endregion

                #region GUI interaction
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Fast View.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Enter file Number to Search From Fast View.";
                FastDriver.WebDriver.SwitchToWindow("FAST View");     
                FastDriver.FASTView.WaitForScreenToLoad(FastDriver.FASTView.FindNow);
                FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber);
               
                Reports.TestStep = "Click on Find Now.";
                FastDriver.FastViewFileSearch.FindNow.FAClick();
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                Playback.Wait(10000);//

                Reports.TestStep = "Select Notes.";

                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch 
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotes.FAGetText().ToString().ToString(), "Notes Data including - * # Specialcharacter :) !");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0004

        [TestMethod]
        public void FMUC0010_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM7627: Add New File Note in FAST View.";
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Enter a new note in Fast View";
                };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region GUI interaction
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Fast View.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Enter file Number to Search From Fast View.";
                FastDriver.WebDriver.SwitchToWindow("FAST View");
                FastDriver.FASTView.WaitForScreenToLoad(FastDriver.FASTView.FindNow);
                FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber);

                Reports.TestStep = "Click on Find Now.";
                FastDriver.FastViewFileSearch.FindNow.FAClick();
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                Playback.Wait(10000);//

                Reports.TestStep = "Select Notes.";

                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotes.FAGetText().ToString().ToString(), "Notes Data including - * # Specialcharacter :) !");
                FastDriver.FastViewFileNotes.New.FAClick();

                Reports.TestStep = "Add a Note in Fast View.";
                FastDriver.FastViewEditor.WaitForScreenToLoad();
                FastDriver.FastViewEditor.AddNote(addNoteDetails);
                FastDriver.FastViewEditor.ClickDone();

                Reports.TestStep = "Select Notes.";
                string s = FastDriver.WebDriver.Url.ToString();
                FastDriver.WebDriver.SwitchToWindow("FAST View");
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note in File Notes screen.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotesGrid1.FAGetText().ToString(), "Enter a new note in Fast View");

                Reports.TestStep = "Validate new note and Click on append button.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotes.FAGetText().ToString().ToString(), "Notes Data including - * # Specialcharacter :) !");
                FastDriver.FastViewFileNotes.FileNotesGrid1.FAClick();
                
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0010_REG0005
        [TestMethod]
        public void FMUC0010_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM7628_HK4: Append File Notes in FAST View.";
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Enter a new note in Fast View";
                };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region GUI interaction
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Fast View.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Enter file Number to Search From Fast View.";
                FastDriver.WebDriver.SwitchToWindow("FAST View");
                FastDriver.FASTView.WaitForScreenToLoad(FastDriver.FASTView.FindNow);
                FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber);

                Reports.TestStep = "Click on Find Now.";
                FastDriver.FastViewFileSearch.FindNow.FAClick();
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                Playback.Wait(10000);//

                Reports.TestStep = "Select Notes.";
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotes.FAGetText().ToString().ToString(), "Notes Data including - * # Specialcharacter :) !");
                FastDriver.FastViewFileNotes.New.FAClick();

                Reports.TestStep = "Add a Note in Fast View.";
                FastDriver.FastViewEditor.WaitForScreenToLoad();
                FastDriver.FastViewEditor.AddNote(addNoteDetails);
                                FastDriver.FastViewEditor.ClickDone();

                Reports.TestStep = "Select Notes.";
                string s = FastDriver.WebDriver.Url.ToString();
                FastDriver.WebDriver.SwitchToWindow("FAST View");
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note in File Notes screen.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotesGrid1.FAGetText().ToString(), "Enter a new note in Fast View");

                Reports.TestStep = "Validate new note and Click on append button.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotes.FAGetText().ToString().ToString(), "Notes Data including - * # Specialcharacter :) !");
                FastDriver.FastViewFileNotes.FileNotesGrid1.FAClick();
                FastDriver.FastViewFileNotes.Append.FAClick();

                //Reports.TestStep = "Append a Note in Fast View.";               
                //FastDriver.FastViewFileNotes.FileNotesGrid1.FAClick();
                //FastDriver.FastViewFileNotes.Append.FAClick();
                Reports.TestStep = "Append a Note in Fast View.";
                addNoteDetails.NoteText = "Append a Note in Fast View.";
                FastDriver.FastViewEditor.WaitForScreenToLoad();
                FastDriver.FastViewEditor.AddNote(addNoteDetails);
                                FastDriver.FastViewEditor.ClickDone();

                Reports.TestStep = "Select Notes.";
                FastDriver.WebDriver.SwitchToWindow("FAST View");
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate append a note.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                this.VerifySubString(FastDriver.FastViewFileNotes.FileNotesGrid1.FAGetText().ToString(), "Append a Note in Fast View.");

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test

        #region Test FMUC0010_REG0006
        [TestMethod]
        public void FMUC0010_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM7629_HK2: Preview File Notes in FAST View.";
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Enter a new note in Fast View";
                };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region GUI interaction
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Fast View.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Enter file Number to Search From Fast View.";
                FastDriver.WebDriver.SwitchToWindow("FAST View");
                FastDriver.FASTView.WaitForScreenToLoad(FastDriver.FASTView.FindNow);
                FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber);

                Reports.TestStep = "Click on Find Now.";
                FastDriver.FastViewFileSearch.FindNow.FAClick();
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                Playback.Wait(10000);//

                Reports.TestStep = "Select Notes.";

                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotes.FAGetText().ToString().ToString(), "Notes Data including - * # Specialcharacter :) !");
                FastDriver.FastViewFileNotes.New.FAClick();

                Reports.TestStep = "Add a Note in Fast View.";
                FastDriver.FastViewEditor.WaitForScreenToLoad();
                FastDriver.FastViewEditor.AddNote(addNoteDetails);
                                FastDriver.FastViewEditor.ClickDone();

                Reports.TestStep = "Select Notes.";
                string s = FastDriver.WebDriver.Url.ToString();
                FastDriver.WebDriver.SwitchToWindow("FAST View");
                Reports.TestStep = "Select Notes.";

                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note in File Notes screen.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotesGrid1.FAGetText().ToString(), "Enter a new note in Fast View");

                Reports.TestStep = "Validate new note and Click on append button.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotes.FAGetText().ToString().ToString(), "Notes Data including - * # Specialcharacter :) !");
                FastDriver.FastViewFileNotes.FileNotesGrid1.FAClick();
                FastDriver.FastViewFileNotes.Append.FAClick();

                //Reports.TestStep = "Append a Note in Fast View.";               
                //FastDriver.FastViewFileNotes.FileNotesGrid1.FAClick();
                //FastDriver.FastViewFileNotes.Append.FAClick();
                Reports.TestStep = "Append a Note in Fast View.";
                addNoteDetails.NoteText = "Append a Note in Fast View.";
                FastDriver.FastViewEditor.WaitForScreenToLoad();
                FastDriver.FastViewEditor.AddNote(addNoteDetails);
                                FastDriver.FastViewEditor.ClickDone();

                Reports.TestStep = "Select Notes.";
                FastDriver.WebDriver.SwitchToWindow("FAST View");
                Reports.TestStep = "Select Notes.";

                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate append a note.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                this.VerifySubString(FastDriver.FastViewFileNotes.FileNotesGrid1.FAGetText().ToString(), "Append a Note in Fast View.");

                Reports.TestStep = "Select All Notes as Notes Type and Click on Preview button";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                FastDriver.FastViewFileNotes.NotesType.FASelectItem("All Notes");
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                FastDriver.FastViewFileNotes.Preview.FAClick();

                Reports.TestStep = "Verify preview notes";
                FastDriver.FastViewFileNotes.SwitchToFastViewContentFrame();
                this.VerifySubString(FastDriver.FastViewFileNotes.PreviewDetails.FAGetText().ToString(), "Append a Note in Fast View.");
                Support.AreEqual(FastDriver.FastViewFileNotes.ByPreview.FAGetText().ToString(), "Super User");
                Support.AreEqual(FastDriver.FastViewFileNotes.TitlePreview.FAGetText().ToString(), "EPIC");

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test

        #region Test FMUC0010_REG0007_PH
        [TestMethod]
        public void FMUC0010_REG0007_PH()
        {
            try
            {
                Reports.TestDescription = "FM7629_Validation_PlaceHolder: Validate that All details appear including timestamp in Preview window";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                 Support.Fail(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0010_REG0008

        [TestMethod]
        public void FMUC0010_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM9864_FM9865_FM9872: Displays Process/Task Name/Displays separate sections for the Published and Non-Published Task Comments/Default view.";

                #region data setup
                var credentials = new Credentials() 
                {
                    UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword
                };
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Enter a new note in Fast View";
                };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();                
                #endregion

                #region GUI interaction
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                CreateFile();

                Reports.TestStep = "Navigate to file workflow.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();

                Reports.TestStep = "Uncheck active only button.";
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
               // Playback.Wait(5000);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                //Playback.Wait(5000);

                Reports.TestStep = "Click on Task Comment button.";
                FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "1", 12, TableAction.Click);
                Playback.Wait(5000);

                Reports.TestStep = "Add task comment and Click on Done.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("New note in File workflow - Non-Published Comment");
                FastDriver.TaskCommentEditDlg.Comment.FASetText("New note in File workflow - Published Comment");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
     
               
                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0010_REG0009
        [TestMethod]
        public void FMUC0010_REG0009()
        {
            try
            {
                Reports.TestDescription = "FM9869_FM9870: Prevent adding New/Appending to the copied Task Comments to the File Notes.";
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Enter a new note in Fast View";
                };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region GUI interaction
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                CreateFile();

                Reports.TestStep = "Navigate to file workflow.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();

                Reports.TestStep = "Uncheck active only button.";
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Click on Task Comment button.";
                FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "1", 12, TableAction.Click);
                Playback.Wait(5000);

                Reports.TestStep = "Add task comment and Click on Done.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("New note in File workflow - Non-Published Comment");
                FastDriver.TaskCommentEditDlg.Comment.FASetText("New note in File workflow - Published Comment");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Task Comments", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Apply();

                Reports.TestStep = "navigate to the File Notes.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

                Reports.TestStep = "Validate the new task comments are present.";
                this.VerifySubString(FastDriver.FileNotes.TaskNotes.FAGetText().ToString(), "New note in File workflow - Non-Published Comment");
                this.VerifySubString(FastDriver.FileNotes.TaskNotes.FAGetText().ToString(), "New note in File workflow - Published Comment");
                // 

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0010_REG0010
        [TestMethod]
        public void FMUC0010_REG0010()
        {
            try
            {
                Reports.TestDescription = "FM1665_FM1654: Valid Note Types and Mandatory Association One File.";
                  #region data setup
                var credentials = new Credentials() 
                {
                    UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword
                };
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Enter a new note in Fast View";
                };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();                
                #endregion

                #region GUI interaction
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                CreateFile();

                Reports.TestStep = "Navigate to file workflow.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();

                Reports.TestStep = "Uncheck active only button.";
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Click on Task Comment button.";
                FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "1", 12, TableAction.Click);
                Playback.Wait(5000);

                Reports.TestStep = "Add task comment and Click on Done.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("New note in File workflow - Non-Published Comment");
                FastDriver.TaskCommentEditDlg.Comment.FASetText("New note in File workflow - Published Comment");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Click On Apply Button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Task Comments", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Apply();

                Reports.TestStep = "navigate to the File Notes.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

                Reports.TestStep = "Validate the new task comments are present.";
                this.VerifySubString(FastDriver.FileNotes.TaskNotes.FAGetText().ToString(), "New note in File workflow - Non-Published Comment");
                this.VerifySubString(FastDriver.FileNotes.TaskNotes.FAGetText().ToString(), "New note in File workflow - Published Comment");
                // 
                Reports.TestStep = "Navigate to file workflow.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();

                Reports.TestStep = "Uncheck active only button.";
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Click on Task Comment button.";
                FastDriver.FileWorkflow.ProcessTable.PerformTableAction(4, "1", 12, TableAction.Click);


                Reports.TestStep = "Edit task and Clicking Done.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                FastDriver.TaskCommentEditDlg.InternalComment.FASetText("Edited note in File workflow - Non-Published Comment");
                FastDriver.TaskCommentEditDlg.Comment.FASetText("Edited note in File workflow - Published Comment");
                FastDriver.TaskCommentEditDlg.Done.FAClick();

                Reports.TestStep = "Validate the presence of Published task";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Task Comments", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Apply();

                Reports.TestStep = "navigate to the File Notes.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

                Reports.TestStep = "Validate the new task comments are present.";
                this.VerifySubString(FastDriver.FileNotes.TaskNotes.FAGetText().ToString(), "Edited note in File workflow - Non-Published Comment");
                this.VerifySubString(FastDriver.FileNotes.TaskNotes.FAGetText().ToString(), "Edited note in File workflow - Published Comment");

                Reports.TestStep = "navigate to the File Notes.";
                FastDriver.FileNotes.NotesType.FASelectItem("Task Comments");
                Playback.Wait(10000);
                Support.AreEqual("false", FastDriver.FileNotes.New.Enabled.ToString().ToLower().Trim());
                Support.AreEqual("false", FastDriver.FileNotes.Append.Enabled.ToString().ToLower().Trim());
                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0010_REG0011
        [TestMethod]
        public void FMUC0010_REG0011()
        {
            try
            {
                Reports.TestDescription = "FM9868: Display copied Task Comments from File Workflow or My FAST Today to the File Notes.";
                #region GUI interaction
                Reports.TestStep = "Log into FAST ADM.";
                ADMLOGIN();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                ProcessParameters ProcParams = new ProcessParameters();
                ProcParams.ProcessName = "FMUC0010_FileNotes_Template";
                ProcParams.ProcessType = "Title Production";
                ProcParams.TranType = @"REO Sale/Cash";
                ProcParams.State = "CA";
                ProcParams.County = "Alameda";
                ProcParams.ProcessEvent = "File created with Open status";
                ProcParams.Tasks = new[] { "FMUC0010_FileNotes1", "FMUC0010_FileNotes2" };
                Dictionary<string, string> ProcDetails = FastDriver.RegionalProcessEdit.CreateNewProcess(ProcParams);//,PublicTask:true);
                Reports.TestStep = "Log into FAST application.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                //
                Reports.TestStep = "Create a basic file";
                string FileNumber = CreateQFEWithDetails(TransactionType: @"REO Sale/Cash");

                Reports.TestStep = "Navigate to File workflow.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.AssignTaskTo("FMUC0010_FileNotes_Template","FMUC0010_FileNotes1","QA07, FAST");

                Reports.TestStep = "Navigate to My Fast Today.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today").WaitForScreenToLoad();
                FastDriver.MyFASTToday.WaitForScreenToLoad();
                //FastDriver.MyFASTToday.FilterEmployee.FASelectItem(@"QA07, FAST");
                FastDriver.MyFASTToday.SelectTaskNameFilter("FMUC0010_FileNotes1");
                FastDriver.MyFASTToday.FindNow.FAClick();
                FastDriver.MyFASTToday.WaitForTaskTableToLoad();
                if (FastDriver.MyFASTToday._ActiveTasksTable.FAGetText().Contains("FMUC0010_FileNotes1"))
                    FastDriver.MyFASTToday.OpenTaskCommentDlgForTask("FMUC0010_FileNotes1", FileNumber);
               
                Reports.TestStep = "Add task comment and Click on Done.";
                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                //FastDriver.TaskCommentEditDlg.InternalComment.FASetText("New note in My Fast Today - Non-Published Comment");
                FastDriver.TaskCommentEditDlg.Comment.FASetText("New note in My Fast Today - Published Comment");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
                Thread.Sleep(7000);
                Reports.TestStep = "Navigate to the File Notes.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                Reports.TestStep = "Validate the new task comments are present.";
                //this.VerifySubString(FastDriver.FileNotes.Table.FAGetText().ToString(), "New note in My Fast Today - Non-Published Comment");
                this.VerifySubString(FastDriver.FileNotes.Table.FAGetText().ToString(), "New note in My Fast Today - Published Comment");

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0012
        [TestMethod]
        public void FMUC0010_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM4523_1_FM1653_1: Permit Multiple Notes per Type.";

                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Title - create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
          

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("EPIC");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();           

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note for EPIC.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                addNoteDetails.NoteType = "EPIC";
                addNoteDetails.NoteText = "EPIC - create a new note";
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate a note for Title.";
                FastDriver.FileNotes.WaitForScreenToLoad();                
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FileNotes.FileNotesGrid.FAGetText(), "Title - create a new note");

                Reports.TestStep = "Validate a note for EPIC.";
                FastDriver.FileNotes.NotesType.FASelectItem("EPIC");   
                FastDriver.FileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FileNotes.FileNotesGrid1.FAGetText(), "EPIC - create a new note");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        /// <summary>
        /// 
        /// </summary>
        #region Test FMUC0010_REG0013
        [TestMethod]
        public void FMUC0010_REG0013()
        {
            try
            {
                Reports.TestDescription = "HK1_FM4523_2_HK3: Add a new note using 'CTRL+N'/Permit Multiple Notes per Type.";
                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Title - create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                //  String Date;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Add a new note us 'CTRL+N'.";
                Keyboard.SendKeys("%N");

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Add a new note us 'CTRL+N'.";
                Keyboard.SendKeys("%N");                

                Reports.TestStep = "Add a note for EPIC.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                addNoteDetails.NoteType = "EPIC";
                addNoteDetails.NoteText = "EPIC - create a new note";
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate a note for Title.";
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FileNotes.FileNotesGrid.FAGetText(), "Title - create a new note");

                Reports.TestStep = "Validate a note for EPIC.";
                FastDriver.FileNotes.NotesType.FASelectItem("EPIC");
                FastDriver.FileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FileNotes.FileNotesGrid1.FAGetText(), "EPIC - create a new note");

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0014
        [TestMethod]
        public void FMUC0010_REG0014()
        {
            try
            {
                Reports.TestDescription = "FM1653_2: Permit Multiple File Notes.";
                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Title - create a new note1";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note for EPIC.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                addNoteDetails.NoteType = "Title";
                addNoteDetails.NoteText = "Title - create a new note2";
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate a note for Title.";
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FileNotes.FileNotesGrid.FAGetText(), "Title - create a new note1");
                Support.AreEqual(FastDriver.FileNotes.FileNotesGrid1.FAGetText(), "Title - create a new note2");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0015
        [TestMethod]
        public void FMUC0010_REG0015()
        {
            try
            {
                Reports.TestDescription = "FD: Checking FD for the File Note Editor screen.";

                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "ABCDEFGHIJKLM NOPQRSTUVWXYZAB CDEFGHIJKLMNO PQRSTUVWXYZAB CDEFGHIJKLMNOP QRSTUVWXYZABCDEFG HIJKLMNO PQRSTUVWXYZAB CDEFGHIJKLMNO PQRSTUVWXYZABC DEFGHIJKLMN OPQRSTUVWXY ZABCDEFGHI JKLMNOPQRST UVWXYZABCDE FGHIJKLMNOP QRSTUVWXYZA BCDEFGHIJKLMNOPQ RSTUVWXYZA BCDEFGHIJK LMNOPQRST";
                                               
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Support.AreEqual(FastDriver.FileNotesEditor.Detail.FAGetText(), "");
               
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Support.AreEqual(FastDriver.FileNotesEditor.Detail.FAGetText(), "");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("Title");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();

                addNoteDetails.NoteText = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU";
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);
                Support.AreEqual(FastDriver.FileNotesEditor.Detail.FAGetText(), "");

                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0016
        [TestMethod]
        public void FMUC0010_REG0016()
        {
            try
            {
                Reports.TestDescription = "FD: Checking FD for the File Note Editor screen.";
                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Title - create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";

                NewFileParameters fileParameters = new NewFileParameters();
                fileParameters.BusinessSourceGABcode = "HUDASLNDR1";
                fileParameters.TransactionType = "Sale w/Mortgage";
                fileParameters.PropertyState = "CA";
                fileParameters.PropertyCounty = "Orange";
                fileParameters.Title = true;

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    Reports.TestStep = "Click on skip button to go to QFE.";
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    FastDriver.QuickFileEntry.CreateFile(fileParameters);
                }
                catch
                {
                    Reports.StatusUpdate("File creation failed", false);
                }

                Reports.TestStep = "Select Note Type and don’t enter Note,verify Error.";
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate: Error(s) occurred. See Message pane.";
                Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage(false));
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Verify Error Message For QFE when Note type is selected and data in not entered.";
                Support.AreEqual(@"ServiceFileNote: No text was entered in the Note.", FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText());

                Reports.TestStep = "Select Note Type and don’t enter Notetype,verify Error.";
                FastDriver.QuickFileEntry.NoteType.FASelectItemByIndex(0);
                FastDriver.QuickFileEntry.Notes.FASetText(@"Note Without Note Type." + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                 Reports.TestStep = "Validate: Error(s) occurred. See Message pane.";
                Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage(false));
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Verify Error Message For QFE when is Note is entered and Note type in not selected.";
                Support.AreEqual(@"ServiceFileNoteTypeCdID: ServiceFileNoteTypeCdID is required.", FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText());

                Reports.TestStep = "Select Note Type and don’t enter Note,verify Error.";
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Note For FMUC0010 Review." + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the new note created is present.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.Table.PerformTableAction(1, "Note For FMUC0010 Review.", 2, TableAction.Click);

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0016_1
        [TestMethod]
        public void FMUC0010_REG0016_1()
        {
            try
            {
                Reports.TestDescription = "FM7628 : Append File Notes in FAST View";
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "New Note";
                };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region GUI interaction
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Fast View.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FastView.FAClick();

                Reports.TestStep = "Enter file Number to Search From Fast View.";
                FastDriver.WebDriver.SwitchToWindow("FAST View");
                FastDriver.FASTView.WaitForScreenToLoad(FastDriver.FASTView.FindNow);
                FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber);

                Reports.TestStep = "Click on Find Now.";
                FastDriver.FastViewFileSearch.FindNow.FAClick();
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                Playback.Wait(10000);//

                Reports.TestStep = "Select Notes.";
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotes.FAGetText().ToString().ToString(), "Notes Data including - * # Specialcharacter :) !");
                FastDriver.FastViewFileNotes.New.FAClick();

                Reports.TestStep = "Add a Note in Fast View.";
                FastDriver.FastViewEditor.WaitForScreenToLoad();
                FastDriver.FastViewEditor.AddNote(addNoteDetails);
                                FastDriver.FastViewEditor.ClickDone();

                Reports.TestStep = "Select Notes.";

                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FastViewFileNotes.FileNotesGrid1.FAGetText().ToString().ToString(), "New Note");
                FastDriver.FastViewFileNotes.FileNotesGrid1.FAClick();
                FastDriver.FastViewFileNotes.Append.FAClick();

                Reports.TestStep = "Add a Note in Fast View.";
                FastDriver.FastViewEditor.WaitForScreenToLoad();
                addNoteDetails.NoteText = "Append a Note";
                FastDriver.FastViewEditor.AddNote(addNoteDetails);
                                FastDriver.FastViewEditor.ClickDone();

                Reports.TestStep = "Select Notes.";
                for (int i = 0; i < 5; i++)
                {
                    FastDriver.FastViewFileSearch.WaitForScreenToLoad();
                    FastDriver.FastViewFileSearch.Numbers.GiveFocus();
                    Keyboard.SendKeys("^+N");
                    try
                    {
                        System.Threading.Thread.Sleep(2000);
                        FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                    }
                    catch
                    {
                        continue;
                    }
                    break;
                }

                Reports.TestStep = "Validate new note.";
                FastDriver.FastViewFileNotes.WaitForScreenToLoad();
                this.VerifySubString(FastDriver.FastViewFileNotes.FileNotesGrid1.FAGetText().ToString().ToString(), "Append a Note");
               
                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0017
        [TestMethod]
        public void FMUC0010_REG0017()
        {
            try
            {
                Reports.TestDescription = "HK5: Cancelling a note.";

                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Title - create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to File Notes and Add a Note.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("EPIC");
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Add a note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Cancel.";
                Keyboard.SendKeys("^Q");
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0018_PH

        [TestMethod]
        public void FMUC0010_REG0018_PH()
        {

            try
            {
                Reports.TestDescription = "FM1655_FM4524_FM1791_FM4525_FM7886_PlaceHolder: Display Sequence of Notes.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0010_REG0019_PH

        [TestMethod]
        public void FMUC0010_REG0019_PH()
        {

            try
            {
                Reports.TestDescription = "FM8813_FM8814_FM8984_FM4524_FM9867_PlaceHolder: Online HUD-1 Revision change request displayed in File Notes.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0010_REG0020_PH

        [TestMethod]
        public void FMUC0010_REG0020_PH()
        {

            try
            {
                Reports.TestDescription = "FM1652_FM1656_PlaceHolder: Capture Append User info.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0010_REG0021
        [TestMethod]
        public void FMUC0010_REG0021()
        {
            try
            {

                Reports.TestDescription = "FD: Checking FD for the File Note Editor screen.";
                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Title - create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                //  String Date;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to Active Disbursement Summary screeen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();                
                FastDriver.ActiveDisbursementSummary.Note.FAClick();

                Reports.TestStep = "Enter a note from Active Disbursement screen.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"Note From Active Disbursement screen");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Trial Balance Note", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FAClick();

                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Note From File Balance Summary");
                //FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FASetText("Note From File Balance Summary");

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
               // FastDriver.WebDriver.WaitForWindowAndSwitch("Trial Balance Note", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();                

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0022
        [TestMethod]
        public void FMUC0010_REG0022()
        {
            try
            {
                Reports.TestDescription = "Validate the note in file notes screen";
                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Title - create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                //  String Date;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to Active Disbursement Summary screeen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Note.FAClick();

                Reports.TestStep = "Enter a note from Active Disbursement screen.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"Note From Active Disbursement screen");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Trial Balance Note", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FAClick();

                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Note From File Balance Summary");
                //FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FASetText("Note From File Balance Summary");

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                // FastDriver.WebDriver.WaitForWindowAndSwitch("Trial Balance Note", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestDescription = "Navigate to File notes and Validate the note in file notes screen for notes from Active Disbursement screen and File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("All File Notes w/o Task Comments");
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Validate That Note appears from Active Disbursement Screen.";
                string sFileNote = FastDriver.FileNotes.FileNotesGrid1.FAGetText();
                this.VerifySubString(sFileNote, "Note From Active Disbursement screen");

                Reports.TestStep = "Validate That Note appears from File Balance Summary.";
                this.VerifySubString(sFileNote, "Note From File Balance Summary");


                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0010_REG0023
        [TestMethod]
        public void FMUC0010_REG0023()
        {
            try
            {
                Reports.TestDescription = "EXPECTED FAILURE:Validate that date and timestamp appears in file notes";
                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "Title - create a new note";
                }
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                //  String Date;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to Active Disbursement Summary screeen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Note.FAClick();

                Reports.TestStep = "Enter a note from Active Disbursement screen.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"Note From Active Disbursement screen");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FAClick();

                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Note From File Balance Summary");

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestDescription = "Navigate to File notes and Validate the note in file notes screen for notes from Active Disbursement screen and File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem("All File Notes w/o Task Comments");
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Validate That Note appears from Active Disbursement Screen.";
                string sFileNote = FastDriver.FileNotes.FileNotesGrid1.FAGetText();
                this.VerifySubString(sFileNote, "Note From Active Disbursement screen");

                Reports.TestStep = "Validate That Note appears from File Balance Summary.";
                this.VerifySubString(sFileNote, "Note From File Balance Summary");

                Reports.TestStep = "Validate the date/timestamp in the notes";
                string dTodayDate = DateTime.Today.ToUniversalTime().AddHours(8).ToDateString();
                this.VerifySubString(sFileNote, dTodayDate);

                #endregion GUI interaction
              
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0010_REG0024
        [TestMethod]
        public void FMUC0010_REG0024()
        {
            try
            {               
                Reports.TestDescription = "Validate the field defination and error warning condition";
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to Active Disbursement Summary screeen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Note.FAClick();

                Reports.TestStep = "Enter a note from Active Disbursement screen using Trial Balance Note Dialog.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"test comment length should not exceed 61&^*(^*)&(;\/ testing _,/\");
                FastDriver.DialogBottomFrame.ClickDone();

                //Support.AreEqual(@"Error: Internal Comment length of 65 exceeds maximum of 61. Reduce the size of the internal comment to 61 or less to save.", FastDriver.WebDriver.HandleDialogMessage(false).Trim());
                this.VerifySubString(FastDriver.WebDriver.HandleDialogMessage(false).Trim(), @"Error: Internal Comment length of 65 exceeds maximum of 61.");
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"test comment length 61&^*(^*)&(;\/ testing _,/\");
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Please enter a valid Trial Balance Note.", FastDriver.WebDriver.HandleDialogMessage(false));
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"Note From Active Disbursement screen");
                FastDriver.DialogBottomFrame.ClickDone();
               
                Reports.TestStep = "Click on Done.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Trial Balance Note", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FAClick();

                Reports.TestStep = "Enter a note from File balance summary screen using Trial Balance Note Dialog.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"test comment length should not exceed 61&^*(^*)&(;\/ testing _,/\");
                FastDriver.DialogBottomFrame.ClickDone();

                //Support.AreEqual(@"Error: Internal Comment length of 65 exceeds maximum of 61. Reduce the size of the internal comment to 61 or less to save.", FastDriver.WebDriver.HandleDialogMessage(false));
                this.VerifySubString(FastDriver.WebDriver.HandleDialogMessage(false).Trim(), @"Error: Internal Comment length of 65 exceeds maximum of 61.");
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"test comment length 61&^*(^*)&(;\/ testing _,/\");
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Please enter a valid Trial Balance Note.", FastDriver.WebDriver.HandleDialogMessage(false));
                FastDriver.WebDriver.HandleDialogMessage(false, false);

               
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Note From File Balance Summary");
                //FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FASetText("Note From File Balance Summary");

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                // FastDriver.WebDriver.WaitForWindowAndSwitch("Trial Balance Note", false, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        //Team                  :  ServReq-Team1
        //Iteration             :  r08
        //UserStory             :  User Story 815236
        //TestCase              :  830103,830795,838861
        //Appended By/ Created By: Osama
        #region Test US815236
        [TestMethod]
        public void FMUC0010_REG0025()
        {
            try
            {
                Reports.TestDescription = "US815236 : To verify the Sorting order of Task Comments added from Workflow screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                #region Check the sorting order checkbox
                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Process and Task from ADM
                Reports.TestDescription = "Create Process and Task ADM";
                var process = CreateNewProcessTemplate("FMUC0010_US815236");
                #endregion

                #region IIS interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Add Task Comments to workflow tasks";
                Add_Task_Comment();

                //Non Public
                #region Append Non Public task comment and Verify
                Reports.TestStep = "Append Non Public Task Comments";
                Append_Task_Comment_NonPublic();

                Reports.TestStep = "Navigate to File Notes screen";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

                #region Verify in Task Comments
                FastDriver.FileNotes.NotesType.FASelectItem("Task Comments");
                //FastDriver.FileNotes.WaitForScreenToLoad();

                // string TaskComment1 = process.Name + "/" + process.Tasks[1].Name;
                //Support.AreEqual(TaskComment1, FastDriver.FileNotes.TaskComment.Text.ToString());

                FastDriver.FileNotes.Image.FAClick();

                string NonPublicAppended = FastDriver.FileNotes.TaskComment1.FindElements(By.TagName("div"))[2].Text.ToString();
                Support.AreEqual("Test Comment 1 Appended 1", NonPublicAppended);
                #endregion

                #region Verify in AllNotes
                FastDriver.FileNotes.NotesType.FASelectItem("All Notes");
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Verify notes for Non Public Task";
                string NonPublicAppendedAllNotes = FastDriver.FileNotes.FileNotesGrid.FindElements(By.TagName("div"))[2].Text.ToString();
                Support.AreEqual("Test Comment 1 Appended 1", NonPublicAppendedAllNotes);
                #endregion
                #endregion

                #region Append Public Task and verify
                Reports.TestStep = "Append Public Task Comments";
                Append_Task_Comment_Public();

                Reports.TestStep = "Navigate to File Notes screen";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

                #region Verify in Task Comment
                FastDriver.FileNotes.NotesType.FASelectItem("Task Comments");
                //FastDriver.FileNotes.WaitForScreenToLoad();

                //string TaskComment2 = process.Name + "/" + process.Tasks[0].Name;
                //Support.AreEqual(TaskComment2, FastDriver.FileNotes.TaskComment.Text.ToString());

                FastDriver.FileNotes.Image.FAClick();

                string pubCommentTC = FastDriver.FileNotes.TaskComment1.FindElements(By.TagName("div"))[2].Text.ToString();
                Support.AreEqual("Test Comment 1 Published Appended", pubCommentTC);

                string npubCommentTC = FastDriver.FileNotes.FileNotesGrid.FindElements(By.TagName("div"))[4].Text.ToString();
                Support.AreEqual("Test Comment 1 Non-Published Appended", npubCommentTC);

                string commentCodeTC = FastDriver.FileNotes.FileNotesGrid.FindElements(By.TagName("div"))[5].FindElements(By.TagName("div"))[1].FindElement(By.TagName("table")).FindElement(By.TagName("tbody")).FindElement(By.TagName("tr")).FindElements(By.TagName("td"))[1].Text.ToString();
                var compareCC = commentCodeTC.Contains("Comment Code Appended").ToString();
                Support.AreEqual("True", compareCC);
                #endregion

                #region Verify in All Notes

                FastDriver.FileNotes.NotesType.FASelectItem("All Notes");
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Verify notes for Public Task";
                string pubComment = FastDriver.FileNotes.FileNotesGrid.FindElements(By.TagName("div"))[2].Text.ToString();
                Support.AreEqual("Test Comment 1 Published Appended", pubComment);

                string npubComment = FastDriver.FileNotes.FileNotesGrid.FindElements(By.TagName("div"))[4].Text.ToString();
                Support.AreEqual("Test Comment 1 Non-Published Appended", npubComment);

                string commentCode = FastDriver.FileNotes.FileNotesGrid.FindElements(By.TagName("div"))[5].FindElements(By.TagName("div"))[1].FindElement(By.TagName("table")).FindElement(By.TagName("tbody")).FindElement(By.TagName("tr")).FindElements(By.TagName("td"))[1].Text.ToString();
                var compareCC2 = commentCode.Contains("Comment Code Appended").ToString();
                Support.AreEqual("True", compareCC2);

                #endregion
                #endregion
                #endregion GUI interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region UnCheck the sorting order checkbox
                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(false);
                }
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        //Team                  :  ServReq-Team1
        //Iteration             :  r09
        //UserStory             :  User Story 815238
        //TestCase              : 856660, 856921
        //Created By: Osama
        #region Test US815238
        [TestMethod]
        public void FMUC0010_REG0026()
        {
            try
            {
                Reports.TestDescription = "US815238 : To verify the Sorting order of Notes in File Notes and Preview";

                #region data setup
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = "Times New Roman";
                    addNoteDetails.FontSize = "3";
                    addNoteDetails.NoteType = "Title";
                    addNoteDetails.NoteText = "create a new note";
                }

                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                #region Check the sorting order checkbox
                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true); ;
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                #region Add Notes and verify sorting order to the File
                #region EPIC Note
                Reports.TestStep = "Add EPIC note and verify order.";         //EPIC
                addNoteDetails.NoteText = "Test EPIC Note";
                addNoteDetails.NoteType = "EPIC";
                string note = addNoteDetails.NoteText;
                string type = addNoteDetails.NoteType;

                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                VerifySortingOrder(note, type);
                note = "";
                type = "";
                #endregion

                #region Title Note
                Reports.TestStep = "Add Title note and verify order."; //Title
                addNoteDetails.NoteText = "Test Title Note";
                addNoteDetails.NoteType = "Title";
                note = addNoteDetails.NoteText;
                type = addNoteDetails.NoteType;

                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                VerifySortingOrder(note, type);

                note = "";
                type = "";
                #endregion

                #region UCC Note
                Reports.TestStep = "Add UCC note and verify order.";  //UCC
                addNoteDetails.NoteText = "Test UCC Note";
                addNoteDetails.NoteType = "UCC";
                note = addNoteDetails.NoteText;
                type = addNoteDetails.NoteType;

                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.New.FAClick();

                FastDriver.FileNotesEditor.AddNote(addNoteDetails);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                VerifySortingOrder(note, type);
                note = "";
                type = "";
                #endregion
                #endregion

                #region Append Note and verify order
                Reports.TestStep = "Append EPIC note and verify order.";//EPIC
                note = "Test EPIC Note Appended.";
                type = "EPIC";

                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem(type);
                FastDriver.FileNotes.Table.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.FileNotes.Append.FAClick();
                FastDriver.FileNotesEditor.AddNote(note);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                VerifySortingOrder(note, type);
                note = "";
                type = "";

                #endregion

                #region Add Worflow task Comments
                Reports.TestStep = "Navigate to File Workflow screen";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.ExpandButton.FAClick();

                FastDriver.FileWorkflow.Process.PerformTableAction(1, 12, TableAction.Click).ToString();
                FastDriver.TaskCommentEditDlg.SwitchToDialogContentFrame();
                if ("No" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
                {
                    FastDriver.TaskCommentEditDlg.Comment.FASetText("Test Comment 1");
                    FastDriver.TaskCommentEditDlg.Done.FAClick();
                    note = "Test Comment 1";
                }
                else if ("Yes" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
                {
                    FastDriver.TaskCommentEditDlg.PublishedComment.FASetText("Test Comment 1 Published");
                    FastDriver.TaskCommentEditDlg.NonPublishedComment.FASetText("Test Comment 1 Non-Published");
                    FastDriver.TaskCommentEditDlg.Done.FAClick();
                    note = "Test Comment 1 Published";
                }
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                type = "Task Comments";

                FastDriver.BottomFrame.Apply();
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                #endregion

                #region verify Order
                VerifySortingOrder(note, type);
                note = "";
                type = "";
                #endregion

                #region Add Trial Balance Note
                Reports.TestStep = "Navigate to Active Disbursement screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                Reports.TestStep = "Verify the Note button is enabled.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Note.Enabled.ToString(), "Validates Button Note is Enabled");
                Playback.Wait(4000);
                FastDriver.ActiveDisbursementSummary.Note.FAClick();
                Playback.Wait(4000);
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter data in Textbox.";
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Trial Balance Note");
                note = "Trial Balance Note";
                type = "Trial Balance";
                FastDriver.TrialBalanceNoteDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                //Playback.Wait(4000);

                #endregion

                #region Verify Order
                VerifySortingOrder(note, type);
                note = "";
                type = "";
                #endregion

                #region Append the Worflow task Comments
                Reports.TestStep = "Navigate to File Workflow screen";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.ExpandButton.FAClick();

                FastDriver.FileWorkflow.Process.PerformTableAction(1, 12, TableAction.Click).ToString();
                FastDriver.TaskCommentEditDlg.SwitchToDialogContentFrame();
                if ("No" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
                {
                    FastDriver.TaskCommentEditDlg.Comment.FASetText("Test Comment 1 Appended");
                    FastDriver.TaskCommentEditDlg.Done.FAClick();
                    note = "Test Comment 1 Appended";
                }
                else if ("Yes" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
                {
                    FastDriver.TaskCommentEditDlg.PublishedComment.FASetText("Test Comment 1 Published Appended");
                    FastDriver.TaskCommentEditDlg.NonPublishedComment.FASetText("Test Comment 1 Non-Published Appended");
                    //FastDriver.TaskCommentEditDlg.TaskComment1.FAClick();
                    FastDriver.TaskCommentEditDlg.Done.FAClick();
                    note = "Test Comment 1 Published Appended";
                }
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                type = "Task Comments";
                FastDriver.BottomFrame.Apply();
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();

                #endregion

                #region Verify Order
                VerifySortingOrder(note, type);
                note = "";
                type = "";
                #endregion

                #region Append Trial Balance Note
                Reports.TestStep = "Navigate to Active Disbursement screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                Reports.TestStep = "Verify the Note button is enabled.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Note.Enabled.ToString(), "Validates Button Note is Enabled");
                Playback.Wait(4000);
                FastDriver.ActiveDisbursementSummary.Note.FAClick();
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter data in Textbox.";
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Trail Balance Note Appended" + FAKeys.Tab);
                note = "Trail Balance Note Appended";
                type = "Trial Balance";
                FastDriver.TrialBalanceNoteDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                //Playback.Wait(4000);

                #endregion

                #region Verify Order
                VerifySortingOrder(note, type);
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #region UnCheck the sorting order checkbox
                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(false);
                }
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion


        #endregion REG
        #region HelpMethods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TransactionType"></param>
        /// <param name="BusinessSegment"></param>
        /// <param name="BusSourceGabCode"></param>
        /// <param name="DirectebyIDCode"></param>
        /// <param name="NewLoanIDCode"></param>
        /// <param name="AssBusPartyIDCode"></param>
        private static string CreateFile(string TransactionType = "SALE", string BusinessSegment = "RESIDENTAL", string BusSourceGabCode = "HUDFLINSR1", string DirectebyIDCode = "HUDLEASE03",
            string NewLoanIDCode = "247", string AssBusPartyIDCode = "HUDASLNDR1")
        {
            CreateFileRequest fileRequest = new CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            fileRequest.File.BusinessParties = new FileBusinessParty[]
            {
                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(BusSourceGabCode),   // HUDFLINSR1
                    RoleTypeObjectCD = "BUSSOURCE",
                    CustomerReferenceNumber = "1234567890",
                    AdditionalRole = new AdditionalRoleList() { eAddtionalRole = AdditionalRoleType.NewLender }
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(DirectebyIDCode),   // HUDLEASE03
                    RoleTypeObjectCD = "DirectedBy"
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(AssBusPartyIDCode), // HUDASLNDR1
                    RoleTypeObjectCD = "ASSOTDPTY"
                }
            };

            fileRequest.File.BusinessSegmentObjectCD = BusinessSegment; // RESIDENTIAL
            fileRequest.File.TransactionTypeObjectCD = TransactionType; // REFI           
            fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId(NewLoanIDCode);  // 247

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            return File.FileNumber;
        }
        //
        private string CreateQFEWithDetails(int SalesPrice = 0, bool title = true, bool escrow = true, bool subescrow = false,string TransactionType="Sale w/Mortgage")
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            NewFileParameters QFEParams = new NewFileParameters();
            QFEParams = NewFileParameters.GetDefaultParams();
            QFEParams.Title = title;
            QFEParams.Escrow = escrow;
            QFEParams.SubEscrow = subescrow;
            QFEParams.TransactionType = TransactionType;
            if (SalesPrice != 0)
                QFEParams.TermsDatesSalesPrice = SalesPrice.ToString();
            QFEParams.PropertyInformationName = "J305";
            QFEParams.PropertyInformationType = "Single Family Residence";
            QFEParams.PropertyInformationLot = "Lot1";
            QFEParams.PropertyInformationBlock = "Block1";
            QFEParams.PropertyInformationUnit = "Unit1";
            QFEParams.PropertyPropTaxAPN1 = "Prop1APN1";
            QFEParams.PropertyPropTaxAPN2 = "9845012345";
            QFEParams.PropertyBookAddrLin1 = "J305";
            QFEParams.PropertyBookAddrLin2 = "JJEJAMQ";
            QFEParams.PropertyBookAddrLin3 = "JJEJAMQ";
            QFEParams.PropertyCity = "ALBANY";
            QFEParams.PropertyState = "CA";
            QFEParams.PropertyZipCode = "12345";
            QFEParams.PropertyCounty = "ALAMEDA";
            //QFEParams.NoteType = "EPIC";
            //QFEParams.Notes = "Internal Comment";
            FastDriver.QuickFileEntry.CreateFile(QFEParams);
            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }
            Thread.Sleep(5000);
            FastDriver.FileHomepage.WaitForScreenToLoad();
            FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.FileNum, true);
            return FastDriver.FileHomepage.FileNum.FAGetValue();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TransactionType"></param>
        /// <param name="BusinessSegment"></param>
        /// <param name="BusSourceGabCode"></param>
        /// <param name="DirectebyIDCode"></param>
        /// <param name="NewLoanIDCode"></param>
        /// <param name="AssBusPartyIDCode"></param>
        //private static void CreateFileForWF()
        //{
           
        //    NewFileParameters fileParameters = new NewFileParameters();
        //    fileParameters.BusinessSourceGABcode = "WF";
        //    fileParameters.TransactionType = "Sale/Cash";
        //    fileParameters.PropertyState = "CA";
        //    fileParameters.PropertyCounty = "Orange";
        //    fileParameters.ServiceProgramType = "Title";
        //    fileParameters.Title = true;
        //    fileParameters.Title = true;
        //    fileParameters.NoteType = "EPIC";
        //    fileParameters.Notes = "File Notes";
        //    FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
        //    try
        //    {
        //        Reports.TestStep = "Click on skip button to go to QFE.";
        //        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

        //        FastDriver.QuickFileEntry.CreateFile(fileParameters);

        //    }
        //    catch
        //    {
        //        Reports.StatusUpdate("File creation failed", false);
        //    }
        //    FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
        //    FastDriver.QuickFileEntry.Notes.FASetText(@"File Notes" + FAKeys.Tab);
        //    FastDriver.BottomFrame.Done();
        //}
        /// <summary>
        /// this.AddNoteFromNavigation("All Notes", "Times New Roman", "3", "Title", "create a new note");
        /// </summary>
        /// <param name="sNoteType"></param>
        /// <param name="sFontName"></param>
        /// <param name="sFontSize"></param>
        /// <param name="sNoteTypeEditor"></param>
        /// <param name="sNoteText"></param>
        private void AddNoteFromNavigation(string sNoteType, string sFontName, string sFontSize, string sNoteTypeEditor, string sNoteText, string sClickOn="")
        {
            try
            {
                Reports.TestStep = "Navigate to File Notes and Select Note Type.";
                FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
                FastDriver.FileNotes.WaitForScreenToLoad();
                FastDriver.FileNotes.NotesType.FASelectItem(sNoteType);
                FastDriver.FileNotes.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.FileNotes.New.FAClick();

                Reports.TestStep = "Create a file note.";
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                NewFileNoteParameters addNoteDetails = new NewFileNoteParameters();
                {
                    addNoteDetails.FontName = sFontName;
                    addNoteDetails.FontSize = sFontSize;
                    addNoteDetails.NoteType = sNoteTypeEditor;
                    addNoteDetails.NoteText = sNoteText;
                }
                FastDriver.FileNotesEditor.AddNote(addNoteDetails);
                if (sClickOn == "CheckSpelling")
                {
                    Reports.TestStep = "Click on checkSpelling.";
                    FastDriver.FileNotesEditor.CheckSpelling.FAClick();
                }
                else
                {
                    Reports.TestStep = "Click on Done.";
                    FastDriver.BottomFrame.Done();
                }
            }
            catch (Exception e)
            {
                FailTest("Test case failed because of following error : " + e.Message);
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="colIndex"></param>
        /// <param name="rowNum"></param>
        /// <param name="sText"></param>
        private void CheckValueInTable(int colIndex, int rowNum, string sText)
        {
            string value = "";
           // int rowNum = FastDriver.FileNotes.Table.GetRowCount();
            for (int i = 1; i < rowNum; i++)
            {
                value = FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad().Table.PerformTableAction(colIndex, sText.Trim(), i, TableAction.Click).ToString();
                if (value == "FASTSelenium.Common.OperationResult")
                {
                    break;
                }
            }

            Support.AreEqual("FASTSelenium.Common.OperationResult", value);     

        }
        public void VerifySubString(string sString, string sSubString)
        {
            try
            {
                if (sString.Contains(sSubString))
                {
                    Reports.UpdateDebugLog("Verify Text", "", "VerifySubString", "", "Expected Sub String is :\t" + sSubString, "Actual string is :\t" + sString, Reports.Result(true), "");
                }
                else
                {
                    Support.AreEqual(sString, sSubString);
                }
            }
            catch
            {

            }
        }
        //
        private void IISLOGIN(string UserName = null, string Password = null, bool CleanSession = true)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, CleanSession);

        }
        //
        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            UserName = UserName ?? AutoConfig.UserNameSU;
            Password = Password ?? AutoConfig.UserPasswordSU;
            Credentials credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
        }
        //

        #region SRT-ServReq

        //Team                  :  ServReq-Team1
        //Iteration             :  r08
        //UserStory             :  User Story 815236
        //TestCase              :  830103,830795,838861
        //Appended By/ Created By: Osama
        //Osama
        private WorkflowProcessTemplateInformation CreateNewProcessTemplate(string testCaseName)
        {
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            var processTemplate = new WorkflowProcessTemplateInformation
            {
                Type = "1099",
                Name = "FMUC0012_" + Support.RandomString("AAZZ"),
                WorkGroupName = "Accounting",
                Tasks = new List<WorkflowProcessTask>()
            };

            Reports.TestStep = "Create new template";
            Reports.StatusUpdate(string.Format("Create new template for {0}.", testCaseName), true);

            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            Reports.TestStep = "Navigate to Region Level.";
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID("1486");
            FastDriver.HomePage.WaitForHomeScreen();

            Reports.TestStep = "Navigate to Comment Codes screen.";
            FastDriver.LeftNavigation.Navigate<CommentCodes>(@"Home>System Maintenance>Process Setup>Comment Codes").WaitForScreenToLoad();
            int rowCount = FastDriver.CommentCodes.CommentCodeTable.GetRowCount();
            string commentCodeName = "OMF_CC1" + Support.RandomString("CCA");
            string commentCodeDescription = "Description FMUC0012_Osama" + rowCount.ToString();
            FastDriver.CommentCodes.New.FAClick();

            FastDriver.CommentCodes.CommentCodeTable.PerformTableAction((rowCount + 1), 3, TableAction.SetText, commentCodeName);
            FastDriver.CommentCodes.CommentCodeTable.PerformTableAction((rowCount + 1), 4, TableAction.SetText, commentCodeDescription);
            FastDriver.CommentCodes.CommentCodeTable.PerformTableAction((rowCount + 1), 5, TableAction.SelectItem, "Active");
            FastDriver.CommentCodes.CommentCodeTable.PerformTableAction((rowCount + 1), 6, TableAction.Click);
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();


            Reports.TestStep = "Navigate to Task Templates.";
            FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>(@"Home>System Maintenance>Process Setup>Task Templates").WaitForScreenToLoad();
            int rowCountT = FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount();
            FastDriver.TaskTemplateSelection.New.FAClick();

            Reports.TestStep = "Add info for new task.";
            FastDriver.TaskTemplateSelection.WaitCreation(FastDriver.TaskTemplateSelection.TasksForTable);
            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "AAOMFT" + Support.RandomString("TTA") });

            //string CCtaskName = "AAOMFT" + Support.RandomString("TTA");
            FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction((rowCountT + 1), 3, TableAction.SetText, processTemplate.Tasks[0].Name);
            FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction((rowCountT + 1), 5, TableAction.SelectItem, "Yes");
            FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction((rowCountT + 1), 4, TableAction.SetText, processTemplate.Tasks[0].Name);
            FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction((rowCountT + 1), 9, TableAction.Click);
            FastDriver.CommentCodeDlg.SwitchToDialogContentFrame();
            FastDriver.CommentCodeDlg.CommentCodeTable.PerformTableAction(2, commentCodeName, 1, TableAction.On); //(2, 1, TableAction.Click)
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
            FastDriver.BottomFrame.Save();
            FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
            FastDriver.BottomFrame.Done();
            FastDriver.TaskTemplateSelection.WaitForScreenToLoad();


            Reports.TestStep = "Navigate to Regional Process Summary.";
            FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.New.FAClick();

            Reports.TestStep = "Enter Process basic info.";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.ProcessType.FASelectItem(processTemplate.Type);
            FastDriver.RegionalProcessEdit.ProcessName.FASetText(processTemplate.Name);
            FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
            FastDriver.RegionalProcessEdit.Description.FASetText("Selenium001");

            Reports.TestStep = "Enter process template selection criteria.";
            FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
            FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
            FastDriver.SelectionCriteriaDlg.Done.FAClick();

            Reports.TestStep = "Enter process event selection criteria.";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
            FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
            FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "File created with Open status", 1, TableAction.On);
            FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "File created with Pending Status", 1, TableAction.On);
            FastDriver.DialogBottomFrame.ClickDone();

            Reports.TestStep = "Enter process template tasks.";
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
            FastDriver.RegionalProcessEdit.Add.FAClick();
            FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
            int TaskrowCount = FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetRowCount();
            Reports.TestStep = "Add info for new task.";
            FastDriver.TaskTemplateSelectionDlg.New.FAClick();
            FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();

            processTemplate.Tasks.Add(new WorkflowProcessTask { Name = "ZZ12_OMF" + Support.RandomString("AAZNA") });
            //string taskName = "ZZ12_OMF" + Support.RandomString("AAZNA");
            FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction((TaskrowCount + 1), 3, TableAction.SetText, processTemplate.Tasks[1].Name);
            FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction((TaskrowCount + 1), 5, TableAction.SelectItem, "No");
            FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction((TaskrowCount + 1), 2, TableAction.On);
            FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, processTemplate.Tasks[0].Name, 2, TableAction.Click);

            FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();


            FastDriver.BottomFrame.Done();
            FastDriver.RegionalProcessSummary.WaitForScreenToLoad();


            Reports.TestStep = "Select the created process name from the Regional Process Summary table.";
            FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processTemplate.Name, 1, TableAction.Click);

            Reports.TestStep = "Change the status.";
            FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
            FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
            FastDriver.StatusEdit.WaitForScreenToLoad();
            FastDriver.StatusEdit.Activate.FAClick();

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage();

            Reports.TestStep = "Navigate to Pending Refresh Summary.";
            FastDriver.PendingRefreshSummary.RefreshTemplate(processTemplate.Name);
            FastDriver.WebDriver.Quit();

            return processTemplate;
        }

        private void Add_Task_Comment()
        {
            Reports.TestStep = "Navigate to File Workflow screen";
            FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
            FastDriver.FileWorkflow.ExpandButton.FAClick();
            for (int i = 1; i <= 2; i++)
            {
                FastDriver.FileWorkflow.Process.PerformTableAction(i, 12, TableAction.Click).ToString();
                FastDriver.TaskCommentEditDlg.SwitchToDialogContentFrame();
                if ("No" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
                {
                    FastDriver.TaskCommentEditDlg.Comment.FASetText("Test Comment 1");
                    FastDriver.TaskCommentEditDlg.Done.FAClick();
                }
                else if ("Yes" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
                {
                    FastDriver.TaskCommentEditDlg.PublishedComment.FASetText("Test Comment 1 Published");
                    FastDriver.TaskCommentEditDlg.NonPublishedComment.FASetText("Test Comment 1 Non-Published");
                    FastDriver.TaskCommentEditDlg.TaskComment1.FAClick();
                    FastDriver.TaskCommentEditDlg.Done.FAClick();
                }
                FastDriver.FileWorkflow.WaitForScreenToLoad();
            }
            FastDriver.BottomFrame.Apply();
        }
        private void Append_Task_Comment_NonPublic()
        {

            Reports.TestStep = "Navigate to File Workflow screen";
            FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
            FastDriver.FileWorkflow.ExpandButton.FAClick();
            //for (int i = 1; i <= 2; i++)
            //{
            FastDriver.FileWorkflow.Process.PerformTableAction(2, 12, TableAction.Click).ToString();
            FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
            if ("No" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
            {
                FastDriver.TaskCommentEditDlg.Comment.FASetText("Test Comment 1 Appended 1");
                //FastDriver.TaskCommentEditDlg.TaskComment1.FAClick();
                //commentCodeName[i] = FastDriver.TaskCommentEditDlg.CommentCodeName.FAGetText().ToString();
                FastDriver.TaskCommentEditDlg.Done.FAClick();
            }
            else if ("Yes" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
            {
                FastDriver.TaskCommentEditDlg.PublishedComment.FASetText("Test Comment 1 Published Appended");
                FastDriver.TaskCommentEditDlg.NonPublishedComment.FASetText("Test Comment 1 Non-Published Appended");
                FastDriver.TaskCommentEditDlg.TaskComment1.FAClick();
                FastDriver.TaskCommentEditDlg.Done.FAClick();
            }
            FastDriver.FileWorkflow.WaitForScreenToLoad();
            //}
            FastDriver.BottomFrame.Apply();
        }

        private void Append_Task_Comment_Public()
        {

            Reports.TestStep = "Navigate to File Workflow screen";
            FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
            FastDriver.FileWorkflow.ExpandButton.FAClick();
            //for (int i = 1; i <= 2; i++)
            //{
            FastDriver.FileWorkflow.Process.PerformTableAction(1, 12, TableAction.Click).ToString();
            FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
            if ("No" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
            {
                FastDriver.TaskCommentEditDlg.Comment.FASetText("Test Comment 1 Appended 1");
                //FastDriver.TaskCommentEditDlg.TaskComment1.FAClick();
                //commentCodeName[i] = FastDriver.TaskCommentEditDlg.CommentCodeName.FAGetText().ToString();
                FastDriver.TaskCommentEditDlg.Done.FAClick();
            }
            else if ("Yes" == FastDriver.TaskCommentEditDlg.PublicFlag.Text.ToString())
            {
                FastDriver.TaskCommentEditDlg.PublishedComment.FASetText("Test Comment 1 Published Appended");
                FastDriver.TaskCommentEditDlg.NonPublishedComment.FASetText("Test Comment 1 Non-Published Appended");
                FastDriver.TaskCommentEditDlg.CommentCodeDescription.FASetText("Comment Code Appended");
                FastDriver.TaskCommentEditDlg.Done.FAClick();
            }
            FastDriver.FileWorkflow.WaitForScreenToLoad();
            //}
            FastDriver.BottomFrame.Apply();
        }

        private void VerifySortingOrder(string note, string type)
        {
            Reports.TestStep = "Verify the Sorting Order.";
            FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
            string x = FastDriver.FileNotes.FileNotesGrid.Text.Contains(note).ToString();
            Support.AreEqual("True", x);
            FastDriver.FileNotes.NotesType.FASelectItem(type);
            if (type == "Task Comments")
            {
                FastDriver.FileNotes.Image.FAClick();
                string x1 = FastDriver.FileNotes.TaskComment1.Text.Contains(note).ToString();
                Support.AreEqual("True", x1);
            }
            else
            {
                string x9 = FastDriver.FileNotes.FileNotesGrid.Text.Contains(note).ToString();
                Support.AreEqual("True", x9);
            }
            FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();
            Reports.TestStep = "Verify order in Preview screen.";
            FastDriver.FileNotes.Preview.FAClick();
            Playback.Wait(5000);
            string x8 = FastDriver.FileNotes.TitlePreview.Text.Contains(type).ToString();
            Support.AreEqual("True", x8);
            string x2 = FastDriver.FileNotes.NotePreviewGrid1.Text.Contains(note).ToString();
            Support.AreEqual("True", x2);

            FastDriver.LeftNavigation.Navigate<FileNotes>(@"Home>Order Entry>File Notes").WaitForScreenToLoad();

        }

        //End Osama
        #endregion

        #endregion
       // #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
