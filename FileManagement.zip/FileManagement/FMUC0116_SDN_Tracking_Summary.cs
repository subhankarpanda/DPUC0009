﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using AutoIt;
using System.Threading;
using System.IO;
using FASTSelenium.PageObjects.ADM;

namespace FileManagement
{
    [CodedUITest]

    public class FMUC0116_SDN_Tracking_Summary : MasterTestClass
    {
        #region REG

        #region Test FMUC0116_REG0001

        /// <summary>
        /// MF1: Disbursement Summary Report.
        /// </summary>
        [TestMethod]
        public void FMUC0116_REG0001()
        {
            try
            {
                Reports.TestDescription = "MainCourse, Business Rules:FM14450_FM14451_FM14454_FM14455_FM14456_FM14462_FM14463_FM14464.";

                #region DataSetup
                string AdhocNameForTest1 = "TestName1";
                string AdhocNameForTest2 = "Bin Laden";
                #endregion

                #region Login to file side
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Validate the SDN tracking summary page with SDN hit, no hit and InProgress tables and the names search in SDN screen.
                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Navigate to SDN Tracking Summary Page and validate the screen display with SDN hit, no hit and InProgress tables.";
                FastDriver.SDNTrackingSummary.Open();
                Support.AreEqual("true", FastDriver.SDNTrackingSummary.SDNHitTable.IsDisplayed().ToString().Trim().ToLower(), true);
                Support.AreEqual("true", FastDriver.SDNTrackingSummary.SDNNoHitTable.IsDisplayed().ToString().Trim().ToLower(), true);
                Support.AreEqual("true", FastDriver.SDNTrackingSummary.SdnInProgressTable.IsDisplayed().ToString().Trim().ToLower(), true);

                Reports.TestStep = "Validate the columns Searched, Hit and No Hit in SDN Tracking Summary Screen.";
                string SDNColumns = FastDriver.SDNTrackingSummary.SDNTable.FAGetText().ToString();
                if (SDNColumns.Contains("Searched") && SDNColumns.Contains("Hit") && SDNColumns.Contains("No Hit"))
                    Reports.StatusUpdate("The columns Searched, Hit and No Hit are available in the SDN tracking summary screen for Search in progress , Hit and No hit tables.", true);
                else
                    Reports.StatusUpdate("The columns Searched, Hit and No Hit are not available in the SDN tracking summary screen for Search in progress , Hit and No hit tables.", true);

                Reports.TestStep = "Validate the names in SDN summary screen.";
                FastDriver.SDNTrackingSummary.ValidateNamesInSDNScreen("Buyer1Firstname Buyer1Lastname");
                FastDriver.SDNTrackingSummary.ValidateNamesInSDNScreen("Buyer2Firstname Buyer2Lastname");
                FastDriver.SDNTrackingSummary.ValidateNamesInSDNScreen("Buyer2SpouseName Buyer2Lastname");
                FastDriver.SDNTrackingSummary.ValidateNamesInSDNScreen("Lenders Advantage A Division Of First American Title Ins.");
                FastDriver.SDNTrackingSummary.ValidateNamesInSDNScreen("Seller1FirstName Seller1Lastname");
                FastDriver.SDNTrackingSummary.ValidateNamesInSDNScreen("Seller2Firstname Seller2Lastname");
                FastDriver.SDNTrackingSummary.ValidateNamesInSDNScreen("Seller2SpouseName Seller2Lastname");

                Reports.TestStep = "Add a buyer and verify that name is present in SDN.";
                FastDriver.BuyerSellerSummary.Open(true);
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                Thread.Sleep(5000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(AdhocNameForTest1);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the adhoc name in Search table of SDN.";
                FastDriver.SDNTrackingSummary.Open();
                FastDriver.SDNTrackingSummary.ValidateNamesInSearchProgress(AdhocNameForTest1);

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Validate the adhoc name in No Hit table of SDN summary screen.";
                FastDriver.SDNTrackingSummary.ValidateNamesInSDNScreen(AdhocNameForTest1);
                /** No Hit Table has been removed by US 850809
                Reports.TestStep = "Validate the adhoc name date stamp in No Hit table of SDN summary screen for searched date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SdnNoHitTable, AdhocNameForTest1, 4);

                Reports.TestStep = "Validate the adhoc name date stamp in No Hit table of SDN summary screen for No Hit date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SdnNoHitTable, AdhocNameForTest1, 9);
                **/
                Reports.TestStep = "Add a buyer and verify that name is present in SDN.";
                FastDriver.BuyerSellerSummary.Open(true);
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                Thread.Sleep(5000);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(AdhocNameForTest2);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the adhoc name in Search table of SDN.";
                FastDriver.SDNTrackingSummary.Open();
                FastDriver.SDNTrackingSummary.ValidateNamesInSearchProgress(AdhocNameForTest2);

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Validate the adhoc name (Restricted name) in No Hit table of SDN summary screen.";
                FastDriver.SDNTrackingSummary.ValidateNamesInHit(AdhocNameForTest2);

                Reports.TestStep = "Validate the adhoc name date stamp in No Hit table of SDN summary screen for searched date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SDNHitTable, AdhocNameForTest2, 4);

                Reports.TestStep = "Validate the adhoc name date stamp in Hit table of SDN summary screen for Hit date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SDNHitTable, AdhocNameForTest2, 5);


                #endregion
            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0116_REG0002

        /// <summary>
        /// 
        /// </summary>
        [TestMethod]
        public void FMUC0116_REG0002()
        {
            try
            {
                Reports.TestDescription = "Business Rules: FM14457_FM14458_FM14459_FM14460_FM14461_FM14491_FM14468_FM14469.";

                #region DataSetup
                string NameForTest1 = "BuyerTest3";
                string NameForTest2 = "BuyerTest4Spouse1";
                string NameForTest3 = "BuyerTest4Spouse2";
                string NameForTest4 = "SellerTest3";
                string NameForTest5 = "SellerTest4Spouse1";
                string NameForTest6 = "SellerTest4Spouse2";
                string NameForTest7 = "Bin Laden Test";
                string NameForTest8 = "Bin Laden Test Update";
                string NameForTest9 = "Bin Laden";
                string NameForTest10 = "TestNameForLaden";
                int CountAfter3 = 0;
                #endregion

                #region Login to file side
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                Reports.TestStep = "Validate the alphabetical order of Roles in SearchInProcess table.";
                FastDriver.SDNTrackingSummary.Open();
                if (FastDriver.SDNTrackingSummary.SdnInProgressTable.GetRowCount() > 1)
                {
                    FastDriver.SDNTrackingSummary.ValidateRolesAreAlphabeticallyOrdered(FastDriver.SDNTrackingSummary.SdnInProgressTable);
                }

                Reports.TestStep = "Add an Additional Individual buyer.";
                AddIndividualBuyerOrSeller(NameForTest1, "Individual", true);

                Reports.TestStep = "Add an Additional Husband and Wife buyer.";
                AddSpouseBuyerOrSeller(NameForTest2, NameForTest3, "Husband/Wife", true);

                Reports.TestStep = "Add an Additional Individual seller.";
                AddIndividualBuyerOrSeller(NameForTest4, "Individual", false);

                Reports.TestStep = "Add an Additional Husband and Wife seller.";
                AddSpouseBuyerOrSeller(NameForTest5, NameForTest6, "Husband/Wife", false);

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Validate the alphabetical order of Roles in No Hit Table table.";
                FastDriver.SDNTrackingSummary.ValidateRolesAreAlphabeticallyOrdered(FastDriver.SDNTrackingSummary.SDNNoHitTable);

                Reports.TestStep = "Validate the Each Instance of a Role/Association.";
                FastDriver.SDNTrackingSummary.ValidateEachInstanceOfRoles(FastDriver.SDNTrackingSummary.SDNNoHitTable);
                int CountBefore = FastDriver.SDNTrackingSummary.SDNNoHitTable.GetRowCount();

                Reports.TestStep = "Add a name which enters Hit Table.";
                AddIndividualBuyerOrSeller(NameForTest9, "Individual", true);

                Reports.TestStep = "Add an Additional Individual buyer.";
                AddIndividualBuyerOrSeller(NameForTest7, "Individual", true);

                Reports.TestStep = "Validate the new row created for new name added and Hit table still has the previous name.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                if (FastDriver.SDNTrackingSummary.SDNHitTable.FAGetText().Contains(NameForTest9).ToString() == "True")
                {
                    Reports.StatusUpdate("The name which is in Hit table, remains there.", true);
                }
                else
                {
                    Reports.StatusUpdate("The name which is in Hit table does not retain there.", true);
                }


                int CountAfter = FastDriver.SDNTrackingSummary.SDNNoHitTable.GetRowCount();
                if (CountAfter - CountBefore == 1)
                {
                    Support.AreEqual("True", FastDriver.SDNTrackingSummary.SDNNoHitTable.FAGetText().Contains(NameForTest7).ToString(), true);
                    Reports.StatusUpdate("New row added for the name: " + NameForTest7 + ".", true);
                }

                Reports.TestStep = "Add the same name again and validate no additonal rows since name is already available in NoHit table.";
                AddIndividualBuyerOrSeller(NameForTest7, "Individual", true);
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);
                int CountAfter2 = FastDriver.SDNTrackingSummary.SDNNoHitTable.GetRowCount();
                if (CountAfter2 == CountAfter)
                {
                    Reports.StatusUpdate("New row is not added for the name: " + NameForTest7 + " since the name is already available in NoHit table.", true);
                }

                Reports.TestStep = "Update the already exisiting name.";
                FastDriver.BuyerSellerSummary.Open(true);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, NameForTest1, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(NameForTest8);
                string UpdatedName = FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().ToString();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that old name is updated with new name and no new rows created.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);
                if (FastDriver.SDNTrackingSummary.SDNNoHitTable.FAGetText().Contains(NameForTest1).ToString() == "True")
                {
                    Reports.StatusUpdate("Old name" + NameForTest1 + " is not replaced with new name" + UpdatedName + ".", false);
                }
                else
                {
                    Reports.StatusUpdate("Old name" + NameForTest1 + " is replaced with new name" + UpdatedName + ".", true);
                    CountAfter3 = FastDriver.SDNTrackingSummary.SDNNoHitTable.GetRowCount();
                    if (CountAfter3 == CountAfter)
                    {
                        Reports.StatusUpdate("New row is not added for the name: " + UpdatedName + " as it is replaced for name " + NameForTest1 + ".", true);
                    }
                }

                Reports.TestStep = "Update the name existing in Hit table.";
                FastDriver.BuyerSellerSummary.Open(true);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, NameForTest9, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(NameForTest10);
                string UpdatedName2 = FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().ToString();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Hit name is not removed from Hit table and new entry is created for new name.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);
                if (FastDriver.SDNTrackingSummary.SDNHitTable.GetRowCount() > 1)
                {
                    if (FastDriver.SDNTrackingSummary.SDNHitTable.FAGetText().Contains(NameForTest9).ToString() == "True")
                    {
                        Support.AreEqual("Buyer 5", FastDriver.SDNTrackingSummary.SDNHitTable.PerformTableAction(2, NameForTest9, 3, TableAction.GetText).Message.Clean().ToString().Trim(), true);
                        Reports.StatusUpdate("Hit name is available in Hit table even after updation.", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Hit name is not available in Hit table even after updation.", true);
                    }
                }

                if (FastDriver.SDNTrackingSummary.SDNNoHitTable.GetRowCount() - CountAfter3 == 1)
                {
                    if (FastDriver.SDNTrackingSummary.SDNNoHitTable.FAGetText().Contains(UpdatedName2).ToString() == "True")
                    {
                        Support.AreEqual("Buyer 5", FastDriver.SDNTrackingSummary.SDNNoHitTable.PerformTableAction(2, UpdatedName2, 3, TableAction.GetText).Message.Clean().ToString().Trim(), true);
                        Reports.StatusUpdate("No row is added in No hit table for the name: " + UpdatedName2 + ".", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("No row is not added in No hit table for the name: " + UpdatedName2 + ".", true);
                    }
                }


                Reports.TestStep = "Validate H/W as Separate Entries and Display of Multiple Role/Associations.";
                Support.AreEqual("Buyer 4 / Spouse1", FastDriver.SDNTrackingSummary.SDNNoHitTable.PerformTableAction(2, "BuyerTest4Spouse1 LastName", 3, TableAction.GetText).Message.Clean().ToString().Trim(), true);
                Support.AreEqual("Buyer 4 / Spouse2", FastDriver.SDNTrackingSummary.SDNNoHitTable.PerformTableAction(2, "BuyerTest4Spouse2 LastName", 3, TableAction.GetText).Message.Clean().ToString().Trim(), true);
                Support.AreEqual("Seller 4 / Spouse1", FastDriver.SDNTrackingSummary.SDNNoHitTable.PerformTableAction(2, "SellerTest4Spouse1 LastName", 3, TableAction.GetText).Message.Clean().ToString().Trim(), true);
                Support.AreEqual("Seller 4 / Spouse2", FastDriver.SDNTrackingSummary.SDNNoHitTable.PerformTableAction(2, "SellerTest4Spouse2 LastName", 3, TableAction.GetText).Message.Clean().ToString().Trim(), true);
                Support.AreEqual("Buyer 6, Buyer 7", FastDriver.SDNTrackingSummary.SDNNoHitTable.PerformTableAction(2, "Bin Laden Test", 3, TableAction.GetText).Message.Clean().ToString().Trim(), true);

            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0116_REG0003_PH
        /// <summary>
        /// FM14492 Searching Names every 180 days , FM14498 Update SDN Tracking Summary Table for Search Performed every 180 Days 
        /// </summary>
        [TestMethod, Obsolete]
        public void FMUC0116_REG0003_PH()
        {
            try
            {
                Reports.TestDescription = "FM14492 Searching Names every 180 days , FM14498 Update SDN Tracking Summary Table for Search Performed every 180 Days .";
                Reports.StatusUpdate("Dummy subtest to use it as a Place holder for Non Automated scenarios - This Flow has NOT been Automated Please perform this MANUALLY", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Test FMUC0116_REG0004

        /// <summary>
        /// FM14452_FM14453_FM14465_FM14466_FM14467.
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void FMUC0116_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM14452_FM14453_FM14465_FM14466_FM14467.";

                #region DataSetup
                string NameForTest1 = "BIN LADEN";
                string NameForTest2 = "ABU ZUBEYR";
                string todaysdate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, TimeZoneInfo.Local.Id, "Pacific Standard Time").ToString("MM/dd/yyyy");

                
                #endregion

                #region Login to file side
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region
                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Add an additional buyer 3.";
                AddIndividualBuyerOrSeller(NameForTest1, "Individual", true);

                Reports.TestStep = "Add an additional buyer 4.";
                AddIndividualBuyerOrSeller(NameForTest2, "Individual", true);

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);
                /**No Hit Table has been removed by US 850809
                Reports.TestStep = "Validate the date stamp for buyer 1 in NoHit table of SDN summary screen for searched date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SdnNoHitTable, "Buyer1Firstname Buyer1Lastname", 4);

                Reports.TestStep = "Validate the date stamp for buyer 1 in NoHit table of SDN summary screen for NoHit date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SdnNoHitTable, "Buyer1Firstname Buyer1Lastname", 9);

                Reports.TestStep = "Validate the date stamp for seller 1 in NoHit table of SDN summary screen for searched date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SdnNoHitTable, "Seller1FirstName Seller1Lastname", 4);

                Reports.TestStep = "Validate the date stamp for seller 1 in NoHit table of SDN summary screen for NoHit date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SdnNoHitTable, "Seller1FirstName Seller1Lastname", 9);
                **/

                Reports.TestStep = "Validate the date stamp for buyer 3 in Hit table of SDN summary screen for searched date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SDNHitTable, NameForTest1, 4);

                Reports.TestStep = "Validate the date stamp for buyer 3 in Hit table of SDN summary screen for Hit date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SDNHitTable, NameForTest1, 5);

                Reports.TestStep = "Validate the date stamp for buyer 4 in Hit table of SDN summary screen for searched date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SDNHitTable, NameForTest2, 4);

                Reports.TestStep = "Validate the date stamp for buyer 4 in Hit table of SDN summary screen for Hit date.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SDNHitTable, NameForTest2, 5);

                UplaodAndSaveDoc("SEC-SDN Cleared", "BIN LADEN");

                /* Not Cleared reference has been removed by US 850821
                UplaodAndSaveDoc("SEC-SDN NOT Cleared", "ABU ZUBEYR");
                Reports.TestStep = "Wait for Upload and Save complete and validate the same in Doc Rep.";
                WaitForUploadAndSaveComplete(50);
                Reports.TestStep = "Complete the SDN process for the SDN cleared and not cleared Hit names.";
                CompleteTheSDNProcess();
                */
                Reports.TestStep = "Wait for the Process Complete to reflect in SDN.";
                FastDriver.SDNTrackingSummary.WaitForSDNPrcoessComplete(FastDriver.SDNTrackingSummary.SDNHitTable, NameForTest2, 8);

                Reports.TestStep = "Validate the DocUpl Sec-SDN cleared date stamp for Cleared Hitname: buyer 3 in SDN summary screen.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SDNHitTable, NameForTest1, 6);

                Reports.TestStep = "Validate the process completed date stamp for Cleared Hitname: buyer 3 in SDN summary screen.";
                Support.AreEqual(true, FastDriver.SDNTrackingSummary.SDNHitTable.FAGetText().Contains(todaysdate),"Today's date is displayed");

                /* Not Cleared reference has been removed by US 850821            
                Reports.TestStep = "Validate the DocUpl Sec-SDN  NOT cleared date stamp for Cleared Hitname: buyer 4 in SDN summary screen.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SdnHitTable, NameForTest2, 7);
                Reports.TestStep = "Validate the process completed date stamp for Cleared Hitname: buyer 4 in SDN summary screen.";
                FastDriver.SDNTrackingSummary.ValidateDate(FastDriver.SDNTrackingSummary.SdnHitTable, NameForTest2, 8);
                */
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC116_REG0005

        [TestMethod]
        public void FMUC116_REG0005()
        {
            try
            {
                Reports.TestDescription = "To test US# 850809 - Verify Columns: Hit, Doc Upl SEC-SDN Not cleared, Process Complete and No Hit, are not displaying on SDN Tracking Summary Screen.";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST IIS Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File";
                CreateBasicFile();

                Reports.TestStep = "Navigate to SDN Tracking Summary Screen.";
                FastDriver.SDNTrackingSummary.Open();

                Reports.TestStep = "Verify Columns: Hit, Doc Upl SEC-SDN Cleared, Doc Upl SEC-SDN Not Cleared, Process Complete and No Hit, are not displaying on SDN Tracking Summary Screen.";
                Support.AreEqual("False", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("Hit").ToString(), "Hit column is not present");
                Support.AreEqual("False", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("Doc Upl SEC-SDN Cleared").ToString(), "Doc Upl SEC-SDN Cleared column is not present");
                Support.AreEqual("False", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("Doc Upl SEC-SDN Not Cleared").ToString(), "Doc Upl SEC-SDN Not Cleared column is not present");
                Support.AreEqual("False", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("Process Complete").ToString(), "Process Complete column is not present");
                Support.AreEqual("False", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("No Hit").ToString(), "No Hit column is not present");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region Test FMUC116_REG0006

        [TestMethod]
        public void FMUC116_REG0006()
        {
            try
            {
                Reports.TestDescription = "To test US# 850809 - Verify 'SCD Completed' column is displayed on SDN Tracking Summary Screen.";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST IIS Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File";
                CreateBasicFile();

                Reports.TestStep = "Navigate to SDN Tracking Summary Screen.";
                FastDriver.SDNTrackingSummary.Open();

                Reports.TestStep = "Verify 'SCD Completed' column is displayed on SDN Tracking Summary Screen.";
                Support.AreEqual("True", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("SDN Completed").ToString(), "SCD Cleared column is present");
                Support.AreEqual("False", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("Doc Upl SEC-SDN Cleared").ToString(), "Doc Upl SEC-SDN Cleared column is not present");

                Reports.TestStep = "SDN Tracking Summary Screen only displays Columns: Name, Role/Association, Searched and SDN Cleared.";
                Support.AreEqual("True", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("Name").ToString(), "Name column is present");
                Support.AreEqual("True", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("Role/Association").ToString(), "Role/Association column is present");
                Support.AreEqual("True", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("Searched").ToString(), "Searched column is present");
                Support.AreEqual("True", FastDriver.SDNTrackingSummary.SDNTable.FAGetText().Contains("SDN Completed").ToString(), "SCD Completed column is present");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region Test FMUC116_REG0007

        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC116_REG0007()
        {
            try
            {
                Reports.TestDescription = "To test US# 850821 - Verify ‘SEC-SDN Not Cleared' is removed from Upload and Scan Save Document Dialog on Document Repository";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST IIS Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File";
                CreateBasicFile();

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.DocumentRepository.Open();

                Reports.TestStep = "Click on Upload, select a File and click Upload";
                FastDriver.DocumentRepository.Upload.FAClick();
                BrowseFileUpload();

                Reports.TestStep = "Verify ‘SEC-SDN NOT Cleared' is not displaying as part of the Upload Document Name list";
                ValidateOnUpload();

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.DocumentRepository.Open();

                Reports.TestStep = "Click on Scan, open a File and click Done";
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                BrowseFileScan();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify ‘SEC-SDN NOT Cleared' is not displaying as part of the Scan Document Name list";
                ValidateOnScan();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test FMUC116_REG0008
        
        [TestMethod]
        public void FMUC116_REG0008()
        {
            try
            {
                Reports.TestDescription = "To test US# 855343 - Verify system automatically populate date and time information when the SEC-SDN Cleared document is uploaded";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST IIS Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File with SDN Buyer";
                CreateBasicFile();

                Reports.TestStep = "Navigate to SDN Tracking Summary";
                Reports.TestStep = "Wait to the SDN compares submitted names to SDN list and identifies one or more hits";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.SDNTrackingSummary.Open();
                    return FastDriver.SDNTrackingSummary.SDNHitTable.Text.Contains("Bin Laden");
                }, timeout: 300, idleInterval: 5);

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.DocumentRepository.Open();

                Reports.TestStep = "Obtain Hit document on Document Search Results";
                Support.AreEqual("True", FastDriver.DocumentRepository.DocumentsTable.FAGetText().Contains("SDN Search Results - Osama Bin Laden").ToString(), "SDN Search Results - Osama Bin Laden is present on Document Repository");

                Reports.TestStep = "Upload SEC-SDN Cleared document for the SDN";
                FastDriver.DocumentRepository.Upload.FAClick();
                UploadSDNClearedFile();

                Reports.TestStep = "Navigate to SDN Tracking Summary";
                FastDriver.SDNTrackingSummary.Open();

                Reports.TestStep = "Verify system automatically populate date and time information in the SDN Completed column";
                string todaysdate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, TimeZoneInfo.Local.Id, "Pacific Standard Time").ToString("MM/dd/yyyy");
                Support.AreEqual("True", FastDriver.SDNTrackingSummary.SDNCleared.FAGetText().Clean().Contains(todaysdate).ToString(), "Verify the Date/Time for SDN");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test FMUC116_REG0009

        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC116_REG0009()
        {
            try
            {
                Reports.TestDescription = "To test US# 886333 - Verify Web Service GetSDNTrackingSummaryDetails response is updated accordingly.";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST IIS Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File, Create Buyer = Osama Bin Laden";
                int FileID = CreateBasicFile();

                Reports.TestStep = "Navigate to SDN Tracking Summary Screen.";
                Reports.TestStep = "Refresh screen until SDN searching is completed";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.SDNTrackingSummary.Open();
                    return FastDriver.SDNTrackingSummary.SDNHitTable.Text.Contains("Bin Laden");
                }, timeout: 300, idleInterval: 5);

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.DocumentRepository.Open();

                Reports.TestStep = "Obtain Hit document on Document Search Results";
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.FAGetText().Contains("SDN Search Results - Osama Bin Laden"), "SDN Search Results - Osama Bin Laden is present on Document Repository");

                Reports.TestStep = "Upload SEC-SDN Cleared document for the SDN";
                FastDriver.DocumentRepository.Upload.FAClick();
                UploadSDNClearedFile();

                Reports.TestStep = "Navigate to SDN Tracking Summary";
                FastDriver.SDNTrackingSummary.Open();

                Reports.TestStep = "Obtain from SDN Hit: Name, Role/Association,Searched, SDN Completed, SDN Reference Number";
                string Name = FastDriver.SDNTrackingSummary.HitName.FAGetText().Clean();
                string RoleAssociation = FastDriver.SDNTrackingSummary.HitRoleAssociation.FAGetText().Clean();
                string Searched = FastDriver.SDNTrackingSummary.HitSearched.FAGetText().Clean();
                string SDNCompleted = FastDriver.SDNTrackingSummary.SDNCleared.FAGetText().Clean();
                string SDNReferenceNumber = FastDriver.SDNTrackingSummary.SDNReferenceNumber.FAGetText().Clean();

                Reports.TestStep = "Call GetSDNTrackingSummaryDetails";
                var GetSDNTrackingSummaryDetailsRequest = EscrowRequestFactory.GetSDNSearchRequest(FileID);
                var response = EscrowService.GetSDNTrackingSummaryDetails(GetSDNTrackingSummaryDetailsRequest);

                Reports.TestStep = "Verify the following nodes are not displaying on the response: DocumentUploadClearedDate, DocumentUploadNotClearedDate, HitDate, NoHitDate, ProcessCompletedDate";
                Support.AreEqual(false, response.Hit[0].HasProperty("DocumentUploadClearedDate"), "DocumentUploadClearedDate is not present");
                Support.AreEqual(false, response.Hit[0].HasProperty("DocumentUploadNotClearedDate"), "DocumentUploadNotClearedDate is not present");
                Support.AreEqual(false, response.Hit[0].HasProperty("HitDate"), "HitDate is not present");
                Support.AreEqual(false, response.Hit[0].HasProperty("NoHitDate"), "NoHitDate is not present");
                Support.AreEqual(false, response.Hit[0].HasProperty("ProcessCompletedDate"), "ProcessCompletedDate is not present");

                Reports.TestStep = "Validate that the response data is the same as the UI: Name, Role/Association, Searched, SDN Completed, SDN Reference Number";
                Support.AreEqual(Name, response.Hit[0].Name.Clean());
                Support.AreEqual(RoleAssociation, response.Hit[0].RoleOrAssociation.Clean());
                Support.AreEqual(Searched, response.Hit[0].SearchedDate.Clean());
                Support.AreEqual(SDNCompleted, response.Hit[0].SDNCompleted.Clean());
                Support.AreEqual(SDNReferenceNumber, response.Hit[0].SDNReferenceNumber.ToString().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Test FMUC116_REG0010

        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC116_REG0010()
        {
            try
            {
                Reports.TestDescription = "To Test US# 890888 - Verify if the SDN Naming convention is displayed on Work Queue to add SDN Search Name List.";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST IIS Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File with Buyer = Osama Bin Laden";
                string FileNumber = CreateBasicFileString();

                Reports.TestStep = "Navigate to SDN Tracking Summary Screen.";
                Reports.TestStep = "Refresh screen until SDN searching is completed";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.SDNTrackingSummary.Open();
                    return FastDriver.SDNTrackingSummary.SDNHitTable.Text.Contains("Bin Laden");
                }, timeout: 300, idleInterval: 5);

                ValidateOnWorkQUpload(FileNumber);

                Reports.TestStep = "Navigate to SDN Tracking Summary";
                FastDriver.SDNTrackingSummary.Open();

                Reports.TestStep = "Verify system automatically populate date and time information in the SDN Completed column";
                string todaysdate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, TimeZoneInfo.Local.Id, "Pacific Standard Time").ToString("MM/dd/yyyy");
                Support.AreEqual("True", FastDriver.SDNTrackingSummary.SDNCleared.FAGetText().Clean().Contains(todaysdate).ToString(), "Verify the Date/Time for SDN");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test FMUC116_REG0011
        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC116_REG0011()
        {
            try
            {
                Reports.TestDescription = "To Test US# 890897 - Verify system is automatically completing SDN Completed column for all duplicate SDN Reference numbers - Upload";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST IIS Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File with Buyer = Osama Bin Laden";
                CreateBasicFile();

                Reports.TestStep = "Create Seller = Osama BinLaden";
                FastDriver.BuyerSellerSetup.Open(false);
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Usama");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Bin Laden");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to SDN Tracking Summary Screen.";
                Reports.TestStep = "Refresh screen until SDN searching is completed";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.SDNTrackingSummary.Open();
                    return FastDriver.SDNTrackingSummary.SDNHitTable.Text.Contains("Osama") && FastDriver.SDNTrackingSummary.SDNHitTable.Text.Contains("Usama");
                }, timeout: 300, idleInterval: 5);

                Reports.TestStep = "Verify that Buyer and Seller SDN Reference number is the same";
                var BuyerReference = FastDriver.SDNTrackingSummary.SDNReferenceNumber.FAGetText().Clean();
                var SellerReference = FastDriver.SDNTrackingSummary.SDNReferenceNumber1.FAGetText().Clean();
                Support.AreEqual(BuyerReference, SellerReference, "Buyer and Seller SDN Reference number is the same");

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.DocumentRepository.Open();

                Reports.TestStep = "Obtain Hit document on Document Search Results";
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.FAGetText().Contains("SDN Search Results - Osama Bin Laden"), "SDN Search Results - Osama Bin Laden is present on Document Repository");

                Reports.TestStep = "Upload SEC-SDN Cleared document for the SDN";
                FastDriver.DocumentRepository.Upload.FAClick();
                UploadSDNClearedFile();

                Reports.TestStep = "Navigate to SDN Tracking Summary";
                FastDriver.SDNTrackingSummary.Open();

                Reports.TestStep = "Verify system automatically populate date and time information in the SDN Completed column for Buyer and Seller";
                string todaysdate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, TimeZoneInfo.Local.Id, "Pacific Standard Time").ToString("MM/dd/yyyy");
                Support.AreEqual(true, FastDriver.SDNTrackingSummary.SDNCleared.FAGetText().Clean().Contains(todaysdate), "Verify the Date/Time for Buyer SDN");
                Support.AreEqual(true, FastDriver.SDNTrackingSummary.SDNCleared1.FAGetText().Clean().Contains(todaysdate), "Verify the Date/Time for Seller SDN");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }       

        #endregion

        #region Test FMUC116_REG0012
        [TestMethod]
        public void FMUC116_REG0012()
        {
            try
            {
                Reports.TestDescription = "To test US# 890905 – Verify SDN Reference number is being automatically populated in the SDN Reference number column after the search results return.";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST IIS Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File, add buyer with the name = Osama Bin Laden";
                CreateBasicFile();

                Reports.TestStep = "Navigate to SDN Tracking Summary Screen.";
                Reports.TestStep = "Refresh screen until SDN searching is completed";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.SDNTrackingSummary.Open();
                    return FastDriver.SDNTrackingSummary.SDNHitTable.Text.Contains("Bin Laden");
                }, timeout: 300, idleInterval: 5);

                Reports.TestStep = "Confirm SDN Reference number is being automatically populated in the SDN Reference number column";
                Support.AreEqual(true, FastDriver.SDNTrackingSummary.SDNReferenceNumber.Exists(), "SDN Reference Number is displayed.");
                Support.AreNotEqual("0", (FastDriver.SDNTrackingSummary.SDNReferenceNumber.FAGetText().Clean()), "SDN Reference Number is displayed correctly.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region Test FMUC116_REG0013

        [TestMethod]
        public void FMUC116_REG0013()
        {
            try
            {
                Reports.TestDescription = "To test US# 890918 - Verify that duplicate SDN hits has the same SDN Reference number and only one workflow process should be pulled.";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST IIS Application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File, Create Buyer = Osama Bin Laden";
                CreateBasicFile();

                Reports.TestStep = "Navigate to SDN Tracking Summary Screen.";
                Reports.TestStep = "Refresh screen until SDN searching is completed";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.SDNTrackingSummary.Open();
                    return FastDriver.SDNTrackingSummary.SDNHitTable.Text.Contains("Bin Laden");
                }, timeout: 300, idleInterval: 5);

                Reports.TestStep = "Create Seller = Usama Bin Laden";
                FastDriver.BuyerSellerSetup.Open(false);
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Usama");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Bin Laden");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to SDN Tracking Summary Screen.";
                Reports.TestStep = "Refresh screen until SDN searching is completed";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.SDNTrackingSummary.Open();
                    return FastDriver.SDNTrackingSummary.SDNHitTable.Text.Contains("Usama");
                }, timeout: 300, idleInterval: 5);

                Reports.TestStep = "Verify that Buyer and Seller SDN Reference number is the same";
                var BuyerReference = FastDriver.SDNTrackingSummary.SDNReferenceNumber.FAGetText().Clean();
                var SellerReference = FastDriver.SDNTrackingSummary.SDNReferenceNumber1.FAGetText().Clean();
                Support.AreEqual(BuyerReference, SellerReference, "Buyer and Seller SDN Reference number is the same");

                Reports.TestStep = "Navigate to WorkFlow screen";
                FastDriver.FileWorkflow.Open();

                Reports.TestStep = "Verify only on process pulls in for SDN Clearance";
                Support.AreEqual(true, FastDriver.FileWorkflow.MainTable.FAGetText().Contains("Osama Bin Laden"), "1st Process is pulled");
                Support.AreEqual(false, FastDriver.FileWorkflow.MainTable.FAGetText().Contains("Usama Bin Laden"), "Duplicate Process is not pull");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #endregion

        #region Private Methods

        private void IISLOGIN(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void AddIndividualBuyerOrSeller(string Name, string BuyerType, bool BuyerOrSeller)
        {
            FastDriver.BuyerSellerSummary.Open(BuyerOrSeller);
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(BuyerType);
            Thread.Sleep(5000);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(Name);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BottomFrame.Done();
        }

        private void AddSpouseBuyerOrSeller(string HusbandName, string WifeName, string BuyerType, bool BuyerOrSeller)
        {
            FastDriver.BuyerSellerSummary.Open(BuyerOrSeller);
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem(BuyerType);
            Thread.Sleep(5000);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText(HusbandName);
            FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("LastName");
            FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText(WifeName);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BottomFrame.Done();
        }

        private void UplaodAndSaveDoc(string DocumentName, string SDNhitName)
        {
            Reports.TestStep = "Navigate to Doc Repository and Click on Upload.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
            FastDriver.DocumentRepository.Upload.FAClick();

            Reports.TestStep = "Browse document and upload it (jpg).";
            if (!((Reports.DEPLOYDIR + "\\Hello.pdf").ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support.Hello.pdf", Reports.DEPLOYDIR + "\\Hello.pdf");
            }
            string FilePath = Reports.DEPLOYDIR + "\\Hello.pdf";
            FastDriver.UploadDocumentDlg.UploadFile(FilePath);

            Reports.TestStep = "Save Scanned doc.";
            FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
            FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
            FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Misc");
            FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(DocumentName);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("Test");
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.SaveDocumentDlg.SDNhitNameList.FASelectItem(SDNhitName);
            FastDriver.SaveDocumentDlg.Ok.Click();
            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false);
            }
            catch (TimeoutException)
            {
                Reports.StatusUpdate("Saving... NoTitle window has closed fast.", true);
            }
        }

        private void WaitForUploadAndSaveComplete(int timeoutSeconds)
        {
            int i = 0;

            do
            {
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(FastDriver.DocumentRepository.Deliver);
                string text = FastDriver.DocumentRepository.DocumentsTable.FAGetText();
                if ((text.Contains("SEC-SDN Cleared - BIN LADEN").ToString() == "True") && (text.Contains("SEC-SDN NOT Cleared - ABU ZUBEYR").ToString() == "True"))
                {
                    break;
                }
                else
                {
                    i = i + 5;
                    Playback.Wait(5000);
                }
            } while (i <= timeoutSeconds);
        }

        private void CompleteTheSDNProcess()
        {
            FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad(FastDriver.FileWorkflow.EventLog);
            if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
            {
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Applying Changes...", false);
            }

            FastDriver.FileWorkflow.ClickCompleteTaskCheckboxForTask("SDN Clearance - BIN LADEN", "SDN Cleared");

            FastDriver.FileWorkflow.ClickCompleteTaskCheckboxForTask("SDN Clearance - ABU ZUBEYR", "SDN NOT Cleared");

            FastDriver.BottomFrame.Apply();

        }

        public int CreateBasicFile()
        {
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 First American St.";
            fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
            fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
            fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
            fileRequest.File.Properties[0].PropertyAddress[0].Zip = "92707";
            fileRequest.File.NewLoan = null;
            fileRequest.File.Buyers[0].Type = "Individual";
            fileRequest.File.Buyers[0].FirstName = "Osama";
            fileRequest.File.Buyers[0].LastName = "Bin Laden";
            fileRequest.File.Sellers = null;
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            return (int)File.FileID;
        }

        public string CreateBasicFileString() // Basic file with Buyer = Osama Bin Laden
        {
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1 First American St.";
            fileRequest.File.Properties[0].PropertyAddress[0].City = "Adams";
            fileRequest.File.Properties[0].PropertyAddress[0].State = "OH";
            fileRequest.File.Properties[0].PropertyAddress[0].County = "Adams";
            fileRequest.File.Properties[0].PropertyAddress[0].Zip = "94122";
            fileRequest.File.NewLoan = null;
            fileRequest.File.Buyers[0].Type = "Individual";
            fileRequest.File.Buyers[0].FirstName = "Osama";
            fileRequest.File.Buyers[0].LastName = "Bin Laden";
            fileRequest.File.Sellers = null;
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            return File.FileNumber;
        }

        public void BrowseFileUpload()
        {
            Playback.Wait(3000);
            Reports.TestStep = "Browse document and upload it (jpg).";
            if (!((Reports.DEPLOYDIR + "\\JpegFile.jpg").ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support.JpegFile.jpg", Reports.DEPLOYDIR + "\\JpegFile.jpg");
            }
            string FilePath = Reports.DEPLOYDIR + "\\JpegFile.jpg";
            FastDriver.UploadDocumentDlg.UploadFile(FilePath);
        }

        public void BrowseFileScan()
        {
            FastDriver.ImagingWorkBench.ClickOpen();
            FastDriver.OpenImageDlg.OpenImage((Reports.DEPLOYDIR + "\\JpegFile.jpg"));
            Playback.Wait(3000);
        }

        private void ValidateOnUpload()
        {
            FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
            FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Misc");
            Support.AreEqual("False", FastDriver.SaveDocumentDlg.DocumentName.FAGetText().Contains("SEC-SDN NOT Cleared").ToString(), "'SEC SDN Not Cleared' option is not present");

            Reports.TestStep = "Click Cancel";
            FastDriver.SaveDocumentDlg.Cancel.FAClick();
            FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
            FastDriver.UploadDocumentDlg.Cancel.FAClick();
        }

        private void ValidateOnScan()
        {
            Playback.Wait(4000);
            Reports.TestStep = "Select Document Type";
            AutoItX.WinWait("Save Document", "", 5);
            AutoItX.WinActivate("Save Document");
            AutoItX.ControlCommand("Save Document", "", "[CLASS:ThunderRT6ComboBox;INSTANCE:5]", "SelectString", "Escrow: Misc");
            AutoItX.ControlCommand("Save Document", "", "[CLASS:ThunderRT6ComboBox;INSTANCE:4]", "SelectString", "SEC-SDN NOT Cleared");

            Reports.TestStep = "Click Cancel";
            Reports.StatusUpdate("Document Name not available.", AutoItX.ControlCommand("Save Document", "", "[CLASS:ThunderRT6CommandButton;Text:OK]", "IsEnabled", "") == "0");
            AutoItX.ControlEnable("Save Document", "", "[CLASS:ThunderRT6CommandButton;Text:Cancel]");
            AutoItX.ControlClick("Save Document", "", "[CLASS:ThunderRT6CommandButton;Text:Cancel]");
        }

        private void ValidateOnWorkQUpload()
        {
            Reports.TestStep = "Click on WorkQ";
            FastDriver.TopFrame.ClickWorkQTab();
            Support.CloseAllProcessStartingWith("AcroRd");
            if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
            {
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
            }
            FastDriver.WebDriver.HandleDialogMessage();
            Playback.Wait(2000);
            FastDriver.WorkQueueTop.WaitForScreenToLoad();

            Reports.TestStep = "Click on WorkQ Upload and Upload a file";
            FastDriver.WorkQueueTop.Upload.FAClick();
            FastDriver.UploadFileToQueueDlg.WaitForScreenToLoad();
            Reports.TestStep = "Browse document and upload it (jpg).";
            if (!((Reports.DEPLOYDIR + "\\JpegFile.jpg").ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support.JpegFile.jpg", Reports.DEPLOYDIR + "\\JpegFile.jpg");
            }
            string FilePath = Reports.DEPLOYDIR + "\\JpegFile.jpg";
            FastDriver.UploadFileToQueueDlg.imageFilePath.FASetText(FilePath);
            FastDriver.UploadFileToQueueDlg.Upload.FAClick();
            FastDriver.TopFrame.ClickWorkNTab();
            if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
            {
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
            }
            FastDriver.WebDriver.HandleDialogMessage();
            Playback.Wait(2000);
            FastDriver.TopFrame.ClickWorkQTab();
            Support.CloseAllProcessStartingWith("AcroRd");
            if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
            {
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
            }
            FastDriver.WebDriver.HandleDialogMessage();
            Playback.Wait(2000);
            FastDriver.WorkQueueTop.WaitForScreenToLoad();

            Reports.TestStep = "Click on WorkQ Attach";
            FastDriver.WorkQueueTop.Attach.FAClick();
            FastDriver.AttachMessageDlg.WaitForScreenToLoad();

            Reports.TestStep = "Verify ‘SEC SDN Not Cleared' is not displaying as part of the Attach Message Document Name list";
            FastDriver.AttachMessageDlg.DocumentType.FASelectItem("Escrow: Misc");
            Support.AreEqual("False", FastDriver.AttachMessageDlg.DocumentName.FAGetText().Contains("SEC-SDN NOT Cleared").ToString(), "'SEC SDN Not Cleared' option is not present");

            Reports.TestStep = "Click Cancel";
            FastDriver.AttachMessageDlg.Cancel.FAClick();
        }

        public void UploadSDNClearedFile()
        {
            Playback.Wait(3000);
            Reports.TestStep = "Browse document and upload it (jpg).";
            if (!((Reports.DEPLOYDIR + "\\JpegFile.jpg").ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support.JpegFile.jpg", Reports.DEPLOYDIR + "\\JpegFile.jpg");
            }
            string FilePath = Reports.DEPLOYDIR + "\\JpegFile.jpg";
            FastDriver.UploadDocumentDlg.UploadFile(FilePath);
            FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
            FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Misc");
            FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("SEC-SDN Cleared");
            FastDriver.SaveDocumentDlg.SDNhitNameList.FASelectItem("Osama Bin Laden");

            Reports.TestStep = "Click OK";
            FastDriver.SaveDocumentDlg.Ok.FAClick();
            Playback.Wait(2000);
        }

        private void ValidateOnWorkQUpload(string filenum)
        {
            Reports.TestStep = "Click on WorkQ";
            FastDriver.TopFrame.ClickWorkQTab();
            Support.CloseAllProcessStartingWith("AcroRd");
            if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
            {
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
            }
            FastDriver.WebDriver.HandleDialogMessage();
            Playback.Wait(2000);
            FastDriver.WorkQueueTop.WaitForScreenToLoad();

            Reports.TestStep = "Click on WorkQ Upload and Upload a file";
            FastDriver.WorkQueueTop.Upload.FAClick();
            FastDriver.UploadFileToQueueDlg.WaitForScreenToLoad();
            Reports.TestStep = "Browse document and upload it (jpg).";
            if (!((Reports.DEPLOYDIR + "\\JpegFile.jpg").ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support.JpegFile.jpg", Reports.DEPLOYDIR + "\\JpegFile.jpg");
            }
            string FilePath = Reports.DEPLOYDIR + "\\JpegFile.jpg";
            FastDriver.UploadFileToQueueDlg.imageFilePath.FASetText(FilePath);
            FastDriver.UploadFileToQueueDlg.Upload.FAClick();
            FastDriver.TopFrame.ClickWorkNTab();
            if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
            {
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
            }
            FastDriver.WebDriver.HandleDialogMessage();
            Playback.Wait(2000);
            FastDriver.TopFrame.ClickWorkQTab();
            Support.CloseAllProcessStartingWith("AcroRd");
            if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
            {
                FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
            }
            FastDriver.WebDriver.HandleDialogMessage();
            Playback.Wait(2000);
            FastDriver.WorkQueueTop.WaitForScreenToLoad();

            Reports.TestStep = "Click on WorkQ Attach";
            FastDriver.WorkQueueTop.Attach.FAClick();
            FastDriver.AttachMessageDlg.WaitForScreenToLoad();

            Reports.TestStep = "Insert File number";
            FastDriver.AttachMessageDlg.FileNo.FASetText(filenum);

            Reports.TestStep = "Select Document Type";
            FastDriver.AttachMessageDlg.DocumentType.FASelectItem("Escrow: Misc");

            Reports.TestStep = "Select Document name =  SEC SDN Cleared";
            FastDriver.AttachMessageDlg.DocumentName.FASelectItem("SEC-SDN Cleared");

            Reports.TestStep = "Verify SDN Search Hit Name List option is displayed";
            Support.AreEqual(true, FastDriver.AttachMessageDlg.SDNSearchHitLabel.Exists(), "SDN Search Hit Label is displayed");

            Reports.TestStep = "Select SDN Search Hit Name = Osama Bin Laden";
            FastDriver.AttachMessageDlg.SDNSearchHitName.FASelectItem("Osama Bin Laden");

            Reports.TestStep = "Click Done";
            FastDriver.AttachMessageDlg.Done.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();

            Reports.TestStep = "Click on WorkN";
            FastDriver.TopFrame.ClickWorkNTab();
        }

        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
