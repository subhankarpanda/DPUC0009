﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;
using System.Collections.Generic;
using FASTSelenium.PageObjects;

namespace FileManagement
{
    /// <summary>
    /// Summary description for FMUC0068 Split Fees
    /// </summary>
    [CodedUITest]

    public class FMUC0068 : FASTHelpers
    {
        #region BAT
        [TestMethod]
        public void FMUC0068_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Create a Split Fee Disbursement.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                #endregion

                #region IIS Login
                FAST_Login_IIS();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Navigate back to fee entry page and verify split fee exists.
                Reports.TestStep = "Navigate back to fee entry page and verify split fee exists and validate the value.";
                FastDriver.FileFees.Open();
                Support.AreEqual(splitAmount, FastDriver.FileFees.SplitFeeAmt.FAGetText().Replace("$", string.Empty), "Split fees amount at file fee page.");
                #endregion

                #region Validate that pending check is available for split fee payee.
                Reports.TestStep = "Navigate back to Active Disbursement page and verify split fee exists and validate the value.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual(splitAmount, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 7, TableAction.GetText).Message.Trim(), "Split Amount at Active Disbursement page.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_BAT0001 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_00: Edit a Split Fee Percentage.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee after clicking on the new button.
                string newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                #endregion

                #region Split the first fee between two payees and validate the amount is splitted correctly.
                Reports.TestStep = "Click on the scissors sign of first fee and split the fees between the two payees.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate back to the SplitFee/Assign state page and update the split percentage.
                Reports.TestStep = "Navigate to the split fee disbursment page.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "20.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Storing the values for future verification.
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                string totalCharegFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 3, TableAction.GetText).Message.Trim();
                string splitPerFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 4, TableAction.GetText).Message.Trim();
                string splitDollrFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.GetText).Message.Trim();
                string splitRetDolFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 6, TableAction.GetText).Message.Trim();
                #endregion

                #region Change the split percentage for more than 100% and validate the message.
                Reports.TestStep = "Change the split percentage for more than 100% and validate the message";
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 4, TableAction.SetText, "111" + FAKeys.Tab);
                string msgContent = FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                Support.AreEqual("Total of split percentages cannot be greater than 100%.", msgContent.Trim(), "Error Message for entering the split% more than 100%.");
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                #endregion

                #region Validate the data is set to previous value after enter split % more than 100%.
                Reports.TestStep = "Validate the data is set to previous value after enter split % more than 100%.";
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);

                Support.AreEqual(totalCharegFee1, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 3, TableAction.GetText).Message.Trim(), "Total Charge for Fee1");
                Support.AreEqual(splitPerFee1, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 4, TableAction.GetText).Message.Trim(), "Split% for Fee1");
                Support.AreEqual(splitDollrFee1, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.GetText).Message.Trim(), "Split$ for Fee1");
                Support.AreEqual(splitRetDolFee1, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 6, TableAction.GetText).Message.Trim(), "Ret. $ for Fee1");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_BAT0002 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF2_00: Edit a Split Fee $ Amount.";
                #region DataSetup
                string acttotalFeeAmount = string.Empty;
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee after clicking on the new button.
                string newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                #endregion

                #region Split the first fee between two payees and validate the amount is splitted correctly.
                Reports.TestStep = "Click on the scissors sign of first fee and split the fees between the two payees.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitAmnt: "3.33");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate back to the SplitFee/Assign state page and update the split amount.
                Reports.TestStep = "Navigate to the split fee disbursment page and update the split amount for different value but less than the total fee amount.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitAmnt: "6.66");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Storing the values for future verification.
                Reports.TestStep = "Storing the values for future verification.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                string totalCharegFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 3, TableAction.GetText).Message.Trim();
                string splitDollrFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.GetText).Message.Trim();
                string splitRetDolFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 6, TableAction.GetText).Message.Trim();
                #endregion

                #region Enter the Split amount more than the total fee amount.
                Reports.TestStep = "Enter split $ more than fee amount.";
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.SetText, "111" + FAKeys.Tab);
                string msgContent = FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                Support.AreEqual("Total of split dollar amounts cannot be greater than the total fee amount.", msgContent.Trim(), "Error message on entering the split$ amount more than total fee amount.");
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 2, TableAction.Click);

                Reports.TestStep = "Verify the data is set to previous value after enter split $ more than fee amount.";
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);

                Support.AreEqual(totalCharegFee1, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 3, TableAction.GetText).Message.Trim(), "Total Charge for Fee1");
                Support.AreEqual(splitDollrFee1, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.GetText).Message.Trim(), "Split$ for Fee1");
                Support.AreEqual(splitRetDolFee1, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 6, TableAction.GetText).Message.Trim(), "Ret. $ for Fee1");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_BAT0003 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF3_00: Remove a Split Fee. //nAF4_00: Remove a Split Fee Payee.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Remove the second Splitting fee and validate the values.
                Reports.TestStep = "Enter the zero value or # for the split $ for the second fee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitAmnt: "#");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.SplitFeeDisbursements.Open();
                #endregion

                #region Validate the second splitting row is removed from the split fee summary page and validate the calculation.
                int rowCount = FastDriver.SplitFeeDisbursements.SplitFeesSummary.GetRowCount() / 2;
                Support.AreEqual("3", rowCount.ToString(), "Row count at split fee summary table.");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion

                #region Remove the first Splitting fee and validate the values.
                Reports.TestStep = "Enter the zero value or # for the split % for the first fee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "#");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.SplitFeeDisbursements.Open();
                #endregion

                #region Validate the added payee name is removed from the payee summary page and values reset to initials.
                string tableContent = FastDriver.SplitFeeDisbursements.PayeesSummary.FAGetText();
                bool result = !tableContent.Contains(newPayee);
                Reports.StatusUpdate(controlDescription: "Validation result for added payee is removed from the Payee summary page: " + (result).ToString(), status: result, expectedValue: "True", actualValue: (result).ToString());
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_BAT0004 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Remove a Split Fee Payee.";
                Reports.StatusUpdate("This test method has been clubbed with BAT004.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_BAT0005 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF5_00: Create an Additional Check to a Split Fee Payee.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee after clicking on the new button.
                string newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                #endregion

                #region Split the first fee between two payees and validate the amount is splitted correctly.
                Reports.TestStep = "Click on the scissors sign of first fee and split the fees between the two payees.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "12.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Navigate back to the split fee disbursement page and validate the splitted amount for the office and get the split amount.
                Reports.TestStep = "Navigate back to the Split Fee disbursement page and validate the total amount for the office.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                string splitAmount = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.GetText).Message.Trim();
                #endregion

                #region Navigate to the Active disbursement summary page and issue the check with the  split amount.
                Reports.TestStep = "Navigate to the active disbursement summary page and select the row with the split amount.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", splitAmount, "Amount", TableAction.Click);

                Reports.TestStep = "Issue the check.";
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint();
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the status of the check is issued in active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", splitAmount, "Status", TableAction.GetText).Message.Trim(), "Status of the Check with the split Amount.");

                #endregion

                #region Validate the check issued sign for the new payee is availabe at payee summary page of the split fee disbursement page.
                Reports.TestStep = "Validate the check issued sign for the new payee is availabe at payee summary page of the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, newPayee, 7, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").Exists(), "Verify Check issued image exists.");
                #endregion

                #region Split the Second fee between two payees and validate the amount is splitted correctly.
                Reports.TestStep = "Click on the scissor sign of Second fee and split the fees between the two payees.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitAmnt: "4.44");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Navigate back to the Split Fee Disbursement page and validate the total amount for office after split.
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion

                #region Navigate to the ACtive Disbursement summary page and validate the check is in the pending status for the new split amount.
                Reports.TestStep = "Navigate to the ACtive Disbursement summary page and validate the check is in the pending status for the new split amount.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.44", "Status", TableAction.GetText).Message.Trim(), "Check Status");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_BAT0006 failed because: " + ex.Message);
            }
        }
        #endregion

        #region REG

        [TestMethod]
        public void FMUC0068_REG0001()
        {
            try
            {
                Reports.TestDescription = "BR_FM3155_FM3158_FM3159_FM5267_FM5272_FM5266_ER7";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Navigate to fee entry page and verify split fee exists.
                Reports.TestStep = "Navigate back to fee entry page and verify split fee exists and validate the value.";
                FastDriver.FileFees.Open();
                Support.AreEqual(splitAmount, FastDriver.FileFees.SplitFeeAmt.FAGetText().Replace("$", string.Empty), "Split fees amount at file fee page.");
                Support.AreEqual(true, FastDriver.FileFees.SplitFees.IsDisplayed(), "Verify that Split Fee exists at File Fee page.");
                Support.AreEqual(true, FastDriver.FileFees.TotalFees.IsDisplayed(), "Verify that Total Fee exists at File Fee page.");
                #endregion

                #region Validate that pending check is available for split fee payee.
                Reports.TestStep = "Navigate back to Active Disbursement page and verify split fee exists and validate the value.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 7, TableAction.Click);

                Reports.TestStep = "Issue the check.";
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint();
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the status of the check is issued in active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", splitAmount, "Status", TableAction.GetText).Message.Trim(), "Status of the Check with the split Amount.");
                #endregion

                #region Navigate to SplitFeeDisbursement page and Select the new payee and verify the payee reference in payee details page.
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Reports.TestStep = "Verify the  payee reference field for the selected payee.";
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.PayeeDetails.PayeeReference.IsEnabled(), "Verify that Payee reference test field is not enabled when check is issued.");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Try to change the payee name for the issue split fee.
                Reports.TestStep = "Change the payee for the fee we issue check to other than the issued one.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 2, TableAction.SelectItemByIndex, "0");
                string msgContent = FastDriver.WebDriver.HandleDialogMessage(timeout: 20);
                Support.AreEqual("A check has been issued for this Payee.  The Payee name cannot be changed.", msgContent.Trim(), "Verify the error message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0001 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0002()
        {
            try
            {
                Reports.TestDescription = "BR_FM6284_FM13690_BR FM6284: Allow Only One Split Entity per GAB ID.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                string newPayee = null;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add one fee, Navigate to the Split fee page and add one payee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the split fee page and add one payee";
                FastDriver.SplitFeeDisbursements.Open();
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                #endregion

                #region Select the newly added payee and click on new button to add a payee of same GAB id.
                Reports.TestStep = "Select the newly added payee and click on new button.";
                FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, newPayee, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.New.FAClick();

                Reports.TestStep = "Add the a payee with same role to the payee list and verify the error message.";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FABResultsTable.PerformTableAction(5, "New Lender", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                string msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please select only one instance of the same GAB/FAB entry at a time.", msgContent.Trim(), "Verify the error message.");
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitAmnt: "12.00");
                #endregion

                #region Select the newly added payee and click on new button to add a payee with different role.
                Reports.TestStep = "Select the newly added payee and click on new button.";
                FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, newPayee, 1, TableAction.Click);

                Reports.TestStep = "Add the a payee with Different role to the payee list.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "Buyer");
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitAmnt: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0002 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_FM5450: Populate GAB Contacts to Attention.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string attention = "L247";
                string otherAvlblAtttention = null;
                #endregion

                #region ADM settings
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and select the GAB 247 at  Address Book.
                Reports.TestStep = "Move to the region level and navigate to the address book search page.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);
                FastDriver.AddressBookSearch.Open();
                Reports.TestStep = "Search for the GAB 247 and click on the edit button";
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");
                #endregion

                #region Set the primary contact as L247 for the GAB 247.
                Reports.TestStep = "Set the primary contact as L247 for the GAB 247.";
                FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItem(attention);
                otherAvlblAtttention = FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FAGetAllTextFromSelect();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee after clicking on the new button.
                string newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                #endregion

                #region Split the first fee between two payees and validate the amount is splitted correctly.
                Reports.TestStep = "Click on the scissors sign of first fee and split the fees between the two payees.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Navigate back to split fee disbursement page and validate the office total amount.
                Reports.TestStep = "Navigate back to split fee disbursement page and validate the office total amount.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion

                #region Select the newly added payee, click on the payee details and validate the attention value for the GAB.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Reports.TestStep = "Validate that attention name is primary contact and other options are available at drop down.";
                Support.AreEqual(attention, FastDriver.PayeeDetails.Attention.FAGetSelectedItem(), "Validation result for the attention name is the same as primary contact availabe at GAB detail(ADM) of the selected payee. ");
                Support.AreEqual(otherAvlblAtttention, FastDriver.PayeeDetails.Attention.FAGetAllTextFromSelect(), "Validation result for the other options availabe in the attention drop down.");
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0003 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_FM5450_001: Set Primary contact blank(ADM).\\nBR_FM5450_002: Verify Attention is Blank by default in file side and contact is available in dropdown.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string attention = "";
                string otherAvlblAtttention = null;
                #endregion

                #region ADM settings
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and select the GAB 247 at  Address Book.
                Reports.TestStep = "Move to the region level and navigate to the address book search page.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for the GAB 247 and click on the edit button";
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");
                #endregion

                #region Set the primary contact as blank for the GAB 247.
                Reports.TestStep = "Set the primary contact as blank for the GAB 247.";
                FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItemByIndex(0);
                attention = FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FAGetSelectedItem();
                otherAvlblAtttention = FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FAGetAllTextFromSelect();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region IIS Login

                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee after clicking on the new button.
                string newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                #endregion

                #region Split the first fee between two payees and validate the amount is splitted correctly.
                Reports.TestStep = "Click on the scissors sign of first fee and split the fees between the two payees.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Navigate back to split fee disbursement page and validate the office total amount.
                Reports.TestStep = "Navigate back to split fee disbursement page and validate the office total amount.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion

                #region Select the newly added payee, click on the payee details and validate the attention value for the GAB.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Reports.TestStep = "Validate that attention name is blank and other options are available at drop down.";
                Support.AreEqual(attention, FastDriver.PayeeDetails.Attention.FAGetSelectedItem(), "Validation result for the attention name is the same as availabe at GAB detail(ADM) of the selected payee. In this case it is blank. ");
                Support.AreEqual(otherAvlblAtttention, FastDriver.PayeeDetails.Attention.FAGetAllTextFromSelect(), "Validation result for the other options availabe in the attention drop down.");
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0004 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0005()
        {
            try
            {
                Reports.TestDescription = "BR_FM5450_002: Verify Attention is Blank by default in file side and contact is available in dropdown.";
                Reports.StatusUpdate("This test method has been clubbed with the REG0004. Please verify the result of REG0004.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0005 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR_FM5450_003: Set Primary contact for BusOrg(ADM).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0003, Please verify the results of REG0003.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0006 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0007()
        {
            try
            {
                Reports.TestDescription = "BR_FM6283_001: Use Combination of Contact and Business Org. Contact Info(ADM) and validation at file side.";

                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                FASTSelenium.DataObjects.ADM.PhoneParameters phoneData = new FASTSelenium.DataObjects.ADM.PhoneParameters
                {
                    BusinessPhoneNumber = "(342)348-9134",
                    BusinessPhoneExtn = "777",
                    Email = "testproactive@proactive.com"
                };
                Dictionary<string, string> contact = new Dictionary<string, string>();

                #endregion

                #region ADM settings
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and select the GAB 247 at  Address Book.
                Reports.TestStep = "Move to the region level and navigate to the address book search page.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search for the GAB 247 and click on the edit button";
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");
                #endregion

                #region Add one new contact to the GAB code.
                Reports.TestStep = "Click on the view/add contacts button.";
                FastDriver.BusinessPartyOrganizationSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                Reports.TestStep = "Create a new contact for the GAB having only the email and Business phone and extention details.";
                FastDriver.BusPartyContactsList.ClickNew();
                contact = FastDriver.BusPartyContactSetup.CreateNewContactForBusOrg(PhoneParams: phoneData);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update the contact details for GAB247. It should not have the email and Business phone and extention details.
                Reports.TestStep = "Update the contact details for GAB 247. It should not have the email and Business phone and extention details.";
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.ClickVersion();

                Reports.TestStep = "Remove the Business Phone ,Email and Extension details for the GAB.";
                FastDriver.BusinessPartyOrganizationSetUp.EmailType.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.PhonesRemove.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneType.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.PhonesRemove.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Update the remaining details.";
                FastDriver.BusinessPartyOrganizationSetUp.BusinessFaxType.FASelectItem("Business Fax");
                FastDriver.BusinessPartyOrganizationSetUp.BusinessFaxTypeNumber.FASetText("(616)451-2290");
                FastDriver.BusinessPartyOrganizationSetUp.PagerType.FASelectItem("Pager");
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.PagerNumber.FASetText("(616)451-2290");
                FastDriver.BusinessPartyOrganizationSetUp.CellularType.FASelectItem("Cellular");
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.CellularNumber.FASetText("(616)451-2290");

                Reports.TestStep = "Select the newly created contact as primary contact of the GAB.";
                FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItem(contact["LastName"] + ", " + contact["FirstName"]);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move again to the GAB 247 detail page and validate changes are done.
                Reports.TestStep = "Open the GAB 247 details.";
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");

                Reports.TestStep = "Verify that changes made are available for GAB.";
                Support.AreEqual(contact["LastName"] + ", " + contact["FirstName"], FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FAGetSelectedItem(), "Verifying Primary contact detail is updated.");
                Support.AreEqual("", FastDriver.BusinessPartyOrganizationSetUp.EmailNumber.FAGetValue(), "Verifying email address is not available.");
                Support.AreEqual("", FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneTypeNumber.FAGetValue(), "Verifying business phone number is not available.");
                Support.AreEqual("", FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneTypeExtension.FAGetValue(), "Verifying business phone number is not available.");
                FastDriver.BottomFrame.Done();
                #endregion

                #endregion

                #region IIS Login

                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee after clicking on the new button.
                string newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                #endregion

                #region Split the first fee between two payees and validate the amount is splitted correctly.
                Reports.TestStep = "Click on the scissors sign of first fee and split the fees between the two payees.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Navigate back to split fee disbursement page and validate the office total amount.
                Reports.TestStep = "Navigate back to split fee disbursement page and validate the office total amount.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion

                #region Select the newly added payee, click on the payee details.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                #endregion

                #region Select the newly added contact as attention and validate the contact details is the combination of the Business org contact detail and attention details.
                Reports.TestStep = "Validate the contact detail of business organisation.It should be combination of the details from the contact and business organisation contact. In this case business phone number, extention and mailid from Contact.";
                Support.AreEqual(phoneData.BusinessPhoneNumber, FastDriver.PayeeDetails.BusPhone.FAGetValue().Trim(), "Validation for field value of the Business Phone.");
                Support.AreEqual(phoneData.BusinessPhoneExtn, FastDriver.PayeeDetails.ExtnPhone.FAGetValue().Trim(), "Validation for field value of the Business Phone Extention.");
                Support.AreEqual("(616)451-2290", FastDriver.PayeeDetails.BusFax.FAGetValue().Trim(), "Validation for field value of the Business Fax.");
                Support.AreEqual("(616)451-2290", FastDriver.PayeeDetails.CellPhone.FAGetValue().Trim(), "Validation for field value of the Cell Phone.");
                Support.AreEqual("(616)451-2290", FastDriver.PayeeDetails.Pager.FAGetValue().Trim(), "Validation for field value of the Page.");
                Support.AreEqual(phoneData.Email, FastDriver.PayeeDetails.EmailAddress.FAGetValue().Trim(), "Validation for field value of the Email Address.");
                #endregion

                /*
                #region ADM settings for reverting back the changes.
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and select the GAB 247 at  Address Book.
                Reports.TestStep = "Move to the region level and navigate to the address book search page.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search for the GAB 247 and click on the edit button";
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");
                #endregion

                #region Update the contact details for GAB247. It should not have the email and Business phone and extention details.
                Reports.TestStep = "Update the contact details for GAB 247. It should not have the email and Business phone and extention details.";
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.ClickVersion();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Add the Business Phone ,Email and Extension details for the GAB.";
                FastDriver.BusinessPartyOrganizationSetUp.EmailType.FASelectItem("Email");
                FastDriver.BusinessPartyOrganizationSetUp.EmailNumber.FASetText("FirstAm@first.com");
                FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneType.FASelectItem("Business Phone");
                FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneTypeNumber.FASetText("(616)451-2290");
                FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneTypeExtension.FASetText("672");

                Reports.TestStep = "Select primary contact as blank.";
                FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move again to the GAB 247 detail page and validate changes are done.
                Reports.TestStep = "Open the GAB 247 details.";
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");

                Reports.TestStep = "Verify that changes made are available for GAB.";
                Support.AreEqual("", FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FAGetSelectedItem(), "Verifying Primary contact detail is updated.");
                Support.AreEqual("FirstAm@first.com", FastDriver.BusinessPartyOrganizationSetUp.EmailNumber.FAGetValue(), "Verifying email address is available.");
                Support.AreEqual("(616)451-2290", FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneTypeNumber.FAGetValue(), "Verifying business phone number available.");
                Support.AreEqual("672", FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneTypeExtension.FAGetValue(), "Verifying business phone extention is available.");
                FastDriver.BottomFrame.Done();
                #endregion

                #endregion */

            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0007 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0008()
        {
            try
            {
                Reports.TestDescription = "BR_FM6283_002: Use Combination of Contact and Business Org. Contact Info(File side).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG03, Please verify the results of REG0008.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0008 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0009()
        {
            try
            {
                Reports.TestDescription = "BR_FM3163_001_FM6134_FM6131: Edit Payee Attention.";
                #region DataSetup
                string newPayee = null;
                string splitAmount = null;
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;

                FASTSelenium.DataObjects.ADM.PhoneParameters phoneData = new FASTSelenium.DataObjects.ADM.PhoneParameters
                {
                    BusinessPhoneNumber = "(342)348-9134",
                    BusinessPhoneExtn = "111",
                    Email = "testchanged@proactive.com",
                    CellularNumber = "(342)348-9135",
                    PagerNumber = "(342)348-9136",
                    BusinessFaxNumber = "(342)348-9137",
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Select the new payee in payee details page and Check the editname checkbox and validate.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Reports.TestStep = "Check the EditName checkbox and Edit the Name.";
                FastDriver.PayeeDetails.EditName.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.Name.FASetText("ATTENTION1");

                Reports.TestStep = "Validate that the Attention is disabled, Name field is enabled and value is blank for attention after clicking on the Edit Name checkbox.";
                Support.AreEqual(false, FastDriver.PayeeDetails.Attention.IsEnabled(), "Validation: Attention is disabled.");
                Support.AreEqual(true, FastDriver.PayeeDetails.Name.IsEnabled(), "Validation :Name field is enabled.");
                Support.AreEqual(string.Empty, FastDriver.PayeeDetails.Attention.FAGetSelectedItem(), "Validation: Attention is blank.");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Select the New payee, click on the Payee details button and validate that name field is updated.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Support.AreEqual("ATTENTION1", FastDriver.PayeeDetails.Name.FAGetValue(), "Validation :Name field is updated with new name.");
                Support.AreEqual(true, FastDriver.PayeeDetails.Name.IsEnabled(), "Validation :Name field is enabled.");
                #endregion

                #region Uncheck the EditName check box and validate the changes.
                FastDriver.PayeeDetails.EditName.FASetCheckbox(false);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.PayeeDetails.Name.FAGetValue(), "Validation :Name field blank.");
                Support.AreEqual(false, FastDriver.PayeeDetails.Name.IsEnabled(), "Validation :Name field is disabled.");
                Support.AreEqual(true, FastDriver.PayeeDetails.Attention.IsEnabled(), "Validation: Attention is enabled.");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Select the New payee, Click on the Payee details button and validate that businees party contact details fields.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Validate that user can edit the contact details of business party GAB contact.";
                Support.AreEqual(true, FastDriver.PayeeDetails.Edit.IsEnabled(), "Validation :Edit Checkbox at contact details is enabled.");
                FastDriver.PayeeDetails.ValidateBusinessPartyContactDetailsEnabled(expectedResult: false);

                Reports.TestStep = "Check the Edit box and validate the contact details fields.";
                FastDriver.PayeeDetails.Edit.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.PayeeDetails.Edit.IsEnabled(), "Validation :Edit Checkbox at contact details is enabled.");
                FastDriver.PayeeDetails.ValidateBusinessPartyContactDetailsEnabled(expectedResult: true);

                Reports.TestStep = "Update the contact details.";
                FastDriver.PayeeDetails.BusPhone.FASetText(phoneData.BusinessPhoneNumber);
                FastDriver.PayeeDetails.ExtnPhone.FASetText(phoneData.BusinessPhoneExtn);
                FastDriver.PayeeDetails.BusFax.FASetText(phoneData.BusinessFaxNumber);
                FastDriver.PayeeDetails.CellPhone.FASetText(phoneData.CellularNumber);
                FastDriver.PayeeDetails.Pager.FASetText(phoneData.PagerNumber);
                FastDriver.PayeeDetails.EmailAddress.FASetText(phoneData.Email);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Select the New payee, Click on the Payee details button and validate the changes are available.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Reports.TestStep = "Validate the changes are available.";
                Support.AreEqual(phoneData.BusinessPhoneNumber, FastDriver.PayeeDetails.BusPhone.FAGetValue(), "Validation :Business Phone field value.");
                Support.AreEqual(phoneData.BusinessPhoneExtn, FastDriver.PayeeDetails.ExtnPhone.FAGetValue(), "Validation : Bus. Phone Ext value.");
                Support.AreEqual(phoneData.BusinessFaxNumber, FastDriver.PayeeDetails.BusFax.FAGetValue(), "Validation :Business Faxvalue.");
                Support.AreEqual(phoneData.CellularNumber, FastDriver.PayeeDetails.CellPhone.FAGetValue(), "Validation :Cell Phone value.");
                Support.AreEqual(phoneData.PagerNumber, FastDriver.PayeeDetails.Pager.FAGetValue(), "Validation :Pager at contact value.");
                Support.AreEqual(phoneData.Email, FastDriver.PayeeDetails.EmailAddress.FAGetValue(), "Validation :Email at contact value.");
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0009 failed because: " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0068_REG0010()
        {
            try
            {
                Reports.TestDescription = "BR_FM3163_002_FM5272_FM5271: Edit Payee Attention when disbursement is issued to payee.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add one scanned document at DocRep.
                FastDriver.DocumentRepository.ScanImageDoc(docType: "Escrow: Payoff Demand/Bills", docName: "PO-Invoice", addtlInfo: "AFFIX INV");
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Navigate to fee entry page and verify split fee exists.
                Reports.TestStep = "Navigate back to fee entry page and verify split fee exists and validate the value.";
                FastDriver.FileFees.Open();
                Support.AreEqual(splitAmount, FastDriver.FileFees.SplitFeeAmt.FAGetText().Replace("$", string.Empty), "Split fees amount at file fee page.");
                #endregion

                #region Navigate to active disbursement summary page and validate a pending check is created for split fee.
                Reports.TestStep = "Navigate back to Active Disbursement page and verify split fee exists and validate the value.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.GetText).Message.Trim(), "Split Amount at Active Disbursement page.");
                #endregion

                #region Issue the pending check for split fee.
                Reports.TestStep = "Click on the Print Button to disburse the split amount to Payee.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint();
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the status of the check is issued in active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.GetText).Message.Trim(), "Status of the Check with the split Amount.");
                #endregion

                #region Navigate to the splitfeedisbursement page and validate Attention, EditName checkbox and Name fields for the added payee.
                Reports.TestStep = "Navigate to the Split Fee Disbursement page and select the added payee.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Reports.TestStep = "Validate that the fields Attention, EditName checkbox and Name are disabled.";
                Support.AreEqual(false, FastDriver.PayeeDetails.EditName.IsEnabled(), "Validation :Edit Name check box is disabled..");
                Support.AreEqual(false, FastDriver.PayeeDetails.Name.IsEnabled(), "Validation :Name field is disabled.");
                Support.AreEqual(false, FastDriver.PayeeDetails.Attention.IsEnabled(), "Validation: Attention is disabled.");
                #endregion

                Reports.TestStep = " BR FM5271 - Issue the split fee as wire";
                #region Navigate to the ActiveDisbursement summary page and void the issued split fee check.
                Reports.TestStep = "Navigate to the ActiveDisbursement summary page and void the issued split fee check.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.SetVoidReason("Voiding the fee to convert into wire.");
                FastDriver.VoidDlg.ClickOk();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "To verify the voided disbursement is changed to Pend.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.GetText).Message.Trim(), "Split Amount at Active Disbursement page.");

                #endregion

                #region Convert the check in to wire.
                Reports.TestStep = "Convert into the wire.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on the add button to add the wire instruction";
                FastDriver.EditDisbursement.ConvertToWire();

                Reports.TestStep = "Navigate to the active disbursement summary page and validate the check has been converted into wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Wire", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 3, TableAction.GetText).Message, "Validation: Check is converted into wire.");
                #endregion

                #region Disburse the split fee as wire.
                Reports.TestStep = "Disburse the split fee as wire.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                FastDriver.ChangeFileStatusDlg.ConfirmStatus();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the status of the check is issued in active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.GetText).Message.Trim(), "Status of the Check with the split Amount.");
                #endregion

                #region Navigate back to the split fee disbursement page to validate the check generation image.
                Reports.TestStep = "Navigate back to the spit fee disbursement page to validate the check generation image.";
                FastDriver.SplitFeeDisbursements.Open();
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, newPayee, 7, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").Exists(), "Verify Check issued image exists.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0010 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0011()
        {
            try
            {
                Reports.TestDescription = "BR_FM6141_FM6131: Prevent Edit Contact Information for an adhoc GAB.";
                #region DataSetup
                string newPayee = null;
                string splitAmount = null;
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                Reports.TestStep = "BR FM6141- Create an adhoc GAB";
                #region Create and Add a new adhoc payee.
                Reports.TestStep = "Click on the New button to add new payee.";
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();

                Reports.TestStep = "Select the Organization radio button and find the gab 247.";
                FastDriver.PayeeSearchDlg.Organization.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.GABIDcode.FASetText("247" + FAKeys.Tab);
                FastDriver.PayeeSearchDlg.Find.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();

                Reports.TestStep = "Click on the New GAB entry button to create adhoc payee.";
                FastDriver.PayeeSearchDlg.NewGABEntry.FAClick();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.CreateGAB(_entityType: "Attorney", _name1: "Adhoc", _name2: "AdhocLastName", _address1: "FM Street", _city: "Lincoln", _zipCode: "92707", _addressState: "CA");
                #endregion

                #region BR FM6141 - Verify the Prevent Edit Contact Information for a adhoc GAB is disabled.
                Reports.TestStep = "Validate that the new adhoc payee is added to the payeesummary page.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                Support.AreEqual("0.00", FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, "Adhoc", 6, TableAction.GetText).Message, "Validation: New adhoc payee is added");

                Reports.TestStep = "Perform the Split with new adhoc payee as well";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: "Adhoc", splitAmnt: "5.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: "Adhoc");

                Reports.TestStep = "Navigate back to the page and validate the total amount for the office.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);

                Reports.TestStep = "Select the adhoc payee and click on the payee details.";
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: "Adhoc");

                Reports.TestStep = "Validate that edit name field is unchecked and contact details of business pary contact are also disabled.";
                Support.AreEqual(false, FastDriver.PayeeDetails.Name.IsEnabled(), "Validation :Name field  is disabled.");
                FastDriver.PayeeDetails.ValidateFieldsatContactDtlsEnabled(expectedResult: false);

                Reports.TestStep = "Click on the Edit Name check box.";
                FastDriver.PayeeDetails.EditName.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.ContactExpandbtn.FAClick();
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.ValidateFieldsatContactDtlsEnabled(expectedResult: false);

                Reports.TestStep = "Validate the Name and Attention fields. Name field should be enabled and attention field should disabled.";
                Support.AreEqual(true, FastDriver.PayeeDetails.Name.IsEnabled(), "Validation :Name field  is enabled.");
                Support.AreEqual(false, FastDriver.PayeeDetails.Attention.IsEnabled(), "Validation :Attention field  is disabled.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0011 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0012()
        {
            try
            {
                Reports.TestDescription = "BR_FM6198: Re-Populate Primary Contact Info when Edit Name Deselected.";
                #region DataSetup
                string newPayee = null;
                string splitAmount = null;
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string primaryContact = null;
                string updtPayeeName = "payeenameupdated";

                FASTSelenium.DataObjects.ADM.PhoneParameters changedDetail = new FASTSelenium.DataObjects.ADM.PhoneParameters
                {
                    BusinessPhoneNumber = "(342)348-9134",
                    BusinessPhoneExtn = "111",
                    Email = "testchanged@proactive.com",
                    CellularNumber = "(342)348-9135",
                    PagerNumber = "(342)348-9136",
                    BusinessFaxNumber = "(342)348-9137",
                };
                #endregion

                #region ADM settings
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and select the GAB 247 at  Address Book.
                Reports.TestStep = "Move to the region level and navigate to the address book search page.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Open address search book and Search for the GAB 247 and click on the edit button";
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");
                #endregion

                #region Set the primary contact as L247 for the GAB 247.
                Reports.TestStep = "Set the primary contact as blank for the GAB 247.";
                FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItem("L247");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Reopen the GAB and verify primary contact has been set.";
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");
                Support.AreEqual("L247", FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FAGetSelectedItem(), "Validating primary contact has been changed.");
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File.
                CreateBasicFile();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Select the Added Payee and Open the Payee details Page.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                #endregion

                #region Get the Primary Contact details and store it for future reference.
                primaryContact = FastDriver.PayeeDetails.Attention.FAGetSelectedItem();
                FASTSelenium.DataObjects.ADM.PhoneParameters beforeChange = FastDriver.PayeeDetails.GetAttentionContctDtl();
                #endregion

                #region Select the EditName checkbox and update the Name and contact details at contact section.
                Reports.TestStep = "Make the edit name checkbox checked and udpate the name and attention contact details.";
                FastDriver.PayeeDetails.EditName.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.Name.FASetText(updtPayeeName + FAKeys.Tab);
                FastDriver.PayeeDetails.UpdateAttentionContctDtl(changedDetail);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate back to the Payee Details page and Validate changes are done.
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Reports.TestStep = "Validate that changes are done.";
                Support.AreEqual("", FastDriver.PayeeDetails.Attention.FAGetSelectedItem(), "Primary Contact should be blank.");
                Support.AreEqual(updtPayeeName, FastDriver.PayeeDetails.Name.FAGetValue(), "Value of Name field should be updated one.");

                Reports.TestStep = "Verify Contact details are updated one.";
                FastDriver.PayeeDetails.VerifyContactDetail(exptdDetail: changedDetail, actDetail: FastDriver.PayeeDetails.GetAttentionContctDtl());

                #endregion

                #region Uncheck the edit name check box and validate the attention contact details field.
                Reports.TestStep = "Uncheck the edit name check box.";
                FastDriver.PayeeDetails.EditName.FASetCheckbox(false);
                FastDriver.PayeeDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate that attention contact details are populated with the primary contact's contact details.";
                Support.AreEqual(primaryContact, FastDriver.PayeeDetails.Attention.FAGetSelectedItem(), "Validate that the attetion field value is reset to the primary contact.");

                Reports.TestStep = "Uncheck the edit checkbox of the attention details.";
                FastDriver.PayeeDetails.AttentionEdit.FASetCheckbox(false);
                FastDriver.PayeeDetails.WaitForScreenToLoad();

                Reports.TestStep = "Verify attention contact details is changed to the primary contact's contact details";
                FastDriver.PayeeDetails.VerifyContactDetail(exptdDetail: beforeChange, actDetail: FastDriver.PayeeDetails.GetAttentionContctDtl());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0012 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0013()
        {
            try
            {
                Reports.TestDescription = "BR_FM6189_001: Re-Populate Bus Org Contact Info when Edit Name Deselected(ADM).BR_FM6189_002_FD_07_FM6131:1).Re-Populate Bus Org Contact Info when Edit Name Deselected(File) 2).Validated edited contact details in File side did not get edited the contact details in ADM side.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string primaryContact = null;
                string newPayee = null;
                string splitAmount = null;
                string updtPayeeName = "payeenameupdated";

                FASTSelenium.DataObjects.ADM.PhoneParameters changedDetail = new FASTSelenium.DataObjects.ADM.PhoneParameters
                {
                    BusinessPhoneNumber = "(342)348-9134",
                    BusinessPhoneExtn = "111",
                    Email = "testchanged@proactive.com",
                    CellularNumber = "(342)348-9135",
                    PagerNumber = "(342)348-9136",
                    BusinessFaxNumber = "(342)348-9137",
                };
                #endregion

                #region ADM settings
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and select the GAB 247 at  Address Book.
                Reports.TestStep = "Move to the region level and navigate to the address book search page.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);
                FastDriver.AddressBookSearch.Open();
                Reports.TestStep = "Search for the GAB 247 and click on the edit button";
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");
                #endregion

                #region Set the primary contact as blank for the GAB 247.
                Reports.TestStep = "Set the primary contact as blank for the GAB 247.";
                FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FASelectItemByIndex(0);
                primaryContact = FastDriver.BusinessPartyOrganizationSetUp.PrimaryContact.FAGetSelectedItem();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Select the Added Payee and Open the Payee details Page.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                #endregion

                #region Get the contact details from the payee information section.
                FASTSelenium.DataObjects.ADM.PhoneParameters beforeChange = FastDriver.PayeeDetails.GetPayeeInformationContctDtl();
                #endregion

                #region Select the EditName checkbox and update the Name and contact details at contact section.
                Reports.TestStep = "Make the edit name checkbox checked and udpate the name and attention contact details.";
                FastDriver.PayeeDetails.EditName.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.Name.FASetText(updtPayeeName + FAKeys.Tab);
                FastDriver.PayeeDetails.UpdatePayeeInfoContctDtl(changedDetail);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate back to the Payee Details page and Validate changes are done.
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Validate that changes are done.";
                Support.AreEqual(primaryContact, FastDriver.PayeeDetails.Attention.FAGetSelectedItem(), "Primary Contact should be blank.");
                Support.AreEqual(updtPayeeName, FastDriver.PayeeDetails.Name.FAGetValue(), "Value of Name field should be updated one.");
                FastDriver.PayeeDetails.VerifyContactDetail(exptdDetail: changedDetail, actDetail: FastDriver.PayeeDetails.GetPayeeInformationContctDtl());
                #endregion

                #region Uncheck the edit name check box and validate the payee information contact details field.
                Reports.TestStep = "Uncheck the edit name check box.";
                FastDriver.PayeeDetails.EditName.FASetCheckbox(false);
                FastDriver.PayeeDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate that attention contact details are populated with the primary contact's contact details.";
                Support.AreEqual("", FastDriver.PayeeDetails.Attention.FAGetSelectedItem(), "Validate that the attetion field value is reset to the blank.");

                Reports.TestStep = "Uncheck the edit checkbox of the Payee Information Contact details.";
                FastDriver.PayeeDetails.Edit.FASetCheckbox(false);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.VerifyContactDetail(exptdDetail: beforeChange, actDetail: FastDriver.PayeeDetails.GetPayeeInformationContctDtl());
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0013 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0014()
        {
            try
            {
                Reports.TestDescription = "BR_FM6189_002_FD_07_FM6131:1).Re-Populate Bus Org Contact Info when Edit Name Deselected(File) 2).Validated edited contact details in File side did not get edited the contact details in ADM side.";
                Reports.StatusUpdate("This test method has been clubbed with the REG0013. Please verify the result of REG0013.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0014 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0014_A()
        {
            try
            {
                Reports.TestDescription = "BR_FM6229: Validate change/edit in GAB details in ADM will not update in existing payee in file side.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;

                FASTSelenium.DataObjects.ADM.PhoneParameters changedDetail = new FASTSelenium.DataObjects.ADM.PhoneParameters
                {
                    BusinessPhoneNumber = "(342)348-9134",
                    BusinessPhoneExtn = "111",
                    Email = "testchanged@proactive.com",
                    CellularNumber = "(342)348-9135",
                    PagerNumber = "(342)348-9136",
                    BusinessFaxNumber = "(342)348-9137",
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Select the Added Payee and Open the Payee details Page.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                #endregion

                #region Update the contact details displayed at the payee information section.
                FastDriver.PayeeDetails.UpdatePayeeInfoContctDtl(changedDetail);
                FastDriver.BottomFrame.Done();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                #endregion

                #region Again Select the Payee and validate that the changes are done at payee details page.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Support.AreEqual(true, FastDriver.PayeeDetails.Edit.IsSelected(), "Edit check box should be checked.");
                FastDriver.PayeeDetails.VerifyContactDetail(exptdDetail: changedDetail, actDetail: FastDriver.PayeeDetails.GetPayeeInformationContctDtl());
                #endregion

                #region Move to ADMIN side and update the GAB contact details.
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and select the GAB 247 at  Address Book.
                Reports.TestStep = "Move to the region level and navigate to the address book search page.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);
                FastDriver.AddressBookSearch.Open();
                Reports.TestStep = "Search for the GAB 247 and click on the edit button";
                FastDriver.AddressBookSearch.EditGAB(GAB: "247");
                #endregion

                #region Update the contact details of the GAB.
                FastDriver.BusinessPartyOrganizationSetUp.ClickVersion();
                FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneTypeNumber.FASetText("(432)843-4187");
                FastDriver.BusinessPartyOrganizationSetUp.BusinessPhoneTypeExtension.FASetText("675");
                FastDriver.BusinessPartyOrganizationSetUp.EmailNumber.FASetText("FirstAM@test.com");
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region Login to the File side and open the same file.
                IISLOGIN();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to the Split fee disbursement page and open the Payee detail for the same payee.
                Reports.TestStep = "Navigate to the Split fee disbursement page and open the Payee detail for the same payee.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                #endregion

                #region Verify that updated details are not reflecting for the payee information field as edit check box is still checked.
                FastDriver.PayeeDetails.VerifyContactDetail(exptdDetail: changedDetail, actDetail: FastDriver.PayeeDetails.GetPayeeInformationContctDtl());
                Support.AreEqual(true, FastDriver.PayeeDetails.Edit.IsSelected(), "Edit check box should be checked.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0014_A failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0015()
        {
            try
            {
                Reports.TestDescription = "BR_FM6189_003: Re-Populate Bus Org Contact Info when Edit Name Deselected(ADM).";
                Reports.StatusUpdate("This test method has been clubbed with the REG0013. Please verify the result of REG0013.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0015 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0016()
        {
            try
            {
                Reports.TestDescription = "BR_FM6191: Default Contact Info when Edit Name Selected.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;

                FASTSelenium.DataObjects.ADM.PhoneParameters changedDetail = new FASTSelenium.DataObjects.ADM.PhoneParameters
                {
                    BusinessPhoneNumber = "(342)348-9134",
                    BusinessPhoneExtn = "111",
                    Email = "testchanged@proactive.com",
                    CellularNumber = "(342)348-9135",
                    PagerNumber = "(342)348-9136",
                    BusinessFaxNumber = "(342)348-9137",
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Open the Payee details page for the added payee and get the contact details of payee information section.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                FASTSelenium.DataObjects.ADM.PhoneParameters defaultValue = FastDriver.PayeeDetails.GetPayeeInformationContctDtl();
                #endregion

                #region Click on the EditName check box and verify that contact values are still the same.
                FastDriver.PayeeDetails.EditName.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.VerifyContactDetail(defaultValue, FastDriver.PayeeDetails.GetPayeeInformationContctDtl());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0016 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0017()
        {
            try
            {
                Reports.TestDescription = "BR_FM6229_FM6232_FM6133_FM13691_FM6132: Edited Contact Info when GAB Contact Info Changes.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;

                FASTSelenium.DataObjects.ADM.PhoneParameters changedDetail = new FASTSelenium.DataObjects.ADM.PhoneParameters
                {
                    BusinessPhoneNumber = "(342)348-9134",
                    BusinessPhoneExtn = "111",
                    Email = "testchanged@proactive.com",
                    CellularNumber = "(342)348-9135",
                    PagerNumber = "(342)348-9136",
                    BusinessFaxNumber = "(342)348-9137",
                };
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Open the Payee details page for the added payee and get the contact details of payee information section.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                #endregion

                #region Click on the Edit check box and verify that contact values are still the same.
                Reports.TestStep = "Get the default contact details available at payee information section.";
                FASTSelenium.DataObjects.ADM.PhoneParameters beforeChange = FastDriver.PayeeDetails.GetPayeeInformationContctDtl();

                Reports.TestStep = "Click on the payee information edit check box and update the contact details.";
                FastDriver.PayeeDetails.Edit.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.ValidateBusinessPartyContactDetailsEnabled(expectedResult: true);
                FastDriver.PayeeDetails.UpdatePayeeInfoContctDtl(changedDetail);
                FastDriver.BottomFrame.Done();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                #endregion

                #region Again select the payee and click on the Payee details button, uncheck edit check box, validate that contact details is reset to previous one.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Uncheck the Edit check box of the payee information section.";
                FastDriver.PayeeDetails.Edit.FASetCheckbox(false);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.ValidateBusinessPartyContactDetailsEnabled(expectedResult: false);

                Reports.TestStep = "Validate that payee information is reset to previous one.";
                FastDriver.PayeeDetails.VerifyContactDetail(beforeChange, FastDriver.PayeeDetails.GetPayeeInformationContctDtl());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0017 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0018()
        {
            try
            {
                Reports.TestDescription = "BR_FM5452_ER14: Prevent Removal of Escrow Owning Office Payee.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;

                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region User tries to select the office in Payee Summary page.
                Reports.TestStep = "Click on the office detail in payee summary table.";
                FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, AutoConfig.SelectedOfficeName, 1, TableAction.Click);
                string msgContnt = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Escrow Owning Office payee cannot be selected.", msgContnt, "Verification of error message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0018 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0019()
        {
            try
            {
                Reports.TestDescription = "BR_FM7735: 1.Remove split % amount when Owning Office is edited or changed;2. Fee When Issued check,change Owning Office and Check System message.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                string acttotalFeeAmount = string.Empty;
                bool result = false;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                Reports.TestStep = " BR FM7735 - Validate the system removes split amount and adds the split $ amount to the total of Net Retained Fees when Owning Office is edited or changed.";
                #region Move to the File Homepage and click on the change oo button to change the escrow owning office.
                Reports.TestStep = "Navigate to file homepage and click on the change oo button";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ClickChangeOO();
                #endregion

                #region Change the escrow owning office to some other office.
                Reports.TestStep = "Change the escrow owning office to some other office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItemBySendingKeys("JVR" + FAKeys.Tab);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                string officName = FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FAGetSelectedItem();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to file fees page and verify the split fee amount. It should be zero.
                Reports.TestStep = "Navigate to file fees page and verify the split fee amount. It should be zero.";
                FastDriver.FileFees.Open();
                Support.AreEqual("0.00", FastDriver.FileFees.SplitFeeAmt.FAGetText().Replace("$", string.Empty), "Split fees amount at file fee page. It should be zero.");
                #endregion

                #region Navigate to the split fee disbursment page. Validate all the split fee amount has been removed.
                Reports.TestStep = "Navigate to the split fee disbursment page. Validate all the split fee amount has been removed.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Verify whether the escrow office name has been changed.";
                Support.AreEqual(true, officName.Contains(FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, 1, TableAction.GetText).Message), "Verifying office name is changed.");
                officName = FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, 1, TableAction.GetText).Message;

                acttotalFeeAmount = FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction("Name", officName, "Total Amt.", TableAction.GetText).Message;
                string exptotalFeeCharge = string.Format("{0:0.00}", (fee1BuyerCharge + fee1SellerCharge + fee2BuyerCharge + fee2SellerCharge));
                result = acttotalFeeAmount.Equals(exptotalFeeCharge);
                Reports.StatusUpdate("Validation result for the total amount of entered fee: " + result.ToString(), result, expectedValue: exptotalFeeCharge, actualValue: acttotalFeeAmount);

                Reports.TestStep = "Validate the first fee total amount.";
                acttotalFeeAmount = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 3, TableAction.GetText).Message;
                exptotalFeeCharge = string.Format("{0:0.00}", (fee1BuyerCharge + fee1SellerCharge));
                result = acttotalFeeAmount.Equals(exptotalFeeCharge);
                Reports.StatusUpdate("Validation result for the total charges entered for first fee: " + result.ToString(), result, expectedValue: exptotalFeeCharge, actualValue: acttotalFeeAmount);

                Reports.TestStep = "Validate the second fee total amount.";
                acttotalFeeAmount = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 3, TableAction.GetText).Message;
                exptotalFeeCharge = string.Format("{0:0.00}", (fee2BuyerCharge + fee2SellerCharge));
                result = acttotalFeeAmount.Equals(exptotalFeeCharge);
                Reports.StatusUpdate("Validation result for the total charges entered for second fee: " + result.ToString(), result, expectedValue: exptotalFeeCharge, actualValue: acttotalFeeAmount);
                #endregion

                Reports.TestStep = "(BR FM7735)- 1. Verify the split fee when split fee is issued.";
                #region Add new Payee and split the first fee.
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitAmnt: "3.33");
                #endregion

                #region Navigate to the active disbursment summary page and issue the check related with the split fee.
                Reports.TestStep = "Navigate to the active disbursement summary page and validate the pending check related with split fee.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.GetText).Message.Trim(), "Status of the check for split fee.");

                Reports.TestStep = "Issue the check related with the split fee.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.FASetText("1000");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 20);
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }

                
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("RElease the amount.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the active disbursement summary page and validate the issue check related with split fee.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 1, TableAction.GetText).Message.Trim(), "Status of the check for split fee should be Issued.");
                #endregion

                #region Move to the File Homepage and click on the change oo button to change the escrow owning office.
                Reports.TestStep = "Navigate to file homepage and click on the change oo button";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ClickChangeOO();
                #endregion

                #region Change the escrow owning office to some other office.
                Reports.TestStep = "Change the escrow owning office to some other office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878 (1487)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                Reports.TestStep = "Verify the error message occurred.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                string errorList = FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText();
                string msg1 = "Service File: Current Available Funds is not $0.00. You cannot change the Escrow Owning Office or remove Escrow Service Type.";
                string msg2 = "Service File: File has issued fee disbursements. You cannot change the Owning Office or remove Service Type.";
                if (errorList.Contains(msg1) && errorList.Contains(msg2))
                    Reports.StatusUpdate("System message does match with text in FAST's Change of Owing office screen ", true);
                else
                    Reports.StatusUpdate("System message does not match with text in FAST's Change of Owing office screen ", false);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0019 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0019_A()
        {
            try
            {
                Reports.TestDescription = "BR_FM7735: When the Split fee is not issued remove escrow service and verify the split % fee.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Navigate to the file Home page and click on the change oo button and remove the escrow service.
                Reports.TestStep = "Navigate to the file Home page and click on the change oo button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ClickChangeOO();

                Reports.TestStep = "Remove the escrow services.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Navigate to the split fee disbursement page and validate the error message.
                Reports.TestStep = "Navigate to the split fee disbursement page and validate the  message.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Escrow Owning Office does not exist on the File. Fees cannot be Split. No change in State Assignment required as there is only one distinct Property state on File.", msgContent, "Verify the message on navigating the split fee disbursement page.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0019_A failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0020()
        {
            try
            {
                Reports.TestDescription = "BR_FM3183_FM3170_ER13_FM13681_FM3183_FM8104: Prevent Split Percentage Greater Than 100%.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Add one more payee into the split fee disbursement page and perform the split fee for that.
                Reports.TestStep = "Add one more payee into the split fee disbursement page.";
                string newPayee1 = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "Buyer");

                Reports.TestStep = "Perform the split fee for the first fee with Buyer as well with split% 40%";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee1, splitPer: "40.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee1);
                #endregion

                #region Add one more payee as seller and Perform split fee with third payee with split percentage such that overall it is morethan 100%.
                Reports.TestStep = "Add one more payee into the split fee disbursement page.";
                string newPayee2 = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "Seller");

                Reports.TestStep = "Perform split fee with third payee with split percentage such that overall it is morethan 100%.";
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(4, 2, TableAction.SelectItemBySendkeys, newPayee2 + FAKeys.Tab);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(4, 4, TableAction.SendKeys, "60.00" + FAKeys.Tab);

                Reports.TestStep = "Verify the error message.";
                msgContent = FastDriver.WebDriver.HandleDialogMessage(timeout:20);
                Support.AreEqual("Total of split percentages cannot be greater than 100%.", msgContent, "Verifying the error message.");
                #endregion

                #region Navigate back to the Split fee disbursement page and Verify cancel and next buttons to navigate to Assign sate screen are not available for single property state";
                Reports.TestStep = "Navigate back to the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Verify cancel and next buttons to navigate to Assign sate screen are not available for single property state";
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.Cancel.IsDisplayed(), "Verify there is no cancel button.");
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.Next.IsDisplayed(), "Verify there is no Next button.");
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.PayeeDetails.IsDisplayed(), "Verify Payee details button is displayed.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0020 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0021()
        {
            try
            {
                Reports.TestDescription = "BR_FM5265_FM3160_FM5453_ER11: Prevent Split Dollar Amount Greater Than the total fee Amount.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Update the split$ amount for first fee with split$ amount and validate the split% amount.
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitAmnt: "4.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                Support.AreEqual("0.0000", FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 4, TableAction.GetText).Message.Trim(), "FM3160:Split % does not calculated based on split$ amount");
                #endregion

                #region Add one more payee into the split fee disbursement page.
                Reports.TestStep = "Add one more payee into the split fee disbursement page.";
                string newPayee1 = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "Buyer");

                Reports.TestStep = "Perform the split fee for the second fee with Buyer as well with the split $ amount 10.00";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee1, splitAmnt: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee1);
                #endregion

                #region Add one more payee and split the second fee with the split $ amount such that overall split amount becomes more than fee amount.
                Reports.TestStep = "Add one more payee into the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();
                string newPayee2 = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "Seller");

                Reports.TestStep = "Perform the split fee for the  fee with seller as well with the split $ such that overall split amount is more than fee amount";
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(3, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(6, 2, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(6, 2, TableAction.SelectItemBySendkeys, newPayee2 + FAKeys.Tab);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(6, 5, TableAction.SetText, "78.00" + FAKeys.Tab);
                #endregion

                #region Verify the error message.
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Total of split dollar amounts cannot be greater than the total fee amount.", msgContent, "Verifying the error message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0021 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0022()
        {
            try
            {
                Reports.TestDescription = "BR_FM5298_FM13685: Prevent Split of POC Fees.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the file fee page and open the fee details for the fee.
                Reports.TestStep = "Navigate to file fee page and click on the fee details button.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.FeeDetails.FAClick();
                #endregion

                #region Change the Payment method to POC.
                Reports.TestStep = "Change the payment method to POC.";
                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.PaymentDetails.WaitForScreenToLoad();
                    FastDriver.PaymentDetails.BuyerAtClosing.FASetText("0.00");
                    FastDriver.PaymentDetails.BuyerPaidByOthers.FASetText("11.11");
                    FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItem("POC");
                    FastDriver.PaymentDetails.SellerAtClosing.FASetText("0.00");
                    FastDriver.PaymentDetails.SellerPaidbyOthers.FASetText("33.33");
                    FastDriver.PaymentDetails.SellerPaidbyOthersPayMethod.FASelectItem("POC");
                }
                else
                {
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.FeePaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC");
                    FastDriver.FeePaymentDetailsDlg.sellerPayMethod.FASelectItem("POC-S");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to the split fee disbursement page and validate the error message.
                Reports.TestStep = "Navigate to the split fee disbursement page and validate the  message.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Fees are not available for Split. No change in State Assignment required as there is only one distinct Property state on File.", msgContent, "Verify the message on navigating the split fee disbursement page.");

                Reports.TestStep = "After clicking on OK on the message validate all the buttons are disabled in Split fee disbursemnet screen";
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.New.IsEnabled(), "New Button should be disabled.");
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.Remove.IsEnabled(), "Remove Button should be disabled.");
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.PayeeDetails.IsEnabled(), "Payee details Button should be disabled.");
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.CheckDetails.IsEnabled(), "CheckDetails Button should be disabled.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0022 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0023()
        {
            try
            {
                Reports.TestDescription = "BR_FM3156_FM13690_FM8106_FM8107: Add Title Agent Type to File.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Search for the title agent and add it as a new payee.
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromOrgnization(nametoBeSelected: "E0073SNB", entityID: "E0073SNB");
                #endregion

                #region Split the first fee with newly added payee by percentage.
                Reports.TestStep = "Perform the split fee with newly added payee by percentage.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);

                Reports.TestStep = "Validate the total Amount for the office.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion

                #region Open the Payee Details for the newly added Payee and verify the title agent type.
                Reports.TestStep = "Select the Newly added payee.";
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Verify the Title Agent Type.";
                Support.AreEqual("Title Agent - Non-Affiliated", FastDriver.PayeeDetails.TitleAgentType.FAGetText(), "Verify the title agent type.");
                FastDriver.BottomFrame.Done();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = " BR FM8106 - Validate system should able to enter an Entity Name for a GAB party in the Name field, and click Find Code to add the payee";
                #region Click on new button and add the payee with GAB name for a GAB party.
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromOrgnization(nametoBeSelected: "Lenders Advantage-Nj", entityName: "Lenders");
                #endregion

                #region Split the first fee with newly added payee by percentage.
                Reports.TestStep = "Perform the split fee for first fee with new added payee by percentage.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "12.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);

                Reports.TestStep = "Validate the total Amount for the office.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion

                Reports.TestStep = "BR FM8107 - Validate Name search for the GAB using wild card search can be selected in GAB and added as payee";
                #region Click on new button and search the payee with wild card and add it.
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromOrgnization(nametoBeSelected: "Harris Bank", entityName: "H*");
                #endregion

                #region Split the first fee with newly added payee by percentage.
                Reports.TestStep = "Perform the split fee for first fee with new added payee by percentage.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);

                Reports.TestStep = "Validate the total Amount for the office.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0023 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0024()
        {
            try
            {
                Reports.TestDescription = "BR_FM5262: Prevent Title Agent Type Update to File Business Party.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Search for the title agent and add it as a new payee.
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromOrgnization(nametoBeSelected: "E0073SNB", entityID: "E0073SNB");
                #endregion

                #region Split the first fee with newly added payee by percentage.
                Reports.TestStep = "Perform the split fee with newly added payee by percentage.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);

                Reports.TestStep = "Validate the total Amount for the office.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion

                #region Open the Payee Details for the newly added Payee and verify the title agent type.
                Reports.TestStep = "Open the Payee details of the Newly added payee.";
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Get the Title Agent Type.";
                string titleAgentType = FastDriver.PayeeDetails.TitleAgentType.FAGetText();
                Support.AreEqual("Title Agent - Non-Affiliated", titleAgentType, "Verify the title agent type.");
                FastDriver.BottomFrame.Done();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "BR_FM5262_001: Prevent Title Agent Type Update to File Business Party(ADM).";
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and select the GAB E0073SNB at  Address Book.
                Reports.TestStep = "Move to the region level and navigate to the address book search page.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search for the GAB E0073SNB and click on the edit button";
                FastDriver.AddressBookSearch.EditGAB(GAB: "E0073SNB");
                #endregion

                #region Set the title agent type as Title Agent - Affiliated/Non-Consolidated for the GAB.
                Reports.TestStep = "Set the title agent type as Title Agent - Affiliated/Non-Consolidated for the GAB.";
                FastDriver.BusinessPartyOrganizationSetUp.TitleAgentType.FASelectItem("Title Agent - Affiliated/Non-Consolidated");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "BR_FM5262_002_FD_06: Prevent Title Agent Type Update to File Business Party(File).";
                #region IIS Login
                IISLOGIN();
                #endregion

                #region Find the Previous file id.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber: fileNumber);
                #endregion

                #region Navigate to the split fee dibursment page and open the payee details of added payee.
                Reports.TestStep = "Navigate to the Split fee Disbursment page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Open the Payee details of the Newly added payee.";
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Get the Title Agent Type.";
                Support.AreNotEqual("Title Agent - Affiliated/Non-Consolidated", FastDriver.PayeeDetails.TitleAgentType.FAGetText(), "Verify the title agent type is not updated with new one.");
                Support.AreEqual(titleAgentType, FastDriver.PayeeDetails.TitleAgentType.FAGetText(), "Verify the title agent type is the previous one.");
                FastDriver.BottomFrame.Done();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.FileHomepage.Open();
                #endregion

                #region Create a new file, Add two fees, and Add new payee.
                Reports.TestStep = "Create a New file.";
                CreateBasicFile();
                fileNumber = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search for the title agent and add it as a new payee.";
                FastDriver.SplitFeeDisbursements.Open();
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromOrgnization(nametoBeSelected: "E0073SNB", entityID: "E0073SNB");
                #endregion

                #region Split the first fee with newly added payee by percentage.
                Reports.TestStep = "Perform the split fee with newly added payee by percentage.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);

                Reports.TestStep = "Validate the total Amount for the office.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                #endregion

                #region Open the Payee Details for the newly added Payee and verify the title agent type.
                Reports.TestStep = "Open the Payee details of the Newly added payee.";
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Get the Title Agent Type.";
                titleAgentType = FastDriver.PayeeDetails.TitleAgentType.FAGetText();
                Support.AreEqual("Title Agent - Affiliated/Non-Consolidated", titleAgentType, "Verify the title agent type is updated for the new file.");
                FastDriver.BottomFrame.Done();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "BR_FM5262_003: Prevent Title Agent Type Update to File Business Party(ADM).";
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and select the GAB E0073SNB at  Address Book.
                Reports.TestStep = "Move to the region level and navigate to the address book search page.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);
                Reports.TestStep = "Search for the GAB E0073SNB and click on the edit button";
                FastDriver.AddressBookSearch.EditGAB(GAB: "E0073SNB");
                #endregion

                #region Set the title agent type as Title Agent - Non-Affiliated for the GAB.
                Reports.TestStep = "Set the title agent type as Title Agent - Non-Affiliated for the GAB.";
                FastDriver.BusinessPartyOrganizationSetUp.TitleAgentType.FASelectItem("Title Agent - Non-Affiliated");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0024 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0025()
        {
            try
            {
                Reports.TestDescription = "BR_FM5262_002_FD_06: Prevent Title Agent Type Update to File Business Party(File).";
                Reports.StatusUpdate("This test method has been clubbed with the REG0024. Please verify the result of REG0004.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0025 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0026()
        {
            try
            {
                Reports.TestDescription = "BR_FM5262_003: Prevent Title Agent Type Update to File Business Party(ADM).";
                Reports.StatusUpdate("This test method has been clubbed with the REG0024. Please verify the result of REG0004.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0026 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0027()
        {
            try
            {
                Reports.TestDescription = "BR_FM7732: Increase Amount of Split Fee.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Navigate to the fee entry page and Increase the Fee Amount.
                Reports.TestStep = "Navigate to Fee Entry Page.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Increase the charges for the New Home Rate (Title Only) fee.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.Click);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SendKeys, "50.00" + FAKeys.Tab);

                Reports.TestStep = "Verify the warning message.";
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("This change will update Split Fee and/or Retained amounts, and may create additional pending Split Fee Disbursements and/or Fee Transfers. Continue?", msgContent, "Verifying the warning message.");
                }
                else
                {
                    Support.AreEqual("This change will update Split Fee and/or Retained amounts, and may create additional pending Split Fee Disbursements and/or Fee Transfers, and may remove Underwriter and Agent premium splits. Continue?", msgContent, "Verifying the warning message.");
                }
                #endregion

                #region Navigate to the split fee disbursement page and verify the split fee amount after fee is increased.
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0027 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0028()
        {
            try
            {
                Reports.TestDescription = "BR_FM7733_ER1: Restrict Display of Fee on Split Fee Disbursement Screen.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Remove the split $ amount for the second fee.
                Reports.TestStep = "Remove the split $ amount for the second fee.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitAmnt: "0.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the File Fee page and make all the Buyer and seller charges of fee zero.
                Reports.TestStep = "Remove the charges of fee 1.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.Click);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SendKeys, "0.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.Click);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SendKeys, "0.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Remove the charges of fee 2.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.Click);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SendKeys, "0.00" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.Click);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SendKeys, "0.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the split fee disbursement page and verify the message.
                Reports.TestStep = "Navigate to the Split fee disbursement page.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");

                Reports.TestStep = "Verify the error message.";
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Fees are not available for Split. No change in State Assignment required as there is only one distinct Property state on File.", msgContent, "Verifying the warning message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0028 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0029()
        {
            try
            {
                Reports.TestDescription = "BR_FM13682_FM13681_FM13699_FM13704_FM13705_FM13706_FM13707_FM13694: Multiple States with Fees available for Split and State Assignment.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "KS";
                #endregion

                //ADM settings to check the "Subject to state assignment" check box for the fee.
                #region ADM Settings.
                 #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and Navigate to the Fee Summary.
                Reports.TestStep = "Move to the region level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to the Fee Summary Screen.";
                FastDriver.FeeList2.Open();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).
                Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Owners Policy", feeName: "New Home Rate (Title Only)");

                Reports.TestStep = "check the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                Reports.TestStep = "Select the New Home Rate Eagle Lender Policy-1 fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                Reports.TestStep = "Uncheck the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Verify Whether both the fees are state assigned.
                Reports.TestStep = "Verify whether both the fees are state assigned.";
                FastDriver.FileFees.Open();
                Support.AreEqual("Y", FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Asg State", TableAction.GetText).Message.Trim(), "Verification of fee1 for State assignment.");
                Support.AreEqual("Y", FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Asg State", TableAction.GetText).Message.Trim(), "Verification of fee1 for State assignment.");
                #endregion

                #region Navigate back to Split Fee disbursement and Verify for the Cancel and Next Button and click on the next button.
                Reports.TestStep = "Navigate to the Split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Validate the Cancel and Next buttons are available when there are distinct properties in file.";
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.Next.IsDisplayed(), "Next button should be visible.");
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.Cancel.IsDisplayed(), "Cancel button should be visible.");

                Reports.TestStep = "Get the Ret.$ amount for both the fees.";
                string retFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 6, TableAction.GetText).Message.Trim();
                string retFee2 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(3, 6, TableAction.GetText).Message.Trim();

                Reports.TestStep = "Validate the buttons are not available.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(false, FastDriver.BottomFrame.btnDone.IsDisplayed(), "Done button should not be visible.");
                Support.AreEqual(false, FastDriver.BottomFrame.btnReset.IsDisplayed(), "Reset button should not be visible.");
                Support.AreEqual(false, FastDriver.BottomFrame.btnAutoSave.IsDisplayed(), "Save button should not be visible.");
                #endregion

                #region Verify the amount after split is displayed in assign property screen.
                Reports.TestStep = "Click on the next button and verify the retained amount for the fee.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Verify the amount after split is displayed in Assign Property screen.";
                Support.AreEqual(retFee1, FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate (Title Only)", 3, TableAction.GetText).Message.Trim(), "Verification of Retained Dollar amount for fee1");
                Support.AreEqual(retFee2, FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 3, TableAction.GetText).Message.Trim(), "Verification of Retained Dollar amount for fee2");
                #endregion

                #region Verify the default values and Split the first fee amount between the two states by percentage and by amount.
                FastDriver.AssignFeetoPropertyStates.VerifyDefaultValuesforStateBeforAssign(feeName: "New Home Rate (Title Only)", stateName: stateName);
                FastDriver.AssignFeetoPropertyStates.AssignFeeBetweenStates(feeName: "New Home Rate (Title Only)", stateName: stateName, assignPer: "10.0000");
                FastDriver.AssignFeetoPropertyStates.AssignFeeBetweenStates(feeName: "New Home Rate Eagle Lender Policy-1", stateName: stateName, assignAmount: "10.00");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "BR FM13682 - Validate system should not allow user to assign the fee to the properties after 100% split .";
                #region BR FM13682 - Validate system should not allow user to assign the fee to the properties after 100% split.
                Reports.TestStep = "Navigate to the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Split the fee between the payee with 100%.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "100");
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Select the first fee and and Validate on cent % split,assign fee to propertystate should not be allowed.";
                FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate (Title Only)", 1, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.AssignState.IsEnabled(), "Assign fee between the property states check box should be disabled.");
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0029 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0030()
        {
            try
            {
                Reports.TestDescription = "BR_FM13702_FM13711_FM13693_ER15: Property State of disbursed fee.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "TX";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Navigate to the Active disbursement summary page and disburse pending check related to the split fee.
                Reports.TestStep = "Navigate to the Active Disbursement Summary page.";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "Select the pending check related to the split fee and click on the print button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Perform the Print Delievery.";
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint();
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the status of the check is issued in active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", splitAmount, "Status", TableAction.GetText).Message.Trim(), "Status of the Check with the split Amount.");
                #endregion

                #region Navigate to the split fee disbursement page and click on the next button.
                Reports.TestStep = "Navigate to the split fee disbursement page and click on the next button.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.Next.FAClick();
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                #endregion

                #region Verify that the assign fee checkbox and state radio buttons are disabled.
                Reports.TestStep = "Select the Second fee and Verify that the assign fee checkbox and state radio buttons are disabled.";
                FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 1, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.AssignState.IsEnabled(), "Assign fees between property states checkbox should be disabled.");

                Reports.TestStep = "Select the first fee and click on the state radio button.";
                FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate (Title Only)", 1, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                FastDriver.AssignFeetoPropertyStates.State1.FAClick();

                Reports.TestStep = "Verifying the warning message.";
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Fee has been disbursed. Void or cancel Disbursement before changing the assigned Property State.", msgContent, "Verifying the warning message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0030 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0031()
        {
            try
            {
                Reports.TestDescription = "BR_FM13692_FM13700: Retained Amount assigned to Property State.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "KS";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee after clicking on the new button.
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                #endregion

                #region Split the first fee between two payees and validate the amount is splitted correctly.
                Reports.TestStep = "Enter split% as 100% for first fee and validate the retained amount is zero.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "100.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Click on the Next button and verify the retained amount for the office.
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Verify that retained amount by the office for fee1 is zero.";
                Support.AreEqual("0.00", FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate (Title Only)", 3, TableAction.GetText).Message.Trim(), "Retained Amount for fee1 by office. It should be zero.");

                Reports.TestStep = "Verify that the assign fee checkbox and state radio buttons are disabled.";
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.AssignState.IsEnabled(), "Assign fees between property states checkbox should be disabled.");
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.State1.IsEnabled(), "State1 radio button should be disabled.");
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.State2.IsEnabled(), "State2 radio button should be disabled.");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate back to the split fee Disbursement page and split the first fee with less than 100%.
                Reports.TestStep = "Enter split% value less than 100% for first fee and validate the retained amount is not zero.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "25.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                string retDolAmount = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction("Payee", AutoConfig.SelectedOfficeName, "Ret. $", TableAction.GetText).Message.Trim();
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Verify that Retained amount of Fee1 for office is not zero.";
                Support.AreNotEqual("0.00", FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate (Title Only)", 3, TableAction.GetText).Message.Trim(), "Retained Amount for fee1 by office. It should not be zero.");
                Support.AreEqual(retDolAmount, FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate (Title Only)", 3, TableAction.GetText).Message.Trim(), "Verifying the value of Retained amount of fee1 from the previous page.");
                #endregion

                #region Verify that if Retained amount for the office is not zero than we are able to perform the split fee between the states.
                Reports.TestStep = "Verify that if Retained amount for the office is not zero than we are able to perform the split fee between the states.";
                FastDriver.AssignFeetoPropertyStates.AssignFeeBetweenStates(feeName: "New Home Rate (Title Only)", stateName: stateName, assignPer: "10.00");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0031 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0032()
        {
            try
            {
                Reports.TestDescription = "BR_FM13703_FM13710_FM13683_ER16: Property State of invoiced fee.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "KS";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Click on the Next button and assign the fee1 between the two states.
                FastDriver.SplitFeeDisbursements.ClickNext();
                Reports.TestStep = "Assign the Fee1 between the two states.";
                FastDriver.AssignFeetoPropertyStates.AssignFeeBetweenStates(feeName: "New Home Rate (Title Only)", stateName: stateName, assignPer: "10.00");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the Invoice screen and Click on the final button.
                Reports.TestStep = "Navigate to the invoice Fee Screen.";
                FastDriver.InvoiceFees.Open();

                Reports.TestStep = "Verify for the Final button and click on it.";
                Support.AreEqual(true, FastDriver.InvoiceFees.Final.IsEnabled(), "Verify that Final button is enabled.");
                FastDriver.InvoiceFees.Final.FAClick();
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                #endregion

                #region Navigate back to the Assign Fee After Fee is Invoiced.
                Reports.TestStep = "Navigate back to the Assign Fee After Fee is Invoiced.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();

                Reports.TestStep = "Verify that the assign fee checkbox and state radio buttons are disabled.";
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.AssignState.IsEnabled(), "Assign fees between property states checkbox should be disabled.");
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.State1.IsEnabled(), "State1 radio button should be disabled.");
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.State2.IsEnabled(), "State2 radio button should be disabled.");

                Reports.TestStep = "Click on the fee2.";
                FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 1, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();

                Reports.TestStep = "Change the property assignment for an INVOICED fee.";
                FastDriver.AssignFeetoPropertyStates.State2.FAClick();
                msgContent = FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Warning message.";
                Support.AreEqual("Fee is part of finalized invoice. Cancel Invoice before changing the assigned Property State. ", msgContent, "Verifying the Warning Message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0032 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0033()
        {
            try
            {
                Reports.TestDescription = "BR_FM13708_FM13709_ER18_ER19: Prevent Assign Percentage Greater Than 100% (not working).";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "KS";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Click on the Next button and assign the fee1 between the two states with percetage more than 100%.
                FastDriver.SplitFeeDisbursements.ClickNext();
                Reports.TestStep = "Assign the Fee1 between the two states with percetage more than 100%.";
                FastDriver.AssignFeetoPropertyStates.AssignState.FASetCheckbox(true);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, stateName, 1, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, stateName, 3, TableAction.SetText, "101" + FAKeys.Tab);

                Reports.TestStep = "Verify the Warning message.";
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Assign percentages cannot be greater than 100%.", msgContent, "Verifying the Warning Message.");
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();

                FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, stateName, 1, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, stateName, 3, TableAction.SetText, "10" + FAKeys.Tab);
                #endregion

                #region Assign the Fee1 between the states with more than the Fee Amount.
                Reports.TestStep = "Enter split$ more than fee amount.";
                FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, stateName, 1, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, stateName, 4, TableAction.SetText, "35.00" + FAKeys.Tab);

                Reports.TestStep = "Verify the Warning message.";
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Total of assign dollar amount cannot be greater than the Total Charge.", msgContent, "Verifying the Warning Message.");

                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, stateName, 4, TableAction.SetText, "10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0033 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0034()
        {
            try
            {
                Reports.TestDescription = "BR_FM13713: Default to first property state when Split amount changes.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "TX";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);

                Reports.TestStep = "Get the Ret.$ amount for both the fees.";
                string retFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 6, TableAction.GetText).Message.Trim();
                string retFee2 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(3, 6, TableAction.GetText).Message.Trim();
                #endregion

                #region Navigate to the Assign Fee to states page and verify the retained amount.
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Verify the amount after split is displayed in Assign Property screen.";
                Support.AreEqual(retFee1, FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate (Title Only)", 3, TableAction.GetText).Message.Trim(), "Verification of Retained Dollar amount for fee1");
                Support.AreEqual(retFee2, FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 3, TableAction.GetText).Message.Trim(), "Verification of Retained Dollar amount for fee2");
                #endregion

                #region Assign the fee1 between the states.
                Reports.TestStep = "Assign the fee1 between the states.";
                FastDriver.AssignFeetoPropertyStates.AssignFeeBetweenStates(feeName: "New Home Rate (Title Only)", stateName: stateName, assignPer: "10.0000");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate back to split fee disbursment page and increase the split fee %.
                Reports.TestStep = "Navigate back to the Split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Increase the split % for fee1.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "75.00");
                #endregion

                #region Navigate to the assign fees to state page and verify the assign state check box and state radio button.
                Reports.TestStep = "Move to the Assign fee to states page.";
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Verify Assign checkbox is unchecked and fee is defaulted to first property.";
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.AssignState.IsSelected(), "Assign fees between property states checkbox should be unchecked.");
                Support.AreEqual(true, FastDriver.AssignFeetoPropertyStates.State1.IsSelected(), "State1 radio button should be selected.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0034 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0035()
        {
            try
            {
                Reports.TestDescription = "BR_FM13712: Allocate to first property state on change of Transaction.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "TX";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);

                Reports.TestStep = "Get the Ret.$ amount for both the fees.";
                string retFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 6, TableAction.GetText).Message.Trim();
                string retFee2 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(3, 6, TableAction.GetText).Message.Trim();
                #endregion

                #region Navigate to the Assign Fee to states page and verify the retained amount.
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Verify the amount after split is displayed in Assign Property screen.";
                Support.AreEqual(retFee1, FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate (Title Only)", 3, TableAction.GetText).Message.Trim(), "Verification of Retained Dollar amount for fee1");
                Support.AreEqual(retFee2, FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 3, TableAction.GetText).Message.Trim(), "Verification of Retained Dollar amount for fee2");
                #endregion

                #region Assign the fee1 between the states.
                Reports.TestStep = "Assign the fee1 between the states.";
                FastDriver.AssignFeetoPropertyStates.AssignFeeBetweenStates(feeName: "New Home Rate (Title Only)", stateName: stateName, assignAmount: "2.25");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to File Home page and change the transaction type.
                Reports.TestStep = "Navigate File HomePage.";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Change the Transaction type of the file to Refinance.";
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("r" + FAKeys.Tab);// changing the transaction type to Refinance
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the assign fees to state page and verify the assign state check box and state radio button.
                Reports.TestStep = "Move to the Assign fee to states page.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Verify the Assign state check box and state radio button is selected.";
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.AssignState.IsSelected(), "Assign fees between property states checkbox should be unchecked.");
                Support.AreEqual(true, FastDriver.AssignFeetoPropertyStates.State1.IsSelected(), "State1 radio button should be selected.");

                Reports.TestStep = "Validate the retained amount after change the transaction type to refinance.";
                Support.AreEqual(fee1BuyerCharge.ToString(), FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, "New Home Rate (Title Only)", 3, TableAction.GetText).Message.Trim(), "Verification of Retained Dollar amount for fee1");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0034 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0036()
        {
            try
            {
                Reports.TestDescription = "1.BR_FM13684_001_FM13695_FM13697: Multiple States with only Fees available for Split(ADM). 2.BR_FM13684_002_FM13695_FM13697: Multiple States with only Fees available for Split(File). 3.BR_FM13684_003_FM13695_FM13697: Multiple States with only Fees available for Split(ADM).";

                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "TX";
                #endregion

                Reports.TestStep = "1.BR_FM13684_001_FM13695_FM13697: Multiple States with only Fees available for Split(ADM).";
                #region ADM Settings.
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and Navigate to the Fee Summary.
                Reports.TestStep = "Move to the region level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to the Fee Summary Screen.";
                FastDriver.FeeList2.Open();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).
                Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Owners Policy", feeName: "New Home Rate (Title Only)");

                Reports.TestStep = "check the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(true);
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                Reports.TestStep = "Select the New Home Rate Eagle Lender Policy-1 fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                Reports.TestStep = "Uncheck the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(false);
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #endregion

                Reports.TestStep = "2.BR_FM13684_002_FM13695_FM13697: Multiple States with only Fees available for Split(File).";
                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");

                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Whether New Home Rate (Title Only) is state assigned and New Home Rate Eagle Lender Policy-1 is not state assigned.
                Reports.TestStep = "Verify Whether New Home Rate (Title Only) is state assigned and New Home Rate Eagle Lender Policy-1 is not state assigned.";
                FastDriver.FileFees.Open();
                Support.AreEqual("Y", FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Asg State", TableAction.GetText).Message.Trim(), "Verification of fee1 for State assignment.");
                Support.AreEqual("N", FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Asg State", TableAction.GetText).Message.Trim(), "Verification of fee1 for State assignment.");
                #endregion

                #region Move to the Split Fee Disbursement page and verify for the buttons.
                Reports.TestStep = "Validate the Done, AutoSave and Reset buttons are not available.";
                FastDriver.SplitFeeDisbursements.Open();
                Support.AreEqual(false, FastDriver.BottomFrame.btnDone.IsDisplayed(), "Done button should not be visible.");
                Support.AreEqual(false, FastDriver.BottomFrame.btnReset.IsDisplayed(), "Reset button should not be visible.");
                Support.AreEqual(false, FastDriver.BottomFrame.btnAutoSave.IsDisplayed(), "Save button should not be visible.");

                Reports.TestStep = "Validate the Cancel and Next buttons are available.";
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.Next.IsDisplayed(), "Next button should be visible.");
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.Cancel.IsDisplayed(), "Cancel button should be visible.");
                #endregion

                #region Move to the Assign fee to state page and validate only state assigned fees are available.
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "BR FM13697 - Validate Fee with Assign state N does not get displayed in Assign state screen.";
                msgContent = FastDriver.AssignFeetoPropertyStates.FeeTable.FAGetText();

                Support.AreEqual(false, msgContent.Contains("New Home Rate Eagle Lender Policy-1"), "Verify that New Home Rate Eagle Lender Policy-1 should not be available at fee table.");
                #endregion

                Reports.TestStep = "3.BR_FM13684_003_FM13695_FM13697: Multiple States with only Fees available for Split(ADM).";
                #region ADM Settings.

                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and Navigate to the Fee Summary.
                Reports.TestStep = "Move to the region level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to the Fee Summary Screen.";
                FastDriver.FeeList2.Open();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                Reports.TestStep = "Select the New Home Rate Eagle Lender Policy-1 fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                Reports.TestStep = "Check the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(true);
               
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0036 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0037()
        {
            try
            {
                Reports.TestDescription = "BR_FM13684_002_FM13695_FM13697: Multiple States with only Fees available for Split(File).";
                Reports.StatusUpdate("This test method has been clubbed with the REG0036. Please verify the result of REG0036.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0037 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0038()
        {
            try
            {
                Reports.TestDescription = "BR_FM13684_003_FM13695_FM13697: Multiple States with only Fees available for Split(ADM).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0036, Please verify the results of REG0036.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0038 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0039()
        {
            try
            {
                Reports.TestDescription = "BR_FM13696_001_002_003: Change of State Assignment attribute on Fee Setup(File).";

                Reports.TestStep = "Login to ADM side to verify the fee settings.";
                #region ADM settings.
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and Navigate to the Fee Summary.
                Reports.TestStep = "Move to the region level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to the Fee Summary Screen.";
                FastDriver.FeeList2.Open();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).
                Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Owners Policy", feeName: "New Home Rate (Title Only)");

                Reports.TestStep = "check the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(true);
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                Reports.TestStep = "Select the New Home Rate Eagle Lender Policy-1 fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                Reports.TestStep = "Uncheck the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(true);
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #endregion

                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "TX";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Verify Whether both the fees are state assigned.
                Reports.TestStep = "Verify whether both the fees are state assigned.";
                FastDriver.FileFees.Open();
                Support.AreEqual("Y", FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Asg State", TableAction.GetText).Message.Trim(), "Verification of fee1 for State assignment.");
                Support.AreEqual("Y", FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Asg State", TableAction.GetText).Message.Trim(), "Verification of fee1 for State assignment.");
                #endregion

                #region Navigate back to Split Fee disbursement and Verify for the Cancel and Next Button and click on the next button.
                Reports.TestStep = "Navigate to the Split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Validate the Cancel and Next buttons are available when there are distinct properties in file.";
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.Next.IsDisplayed(), "Next button should be visible.");
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.Cancel.IsDisplayed(), "Cancel button should be visible.");

                Reports.TestStep = "Get the Ret.$ amount for both the fees.";
                string retFee1 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 6, TableAction.GetText).Message.Trim();
                string retFee2 = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(3, 6, TableAction.GetText).Message.Trim();

                Reports.TestStep = "Validate the buttons are not available.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(false, FastDriver.BottomFrame.btnDone.IsDisplayed(), "Done button should not be visible.");
                Support.AreEqual(false, FastDriver.BottomFrame.btnReset.IsDisplayed(), "Reset button should not be visible.");
                Support.AreEqual(false, FastDriver.BottomFrame.btnAutoSave.IsDisplayed(), "Save button should not be visible.");
                #endregion

                Reports.TestStep = "Perform ADM settings for unchecking the state assignment attribute on fee Setup.(ADM)";
                #region ADM Settings.

                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and Navigate to the Fee Summary.
                Reports.TestStep = "Move to the region level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to the Fee Summary Screen.";
                FastDriver.FeeList2.Open();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).
                Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Owners Policy", feeName: "New Home Rate (Title Only)");

                Reports.TestStep = "Uncheck the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(false);
               
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                Reports.TestStep = "Select the New Home Rate Eagle Lender Policy-1 fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                Reports.TestStep = "Uncheck the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(false);
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #endregion

                Reports.TestStep = "Verify in file side that changing the state assignmen attribute does not affect for already existing file.";
                #region IIS Login
                IISLOGIN();
                #endregion

                #region Open the previous file.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber: fileNumber);
                #endregion

                #region NAvigate to the file fee page verify that fees are still state assigned.
                Reports.TestStep = "NAvigate to the file fee page verify that fees are still state assigned.";
                FastDriver.FileFees.Open();
                Support.AreEqual("Y", FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Asg State", TableAction.GetText).Message.Trim(), "Verification of fee1 for State assignment.");
                Support.AreEqual("Y", FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Asg State", TableAction.GetText).Message.Trim(), "Verification of fee1 for State assignment.");
                #endregion

                Reports.TestStep = "Perform ADM settings for checking the state assignment attribute on fee Setup.(ADM)";
                #region ADM Settings.

                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and Navigate to the Fee Summary.
                Reports.TestStep = "Move to the region level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to the Fee Summary Screen.";
                FastDriver.FeeList2.Open();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).
                Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Owners Policy", feeName: "New Home Rate (Title Only)");

                Reports.TestStep = "Check the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(true);
               
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                Reports.TestStep = "Select the New Home Rate Eagle Lender Policy-1 fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                Reports.TestStep = "Check the Subject to State Assignment and Rate type.";
                FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(true);
               
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0039 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0040()
        {
            try
            {
                Reports.TestDescription = "BR_FM13696_002: Change of State Assignment attribute on Fee Setup(ADM).";
                Reports.StatusUpdate("This test method has been clubbed with the REG0039. Please verify the result of REG0039.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0040 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0041()
        {
            try
            {
                Reports.TestDescription = "BR_FM13696_003: Change of State Assignment attribute on Fee Setup(File).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0039, Please verify the results of REG0039.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0041 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0042()
        {
            try
            {
                Reports.TestDescription = "BR_FM13696_004: Change of State Assignment attribute on Fee Setup(File).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0039, Please verify the results of REG0039.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0042 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0043()
        {
            try
            {
                Reports.TestDescription = "BR_FM13698: Distinct Multiple Property States.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add one more Property with two address states.
                Reports.TestStep = "Navigate to the Property/Tax Info screen.";
                FastDriver.PropertiesSummary.Open();

                Reports.TestStep = "Click on New Button.";
                FastDriver.PropertiesSummary.New.FAClick();

                Reports.TestStep = "Click on the new button on General tab and add state TX.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("CA");

                Reports.TestStep = "Add one more address to this property.";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("AP");

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the assign fee to state page and verify all distinct states are available.
                Reports.TestStep = "Navigate to the assign fee to state page and verify all distinct states are available.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Verify that all distinct states are availabe at property table.";
                FastDriver.AssignFeetoPropertyStates.PropertyTable.PerformTableAction(2, "CA", 2, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.PropertyTable.PerformTableAction(2, "AP", 2, TableAction.Click);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0043 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0044()
        {
            try
            {
                Reports.TestDescription = "BR_FM13686_001_002_003_004: Splitting of Fees when Corporate Parent of Owning Office is FA(ADM).";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                Reports.TestStep = "BR_FM13686_001: Splitting of Fees when Corporate Parent of Owning Office is FA(ADM).";
                #region ADM Settings.
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Change the Corporate Parent to First American (FA).
                Reports.TestStep = "Change the Corporate Parent to First American (FA).";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.CorporateParent.FASelectItem("First American (FA)");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move into the region level of 1486 and Navigate to the Fee Summary.
                Reports.TestStep = "Move to the region level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to the Fee Summary Screen.";
                FastDriver.FeeList2.Open();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).
                Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Owners Policy", feeName: "New Home Rate (Title Only)");

                Reports.TestStep = "Check the Split with FA office checkbox.";
                FastDriver.FeeSetup.SplitWithFAOffice.FASetCheckbox(true);
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                Reports.TestStep = "Select the New Home Rate Eagle Lender Policy-1 fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                Reports.TestStep = "Check the Split with FA office checkbox.";
                FastDriver.FeeSetup.SplitWithFAOffice.FASetCheckbox(true);
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion
                #endregion

                Reports.TestStep = "BR_FM13686_002_FM13690_FM5451_FM8105: Splitting of Fees when Corporate Parent of Owning Office is FA(File).";
                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee for split from FPB and perform split.
                Reports.TestStep = "Click on New Button and add payee from the File production office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromFPBorOffice(officeName: "JVR Office", fpb: true);

                Reports.TestStep = "Perform the Split action with the newly added payee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitAmnt: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Add New Payee from the offices table and perform split.
                FastDriver.SplitFeeDisbursements.Open();
                Reports.TestStep = "Click on New Button and add payee from the File production office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromFPBorOffice(officeName: "FATICO-QA", fpb: false);

                Reports.TestStep = "Perform the Split action with the newly added payee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitAmnt: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "BR_FM13686_003_FM13689: Splitting of Fees when Corporate Parent of Owning Office is FA(ADM).";
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Move into the region level of 1486 and Navigate to the Fee Summary.
                Reports.TestStep = "Move to the region level.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to the Fee Summary Screen.";
                FastDriver.FeeList2.Open();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).
                Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Owners Policy", feeName: "New Home Rate (Title Only)");

                Reports.TestStep = "Uncheck the Split with FA office checkbox.";
                FastDriver.FeeSetup.SplitWithFAOffice.FASetCheckbox(false);
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                Reports.TestStep = "Select the New Home Rate Eagle Lender Policy-1 fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: AutoConfig.FormType, feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                Reports.TestStep = "Uncheck the Split with FA office checkbox.";
                FastDriver.FeeSetup.SplitWithFAOffice.FASetCheckbox(false);
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion

                Reports.TestStep = "BR_FM13686_004_FM13689: Splitting of Fees when Corporate Parent of Owning Office is FA(File).";
                #region Login to file side and  Open the previous file.
                this.IISLOGIN();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber: fileNumber);
                #endregion

                #region NAvigate to the Split fee Disbursement page and verify split is still available.
                Reports.TestStep = "NAvigate to the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Verify that split is still available for the previous file.";
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: "JVR Office");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: "FATICO-QA");
                FastDriver.FileHomepage.Open();
                #endregion

                Reports.TestStep = "Verify that we can not split the fee between the office when split between fees checkbox is unchecked for new files.";
                #region Create a Basic File
                CreateBasicFile();
                fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee for split from FPB and perform split.
                Reports.TestStep = "Click on New Button and add payee from the File production office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromFPBorOffice(officeName: "JVR Office", fpb: true);

                Reports.TestStep = "Validate the Scissors icon is disabled when the payee is FA office and fee is not Split with FA Office.";
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAGetAttribute("Src").Contains("smsfast/Images2/Cut1.jpg"), "Scissor image1 should be disabled.");
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAGetAttribute("Src").Contains("smsfast/Images2/Cut1.jpg"), "Scissor image2 should be disabled.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0043 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0045()
        {
            try
            {
                Reports.TestDescription = "BR_FM13686_002_FM13690_FM5451_FM8105: Splitting of Fees when Corporate Parent of Owning Office is FA(File).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0044, Please verify the results of REG0044.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0045 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0046()
        {
            try
            {
                Reports.TestDescription = "BR_FM13686_003_FM13689: Splitting of Fees when Corporate Parent of Owning Office is FA(ADM).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0044, Please verify the results of REG0044.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0046 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0047()
        {
            try
            {
                Reports.TestDescription = "BR_FM13686_004_FM13689: Splitting of Fees when Corporate Parent of Owning Office is FA(File).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0044, Please verify the results of REG0044.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0047 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0048()
        {
            try
            {
                Reports.TestDescription = "BR_FM13687_001: Splitting of Fees when Corp Parent of Owning Office is NAT/Other(ADM).";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region ADM Settings.
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Change the Corporate Parent to North American Title (NAT).
                Reports.TestStep = "Change the Corporate Parent to North American Title (NAT).";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.CorporateParent.FASelectItem("North American Title (NAT)");
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                Reports.TestStep = "BR_FM13687_002: Splitting of Fees when Corp Parent of Owning Office is NAT/Other(File).";
                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee for split from FPB and perform split.
                Reports.TestStep = "Click on New Button and add payee from the File production office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromFPBorOffice(officeName: AutoConfig.SelectedOfficeName, fpb: true);

                Reports.TestStep = "Perform the Split action with the newly added payee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitAmnt: "23.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);

                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0048 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0049()
        {
            try
            {
                Reports.TestDescription = "BR_FM13687_002: Splitting of Fees when Corp Parent of Owning Office is NAT/Other(File).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0048, Please verify the results of REG0048.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0049 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0050()
        {
            try
            {
                Reports.TestDescription = "01.BR_FM13688_001: Change in Corporate Parent of Owning Office and Payee(ADM). 02.BR_FM13688_002: Change in Corporate Parent of Owning Office and Payee(File).";

                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region ADM Settings.
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Change the Corporate Parent to North American Title (NAT).
                Reports.TestStep = "Change the Corporate Parent to North American Title (NAT).";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.CorporateParent.FAGetSelectedItem().Equals("North American Title (NAT)"))
                {
                    FastDriver.OfficeSetupOffice.CorporateParent.FASelectItem("North American Title (NAT)");
                }
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee for split from FPB and perform split.
                Reports.TestStep = "Click on New Button and add payee from the File production office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromFPBorOffice(officeName: AutoConfig.SelectedOfficeName, fpb: true);

                Reports.TestStep = "Perform the Split action with the newly added payee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitAmnt: "23.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);

                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "BR_FM13688_001: Change in Corporate Parent of Owning Office and Payee(ADM).";

                #region ADM Settings.
                #region ADM Login
                this.ADMLOGIN();
                #endregion

                #region Change the Corporate Parent to First American (FA).
                Reports.TestStep = "Change the Corporate Parent to First American (FA).";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.CorporateParent.FASelectItem("First American (FA)");
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                Reports.TestStep = "BR_FM13688_002: Change in Corporate Parent of Owning Office and Payee(File).";
                #region login to file side and Open the previous file.
                this.IISLOGIN();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber: fileNumber);
                #endregion

                #region NAvigate to the Split fee Disbursement page and verify split is still available.
                Reports.TestStep = "NAvigate to the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Verify that split is still available for the previous file.";
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Perform the Split action with the newly added payee with zero dollar amount and percentage.
                Reports.TestStep = "Perform the Split action with the newly added payee with zero dollar amount and percentage.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "0.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitAmnt: "0.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Remove the Payee.
                Reports.TestStep = "Remove the payee.";
                FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.Remove.FAClick();
                FastDriver.SplitFeeDisbursements.WaitForScreenToBeReady();
                FastDriver.SplitFeeDisbursements.Open();
                #endregion

                #region Again Add the payee from the FBP and Validate for the scissor sign.
                Reports.TestStep = "Again Add the payee from the FBP and perform Split Fee.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromFPBorOffice(officeName: AutoConfig.SelectedOfficeName, fpb: true);

                Reports.TestStep = "Validate the Scissors icon is disabled when the payee is FA office and fee is not Split with FA Office.";
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAGetAttribute("Src").Contains("smsfast/Images2/Cut1.jpg"), "Scissor image1 should be disabled.");
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAGetAttribute("Src").Contains("smsfast/Images2/Cut1.jpg"), "Scissor image2 should be disabled.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0050 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0051()
        {
            try
            {
                Reports.TestDescription = "BR_FM13688_002: Change in Corporate Parent of Owning Office and Payee(File).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0050, Please verify the results of REG0050.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0051 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0052()
        {
            try
            {
                Reports.TestDescription = "BR_FM13701_001__FM13705: Default to first property state for an FACC calculated fee.";
                #region DataSetup
                string overrideAmount = "65.00";
                string firstState = string.Empty;
                string stateName = "KS";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Navigate to the New Loan page and add one loan detail.
                Reports.TestStep = "Navigate to the New Loan page.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Navigate to the File Fee page, select All Fees and Calculate.
                Reports.TestStep = "Navigate to the File Fee page.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Check All Fees check box and click on the calculate fee button.";
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees.";
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.SelectTitleAndEndorsement(titleProduct: "ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.SelectRecordingFees(RecordingDoc: "Deed", pages: "3", ConsiderationAmount: "5000.00");
                FastDriver.CalculateFees.Next.FAClick();
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.Next.FAClick();

                string[] feeDetail1 = FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType(FeeDesc: "Eagle Lender Policy - 1", chargeTo: "Buyer", OverrideReason: "Prepaid Credit", OverrideAmount: overrideAmount);
                string[] feeDetail2 = FastDriver.CalculateFees.SelectFeeFromSummaryTable(row: 3, feeDescription: "Record Deed", chargeTo: "Seller");
                FastDriver.CalculateFees.SelectFeeFromSummaryTable(row: 4, feeDescription: "Record Trust Deed", chargeTo: "Seller");
                FastDriver.CalculateFees.SelectFeeFromSummaryTable(row: 5, feeDescription: "1064_Recording_Fee_Mortgage", chargeTo: "Seller");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the split fee disbursement page and assign the overriden fee between states.
                Reports.TestStep = "Navigate to the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                FastDriver.SplitFeeDisbursements.ClickNext();
                #endregion

                Reports.TestStep = "BR_FM13701_001: Default to first property state for an FACC calculated fee(overridden fee).";
                #region Verify that Override fee amount is assigned to the default state.
                Reports.TestStep = "Select the override fee and verify all override amount is assigned to the first property state.";
                FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, feeDetail1[0], 1, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                FastDriver.AssignFeetoPropertyStates.AssignState.FASetCheckbox(true);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                firstState = FastDriver.AssignFeetoPropertyStates.PropertyTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim();
                Support.AreEqual(overrideAmount, FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, firstState, 4, TableAction.GetText).Message.Trim(), "Verification of override amount is assigned to first state by default.");
                #endregion

                Reports.TestStep = " BR FM13701_002- Assign the fees to multiple properties when override exists.";
                #region Verify whether we are able to split the overidden fee between states.
                FastDriver.AssignFeetoPropertyStates.AssignFeeBetweenStates(feeName: feeDetail1[0], stateName: stateName, assignPer: "15");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = " BR FM13705 - Split the fee between states with $ amount and verfy the Split % is not calculated.";
                #region Navigate to Split Fee Disbursement, update split $ and verify Split % is not calculated.
                Reports.TestStep = "Navigate to the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Update the $ amount and verify that % is not calculated.";
                FastDriver.AssignFeetoPropertyStates.AssignFeeBetweenStates(feeName: feeDetail1[0], stateName: stateName, assignAmount: "30");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the Split Fee Disbursement, select the fee which is not overridden.
                Reports.TestStep = "Navigate to the Split Fee Disbursement";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Check the assign fee checkbox and radio buttons are disabled for the Fee which is not overridden.";
                FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, feeDetail2[0], 1, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.AssignState.IsEnabled(), "Assign fees between property states checkbox should be disabled.");
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.State1.IsEnabled(), "State1 radio button should be disabled.");
                Support.AreEqual(false, FastDriver.AssignFeetoPropertyStates.State2.IsEnabled(), "State2 radio button should be disabled.");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0052 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0053()
        {
            try
            {
                Reports.TestDescription = "BR_FM13701_002: Default to first property state for an FACC calculated fee(overridden fee).";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0052, Please verify the results of REG0052.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0053 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0056()
        {
            try
            {
                Reports.TestDescription = "ER2: User navigates to Split Fees/Assign State screen when no Fees are available for Split and State Assignment.";
                #region DataSetup
                string stateName = "KS";
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Navigate to the Split Fee Disbursement page and Verify the Warning message.
                Reports.TestStep = "User navigates to Split Fees/Assign State screen when no Fees are available for Split and no Fees are subject to State Assignment.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                msgContent = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Support.AreEqual("Fees are not available for Split. No Fees are subject to State Assignment.", msgContent, "Verifying Error Warning Message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0056 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0057()
        {
            try
            {
                Reports.TestDescription = "ER3: User navigates to Split Fees/Assign State screen when no Escrow Owning office exists on File(one property).";
                #region DataSetup
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File Without Escrow Owning Office.
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Create a Basic file without escrow owning office.";
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(GABCode: "HUDFLINSR1");
                FastDriver.QuickFileEntry.cbxServiceTitle.FASetCheckbox(true);
                FastDriver.QuickFileEntry.cbxServiceEscrow.FASetCheckbox(false);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to the Split Fee Disbursement page and Verify the Warning message.
                Reports.TestStep = "User navigates to Split Fees/Assign State screen when no Escrow Own office exists on File and there is only one distinct Property state on File.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                msgContent = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Support.AreEqual("Escrow Owning Office does not exist on the File. Fees cannot be Split. No change in State Assignment required as there is only one distinct Property state on File.", msgContent, "Verifying Error Warning Message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0057 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0058()
        {
            try
            {
                Reports.TestDescription = "ER4: User navigates to Split Fees/Assign State screen when no Escrow Owning office exists and no State Assignment.";
                #region DataSetup
                string stateName = "KS";
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File Without Escrow Owning Office.
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Create a Basic file with escrow owning office.";
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(GABCode: "HUDFLINSR1");
                FastDriver.QuickFileEntry.cbxServiceTitle.FASetCheckbox(true);
                FastDriver.QuickFileEntry.cbxServiceEscrow.FASetCheckbox(false);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.QuickFileEntry.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.QuickFileEntry.FormType_HUD.FAClick();
                }
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Navigate to the Split Fee Disbursement page and Verify the Warning message.
                Reports.TestStep = "User navigates to Split Fees/Assign State screen when no Escrow Own office exists on File and no Fees are subject to State Assignment.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                msgContent = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Support.AreEqual("Escrow Owning Office does not exist on the File. Fees cannot be Split. No Fees are subject to State Assignment.", msgContent, "Verifying Error Warning Message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0058 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0059()
        {
            try
            {
                Reports.TestDescription = "ER4: User navigates to Split Fees/Assign State screen when no Escrow Owning office exists and no State Assignment.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee for split from FPB and perform split.
                Reports.TestStep = "Click on New Button and add payee from the File production office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");

                Reports.TestStep = "Verify the error message when user enters the split amount without selecting the Payee.";
                FastDriver.SplitFeeDisbursements.Scissor1.FAClick();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.SetText, "10.00" + FAKeys.Tab);
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please select a Payee.", msgContent, "Verifying the error warning message.");

                Reports.TestStep = "Verify that split $ and Split% is reset to zero.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                Support.AreEqual("0.0000", FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 4, TableAction.GetText).Message.Trim(), "Split% after message.");
                Support.AreEqual("0.00", FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.GetText).Message.Trim(), "Split$ after message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0059 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0060()
        {
            try
            {
                Reports.TestDescription = "ER6: User attempts to selects the same payee from drop down which is already selected and split.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee for split from FAB and perform split.
                Reports.TestStep = "Click on New Button and add payee from the File Address office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");

                Reports.TestStep = "Perform the Split with newly added Payee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "20.00");
                #endregion

                #region Add one more payee and perform the split with previously added payee.
                Reports.TestStep = "Add One more payee with role Buyer.";
                FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "Buyer");

                Reports.TestStep = "Click on scissor image and select the previous payee again.";
                FastDriver.SplitFeeDisbursements.Scissor1.FAClick();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(3, 2, TableAction.SelectItemBySendkeys, newPayee + FAKeys.Tab);
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Payee is already selected.", msgContent, "Verifying the error warning message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0060 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0061()
        {
            try
            {
                Reports.TestDescription = "ER8_FD_06/ER09: When user checks the Edit Name Check Box and saves without Name./When the User enters an invalid e-Mail Address.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Select the Payee and Open the Payee details page.
                Reports.TestStep = "Select the newly added payee.";
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Check the Edit Name and save.";
                FastDriver.PayeeDetails.EditName.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();

                Reports.TestStep = "Click on Done button without entering the name and verify the error message.";
                FastDriver.BottomFrame.Done();
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Name field is required when Edit Name checkbox is selected.", msgContent, "Verifying the Error Warning Message.");
                #endregion

                Reports.TestStep = "ER9: When the user enters an invalid e-Mail address.";
                #region Uncheck the edit Name check box and check the edit check box.
                Reports.TestStep = "Uncheck Edit Name.";
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.EditName.FASetCheckbox(false);
                FastDriver.PayeeDetails.WaitForScreenToLoad();

                Reports.TestStep = "Check Edit.";
                FastDriver.PayeeDetails.Edit.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();

                Reports.TestStep = "Enter Invalid Email.";
                FastDriver.PayeeDetails.EmailAddress.FASetText("1234" + FAKeys.Tab);

                Reports.TestStep = "Validate the tool tip text for the invalid email address.";
                msgContent = FastDriver.PayeeDetails.EmailAddress.FAGetAttribute("title").ToString();
                Support.AreEqual(true, msgContent.Contains("Email address is invalid."), "Verifying the Help Text of email address field.");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0061 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0062()
        {
            try
            {
                Reports.TestDescription = "ER9: When the user enters an invalid e-Mail address.";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0061, Please verify the results of REG0061.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0062 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0063()
        {
            try
            {
                Reports.TestDescription = "ER10: User enters Split dollar amount greater than 100% of total fee.";
                Reports.StatusUpdate("This testmethod is already covered in REG0021 and BAT0003, Please verify the results for detailed report.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0063 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0064()
        {
            try
            {
                Reports.TestDescription = "ER17: In the Assign Fees to Property States screen, user clicks on Done button without splitting the fees.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add one more Property.
                this.AddNewPropertyState(StateName: "TX");
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
                this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: fee1BuyerCharge, Fee1SellerChrg: fee1SellerCharge, Fee2BuyerChrg: fee2BuyerCharge, Fee2SellerChrg: fee2SellerCharge);
                #endregion

                #region Add new Payee for split from FAB and perform split.
                Reports.TestStep = "Click on New Button and add payee from the File Address office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");

                Reports.TestStep = "Perform the split for the first fee between the payees.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitAmnt: "10.12");
                FastDriver.SplitFeeDisbursements.ClickNext();
                #endregion

                #region Move to assign fee to states page, check the assign state check box, Click on Done button and verify the error warning.
                Reports.TestStep = "Check the assign fee checkbox.";
                FastDriver.AssignFeetoPropertyStates.AssignState.FASetCheckbox(true);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the error message.";
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Fee has not been assigned between properties.", msgContent, "Verifying the error warning message.");

                Reports.TestStep = "Uncheck the Assign State check box and clic on done.";
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                FastDriver.AssignFeetoPropertyStates.AssignState.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0064 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0065()
        {
            try
            {
                Reports.TestDescription = "ER12: User decreases a Fee to less than total of the Fees transferred.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                string newPayee = string.Empty;
                string splitAmount = string.Empty;
                string acttotalFeeAmount = string.Empty;
                string msgContent = string.Empty;
                string stateName = "TX";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add one more Property.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the Active Disbursement page and transfer the fee.
                Reports.TestStep = "Navigate to Active Disbursement Summary page and verify for the pending fee.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.GetText).Message.Trim(), "Verifying the status of added fee.");

                Reports.TestStep = "Click on the fee transfer Button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickCancel();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.GetText).Message.Trim(), "Verifying the status of added fee.");
                #endregion

                #region Navigate to the Split fee disbursment page and Add new Payee for split from FAB.
                Reports.TestStep = "Navigate to the Split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Click on New Button and add payee from the File Address office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                #endregion

                #region Perform the split action for the fee between the added payees and verify the error warning.
                Reports.TestStep = "Click on Scissors button for First Fee.";
                FastDriver.SplitFeeDisbursements.Scissor1.FAClick();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Select Payee after fee is issued.";
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 2, TableAction.SelectItemBySendkeys, newPayee);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 4, TableAction.SetText, "10.00" + FAKeys.Tab);

                Reports.TestStep = "Verify the error warning message.";
                msgContent = FastDriver.WebDriver.HandleDialogMessage(timeout: 20);
                Support.AreEqual("You cannot decrease a fee to less than the total of the fees transfered.", msgContent, "Verifying the error warning message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0065 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0066()
        {
            try
            {
                Reports.TestDescription = "ER20: User enters Assign percentages such that the total of Assign percentages is greater than 100%.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                string newPayee = string.Empty;
                string msgContent = string.Empty;
                string stateName = "TX";
                string stateName1 = "VA";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                this.AddNewPropertyState(StateName: stateName1);
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region navigate to split fee disbursement, Click on Next button, and split the first fee between states with % more than 100.
                Reports.TestStep = "Navigate to the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Click on Next button.";
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Perform the split with first state with less than 100%.";
                FastDriver.AssignFeetoPropertyStates.AssignFeeBetweenStates(feeName: "New Home Rate (Title Only)", stateName: stateName, assignPer: "10.00");

                Reports.TestStep = "Perform the split fee with the second state such that total of split% should be more than 100.";
                FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, stateName1, 2, TableAction.Click);
                FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction(2, stateName1, 3, TableAction.SetText, "99" + FAKeys.Tab);

                Reports.TestStep = "Verify the error message.";
                msgContent = FastDriver.WebDriver.HandleDialogMessage(timeout: 20);
                Support.AreEqual("Total of assign percentages cannot be greater than 100%.", msgContent, "Verifying the error message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0066 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0069()
        {
            try
            {
                Reports.TestDescription = "FD_01: Work pane-Specific Buttons / Icons / Tool Tips-Payees and Split fees.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                string newPayee = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Navigate to Split fee disbursement page and verify the buttons.
                Reports.TestStep = "Navigate to Split Fee.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Validate the buttons are disabled when no fees are available.
                Reports.TestStep = "Validate the buttons are disabled when no fees are available.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.New.IsEnabled(), "Verifying that New button is disabled.");
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.Remove.IsEnabled(), "Verifying that Remove button is disabled.");
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.PayeeDetails.IsEnabled(), "Verifying that Payee Details button is disabled.");
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.CheckDetails.IsEnabled(), "Verifying that Check details button is disabled.");

                Reports.TestStep = "Verify Done/Reset/AutoSave buttons are available.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(true, FastDriver.BottomFrame.btnDone.IsDisplayed(), "Verifying that Done button is visible.");
                Support.AreEqual(true, FastDriver.BottomFrame.btnReset.IsDisplayed(), "Verifying that Reset button is visible.");
                Support.AreEqual(true, FastDriver.BottomFrame.btnAutoSave.IsDisplayed(), "Verifying that AutoSave button is visible.");
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate back to the Split fee and add one payee and verify buttons.
                Reports.TestStep = "Navigate to Split Fee.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Add One payee for split.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");

                Reports.TestStep = "Validate the Remove,CheckDetails button is enabled and Payee Details button is Disabled for payee without split fee.";
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.Remove.IsEnabled(), "Verifying that Remove button is Enabled.");
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.PayeeDetails.IsEnabled(), "Verifying that Payee Details button is disabled.");
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.CheckDetails.IsEnabled(), "Verifying that Check details button is enabled.");
                #endregion

                #region Perform the split fee, Select the Payee and Verify Buttons.
                Reports.TestStep = "Perform the split fee with %.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "12.00");

                Reports.TestStep = "Select the payee and Validate the Remove button is disabled and Payee Details button is enabled foe a payee with split fee.";
                FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, newPayee, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.SplitFeeDisbursements.Remove.IsEnabled(), "Verifying that Remove button is disabled.");
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.PayeeDetails.IsEnabled(), "Verifying that Payee details button is enabled.");
                #endregion

                #region Click on the Check details Button.
                Reports.TestStep = "Click on the Check Details button and Edit the check details.";
                FastDriver.SplitFeeDisbursements.CheckDetails.FAClick();
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.CheckDetailsDlg.Description.FASetText("Edited check details description.");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Edited Voucher information.");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                #endregion

                #region Select the payee, open payee details and validate the Find/Cancel/Done button.
                Reports.TestStep = "Open payee details of newly added payee.";
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Validate Find/Cancel/Done botton.";
                Support.AreEqual(false, FastDriver.PayeeDetails.Find.IsEnabled(), "Verifying Find button is enabled.");

                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(true, FastDriver.BottomFrame.btnDone.IsEnabled(), "Verifying Done button is enabled.");
                Support.AreEqual(true, FastDriver.BottomFrame.btnCancel.IsEnabled(), "Verifying Cancel button is enabled.");
                #endregion

                #region Update the Name for the payee information section.
                Reports.TestStep = "Update the Name for the payee information section.";
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.EditName.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.Name.FASetText("Attention1");
                #endregion

                #region NAvigate back to split fee disbursement page and open the payee details.
                Reports.TestStep = "Navigate back to Split Fee.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Select the payee and Click on Payee Details Button.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Validate changes are not saved on navigating away.";
                Support.AreEqual(false, FastDriver.PayeeDetails.EditName.IsSelected(), "Verify that edit name check box is not checked.");
                #endregion

                #region NAvigate to the Active disbursement summary page and issue the split fee.
                Reports.TestStep = "Navigate to the active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 6, TableAction.Click);

                Reports.TestStep = "Click on Print button.";
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.Delivery();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint();
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate back to split fee disbursement page and verify the check issued image.
                Reports.TestStep = "Navigate to split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();
                Support.AreEqual(true, FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, newPayee, 7, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").Exists(), "Verify Check issued image exists.");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(true, FastDriver.BottomFrame.btnDone.IsEnabled(), "Verifying Done button is enabled.");
                Support.AreEqual(true, FastDriver.BottomFrame.btnCancel.IsEnabled(), "Verifying Cancel button is enabled.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0069 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0070()
        {
            try
            {
                Reports.TestDescription = "FD_02: Work pane-Specific Buttons / Icons / Tool Tips-Framework.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = null;
                string splitAmount = null;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add Two Fees, Add a new Payee and  perform split  fees.
                this.AddFeesAndPerformSplitAction("New Home Rate (Title Only)", "New Home Rate Eagle Lender Policy-1", fee1BuyerCharge, fee1SellerCharge, fee2BuyerCharge, fee2SellerCharge, out newPayee, out splitAmount);
                #endregion

                #region Update the split % for the first fee, click on Reset button.
                Reports.TestStep = "Update the split % for the first fee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "20.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);

                Reports.TestStep = "Click on the Reset button.";
                FastDriver.BottomFrame.Reset();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Verify that data is reset to the previous split value.";
                Support.AreEqual("10.0000", FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 4, TableAction.GetText).Message.Trim(), "Verifying the Split% for the first fee.");
                Support.AreEqual("3.33", FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.GetText).Message.Trim(), "Verifying the Split$ for the first fee.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0066 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0071()
        {
            try
            {
                Reports.TestDescription = "FD_03: Work pane-Specific Buttons / Icons / Tool Tips-Framework.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string msgContent = string.Empty;
                string stateName = "TX";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the Split Fee Disbursement page, Add a new payee and Perform split for first fee.
                Reports.TestStep = "Navigate to the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Add a new Payee.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");

                Reports.TestStep = "Perform split action for the first fee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "12.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Navigate to split fee disbursement page and Click on next button, check assign state check box and navigate away from the page.
                Reports.TestStep = "Navigate to the Split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Click on Next button.";
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Check the assign fee checkbox.";
                FastDriver.AssignFeetoPropertyStates.AssignState.FASetCheckbox(true);
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();

                Reports.TestStep = "Directly click on done button.";
                FastDriver.BottomFrame.Done();
                msgContent = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Support.AreEqual("Exit without saving changes?", msgContent, "Verifying the warning message.");
                msgContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("All information will be erased for this new order. Do you wish to cancel this entry?", msgContent, "Verifying the warning message.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0071 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0072()
        {
            try
            {
                Reports.TestDescription = "FD_04: Assign Fees to Property States Screen.";
                #region DataSetup
                double fee1BuyerCharge = 11111111111.7;
                double fee1SellerCharge = 11111111111.7;
                double fee2BuyerCharge = 11111111111.7;
                double fee2SellerCharge = 0.00;
                string newPayee = string.Empty;
                string msgContent = string.Empty;
                string stateName = "TX";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File        
                CreateBasicFile();
                #endregion

                #region Navigate to the Property/Tax Info page and add new state.
                this.AddNewPropertyState(StateName: stateName);
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingRecordingFee("Monument Fee");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("Monument Fee", false, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                #endregion

                #region Navigate to the split fee disbursement page, click on next button and verify the total charges.
                Reports.TestStep = "Navigate to the split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.ClickNext();

                Reports.TestStep = "Verify the description ,total charge, retained amount for the fee1.";
                Support.AreEqual("11,111,111,111.70", FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction("Description", "Monument Fee", "Total Charge", TableAction.GetText).Message.Trim(), "Total Charge for the Fee1");
                Support.AreEqual("11,111,111,111.70", FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction("Description", "Monument Fee", "Retained Amount", TableAction.GetText).Message.Trim(), "Retained Amount for the Fee1");

                Reports.TestStep = "Verify the description ,total charge, retained amount for the fee1.";
                Support.AreEqual("22,222,222,223.40", FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Total Charge", TableAction.GetText).Message.Trim(), "Total Charge for the Fee2");
                Support.AreEqual("22,222,222,223.40", FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Retained Amount", TableAction.GetText).Message.Trim(), "Retained Amount for the Fee2");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0072 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0073()
        {
            try
            {
                Reports.TestDescription = "FD_05: Split Fee Disbursements Screen.";
                #region DataSetup
                double fee1BuyerCharge = 11111111111.7;
                double fee1SellerCharge = 11111111111.7;
                double fee2BuyerCharge = 11111111111.7;
                double fee2SellerCharge = 0.00;
                string newPayee = string.Empty;
                string msgContent = string.Empty;
                string payee2 = "Seller2Firstname Seller2Lastname / Seller2SpouseName Seller2Lastname";
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Second Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the Recording and Tax fee.";
                FastDriver.FileFees.AddFirstMatchingRecordingFee("Monument Fee");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("Monument Fee", false, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the Split Fee page, Add New Payee, Split the first fee with 100%.
                Reports.TestStep = "Navigate to the Split fee page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Add a New Payee";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");

                Reports.TestStep = "Split the first fee between the payees with 100%";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "100.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                #endregion

                #region Validate the Address,City, State and Zip for the added payee.
                Support.AreEqual("15441 94Th Avenue", FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction("Name", newPayee, "Address", TableAction.GetText).Message, "Verification of Payee Address.");
                Support.AreEqual("Orland Park", FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction("Name", newPayee, "City", TableAction.GetText).Message, "Verification of Payee Address City.");
                Support.AreEqual("IL", FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction("Name", newPayee, "State", TableAction.GetText).Message, "Verification of Payee Address State.");
                Support.AreEqual("60462", FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction("Name", newPayee, "Zip", TableAction.GetText).Message, "Verification of Payee Address Zip.");
                #endregion

                #region Add one more Payee with role seller and verify name is truncated.
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(Name: payee2);

                Reports.TestStep = "Verify seller is added to Payee Summary and the name is truncated.";
                string payee1 = FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(2, 1, TableAction.GetText).Message.Trim();

                Support.AreNotEqual(newPayee, payee2, "Verifying the name appearing in payee summary table is not full name.");
                Support.AreEqual(true, payee2.Replace("/", "and").Contains(newPayee), "Verifying the name appearing in payee summary table is not full name, it is truncated.");
                #endregion

                #region Validate that newly added payee name is truncated in payee dropdown as well.
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 2, TableAction.Click);
                Support.AreEqual("-----------------Select Payee-----------------" + payee1 + newPayee, FastDriver.SplitFeeDisbursements.Payee.FAGetAllTextFromSelect().Replace("|", string.Empty), "Validate that newly added payee name is truncated in payee dropdown as well");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0073 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0074()
        {
            try
            {
                Reports.TestDescription = "FD_06: Payee Search - Dialog.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                string newPayee = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create a Basic File
                CreateBasicFile();
                #endregion

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Click on New button.
                Reports.TestStep = "Navigate to Split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Click on the New botton.";
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                #endregion

                #region Field Validation of the Payee Details dailog.
                Reports.TestStep = "Validate GAB,FAB,Office and FPO exists in Payee Seacrh Dialog.";
                Support.AreEqual(true, FastDriver.PayeeSearchDlg.Office.IsEnabled(), "Verifying radio button for offices is enabled.");
                Support.AreEqual(true, FastDriver.PayeeSearchDlg.FileProductionOffices.IsEnabled(), "Verifying radio button for FBP is enabled.");
                Support.AreEqual(true, FastDriver.PayeeSearchDlg.OfficeAdressBook.IsEnabled(), "Verifying radio button for office address book is enabled.");
                Support.AreEqual(true, FastDriver.PayeeSearchDlg.Organization.IsEnabled(), "Verifying radio button for office address book is enabled.");
                #endregion

                #region Select the office radio button and verify the office address components.
                Reports.TestStep = "Select Office from Payee Search Dialog and verify the Office Name and Address.";
                FastDriver.PayeeSearchDlg.Office.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();

                Support.AreEqual("CA", FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "State", TableAction.GetText).Message, "Verification of office Address State.");
                Support.AreEqual("92707", FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Zip", TableAction.GetText).Message, "Verification of office Address Zip.");
                Support.AreEqual(AutoConfig.SelectedRegionName, FastDriver.PayeeSearchDlg.comboRegion.FAGetSelectedItem(), "Verifying the selected region name.");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                #endregion

                #region Again click on the New button and select the office from the File production office and verify address component.
                Reports.TestStep = "Again click on the New button and select the office from the File production office and verify address component.";
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();

                FastDriver.PayeeSearchDlg.FileProductionOffices.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();

                Support.AreEqual("First American", FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Address", TableAction.GetText).Message, "Verification of office Address State.");
                Support.AreEqual("CA", FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "State", TableAction.GetText).Message, "Verification of office Address State.");
                Support.AreEqual("92707", FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction("Office Name", AutoConfig.SelectedOfficeName, "Zip", TableAction.GetText).Message, "Verification of office Address Zip.");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "FD_07: Payee Details Screen.";

                #region Add one payee from the File address book and perform split for the fee.
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitAmnt: "10.00");
                #endregion

                #region Select the payee and open the payee details page.
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);

                Reports.TestStep = "Validate the Name IdCode and Address.";
                Support.AreEqual(false, FastDriver.PayeeDetails.GABcode.IsEnabled(), "Verifying id code field.");
                Support.AreEqual(false, FastDriver.PayeeDetails.NameB.IsEnabled(), "verifying the name field.");
                Support.AreEqual(false, FastDriver.PayeeDetails.Code1.IsEnabled(), "Verifying the Code1 field.");
                Support.AreEqual(true, FastDriver.PayeeDetails.Name1.IsEnabled(), "Verifying the Name1 field.");
                Support.AreEqual(true, FastDriver.PayeeDetails.Name2.IsEnabled(), "Verifying the Name2 field.");
                Support.AreEqual(true, FastDriver.PayeeDetails.Address1.IsEnabled(), "Verifying the Address1 field.");
                Support.AreEqual(true, FastDriver.PayeeDetails.Address2.IsEnabled(), "Verifying the Address2 field.");
                #endregion

                #region Max length verification for the name and payee reference field.
                Reports.TestStep = "Enter the Maximum characters for name and payee reference field.";
                FastDriver.PayeeDetails.EditName.FASetCheckbox(true);
                FastDriver.PayeeDetails.WaitForScreenToLoad();
                FastDriver.PayeeDetails.Name.FASetText("Entered more than 40chr characters for Name in Payee Details");
                FastDriver.PayeeDetails.PayeeReference.FASetText("Entered  maximum of 50chr characters for Reference");
                FastDriver.BottomFrame.Done();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Reopen the same payee detail and validate the field lenght.";
                FastDriver.SplitFeeDisbursements.OpenPayeeDetail(payeeName: newPayee);
                Support.AreEqual("Entered more than 40chr characters for Name in Payee Details", FastDriver.PayeeDetails.Name.FAGetValue(), "Maximum length of characters in Name.");
                Support.AreEqual("Entered  maximum of 50chr characters for Reference", FastDriver.PayeeDetails.PayeeReference.FAGetValue(), "Maximum length of characters in Payee reference.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0074 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0075()
        {
            try
            {
                Reports.TestDescription = "FD_07: Payee Details Screen.";
                Reports.StatusUpdate("This testmethod is clubbed with the REG0074, Please verify the results of REG0074.", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0075 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0076()
        {
            try
            {
                Reports.TestDescription = "FM3155_FM3159_ FM5280.";
                Reports.StatusUpdate("This BRs have already been covered in REG01", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0076 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0068_REG0077_PH()
        {
            try
            {
                Reports.TestDescription = "PlaceHolder Business Rule: FM5268_FM5486 - 1)Indicate Split Fees on Fee Entry with BackGround Color; 2)Report File's Title Agent Type to External Databases.";
                Reports.TestStep = "Fees on split should mark corresponding Fees the Total Charge Column as Pink Background Color.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
                //
                //
                Reports.TestStep = "Report File's Title Agent Type to External Databases";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch(Exception ex)
            {
                FailTest("Test case FMUC0068_REG0077_PH failed because: " + ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r10
        //UserStory                               : US#836303:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Split Fee
        //TestCase                                : 881716
        //Appended By/ Created By                 : Sheetal Gothi

        [TestMethod]
        public void FMUC0068_REG0078()
        {
            try
            {
                Reports.TestDescription = "Verify system is able to associate Hidden and Active office as payee with split fee.";
                #region DataSetup
                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                double fee2BuyerCharge = 33.33;
                double fee2SellerCharge = 44.44;
                string newPayee = string.Empty;
                string msgContent = string.Empty;

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                #endregion DataSetup

                #region UI Iteration
                #region Create a new office in ADM side if not created .

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Navigate to the Fee Summary Screen.";
                FastDriver.FeeList2.Open();

                #region Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).
                Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: "CD", feeType: "Title - Owners Policy", feeName: "New Home Rate (Title Only)");

                Reports.TestStep = "Check the Split with FA office checkbox.";
                FastDriver.FeeSetup.SplitWithFAOffice.FASetCheckbox(true);
                FastDriver.FeeSetup.GovtRep.FASetCheckbox(true);
                FastDriver.FeeSetup.RateType.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).

                #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                FastDriver.FeeList2.SelectFeeandClickEdit(formType: "CD", feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                Reports.TestStep = "Check the Split with FA office checkbox.";
                FastDriver.FeeSetup.SplitWithFAOffice.FASetCheckbox(true);
                FastDriver.FeeSetup.GovtRep.FASetCheckbox(true);
                FastDriver.FeeSetup.RateType.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.WaitScreenToLoad();
                #endregion Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.

                Reports.TestStep = "Verify if office is not created then create or just mark the office as Hidden.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it and verify office is marked as Hidden.";
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                    FastDriver.OfficeSummary.Edit.FAClick();
                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    if (!FastDriver.OfficeSetupOffice.ExceptionOffice.IsSelected())
                    {
                        FastDriver.OfficeSetupOffice.ExceptionOffice.FASetCheckbox(true);
                    }

                    if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                    {
                        FastDriver.BottomFrame.Done();
                    }
                    else
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);
                        FastDriver.BottomFrame.Done();
                    }
                }

                else if (!FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Test Automation Office"))
                {
                    #region Move into the region level of 1486 and Navigate to the Fee Summary.
                    Reports.TestStep = "Move to the region level.";
                    FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(BUID: AutoConfig.SelectedRegionBUID);


                    Reports.TestStep = "Navigate to the Fee Summary Screen.";
                    FastDriver.FeeList2.Open();
                    #endregion Move into the region level of 1486 and Navigate to the Fee Summary.

                    #region Edit fee for state assignment settings and rate type settings for New Home Rate (Title Only).
                    Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                    FastDriver.FeeList2.SelectFeeandClickEdit(formType: "CD", feeType: "Title - Owners Policy", feeName: "New Home Rate (Title Only)");

                    Reports.TestStep = "Check the Split with FA office checkbox.";
                    FastDriver.FeeSetup.SplitWithFAOffice.FASetCheckbox(true);
                    FastDriver.FeeSetup.RateType.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    FastDriver.FeeList2.WaitScreenToLoad();
                    #endregion

                    #region Edit fee for state assignment settings and rate type settings for New Home Rate Eagle Lender Policy-1.
                    Reports.TestStep = "Select the New Home Rate (Title Only) fee and click on Edit button.";
                    FastDriver.FeeList2.SelectFeeandClickEdit(formType: "CD", feeType: "Title - Lenders Policy", feeName: "New Home Rate Eagle Lender Policy-1");

                    Reports.TestStep = "Check the Split with FA office checkbox.";
                    FastDriver.FeeSetup.SplitWithFAOffice.FASetCheckbox(true);
                    FastDriver.FeeSetup.RateType.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    FastDriver.FeeList2.WaitScreenToLoad();
                    #endregion
                    FastDriver.OfficeSetupOffice.CreateNewOffice();
                }

                #endregion Create a new office in ADM side if not created.

                #region IIS Login
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");
                #endregion IIS Login

                #region Create New File
                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion Create New File

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Click on New button.
                Reports.TestStep = "Navigate to Split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Click on the New botton.";
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                #endregion

                #region Add new Payee for split from FPB and perform split.
                Reports.TestStep = "Click on New Button and add payee from the Office.";
                FastDriver.SplitFeeDisbursements.Open();
                Reports.TestStep = "Click on New Button and add payee from the Office.";
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromOffice(officeName: "JVR Office", status: "Active", fpb: false);

                Reports.TestStep = "Perform the Split action with the newly added payee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.BottomFrame.Done();

                #endregion Add new Payee for split from FPB and perform split.

                #region Mark the office Hidden
                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Verify if office is not created then create or just mark the office as Hidden.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an office and edit it.";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                //FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "1088", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.Hidden.IsSelected())
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    FastDriver.BottomFrame.Done();
                }

                #endregion Mark the office Hidden

                #region Assign the split fee payee as Hidden office
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                Reports.TestStep = "Verify the default state of the fields.";
                FastDriver.FileSearch.VerifyTheStateOfFields();

                Reports.TestStep = "Enter the file number.";
                FastDriver.FileSearch.SetFileNumber(fileNumber);
                Reports.TestStep = "Click the Find Now button.";
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(20000);

                Reports.TestStep = "Navigate to SPlit fee and select Hidden office as payee.";
                #endregion Assign the split fee payee as Hidden office

                #region Add second Fee.
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("New Home Rate Eagle Lender Policy-1", true, fee2BuyerCharge.ToString(), fee2SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion Add Second fee

                #region Navigate to Split Fee and Click on New button.
                Reports.TestStep = "Navigate to Split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Click on the New botton.";
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();

                Reports.TestStep = "Click on New Button and add Hidden payee from the Office.";
                FastDriver.SplitFeeDisbursements.Open();
                newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeeFromOffice(officeName: "SRT Test Automation Office", status: "Hidden", fpb: false);

                Reports.TestStep = "Perform the Split action with the newly added Hidden Office payee.";
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitPer: "10.00");
                FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
                FastDriver.BottomFrame.Done();
                #endregion Navigate to Split Fee and Click on New button.


                #endregion UI Iteration
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0068_REG0076 failed because: " + ex.Message);
                //FailTest(ex.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r10
        //UserStory                               : US#836303:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Split Fee
        //TestCase                                : 881715
        //Appended By/ Created By                 : Sheetal Gothi

        [TestMethod]
        public void FMUC0068_REG0079()
        {
            try
            {
                Reports.TestDescription = "Verify in Split fee Payee search dialog Display Drop shows Active and Hidden values.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                double fee1BuyerCharge = 11.11;
                double fee1SellerCharge = 22.22;
                string newPayee = string.Empty;
                string msgContent = string.Empty;
                #endregion

                #region UI Iteration
                #region Login
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");

                #endregion Login

                #region Create New File
                Reports.TestStep = "Create File (T and E) using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion Create New File

                #region Add first Fee.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, fee1BuyerCharge.ToString(), fee1SellerCharge.ToString());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Split Fee and Click on New button.
                Reports.TestStep = "Navigate to Split fee disbursement page.";
                FastDriver.SplitFeeDisbursements.Open();

                Reports.TestStep = "Click on the New botton.";
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                #endregion

                #region Verify Display status on Service Fee Payee Search.
                Reports.TestStep = "Select Office from Payee Search Dialog and verify the Display drop down values.";
                FastDriver.PayeeSearchDlg.Office.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.rbOfficeinPayeesearch.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Region);
                Support.AreEqual("Active", FastDriver.AddressBookSearchDlg.Display.FAGetSelectedItem().ToString(), "Active value selected by default in Title Production office selection window");

                Support.AreEqual("Active|Hidden", FastDriver.AddressBookSearchDlg.Display.FAGetAllTextFromSelect());
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.BottomFrame.Done();

                #endregion Verify Display status on service fee Payee Search.
                #endregion UI Iteration
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// This method logins to File side.
        /// </summary>
        /// <param name="UserName"> username string for login</param>
        /// <param name="Password">password for the corresponding username for login.</param>
        private void IISLOGIN(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Reports.TestStep = "Login into the file Side with user id: " + UserName + ".";
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        /// <summary>
        /// This method creates a basic file with all details.
        /// </summary>
        private void CreateBasicFile()
        {
            Reports.TestStep = "Create a new file.";
            CreateFileRequest fileRequest = new CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            fileRequest.File.TransactionTypeObjectCD = "SALE";
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
            Support.AreEqual("true", FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.ChangeOO, continueOnFailure: true).ToString(), true);
        }

        /// <summary>
        /// This method logins to ADM side.
        /// </summary>
        /// <param name="UserName"> username string for login</param>
        /// <param name="Password">password for the corresponding username for login.</param>
        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            MasterTestClass.PerformRequiredRegistrySettings();
            var website = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Reports.TestStep = "Login into the ADM Side with user id: " + UserName + ".";
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        /// <summary>
        /// This method creats the file with the basic details only i.e BUID, transaction type,business segment and state.
        /// </summary>
        /// <returns></returns>
        private CreateFileRequest GetDefaultFileCreated()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None
                            }
                        } 
                    },
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    } 
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                } 
                            } 
                        } 
                    },
                }
            };
            #endregion
        }

        /// <summary>
        /// This method Verifies the Fee disbursement page just after adding the Fees.
        /// </summary>
        /// <param name="Fee1BuyerChrg">Buyer charge added for fee1</param>
        /// <param name="Fee1SellerChrg">Seller charge added for fee1</param>
        /// <param name="Fee2BuyerChrg">Buyer charge added for fee2</param>
        /// <param name="Fee2SellerChrg">Seller charge added for fee2</param>
        private void ValidateFeeDisbrsmntAfterFeeAdd(double Fee1BuyerChrg, double Fee1SellerChrg, double Fee2BuyerChrg, double Fee2SellerChrg)
        {
            string acttotalFeeAmount = string.Empty;
            bool result = false;

            Reports.TestStep = "Navigate to Split Fee and verify the owning office.";
            FastDriver.SplitFeeDisbursements.Open();

            acttotalFeeAmount = FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction("Name", AutoConfig.SelectedOfficeName, "Total Amt.", TableAction.GetText).Message;
            string exptotalFeeCharge = string.Format("{0:0.00}", (Fee1BuyerChrg + Fee1SellerChrg + Fee2BuyerChrg + Fee2SellerChrg));
            result = acttotalFeeAmount.Equals(exptotalFeeCharge);
            Reports.StatusUpdate("Validation result for the total amount of entered fee: " + result.ToString(), result, expectedValue: exptotalFeeCharge, actualValue: acttotalFeeAmount);

            Reports.TestStep = "Validate the first fee total amount.";
            acttotalFeeAmount = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 3, TableAction.GetText).Message;
            exptotalFeeCharge = string.Format("{0:0.00}", (Fee1BuyerChrg + Fee1SellerChrg));
            result = acttotalFeeAmount.Equals(exptotalFeeCharge);
            Reports.StatusUpdate("Validation result for the total charges entered for first fee: " + result.ToString(), result, expectedValue: exptotalFeeCharge, actualValue: acttotalFeeAmount);

            Reports.TestStep = "Validate the second fee total amount.";
            acttotalFeeAmount = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 3, TableAction.GetText).Message;
            exptotalFeeCharge = string.Format("{0:0.00}", (Fee2BuyerChrg + Fee2SellerChrg));
            result = acttotalFeeAmount.Equals(exptotalFeeCharge);
            Reports.StatusUpdate("Validation result for the total charges entered for second fee: " + result.ToString(), result, expectedValue: exptotalFeeCharge, actualValue: acttotalFeeAmount);
        }

        /// <summary>
        /// This private method adds two fees, then adds one new payee and perform the split fee.
        /// </summary>
        /// <param name="feeName1">fee name 1 to be added</param>
        /// <param name="feeName2">fee name 2 to be added</param>
        /// <param name="Fee1BuyerChrg">buyer charge for fee1</param>
        /// <param name="Fee1SellerChrg">seller charge for fee1</param>
        /// <param name="Fee2BuyerChrg">buyer charge for fee2</param>
        /// <param name="Fee2SellerChrg">seller charge for fee2</param>
        private void AddFeesAndPerformSplitAction(string feeName1, string feeName2, double Fee1BuyerChrg, double Fee1SellerChrg, double Fee2BuyerChrg, double Fee2SellerChrg, out string newPayee, out string splitAmnt)
        {
            #region Add first Fee.
            Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
            FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee(feeName1);
            FastDriver.FileFees.EnterAmount(feeName1, true, Fee1BuyerChrg.ToString(), Fee1SellerChrg.ToString());
            FastDriver.BottomFrame.Done();
            #endregion

            #region Add Second Fee.
            Reports.TestStep = "Navigate to Fee Entry page and add the second Title/Escrow fee.";
            FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee(feeName2);
            FastDriver.FileFees.EnterAmount(feeName2, true, Fee2BuyerChrg.ToString(), Fee2SellerChrg.ToString());
            FastDriver.BottomFrame.Done();
            #endregion

            #region Navigate to Split Fee and Validate the total fee amount added at office level and at individual fee level.
            this.ValidateFeeDisbrsmntAfterFeeAdd(Fee1BuyerChrg: Fee1BuyerChrg, Fee1SellerChrg: Fee1SellerChrg, Fee2BuyerChrg: Fee2BuyerChrg, Fee2SellerChrg: Fee2SellerChrg);
            #endregion

            #region Add new Payee after clicking on the new button.
            newPayee = FastDriver.SplitFeeDisbursements.AddNewPayeefromFAB(roleName: "New Lender");
            #endregion

            #region Split the first fee between two payees and validate the amount is splitted correctly.
            Reports.TestStep = "Click on the scissors sign of first fee and split the fees between the two payees.";
            FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: newPayee, splitPer: "10.00");
            FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
            #endregion

            #region Split the Second fee between two payees and validate the amount is splitted correctly.
            Reports.TestStep = "Click on the scissor sign of Second fee and split the fees between the two payees.";
            FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: newPayee, splitAmnt: "4.44");
            FastDriver.SplitFeeDisbursements.ValidateTotalAmountForAddedPayee(addedPayee: newPayee);
            #endregion

            #region Verify that Next button is visible. If yes proceed according to that.
            if (FastDriver.SplitFeeDisbursements.Next.IsDisplayed())
            {
                Reports.TestStep = "Verify whether Next button is visible. If yes click on that and click on Done.";
                FastDriver.SplitFeeDisbursements.ClickNext();
                FastDriver.BottomFrame.Done();
            }
            #endregion

            #region Navigate back to the Spit fee disbursemnt page and validate the total amount for the office.
            FastDriver.SplitFeeDisbursements.Open();
            FastDriver.SplitFeeDisbursements.ValidateTotalAmountForOffice(office: AutoConfig.SelectedOfficeName);
            splitAmnt = string.Format("{0:0.00}", FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, newPayee, 6, TableAction.GetText).Message);
            #endregion
        }

        /// <summary>
        /// This function adds new proporty state to the file.
        /// </summary>
        /// <returns></returns>
        private void AddNewPropertyState(string StateName)
        {
            Reports.TestStep = "Navigate to the Property/Tax Info screen.";
            FastDriver.PropertiesSummary.Open();

            Reports.TestStep = "Click on New Button.";
            FastDriver.PropertiesSummary.New.FAClick();

            Reports.TestStep = "Click on the new button on General tab and add state " + StateName + ".";
            FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
            FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
            FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
            FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem(StateName);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Verify the warning message.";
            string msgContent = FastDriver.WebDriver.HandleDialogMessage();
            Support.AreEqual("Please associate appropriate fees with the property state by navigating to Split Fees/Assign State screen.", msgContent, "Verify the warning message.");
        }



        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
        #endregion
    }
}

