﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.Common;
using System.Collections.Generic;

namespace FileManagement
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class FMUC0101 : MasterTestClass
    {
        List<string> defaultProgramsList = new List<string>()
        {
            "VIP",
            "Strategic Markets"
        };

        List<string> selectedProgramsList = new List<string>();

        #region BAT
        [TestMethod]
        public void FMUC0101_BAT0001()
        {
            try
            {
                Reports.TestDescription = "FM8716: Multiple Sources.";
                selectedProgramsList = new List<string>();

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();


                Reports.TestStep = "Navigate to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Click Skip button on the Duplicate File Search page.";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Click Add or Remove Business Programs to Add Business Programs.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                //            BusinessSegment.FASelectItemBySendingKeys("Residential");

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                var availableProgramCntOnQFE = FastDriver.QuickFileEntry.BusinessProgramsTable.GetRowCount()-1;

                string program1;
                string program2;
                //add two business programs and verify the same.
                AddAndVerifyBusinessPrograms(out program1, out program2, availableProgramCntOnQFE);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void FMUC0101_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Deselect A Business program.";
                selectedProgramsList = new List<string>();

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                                                             
                Reports.TestStep = "Navigate to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Click Skip button on the Duplicate File Search page.";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Click Add or Remove Business Programs to add two Business Programs.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                var availableProgramCntOnQFE = FastDriver.QuickFileEntry.BusinessProgramsTable.GetRowCount()-1;


                string program1;
                string program2;
                //add two business programs and verify the same.
                AddAndVerifyBusinessPrograms(out program1, out program2, availableProgramCntOnQFE);
                availableProgramCntOnQFE = FastDriver.QuickFileEntry.BusinessProgramsTable.GetRowCount() - 1;

                Reports.TestStep = "Click Add Remove Programs button to deselect a business program.";
                FastDriver.QuickFileEntry.AddRemoveBusinessProgrammes.FAClick();

                Reports.TestStep = "Deselect the second business program, which was just seleted.";
                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();

                string removedProgram = "";

                if (FastDriver.SelectBusinessProgramsDlg.BPCheckBox2.IsSelected())
                {
                    FastDriver.SelectBusinessProgramsDlg.BPCheckBox2.FAClick();
                    removedProgram = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, 2, TableAction.GetText).Message.ToString();
                }

                //var addedProgram2 = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, 2, TableAction.GetText).Message.ToString();
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Verify if the removed business program is not present in the list of business programs on QFE page.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual("Sale w/Mortgage", FastDriver.QuickFileEntry.TransactionType.FAGetSelectedItem());

                bool removedProductFoundOnQFE = false;
                var rowCnt = FastDriver.QuickFileEntry.BusinessProgramsTable.GetRowCount();
                for (int i = 1; i <= rowCnt; i++)
                {
                    var businessProgramNameOnQFE = FastDriver.QuickFileEntry.BusinessProgramsTable.PerformTableAction(i, 1, TableAction.GetText).Message.ToString();
                    if (removedProgram.Trim() == businessProgramNameOnQFE.Trim())
                    {
                        Reports.StatusUpdate("The business program removed on 'Select Business Program' page is found in the business program list on QFE !", false);
                        removedProductFoundOnQFE = true;
                        break;
                    }
                }

                if (!removedProductFoundOnQFE)
                {
                    Reports.StatusUpdate("The business program removed on 'Select Business Program' page is not found in the business program list on QFE !", true);
                    Support.AreEqual((availableProgramCntOnQFE-1).ToString(), (FastDriver.QuickFileEntry.BusinessProgramsTable.GetRowCount()-1).ToString());
                }
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion


        #region Regression
        [TestMethod]
        public void FMUC0101_REG0001()
        {
            try
            {
                //string bankAccountNumber;
                Reports.TestDescription = "FM8716: Multiple Sources.";
                selectedProgramsList = new List<string>();

                SelectAndAssignProgramsToSelectOfficeAndGAB();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void FMUC0101_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM8716_FM8727: Change Business Organization on New Loan.";
                selectedProgramsList = new List<string>();

                SelectAndAssignProgramsToSelectOfficeAndGAB();

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();


                Reports.TestStep = "Navigate to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Click Skip button on the Duplicate File Search page.";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                if(!FastDriver.QuickFileEntry.cbxServiceTitle.IsSelected())
                {
                    FastDriver.QuickFileEntry.cbxServiceTitle.FAClick();
                }
                if (!FastDriver.QuickFileEntry.cbxServiceEscrow.IsSelected())
                {
                    FastDriver.QuickFileEntry.cbxServiceEscrow.FAClick();
                }

                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);


                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(@"250");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Verify the Business programs on File Homepage.";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[0], 1, TableAction.Click);

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[1], 1, TableAction.Click);



                Reports.TestStep = "Enter a new lender on New Loan page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.LoanDetailsGABcode.FASetText(@"123");

                FastDriver.NewLoan.LoanDetailsFind.FAClick();


                Reports.TestStep = "Verify the Business programs on File Homepage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[0], 1, TableAction.Click);

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[1], 1, TableAction.Click);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0101_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM8729: Add Business Organization to New Loan - i.e. check business programs on File Homepage with and without a new lender.";
                selectedProgramsList = new List<string>();

                SelectAndAssignProgramsToSelectOfficeAndGAB();

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();


                Reports.TestStep = "Navigate to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Click Skip button on the Duplicate File Search page.";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                if (!FastDriver.QuickFileEntry.cbxServiceTitle.IsSelected())
                {
                    FastDriver.QuickFileEntry.cbxServiceTitle.FAClick();
                }
                if (!FastDriver.QuickFileEntry.cbxServiceEscrow.IsSelected())
                {
                    FastDriver.QuickFileEntry.cbxServiceEscrow.FAClick();
                }

                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);


                //FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(@"250");
                //FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Verify the Business programs when no lender is added.";
                FastDriver.FileHomepage.WaitForScreenToLoad();

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[0], 1, TableAction.Click);

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[1], 1, TableAction.Click);



                Reports.TestStep = "Enter a new lender on New Loan page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.LoanDetailsGABcode.FASetText(@"250");

                FastDriver.NewLoan.LoanDetailsFind.FAClick();


                Reports.TestStep = "Verify the Business programs on File Homepage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[0], 1, TableAction.Click);

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[1], 1, TableAction.Click);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void FMUC0101_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM9778_FM9779_1: On starter/ref copy default business programs automatically to the target file.";
                selectedProgramsList = new List<string>();


                /*****************************TEST PRE-REQUISITE BLOCK**************************/
                Reports.StatusUpdate("Beginning of the pre-requisites block !", true);
                Reports.TestStep = "Perform pre-requisites by adding programs from ADM. First, login to ADM.";
                LoginToADM();


                Reports.TestStep = "Select the specified Region alone. No associated Offices would be selected.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("@1486");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Add some business programs.";
                FastDriver.LeftNavigation.Navigate<RegionalBusinessPrograms>("Home>System Maintenance>Business Program Setup>Maintain Regional Business Programs").WaitForScreenToLoad();

                FastDriver.RegionalBusinessPrograms.AddRemove.FAClick();
                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();


                Reports.TestStep = "Select business programs from the available list.";
                SelectBusinessPrograms();

                Reports.TestStep = "Click Done button on Select Business Programs dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.StatusUpdate("End of the pre-requisites block !", true);
                //***************************END OF THE PRE-REQUISITE PART*************************************

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the target file for copying another file contents to.";
                var fileNumber1 = CreateBasicFile();

                Reports.TestStep = "Create source file through UI. First, navigate to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Click Skip button on the Duplicate File Search page.";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("123");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                if (!FastDriver.QuickFileEntry.cbxServiceTitle.IsSelected())
                {
                    FastDriver.QuickFileEntry.cbxServiceTitle.FAClick();
                }
                if (!FastDriver.QuickFileEntry.cbxServiceEscrow.IsSelected())
                {
                    FastDriver.QuickFileEntry.cbxServiceEscrow.FAClick();
                }

                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Get the file number.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                var fileNumber2 = FastDriver.FileHomepage.FileNum.FAGetValue();


                Reports.TestStep = "Verify a minimum of three business programs exist on File Homepage.";
                var nuumberOfPrograms = FastDriver.FileHomepage.BusinessProgramsTable.GetRowCount();

                Reports.StatusUpdate("Are there a minimum of three business programs exist ?", nuumberOfPrograms >= 3);

                Reports.TestStep = "Copy All File Items.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();


                FastDriver.StarterReference.StarterFileNumber.FASetText(fileNumber1);

                if (!FastDriver.StarterReference.AllFileItems.IsSelected())
                {
                    FastDriver.StarterReference.AllFileItems.FAClick();
                }


                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                Playback.Wait(35000);


                Reports.TestStep = "Verify the Business programs on File Homepage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[0], 1, TableAction.Click);

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[1], 1, TableAction.Click);

                Reports.TestStep = "Click on History button.";
                FastDriver.FileHomepage.History.FAClick();
                FastDriver.BusinessProgramsHistoryDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Action is added.";
                var programName = FastDriver.BusinessProgramsHistoryDlg.BusinessProgramsHistory.PerformTableAction(5, selectedProgramsList[0], 1, TableAction.GetText).Message;
                Support.AreEqual("Added", programName);

                programName = FastDriver.BusinessProgramsHistoryDlg.BusinessProgramsHistory.PerformTableAction(5, selectedProgramsList[1], 1, TableAction.GetText).Message;
                Support.AreEqual("Added", programName);

                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2000);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }




        [TestMethod]
        public void FMUC0101_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM9778_FM9779_2: On starter/ref copy default business programs automatically to the target file.";

                selectedProgramsList = new List<string>();

                /*****************************TEST PRE-REQUISITE BLOCK**************************/
                Reports.StatusUpdate("Beginning of the pre-requisites block !", true);
                Reports.TestStep = "Perform pre-requisites by adding programs from ADM. First, login to ADM.";
                LoginToADM();


                Reports.TestStep = "Select the specified Region alone. No associated Offices would be selected.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("@1486");
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Add some business programs.";
                FastDriver.LeftNavigation.Navigate<RegionalBusinessPrograms>("Home>System Maintenance>Business Program Setup>Maintain Regional Business Programs").WaitForScreenToLoad();

                FastDriver.RegionalBusinessPrograms.AddRemove.FAClick();
                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();


                Reports.TestStep = "Select business programs from the available list.";
                SelectBusinessPrograms();

                Reports.TestStep = "Click Done button on Select Business Programs dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.StatusUpdate("End of the pre-requisites block !", true);
                //***************************END OF THE PRE-REQUISITE PART*************************************

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the target file for copying another file contents to.";
                var fileNumber1 = CreateBasicFile();

                Reports.TestStep = "Create source file through UI. First, navigate to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Click Skip button on the Duplicate File Search page.";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("123");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                if (!FastDriver.QuickFileEntry.cbxServiceTitle.IsSelected())
                {
                    FastDriver.QuickFileEntry.cbxServiceTitle.FAClick();
                }
                if (!FastDriver.QuickFileEntry.cbxServiceEscrow.IsSelected())
                {
                    FastDriver.QuickFileEntry.cbxServiceEscrow.FAClick();
                }

                FastDriver.QuickFileEntry.PropertyState.FASelectItem(@"CA");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Get the file number.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                var fileNumber2 = FastDriver.FileHomepage.FileNum.FAGetValue();


                Reports.TestStep = "Verify a minimum of three business programs exist on File Homepage.";
                var nuumberOfPrograms = FastDriver.FileHomepage.BusinessProgramsTable.GetRowCount();

                Reports.StatusUpdate("Are there a minimum of three business programs exist ?", nuumberOfPrograms >= 3);

                Reports.TestStep = "Copy All File Items.";
                FastDriver.LeftNavigation.Navigate<StarterReference>(@"Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();


                FastDriver.StarterReference.StarterFileNumber.FASetText(fileNumber1);

                if (!FastDriver.StarterReference.SelectFileItems.IsSelected())
                {
                    FastDriver.StarterReference.SelectFileItems.FAClick();
                }

                if (!FastDriver.StarterReference.BusinessSource.IsSelected())
                {
                    FastDriver.StarterReference.BusinessSource.FAClick();
                }


                Reports.TestStep = "Click on copy now button.";
                FastDriver.StarterReference.CopyNow.FAClick();
                Playback.Wait(35000);


                Reports.TestStep = "Verify the Business programs on File Homepage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[0], 1, TableAction.Click);

                FastDriver.FileHomepage.BusinessProgramsTable.PerformTableAction(1, selectedProgramsList[1], 1, TableAction.Click);



                ////******?????*************/
                Reports.TestStep = "Click on History button.";
                FastDriver.FileHomepage.History.FAClick();
                FastDriver.BusinessProgramsHistoryDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Action is added.";
                var programName = FastDriver.BusinessProgramsHistoryDlg.BusinessProgramsHistory.PerformTableAction(5, selectedProgramsList[0], 1, TableAction.GetText).Message;
                Support.AreEqual("Added", programName);

                programName = FastDriver.BusinessProgramsHistoryDlg.BusinessProgramsHistory.PerformTableAction(5, selectedProgramsList[1], 1, TableAction.GetText).Message;
                Support.AreEqual("Added", programName);

                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2000);
                ////************??????????**********/
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0101_REG0006()
        {
            try
            {
                Reports.TestDescription = "FD: Hotkey action";
                selectedProgramsList = new List<string>();

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Navigate to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();

                Reports.TestStep = "Click Skip button on the Duplicate File Search page.";
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Check if QuickFileEntry page has loaded.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Press ALT+M hotkey to open Selet Business Programs dialog.";
                //FastDriver.QuickFileEntry.AddRemoveBusinessProgrammes.
                Keyboard.SendKeys("%M");

                //Keyboard.SendKeys("{W}", ModifierKeys.Alt); //why this line shows up syntax error, while the same is fine in FMUC0095-Duplicate File Search.cs ?
                //Keyboard.SendKeys("{M}",ModifierKeys.Alt);//, ModifierKeys.Alt);

                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();
                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, defaultProgramsList[0], 2, TableAction.Click);
                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, defaultProgramsList[1], 2, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        #endregion


        #region Private Methods

        private void AddProblemLogsForSearchVendor(bool navigateToSummaryThruDone = true)
        {
            Reports.TestStep = "Navigate to Search Vendor.";
            FastDriver.LeftNavigation.Navigate<SearchVendor>(@"Home>Order Entry>Search Vendor").WaitForScreenToLoad();

            FastDriver.SearchVendor.GABcode.FASetText(@"254");

            FastDriver.SearchVendor.Find.FAClick();
            Playback.Wait(2000);

            FastDriver.SearchVendor.VenderDetailsConfirmDate.FASetText(@"07-22-2012");

            FastDriver.SearchVendor.VenderDetailsProductionProcess.FASelectItem(@"Amend");

            FastDriver.SearchVendor.VenderDetailsCost.FASetText(@"40");

            FastDriver.SearchVendor.Comments.FASetText(@"Testsearchvendor");

                        

            FastDriver.SearchVendor.ProblemLogAddRemove.FAClick();


            Reports.TestStep = "To select the first problem log.";
            FastDriver.ProblemListDlg.WaitForScreenToLoad();

            if (!FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, 1, TableAction.GetCell).Element.IsSelected())
            {
                FastDriver.ProblemListDlg.ProblemTable.PerformTableAction(2, 1, TableAction.Click);
            }

            Reports.TestStep = "Click on Done in dialog box.";
            FastDriver.DialogBottomFrame.ClickDone();

            FastDriver.SearchVendor.WaitForScreenToLoad();
            FastDriver.SearchVendor.CommentsSave.FAClick();

            var message = FastDriver.WebDriver.HandleDialogMessage();
            if (message != "No dialog present")
            {
                Reports.StatusUpdate("Is this an expected Alert ?", true);
            }

            if (navigateToSummaryThruDone)
            {

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that search vendor is added.";
                FastDriver.SearchVendorSummary.WaitForScreenToLoad();

                FastDriver.SearchVendorSummary.SearchVendorSummaryTable.PerformTableAction(2, "Ctx Mortgage Company", 2, TableAction.Click);
            }
        }

        private string CreateBasicFile()
        {

            var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

            Reports.TestStep = "Create File using web service.";
            var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);

            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            return fileNumber;
            //FileNo = FileService.GetFilesByFileNum(fileNumber.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;
        }

        private void SelectAndAssignProgramsToSelectOfficeAndGAB()
        {
            Reports.TestStep = "Login to ADM.";
            LoginToADM();


            Reports.TestStep = "Select the specified Region alone. No associated Offices would be selected.";
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("@1486");
            FastDriver.HomePage.WaitForHomeScreen();

            Reports.TestStep = "Add some business programs.";
            FastDriver.LeftNavigation.Navigate<RegionalBusinessPrograms>("Home>System Maintenance>Business Program Setup>Maintain Regional Business Programs").WaitForScreenToLoad();

            FastDriver.RegionalBusinessPrograms.AddRemove.FAClick();
            FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();


            Reports.TestStep = "Select business programs from the available list.";

            //int addedProgramCnt = 0;


            //this block selects any two programs which are not yet selected.
            /*for (int i = 0; i <= programCnt; i++)
            {
                IWebElement chkElement = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.XPath("./span/span/input"));
                if (!chkElement.IsSelected())
                {
                    chkElement.FAClick();
                    var addedProgramName = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(i,2,TableAction.GetText).Message;
                    newlyAddedProgramsList.Add(addedProgramName);
                    addedProgramCnt++;
                }
                if(addedProgramCnt==2)
                {
                    break;
                }
            }*/

            if (SelectBusinessPrograms())
            {
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select the business program to assign it to an office.";
                FastDriver.LeftNavigation.Navigate<AssignBusinessPrograms>("Home>System Maintenance>Business Program Setup>Assign Office Business Programs").WaitForScreenToLoad();

                Reports.TestStep = "Select the first of the newly added busines programs.";
                AssignBusinessProgramsToOffices(selectedProgramsList[0]);

                Reports.TestStep = "Select the second busines program in the list.";
                AssignBusinessProgramsToOffices(selectedProgramsList[1]);


                Reports.TestStep = "Add a business program to the selected GAB Code.";
                AddBusinessProgramToSelectGAB("248", selectedProgramsList[0]);

                Reports.TestStep = "Add the second business program in the list to another GAB Code.";
                AddBusinessProgramToSelectGAB("250", selectedProgramsList[1]);

            }
        }

        private bool SelectBusinessPrograms()
        {
            try
            {
                selectedProgramsList = new List<string>();
                int counter = 0;
                int programCnt = FastDriver.SelectBusinessProgramsDlg.BPTable.GetRowCount();
                for (int i = 1; i <= programCnt; i++)
                {
                    var program = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(i, 2, TableAction.GetText).Message;
                    if (program.Trim().Equals(defaultProgramsList[0]) || program.Trim().Equals(defaultProgramsList[1]))
                    {
                        FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(i, 1, TableAction.On);
                        selectedProgramsList.Add(program);
                        counter++;
                    }
                    if (counter == 2)
                    {
                        break;
                    }
                }

                if (counter == 2)
                {
                    Reports.StatusUpdate("Added two default programs successfully !", true);
                }
                else
                {
                    AddNonDefaultProgramsConditionally(programCnt, counter);
                }

                return true;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception occurred while adding default programs ! Message :" + ex.Message, false);
                return false;
            }
        }

        private bool AddNonDefaultProgramsConditionally(int totalProgramCnt, int addedProgramCnt)
        {
            try
            {
                /* for (int i = 1; i <= totalProgramCnt; i++)
                 {
                     IWebElement chkElement = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.XPath("./span/span/input"));
                     if (!chkElement.IsSelected())
                     {
                         chkElement.FAClick();
                         var program = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(i, 2, TableAction.GetText).Message;
                         selectedProgramsList.Add(program);
                         addedProgramCnt++;
                     }
                     if (addedProgramCnt == 2)
                     {
                         break;
                     }
                 }*/
                selectedProgramsList = new List<string>();
                for (int i = 1; i <= 2; i++)
                {
                    FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(i, 1, TableAction.On);
                    var program = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(i, 2, TableAction.GetText).Message;
                    selectedProgramsList.Add(program);
                }
                Reports.StatusUpdate("Added the first two programs in the list !", true);
                return true;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception occurred while adding non-default programs that were deselected !\r\n Function Point : AddNonDefaultProgramsConditionally().\r\n Message :" + ex.Message, false);
                return false;
            }
        }


        private void AssignBusinessProgramsToOffices(string program)
        {
            try
            {
                FastDriver.AssignBusinessPrograms.BusinessProgramTable.PerformTableAction(1, program, 1, TableAction.Click);
                FastDriver.AssignBusinessPrograms.AssigntoOffices.FAClick();

                Reports.TestStep = "Select the office to associate from the Select Office dialog.";
                FastDriver.SelectOfficeDlg.WaitForScreenToLoad();

                FastDriver.SelectOfficeDlg.Clear.FAClick();
                //Playback.Wait(2000);

                FastDriver.SelectOfficeDlg.OfficeTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 1, TableAction.On);

                FastDriver.SelectOfficeDlg.Select.FAClick();

                FastDriver.AssignBusinessPrograms.WaitForScreenToLoad();
                Reports.StatusUpdate("Successfully associated office to program '" + program + "'", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception occurred while associating office to program '" + program + "'. Exception :" + ex.Message, false);
            }
        }

        private void AddBusinessProgramToSelectGAB(string GABCode, string program)
        {
            try
            {
                Reports.TestStep = "Navigate to Address Book page ==> search for a GAB and edit it.";
                FastDriver.AddressBookSearch.EditGAB(GABCode);
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Click 'Add/Remove' button to add a business program.";
                FastDriver.BusinessPartyOrganizationSetUp.BusinessProgramAddRemove.FAClick();

                Reports.TestStep = "Add one of the previously selected business programs to the selected GAB code.";
                FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();
                FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, program, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                Reports.StatusUpdate("Successfully associated business program '" + program + "' to GAB Code '" + GABCode + "'", true);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception occurred while adding business program '" + program + "' to GAB Code '" + GABCode + "'. Exception :" + ex.Message, false);
            }
        }

        private void AddAndVerifyBusinessPrograms(out string addedProgram1, out string addedProgram2, int availableProgramCntOnQFE)
        {
            Reports.TestStep = "Click Add Remove Programs button.";
            FastDriver.QuickFileEntry.AddRemoveBusinessProgrammes.FAClick();

            Reports.TestStep = "Select two business programs on Select Business Programs dialog.";
            FastDriver.SelectBusinessProgramsDlg.WaitForScreenToLoad();
            FastDriver.SelectBusinessProgramsDlg.BPCheckBox1.FAClick();
            addedProgram1 = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(1, 2, TableAction.GetText).Message.ToString();
            FastDriver.SelectBusinessProgramsDlg.BPCheckBox2.FAClick();
            addedProgram2 = FastDriver.SelectBusinessProgramsDlg.BPTable.PerformTableAction(2, 2, TableAction.GetText).Message.ToString();
            FastDriver.DialogBottomFrame.ClickDone();


            Reports.TestStep = "Verify added business programs.";
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            Support.AreEqual("Sale w/Mortgage", FastDriver.QuickFileEntry.TransactionType.FAGetSelectedItem());
            FastDriver.QuickFileEntry.BusinessProgramsTable.PerformTableAction(1, addedProgram1, 1, TableAction.Click);
            FastDriver.QuickFileEntry.BusinessProgramsTable.PerformTableAction(1, addedProgram2, 1, TableAction.Click);

            availableProgramCntOnQFE += 2;
            Support.AreEqual(availableProgramCntOnQFE.ToString(), (FastDriver.QuickFileEntry.BusinessProgramsTable.GetRowCount()-1).ToString());

        }

        private void LoginToADM()
        {
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            }
            catch (Exception ex)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }



        private void LoginToIIS(bool IsSecondUserToUse = false)
        {
            #region data setup
            //string credentials = ""
            Credentials credentials;
            if (IsSecondUserToUse)
            {
                credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
            }
            else
            {
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            }
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            catch (Exception ex)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }



        #region File Creation

        private string CreateFile(bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = BuildCreateFileRequest();
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch
            {
                return "";
            }
            return fileNumber;
        }


        private CreateFileRequest BuildCreateFileRequest()
        {
            var x = new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,

                #region File
                File = new File()
                {
                    SalesPriceAmount = 5000,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "COMMERCIAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,


                    BusinessParties = new FileBusinessParty[] 
                    { 
                        
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                    },


                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            
                            Taxes = new Taxes[]
                            {
                                new Taxes()
                                {
                                     APN = "Prop1APN1",
                                },
                                new Taxes()
                                {
                                     APN = "9845012345",
                                }
                            },
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                    
                                } 
                            } 
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1SpouLastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2SpouLastname"
                        }
                    },

                    FileNotes = new FileNote[] 
                    { 
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
                #endregion
            };


            return x;
        }
        #endregion

        #endregion


     /*   [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }*/
    }
}
