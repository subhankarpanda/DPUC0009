﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace FileManagement
{
    [CodedUITest]

    public class FMUC0112 : MasterTestClass
    {

        #region BAT

        [TestMethod]
        public void FMUC0112_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Main Course: Login to the FAST Transactions System / View of New Exchange File Entry- Detail Tab";

                Reports.TestStep = "Log in to FAST ADM and select Exchange/Expresso region";
                FALogin(AutoConfig.FASTAdmURL, AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12385");

                #region Data Setup
                var employee = new EmployeeSearchParameters
                {
                    LoginName = "fastts\\fastqa01"
                };
                #endregion

                Reports.TestStep = "Set up " + employee.LoginName + "as Exchange Assistance & Exchange Officer";
                FastDriver.LeftNavigation.Navigate<EmployeeSearch>("Home>System Maintenance>Employee Setup").WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchEmployee(employee);
                FastDriver.EmployeeSearch.EditEmployee(employee.LoginName);
                FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Exchange Assistant");
                FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Exchange Officer");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();
                
                Reports.TestStep = "Main Course: Login to the FAST Transactions System: Logging in to Exchange Automation Region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Main Course: Login to the FAST Transactions System: Verify for 1031 Exchange, Exchange File Entry menu items";
                Support.AreEqual(true, FastDriver.LeftNavigation.CanNavigateTo<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry"), "Verifying use is able to access Exchange File Entry screen");
                
                Reports.TestStep = "View of New Exchange File Entry- Detail Tab: Verify Exchange File Entry Tabs";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad();
                string[] tabNames = { "Detail", "Parties", "Trans Summary", "Relinquished", "Replacement", "EAT Acquisition", "EAT Disposition" };
                foreach(string tabName in tabNames)
                {
                    Support.AreEqual(true.ToString(), FastDriver.ExchangeFileEntry.Tab(tabName).IsDisplayed().ToString(), "Verify tab " + tabName + " is displayed");
                }
                
                Reports.TestStep = "View of New Exchange File Entry- Detail Tab: verify Service, Business, Products";
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.Service.IsEnabled(), "Verify Service Checkbox is disabled");
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.BusinessSegment.IsEnabled(),"Verify Business Segment Dropdown is disabled");
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.Product.IsEnabled(), "Verify Product Dropdown is disabled");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransactionType.FAGetAllTextFromSelect(", ").Contains("Delayed, Reverse / Construction"), "Verifying Transaction Dropdown options");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedItem().Contains("QA Automation Office Expresso"), "Verify Office default selection");
                
                Reports.TestStep = "View of New Exchange File Entry- Detail Tab: Exchange officer and Exchange Assistant dropdown list contains the name of the Exchange officer and Exchange Assistant as setup in Employee Setup screen (Admin side).  ";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ExchangeOfficer.FAGetText().Contains("FASTQA01"), "Verifying Exchange Officer is contained in dropdown" );
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ExchangeAssistant.FAGetText().Contains("FASTQA01"), "Verifying Exchange Assistant is contained in dropdown");

                Reports.TestStep = "View of New Exchange File Entry- Detail Tab: Date grid";
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.DeadLine45thDay.IsEnabled(), "Verify 45th day Dealine is disabled");
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.DeadLine180thDay.IsEnabled(), "Verify 180th day Deadline is disabled");
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.FirstCOEDate.IsEnabled(), "Verify First COE date deadline is disabled");
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.DayofWeek45thDay.IsEnabled(), "Verify 45th Day of the Week is disabled");
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.DayofWeek180thDay.IsEnabled(), "Verify 180th Day of the Week is disabled");
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.DaysLeft45thDay.IsEnabled(), "Verify 45th Days left is disabled");
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.DaysLeft180thDay.IsEnabled(), "Verify 180th Days left is disabled");

                Reports.TestStep = "View of New Exchange File Entry- Detail Tab: Taxpayer Grid, Add a New Tax payer by clicking on Add new Button";
                FastDriver.ExchangeFileEntry.TaxPayerAddNew.FAClick();
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DetailsTaxPayerTable.GetRowCount().Equals(2), "Verifying Tax payer Table after adding a new tax payer ( Husband, Wire or Individual)");

                Reports.TestStep = "View of New Exchange File Entry- Detail Tab: Taxpayer Grid, Add a New Tax payer by clicking on New Search Button";
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();

                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DetailsTaxPayerTable.GetRowCount().Equals(3), "Verifying Tax payer Table after adding a new tax payer using GAB");

                Reports.TestStep = "View of New Exchange File Entry- Detail Tab: Taxpayer Grid, Remove a Tax Payer";
                FastDriver.ExchangeFileEntry.DetailsTaxPayerTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ExchangeFileEntry.TaxPayerRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DetailsTaxPayerTable.GetRowCount().Equals(2), "Verifying Tax payer Table after removing a tax payer");

                Reports.TestStep = "View of New Exchange File Entry- Detail Tab: Note Grid";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.NoteType.FAGetAllTextFromSelect(", ").Contains("Exchange Delayed, Exchange Reverse"), "Veryfing Note type contains Exchange Delayed as option");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0112_BAT0002()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 1:  Creating New Exchange File – Detail Tab";
                
                Reports.TestStep = "Alternate Course 1:  Creating New Exchange File – Detail Tab: Logging in to Exchange Automation Region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Alternate Course 1: Navigate to Exchange File Entry";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();

                Reports.TestStep = "Alternate Course 1: User enters the file number manually";
                FastDriver.ExchangeFileEntry.AutoNumber.FASetCheckbox(false);
                string fileNumber = Support.RandomString("ANANAN");
                FastDriver.ExchangeFileEntry.FileNo.FASetText(fileNumber + FAKeys.Tab);
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.FileNo.FAGetValue().Contains(fileNumber), "Verify FileNumber Input when edited and Auto Number is not checked");
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad();
                
                Reports.TestStep = "Alternate Course 1: User leaves the Auto Number checked.";
                FastDriver.BottomFrame.New();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Alternate Course 1:User selects Transaction Type from dropdown list, Delayed for Delayed Office";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad();
                Support.AreEqual(true, String.IsNullOrEmpty(FastDriver.ExchangeFileEntry.FileNo.FAGetValue()), "Verify FileNumber after Exchange file is created");

                Reports.TestStep = "Alternate Course 1-a: Reverse File Number proceeds with \"R.\" ";
                FastDriver.BottomFrame.New();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Alternate Course 1: User selects Transaction Type from dropdown list, Reverse/Construction for Reverse office.";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItemByIndex(2);
                FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemByIndex(2);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Alternate Course 1: Optional- User enters Taxpayer(s) or selects from GAB. The Taxpayer information is not required. However, it is required for IBA Transaction.";
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Alternate Course 1: Optional- User selects appropriate Note Type for Exchange transactions from the dropdown list.";
                FastDriver.ExchangeFileEntry.NoteType.FASelectItem("Exchange Reverse");
                FastDriver.ExchangeFileEntry.Notes.FASetText("FMUC0112 Exchange Automated test.");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Verifying that Exchange Reverse file number ends in R";
                Support.AreEqual(true, FastDriver.TopFrame.GetFileNumber().EndsWith("R"), "Verify FileNumber after Exchange ends with R");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0112_BAT0003()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 2:  Creating New Exchange File – Parties Tab";

                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Click on Parties tab";
                FastDriver.ExchangeFileEntry.PartiesTab.FAClick();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad(FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Add a Directed/Referred By GAB party using the Address Book";
                FastDriver.ExchangeFileEntry.ReferredByFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Exchange Company");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad(FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Add a Directed/Referred By GAB party using known ID code";
                FastDriver.ExchangeFileEntry.ReferredByGABcode.FASetText("DIRECTEDBY");
                FastDriver.ExchangeFileEntry.ReferredByFind.FAClick();

                Reports.TestStep = "Add a CreditTo GAB party using the Address Book";
                FastDriver.ExchangeFileEntry.CreditToFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Exchange Company");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad(FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Add a Directed/Referred By GAB party using known ID code";
                FastDriver.ExchangeFileEntry.CreditToGABcode.FASetText("CTESTDKEXU");
                FastDriver.ExchangeFileEntry.CreditToFind.FAClick();

                Reports.TestStep = "Add a TaxPayer Rep GAB party using the Address Book";
                FastDriver.ExchangeFileEntry.TaxPayerRepFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Exchange Company");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad(FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Add a TaxPayer Rep GAB party using known ID code";
                FastDriver.ExchangeFileEntry.TaxPayerRepGABcode.FASetText("CTESTDKEXU");
                FastDriver.ExchangeFileEntry.TaxPayerRepFind.FAClick();

                Reports.TestStep = "Add a Advisor/CPA GAB party using the Address Book";
                FastDriver.ExchangeFileEntry.AdvisorCPAFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Exchange Company");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad(FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Add a Advisor/CPA GAB party using known ID code";
                FastDriver.ExchangeFileEntry.AdvisorCPAGABcode.FASetText("EXCHCPA");
                FastDriver.ExchangeFileEntry.AdvisorCPAFind.FAClick();

                Reports.TestStep = "Add a Advisor/Attorney GAB party using the Address Book";
                FastDriver.ExchangeFileEntry.AttorneyGABFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Exchange Company");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad(FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Add a Advisor/Attorney GAB party using known ID code";
                FastDriver.ExchangeFileEntry.AttorneyGABcode.FASetText("ATNYTITCMP");
                FastDriver.ExchangeFileEntry.AttorneyGABFind.FAClick();
                FastDriver.BottomFrame.Save();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0112_BAT0004()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 3:  Creating New Exchange File –Relinquished Property";

                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Click on Parties tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.PartiesTab, FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Enter GAB parties in Parties Tab screen";
                FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");

                Reports.TestStep = "Click on Relinquished Property tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.RelinquishedTab, FastDriver.ExchangeFileEntry.RelEstDaystoClose);

                Reports.TestStep = "Verifying State field is a required field";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.RelEstDaystoClose, false);

                Reports.TestStep = "Enter Property information";
                FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.RelPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelPropertyCounty.FASelectItem("Orange");

                Reports.TestStep = "Enter COE Date";
                FastDriver.ExchangeFileEntry.RelCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.RelActualCOE.FASetCheckbox(true);

                Reports.TestStep = "Adding GAB entries for Escrow Officer, Tax Payer's Agent and Buyer's Agent.";
                FastDriver.ExchangeFileEntry.EnterRelinquishedTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");

                Reports.TestStep = "Searching buyers from GAB (Business Entity or Trust/Estate)";
                FastDriver.ExchangeFileEntry.RelBuyersNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.RelEstDaystoClose, false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verifying COE Date updates the Date Grid in Detail Tab.";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.FirstCOEDate.FAGetValue().Equals(DateTime.Now.ToDateString()), "Verifying FirstCOEDate is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DeadLine45thDay.FAGetValue().Equals(DateTime.Now.AddDays(45).ToDateString()), "Verifying DeadLine45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DayofWeek45thDay.FAGetValue().Equals(DateTime.Now.AddDays(45).DayOfWeek.ToString()), "Verifying DayofWeek45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DaysLeft45thDay.FAGetValue().Equals("45"), "Verifying DaysLeft45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DeadLine180thDay.FAGetValue().Equals(DateTime.Now.AddDays(180).ToDateString()), "Verifying DeadLine180thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DayofWeek180thDay.FAGetValue().Equals(DateTime.Now.AddDays(180).DayOfWeek.ToString()), "Verifying DayofWeek180thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DaysLeft180thDay.FAGetValue().Equals("180"), "Verifying DayofWeek180thDay is updated.");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0112_BAT0005()
        {
            try
            {

                Reports.TestDescription = "Alternate Course 4:  Creating New Exchange File –Replacement Property";

                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Click on Parties tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.PartiesTab, FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Enter GAB parties in Parties Tab screen";
                FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");

                Reports.TestStep = "Navigate to Replacement Tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.ReplacementTab, FastDriver.ExchangeFileEntry.REPEstDaystoClose);

                Reports.TestStep = "Verifying State field is a required field";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.REPEstDaystoClose, false);

                Reports.TestStep = "Enter Property information";
                FastDriver.ExchangeFileEntry.REPPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.REPPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.REPPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.REPPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.REPPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.REPPropertyCounty.FASelectItem("Orange");

                Reports.TestStep = "Enter COE Date";
                FastDriver.ExchangeFileEntry.REPCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.REPActualCOE.FASetCheckbox(true);

                Reports.TestStep = "Adding GAB entries for Escrow Officer, Tax Payer's Agent and Buyer's Agent.";
                FastDriver.ExchangeFileEntry.EnterReplacementTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");

                Reports.TestStep = "Searching buyers from GAB (Business Entity or Trust/Estate)";
                FastDriver.ExchangeFileEntry.REPNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.REPEstDaystoClose, false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verifying COE Date updates the Date Grid in Detail Tab.";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.FirstCOEDate.FAGetValue().Equals(DateTime.Now.ToDateString()), "Verifying FirstCOEDate is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DeadLine45thDay.FAGetValue().Equals(DateTime.Now.AddDays(45).ToDateString()), "Verifying DeadLine45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DayofWeek45thDay.FAGetValue().Equals(DateTime.Now.AddDays(45).DayOfWeek.ToString()), "Verifying DayofWeek45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DaysLeft45thDay.FAGetValue().Equals("45"), "Verifying DaysLeft45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DeadLine180thDay.FAGetValue().Equals(DateTime.Now.AddDays(180).ToDateString()), "Verifying DeadLine180thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DayofWeek180thDay.FAGetValue().Equals(DateTime.Now.AddDays(180).DayOfWeek.ToString()), "Verifying DayofWeek180thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DaysLeft180thDay.FAGetValue().Equals("180"), "Verifying DayofWeek180thDay is updated.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0112_BAT0006()
        {
            try
            {
                
                Reports.TestDescription = "Alternate Course 5:  Creating New Exchange File –Transaction Summary Tab ";

                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Click on Parties tab and enter GAB parties in Parties Tab screen";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.PartiesTab, FastDriver.ExchangeFileEntry.ReferredByGABcode);
                FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");

                Reports.TestStep = "Click on Relinquished Property tab and enter all details";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.RelinquishedTab, FastDriver.ExchangeFileEntry.RelEstDaystoClose);
                FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.RelPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.RelCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.RelActualCOE.FASetCheckbox(true);
                FastDriver.ExchangeFileEntry.EnterRelinquishedTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.RelBuyersNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.RelEstDaystoClose, false);

                Reports.TestStep = "Navigate to Replacement Tab and enter all details";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.ReplacementTab, FastDriver.ExchangeFileEntry.REPEstDaystoClose);
                FastDriver.ExchangeFileEntry.REPPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.REPPropertyAddressLine1.FASetText("2 Main St.");
                FastDriver.ExchangeFileEntry.REPPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.REPPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.REPPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.REPPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.EnterReplacementTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.REPNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.REPEstDaystoClose, false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Navigate to Summary tab.";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.TransSummarytab, FastDriver.ExchangeFileEntry.TransTabEditbutton);

                Reports.TestStep = "Verifying that Edit and Remove buttons are enabled by default when properties are added";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransTabEditbutton.IsEnabled(), "Verifying Edit button is enabled by default.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransTabEditbutton.IsEnabled(), "Verifying Remove button is enabled by default.");

                Reports.TestStep = "Verifying that Transaction Summary table includes both Relinquished and Replacement properties.";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransSummaryTable.GetRowCount().Equals(3), "Verifying Transaction Summary Table contains added properties.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Contains("1 Main St."), "Verifying Relinquished Property Information");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean().Contains("2 Main St."), "Verifying Replacement Property Information");

                Reports.TestStep = "User also can edit the property via Transaction Summary.";
                FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ExchangeFileEntry.TransTabEditbutton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.RelEstDaystoClose, false);

                Reports.TestStep = "User also can remove the property via Transaction Summary.";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.TransSummarytab, FastDriver.ExchangeFileEntry.TransTabEditbutton);
                


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0112_BAT0007()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 6:  Creating New Exchange File –EAT Acquisition";

                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItemBySendingKeys("reverse");
                FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemByIndex(2);
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Click on Parties tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.PartiesTab, FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Enter GAB parties in Parties Tab screen";
                FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");

                Reports.TestStep = "Click on Relinquished Property tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.EATAcquisitionTab, FastDriver.ExchangeFileEntry.EATAcqActualCOE);

                Reports.TestStep = "Verifying State field is a required field";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.EATAcqActualCOE, false);

                Reports.TestStep = "Enter Property information";
                FastDriver.ExchangeFileEntry.EATAcqPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.EATAcqPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.EATAcqPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.EATAcqPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.EATAcqPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.EATAcqPropertyCounty.FASelectItem("Orange");

                Reports.TestStep = "Enter COE Date";
                FastDriver.ExchangeFileEntry.EATAcqCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.EATAcqActualCOE.FASetCheckbox(true);

                Reports.TestStep = "Adding GAB entries for Escrow Officer, Tax Payer's Agent and Buyer's Agent.";
                FastDriver.ExchangeFileEntry.EnterEATAcquisitionTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");

                Reports.TestStep = "Searching buyers from GAB (Business Entity or Trust/Estate)";
                FastDriver.ExchangeFileEntry.EATAcqSellersNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.EATAcqCOEDate, false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verifying COE Date updates the Date Grid in Detail Tab.";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.FirstCOEDate.FAGetValue().Equals(DateTime.Now.ToDateString()), "Verifying FirstCOEDate is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DeadLine45thDay.FAGetValue().Equals(DateTime.Now.AddDays(45).ToDateString()), "Verifying DeadLine45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DayofWeek45thDay.FAGetValue().Equals(DateTime.Now.AddDays(45).DayOfWeek.ToString()), "Verifying DayofWeek45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DaysLeft45thDay.FAGetValue().Equals("45"), "Verifying DaysLeft45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DeadLine180thDay.FAGetValue().Equals(DateTime.Now.AddDays(180).ToDateString()), "Verifying DeadLine180thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DayofWeek180thDay.FAGetValue().Equals(DateTime.Now.AddDays(180).DayOfWeek.ToString()), "Verifying DayofWeek180thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DaysLeft180thDay.FAGetValue().Equals("180"), "Verifying DayofWeek180thDay is updated.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0112_BAT0008()
        {
            try
            {
                
                Reports.TestDescription = "Alternate Course 7:  Creating New Exchange File –EAT Disposition Property";

                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItemBySendingKeys("reverse");
                FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemByIndex(2);
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Click on Parties tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.PartiesTab, FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Enter GAB parties in Parties Tab screen";
                FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");

                Reports.TestStep = "Click on Relinquished Property tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.EATDispositionTab, FastDriver.ExchangeFileEntry.EATDispEstDaystoClose);

                Reports.TestStep = "Verifying State field is a required field";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.EATDispEstDaystoClose, false);

                Reports.TestStep = "Enter Property information";
                FastDriver.ExchangeFileEntry.EATDispPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.EATDispPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.EATDispPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.EATDispPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.EATDispPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.EATDispPropertyCounty.FASelectItem("Orange");

                Reports.TestStep = "Enter COE Date";
                FastDriver.ExchangeFileEntry.EATDispCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.EATDispActualCOE.FASetCheckbox(true);

                Reports.TestStep = "Adding GAB entries for Escrow Officer, Tax Payer's Agent and Buyer's Agent.";
                FastDriver.ExchangeFileEntry.EnterEATDispositionGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");

                Reports.TestStep = "Searching buyers from GAB (Business Entity or Trust/Estate)";
                FastDriver.ExchangeFileEntry.EATDispSellersNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.EATDispEstDaystoClose, false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verifying COE Date updates the Date Grid in Detail Tab.";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.FirstCOEDate.FAGetValue().Equals(DateTime.Now.ToDateString()), "Verifying FirstCOEDate is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DeadLine45thDay.FAGetValue().Equals(DateTime.Now.AddDays(45).ToDateString()), "Verifying DeadLine45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DayofWeek45thDay.FAGetValue().Equals(DateTime.Now.AddDays(45).DayOfWeek.ToString()), "Verifying DayofWeek45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DaysLeft45thDay.FAGetValue().Equals("45"), "Verifying DaysLeft45thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DeadLine180thDay.FAGetValue().Equals(DateTime.Now.AddDays(180).ToDateString()), "Verifying DeadLine180thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DayofWeek180thDay.FAGetValue().Equals(DateTime.Now.AddDays(180).DayOfWeek.ToString()), "Verifying DayofWeek180thDay is updated.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.DaysLeft180thDay.FAGetValue().Equals("180"), "Verifying DayofWeek180thDay is updated.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region REG

        [TestMethod]
        public void FMUC0112_REG0001()
        {
            try
            {
                
                Reports.TestDescription = "FMUC0112 BRs: Status, Date and Time of the File Grid";

                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();

                Reports.TestStep = "Verifying default file status";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.FileStatus.FAGetSelectedItem().Equals("Open"), "Verifying default file status");

                Reports.TestStep = "Ability to change file status";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.FileStatus.IsEnabled(), "Verifying file status field is enabled");
                
                Reports.TestStep = "Verifying file status date";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.StatusDate.FAGetValue().Equals(DateTime.Now.ToDateString()), "Verifying file status date match");

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Click on Parties tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.PartiesTab, FastDriver.ExchangeFileEntry.ReferredByGABcode);

                Reports.TestStep = "Enter GAB parties in Parties Tab screen";
                FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");

                Reports.TestStep = "Navigate to Replacement Tab and enter all necessary info.";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.ReplacementTab, FastDriver.ExchangeFileEntry.REPEstDaystoClose);
                FastDriver.ExchangeFileEntry.REPPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.REPPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.REPPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.REPPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.REPPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.REPPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.REPCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.REPActualCOE.FASetCheckbox(true);
                FastDriver.ExchangeFileEntry.EnterReplacementTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.REPNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.REPEstDaystoClose, false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verifying file status options";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.FileStatus.FAGetAllTextFromSelect(", ").Contains("Open, Cancelled, Open In Error, Closed"), "Verifying default file status");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0112_REG0002()
        {
            try
            {

                Reports.TestDescription = "Details Tab: Dates, Taxpayers, Transaction Type Selection";

                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();

                Reports.TestStep = "Tab status when Transaction Type is Delayed";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                Support.AreEqual("true", FastDriver.ExchangeFileEntry.EATAcquisitionTab.FAGetAttribute("disabled"), "Verifying that EATAcquisitionTab is disabled when Transaction Type is Delayed");
                Support.AreEqual("true", FastDriver.ExchangeFileEntry.EATDispositionTab.FAGetAttribute("disabled"), "Verifying that EATDispositionTab is disabled when Transaction Type is Delayed");
                
                Reports.TestStep = "Tab status when Transaction Type is Reverse / Construction";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItemBySendingKeys("reverse");
                Support.AreEqual("true", FastDriver.ExchangeFileEntry.RelinquishedTab.FAGetAttribute("disabled"), "Verifying that RelinquishedTab is disabled when Transaction Type is Delayed");
                Support.AreEqual("true", FastDriver.ExchangeFileEntry.ReplacementTab.FAGetAttribute("disabled"), "Verifying that ReplacementTab is disabled when Transaction Type is Delayed");

                Reports.TestStep = "Add Tax Payer Info and select Delayed as transaction type";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Save();
                
                Reports.TestStep = "Verify that transaction type cannot be changed after file is saved.";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                Support.AreEqual("true", FastDriver.ExchangeFileEntry.TransactionType.FAGetAttribute("disabled"), "Verifying that Transaction Type field is enabled after file is saved.");

                Reports.TestStep = "Taxpayers section: New Search, Add New, Remove, Vesting, Signatures";
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad();
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TaxPayerNewSearch.IsDisplayed(), "Verifying that New Search button is displayed.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TaxPayerAddNew.IsDisplayed(), "Verifying that Add New button is displayed.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TaxPayerRemove.IsDisplayed(), "Verifying that Remove button is displayed.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TaxPayerVesting.IsDisplayed(), "Verifying that Vesting button is displayed.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TaxPayerSignatures.IsDisplayed(), "Verifying that Signatures button is displayed.");

                Reports.TestStep = "Indicate Taxpayer Type, adding/removing Taxpayer";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TaxPayerAddNew.IsEnabled(), "Verifying Remove button is enabled.");
                Support.AreEqual(false, FastDriver.ExchangeFileEntry.TaxPayerRemove.IsEnabled(), "Verifying Remove button is disabled.");
                FastDriver.ExchangeFileEntry.TaxPayerAddNew.FAClick();
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TaxPayerType.FAGetAllTextFromSelect(", ").Contains(@"Individual, Husband/Wife, Trust/Estate, Business Entity"), "Verifying options under Taxpayer Type");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TaxPayerType.FAGetSelectedItem().Equals(@"Husband/Wife"), "Verifying default selection under Taxpayer Type");

                Reports.TestStep = "Add a new Taxpayer";
                FastDriver.ExchangeFileEntry.TaxPayerType.FASelectItem("Individual");
                FastDriver.ExchangeFileEntry.TaxpyrIndividualName.FASetText("John");
                FastDriver.ExchangeFileEntry.TaxpyrIndividualLast.FASetText("Doe");
                FastDriver.ExchangeFileEntry.TaxpyrIndividualSSNTIN.FASetText("123456789");
                FastDriver.ExchangeFileEntry.TaxPayerAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.TaxPayerCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.TaxPayerState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.TaxPayerZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.TaxPayerCounty.FASetText("Orange");
                FastDriver.ExchangeFileEntry.TaxPayerBusPh.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerHomePh.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerCellFax.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerPager.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerEmail.FASetText("test@test.net");

                Reports.TestStep = "Add a second new Taxpayer";
                FastDriver.ExchangeFileEntry.TaxPayerAddNew.FAClick();
                FastDriver.ExchangeFileEntry.TaxPayerType.FASelectItemBySendingKeys("husband");
                FastDriver.ExchangeFileEntry.TaxPayerHusName.FASetText("John");
                FastDriver.ExchangeFileEntry.TaxPayerHusLast.FASetText("Doe");
                FastDriver.ExchangeFileEntry.TaxPayerHusSSNTIN.FASetText("123456789");
                FastDriver.ExchangeFileEntry.TaxPayerSpouseName.FASetText("Jane");
                FastDriver.ExchangeFileEntry.TaxPayerSpouseSSNTIN.FASetText("987654321");
                FastDriver.ExchangeFileEntry.TaxPayerAddressLine1.FASetText("5 Main St.");
                FastDriver.ExchangeFileEntry.TaxPayerCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.TaxPayerState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.TaxPayerZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.TaxPayerCounty.FASetText("Orange");
                FastDriver.ExchangeFileEntry.TaxPayerBusPh.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerHomePh.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerCellFax.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerPager.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.TaxPayerEmail.FASetText("test@test.net");

                Reports.TestStep = "Remove a newly created Taxpayer";
                FastDriver.ExchangeFileEntry.DetailsTaxPayerTable.PerformTableAction(3, 2, TableAction.Click);
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TaxPayerRemove.IsEnabled(), "Verifying Remove button is enabled.");
                FastDriver.ExchangeFileEntry.TaxPayerRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0112_REG0003()
        {
            try
            {
                
                Reports.TestDescription = "Transaction Summary Screen BRs";
                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                #region Data Setup
                var deposit = new DepositParameters()
                {
                    Amount = 10.00,
                    TypeofFunds = "Direct Deposit",
                    ReceivedFrom = "Buyer",
                    Representing = "Exchange Fees",
                    Description = "FMUC0112 - REG0003",
                };
                #endregion

                Reports.TestStep = "Navigate to Exchange File Entry";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Click on Parties tab";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.PartiesTab, FastDriver.ExchangeFileEntry.ReferredByGABcode);
                FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");

                Reports.TestStep = "Click on Relinquished Property tab and create a new property entry";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.RelinquishedTab, FastDriver.ExchangeFileEntry.RelEstDaystoClose);
                FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.RelPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.RelCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.RelActualCOE.FASetCheckbox(true);
                FastDriver.ExchangeFileEntry.EnterRelinquishedTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.RelBuyersNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.RelEstDaystoClose, false);

                Reports.TestStep = "Click on Replacement Property tab and create a new property entry";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.ReplacementTab, FastDriver.ExchangeFileEntry.REPEstDaystoClose);
                FastDriver.ExchangeFileEntry.REPPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.REPPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.REPPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.REPPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.REPPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.REPPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.REPCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.REPActualCOE.FASetCheckbox(true);
                FastDriver.ExchangeFileEntry.EnterReplacementTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.REPNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.REPEstDaystoClose, false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Navigate to Summary tab.";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.TransSummarytab, FastDriver.ExchangeFileEntry.TransTabEditbutton);

                Reports.TestStep = "Verify that Properties have numerical or alphanumerical transaction numbers";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean().Equals("1"), "Verifying Relinquished Property has a numerical transaction number");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(3, 1, TableAction.GetText).Message.Clean().Equals("A"), "Verifying Replacement Property has an alphanumerical transaction number");

                Reports.TestStep = "Removing transaction when File Status is Closed";
                FastDriver.ExchangeFileEntry.FileStatus.FASelectItem("Closed");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Navigate to Summary tab.";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.TransSummarytab, FastDriver.ExchangeFileEntry.TransTabEditbutton);

                Reports.TestStep = "Click on Remove to attempt to erase transaction";
                FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.ExchangeFileEntry.TransTabRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.TransTabEditbutton, false);

                Reports.TestStep = "No Re-sequencing Transaction #";
                FastDriver.ExchangeFileEntry.FileStatus.FASelectItem("Open");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.TransSummarytab, FastDriver.ExchangeFileEntry.TransTabEditbutton);

                Reports.TestStep = "Click on Relinquished Property tab and create a new property entry";
                for (int i = 0; i < 2; i++)
                { 
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.RelinquishedTab, FastDriver.ExchangeFileEntry.RelEstDaystoClose);
                FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.RelPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.RelCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.RelActualCOE.FASetCheckbox(true);
                FastDriver.ExchangeFileEntry.EnterRelinquishedTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.RelBuyersNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.RelEstDaystoClose, false);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                }

                Reports.TestStep = "Navigate to Summary tab.";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.TransSummarytab, FastDriver.ExchangeFileEntry.TransTabEditbutton);

                Reports.TestStep = "Click on Remove to attempt to erase transaction";
                FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(4, 1, TableAction.Click);
                FastDriver.ExchangeFileEntry.TransTabRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.TransTabEditbutton, false);
                Playback.Wait(5000);

                Reports.TestStep = "Verify that properties have not been resequenced.";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean().Equals("3"), "Verifying that 3rd Relinquished property still has transaction #3");

                Reports.TestStep = "Verify that the COE date has been updated on all properties.";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean().Equals("actual " + DateTime.Now.ToDateString(true, true)), "Verifying that 3rd Relinquished property still has transaction #3");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(3, 3, TableAction.GetText).Message.Clean().Equals("actual " + DateTime.Now.ToDateString(true, true)), "Verifying that 3rd Relinquished property still has transaction #3");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(4, 3, TableAction.GetText).Message.Clean().Equals("actual " + DateTime.Now.ToDateString(true, true)), "Verifying that 3rd Relinquished property still has transaction #3");

                Reports.TestStep = "Create a deposit and select one of the created properties.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Property.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Navigate to Exchange File Entry";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Exchange File Entry").WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Navigate to Summary tab.";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.TransSummarytab, FastDriver.ExchangeFileEntry.TransTabEditbutton);

                Reports.TestStep = "Click on Remove to attempt to erase transaction";
                FastDriver.ExchangeFileEntry.TransSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ExchangeFileEntry.TransTabRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.TransTabEditbutton, false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0112_REG0004()
        {
            try
            {

                Reports.TestDescription = "Errors and Warning Conditions";
                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();

                Reports.TestStep = "Navigate to Exchange File Entry and create file";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Changing transaction type before saving file";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.RelinquishedTab, FastDriver.ExchangeFileEntry.RelEstDaystoClose);
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.DetailsTab, FastDriver.ExchangeFileEntry.TransactionType);
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItemBySendingKeys("reverse");
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Saving file with an office that does not match transaction type";
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.RelActualCOE, false);
                Support.AreEqual(true, FastDriver.FastErrorMessageList.GetErrorMsgText().Contains("Please Select Reverse Exchange Office"), "Verifying error message when office and transaction type do not match.");

                Reports.TestStep = "Saving file with an office that does not match transaction type";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.DetailsTab, FastDriver.ExchangeFileEntry.TransactionType);

                Reports.TestStep = "Percentage cannot be more than 100% - Relinquished/Replacement properties";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.RelinquishedTab, FastDriver.ExchangeFileEntry.RelEstDaystoClose);
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelTermsSalePrice.FASetText("5000");
                FastDriver.ExchangeFileEntry.RELIntinProperty.FASetText("120");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.RelActualCOE, false);

                Reports.TestStep = "Percentage cannot be more than 100% - Relinquished/Replacement properties";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.ReplacementTab, FastDriver.ExchangeFileEntry.REPActualCOE);
                FastDriver.ExchangeFileEntry.REPPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.REPTermsSalePrice.FASetText("5000");
                FastDriver.ExchangeFileEntry.REPIntinProperty.FASetText("120");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.REPActualCOE, false);

                Reports.TestStep = "Create a Replacement property entry";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.RelinquishedTab, FastDriver.ExchangeFileEntry.RelEstDaystoClose);
                FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.RelPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.RelCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.RelActualCOE.FASetCheckbox(true);

                Reports.TestStep = "Create a Relinquished property entry with an earlier actual COE date.";
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.ReplacementTab, FastDriver.ExchangeFileEntry.REPActualCOE);
                FastDriver.ExchangeFileEntry.REPPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.REPPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.REPPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.REPPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.REPPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.REPPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.REPCOEDate.FASetText(DateTime.Now.SubtractBusinessDays(5).ToDateString());
                FastDriver.ExchangeFileEntry.REPActualCOE.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.REPActualCOE, false);
                Support.AreEqual(true, FastDriver.FastErrorMessageList.GetErrorMsgText().Contains("Replacement COE must be greater than or equal to Relinquished property Actual COE"), "Verifying error message when office and transaction type do not match.");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0112_REG0005()
        {
            try
            {
                Reports.TestDescription = "CR53- Allow the user to change Home Office after the file is saved.";
                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();

                Reports.TestStep = "Create file.";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Verify that the Office Selection dropdown is enabled";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ExchangeOffice.IsEnabled(), "Verifying that the Exchange Office dropdown is enabled.");

                Reports.TestStep = "Change the Exchange office when file has no funds.";
                FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Change the Exchange office from A to B and viceversa.";
                FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);
                FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Navigate to Event/Tracking Log";
                FastDriver.LeftNavigation.Navigate<EventTrackingLog>("Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean().Equals("[Change Owning Office]"), "Verifying Exchange Office Change");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean().Contains("Old Office: QA Automation Office Expresso"), "Verifying Exchange Office Change");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean().Contains("New Office: zz-Exchange Delay FAST Admin Office"), "Verifying Exchange Office Change");

                Reports.TestStep = "Navigate to Exchange File Entry and add a relinquished property";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad(skipSearch: false);
                FastDriver.ExchangeFileEntry.ClickTabAndWaitForScreen(FastDriver.ExchangeFileEntry.RelinquishedTab, FastDriver.ExchangeFileEntry.RelEstDaystoClose);
                FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.RelPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.RelCOEDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ExchangeFileEntry.RelActualCOE.FASetCheckbox(true);
                FastDriver.ExchangeFileEntry.EnterRelinquishedTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.RelBuyersNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(FastDriver.ExchangeFileEntry.RelEstDaystoClose, false);
                FastDriver.BottomFrame.Save();
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Create a Miscellaneous Disbursement with a GAB";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Accounting>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("EXCHCPA");
                FastDriver.MiscDisbursementDetail.ExchDisbursementType.FASelectItem("Earnest Money Deposit");
                FastDriver.MiscDisbursementDetail.ExchProperty.FASelectItemByIndex(1);
                FastDriver.MiscDisbursementDetail.ExchAmount.FASetText("1000");
                FastDriver.BottomFrame.Done();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                Reports.TestStep = "Create a Miscellaneous Disbursement with a GAB";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplateUpload.FAClick();
                FastDriver.UploadDocumentDlg.UploadFile(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.UploadDocumentDlg.Upload.FAClick();
                FastDriver.SaveDocumentDlg.SaveWireDocument("Escrow: Payoff Demand/Bills", "Miscellaneous", "1099");
                FastDriver.DocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Select recently created disbursement and click Edit";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>("Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Edit disbursement and disburse as Wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Playback.Wait(5000);
                
                Reports.TestStep = "Add wire instructions";
                FastDriver.EditDisbursement.Add.FAClick();
                FastDriver.SelectWireInstructionsDlg.SelectWireInstructions("Miscellaneous");

                Reports.TestStep = "Enter wire details";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("123456789");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("Test Bank");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("987654321");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("987654321");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select disbursement and click on Wire.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                Reports.TestStep = "Click on Disburse and enter Overdraft password";
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterPassword();
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Exchange File Entry and verify that Exchange Office dropdown was disabled.";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad(skipSearch: false);
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetAttribute("disabled") != null, "Verifying that the Exchange Office dropdown is enabled.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0112_REG0006()
        {
            try
            {
                Reports.TestDescription = "CR54- Required to have an entry field(s) for Entity (LLC) for Delayed and Reverse Transactions";
                Reports.TestStep = "Log into FAST application and navigate to Exchange/Expresso region";
                FALogin(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12386");

                Reports.TestStep = "Navigate to Exchange File Entry";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenLoad();

                Reports.TestStep = "Verify that Reverse Entity field appears for Delayed transaction type";
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ReverseEntity.IsDisplayed(), "Verifying if Reverse Entity is displayed");

                Reports.TestStep = "Enter data in Reverse Entity field";
                FastDriver.ExchangeFileEntry.ReverseEntity.FASetText("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quam massa, sollicitudin sed gravida eget, dignissim et sem. Curabitur tempus finibus volutpat. Cras hendrerit, enim et interdum vehicula, massa diam pharetra leo, at pellentesque leo urna");

                Reports.TestStep = "Fill out all fields in Detail tab and save";
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Verify character limit for Reverse Entity";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ReverseEntity.FAGetValue().Length.Equals(255), "Verifying character limit for Reverse Entity");

                Reports.TestStep = "Modify data in Reverse Entity field and save.";
                FastDriver.ExchangeFileEntry.ReverseEntity.FASetText("Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque rutrum lacinia eros sed pharetra. Ut aliquam ex vitae convallis imperdiet. Vivamus laoreet velit sit amet dolor feugiat egestas. Aenean blandit leo nunc, quisser");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Verify that modified text was saved.";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ReverseEntity.FAGetValue().Contains("Cum sociis natoque penatibus et magnis dis parturient montes"), "Verifying that system saved modified text.");

                Reports.TestStep = "Verify that Reverse Entity and Related Transaction fields appear for Reverse transaction type";
                FastDriver.BottomFrame.New();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad();
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItemBySendingKeys("reverse");
                FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemByIndex(2);
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ReverseEntity.IsDisplayed(), "Verifying if Reverse Entity is displayed");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.RelatedTransaction.IsDisplayed(), "Verifying if Related Transaction is displayed");

                Reports.TestStep = "Enter data in Reverse Entity field";
                FastDriver.ExchangeFileEntry.ReverseEntity.FASetText("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quam massa, sollicitudin sed gravida eget, dignissim et sem. Curabitur tempus finibus volutpat. Cras hendrerit, enim et interdum vehicula, massa diam pharetra leo, at pellentesque leo urna");

                Reports.TestStep = "Enter data in Reverse Entity field";
                FastDriver.ExchangeFileEntry.RelatedTransaction.FASetText("Cum sociis natoque penatibus magnis");

                Reports.TestStep = "Fill out all fields in Detail tab and save";
                FastDriver.ExchangeFileEntry.TaxPayerNewSearch.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Verify character limit for Reverse Entity and Related Transaction";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ReverseEntity.FAGetValue().Length.Equals(255), "Verifying character limit for Reverse Entity");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.RelatedTransaction.FAGetValue().Length.Equals(35), "Verifying character limit for Related Transaction");

                Reports.TestStep = "Modify data in Reverse Entity field and save.";
                FastDriver.ExchangeFileEntry.ReverseEntity.FASetText("Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque rutrum lacinia eros sed pharetra. Ut aliquam ex vitae convallis imperdiet. Vivamus laoreet velit sit amet dolor feugiat egestas. Aenean blandit leo nunc, quisser");
                FastDriver.ExchangeFileEntry.RelatedTransaction.FASetText("Lorem ipsum dolor sit amet, consect");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ExchangeFileEntry.WaitForScreenLoad(skipSearch: false);

                Reports.TestStep = "Verify that modified text was saved.";
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.ReverseEntity.FAGetValue().Contains("Cum sociis natoque penatibus et magnis dis parturient montes"), "Verifying that system saved modified text.");
                Support.AreEqual(true, FastDriver.ExchangeFileEntry.RelatedTransaction.FAGetValue().Equals("Lorem ipsum dolor sit amet, consect"), "Verifying that system saved modified text.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 838136:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Exchange File Entry
        //TestCase                                : 849590
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0112_REG008()
        {

            try
            {

                Reports.TestDescription = "US# 838136: System shall not display Hidden Office in EFE screen -Exchange office drop down. ";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region Mark the office Hidden
                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>1031EX>Offices").WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "9998", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                #endregion #region Mark the office Hidden

                #region Validate the office is not displayed in list

                Reports.TestStep = "Log in to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);
                Reports.TestStep = "Creating file in IIS";
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                FastDriver.SecuritySelectRegionOffice.EnterBUID("12367");

                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry");

                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Delayed");
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                if (FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Exchange office");
                }

                else
                {
                    Support.AreEqual("2", FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Exchange office");
                }
                string[] AllExchangeOffices = FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetAllTextFromSelect().Split('|');

                bool isPresent_ExchangeOffice = false;
                foreach (string office in AllExchangeOffices)
                {
                    if (office.Contains("9998"))
                    {
                        isPresent_ExchangeOffice = true;
                        break;
                    }
                }

                Support.AreEqual(false, isPresent_ExchangeOffice, "Verify the Hidden Office should not be present under Exchange office.");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(2000);
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemBySendingKeys("zz-Exchange Delay FAST Admin Office PR: 1031EX off: 9999");
                //FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItemByIndex(0);                
                //FastDriver.WebDriver.HandleDialogMessage();
                //Playback.Wait(2000);
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                //Support.AreEqual("zz-Exchange Delay FAST Admin Office PR: 1031EX off: 9999(12199)", FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedItem());
                FastDriver.BottomFrame.Done();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry");
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                Support.AreEqual("zz-Exchange Delay FAST Admin Office PR: 1031EX off: 9999(12199)", FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedItem());
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                if (FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedIndex() == 0)
                {
                    Support.AreEqual("0", FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedIndex().ToString(), "Blank value selected in Exchange office");
                }

                else
                {
                    Support.AreEqual("2", FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedIndex().ToString(), "Blank value is not selected in Exchange office");
                }
                #endregion Validate the office is not displayed in list

                #region Mark the office again Active
                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>1031EX>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.Status.FASelectItem("Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "9998", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (FastDriver.OfficeSetupOffice.Hidden.Selected)
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);
                }
                FastDriver.BottomFrame.Done();
                #endregion #region Mark the office Active

            }


            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r09
        //UserStory                               : User Story 838136:REQ0909373 - NCS - Hide Select office Name in FAST Office Selection Screens- Exchange File Entry
        //TestCase                                : 849592
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod]
        public void FMUC0112_REG009()
        {

            try
            {

                Reports.TestDescription = "US# 838136: Create a file in EFE screen and Verify system is displaying the selected Exchange office for the same file after the office marked as hidden . ";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region Precondition

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>1031EX>Offices").WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "9998", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (FastDriver.OfficeSetupOffice.Hidden.Selected)
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);
                }
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create a file

                Reports.TestStep = "Log in to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);
                Reports.TestStep = "Creating file in IIS";
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12367");
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry");
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                FastDriver.ExchangeFileEntry.TransactionType.FASelectItem("Reverse / Construction");
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                #region Mark the office Hidden

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>1031EX>Offices").WaitForScreenToLoad();
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "9998", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();

                #endregion

                #region Validate the created file

                Reports.TestStep = "Log in to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);
                Reports.TestStep = "Verify the Exchange office for created file.";
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12367");
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>File Search");
                Playback.Wait(3000);
                //FastDriver.FileSearch.Numbers.FASetText("467180R");
                FastDriver.FileSearch.Numbers.FASetText(FileNumber);
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(3000);
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                Support.AreEqual("zz-Exchange Reverse FAST Admin Office PR: 1031EX off: 9998(12367)", FastDriver.ExchangeFileEntry.ExchangeOffice.FAGetSelectedItem());

                #endregion

                #region Mark the office again Active
                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>1031EX>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.Status.FASelectItem("Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "9998", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (FastDriver.OfficeSetupOffice.Hidden.Selected)
                {
                    FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);
                }
                FastDriver.BottomFrame.Done();

                #endregion

            }


            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }


        #region Private  methods
        private void FALogin(string URL, string userName, string userPwd)
        {
            var credentials = new Credentials()
            {
                UserName = userName,
                Password = userPwd
            };

            FASTLogin.Login(URL, credentials, true);
        }
        

        #endregion


    }
}
