﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0070 : MasterTestClass
    {
        [TestMethod]
        public void FMUC0070_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Cancel Adhoc File Business Party";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                BusOrgAdhocDlgParameters adhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Miscellaneous",
                    Name1 = "Name1",
                    Name2 = "Name2",
                    AddrLine1 = "Addrline1",
                    AddrLine2 = "Addrline2",
                    AddrLine3 = "Addrline3",
                    AddrLine4 = "Addrline4",
                    City = "Santa Ana",
                    State = "CA",
                    Zip = "12345",
                    County = "Orange",
                    Country = "USA",
                    BusPhone = @"(111)111-1111",
                    BusFax = @"(111)111-1112",
                    CellPhone = @"(111)111-1113",
                    Pager = @"(111)111-1114",
                    Email = @"TestAccount@Firstam.com"
                };
                BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                #region Verify Cancel Adhoc Details in MiscDisbursementDetail

                Reports.TestStep = "Enter MiscDisbursementDetail Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Verify the Values in Miscellaneous Disbursement Screen with the values entered in AdhocEntry Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.VerifyAdhocValues(BusOrgAdhoc);

                #endregion Verify Cancel Adhoc Details in MiscDisbursementDetail

                #region Verify Cancel Adhoc Details in REB

                Reports.TestStep = @"Enter Real Estate Broker/Agent Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Verify the Values in REB Screen with the values entered in AdhocEntry Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.VerifyAdhocValues(BusOrgAdhoc);

                #endregion Verify Cancel Adhoc Details in REB
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0070_BAT0002()
        {
            try
            {
                Reports.TestDescription = "Create Adhoc File Business Party";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                BusOrgAdhocDlgParameters adhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Miscellaneous",
                    Name1 = "Name1",
                    Name2 = "Name2",
                    AddrLine1 = "Addrline1",
                    AddrLine2 = "Addrline2",
                    AddrLine3 = "Addrline3",
                    AddrLine4 = "Addrline4",
                    City = "Santa Ana",
                    State = "CA",
                    Zip = "12345",
                    County = "Orange",
                    Country = "USA",
                    BusPhone = @"(111)111-1111",
                    BusFax = @"(111)111-1112",
                    CellPhone = @"(111)111-1113",
                    Pager = @"(111)111-1114",
                    Email = @"TestAccount@Firstam.com"
                };
                BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                #region Verify Create Adhoc Details in MiscDisbursementDetail

                Reports.TestStep = "Enter MiscDisbursementDetail Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.VerifyAll(BusOrgAdhoc);
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Verify the Values in Miscellaneous Disbursement Screen with the values entered in AdhocEntry Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.VerifyAdhocValues(BusOrgAdhoc);

                #endregion Verify Create Adhoc Details in MiscDisbursementDetail

                #region Verify Create Adhoc Details in REB

                Reports.TestStep = @"Enter Real Estate Broker/Agent Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the Values in REB Screen with the values entered in AdhocEntry Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.VerifyAdhocValues(BusOrgAdhoc);

                #endregion Verify Create Adhoc Details in REB
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0070_BAT0003()
        {
            try
            {
                Reports.TestDescription = "Update Adhoc File Business Party";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                BusOrgAdhocDlgParameters adhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Miscellaneous",
                    Name1 = "Name1",
                    Name2 = "Name2",
                    AddrLine1 = "Addrline1",
                    AddrLine2 = "Addrline2",
                    AddrLine3 = "Addrline3",
                    AddrLine4 = "Addrline4",
                    City = "Santa Ana",
                    State = "CA",
                    Zip = "12345",
                    County = "Orange",
                    Country = "USA",
                    BusPhone = @"(111)111-1111",
                    BusFax = @"(111)111-1112",
                    CellPhone = @"(111)111-1113",
                    Pager = @"(111)111-1114",
                    Email = @"TestAccount@Firstam.com"
                };
                BusOrgAdhocDlgParameters Modifiedadhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Attorney",
                    Name1 = "ModifiedName1",
                    Name2 = "ModifiedName2",
                    AddrLine1 = "ModifiedAddrline1",
                    AddrLine2 = "ModifiedAddrline2",
                    AddrLine3 = "ModifiedAddrline3",
                    AddrLine4 = "ModifiedAddrline4",
                    City = "New York",
                    State = "NY",
                    Zip = "99999",
                    County = "New York",
                    Country = "USA",
                    BusPhone = @"(111)111-1121",
                    BusFax = @"(111)111-1122",
                    CellPhone = @"(111)111-1123",
                    Pager = @"(111)111-1124",
                    Email = @"AlternateAccount@Firstam.com"
                };

                BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                #region Verify Modify Adhoc Details in MiscDisbursementDetail

                Reports.TestStep = "Enter MiscDisbursementDetail Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestDescription = "Modify Adhoc File Business Party";
                Reports.TestStep = "Modfiy MiscDisbursementDetail Adhoc Details.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.SetAll(Modifiedadhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.VerifyAll(BusOrgAdhoc);
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Verify the Values in Miscellaneous Disbursement Screen with the values entered in AdhocEntry Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.VerifyAdhocValues(BusOrgAdhoc);

                #endregion Verify Modify Adhoc Details in MiscDisbursementDetail

                #region Verify Modify Adhoc Details in REB

                Reports.TestStep = @"Enter Real Estate Broker/Agent Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Modify Real Estate Broker/Agent Adhoc Details.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the Values in REB Screen with the values entered in AdhocEntry Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.VerifyAdhocValues(BusOrgAdhoc);

                #endregion Verify Modify Adhoc Details in REB
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0070_BAT0004()
        {
            try
            {
                Reports.TestDescription = "Verify Adhoc Details in MiscDisbursementDetail when GAB Business Party Exists";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var detailsGABCode = "HUDFLINSR1";

                BusOrgAdhocDlgParameters adhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Miscellaneous",
                    Name1 = "Name1",
                    Name2 = "Name2",
                    AddrLine1 = "Addrline1",
                    AddrLine2 = "Addrline2",
                    AddrLine3 = "Addrline3",
                    AddrLine4 = "Addrline4",
                    City = "Santa Ana",
                    State = "CA",
                    Zip = "12345",
                    County = "Orange",
                    Country = "USA",
                    BusPhone = @"(111)111-1111",
                    BusFax = @"(111)111-1112",
                    CellPhone = @"(111)111-1113",
                    Pager = @"(111)111-1114",
                    Email = @"TestAccount@Firstam.com"
                };
                BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                #region Verify Adhoc Details in MiscDisbursementDetail when GAB Business Party Exists

                Reports.TestStep = "Enter MiscDisbursementDetail Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();

                Reports.TestStep = "Search for a GAB.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.MiscDisbursementDetail.Find.Click();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                string GABID = FastDriver.MiscDisbursementDetail.IDCode.FAGetText();
                Reports.StatusUpdate("GAB ID is " + GABID, true);

                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify whether the System generated Adhoc GAB is displayed";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.VerifyAdhocGABID();

                #endregion Verify Adhoc Details in MiscDisbursementDetail when GAB Business Party Exists
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0070_BAT0005()
        {
            try
            {
                Reports.TestDescription = "Verify Modification of Address when Country not  USA or Canada";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                BusOrgAdhocDlgParameters nonUSAadhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Miscellaneous",
                    Name1 = "Name1",
                    Name2 = "Name2",
                    AddrLine1 = "Addrline1",
                    AddrLine2 = "Addrline2",
                    AddrLine3 = "Addrline3",
                    AddrLine4 = "Addrline4",
                    City = "",
                    State = "",
                    Zip = "",
                    County = "",
                    Country = "INDIA",
                    BusPhone = @"(111)111-1111",
                    BusFax = @"(111)111-1112",
                    CellPhone = @"(111)111-1113",
                    Pager = @"(111)111-1114",
                    Email = @"TestAccount@Firstam.com"
                };
                BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                #region Verify Modification of Address when Country not  USA or Canada in MiscDisbursementDetail

                Reports.TestStep = "Enter MiscDisbursementDetail Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);

                Reports.TestStep = "Select the Country Other Than USA";
                FastDriver.BusOrgAdhocDlg.SetAll(nonUSAadhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the Values in Miscellaneous Disbursement Screen with the values entered in AdhocEntry Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.VerifyAdhocValues(BusOrgAdhoc, true);

                #endregion Verify Modification of Address when Country not  USA or Canada in MiscDisbursementDetail

                #region Verify Modification of Address when Country not  USA or Canada in REB

                Reports.TestStep = @"Enter Real Estate Broker/Agent Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);

                Reports.TestStep = "Select the Country Other Than USA";
                FastDriver.BusOrgAdhocDlg.SetAll(nonUSAadhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the Values in REB Screen with the values entered in AdhocEntry Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.VerifyAdhocValues(BusOrgAdhoc, true);

                #endregion Verify Modification of Address when Country not  USA or Canada in REB
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0070_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM6135_FM6136_FM6137_FM1695_FM1697_FM1750_FM3272_FM1752_FM5202_FM5217: 1:AdHoc Screen Default to Blank Values  2:Edit AdHoc Information 3:Default Values for Existing AdHoc Business Party 4:Display Read Only ID Code 5:Sys";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                BusOrgAdhocDlgParameters adhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Miscellaneous",
                    Name1 = "Name1",
                    Name2 = "Name2",
                    AddrLine1 = "Addrline1",
                    AddrLine2 = "Addrline2",
                    AddrLine3 = "Addrline3",
                    AddrLine4 = "Addrline4",
                    City = "Santa Ana",
                    State = "CA",
                    Zip = "12345",
                    County = "Orange",
                    Country = "USA",
                    BusPhone = @"(111)111-1111",
                    BusFax = @"(111)111-1112",
                    CellPhone = @"(111)111-1113",
                    Pager = @"(111)111-1114",
                    Email = @"TestAccount@Firstam.com"
                };
                BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                #region Validate Saving of Adhoc Entry to File Addr.

                Reports.TestStep = "Enter MiscDisbursementDetail Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);

                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate Saving of Adhoc Entry to File Addr.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();

                FastDriver.MiscDisbursementDetail.GABcode.FASetText(" ");
                FastDriver.MiscDisbursementDetail.Find.FAClick();

                Reports.TestStep = "Select File Addr Radio Button";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookRadio);

                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FAClick();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookRadio);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FireEvent("onclick");
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookRadio);

                FastDriver.AddressBookSearchDlg.ValidateName("Payee", BusOrgAdhoc.Name1, BusOrgAdhoc.Name2);
                FastDriver.DialogBottomFrame.ClickCancel();

                #endregion Validate Saving of Adhoc Entry to File Addr.
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0070_REG0002()
        {
            try
            {
                Reports.TestDescription = "Verify Error Warning Conditions";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                BusOrgAdhocDlgParameters adhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Miscellaneous",
                    Name1 = "Name1",
                    Name2 = "Name2",
                    AddrLine1 = "Addrline1",
                    AddrLine2 = "Addrline2",
                    AddrLine3 = "Addrline3",
                    AddrLine4 = "Addrline4",
                    City = "Santa Ana",
                    State = "CA",
                    Zip = "12345",
                    County = "Orange",
                    Country = "USA",
                    BusPhone = @"(111)111-1111",
                    BusFax = @"(111)111-1112",
                    CellPhone = @"(111)111-1113",
                    Pager = @"(111)111-1114",
                    Email = @"TestAccount@Firstam.com"
                };
                BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                #region Verify Error Warning Conditions

                Reports.TestStep = "Enter MiscDisbursementDetail Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                FastDriver.BusOrgAdhocDlg.VerifyErrorWarningMessages(adhoc);

                #endregion Verify Error Warning Conditions
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0070_REG0003()
        {
            try
            {
                Reports.TestDescription = "Verify Field Definitions";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                BusOrgAdhocDlgParameters loweradhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Attorney",
                    Name1 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJU39",
                    Name2 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJU39",
                    AddrLine1 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD34",
                    AddrLine2 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD34",
                    AddrLine3 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD34",
                    AddrLine4 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD34",
                    City = "ASDGHIJUOPASDGHIJUOPASDGHIJ29",
                    State = "CA",
                    Zip = "12345",
                    County = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPAS34",
                    Country = "USA",
                    BusPhone = @"",
                    BusFax = @"",
                    CellPhone = @"",
                    Pager = @"",
                    Email = @"ASDGHIJUOPASDGHASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJUXXASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJ99@f.in"
                };

                BusOrgAdhocDlgParameters exactadhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Attorney",
                    Name1 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJU40",
                    Name2 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJU40",
                    AddrLine1 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD35",
                    AddrLine2 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD35",
                    AddrLine3 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD35",
                    AddrLine4 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD35",
                    City = "ASDGHIJUOPASDGHIJUOPASDGHIJO30",
                    State = "CA",
                    Zip = "12345",
                    County = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASO35",
                    Country = "USA",
                    BusPhone = @"(111)111-1111",
                    BusFax = @"(111)111-1112",
                    CellPhone = @"(111)111-1113",
                    Pager = @"(111)111-1114",
                    Email = @"ASDGHIJUOPASDGHASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJUXXASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJ100@f.in"
                };

                BusOrgAdhocDlgParameters upperadhoc = new BusOrgAdhocDlgParameters()
                {
                    EntityType = "Attorney",
                    Name1 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJU40a",
                    Name2 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJU40a",
                    AddrLine1 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD35a",
                    AddrLine2 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD35a",
                    AddrLine3 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD35a",
                    AddrLine4 = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASD35a",
                    City = "ASDGHIJUOPASDGHIJUOPASDGHIJO30a",
                    State = "CA",
                    Zip = "12345",
                    County = "ASDGHIJUOPASDGHIJUOPASDGHIJUOPASO35a",
                    Country = "USA",
                    BusPhone = @"(111)111-11111",
                    BusFax = @"(111)111-11121",
                    CellPhone = @"(111)111-11131",
                    Pager = @"(111)111-11141",
                    Email = @"ASDGHIJUOPASDGHASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJUXXASDGHIJUOPASDGHIJUOPASDGHIJUOPASDGHIJ100@f.ind"
                };

                BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create New File

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create New File

                #region Verify Field Definitions

                Reports.TestStep = "Enter MiscDisbursementDetail Adhoc Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();

                Reports.TestStep = "Verify the Field with Lower Boundary Value.";
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);

                FastDriver.BusOrgAdhocDlg.SetAll(loweradhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.BusOrgAdhocDlg.VerifyAll(loweradhoc);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.VerifyAdhocValues(BusOrgAdhoc);

                Reports.TestStep = "Verify the Field with Exact Boundary Value.";
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);

                FastDriver.BusOrgAdhocDlg.SetAll(exactadhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.BusOrgAdhocDlg.VerifyAll(exactadhoc);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.VerifyAdhocValues(BusOrgAdhoc);

                Reports.TestStep = "Verify the Field with Higher Boundary Value.";
                FastDriver.MiscDisbursementDetail.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.WaitCreation(FastDriver.BusOrgAdhocDlg.Name1);

                FastDriver.BusOrgAdhocDlg.SetAll(upperadhoc);
                BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.BusOrgAdhocDlg.VerifyAll(exactadhoc);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.VerifyAdhocValues(BusOrgAdhoc);

                #endregion Verify Field Definitions
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Obsolete]
        public void FMUC0070_REG0004()
        {
            Reports.TestDescription = @"EWC1: Entity Type is required. ( Covered in FMUC0070_REG0002 )";
            Reports.StatusUpdate("Covered in FMUC0070_REG0002", true);
        }

        [TestMethod, Obsolete]
        public void FMUC0070_REG0005()
        {
            Reports.TestDescription = "Testing the error messages. ( Covered in FMUC0070_REG0002 )";
            Reports.StatusUpdate("Covered in FMUC0070_REG0002", true);
        }

        #region Custom Methods

        private void StoreFileNum()
        {
            FastDriver.QuickFileEntry.SwitchToTopFrame();
            string fileNum1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
        }

        #endregion Custom Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}