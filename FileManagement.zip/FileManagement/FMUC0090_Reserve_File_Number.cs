﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers.Factories;
using System.Collections.Generic;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers;
using System.Linq;

namespace FileManagement
{

    /// <summary>
    /// Summary description for FMUC0090 Reserve File Number
    /// </summary>
    [CodedUITest]

    public class  FMUC0090 : MasterTestClass
    {

        #region BAT

        #region Test FMUC0090_BAT0001

        /// <summary>
        /// MF1_01: Search with results for Duplicate File by Buyer Name(Individual).
        /// </summary>
        [TestMethod]

        public void FMUC0090_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Reserve a File Num, AF1_AF2: Search for File Number and Select Reserved File Number.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion


                #region ReserveNewFile
                Reports.TestStep = "Reserve a new file";
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.ClickReserveNew();
                FastDriver.ReserveFileDlg.AddComment("Reserve this file");
                FastDriver.DialogBottomFrame.ClickDone();
                string RFN = FastDriver.WebDriver.HandleDialogMessage().ToString().Replace("\r", string.Empty).Replace("\n", string.Empty).Replace("Reserved File Number = ", string.Empty);
                FastDriver.ReserveFileNumber.SwitchToContentFrame();
                #endregion


               // #region VerifyRFNWithWildCard
               // Reports.TestStep = "Verify RFN for wild card search";
                /*EXPECTED FAILURE */
                //FastDriver.ReserveFileNumber.EnterFileNumAndClickFind("*");
                //Support.AreEqual("Searching with a wild card or a leading wild card has been temporarily disabled", FastDriver.WebDriver.HandleDialogMessage().ToString().Trim(), true);
               // #endregion


                #region VerifyRFNCreation
                Reports.TestStep = "Enter the RFN created in search criteria and search ";
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(RFN);
                FastDriver.ReserveFileNumber.SearchResultTable(1, RFN, 1, TableAction.Click);
                FastDriver.ReserveFileNumber.Select.FAClick();

                #endregion
                
            }
            catch (Exception ex)
            {
                Support.Fail("Test Method failed because" + ex.Message);
            }
        }

        #endregion

        #region Test FMUC0090_BAT0002
        [TestMethod, Obsolete]
        public void FMUC0090_BAT0002()
        {
            Reports.TestDescription = "AF1_AF2: Search for File Number and Select Reserved File Number( Covered in FMUC0090_BAT0001 )";
            Reports.StatusUpdate("Covered in FMUC0090_BAT0001", true);
        }


        #endregion




        #endregion

        #region Regression


        #region Test FMUC0090_REG0001

        /// <summary>
        /// BR1: Reserve an auto generated file number without specifying Service Type,..
        /// BR2: verify user name, logged in office name and comments when a file number is reserved
        /// </summary>
        [TestMethod]

        public void FMUC0090_REG0001()
        {

            try
            {
                Reports.TestDescription = "BR1: Reserve an auto generated file number without specifying Service Type. BR2: verify user name, logged in office name and comments when a file number is reserved";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region ReserveNewFile
                Reports.TestStep = "Reserve a new file";
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.ClickReserveNew();
                FastDriver.ReserveFileDlg.AddComment("Reserve this file");
                FastDriver.DialogBottomFrame.ClickDone();
                string RFN = FastDriver.WebDriver.HandleDialogMessage().ToString().Replace("\r", string.Empty).Replace("\n", string.Empty).Replace("Reserved File Number = ", string.Empty);
                FastDriver.ReserveFileNumber.SwitchToContentFrame();
                #endregion


                #region Search the reserved file

                Reports.TestStep = "Search the reserved file";
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(RFN);
                FastDriver.ReserveFileNumber.SearchResultTable(1, RFN, 1, TableAction.Click).ToString();

                #endregion



                #region Verify the User Name and Logged office of Reserved file

                Reports.TestStep = "Verify the User Name and Logged office of Reserved file";

                FastDriver.ReserveFileNumber.SearchResultTable(2, "FAST QA07", 2, TableAction.Click).ToString();
                FastDriver.ReserveFileNumber.SearchResultTable(4, "QA Automation Office - DO NOT TOUCH", 4, TableAction.Click).ToString();
                #endregion

            }

            catch (Exception ex)
            {
                Support.Fail("Test Method failed because" + ex.Message);
            }

        }

        #endregion



        #region Test FMUC0090_REG0002

        [TestMethod, Obsolete]
        public void FMUC0090_REG0002()
        {
            Reports.TestDescription = "BR2: verify user name, logged in office name and comments when a file number is reserved( Covered in FMUC0090_REG0001 )";
            Reports.StatusUpdate("Covered in FMUC0090_REG0001", true);
        }
        #endregion



        #region Test FMUC0090_REG0003
        /// <summary>
        /// BR3: search for all or for a specific reserved file numbers in the region.
        /// </summary>
        [TestMethod]

        public void FMUC0090_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR3: search for all or for a specific reserved file numbers in the region";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Select 1487 office and create RFN
                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Select 1487 office";
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");

                Reports.TestStep = "Create RFN";
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.ClickReserveNew();
                FastDriver.ReserveFileDlg.AddComment("Reserve this file - 1487");
                FastDriver.DialogBottomFrame.ClickDone();
                string RFN1 = FastDriver.WebDriver.HandleDialogMessage().ToString().Replace("\r", string.Empty).Replace("\n", string.Empty).Replace("Reserved File Number = ", string.Empty);
                FastDriver.ReserveFileNumber.SwitchToContentFrame();
                #endregion

                #region Verify the RFN created in 1487 office
                Reports.TestStep = "Verify the RFN created in 1487 office";
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(RFN1);
                FastDriver.ReserveFileNumber.SearchResultTable(1, RFN1, 1, TableAction.Click).ToString();
                FastDriver.ReserveFileNumber.SearchResultTable(4, "QA Automation Office - DO NOT TOUCH", 4, TableAction.Click).ToString();
                #endregion


                #region Change the office to 2811 and create RFN

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Select 2811 office";
                FastDriver.SecuritySelectRegionOffice.EnterBUID("2811");

                Reports.TestStep = "create RFN";
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.ClickReserveNew();
                FastDriver.ReserveFileDlg.AddComment("Reserve this file - 2811");
                FastDriver.DialogBottomFrame.ClickDone();
                string RFN2 = FastDriver.WebDriver.HandleDialogMessage().ToString().Replace("\r", string.Empty).Replace("\n", string.Empty).Replace("Reserved File Number = ", string.Empty);
                FastDriver.ReserveFileNumber.SwitchToContentFrame();
                #endregion

                #region Verify the RFN created in 2811 office
                Reports.TestStep = "Verify the RFN created in 2811 office";
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(RFN2);
                FastDriver.ReserveFileNumber.SearchResultTable(1, RFN2, 1, TableAction.Click).ToString();
                FastDriver.ReserveFileNumber.SearchResultTable(4, "QA Automation Office1 - DO NOT TOUCH", 4, TableAction.Click).ToString();
                #endregion

                #region Change the office back to 1487
                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Select 1487 office";
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");
                #endregion

                #region Verify RFN created in 2811 office is reflected
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(RFN2);
                FastDriver.ReserveFileNumber.SearchResultTable(1, RFN2, 1, TableAction.Click).ToString();
                FastDriver.ReserveFileNumber.SearchResultTable(4, "QA Automation Office1 - DO NOT TOUCH", 4, TableAction.Click).ToString();
                #endregion



            }
            catch (Exception ex)
            {
                Support.Fail("Test Method failed because" + ex.Message);
            }

        }

        #endregion


        #region Test FMUC0090_REG0004

        /// <summary>
        /// BR4:FM15240: Allow the user to select a reserved file number to create a new file.
        /// </summary>
        [TestMethod]


        public void FMUC0090_REG0004()
        {

            try
            {
                Reports.TestDescription = "BR4: Allow the user to select a reserved file number to create a new file";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region ReserveNewFile
                Reports.TestStep = "Reserve a new file";
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.ClickReserveNew();
                FastDriver.ReserveFileDlg.AddComment("Reserve this file");
                FastDriver.DialogBottomFrame.ClickDone();
                string RFN = FastDriver.WebDriver.HandleDialogMessage().ToString().Replace("\r", string.Empty).Replace("\n", string.Empty).Replace("Reserved File Number = ", string.Empty);
                FastDriver.ReserveFileNumber.SwitchToContentFrame();
                #endregion

                #region VerifyRFNCreation
                Reports.TestStep = "Enter the RFN created in search criteria and search ";
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(RFN);
                FastDriver.ReserveFileNumber.SearchResultTable(1, RFN, 1, TableAction.Click);

                #endregion

                #region Select the RFN and create qfe
                Reports.TestStep = "Select the RFN and create qfe";
                FastDriver.ReserveFileNumber.Select.FAClick();
                #endregion

                #region Create File using the reserved file number
                Reports.TestStep = "Create File using the reserved file number";
                CreateFileFromRFN(true, "");

                #endregion

                #region Verify if the file is created from RFN
                Reports.TestStep = "Verify if the file is created from RFN";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileFromRFN = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                if (FileFromRFN.Length != 0)
                {
                    Reports.UpdateDebugLog("File was created with number - ", "", "File Number", "TEXT", FileFromRFN, "", Reports.Result(true), "");
                }
                else
                {
                    Reports.UpdateDebugLog("UNSUCCESSFUL", "", "File Number", "TEXT", "FILE NOT CREATED", "", Reports.Result(false), "");
                }

                #endregion


            }
            catch (Exception ex)
            {
                Support.Fail("Test Method failed due to" + ex.Message);
            }
        }

        #endregion


        #region Test FMUC0090_REG0005

        /// <summary>
        /// BR5:FM15241  Prevent Reserved File Number Use as Manual File Number
        /// </summary>
        [TestMethod]

        public void FMUC0090_REG0005()
        {
            try
            {
                Reports.TestDescription = "BR5:FM15241  Prevent Reserved File Number Use as Manual File Number";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region ReserveNewFile
                Reports.TestStep = "Reserve a new file";
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.ClickReserveNew();
                FastDriver.ReserveFileDlg.AddComment("Reserve this file");
                FastDriver.DialogBottomFrame.ClickDone();
                string RFN = FastDriver.WebDriver.HandleDialogMessage().ToString().Replace("\r", string.Empty).Replace("\n", string.Empty).Replace("Reserved File Number = ", string.Empty);
                FastDriver.ReserveFileNumber.SwitchToContentFrame();
                #endregion

                #region VerifyRFNCreation
                Reports.TestStep = "Enter the RFN created in search criteria and search ";
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(RFN);
                FastDriver.ReserveFileNumber.SearchResultTable(1, RFN, 1, TableAction.Click);
                #endregion

                #region Create File using UI
                Reports.TestStep = "Create File using UI";
                CreateFileFromRFN(false, RFN);
                #endregion

                #region Verify if IE popup and error message appear
                Reports.TestStep = "Verify if IE popup apears";
                FastDriver.WebDriver.HandleDialogMessage(true);

                Reports.TestStep = "Verify the error message";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Support.AreEqual("Service File: File Number already exists or reserved.", FastDriver.QuickFileEntry.QFEErrorMessage.FAGetText().ToString().Trim(), true);


                #endregion

            }

            catch (Exception ex)
            {
                Support.Fail("Test Method failed due to" + ex.Message);
            }
        }


        #endregion


        #region Test FMUC0090_REG0006
        /// <summary>
        /// BR6: verify system removes the reserved number from the table once the file is saved, using a reserved number
        /// </summary>

        [TestMethod]

        public void FMUC0090_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR6: verify system removes the reserved number from the table once the file is saved, using a reserved number.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion


                #region ReserveNewFile
                Reports.TestStep = "Reserve a new file";
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.ClickReserveNew();
                FastDriver.ReserveFileDlg.AddComment("Reserve this file");
                FastDriver.DialogBottomFrame.ClickDone();
                string RFN = FastDriver.WebDriver.HandleDialogMessage().ToString().Replace("\r", string.Empty).Replace("\n", string.Empty).Replace("Reserved File Number = ", string.Empty);
                FastDriver.ReserveFileNumber.SwitchToContentFrame();
                #endregion

                #region VerifyRFNCreation
                Reports.TestStep = "Enter the RFN created in search criteria and search ";
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(RFN);
                FastDriver.ReserveFileNumber.SearchResultTable(1, RFN, 1, TableAction.Click);

                #endregion

                #region Select the RFN and create qfe
                Reports.TestStep = "Select the RFN and create qfe";
                FastDriver.ReserveFileNumber.Select.FAClick();
                #endregion

                #region Create File using the reserved file number
                Reports.TestStep = "Create File using the reserved file number";
                CreateFileFromRFN(true, "");

                #endregion

                #region Verify if the file is created from RFN
                Reports.TestStep = "Verify if the file is created from RFN";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileFromRFN = FastDriver.TopFrame.FileNumberEditBox.FAGetValue().Trim();
                Support.AreEqual(RFN, FileFromRFN, true);
                #endregion

                #region Navigate to reserve file number screen and verify the reserved file number which is used to create File has been removed from the reserved file search results table.
                Reports.TestStep = "Navigate to reserve file number screen ";
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                Reports.TestStep = "verify the reserved file number which is used to create File has been removed from the reserved file search results table.";
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(FileFromRFN);
                int RC = FastDriver.ReserveFileNumber.FindSummary.GetRowCount();
                string RFNsearch = FastDriver.ReserveFileNumber.FindSummary.FAGetText();
                if ((bool)RFNsearch.Contains(FileFromRFN) == false && RC < 2)
                {
                    Reports.StatusUpdate("File removed from RFN search result", true);
                }
                else
                {
                    Reports.StatusUpdate("Failed", false);
                }
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail("Test Method failed due to" + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0090_REG0007
        /// <summary>
        /// FV01: Field Validation for comments.
        /// FV02: Field Validation for File Number Text box.
        /// </summary>
        /// 

        [TestMethod]

        public void FMUC0090_REG0007()
        {
            try
            {

                Reports.TestDescription = "FV01: Field Validation for comments,FV02: Field Validation for File Number Text box.";

                #region Login
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region ReserveNewFile
                Reports.TestStep = "Reserve a new file";
                FastDriver.LeftNavigation.Navigate<ReserveFileNumber>("Home>Order Entry>Reserve File Num");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.ClickReserveNew();
                Reports.TestStep = "verify field validation for comments";
                FastDriver.ReserveFileDlg.AddComment("122222222223433356vsavhdbxjsncksdhksnvkcn k13@@@@@kxhvidyfienk768986sbxjsaubxaxj878888888888888xjabx7at8ahixnxc");
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify the error message";
                string ErrMsg = FastDriver.WebDriver.HandleDialogMessage(false, true).ToString().Replace("\r", string.Empty).Replace("\n", string.Empty);

                Support.AreEqual("Comments cannot be more than 60 chars", ErrMsg.Trim(), true);

                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.ReserveFileDlg.SwitchToDialogContentFrame();
                FastDriver.ReserveFileDlg.AddComment("Field validation for comments");
                FastDriver.DialogBottomFrame.ClickDone();
                string RFN = FastDriver.WebDriver.HandleDialogMessage(true, true).ToString().Replace("\r", string.Empty).Replace("\n", string.Empty).Replace("Reserved File Number = ", string.Empty);
                FastDriver.ReserveFileNumber.SwitchToContentFrame();
                #endregion


                #region Verify the field definition for reserve file number field
                Reports.TestStep = "Verify the RFN in search results table";
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(RFN);
                FastDriver.ReserveFileNumber.SearchResultTable(1, RFN, 1, TableAction.Click);
                Reports.TestStep = "Verify the file number search criteria field definition";

                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind("12345678912345");

                string FileNumLength = FastDriver.ReserveFileNumber.FileNumber.FAGetValue();

                if (FileNumLength.Length == 10)
                {
                    Reports.StatusUpdate("Max length is 10", true);
                }
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail("Test Method failed due to" + ex.Message);
            }
        }


        #endregion

        #region Test FMUC0090_REG0008

        [TestMethod, Obsolete]

        public void FMUC0090_REG0008()
        {
            Reports.TestDescription = "FV02: Field Validation for File Number Text box - Covered in FMUC0090_REG0007";
            Reports.StatusUpdate("Covered in FMUC0090_REG0007", true);
        }

        #endregion



        #endregion

        #region Private Methods

        private void IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }


        private void CreateFileFromRFN(bool UncheckAutoNum, string ReserveFileNum)
        {

            if (UncheckAutoNum == false)
            {
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }

            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();
            if (FastDriver.QuickFileEntry.SubEscrow.Selected)
                FastDriver.QuickFileEntry.SubEscrow.FAClick();
            if (UncheckAutoNum == false)
            {
                FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(false);
                FastDriver.QuickFileEntry.FileNum.FASetText(ReserveFileNum);
            }

            FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
            FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
            FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
            FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
            FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
            FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
            FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
            FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
            FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
            FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
            FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
            FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
            FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
            FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
            FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
            FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
            FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
            FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
            Playback.Wait(1000);
            FastDriver.BottomFrame.Done();

        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }


    }
}
