﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using System.Linq;
using FASTWCFHelpers.FastFileService;
using System.Threading;


namespace FileManagement
{

    [CodedUITest]
    public class FMUC0115 : MasterTestClass
    {
        DateTime todaysdate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, TimeZoneInfo.Local.Id, "Pacific Standard Time");
        #region BAT
        #region FMUC0115_BAT0001
        [TestMethod]
        public void FMUC0115_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_FM6859 : Copy information from Starter/Base file to an open file,Group Miscellaneous Disbursements Information";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                Reports.TestStep = "Log into FAST application.";
                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                var File = _CreateFile();
                #endregion
                #region MainFlow
                var FileNum1 = File.FileNumber;
                var addressline1 = File.RealProperties[0].PropertyAddress[0].AddrLine1;
                Reports.TestStep = "Verify that Subject Line Contains File Number and logged in User user is defaulted in the FROM.";
                FastDriver.GenericEmail.Open();
                FastDriver.GenericEmail.VerifyFromToCCSubject(fromEmail: "testProactivenotification@abc.com", filenumber: FileNum1, addressline: addressline1);
                Reports.TestStep = "Enter recepient list in To ,CC, Subject and Message body";
                FastDriver.GenericEmail.SetToCCSubMessage(toaddress: AutoConfig.DeliverEmailTo, ccaddress: "", subject: Environment.MachineName + "-" + AutoConfig.FASTHomeURL + "-" + FileNum1, fontName: "Times New Roman", fontsize: "4", Messagebody: "Test : Body Data including - * # Specialcharacter :");

                #region <SRT-ServReq> - R08
                //Team                                  :  ServReq-Team1
                //Iteration                             :  r08
                //UserStory                             :  User Story 641435:REQ0751931 - Direct - Generic Email Signature Line doesn't update to Sender
                //TestCase                              :  829583
                //Appended By/ Created By               :  Tushar Shankar
                //SRT 08
                FastDriver.GenericEmail.FromButton.FAClick();
                FastDriver.SearchPageDlg.SwitchToDialogBottomFrame();
                string fromName = FastDriver.SearchPageDlg.SalesRepTable.PerformTableAction(2, 2, TableAction.GetText).Message.ToString();
                string fromEmail = FastDriver.SearchPageDlg.SalesRepTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString();
                FastDriver.SearchPageDlg.SalesRepTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.SearchPageDlg.Finished.FAClick();
                FastDriver.GenericEmail.SwitchToContentFrame();
                //SRT 08
                #endregion <SRT-ServReq> - R08

                FastDriver.GenericEmail.CheckSpelling.FAClick();
                Reports.TestStep = "Correct Spelling";
                FastDriver.SpellingErrorDialog.CorrectSpelling(correctedtext: "Special Character");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(1000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GenericEmail.WaitForScreenToLoad();
                FastDriver.GenericEmail.Email.FAClick();
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(1000);
                Reports.TestStep = "Verify entry of sent Email details in Email History";
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 1, date: todaysdate);
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 2, CellText: "testProactivenotification@abc.com");
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 4, CellText: Environment.MachineName + "-" + AutoConfig.FASTHomeURL + "-" + FileNum1);
                FastDriver.EventTrackingLog.Open();
                Reports.TestStep = "Verify Email sent entry in Event track log";
                FastDriver.EventTrackingLog.VerifyEventTableData(rowindex: 1, columnindex: 1, verificationtext: "[Email w/o Attachment]");
                FastDriver.EventTrackingLog.VerifyEventTableData(rowindex: 1, columnindex: 5, verificationtext: "Email w/o attachments successfully delivered to the recipients");
                
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
        #region FMUC0115_BAT0002
        [TestMethod]
        public void FMUC0115_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_01: Email is sent through Document Repository.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                Reports.TestStep = "Log into FAST application.";
                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                var File = _CreateFile();
                #endregion

                #region AF1
                var fileNum = File.FileNumber;
                var addressline1 = File.RealProperties[0].PropertyAddress[0].AddrLine1;
                Reports.TestStep = "Add a document.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.Upload.FAClick();
                string filePath = Support.ReadAppSettings("appSettings", "sharedLocation") + @"\ADJUTMBNJY.doc";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                Reports.TestStep = "Save the Doc.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(windowName: "Save Document", toExist: true, timeoutSeconds: 20);
                FastDriver.SaveDocumentDlg.SaveDocument(docType: @"Escrow: Payoff Demand/Bills", docName: "Miscellaneous", addtlInfo: "Document");
                Playback.Wait(20000);
                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(columnToSearchIndex: 4, searchValue: "Miscellaneous Document", actionCellIndex: 4, action: TableAction.Click);
                FastDriver.DocumentRepository.SelectDeliveryMethod(method: "EMAIL");
                FastDriver.DocumentRepository.ClickDeliver();
                FastDriver.EmailDlg.WaitForDialogToLoad();
                Reports.TestStep = "Send Email through Email Dialog";
                FastDriver.EmailDlg.SetToCCSubMessage(toaddress:  AutoConfig.DeliverEmailTo, ccaddress:  AutoConfig.DeliverEmailTo, subject: Environment.MachineName + "-" + AutoConfig.FASTHomeURL + "-" + fileNum, messagebody: "Testing Message");
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GenericEmail.Open();
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(1000);
                Reports.TestStep = "Verify sent email in history";
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 1, date: todaysdate);
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 2, CellText: "testProactivenotification@abc.com");
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 6, CellText: "Miscellaneous Document");
                FastDriver.EventTrackingLog.Open();
                Reports.TestStep = "Verify sent email in event track log";
                FastDriver.EventTrackingLog.SelectEventCategory(category: "All");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.EventTrackingLog.VerifyEventTableData(rowindex: 1, columnindex: 1, verificationtext: "[E-mail]");
                FastDriver.EventTrackingLog.VerifyEventTableData(rowindex: 1, columnindex: 4, verificationtext: "Email Service");


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion
        #region Test FMUC0115_BAT0003

        [TestMethod]
        public void FMUC0115_BAT0003()
        {

            try
            {
                Reports.TestDescription = "AF3_01: Forward Email.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                Reports.TestStep = "Log into FAST application.";
                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                var File = _CreateFile();
                string filenum = File.FileNumber;
                string addressline = File.RealProperties[0].PropertyAddress[0].AddrLine1;
                #endregion
                #region precondition
                _SendEmail();
                #endregion
                #region AF3_01
                Reports.TestStep = "Verify sent email in history";
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(250);
                FastDriver.EmailHistory.HistoryTable.PerformTableAction(rowIndex: 1, columnIndex: 5, action: TableAction.Click);
                FastDriver.GenericEmailDlg.WaitForDialogToLoad();
                FastDriver.GenericEmailDlg.Forward.FAClick();
                System.Threading.Thread.Sleep(5000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GenericEmail.WaitForScreenToLoad();
                Reports.TestStep = "Set To,CC,Subject and Message body and send email";
                FastDriver.GenericEmail.SetToCCSubMessage(toaddress:  AutoConfig.DeliverEmailTo, ccaddress:  AutoConfig.DeliverEmailTo);
                FastDriver.GenericEmail.Email.FAClick();
                Reports.TestStep = "Verify sent email in history";
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(250);
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 2, CellText: "testProactivenotification@abc.com");
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 4, CellText: "FW:File Number-" + filenum + "-Address-" + addressline);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion
        #region Test FMUC0115_BAT0004

        [TestMethod]
        public void FMUC0115_BAT0004()
        {

            try
            {
                Reports.TestDescription = "AF4_01: Cancel Email.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                var File = _CreateFile();
                string filenum = File.FileNumber;
                string addressline = File.RealProperties[0].PropertyAddress[0].AddrLine1;
                #endregion
                #region AF4
                FastDriver.GenericEmail.Open();
                Reports.TestStep = "Set To,CC,Subject and Message body and send email";
                FastDriver.GenericEmail.VerifyFromToCCSubject(fromEmail: "testProactivenotification@abc.com", filenumber: filenum, addressline: addressline);
                FastDriver.GenericEmail.SetToCCSubMessage(toaddress:  AutoConfig.DeliverEmailTo, ccaddress:  AutoConfig.DeliverEmailTo);
                Reports.TestStep = "Verify Cancel Error Warning";
                FastDriver.GenericEmail.Cancel.FAClick();
                Support.AreEqual("Are you sure you want to exit ?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.GenericEmail.WaitForScreenToLoad();
                FastDriver.GenericEmail.VerifyFromToCCSubject(fromEmail: "testProactivenotification@abc.com");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion
        #region FMUC0115_BAT0005
        [TestMethod]
        public void FMUC0115_BAT0005()
        {

            try
            {
                Reports.TestDescription = "AF5_01: Recipient Selected through Employee Search.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                var File = _CreateFile();
                string filenum = File.FileNumber;
                string addressline = File.RealProperties[0].PropertyAddress[0].AddrLine1;
                #endregion
                #region AF5
                FastDriver.GenericEmail.Open();
                Reports.TestStep = "Select mail Address from Employee Search for To ";
                FastDriver.GenericEmail.ToButton.FAClick();
                FastDriver.SearchPageDlg.WaitForDialogToLoad();
                FastDriver.SearchPageDlg.EmployeeSearchAddressBook.FAClick();
                FastDriver.SearchPageDlg.firstName.FASetText("Fast");
                FastDriver.SearchPageDlg.FindNow.FAClick();
                FastDriver.SearchPageDlg.WaitCreation();
                FastDriver.SearchPageDlg.SearchResult.PerformTableAction(2, "FAST QA02", 1, TableAction.On);
                FastDriver.SearchPageDlg.Finished.FAClick();
                Thread.Sleep(3000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GenericEmail.WaitForScreenToLoad();
                Reports.TestStep = "Select mail Address from Employee Search for To ";
                FastDriver.GenericEmail.CcButton.FAClick();
                FastDriver.SearchPageDlg.WaitForDialogToLoad();
                FastDriver.SearchPageDlg.EmployeeSearchAddressBook.FAClick();
                FastDriver.SearchPageDlg.firstName.FASetText("Fast");
                FastDriver.SearchPageDlg.FindNow.FAClick();
                FastDriver.SearchPageDlg.WaitCreation();
                FastDriver.SearchPageDlg.SearchResult.PerformTableAction(2, "FAST QA02", 1, TableAction.On);
                FastDriver.SearchPageDlg.Finished.FAClick();
                Thread.Sleep(3000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GenericEmail.WaitForScreenToLoad();
                Reports.TestStep = "Set Font and Message Body Text and send email";
                FastDriver.GenericEmail.SetToCCSubMessage(toaddress: "", ccaddress: "", subject: "", fontName: "", fontsize: "4", Messagebody: "Test : Body Data including - * # Specialcharacter :");
                FastDriver.GenericEmail.Email.FAClick();
                Thread.Sleep(3000);
                Reports.TestStep = "Verify sent email in history";
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(250);
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 2, CellText: "testProactivenotification@abc.com");
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 4, CellText: "File Number-" + filenum + "-Address-" + addressline);
                FastDriver.EventTrackingLog.Open();
                Reports.TestStep = "Verify Email sent entry in Event track log";
                FastDriver.EventTrackingLog.VerifyEventTableData(rowindex: 1, columnindex: 1, verificationtext: "[Email w/o Attachment]");
                FastDriver.EventTrackingLog.VerifyEventTableData(rowindex: 1, columnindex: 5, verificationtext: "Email w/o attachments successfully delivered to the recipients");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion
        #region FMUC0115_BAT0006_PH

        [TestMethod]
        public void FMUC0115_BAT0006_PH()
        {

            try
            {
                Reports.TestDescription = "MF_01: Please send mail and verify in ur outlook.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #endregion

        #region REG
        #region Test FMUC0115_REG0001

        [TestMethod]
        public void FMUC0115_REG0001()
        {

            try
            {
                Reports.TestDescription = "FM14500_FM14502: Allow sending Email w/o attachments.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                Reports.TestStep = "Log into FAST application.";
                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                var File = _CreateFile();
                #endregion
                #region FM14500_FM14502
                var FileNum1 = File.FileNumber;
                var addressline1 = File.RealProperties[0].PropertyAddress[0].AddrLine1;
                Reports.TestStep = "Verify that Subject Line Contains File Number and logged in User user is defaulted in the FROM.";
                FastDriver.GenericEmail.Open();
                FastDriver.GenericEmail.VerifyFromToCCSubject(fromEmail: "testProactivenotification@abc.com", filenumber: FileNum1, addressline: addressline1);
                Reports.TestStep = "Enter recepient list in To ,CC, Subject and Message body";
                FastDriver.GenericEmail.SetToCCSubMessage(toaddress:  AutoConfig.DeliverEmailTo, ccaddress: "", subject: "", fontName: "Times New Roman", fontsize: "4", Messagebody: "Test : Body Data including - * # Specialcharacter :");
                FastDriver.GenericEmail.Email.FAClick();
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(1000);
                Reports.TestStep = "Verify entry of sent Email details in Email History";
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 1, date: todaysdate);
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 2, CellText: "testProactivenotification@abc.com");
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 3, CellText:  AutoConfig.DeliverEmailTo);
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 4, CellText: "File Number-" + FileNum1 + "-Address-" + addressline1);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion
        #region Test FMUC0115_REG0002

        [TestMethod]
        public void FMUC0115_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM14501 : Allow viewing history of emails delivered out of FAST.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                Reports.TestStep = "Log into FAST application.";
                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                var File = _CreateFile();
                #endregion
                #region FM14501
                string filenumber = File.FileNumber;
                Reports.TestStep = "Add a document.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.Upload.FAClick();
                string filePath = Support.ReadAppSettings("appSettings", "sharedLocation") + @"\ADJUTMBNJY.doc";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                Reports.TestStep = "Save the Doc.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(windowName: "Save Document", toExist: true, timeoutSeconds: 20);
                FastDriver.SaveDocumentDlg.SaveDocument(docType: @"Escrow: Payoff Demand/Bills", docName: "Miscellaneous", addtlInfo: "Document");
                Playback.Wait(20000);
                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(columnToSearchIndex: 4, searchValue: "Miscellaneous Document", actionCellIndex: 4, action: TableAction.Click);
                FastDriver.DocumentRepository.SelectDeliveryMethod(method: "EMAIL");
                FastDriver.DocumentRepository.ClickDeliver();
                FastDriver.EmailDlg.WaitForDialogToLoad();
                Reports.TestStep = "Send Email through Email Dialog";
                FastDriver.EmailDlg.SetToCCSubMessage(toaddress:  AutoConfig.DeliverEmailTo, ccaddress:  AutoConfig.DeliverEmailTo, subject: Environment.MachineName + "-" + AutoConfig.FASTHomeURL + "-" + filenumber, messagebody: "Testing Message");
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GenericEmail.Open();
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(1000);
                Reports.TestStep = "Verify sent email in history";
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 1, date: todaysdate);
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 2, CellText: "testProactivenotification@abc.com");
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 6, CellText: "Miscellaneous Document");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion
        #region Test FMUC0115_REG0003

        [TestMethod]
        public void FMUC0115_REG0003()
        {

            try
            {
                Reports.TestDescription = "FM14502: Event Logging for successful email delivery.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                Reports.TestStep = "Log into FAST application.";
                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                var File = _CreateFile();
                string filenum = File.FileNumber;
                string addressline = File.RealProperties[0].PropertyAddress[0].AddrLine1;
                #endregion
                #region precondition
                _SendEmail();
                #endregion
                #region FM14502
                Reports.TestStep = "Verify sent email in history";
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(250);
                FastDriver.EmailHistory.HistoryTable.PerformTableAction(rowIndex: 1, columnIndex: 5, action: TableAction.Click);
                FastDriver.GenericEmailDlg.WaitForDialogToLoad();
                FastDriver.GenericEmailDlg.Forward.FAClick();
                Thread.Sleep(3000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.GenericEmail.WaitForScreenToLoad();
                Reports.TestStep = "Set To,CC,Subject and Message body and send email";
                FastDriver.GenericEmail.SetToCCSubMessage(toaddress:  AutoConfig.DeliverEmailTo, ccaddress:  AutoConfig.DeliverEmailTo);
                FastDriver.GenericEmail.Email.FAClick();
                Reports.TestStep = "Verify sent email in history";
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(250);
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 2, CellText: "testProactivenotification@abc.com");
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 4, CellText: "FW:File Number-" + filenum + "-Address-" + addressline);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion
        #region Test FMUC0115_REG0004_PH

        [TestMethod]
        public void FMUC0115_REG0004_PH()
        {

            try
            {
                Reports.TestDescription = "FM14500 :Email delivery will not be restricted to users within the First AM domain only.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test

        //US 765873 REQ0449519 - Agency - Generic eMail - Add Business Source Reference as Subject Line option when eMailing from FAST

       
        [TestMethod]
        public void FMUC0115_REG0005()
        {
            try
            {
                Reports.TestDescription = "UGeneric eMail: When the Business Source Reference checkbox is checked, the system shall automatically disable the check box, if populated, to display in the Subject Line, along with other checked options";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with Business Source Reference";

                var cusfile = RequestFactory.GetCreateFileDefaultRequest();

                cusfile.File.BusinessParties[0].CustomerReferenceNumber = "ref12345";
                var file = FileService.GetOrderDetails((int)FileService.CreateFile(cusfile).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to Generic Email screen";
                FastDriver.LeftNavigation.Navigate<GenericEmail>(@"Home>Order Entry>Generic Email").WaitForScreenToLoad();


                Reports.TestStep = "Verify Business Source Reference as a Subject Line Option checkbox, but not checked";
                Support.AreEqual(false, FastDriver.GenericEmail.BusinessSourceReference.IsSelected(), "Business Source Referen is not checked0");

                Reports.TestStep = "Verify only File Number and Property Address check box are checked";
                Support.AreEqual(true, FastDriver.GenericEmail.FileNumberChk_GenericEmail.IsSelected(), "File Number is checked0");
                Support.AreEqual(true, FastDriver.GenericEmail.PropertyAddressChk_GenericEmail.IsSelected(), " Property Address is checked0");

                Reports.TestStep = "Check the Business Source Reference check box";

                FastDriver.GenericEmail.BusinessSourceReference.FASetCheckbox(true);
                FastDriver.GenericEmail.WaitForScreenToLoad();


                Reports.TestStep = "Verify , that system instantly add the reference number in the subject line";
                Support.AreEqual(true, FastDriver.GenericEmail.EmailSubject.FAGetValue().Clean().Contains("ref12345"), "Reference number is correct");

                Reports.TestStep = "Enter email address and body then click on Email";

                FastDriver.GenericEmail.SetToCCSubMessage("test@firstam.com", null, null, null, null, "Testtext");

                FastDriver.GenericEmail.Email.FAClick();



                FastDriver.GenericEmail.WaitForScreenToLoad();

                Reports.TestStep = "Verify all check boxes are now unchecked";
                Support.AreEqual(false, FastDriver.GenericEmail.BusinessSourceReference.IsSelected(), "Business Source Referen is not checked0");
                Support.AreEqual(false, FastDriver.GenericEmail.FileNumberChk_GenericEmail.IsSelected(), "File Number is not checked0");
                Support.AreEqual(false, FastDriver.GenericEmail.PropertyAddressChk_GenericEmail.IsSelected(), " Property Address is not checked0");




            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

       

       
        [TestMethod]
        public void FMUC0115_REG0006()
        {
            try
            {
                Reports.TestDescription = "Generic eMail: When the Business Source Reference(BSR) checkbox is checked, the system shall automatically disable the check box, if NOT populated, NO BSF in the Subject Line";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with Business Source Reference";

                var cusfile = RequestFactory.GetCreateFileDefaultRequest();

                cusfile.File.BusinessParties[0].CustomerReferenceNumber = "ref12345";
                var file = FileService.GetOrderDetails((int)FileService.CreateFile(cusfile).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to Generic Email screen";
                FastDriver.LeftNavigation.Navigate<GenericEmail>(@"Home>Order Entry>Generic Email").WaitForScreenToLoad();


                Reports.TestStep = "Verify Business Source Reference as a Subject Line Option checkbox, but not checked";
                Support.AreEqual(false, FastDriver.GenericEmail.BusinessSourceReference.IsSelected(), "Business Source Referen is not checked0");

                Reports.TestStep = "Verify only File Number and Property Address check box are checked";
                Support.AreEqual(true, FastDriver.GenericEmail.FileNumberChk_GenericEmail.IsSelected(), "File Number is checked0");
                Support.AreEqual(true, FastDriver.GenericEmail.PropertyAddressChk_GenericEmail.IsSelected(), " Property Address is checked0");

                Reports.TestStep = "Check the Business Source Reference check box";

                FastDriver.GenericEmail.BusinessSourceReference.FASetCheckbox(true);
                FastDriver.GenericEmail.WaitForScreenToLoad();


                Reports.TestStep = "Verify , that system instantly add the reference number in the subject line";
                Support.AreEqual(true, FastDriver.GenericEmail.EmailSubject.FAGetValue().Clean().Contains("ref12345"), "Reference number is correct");

                Reports.TestStep = "Enter email address and body then click on Email";

                FastDriver.GenericEmail.SetToCCSubMessage("test@firstam.com", null, null, null, null, "Testtext");

                FastDriver.GenericEmail.Email.FAClick();

                FastDriver.GenericEmail.WaitForScreenToLoad();

                Reports.TestStep = "Verify all check boxes are now unchecked";
                Support.AreEqual(false, FastDriver.GenericEmail.BusinessSourceReference.IsSelected(), "Business Source Referen is not checked0");
                Support.AreEqual(false, FastDriver.GenericEmail.FileNumberChk_GenericEmail.IsSelected(), "File Number is not checked0");
                Support.AreEqual(false, FastDriver.GenericEmail.PropertyAddressChk_GenericEmail.IsSelected(), " Property Address is not checked0");



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

      

       
        [TestMethod]
        public void FMUC0115_REG0007()
        {
            try
            {
                Reports.TestDescription = "Generic eMail: When the Business Source Reference checkbox is UNchecked, the system enable the check box, if populated, shall NOT display in the Subject Line, along with other checked options";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Login to FAST";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with Business Source Reference";

                var cusfile = RequestFactory.GetCreateFileDefaultRequest();

                cusfile.File.BusinessParties[0].CustomerReferenceNumber = "ref12345";
                var file = FileService.GetOrderDetails((int)FileService.CreateFile(cusfile).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to Generic Email screen";
                FastDriver.LeftNavigation.Navigate<GenericEmail>(@"Home>Order Entry>Generic Email").WaitForScreenToLoad();


                Reports.TestStep = "Verify Business Source Reference as a Subject Line Option checkbox, but not checked";
                Support.AreEqual(false, FastDriver.GenericEmail.BusinessSourceReference.IsSelected(), "Business Source Referen is not checked0");

                Reports.TestStep = "Verify only File Number and Property Address check box are checked";
                Support.AreEqual(true, FastDriver.GenericEmail.FileNumberChk_GenericEmail.IsSelected(), "File Number is checked0");
                Support.AreEqual(true, FastDriver.GenericEmail.PropertyAddressChk_GenericEmail.IsSelected(), " Property Address is checked0");

                Reports.TestStep = "Verify , that system instantly add the reference number is NOT in the subject line";
                Support.AreEqual(false, FastDriver.GenericEmail.EmailSubject.FAGetValue().Clean().Contains("ref12345"), "Reference number is correct");

                Reports.TestStep = "Enter email address and body then click on Email";

                FastDriver.GenericEmail.SetToCCSubMessage("test@firstam.com", null, null, null, null, "Testtext");

                FastDriver.GenericEmail.Email.FAClick();


                FastDriver.GenericEmail.WaitForScreenToLoad();

                Reports.TestStep = "Verify all check boxes are now unchecked";
                Support.AreEqual(false, FastDriver.GenericEmail.BusinessSourceReference.IsSelected(), "Business Source Referen is not checked0");
                Support.AreEqual(false, FastDriver.GenericEmail.FileNumberChk_GenericEmail.IsSelected(), "File Number is not checked0");
                Support.AreEqual(false, FastDriver.GenericEmail.PropertyAddressChk_GenericEmail.IsSelected(), " Property Address is not checked0");



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        

        #endregion
        #region PRIVATE METHODS

        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }
        private OrderDetailsResponse _CreateFile()
        {
            Reports.TestStep = "Create Order";
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            var FileNum1 = File.FileNumber;
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            return File;
        }
        private void _SendEmail()
        {
            Reports.TestStep = "Set To,CC,Subject and Message body and send email";
            FastDriver.GenericEmail.Open();
            FastDriver.GenericEmail.SetToCCSubMessage(toaddress:  AutoConfig.DeliverEmailTo, ccaddress: "", subject: "", fontName: "", fontsize: "", Messagebody: "Test : Body Data including - * # Specialcharacter :");
            FastDriver.GenericEmail.Email.FAClick();

        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
