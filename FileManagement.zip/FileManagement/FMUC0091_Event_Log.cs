﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using System.Collections.Generic;
using System.Threading;

namespace FileManagement
{

    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class FMUC0091 : MasterTestClass
    {

        #region BAT

        #region FMUC0091_BAT0001
        [TestMethod]
        public void FMUC0091_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_001: Log a File Process Event – Triggered by Manual Entry.";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();

                Reports.TestStep = "Verify the Event Log for File created(Event)";
                Support.AreEqual("[Opened]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Opened]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Opened]", 2, TableAction.GetText).Message.Clean().Substring(0,10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Opened]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Opened]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("-sa-su", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Opened]", 6, TableAction.GetText).Message.Clean().Substring(4,6), "User"); // Only get the last 6 digits because supper user account is different between FINT, FAQA, and EVAL

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_BAT0002
        [TestMethod]
        public void FMUC0091_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF001: Log a File Process Event – Triggered by FAST Search System interface.; FM13333: Reflection of routed EWB order in FAST via FAST Search";

                #region Fast Search Setting
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.OfficeSetupOffice.Handle_Launch_Fast_Search_on_Open_Order();
                #endregion

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file using FAST GUI";
                CreateBasicFileFromFASTGUI();

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();

                Reports.TestStep = "Validate [Fast Search Initiated] event";
                Support.AreEqual("[Fast Search Initiated]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fast Search Initiated]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fast Search Initiated]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual("FAST Search Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fast Search Initiated]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fast Search Initiated]", 5, TableAction.GetText).Message.Clean().Contains("FASTSearch Request Initiated.").ToString(), "Comments");

                Reports.TestStep = "Refresh the screen, validate [FS Request Submitted] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual("[FS Request Submitted]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Submitted]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Submitted]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual("FAST Search Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Submitted]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Submitted]", 5, TableAction.GetText).Message.Clean().Contains("FASTSearch Request Submitted.").ToString(), "Comments");

                Reports.TestStep = "Wait 5 mins, Refresh the screen, validate [FS Request Completed] event";
                System.Threading.Thread.Sleep(300000);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                if (FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 1, TableAction.GetText).Message.Clean() != "[FS Request Completed]")
                {
                    Support.AreEqual("[FS Request Completed]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 1, TableAction.GetText).Message.Clean(), "Event");
                    Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                    Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                    Support.AreEqual("FAST Search Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 4, TableAction.GetText).Message.Clean(), "Source");
                    Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 5, TableAction.GetText).Message.Clean().Contains("FASTSearch Request Completed.").ToString(), "Comments");
                    //Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 5, TableAction.GetText).Message.Clean().Contains("Successful [EWB Order]").ToString(), "Comments");
                }
                else
                {
                    Reports.TestStep = "First try failed, try again after 1 min, Refresh the screen, validate [FS Request Completed] event";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                    System.Threading.Thread.Sleep(60000);
                    Support.AreEqual("[FS Request Completed]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 1, TableAction.GetText).Message.Clean(), "Event");
                    Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                    Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                    Support.AreEqual("FAST Search Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 4, TableAction.GetText).Message.Clean(), "Source");
                    Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 5, TableAction.GetText).Message.Clean().Contains("FASTSearch Request Completed.").ToString(), "Comments");
                    //Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FS Request Completed]", 5, TableAction.GetText).Message.Clean().Contains("Successful [EWB Order]").ToString(), "Comments");
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_BAT0003
        [TestMethod]
        public void FMUC0091_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF002: Log a Workflow Event – Triggered by Manual Entry.";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to File Workflow screen, start a task.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.Process);
                FastDriver.FileWorkflow.Process.PerformTableAction(1, 1, TableAction.On);
                string taskName = FastDriver.FileWorkflow.Process.PerformTableAction(1, 5, TableAction.GetText).Message.Clean();
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();

                Reports.TestStep = "Validate [Task Started and Assigned] event is added";
                FastDriver.EventTrackingLog.SelectEventCategory("Workflow");
                Support.AreEqual("[Task Started and Assigned]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Started and Assigned]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Started and Assigned]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Started and Assigned]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Started and Assigned]", 6, TableAction.GetText).Message.Clean(), "User"); 

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_BAT0004
        [TestMethod]
        public void FMUC0091_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF003: Log a Doc Delivery Event – Triggered by Manual Entry; AF008: Delete Document Event";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Document Repository screen, create a Form document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.FilteredTemplatesTab).FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.SearchTable.PerformTableAction(3, "Form", 1, TableAction.Click);
                string docName = FastDriver.DocumentRepository.SearchTable.PerformTableAction(3, "Form", 2, TableAction.GetText).Message.Clean();
                FastDriver.DocumentRepository.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Select the document, perform Print delivery.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 1, TableAction.Click);
                FastDriver.DocumentRepository.Method.FASelectItem("PRINT");
                FastDriver.DocumentRepository.Deliver.FAClick();

                Reports.TestStep = "Print Document.";
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 200);

                Reports.TestStep = "Navigate to Event Tracking Log screen, select Doc Delivery event category";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);

                Reports.TestStep = "Validate [Print] event is created";
                Support.AreEqual("[Print]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("Print Service", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 5, TableAction.GetText).Message.Clean().Contains(docName).ToString(), "Comments");
                Support.AreEqual(@"FAST QA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Navigate to Document Repository screen, Delete the Form document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 1, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Navigate to Event Tracking Log screen, validate [Removed Document] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual("[Removed Document]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 5, TableAction.GetText).Message.Clean().Contains(docName).ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 6, TableAction.GetText).Message.Clean(), "User");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_BAT0005
        [TestMethod]
        public void FMUC0091_BAT0005()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 4:  View Event Log; Project 2262 New 'Integration Services' category to Event Log; FM5094: Grouping Events By Category; FM5095: Display Categories; FM5096:  Event Log Display Fields";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();

                Reports.TestStep = "Validate event log header fields";
                Support.AreEqual("Event", FastDriver.EventTrackingLog.EventTableHeader.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual("Start Date/Time", FastDriver.EventTrackingLog.EventTableHeader.PerformTableAction(1, 2, TableAction.GetText).Message.Clean(), "Start Date/Time");
                Support.AreEqual("Completion Date/Time", FastDriver.EventTrackingLog.EventTableHeader.PerformTableAction(1, 3, TableAction.GetText).Message.Clean(), "Completion Date/Time");
                Support.AreEqual("Source", FastDriver.EventTrackingLog.EventTableHeader.PerformTableAction(1, 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("Comments", FastDriver.EventTrackingLog.EventTableHeader.PerformTableAction(1, 5, TableAction.GetText).Message.Clean(), "Comments");
                Support.AreEqual("User", FastDriver.EventTrackingLog.EventTableHeader.PerformTableAction(1, 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate default Event Category = File Process";
                Support.AreEqual("File Process", FastDriver.EventTrackingLog.EventCategory.FAGetSelectedItem(), "Default Event Category");

                Reports.TestStep = "Validate available values for event category dropdown list";
                string allEvent = FastDriver.EventTrackingLog.EventCategory.FAGetAllTextFromSelect("|");
                Support.AreEqual("True", allEvent.Contains("File Process").ToString(), "File Process");
                Support.AreEqual("True", allEvent.Contains("Workflow").ToString(), "Workflow");
                Support.AreEqual("True", allEvent.Contains("Doc Delivery").ToString(), "Doc Delivery");
                Support.AreEqual("True", allEvent.Contains("Accounting/Privacy").ToString(), "Accounting/Privacy");
                Support.AreEqual("True", allEvent.Contains("Recorded Doc").ToString(), "Recorded Doc");
                Support.AreEqual("True", allEvent.Contains("Recording").ToString(), "Recording");
                Support.AreEqual("True", allEvent.Contains("Real Time Mail").ToString(), "Real Time Mail");
                Support.AreEqual("True", allEvent.Contains("Notifications").ToString(), "Notifications");
                Support.AreEqual("True", allEvent.Contains("Property Search").ToString(), "Property Search");
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("True", allEvent.Contains("CD Changes").ToString(), "CD Changes");
                    Support.AreEqual("True", allEvent.Contains("CD Delivery").ToString(), "CD Delivery");
                }
                Support.AreEqual("True", allEvent.Contains("Integration Services").ToString(), "Integration Services");
                Support.AreEqual("True", allEvent.Contains("All").ToString(), "All");

                Reports.TestStep = "Select 'All' from Event Category";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Support.AreEqual("[Opened]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Opened]", 1, TableAction.GetText).Message.Clean(), "Event");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_BAT0006
        [TestMethod]
        public void FMUC0091_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF011_AF012: Log a Real Time Mail Delivery Event; Alternate Course 12:  View Real Time Mail Delivery Event Details";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Document Repository and click on Add button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Create a Form type document";
                FastDriver.AdHocDocuments.SearchDocument("Both", "Form", "", "");
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Form", "Type", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(10000);

                Reports.TestStep = "Create a Fax Cover Sheet type document";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad(FastDriver.DocumentRepository.FilteredTemplatesTab).FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.SearchDocument("Both", "Fax Cover Sheet", "", "");
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Fax Cover Sheet", "Type", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(10000);

                Reports.TestStep = "Select Multiple Docs For create RTM Package.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.SelectAllDocuments(); 
                FastDriver.DocumentRepository.RTMPackage.FAClick();

                Reports.TestStep = "Give Name For Package and click on Add Address Button in Mail To Tab.";
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.PackageIDName.FASetText("RTMPackage");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.RTM.SwitchToContentFrame();
                FastDriver.RTM.MailTo.FAClick();
                FastDriver.RTM.WaitCreation(FastDriver.RTM.SelectAddressees);
                FastDriver.RTM.SelectAddressees.FAClick();

                Reports.TestStep = "Select The Mail to Address Office.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Select Mail To Addresses");
                FastDriver.RTMMailToAddresseesDlg.SwitchToDialogContentFrame();
                FastDriver.RTMMailToAddresseesDlg.WaitCreation(FastDriver.RTMMailToAddresseesDlg.FileOffices);
                FastDriver.RTMMailToAddresseesDlg.FileOffices.FAClick();
                FastDriver.RTMMailToAddresseesDlg.WaitCreation(FastDriver.RTMMailToAddresseesDlg.EscrowOwningOfficeTable);
                FastDriver.RTMMailToAddresseesDlg.EscrowOwningOfficeTable.PerformTableAction(5, "CA", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Populate Return To Address.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.ReturnTo.FAClick();
                FastDriver.RTM.WaitCreation(FastDriver.RTM.ReturnToOfficeName);
                FastDriver.RTM.ReturnToOfficeName.FASelectItem("QA Automation Office - DO NOT TOUCH (Title Owning)");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Perform RTM Delivery.";
                FastDriver.DocumentRepository.SelectDeliveryMethod("REAL TIME MAIL").ClickDeliver();

                Reports.TestStep = "Click on Delivery button.";
                FastDriver.RealTimeMailDlg.WaitForScreenToLoad().Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("RTM", 200);

                Reports.TestStep = "Validate for Real Time Mail Delivery Event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Real Time Mail");
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                Support.AreEqual("[Real Time Mail]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Real Time Mail]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Real Time Mail]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Real Time Mail]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("Real Time Mail Service", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Real Time Mail]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual(@"FAST QA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Real Time Mail]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Select RTM event, click Details button";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Real Time Mail]", 1, TableAction.Click);
                FastDriver.EventTrackingLog.Details.FAClick();
                FastDriver.RTMLogDetailsWindow.WaitForScreenToLoad();
                Support.AreEqual("RTMPackage", FastDriver.RTMLogDetailsWindow.PackageName.FAGetText().Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_BAT0007
        [TestMethod]
        public void FMUC0091_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF14: Events Triggered by removal of Phrase Code from Commitment or Policy.";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Document Repository and click on Add button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add a title report document to the file";
                FastDriver.AdHocDocuments.SearchDocument("Both", "Title Reports", "", "");
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Title Reports", "Type", TableAction.Click);
                FastDriver.AdHocDocuments.CreateEdit.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                Playback.Wait(10000);
                // Select Delete from the Phrase menu
                Keyboard.SendKeys("%P");
                Playback.Wait(5000);
                Keyboard.SendKeys("D");
                Playback.Wait(1000);

                Reports.TestStep = "Select the first phrase to delete, click Done";
                FastDriver.EditorDlg.WaitForScreenToLoad();
                FastDriver.EditorDlg.PharsesTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Commitment/Policy Phrase Removed] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                Support.AreEqual("[Commitment/Policy Phrase Removed]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Commitment/Policy Phrase Removed]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Commitment/Policy Phrase Removed]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Commitment/Policy Phrase Removed]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Commitment/Policy Phrase Removed]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Commitment/Policy Phrase Removed]", 6, TableAction.GetText).Message.Clean(), "User");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_BAT0008
        [TestMethod]
        public void FMUC0091_BAT0008()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 6:  Log a File Process Event – Triggered by FASTSearch Date Down interface; FM7357: Automated Date Down Event Tracking";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Click D/D link on the top frame";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.DD.FAClick();

                Reports.TestStep = "Click Submit button on Date Down Request dialog";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Date Down Request", true, 20);
                FastDriver.DateDownRequest.WaitForScreenToLoad();
                FastDriver.DateDownRequest.Submit.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to Event/Tracking Log, validate [DD Request Initiated] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                Support.AreEqual("[DD Request Initiated]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Initiated]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Initiated]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Initiated]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Initiated]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Initiated]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Refresh Event/Tracking Log, validate [DD Request Submitted] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                Support.AreEqual("[DD Request Submitted]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Submitted]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Submitted]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Submitted]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("Date Down Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Submitted]", 4, TableAction.GetText).Message.Clean(), "Source");

                Reports.TestStep = "Wait 6 mins, Refresh Event/Tracking Log, validate [DD Request Completed] event";
                System.Threading.Thread.Sleep(360000);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                Support.AreEqual("[DD Request Completed]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Completed]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Completed]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Completed]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("Date Down Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Completed]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[DD Request Completed]", 5, TableAction.GetText).Message.Clean().Contains("DateDown Completed").ToString(), "Comments");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_BAT0009
        [TestMethod]
        public void FMUC0091_BAT0009()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 9:  Manual Request Event";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file with specified address for Data Tree";
                CreateBasicFileForDataTree();

                Reports.TestStep = "Navigate to Document Repository and click on Recorded Docs Request button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad(FastDriver.DocumentRepository.RecordedDocsRequest);
                FastDriver.DocumentRepository.RecordedDocsRequest.FAClick();

                Reports.TestStep = "Enter request data on Recorded Docs dialog window, click Submit button";
                FastDriver.RecordedDocsDlg.WaitForScreenToLoad(FastDriver.RecordedDocsDlg.Recordedcostable);
                FastDriver.RecordedDocsDlg.County.FASelectItem("Alpine");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.RecordedDocsDlg.WaitForScreenToLoad(FastDriver.RecordedDocsDlg.Recordedcostable);
                FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(1, "Assessor Map - Book.Page", 1, TableAction.Click);
                FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(1, "Assessor Map - Book.Page", 5, TableAction.SetText, ".2");
                FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(1, "Assessor Map - Book.Page", 7, TableAction.SetText, "3" + FAKeys.Tab);
                FastDriver.RecordedDocsDlg.Submit.FAClick();

                Reports.TestStep = "Wait 5 mins, click Refresh button";
                System.Threading.Thread.Sleep(300000);
                FastDriver.RecordedDocsDlg.Refresh.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.RecordedDocsDlg.WaitForScreenToLoad(FastDriver.RecordedDocsDlg.Recordedcostable);

                Reports.TestStep = "Check for completed status, if not wait for 2 more mins";
                if (FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(1, "Assessor Map - Book.Page", 13, TableAction.GetText).Message.Clean() == "Completed")
                    FastDriver.DialogBottomFrame.ClickDone();
                else
                {
                    System.Threading.Thread.Sleep(120000);
                    FastDriver.DialogBottomFrame.ClickDone();
                }

                Reports.TestStep = "Navigate to Event/Tracking Log, validate Recorded Doc event";
                try
                {
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                    FastDriver.EventTrackingLog.EventCategory.FASelectItem("Recorded Doc");
                    FastDriver.EventTrackingLog.WaitForScreenToLoad();
                    FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                    Support.AreEqual("[Manual Request]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 1, TableAction.GetText).Message.Clean(), "Event");
                    Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                    Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                    Support.AreEqual("Data Tree Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 4, TableAction.GetText).Message.Clean(), "Source");
                    Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 5, TableAction.GetText).Message.Clean().Contains("Assessor Map - Book.Page").ToString(), "Comments");

                }catch
                {
                    Reports.TestStep = "First try failed, try again. Navigate to Event/Tracking Log, validate Recorded Doc event";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                    FastDriver.EventTrackingLog.EventCategory.FASelectItem("Recorded Doc");
                    FastDriver.EventTrackingLog.WaitForScreenToLoad();
                    FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                    Support.AreEqual("[Manual Request]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 1, TableAction.GetText).Message.Clean(), "Event");
                    Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                    Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                    Support.AreEqual("Data Tree Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 4, TableAction.GetText).Message.Clean(), "Source");
                    Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Request]", 5, TableAction.GetText).Message.Clean().Contains("Assessor Map - Book.Page").ToString(), "Comments");
                }
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_BAT0010
        [TestMethod]
        public void FMUC0091_BAT0010()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 19: Log a File Process Event – FAST Fee Interface to FACC Override; FM10526: Log a File Process Event for FACC Override";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Fee Entry screen, select Title and Endorsement Fees, click Calculate Fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleRates.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "From Calculate Fees screen, select a Title Product and click on 'Add Title Product group' button.";
                FastDriver.CalculateFees.SelectTitleAndEndorsement();
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Set title fee.";
                string[] titleFee = FastDriver.CalculateFees.SelectFeeFromSummaryTable(2, "Seller", "Permitted Rate Surcharge", "100.00", true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Event/Tracking Log, validate [FACC Override] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                Support.AreEqual("[FACC Override]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FACC Override]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FACC Override]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FACC Override]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FACC Override]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FACC Override]", 5, TableAction.GetText).Message.Clean().Contains(titleFee[0]).ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FACC Override]", 6, TableAction.GetText).Message.Clean(), "User");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion BAT

        #region REG

        #region FMUC0091_REG0001
        [TestMethod]
        public void FMUC0091_REG0001()
        {
            try
            {
                Reports.TestDescription = "Signing Events Triggered by FAST; FM13188: Event log for Signing order in Pending status from FAST to FASS";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a new file.";
                CreateBasicFileWithLoanBuyerSeller();

                Reports.TestStep = "Navigate to Signature Signing screen, Click New button";
                FastDriver.LeftNavigation.Navigate<SignatureSigning>(@"Home>Order Entry>Escrow Closing>Signature Signing").WaitForScreenToLoad();
                FastDriver.SignatureSigning.New.FAClick();

                Reports.TestStep = "Enter signing date/time, click Save";
                FastDriver.SignatureSigning.ProposedDate.FASetText(DateTime.Now.ToDateString(), false);
                FastDriver.SignatureSigning.ProposedTime.FASetText("7:00:00 AM" + FAKeys.Tab, false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Select the new signing, click Order Signing button";
                FastDriver.SignatureSigning.WaitForScreenToLoad(FastDriver.SignatureSigning.SigningSummary);
                FastDriver.SignatureSigning.SigningSummary.PerformTableAction(1, 1, TableAction.Click);
                Support.AreEqual("Pending", FastDriver.SignatureSigning.SigningSummary.PerformTableAction(1, 4, TableAction.GetText).Message.Clean());
                FastDriver.SignatureSigning.WaitForScreenToLoad(FastDriver.SignatureSigning.OrderSigning);
                FastDriver.SignatureSigning.OrderSigning.FAClick();
                FastDriver.SignatureSigning.WaitForScreenToLoad(FastDriver.SignatureSigning.SigningSummary);
                Support.AreEqual("Submitted", FastDriver.SignatureSigning.SigningSummary.PerformTableAction(1, 4, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Signing Created] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Signing");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Support.AreEqual("[Signing Created]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("Signing [S.No. 01] Submitted Successfully", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean(), "User");

                Support.AreEqual("[Signing Created]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("Signing [S.No. 01] Created Successfully in Pending Status", FastDriver.EventTrackingLog.EventTable.PerformTableAction(2, 5, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(2, 6, TableAction.GetText).Message.Clean(), "User");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0002
        [TestMethod]
        public void FMUC0091_REG0002()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 21:  Log a File Process Event – Project file routing to myFAST NCS success; FM13407: Event Logging for successful Order Routing to myFAST NCS";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();
                //Project file event doesn't work on QA Automation region so test on QA Sandpointe region
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(@"191");

                Reports.TestStep = "Create a new Project file.";
                CreateProjectFile();

                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Project File] event";
                FastDriver.EventTrackingLog.Open();
                int i = 0;

                for (i = 1; i <= 10; i++)
                {
                    if (FastDriver.EventTrackingLog.EventTable.StringExistOnTable("[Project File]"))
                    {
                        Reports.TestStep = "Navigate to Event/Tracking Log, validate [Project File] event";
                        Support.AreEqual("[Project File]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Project File]", 1, TableAction.GetText).Message.Clean(), "Event");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Project File]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Project File]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                        Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Project File]", 4, TableAction.GetText).Message.Clean(), "Source");
                        Support.AreEqual("Order successfully routed to myFAST NCS.", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Project File]", 5, TableAction.GetText).Message.Clean(), "Comments");
                        Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Project File]", 6, TableAction.GetText).Message.Clean(), "User");
                        break;
                    }
                    else
                    {
                        Playback.Wait(5000);
                        FastDriver.EventTrackingLog.Open();
                    }
                }

                if (i == 11)
                    FailTest("Event does not exist in event log");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0003
        [TestMethod]
        public void FMUC0091_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM6264  Payoff Demands Event Log Tracking";

                Reports.TestStep = "Login FAST ADM Site; check ePayoff is enabled for GAB";
                LoginFastADMSite();
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.SearchAddressBook("1254");
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "1254", 2, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Select Corporate Parent='Bank of America'";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Bank of America");
                FastDriver.BusPartyOrgSetUp.eSubscriptions.FAClick();
                FastDriver.BusPartyOrgeSubscriptionsDlg.WaitForScreenToLoad();
                FastDriver.BusPartyOrgeSubscriptionsDlg.ePayoff.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a new payoff demand file.";
                CreatePayoffDemandFile();

                Reports.TestStep = "Validate Payoff Demand Request message";
                FastDriver.PayoffDemandRequestDlg.WaitForScreenToLoad();
                FastDriver.PayoffDemandRequestDlg.OKbtn.FAClick();

                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Payoff Demand Request Initiated] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                Support.AreEqual("[Payoff Demand Request Initiated]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Payoff Demand Request Initiated]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Payoff Demand Request Initiated]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Payoff Demand Request Initiated]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Payoff Demand Request Initiated]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Payoff Demand Request Initiated]", 5, TableAction.GetText).Message.Clean().Contains("Payoff Demand Request Initiated").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Payoff Demand Request Initiated]", 6, TableAction.GetText).Message.Clean(), "User");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0004
        [TestMethod]
        public void FMUC0091_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM6999: Print Service; FM7000: E-Mail Service; FM7001: Fax Service";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Document Repository screen, create a Form document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.SearchTable.PerformTableAction(3, "Form", 1, TableAction.Click);
                string docName = FastDriver.DocumentRepository.SearchTable.PerformTableAction(3, "Form", 4, TableAction.GetText).Message.Clean();
                FastDriver.DocumentRepository.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Select the document, perform Print delivery.";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 1, TableAction.Click);
                FastDriver.DocumentRepository.Method.FASelectItem("PRINT");
                FastDriver.DocumentRepository.Deliver.FAClick();

                Reports.TestStep = "Print Document.";
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Select the Email Delivery method.";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 1, TableAction.Click);
                FastDriver.DocumentRepository.SelectDeliveryMethod("EMAIL").ClickDeliver();

                Reports.TestStep = "Select to and click on email delivery.";
                FastDriver.EmailDlg.WaitForDialogToLoad();
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
                string emailSubject = Environment.MachineName + " -" + AutoConfig.FASTHomeURL;
                FastDriver.EmailDlg.Subject.FASetText(emailSubject);
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);

                Reports.TestStep = "Perform Fax delivery.";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 1, TableAction.Click);
                FastDriver.DocumentRepository.Method.FASelectItem("FAX");
                FastDriver.DocumentRepository.Deliver.FAClick();
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Insert.FAClick();
                FastDriver.FaxDlg.Name.FASetText(@"QA");
                FastDriver.FaxDlg.Attn.FASetText(@"1");
                FastDriver.FaxDlg.FAXNumber.FASetText(AutoConfig.DeliverFaxTo);
                FastDriver.FaxDlg.FAX.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 200);

                Reports.TestStep = "Navigate to Event Tracking Log screen, select Doc Delivery event category";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);

                Reports.TestStep = "Validate [Print] event is created";
                Support.AreEqual("[Print]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("Print Service", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 5, TableAction.GetText).Message.Clean().Contains(docName).ToString(), "Comments");
                Support.AreEqual(@"FAST QA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate [E-mail] event is created";
                Support.AreEqual("[E-mail]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("Email Service", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 5, TableAction.GetText).Message.Clean().Contains(docName).ToString(), "Comments");
                Support.AreEqual(@"FAST QA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate [Fax] event is created";
                Support.AreEqual("[Fax]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fax]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fax]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fax]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("Fax Service", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fax]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fax]", 5, TableAction.GetText).Message.Clean().Contains(docName).ToString(), "Comments");
                Support.AreEqual(@"FAST QA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fax]", 6, TableAction.GetText).Message.Clean(), "User");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0005
        [TestMethod]
        public void FMUC0091_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM6714: Task Office Assignment; FM6715: Production Office Removed";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to File Workflow screen, change task office selection";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                Playback.Wait(1000);
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.ActiveOnly);
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                Playback.Wait(1000);
                //Screen get refreshed
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                Playback.Wait(1000);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Click the Task Office Selection button on the first task";
                string taskName = FastDriver.FileWorkflow.MainTable.PerformTableAction(2, 5, TableAction.GetText).Message.Clean();
                FastDriver.FileWorkflow.MainTable.PerformTableAction(2, 7, TableAction.Click);

                Reports.TestStep = "Select 'QA SANDPOINTE OFFICE' from the Task Office Selection dialog; click Select button";
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.PerformTableAction(3, "QA SANDPOINTE OFFICE", 1, TableAction.Click);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to File Homepage, remove a production office";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.AddRemoveEscOff.FAClick();
                FastDriver.OfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.OfficeSelectionDlg.OfficesTable.PerformTableAction(2, "QA Automation Office - DO NOT TOUCH", 1, TableAction.Off);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                
                Reports.TestStep = "Validate [Production Office Deleted] event is created";
                Support.AreEqual("[Production Office Deleted]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Production Office Deleted]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Production Office Deleted]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Production Office Deleted]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Production Office Deleted]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("Production Office Deleted: QA Automation Office - DO NOT TOUCH (1487)", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Production Office Deleted]", 5, TableAction.GetText).Message.Clean(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Production Office Deleted]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate [Task Office Assigned] event is created";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Workflow");
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                Support.AreEqual("[Task Office Assigned]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Office Assigned]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Office Assigned]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Office Assigned]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Office Assigned]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("Task: " + taskName + " To: QA SANDPOINTE OFFICE", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Office Assigned]", 5, TableAction.GetText).Message.Clean(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Task Office Assigned]", 6, TableAction.GetText).Message.Clean(), "User");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0006
        [TestMethod]
        public void FMUC0091_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM6995: Log a Delivery Event for 1099-S Form Delivery";

                Reports.TestStep = "Login FAST ADM application.";
                LoginFastADMSite();

                Reports.TestStep = "Navigate to Office Setup screen, set 1099-S Activity Date";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText(DateTime.Now.ToString("MM/dd/yyyy"));
                FastDriver.BottomFrame.Done();
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithLoanBuyerSeller();

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Navigate to Terms/Dates/Status screen, set order received date/time";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.OrderRecievedDate.FASetText(DateTime.Now.ToDateString() + FAKeys.Tab);
                FastDriver.TermsDatesStatus.OrderRecievedTime.FASetText("09:00 AM PST" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Sellers screen, set 1099-S Classification";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Buyer1099sClassification.FASelectItemBySendingKeys("1099-S" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to 1099-S screen, create a new 1099-S";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("200,000.00" + FAKeys.Tab);
                FastDriver._1099S.ActiveReadyForExtract.FASetCheckbox(true);
                FastDriver._1099S.ActiveAddress.FASetText("2 First American Way" + FAKeys.Tab);
                FastDriver._1099S.ActiveCity.FASetText("Santa Ana" + FAKeys.Tab);
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("CA");
                FastDriver._1099S.ActiveZip.FASetText("92704" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Select Print method, click Deliver button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.WaitCreation(FastDriver._1099S.Deliver);
                FastDriver._1099S.Method.FASelectItem("Print");
                FastDriver._1099S.Deliver.FAClick();

                Reports.TestStep = "Print Document.";
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);

                Reports.TestStep = "Validate [Print] event is created";
                Support.AreEqual("[Print]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("Print Service", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 5, TableAction.GetText).Message.Clean().Contains("SEC-1099-S Copy B").ToString(), "Comments");
                Support.AreEqual(@"FAST QA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 6, TableAction.GetText).Message.Clean(), "User");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0007
        [TestMethod]
        public void FMUC0091_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM8766: Event Logs for Updated Title Production Fields";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Properties/Tax Info screen, select a property, click Edit";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Table.PerformTableAction(1, "1", 1, TableAction.DoubleClick);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TitleProductionTab.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionPlanEffactiveDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionVesting.FASetText("Test Vesting");
                FastDriver.PropertyTaxInfoTitleProd.ClickExcReqInfSave();

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();

                Reports.TestStep = "Validate [Modify Title Plant Date] event is created";
                Support.AreEqual("[Modify Title Plant Date]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Plant Date]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Plant Date]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Plant Date]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Plant Date]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Plant Date]", 5, TableAction.GetText).Message.Clean().Contains("ATP Initiated").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Plant Date]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate [Modify Title Vesting] event is created";
                Support.AreEqual("[Modify Title Vesting]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Vesting]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Vesting]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Vesting]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Vesting]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Vesting]", 5, TableAction.GetText).Message.Clean().Contains("ATP Initiated").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Modify Title Vesting]", 6, TableAction.GetText).Message.Clean(), "User");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0008
        [TestMethod]
        public void FMUC0091_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM10012: Paid Disbursement Adjustment";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Make a deposit into the file.";
                #region Deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 20000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Navigate to Home Warranty Screen";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HUDFLINSR1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(2, 3, TableAction.SetText, "10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen, select the pending check, click Print";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "10.00", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Click Deliver on Print Checks screen";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();

                Reports.TestStep = "Print the check";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Navigate to Disbursement History screen.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                Reports.TestStep = "Select the issued check, click Adjust";
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7, "10.00", 7, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Enter adjustment information on Disbursement Adjustment screen";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Input Error");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 10, true);

                Reports.TestStep = "Navigate to Deposit/Receipt history screen, select the deposit, click Adjust button";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, "20,000.00", 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Enter Adjustment information on Deposit Adjustment screen, click Save";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Input Error");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 10, true);

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);

                Reports.TestStep = "Validate [Disbursement Adjustment] event is created";
                Support.AreEqual("[Disbursement Adjustment]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 5, TableAction.GetText).Message.Clean().Contains("Adjustment Reason: Input Error").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate [Deposit Adjustment] event is created";
                Support.AreEqual("[Deposit Adjustment]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Deposit Adjustment]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Deposit Adjustment]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Deposit Adjustment]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Deposit Adjustment]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Deposit Adjustment]", 5, TableAction.GetText).Message.Clean().Contains("Adjustment Reason: Input Error").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Deposit Adjustment]", 6, TableAction.GetText).Message.Clean(), "User");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0009
        [TestMethod]
        public void FMUC0091_REG0009()
        {
            try
            {
                Reports.TestDescription = "FM10053: Log an Event for IBA Transaction Summary Report Delivery; FM10054: Log an Event for IBA Transaction Detail Report Delivery";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithLoanBuyerSeller();

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Make a deposit into the file.";
                #region Deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 20000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Playback.Wait(250);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary, 10);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad(timeout: 15);
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText(@"Abc" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText(@"Address Line 1" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText(@"Address Line 2" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText(@"Santa ana" + FAKeys.Tab); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem(@"CA"); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText(@"92727" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText(@"123456789" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click IBA Bank, select IBA bank, click Done";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary, 10);
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click Transactions tab, enter amount";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.Transactions.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.TransactionAmount);
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10000" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click Details tab, select Print method, click Deliver";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Details);
                FastDriver.InterestBearingAccounts.Details.FAClick();
                FastDriver.InterestBearingAccounts.DeliveryMethod.FASelectItem("Print");
                FastDriver.InterestBearingAccounts.Deliver.FAClick();

                Reports.TestStep = "Print Document.";
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);

                Reports.TestStep = "Validate [Print] event is created";
                Support.AreEqual("[Print]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("Print Service", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 5, TableAction.GetText).Message.Clean().Contains("Documents: IBA Transaction Detail Report").ToString(), "Comments");
                Support.AreEqual(@"FAST QA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Print]", 6, TableAction.GetText).Message.Clean(), "User");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0010
        [TestMethod]
        public void FMUC0091_REG0010()
        {
            try
            {
                Reports.TestDescription = "FM13170: Log an Event for Remove Document; FM13172: Log an Event for Purge FAST Document; FM13290: Log an Event for Document Name Changed";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Document Repository screen, create a Form document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.SearchTable.PerformTableAction(3, "Form", 1, TableAction.Click);
                string docName = FastDriver.DocumentRepository.SearchTable.PerformTableAction(3, "Form", 4, TableAction.GetText).Message.Clean();
                FastDriver.DocumentRepository.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Navigate to Document Repository screen, rename the document";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 10, TableAction.Click);

                Reports.TestStep = "Change document name, click Done";
                FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.Name.FASetText(docName + "_changed");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Delete the Form document";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 1, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Navigate to Event Tracking Log screen, validate [Removed Document] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual("[Removed Document]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 5, TableAction.GetText).Message.Clean().Contains(docName).ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Document]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate [Doc Name Changed] event";
                Support.AreEqual("[Doc Name Changed]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Doc Name Changed]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Doc Name Changed]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Doc Name Changed]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Doc Name Changed]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Doc Name Changed]", 5, TableAction.GetText).Message.Clean().Contains(docName).ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Doc Name Changed]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Navigate to Document Repository screen, select Removed Items";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Form", 6, TableAction.Click);
                Playback.Wait(2000);
                FastDriver.DocumentRepository.Purge.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to Event Tracking Log screen, validate [Purged Document] event";
                FastDriver.EventTrackingLog.Open();
                int i = 0;

                for (i = 0; i <= 10; i++ )
                {
                    if (FastDriver.EventTrackingLog.EventTable.StringExistOnTable("[Purged Document]"))
                    {
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Document]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Document]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                        Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Document]", 4, TableAction.GetText).Message.Clean(), "Source");
                        Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Document]", 5, TableAction.GetText).Message.Clean().Contains(docName).ToString(), "Comments");
                        Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Document]", 6, TableAction.GetText).Message.Clean(), "User");
                        break;
                    }
                    else
                    {
                        Playback.Wait(5000);
                        FastDriver.EventTrackingLog.Open();
                    }
                }

                if (i == 11)
                    FailTest("Event does not exist in event log");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0011
        [TestMethod]
        public void FMUC0091_REG0011()
        {
            try
            {
                Reports.TestDescription = "FM13468: CPL request Event Tracking";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithLoanBuyerSellerForCPL();

                Reports.TestStep = "Creates a Closing Protection Letter for the source file.";
                FastDriver.LeftNavigation.Navigate<ClosingProtectionLetter>(@"Home>Order Entry>Closing Protection Letter").WaitForScreenToLoad();
                FastDriver.ClosingProtectionLetter.Office.FASelectItem(@"DEMO - ABC Settlement Services/OH/Cleveland");
                FastDriver.ClosingProtectionLetter.BuyerSummaryTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.ClosingProtectionLetter.LenderTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ClosingProtectionLetter.SubmitCPLRequest.FAClick();
                Playback.Wait(10000);
                Support.CloseAllProcessStartingWith("AcroRd");

                Reports.TestStep = "Navigate to Event Tracking Log screen, validate [CPL request Completed] event";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual("[CPL request Completed]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[CPL request Completed]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[CPL request Completed]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[CPL request Completed]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("AgentNet Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[CPL request Completed]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[CPL request Completed]", 5, TableAction.GetText).Message.Clean().Contains("CPL received for the following Covered Party(s) : LENDER").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[CPL request Completed]", 6, TableAction.GetText).Message.Clean(), "User");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0012
        [TestMethod]
        public void FMUC0091_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM13566: Log an Event when request is sent to transfer Service Fees; FM13567: Log an Event when request is sent to cancel Service Fee transact; FM14753: Allow Ability to View Accounting/Privacy Event Logs ";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithLoanBuyerSeller();

                Reports.TestStep = "Navigate to Service Fees screen, click New button";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.ClickNew();

                Reports.TestStep = "Select a payee from Payee Search screen";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter service fee amount";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(2, 4, TableAction.SetText, "100.00" + FAKeys.Tab);

                Reports.TestStep = "Click Transfer button";
                FastDriver.ServiceFee.Transfer.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click Cancel button";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.Cancel.FAClick();
                FastDriver.CancelDlg.WaitForScreenToLoad();
                FastDriver.CancelDlg.Reason.FASetText("Test Cancel");
                FastDriver.CancelDlg.OK.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click Done button from bottom frame";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);

                Reports.TestStep = "Navigate to Event Tracking Log screen, validate [Transfer Service Fees] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                Support.AreEqual("[Transfer Service Fees]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Transfer Service Fees]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Transfer Service Fees]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Transfer Service Fees]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Transfer Service Fees]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Transfer Service Fees]", 5, TableAction.GetText).Message.Clean().Contains("Document Type: Service Fee Transfer").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Transfer Service Fees]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate [Cancel Service Fees] event";
                Support.AreEqual("[Cancel Service Fees]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Cancel Service Fees]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Cancel Service Fees]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Cancel Service Fees]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Cancel Service Fees]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Cancel Service Fees]", 5, TableAction.GetText).Message.Clean().Contains("Document Type: Service Fee Transfer").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Cancel Service Fees]", 6, TableAction.GetText).Message.Clean(), "User");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0013
        [TestMethod]
        public void FMUC0091_REG0013()
        {
            try
            {
                Reports.TestDescription = "FM14758: Log Event for Void Disbursement  ";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Make a deposit into the file.";
                #region Deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 20000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Navigate to Home Warranty Screen";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HUDFLINSR1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(2, 3, TableAction.SetText, "10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen, select the pending check, click Print";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "10.00", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Click Deliver on Print Checks screen";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();

                Reports.TestStep = "Print the check";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Navigate to Active Disbursement Summary screen, select the pending check, click Void";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "10.00", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Test void");
                FastDriver.VoidDlg.OK.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);

                Reports.TestStep = "Validate [Disbursement Adjustment] event is created";
                Support.AreEqual("[Void Disbursement]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Void Disbursement]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Void Disbursement]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Void Disbursement]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Void Disbursement]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Void Disbursement]", 5, TableAction.GetText).Message.Clean().Contains("Void Amount: 10.00").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Void Disbursement]", 6, TableAction.GetText).Message.Clean(), "User");

                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0014
        [TestMethod]
        public void FMUC0091_REG0014()
        {
            try
            {
                Reports.TestDescription = "FM6465: Sales Rep Changed Event Comment; FM6466: File Business Party and Sales Rep Changed Event Comment";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file with bus org with sale rep";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to File Homepage and change sale rep only";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartySalesRep1.FASelectItemByIndex(1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to File Homepage and change sale rep and Business Source GAB code";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartySalesRep1.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText("BOA");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to Event Tracking Log screen";
                FastDriver.EventTrackingLog.Open();
                int i = 0;

                for (i = 0; i <= 10; i++ )
                {
                    if (FastDriver.EventTrackingLog.EventTable.StringExistOnTable(@"Sales Reps Changed"))
                    {
                        Reports.TestStep = "Validate [FileBusiness Party & SalesRep(s) changed] event is created";
                        Support.AreEqual("[FileBusiness Party & SalesRep(s) changed]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FileBusiness Party & SalesRep(s) changed]", 1, TableAction.GetText).Message.Clean(), "Event");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FileBusiness Party & SalesRep(s) changed]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FileBusiness Party & SalesRep(s) changed]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                        Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FileBusiness Party & SalesRep(s) changed]", 4, TableAction.GetText).Message.Clean(), "Source");
                        Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FileBusiness Party & SalesRep(s) changed]", 5, TableAction.GetText).Message.Clean().Contains("File Business Party Business Source changed from:").ToString(), "Comments");
                        Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[FileBusiness Party & SalesRep(s) changed]", 6, TableAction.GetText).Message.Clean(), "User");

                        Reports.TestStep = "Validate [Sales Reps Changed] event is created";
                        Support.AreEqual("[Sales Reps Changed]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Reps Changed]", 1, TableAction.GetText).Message.Clean(), "Event");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Reps Changed]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Reps Changed]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                        Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Reps Changed]", 4, TableAction.GetText).Message.Clean(), "Source");
                        Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Reps Changed]", 5, TableAction.GetText).Message.Clean().Contains("File Business Party Business Source For").ToString(), "Comments");
                        Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Reps Changed]", 6, TableAction.GetText).Message.Clean(), "User");
                        break;
                    }
                    else
                    {
                        Thread.Sleep(5000);
                        FastDriver.EventTrackingLog.Open();
                    }
                }

                if (i == 11)
                    FailTest("Event does not exist in event log");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0015
        [TestMethod]
        public void FMUC0091_REG0015()
        {
            try
            {
                Reports.TestDescription = "FM11698: Log event when process is added using  the 'Add Process' feature";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to File Workflow screen, uncheck Active Only checkbox, click Add Process button";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.FileWorkflow.AddProcess.FAClick();
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();

                Reports.TestStep = "Select the first process from the Add Process to File Workflow table";
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Event Tracking Log screen, select Workflow from Event Category";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Workflow");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);

                Reports.TestStep = "Validate [Manual Process Added] event is created";
                Support.AreEqual("[Manual Process Added]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Process Added]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Process Added]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Process Added]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Process Added]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Process Added]", 5, TableAction.GetText).Message.Clean().Contains("Description: Best match process added for the selected process type.").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Manual Process Added]", 6, TableAction.GetText).Message.Clean(), "User");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0016
        [TestMethod]
        public void FMUC0091_REG0016()
        {
            try
            {
                Reports.TestDescription = "FM12699  Log an Event for Sales Tax Override";

                Reports.TestStep = "Login FAST ADM Site; navigate to region level";
                LoginFastADMSite();
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(@"1486");

                Reports.TestStep = "Navigate to Fee Summary screen, select the first fee, double click";
                FastDriver.LeftNavigation.Navigate<FeeList2>("Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.FeeFormType.FASelectItemBySendingKeys(AutoConfig.FormType + FAKeys.Tab);
                Playback.Wait(10000);
                FastDriver.FeeList2.WaitScreenToLoad();
                string feeName = FastDriver.FeeList2.FeeTable.PerformTableAction(1, 4, TableAction.GetText).Message.Clean();
                FastDriver.FeeList2.FeeTable.PerformTableAction(1, 2, TableAction.DoubleClick);

                Reports.TestStep = "Check Subject to Seles Tax checkbox, click Add/Remove button";
                FastDriver.FeeSetup.WaitForScreenToLoad();
                FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(true);
                FastDriver.FeeSetup.SubjectTocalculation.FASetCheckbox(false);
                FastDriver.FeeSetup.AddRemove.FAClick();

                Reports.TestStep = "Select All from Fee Templates dialog, click Done";
                FastDriver.FeeFilterTemplateSummaryDlg.WaitForScreenToLoad();
                FastDriver.FeeFilterTemplateSummaryDlg.FeeFilterTable.PerformTableAction(2, "All", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FeeSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file.";
                CreateBasicFileWithSpecifiedGAB();

                try
                {
                    Reports.TestStep = "Navigate to Fee Entry screen Select the fee above, click the Sales Tax Override button";
                    FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                    FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeName, 1, TableAction.On);
                    FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeName, 4, TableAction.SetText, "10.00" + FAKeys.Tab);
                    FastDriver.FileFees.SalesTaxOverride.FAClick();
                    Playback.Wait(5000);

                    Reports.TestStep = "Enter override amount, click Done";
                    FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeName, 5, TableAction.SetText, "0.01" + FAKeys.Tab);
                    FastDriver.BottomFrame.Done();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                }
                catch
                {
                    Reports.TestStep = "Navigate to Fee Entry screen Select the fee above, click the Sales Tax Override button";
                    FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                    FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeName, 1, TableAction.On);
                    FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeName, 4, TableAction.SetText, "10.00" + FAKeys.Tab);
                    FastDriver.FileFees.SalesTaxOverride.FAClick();
                    Playback.Wait(5000);

                    Reports.TestStep = "Enter override amount, click Done";
                    FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeName, 5, TableAction.SetText, "0.01" + FAKeys.Tab);
                    FastDriver.BottomFrame.Done();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                }

                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Sales Tax Override] event";
                FastDriver.EventTrackingLog.Open();
                int i = 0;

                for (i = 0; i <= 10; i++)
                {
                    if (FastDriver.EventTrackingLog.EventTable.StringExistOnTable("[Sales Tax Override]"))
                    {
                        Support.AreEqual("[Sales Tax Override]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Tax Override]", 1, TableAction.GetText).Message.Clean(), "Event");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Tax Override]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Tax Override]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                        Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Tax Override]", 4, TableAction.GetText).Message.Clean(), "Source");
                        Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Tax Override]", 5, TableAction.GetText).Message.Clean().Contains("Overridden Buyer Sales Tax").ToString(), "Comments");
                        Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Sales Tax Override]", 6, TableAction.GetText).Message.Clean(), "User");
                        break;
                    }
                    else
                    {
                        Playback.Wait(5000);
                        FastDriver.EventTrackingLog.Open();
                    }
                }

                if (i == 11)
                    FailTest("Event does not exist in event log");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0017
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0091_REG0017()
        {
            try
            {
                Reports.TestDescription = "FM13169: Log an Event for Remove Image; FM13171: Log an Event for Purge Image";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file.";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Document Repository screen, click Upload button";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentRepositoryTemplatesScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTab.FAClick();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse document.";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "TIF Image");
                Playback.Wait(20000); //wait for TIF upload to finish

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Select the image document, click Remove button";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous TIF Image", 4, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Select 'Removed Items' from Search Type, select deleted image, click Purge";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous TIF Image", 4, TableAction.Click);
                Playback.Wait(2000);
                int i = 0;

                for (i = 0; i <= 3; i++)
                {
                    if (FastDriver.DocumentRepository.Purge.IsEnabled())
                    {
                        FastDriver.DocumentRepository.Purge.FAClick();
                        break;
                    }
                    else
                    {
                        Playback.Wait(2000);
                        FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous TIF Image", 4, TableAction.Click);
                    }
                }

                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Removed Image] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();

                for (i = 0; i <= 10; i++)
                {
                    if (FastDriver.EventTrackingLog.EventTable.StringExistOnTable("[Removed Image]"))
                    {
                        Reports.TestStep = "Validate [Removed Image] event";
                        Support.AreEqual("[Removed Image]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Image]", 1, TableAction.GetText).Message.Clean(), "Event");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Image]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Image]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                        Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Image]", 4, TableAction.GetText).Message.Clean(), "Source");
                        Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Image]", 5, TableAction.GetText).Message.Clean().Contains("Image Name: Miscellaneous TIF Image").ToString(), "Comments");
                        Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Removed Image]", 6, TableAction.GetText).Message.Clean(), "User");

                        Reports.TestStep = "Validate [Purged Image] event";
                        Support.AreEqual("[Purged Image]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Image]", 1, TableAction.GetText).Message.Clean(), "Event");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Image]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Image]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                        Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Image]", 4, TableAction.GetText).Message.Clean(), "Source");
                        Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Image]", 5, TableAction.GetText).Message.Clean().Contains("Image Name: Miscellaneous TIF Image").ToString(), "Comments");
                        Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Purged Image]", 6, TableAction.GetText).Message.Clean(), "User");
                        break;
                    }
                    else
                    {
                        Thread.Sleep(5000);
                        FastDriver.EventTrackingLog.Open();
                    }
                }
                
                if (i == 11)
                    FailTest("Event does not exist on event log");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0018
        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC0091_REG0018()
        {
            try
            {
                Reports.TestDescription = "FM13384: Log an Event for Wire Disbursements; FM13385: Create Event Logs for all Wire Disbursements; FM13386: Sequence of Events for Wires < $20M when wire is Disbursed; FM13387: Log Event and display Pending status information";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file.";
                CreateBasicFileWithSpecifiedGAB();

                #region Deposit fund into account
                Reports.TestStep = "Make a deposit into the file.";
                #region Deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 20000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);
                #endregion

                #region Set an instance for Survey Details with charge amount entered
                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("Survey");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("20.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Upload and save document
                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                #endregion

                #region Convert to Wire.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Disburse the Wire and Validate that Edit button is disabled after Disburse.
                Reports.TestStep = "Select the wire and click on Wire button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();
                FastDriver.DisburseWires.SwitchToContentFrame();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Wire] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                Support.AreEqual("[Wire]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Wire]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Wire]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Wire]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Wire]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Wire]", 5, TableAction.GetText).Message.Clean().Contains("Status: Pending").ToString(), "Comments");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Wire]", 5, TableAction.GetText).Message.Clean().Contains("Status: Issued").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Wire]", 6, TableAction.GetText).Message.Clean(), "User");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0019
        [TestMethod]
        public void FMUC0091_REG0019()
        {
            try
            {
                Reports.TestDescription = "FM13888: Log Event for QC@Closing Data Sent to QC Engine";

                #region set QC @ Closing Client flag
                Reports.TestStep = "Login FAST ADM Site; check ePayoff is enabled for GAB";
                LoginFastADMSite();
                FastDriver.AddressBookSearch.Open();
                FastDriver.AddressBookSearch.SearchAddressBook("BOA");
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "BOA", 2, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.QCClosingClient.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();
                #endregion

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithLoanBuyerSeller();

                #region change GAB code, set transaction type on QC@Closing tab
                Reports.TestStep = "Navigate to New Loan screen, change GAB code";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("BOA");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Click QC@Closing tab, set Transaction Type";
                FastDriver.NewLoan.QCClosingTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.TransactionType);
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region perform delivery of HUD/CD statement
                if (AutoConfig.FormType == "HUD")
                {
                    FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Home>Order Entry>Escrow Closing>HUD-1 Statement").WaitForScreenToLoad();
                    FastDriver.HUD1PrintOptions.Method.FASelectItem("Imagedoc");
                    FastDriver.HUD1PrintOptions.Deliver.FAClick();
                    FastDriver.ImageDocDlg.WaitForScreenToLoad();
                    FastDriver.ImageDocDlg.ImageDoc.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);
                }
                else
                {
                    Reports.TestStep = "Navigate to Navigate to CD screen.";
                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                    FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();

                    Reports.TestStep = "Perform Imagedoc delivery.";
                    FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.DeliveryMethod);
                    FastDriver.ClosingDisclosure.Combined.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Imagedoc");
                    FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                    FastDriver.ImageDocDlg.WaitForScreenToLoad();
                    FastDriver.ImageDocDlg.ImageDoc.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);
                }
                #endregion

                #region validate event log
                Reports.TestStep = "Navigate to Event/Tracking Log, validate [QC @ Closing Data Sent to QC Engine] event";
                FastDriver.EventTrackingLog.Open();
                int i = 0;

                for (i = 0; i <= 15; i++)
                {
                    if (FastDriver.EventTrackingLog.EventTable.StringExistOnTable(@"Closing Data Sent to QC Engine"))
                    {
                        Support.AreEqual("[QC @ Closing Data Sent to QC Engine]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[QC @ Closing Data Sent to QC Engine]", 1, TableAction.GetText).Message.Clean(), "Event");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[QC @ Closing Data Sent to QC Engine]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                        Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[QC @ Closing Data Sent to QC Engine]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                        Support.AreEqual("FAST Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[QC @ Closing Data Sent to QC Engine]", 4, TableAction.GetText).Message.Clean(), "Source");
                        Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[QC @ Closing Data Sent to QC Engine]", 5, TableAction.GetText).Message.Clean().Contains("Status: Complete").ToString(), "Comments");
                        Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[QC @ Closing Data Sent to QC Engine]", 6, TableAction.GetText).Message.Clean(), "User");
                        break;
                    }
                    else
                    {
                        Playback.Wait(5000);
                        FastDriver.EventTrackingLog.Open();
                    }
                }

                if (i == 16)
                    FailTest("Event does not exist on event log");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0020
        [TestMethod]
        public void FMUC0091_REG0020()
        {
            try
            {
                Reports.TestDescription = "FM14757: Log Event for Overdraft";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file.";
                CreateBasicFileWithSpecifiedGAB();

                #region Set default printer
                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();
                #endregion

                #region Set an instance for Survey Details with charge amount entered
                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("Survey");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1000.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Wait for SDN search to complete";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(20);

                #region Print the check
                Reports.TestStep = "Print the checks";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "1,000.00", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                #endregion

                #region validate event log
                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Overdraft] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                Support.AreEqual("[Overdraft]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Overdraft]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Overdraft]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Overdraft]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Overdraft]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Overdraft]", 5, TableAction.GetText).Message.Clean().Contains("Reason For Loss:").ToString(), "Comments");
                Support.AreEqual(@"FASTTS\FASTQA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Overdraft]", 6, TableAction.GetText).Message.Clean(), "User");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0021
        [TestMethod]
        public void FMUC0091_REG0021()
        {
            try
            {
                Reports.TestDescription = "IF13525  Add Phrase Failure; IF13526  Update Phrase Failure; IF13527  Update Document Failure;IF13528  Finalize Document Failure";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file.";
                CreateBasicFileWithSpecifiedGAB();

                #region Add document to document repository
                Reports.TestStep = "Navigate to Document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();

                Reports.TestStep = "Click on Add Button.";
                FastDriver.DocumentRepository.Add.FAClick();

                Reports.TestStep = "Add the UK ENDOR T Endorsement Document to Document Repository screen.";
                FastDriver.AdHocDocuments.SearchDocument("Both", "Endorsement/Guarantee", "Uk ENDOR T", "");

                Reports.TestStep = "Validate the data entered in Adhoc Documents.";
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Endorsement/Guarantee", "Type", TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                Playback.Wait(1000);

                Reports.TestStep = "Get the fileID and documentID";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Endorsement/Guarantee", 6, TableAction.Click);
                FastDriver.DocumentRepository.Details.FAClick();
                FastDriver.DocumentDetailsScreen.WaitForScreenToLoad();
                int docID = int.Parse(FastDriver.DocumentDetailsScreen.DocID.FAGetText().Clean());
                int fileID = int.Parse(FastDriver.DocumentDetailsScreen.FileID.FAGetText().Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Delete the document";
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(6, "Endorsement/Guarantee", 6, TableAction.Click);
                FastDriver.DocumentRepository.Remove.FAClick();

                Reports.TestStep = "Finalize the document";
                FastDriver.DocumentRepository.FinalizeDocumentUsingWebService(fileID, docID);

                Reports.TestStep = "Add Phrase to Document";
                FileService.AddPhrase(RequestFactory.GetAddPhraseDefaultRequest(fileID, docID));

                Reports.TestStep = "Update Document";
                FileService.UpdateDocument(RequestFactory.GetUpdateDocumentDefaultRequest(fileID, docID));

                Reports.TestStep = "Creaet Image Document";
                FileService.CreateImageDocument(RequestFactory.GetCreateImageDocumentDefaultRequest(fileID, docID));
                #endregion

                #region validate event log
                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Document Finalized] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                Support.AreEqual("[Document Finalized]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Document Finalized]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Document Finalized]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Document Finalized]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAMOS Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Document Finalized]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("Finalize Document failed. Reason: Removed documents cannot be finalized. DocumentID: " + docID, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Document Finalized]", 5, TableAction.GetText).Message.Clean(), "Comments");
                Support.AreEqual(@"FAMOS", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Document Finalized]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate [Update Document] event";
                Support.AreEqual("[Update Document]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAMOS Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("Phrase addition failed. Reason: Phrase can’t be added to a Removed document. DocumentID: " + docID, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message.Clean(), "Comments");
                Support.AreEqual(@"FAMOS", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 6, TableAction.GetText).Message.Clean(), "User");

                Reports.TestStep = "Validate [ImageDoc] event";
                Support.AreEqual("[ImageDoc]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[ImageDoc]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[ImageDoc]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[ImageDoc]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAMOS Application", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[ImageDoc]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("Create Image Document failed. Reason: Removed documents cannot be imaged. DocumentID: " + docID, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[ImageDoc]", 5, TableAction.GetText).Message.Clean(), "Comments");
                Support.AreEqual(@"FAMOS", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[ImageDoc]", 6, TableAction.GetText).Message.Clean(), "User");
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0022
        [TestMethod]
        public void FMUC0091_REG0022()
        {
            try
            {
                Reports.TestDescription = "FM9403:  Notification via Email Successful ";

                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file.";
                CreateBasicFileWithSpecifiedGAB();

                #region Navigate to File Workflow screen, start a task.
                Reports.TestStep = "Navigate to File Workflow screen, complete a task.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileWorkflow.WaitForScreenToLoad(FastDriver.FileWorkflow.Process);
                string taskName = "ADEC-ITI-BILL-FULL";
                FastDriver.FileWorkflow.Process.PerformTableAction(5, taskName, 2, TableAction.On);
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region validate event log
                Reports.TestStep = "Navigate to Event/Tracking Log, validate [Notification via Email Successful] event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Notifications");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                Support.AreEqual("[Notification via Email Successful]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Notification via Email Successful]", 1, TableAction.GetText).Message.Clean(), "Event");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Notification via Email Successful]", 2, TableAction.GetText).Message.Clean().Substring(0, 10), "Start Date");
                Support.AreEqual(System.DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Notification via Email Successful]", 3, TableAction.GetText).Message.Clean().Substring(0, 10), "Completion Date");
                Support.AreEqual("FAST Automated Notification", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Notification via Email Successful]", 4, TableAction.GetText).Message.Clean(), "Source");
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Notification via Email Successful]", 5, TableAction.GetText).Message.Clean().Contains("Task: " + taskName).ToString(), "Comments");
                Support.AreEqual(@"FAST QA07", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Notification via Email Successful]", 6, TableAction.GetText).Message.Clean(), "User");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0023
        [TestMethod]
        public void FMUC0091_REG0023()
        {
            try
            {
                Reports.TestDescription = "US#659720_1: System shall display event for Lender info changes in CD screen";
                Dictionary<string, string> NewLenderInformationContactName = new Dictionary<string, string>();
                Reports.TestStep = "Login to ADM";
                LoginFastADMSite();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                NewLenderInformationContactName = CreateNewContactForBusOrg("247");
                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();
                Reports.TestStep = "Create a basic file with loan info.";
                CreateBasicFileWithLoanBuyerSeller("247");
                Reports.TestStep = "On New Lender screen, Get lender details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                Dictionary<string, string> LenderDetailsFromNewLoan = new Dictionary<string, string>();
                string LenderContact= NewLenderInformationContactName["LastName"]+", "+NewLenderInformationContactName["FirstName"];
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItem(LenderContact);
                LenderDetailsFromNewLoan=FastDriver.NewLoan.GetLenderDetails();
                Reports.TestStep = "Go to closing disclosure and update lender details";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LenderPlus.FAClick();
                FastDriver.ClosingDisclosure.SetLenderDetails();
                Dictionary<string, string> LenderDetailsFromClosingDisclosure = new Dictionary<string, string>();
                LenderDetailsFromClosingDisclosure= FastDriver.ClosingDisclosure.GetLenderDetails();
                FastDriver.ClosingDisclosure.LenderCDDone.FAClick();
                DateTime StartCompletionTime = DateTime.Now;
                #region validate event log
                Reports.TestStep = @"Navigate to Event/Tracking Log, validate lender data changes";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("CD Changes");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                string Event = "[Lender Information in Closing Disclosure Changed]";
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateSourceForEvent(Event, "FAST Application").ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateStartDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateCompletionDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateUserNameForEvent(Event, @"FASTTS\FASTQA07").ToString());
                string Comment = FastDriver.EventTrackingLog.GetCommentForEvent(Event);
                Reports.TestStep = "Validate Lender Data";
                ValidateLenderData(LenderDetailsFromNewLoan, LenderDetailsFromClosingDisclosure, Comment);
                Reports.TestStep = "Validate Contact First Name";
                Support.AreEqualTrim("True", Comment.Contains("Contact First Name changed from: <" + NewLenderInformationContactName["FirstName"] + "> To: <" + LenderDetailsFromClosingDisclosure["LenderContactFirstName"] + ">").ToString());
                Reports.TestStep = "Validate Contact Last Name";
                Support.AreEqualTrim("True", Comment.Contains("Contact Last Name changed from: <" + NewLenderInformationContactName["LastName"] + "> To: <" + LenderDetailsFromClosingDisclosure["LenderContactLastName"] + ">").ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region FMUC0091_REG0024
        [TestMethod]
        public void FMUC0091_REG0024()
        {
            try
            {
                Reports.TestDescription = "US#659720_2: System shall display refresh event for Lender info changes in CD screen";
                Reports.TestStep = "Login to ADM";
                LoginFastADMSite();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Dictionary<string, string> NewLenderInformationContactName = CreateNewContactForBusOrg("247");
                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();
                Reports.TestStep = "Create a basic file with loan info.";
                CreateBasicFileWithLoanBuyerSeller("247");
                Reports.TestStep = "On New Lender screen, Get lender details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                Dictionary<string, string> LenderDetailsFromNewLoan = new Dictionary<string, string>();
                string LenderContact= NewLenderInformationContactName["LastName"]+", "+NewLenderInformationContactName["FirstName"];
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItem(LenderContact);
                LenderDetailsFromNewLoan=FastDriver.NewLoan.GetLenderDetails();
                Reports.TestStep = "Go to closing disclosure and update lender details";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LenderPlus.FAClick();
                FastDriver.ClosingDisclosure.SetLenderDetails();
                //
                Dictionary<string, string> LenderDetailsFromClosingDisclosure1 = FastDriver.ClosingDisclosure.GetLenderDetails();
                FastDriver.ClosingDisclosure.LenderCDDone.FAClick();
                DateTime StartCompletionTime = DateTime.Now;
                #region validate event log
                Reports.TestStep = @"Navigate to Event/Tracking Log, validate lender data changes";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("CD Changes");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                string Event = "[Lender Information in Closing Disclosure Changed]";
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateSourceForEvent(Event, "FAST Application").ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateStartDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateCompletionDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateUserNameForEvent(Event, @"FASTTS\FASTQA07").ToString());               
                #endregion
                Reports.TestStep = "Go to closing disclosure and refresh lender details";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LenderPlus.FAClick();
                FastDriver.ClosingDisclosure.LenderRefresh.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...",false,20);
                StartCompletionTime = DateTime.Now;
                Dictionary<string, string> LenderDetailsFromClosingDisclosure2= FastDriver.ClosingDisclosure.GetLenderDetails();
                FastDriver.ClosingDisclosure.LenderCDDone.FAClick();
                Thread.Sleep(3000);
                Reports.TestStep = @"Navigate to Event/Tracking Log, validate that lender data is refreshed";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("CD Changes");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                Event = "[Lender Information in Closing Disclosure Refreshed]";
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateSourceForEvent(Event, "FAST Application").ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateStartDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateCompletionDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateUserNameForEvent(Event, @"FASTTS\FASTQA07").ToString());
                string Comment = FastDriver.EventTrackingLog.GetCommentForEvent(Event);
                ValidateLenderData(LenderDetailsFromClosingDisclosure1 , LenderDetailsFromClosingDisclosure2,Comment);
                Reports.TestStep = "Validate Contact First Name";
                Support.AreEqualTrim("True", Comment.Contains("Contact First Name changed from: <" + LenderDetailsFromClosingDisclosure1["LenderContactFirstName"] + "> To: <" + LenderDetailsFromClosingDisclosure2["LenderContactFirstName"] + ">").ToString());
                Reports.TestStep = "Validate Contact Last Name";
                Support.AreEqualTrim("True", Comment.Contains("Contact Last Name changed from: <" + LenderDetailsFromClosingDisclosure1["LenderContactLastName"] + "> To: <" + LenderDetailsFromClosingDisclosure2["LenderContactLastName"] + ">").ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            
        }     
        #endregion
        //
        #region FMUC0091_REG0025
        [TestMethod]
        public void FMUC0091_REG0025()
        {
            try
            {
                Reports.TestDescription = "US#659720_3: System shall display refresh event for Lender info changes in CD screen when first lender is deleted and  data is refreshed";
                Reports.TestStep = "Login to ADM";
                LoginFastADMSite();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                Dictionary<string, string> NewLenderInformationContactName = CreateNewContactForBusOrg("247");
                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();
                Reports.TestStep = "Create a basic file with loan info.";
                CreateBasicFileWithLoanBuyerSeller("247");
                Reports.TestStep = "On New Lender screen, Get lender details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemByIndex(2);
                Dictionary<string, string> LenderDetailsFromNewLoan = FastDriver.NewLoan.GetLenderDetails();
                Reports.TestStep = "Create second lender instance.";
                FastDriver.BottomFrame.New();
                NewLoanParameters NewLoanParams = new NewLoanParameters();
                NewLoanParams.GABCode = "HUDFLINSR1";
                NewLoanParams.Amount = "2000";
                NewLoanParams.Type = "Small Loan";
                FastDriver.NewLoan.FillNewLoanForm(NewLoanParams);
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Go to closing disclosure and update lender details";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LenderPlus.FAClick();
                FastDriver.ClosingDisclosure.SetLenderDetails();
                Dictionary<string, string> LenderDetailsFromClosingDisclosure = FastDriver.ClosingDisclosure.GetLenderDetails();
                FastDriver.ClosingDisclosure.LenderCDDone.FAClick();
                DateTime StartCompletionTime = DateTime.Now;
                #region validate event log
                Reports.TestStep = @"Navigate to Event/Tracking Log, validate lender data changes";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("CD Changes");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                string Event = "[Lender Information in Closing Disclosure Changed]";
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateSourceForEvent(Event, "FAST Application").ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateStartDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateCompletionDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateUserNameForEvent(Event, @"FASTTS\FASTQA07").ToString());
                string Comment = FastDriver.EventTrackingLog.GetCommentForEvent(Event);
                Reports.TestStep = "Validate Lender Data";
                ValidateLenderData(LenderDetailsFromNewLoan, LenderDetailsFromClosingDisclosure, Comment);
                #endregion
                Reports.TestStep = "Go to new loan and delete first lender";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#2", TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                //
                Reports.TestStep = "Go to closing disclosure and verify lender info";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LenderPlus.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                Dictionary<string, string> LenderDetailsFromClosingDisclosure2 = FastDriver.ClosingDisclosure.GetLenderDetails();
                FastDriver.ClosingDisclosure.LenderCDDone.FAClick();
                Support.AreEqualTrim("True", CompareDictionaries(LenderDetailsFromClosingDisclosure, LenderDetailsFromClosingDisclosure2).ToString());
                Thread.Sleep(3000);
                Reports.TestStep = "Refresh data and verify all fields are blank";
                //FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LenderPlus.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ClosingDisclosure.WaitForScreenToLoad(FastDriver.ClosingDisclosure.LenderRefresh);
                FastDriver.ClosingDisclosure.LenderRefresh.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ClosingDisclosure.WaitForScreenToLoad(FastDriver.ClosingDisclosure.LenderCDDone);
                FastDriver.ClosingDisclosure.LenderCDDone.FAClick();
                FastDriver.ClosingDisclosure.Open();
                Support.AreEqualTrim("False", FastDriver.ClosingDisclosure.LenderPlus.Exists().ToString());
                Reports.TestStep = @"Navigate to Event/Tracking Log, validate refresh event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("CD Changes");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                Event = "[Lender Information in Closing Disclosure Refreshed]";
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateSourceForEvent(Event, "FAST Application").ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateStartDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateCompletionDateForEvent(Event, StartCompletionTime).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateUserNameForEvent(Event, @"FASTTS\FASTQA07").ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion
        //
        #region FMUC0091_REG0026
        [TestMethod]
        public void FMUC0091_REG0026()
        {
            try
            {
                Reports.TestDescription = "US#659720_3_ Validate that new loan data is unchenged when lender details are changed on CD screen";
                Reports.TestStep = "Login FAST IIS Site";
                LoginFastFileSite();
                Reports.TestStep = "Create a basic file with loan info.";
                CreateBasicFileWithLoanBuyerSeller("247");
                Reports.TestStep = "On New Lender screen, Get lender details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemByIndex(1);
                Dictionary<string, string> LenderDetailsFromNewLoan1 = FastDriver.NewLoan.GetLenderDetails();
                Reports.TestStep = "Go to closing disclosure and update lender details";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LenderPlus.FAClick();
                FastDriver.ClosingDisclosure.SetLenderDetails();
                Dictionary<string, string> LenderDetailsFromClosingDisclosure = new Dictionary<string, string>();
                LenderDetailsFromClosingDisclosure = FastDriver.ClosingDisclosure.GetLenderDetails();
                FastDriver.ClosingDisclosure.LenderCDDone.FAClick();
                Thread.Sleep(3000);
                Reports.TestStep = "Go to new loan and Validate that lender data is not changed";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                Dictionary<string, string> LenderDetailsFromNewLoan2 = FastDriver.NewLoan.GetLenderDetails();
                Support.AreEqualTrim("True", CompareDictionaries(LenderDetailsFromNewLoan1, LenderDetailsFromNewLoan2).ToString());
                //

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }



        #endregion

        #region FMUC0091_REG0027: TC824169 Event Log Entry when UW Employee is changed in File UW Employee from a BLANK(No UW Employee Type)  to a NAME(UW Employee Type)
        [TestMethod]
        public void FMUC0091_REG0027()
        {
            int fileID = 0;
            string user1 = "QA07, FAST";
            string user2 = "QA06, FAST";
            try
            {
                Reports.TestDescription = "TC824169 Event Log Entry when UW Employee is changed in File UW Employee from a BLANK(No UW Employee Type)  to a NAME(UW Employee Type)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Check and setup on UW Employee type on ADM side
                Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa06";


                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa06");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA06]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                Reports.TestStep = @"Performing Empployee Search for Fastts\Fastqa07";
                FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.LoginName.FASendKeys(@"Fastts\Fastqa07");
                FastDriver.EmployeeSearch.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSearch.SearchNow.FAClick();

                FastDriver.EmployeeSearch.WaitForScreenToLoad();
                FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, @"[FASTTS\FASTQA07]", 1, TableAction.Click);

                Reports.TestStep = "Check if not Underwriter Type then set to UW";
                FastDriver.EmployeeSearch.Edit.Click();
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (!FastDriver.EmployeeSetup.EmployeeTypes.FAGetAllSelectedItems().Contains("Underwriter"))

                    FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Underwriter");

                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileID = (int)FileService.CreateFile(fileRequest).FileID;
                var File = FileService.GetOrderDetails(fileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Reports.TestStep = "Navigate to File Homepage screen and verify NO UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem(), "Verify NO UW Employee");

                Reports.TestStep = "Select an UW Employee";
                FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FASelectItem("QA07, FAST");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Homepage screen and verify UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem().Contains("QA07, FAST"), "Verify UW Employee");
                
                Reports.TestStep = "Navigate to Event/Tracking Log screen and verify changed in File UW Employee from a BLANK(No UW Employee Type)  to a NAME(UW Employee Type)";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[UW Employee Changed]"), "Event: [UW Employee Changed]");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("UW Employee Changed From: <blank> To: FAST QA07"), "Comments: UW Employee Changed From: <blank> To: FAST QA07");
                
                //TC824177 Event Log Entry when UW Employee is changed in File UW Employee from a NAME(UW Employee Type) to a NAME(UW Employee Type)
                Reports.TestStep = "TC824177 Event Log Entry when UW Employee is changed in File UW Employee from a NAME(UW Employee Type) to a NAME(UW Employee Type)";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem().Contains(user1), "Verify UW Employee is " + user1);

                Reports.TestStep = "Set UW Employee to user2: " + user2;
                FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FASelectItem(user2);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Homepage screen and verify NO UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem().Contains(user2), "Verify UW Employee is: " + user2);

                Reports.TestStep = "Navigate to Event/Tracking Log screen and verify changed in File UW Employee from a BLANK(No UW Employee Type)  to a NAME(UW Employee Type)";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[UW Employee Changed]"), "Event: [UW Employee Changed]");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("UW Employee Changed From: FAST QA07 To: FAST QA06"), "Comments: UW Employee Changed From: FAST QA07 To: FAST QA06");


                //TC824176 Event Log Entry when UW Employee is changed in File UW Employee from a NAME(UW Employee Type)  to a BLANK(No UW Employee Type)
                Reports.TestStep = "TC824176 Event Log Entry when UW Employee is changed in File UW Employee from a NAME(UW Employee Type)  to a BLANK(No UW Employee Type)";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem().Contains("QA06, FAST"), "Verify UW Employee");

                Reports.TestStep = "Set UW Employee to default";
                FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Homepage screen and verify NO UW Employee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.FileHomepage.TitleOwnOfficeUWEmployees.FAGetSelectedItem(), "Verify NO UW Employee");

                Reports.TestStep = "Navigate to Event/Tracking Log screen and verify changed in File UW Employee from a BLANK(No UW Employee Type)  to a NAME(UW Employee Type)";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"File Process");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[UW Employee Changed]"), "Event: [UW Employee Changed]");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("UW Employee Changed From: FAST QA06 To: <blank>"), "Comments: UW Employee Changed From: FAST QA07 To: <blank>");




            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        #endregion

       
        #endregion REG

        #region Place Holder Test Cases

        #region FMUC0091_REG0001_PH
        [TestMethod]
        public void FMUC0091_REG0001_PH()
        {
            try
            {
                Reports.TestDescription = "FM8765:  Successful Auto-amended Payoff Demand Update";
                Reports.TestStep = "Please test this use case manually, need update from payoff demand interface";
                Reports.StatusUpdate("", true, "", "", "", null);
                Reports.TestStep = "A 'Ebus Payoff Autoamended Event From Lender' Event Log entry will be created when a Lender successfully delivers an updated (lender-initiated) payoff statement to the FAST file";
                Reports.StatusUpdate("", true, "", "", "", null);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0002_PH
        [TestMethod]
        public void FMUC0091_REG0002_PH()
        {
            try
            {
                Reports.TestDescription = "FM8764: Failed Auto-amended Payoff Demand Update";

                Reports.TestStep = "Please test this use case manually, need update from payoff demand interface";
                Reports.StatusUpdate("", true, "", "", "", null);
                Reports.TestStep = "A 'Ebus Payoff Autoamended Event Failed' Event Log entry will be created when a Lender attempts to deliver an updated (lender-initiated) payoff statement to the FAST file and the File and/or Loan 'Restrict Auto Updates' option is selected";
                Reports.StatusUpdate("", true, "", "", "", null);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0091_REG0003_PH
        [TestMethod]
        public void FMUC0091_REG0003_PH()
        {
            try
            {
                Reports.TestDescription = "FM10009, FM10010, FM10011: Paid Check Status from Trust32";
                Reports.TestStep = "Please test this use case manually, need update from Trust32 interface";
                Reports.StatusUpdate("", true, "", "", "", null);
                Reports.TestStep = "FM10010  Disbursement Status Update from Trust32";
                Reports.StatusUpdate("", true, "", "", "", null);
                Reports.TestStep = "FM10011  Deposit Status Update from Trust32";
                Reports.StatusUpdate("", true, "", "", "", null);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion REG

        #region FMUC0091_REG0004_PH
        [TestMethod]
        public void FMUC0091_REG0004_PH()
        {
            try
            {
                Reports.TestDescription = "FM11699:  Log event when process addition using 'Add Process' unsuccessful";

                Reports.TestStep = "Please test this use case manually, don't know how to generate a failed event";
                Reports.StatusUpdate("", true, "", "", "", null);
                Reports.TestStep = "Log an event when process not added successfully using  the 'Add Process' feature on File Workflow";
                Reports.StatusUpdate("", true, "", "", "", null);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion REG

        #region FMUC0091_REG0005_PH
        [TestMethod]
        public void FMUC0091_REG0005_PH()
        {
            try
            {
                Reports.TestDescription = "FM11875  Log an Event for Signing Order Cancellation Request to FASSNotary";

                Reports.TestStep = "Please test this use case manually, need to interact with FASSNotary interface";
                Reports.StatusUpdate("", true, "", "", "", null);
                Reports.TestStep = "The system shall generate a Signing event in the file Event Log when a user requests to cancel a signing order by clicking the Cancel Signing button in the Signature Signing screen";
                Reports.StatusUpdate("", true, "", "", "", null);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion REG

        #region FMUC0091_REG0006_PH
        [TestMethod]
        public void FMUC0091_REG0006_PH()
        {
            try
            {
                Reports.TestDescription = "FM12659: Log an Event for Initiating eTitle Policy Delivery; FM12660: Log an Event for Successful eTitle Delivery";
                Reports.TestStep = "Please test this use case manually, QA Automation Office is not a eTitle BU, need to be on NCSD region/office";
                Reports.StatusUpdate("", true, "", "", "", null);
                Reports.TestStep = "The system shall log an event when an eTitle qualified document is initiated to be sent to the Lender electronically";
                Reports.StatusUpdate("", true, "", "", "", null);
                Reports.TestStep = "The system shall log an event when an eTitle enabled document is transmitted to the FTP Server or Fax Server, using the eTitle Delivery process";
                Reports.StatusUpdate("", true, "", "", "", null);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion Place Holder Test Cases

        #region Private Methods

        private void LoginFastFileSite(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void LoginFastADMSite(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);
        }
        //
        private Dictionary<string, string> CreateNewContactForBusOrg(string GAB)
        {
            Dictionary<string, string> ContactName = new Dictionary<string, string>();

            try
            {
                //Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";

                FastDriver.AddressBookSearch.EditGAB(GAB);
                //
                Reports.TestStep = "Go to business party contact for the Bus Org.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                Thread.Sleep(2000);
                Reports.TestStep = "To click on New button in Business Party Contacts List.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.New.FAClick();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                ContactName = FastDriver.BusPartyContactSetup.CreateNewContactForBusOrg();
                return ContactName;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                return ContactName;
            }

        }
        private void CreateBasicFileWithSpecifiedGAB(string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        private void CreateBasicFileForDataTree()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1");
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            Zip = "92707",
                            City = "Santa Ana", 
                            County = "Orange", 
                            Country = "USA",
                            AddrLine1 = "45 bluejay",
                            AddrLine2 = "",
                            AddrLine3 = ""
                        } 
                    },
                } 
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        private void CreateBasicFileWithLoanBuyerSeller(string LenderGAB="247")
        {
            var customizableFileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            Zip = "92707",
                            City = "Santa Ana", 
                            County = "Orange", 
                            Country = "USA",
                            AddrLine1 = "45 bluejay",
                            AddrLine2 = "",
                            AddrLine3 = ""
                        } 
                    },
                } 
            };
            customizableFileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
            {
                LoanNumber = "LOAN1234567890",
                NewLoanAmount = 5000.00m,
                LiabilityAmount = 5000.00m,
                BenMortgageeTextID = 0,
                FileBusinessParty = new FileBusinessParty
                {
                    Name = "Fast Tester",
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(LenderGAB),
                },
                LoanTypeCdID = 0,
                FundDate = DateTime.Today
            };
            customizableFileRequest.File.Sellers[0].SSN = "111-11-1111";
            customizableFileRequest.File.Sellers[0].LastName1099S = "1099S";
            customizableFileRequest.File.SalesPriceAmount = (decimal)200000;
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        private void CreateBasicFileWithLoanBuyerSellerForCPL()
        {
            var customizableFileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "OH",  
                            Zip = "92707",
                            City = "Adams", 
                            County = "Adams", 
                            Country = "USA",
                            AddrLine1 = "45 Test",
                            AddrLine2 = "",
                            AddrLine3 = ""
                        } 
                    },
                } 
            };
            customizableFileRequest.File.Sellers[0].SSN = "111-11-1111";
            customizableFileRequest.File.Sellers[0].LastName1099S = "1099S";
            customizableFileRequest.File.SalesPriceAmount = (decimal)200000;
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }
        private void CreateBasicFileFromFASTGUI()
        {
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.CreateStandardFile();
        }

        private void CreateProjectFile()
        {
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
            FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Commercial");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Refinance");
            FastDriver.QuickFileEntry.ProjectFile.FASetCheckbox(true);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
            
            Playback.Wait(1000);
            Keyboard.SendKeys("^{D}");
        }

        private void CreatePayoffDemandFile()
        {
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("1254");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.BusinessSourceReference.FASetText("1111111111");
            FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Payoff Lender");
            FastDriver.QuickFileEntry.Title.FASetCheckbox(false);
            FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Refinance");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("FirstName");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("FirstName");

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("2 First Amercan Way");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");

            Playback.Wait(1000);
            Keyboard.SendKeys("^{S}");
        }
        //
        private void ValidateLenderData(Dictionary<string, string> LenderDetailsChangedFrom, Dictionary<string, string> LenderDetailsChangedTo, string Comment)
        {
            Reports.TestStep = "Validate Lender Name";
            Support.AreEqualTrim("True", Comment.Contains("Lender Name changed from: <" + LenderDetailsChangedFrom["LenderName"] + "> To: <" + LenderDetailsChangedTo["LenderName"] + ">").ToString());
            Reports.TestStep = "Validate Lender Address Line1";
            Support.AreEqualTrim("True", Comment.Contains("Lender Address Line1 changed from: <" + LenderDetailsChangedFrom["LenderAddressLine1"] + "> To: <" + LenderDetailsChangedTo["LenderAddressLine1"] + ">").ToString());
            Reports.TestStep = "Validate Lender Address Line2";
            Support.AreEqualTrim("True", Comment.Contains("Lender Address Line2 changed from: <" + LenderDetailsChangedFrom["LenderAddressLine2"] + "> To: <" + LenderDetailsChangedTo["LenderAddressLine2"] + ">").ToString());
            Reports.TestStep = "Validate Lender Address Line3";
            Support.AreEqualTrim("True", Comment.Contains("Lender Address Line3 changed from: <" + LenderDetailsChangedFrom["LenderAddressLine3"] + "> To: <" + LenderDetailsChangedTo["LenderAddressLine3"] + ">").ToString());
            Reports.TestStep = "Validate Lender Address Line4";
            Support.AreEqualTrim("True", Comment.Contains("Lender Address Line4 changed from: <" + LenderDetailsChangedFrom["LenderAddressLine4"] + "> To: <" + LenderDetailsChangedTo["LenderAddressLine4"] + ">").ToString());
            Reports.TestStep = "Validate Lender State";
            Support.AreEqualTrim("True", Comment.Contains("State changed from: <" + LenderDetailsChangedFrom["LenderState"] + "> To: <" + LenderDetailsChangedTo["LenderState"] + ">").ToString());
            Reports.TestStep = "Validate Lender City";
            Support.AreEqualTrim("True", Comment.Contains("City changed from: <" + LenderDetailsChangedFrom["LenderCity"] + "> To: <" + LenderDetailsChangedTo["LenderCity"] + ">").ToString());
            Reports.TestStep = "Validate Lender Zip";
            Support.AreEqualTrim("True", Comment.Contains("Zip changed from: <" + LenderDetailsChangedFrom["LenderZip"] + "> To: <" + LenderDetailsChangedTo["LenderZip"] + ">").ToString());
            Reports.TestStep = "Validate Lender NMLS ID";
            Support.AreEqualTrim("True", Comment.Contains("NMLS ID changed from: <" + LenderDetailsChangedFrom["LenderNMLSID"] + "> To: <" + LenderDetailsChangedTo["LenderNMLSID"] + ">").ToString());
            Reports.TestStep = "Validate Contact ST License ID";
            Support.AreEqualTrim("True", Comment.Contains("State License ID changed from: <" + LenderDetailsChangedFrom["LenderStateLicenseID"] + "> To: <" + LenderDetailsChangedTo["LenderStateLicenseID"] + ">").ToString());
            Reports.TestStep = "Validate Contact NMLS ID";
            Support.AreEqualTrim("True", Comment.Contains("Contact NMLS ID changed from: <" + LenderDetailsChangedFrom["LenderContactNMLSID"] + "> To: <" + LenderDetailsChangedTo["LenderContactNMLSID"] + ">").ToString());
            Reports.TestStep = "Validate Contact Email";
            Support.AreEqualTrim("True", Comment.Contains("Email changed from: <" + LenderDetailsChangedFrom["LenderEmail"] + "> To: <" + LenderDetailsChangedTo["LenderEmail"] + ">").ToString());
            Reports.TestStep = "Validate Phone";
            Support.AreEqualTrim("True", Comment.Contains("Phone changed from: <" + LenderDetailsChangedFrom["LenderBusinessPhone"] + "> To: <" + LenderDetailsChangedTo["LenderBusinessPhone"] + ">").ToString());
            Reports.TestStep = "Validate Phone extension";
            Support.AreEqualTrim("True", Comment.Contains("Ext changed from: <" + LenderDetailsChangedFrom["LenderBusinessPhoneExtension"] + "> To: <" + LenderDetailsChangedTo["LenderBusinessPhoneExtension"] + ">").ToString());
        }
        //
        private bool CompareDictionaries(Dictionary<string, string> Dictionary1, Dictionary<string, string> Dictionary2)
        {
            bool Result = false;
            try
            {
                int count = 0;

                foreach (var DictionaryItem in Dictionary1)
                {
                    string Value = DictionaryItem.Value;
                    bool isEqual = Dictionary2.TryGetValue(DictionaryItem.Key, out Value);
                    if (isEqual)
                    {
                        count++;
                    }
                    else
                        Reports.StatusUpdate("Values for Key " + DictionaryItem.Key + " are not matching", false);
                }
                if (count == Dictionary1.Count)
                    Result = true;
                else
                    Result = false;

                return Result;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                return Result;
            }
        }
        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

