﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using System.Linq;
using System.Collections.Generic;
using OpenQA.Selenium.Interactions;
using System.Windows.Forms;
using OpenQA.Selenium.Support.UI;
using System.Threading;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0012 : MasterTestClass
    {
        static int waitTime = Convert.ToInt32(AutoConfig.WaitTime);

        [TestMethod]
        public void FMUC0012_BAT0001()
        {
            try
            {
                Reports.TestDescription = "AF2: Verify if 'No match found' message appears upon searching for an invalid file number.";

                /*Reports.TestStep = "Create Order";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                var FileNum1 = File.FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);*/

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                var fileNumber = "1122334455";
                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                Reports.TestStep = "Verify the default state of the fields.";
                FastDriver.FileSearch.VerifyTheStateOfFields();

                Reports.TestStep = "Enter the file number.";
                FastDriver.FileSearch.SetFileNumber(fileNumber: fileNumber, IsNonExistingFile: true);

                Reports.TestStep = "Click the Find Now button.";
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Verify that No match found alert appears upon searching for a non-existing file.";
                FastDriver.FileSearch.VerifyIfNoMatchFoundMessageAppears();

                //FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("SMSSpellChecker", false, 5);
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_FM2023: Perform exact match and verify if the approppriate file is opened.";


                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                Reports.TestStep = "Perform a valid file search and verify if the same file is opened.";
                FastDriver.FileSearch.PerformExactSearchAndVerifyIfTheFileIsOpened(fileNumber);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_BAT0003()
        {
            try
            {
                Reports.TestDescription = "Test the New Search functionality. Check if all the fields are reset upon clicking the New Search button.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                //Reports.TestStep = "Create Order";
                //var fileNumber = this.CreateFile();
                Reports.TestStep = "Enter details.";
                FastDriver.FileSearch.SetValues();

                Reports.TestStep = "Click the Find Now button.";
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Verify that No match found alert appears.";
                FastDriver.FileSearch.VerifyIfNoMatchFoundMessageAppears();

                FastDriver.FileSearch.WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Verify if the FindNow button is still enabled.";
                Support.AreEqual("True", FastDriver.FileSearch.FindNow.Enabled.ToString());

                Reports.TestStep = "Click the New Search button.";
                FastDriver.FileSearch.NewSearch.FAClick();
                //FastDriver.FileSearch.WaitForEnabled();

                Reports.TestStep = "Verify that all the fields are reset to the default values.";
                FastDriver.FileSearch.VerifyTheStateOfFields();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_BAT0004()
        {
            try
            {
                Reports.TestDescription = "82930 : Perform wild card search. Check the count of the total number of files listed is at least 2 ";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true);
                //MessageBox.Show("1");

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                //Reports.TestStep = "Create Order";
                //var fileNumber = this.CreateFile();
                Reports.TestStep = "Enter file number with wild card character.";
                FastDriver.FileSearch.SetFileNumber(AddWildcard(fileNumber));

                Reports.TestStep = "Click the Find Now button.";
                FastDriver.FileSearch.FindNow.FAClick();


                Reports.TestStep = "Handle 'More than 100 Records found' message, if more than 100 Records are found.";
                FastDriver.FileSearch.HandleMoreThan100RecordsFoundAlert(120);

                Reports.TestStep = "Check the count of the total number of files listed is at least 2.";
                FastDriver.FileNumberSearchSelectionDlg.CheckTheFileCountIsNotBelowTheSpecifiedValue(refFileCount: 2);

                Reports.TestStep = "Check if the specified file is listed in the dialog.Then, open the file listed next to this file.";
                int currentRow = FastDriver.FileNumberSearchSelectionDlg.SelectTheSpecifiedFileInTheDialog(fileNumber);
                FastDriver.FileNumberSearchSelectionDlg.OpenNextFileFromTheRow(currentRow);

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();


                Reports.TestStep = "Enter multiple search criteria";
                Support.DataLoad("RandomBuyerName");
                var buyerName = Support.data;
                FastDriver.FileSearch.Principals.FASetText(buyerName);
                FastDriver.FileSearch.State.FASelectItem("AR");
                FastDriver.FileSearch.OpenDate.FAClick();
                FastDriver.FileSearch.DateFrom1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());
                FastDriver.FileSearch.DateTo1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());

                //MessageBox.Show("1");

                Reports.TestStep = "Search for the file.";
                if (!FastDriver.FileSearch.RetryFileSearch())
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }

                Reports.TestStep = "Verify if the appropriate file is opened.";
                Support.AreEqual(fileNumber, FastDriver.FileHomepage.GetFileNumber());


            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF6 : File Number Search in MRU - Check if 'No match found' alert appears.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Search for a non-existent file and check if the appropriate alert is displayed.";
                var fileNumber = "1122334455";
                FastDriver.TopFrame.SearchForNonExistentFileAndVerifyTheAlert(fileNumber);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF4 : File Number Search in MRU - Exact macth.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create first file with default values.";
                var fileNumber1 = CreateFile();

                Reports.TestStep = "Create second file with default values.This file is needed to be created to test if an appropriate file is opened upon searching for the same.";
                var fileNumber2 = CreateFile();

                System.Threading.Thread.Sleep(5000);// to avoid the occurrence of getting the 'No match found' alert.

                Reports.TestStep = "Set the first file just created in the MRU and press the 'Enter' key.";
                FastDriver.TopFrame.SetNumberAndPressEnter(fileNumber1);

                Reports.TestStep = "Navigate to File Home Page.";
                var fileNo = FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").GetFileNumber();

                Reports.TestStep = "Verify if the appropriate file is opened.";
                Support.AreEqual(fileNumber1, fileNo);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF4 : Wild card search in MRU.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create first file with default values.";
                var fileNumber1 = CreateFile();

                Reports.TestStep = "Create second file with default values.";
                var fileNumber2 = CreateFile();


                System.Threading.Thread.Sleep(12000);// to avoid the delay in getting the file listed.

                Reports.TestStep = "Enter the few digitis of the file number with wild card and search.";
                FastDriver.TopFrame.SetNumberAndPressEnter(AddWildcard(fileNumber1));

                Reports.TestStep = "File Number Search Dialog should open. Handle 'More than 100 Records found' message, if appears.";
                FastDriver.FileSearch.HandleMoreThan100RecordsFoundAlert();

                Reports.TestStep = "Check the count of the total number of files listed is at least 2.";
                FastDriver.FileNumberSearchSelectionDlg.CheckTheFileCountIsNotBelowTheSpecifiedValue(refFileCount: 2, timeOutValue: 60);


                Reports.TestStep = "Check if the first file just created is listed in the File Number Search dialog. Then, open the same.";
                int returnVal = FastDriver.FileNumberSearchSelectionDlg.SelectTheSpecifiedFileInTheDialog(fileNumber1, true);
                Reports.StatusUpdate("Has the file been tried to open by double clicking the File No. cell in the dialog ?", returnVal == -1);

                // Reports.TestStep = "Click Done.";
                //FastDriver.DialogBottomFrame.ClickDone();

                //Reports.TestStep = "Check if the appropriate file is opened.";
                //Support.AreEqual(fileNumber1, FastDriver.FileHomepage.GetFileNumber());

                Reports.TestStep = "Navigate to File Home Page.";
                var fileNo = FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").GetFileNumber();

                Reports.TestStep = "Verify if the appropriate file is opened.";
                Support.AreEqual(fileNumber1, fileNo);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0001()
        {
            try
            {
                Reports.TestDescription = "[DUPLICATED]";
                //Reports.TestDescription = "82930 : Wild card search on File Search Page - Count the number of files listed is above 1.";
                Reports.StatusUpdate("This scenario is already covered in BAT0004", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0012_REG0002()
        {
            try
            {
                Reports.TestDescription = "AF4_FM827_FM2019 : File Number Search in MRU - wild card search.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with different values for GAB Code and State.";
                var fileNumber = CreateFile(true, "247");

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Enter search criterion in the month field and perform the search.";
                FastDriver.FileSearch.Month.FASetText("1");
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, Convert.ToInt32(AutoConfig.WaitTime));
                FastDriver.FileSearch.VerifyMoreThan100RecordsFoundNote();
                FastDriver.FileSearch.VerifyIfTheFileCreationDateIsWithinTheMonthCriterion(1);

                //if (FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.GetText).Message.Equals(fileNumber))
                //{
                //  FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click); 
                //the above line is commented because it takes sometimes longer duration to get the newly created file number appear in the result list. This causes an invalid failure/false negatives.
                //}
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);

                Reports.TestStep = "Click New Search to perform a fresh search.";
                FastDriver.FileSearch.NewSearch.FAClick();

                Reports.TestStep = "Enter search criterion with wild card in the Principals field.";
                FastDriver.FileSearch.Buyer.FAClick();
                FastDriver.FileSearch.Principals.FASetText("Buyer*");

                Reports.TestStep = "Enter search criterion in Other Parties sectin and perform the search.";
                FastDriver.FileSearch.OtherParties.FASetText("Lenders Advantage");
                FastDriver.FileSearch.RoleType.FASelectItem("Other Real Estate Agent");
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.SwitchToContentFrame();
                //FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                Reports.TestStep = "Search for the file.";
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTable))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }

                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, Convert.ToInt32(AutoConfig.WaitTime));
                //FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click); //this line is commented because it takes sometimes longer duration to get the newly created file number appear in the result list.
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0003()
        {
            try
            {
                Reports.TestDescription = "AF4 : File Number Search in MRU - wild card search.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with different GAB ID.";
                var fileNumber = CreateFile(true, "247");

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();

                List<string> userItems = LoadTheList();

                Reports.TestStep = "Enter search criterion in the month field and perform the search.";
                FastDriver.FileSearch.VerifyAllItemsInRoleTypeDropdown(userItems);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0004()
        {
            try
            {
                Reports.TestDescription = "AF4 : File Number Search in MRU - wild card search.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the first file with default values.";
                var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                Reports.TestStep = "Enter search criterion in the month field and perform the search.";
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.SwitchToContentFrame();
                //FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, Convert.ToInt32(AutoConfig.WaitTime));
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTable))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);

                Reports.TestStep = "Click New Search to perform a fresh search.";
                FastDriver.FileSearch.NewSearch.FAClick();

                Reports.TestStep = "Enter search criterion with wild card in the Principals field.";
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.State);
                FastDriver.FileSearch.State.FASelectItem("CA");
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.FindNow);
                //FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, Convert.ToInt32(AutoConfig.WaitTime));
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTable))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);

                Reports.TestStep = "Click New Search to perform a fresh search.";
                FastDriver.FileSearch.NewSearch.FAClick();

                Reports.TestStep = "Search by Property Parcel and Lot criteria.";
                FastDriver.FileSearch.PropertyLot.FASetText("1");
                FastDriver.FileSearch.PropertyParcel.FASetText("2");
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Verify that No match found alert appears upon searching for a non-existing file.";
                FastDriver.FileSearch.VerifyIfNoMatchFoundMessageAppears();


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void FMUC0012_REG0005()
        {
            try
            {
                //AutoConfig.SelectedRegionName
                Reports.TestDescription = "AF4 : File Number Search by Region and testing the state of the fields on the page.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the first file with default values.";
                var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                Reports.TestStep = "Select the Region that the file has just been created in and perform the search.";
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                Playback.Wait(4000);
                //FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if the Search Results table lists the file number just created.";
                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, waitTime);
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTable))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);


                Reports.TestStep = "Click New Search to perform a fresh search.";
                FastDriver.FileSearch.NewSearch.FAClick();

                Reports.TestStep = "Select 'All Region' in the Region field.";
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                try
                {
                    //FastDriver.FileSearch.Region.FASelectItem("All Regions");
                    FastDriver.FileSearch.Region.FASelectItemBySendingKeys("all regions");
                    Playback.Wait(4000);

                }
                catch (Exception)
                {

                    //Playback.Wait(4000);
                }

                //Playback.Wait(7000);
                WaitForAppropriateElementsState();


                Reports.TestStep = "Verify the state of the fields on the File Search page.";
                Support.AreEqual("False", FastDriver.FileSearch.Principals.IsReadOnly().ToString());

                Support.AreEqual("False", FastDriver.FileSearch.Principals.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.Buyer.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.Seller.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.Debtor.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.AnyPrincipals1.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.IndividualHusband.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.TrustEstate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.BussinessEntity.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.AnyPrincipals2.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.OtherParties.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.RoleType.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.PropertyAddress.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.PropertyName.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.PropertyLot.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.PropertyParcel.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.PropertyTract.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.PropertySubDiv.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.APNTaxNo.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.State.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.County.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.Country.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.Numbers.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.FileNo.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.ExtNo.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.InvoiceNo.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.OutsideRef.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.PolicyNumber.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.PrincipalsReg.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.EntityRef.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.BussinessSource.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.AnyNumbers.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.Open.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.OpeninError.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.Cancelled.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.Closed.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.AnyStatus.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.DateFrom1.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.DateTo1.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.Month.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.OpenDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.CancelledDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.SettlementDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.EstSettlementDate.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.EmployeeName.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.FileSearch.EmployeeType.IsEnabled().ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM4989_FM4386_FM4990_FM4991_FM4992: Invoice Number search - exact match and wild card search.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the first file with default values.";
                var fileNumber = CreateFile();

                Reports.TestStep = "Generate Invoice No. for the file.";
                string invoiceNo = GenerateInvoiceNo();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad(); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                Reports.TestStep = "Perform an exact search based on Invoice No.";
                FastDriver.FileSearch.PerformExactSearchOfInvoiceNoAndVerifyTheFileIsOpened(invoiceNo);

                Reports.TestStep = "Perform Invoice No. based wildcard search.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.InvoiceNo.FAClick();
                FastDriver.FileSearch.SetFileNumber(AddWildcard(invoiceNo, substrLength: 2));
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.FindNow);
                //FastDriver.FileSearch.FindNow.Click();
                //FastDriver.FileSearch.RetryFileSearch();

                Reports.TestStep = "Check that the Search Results table lists the file number just created with the Invoice No.";
                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, waitTime);
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTable))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM2022_FM774_FM805_FM2024: Dates Section :- Search based on 'From' Date Only, then both 'From' Date and 'To' Date, and then based on # of months.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the first file with default values.";
                var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                string fromDate = DateTime.Now.AddDays(-5).ToDateString();
                string toDate = DateTime.Now.ToDateString();

                Reports.TestStep = "Enter only From Date value.";
                FastDriver.FileSearch.DateFrom1.FASetText(fromDate);
                FastDriver.FileSearch.FindNow.Click();


                Reports.TestStep = "Check if the search fetches results.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, Convert.ToInt32(AutoConfig.WaitTime));
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);

                Reports.TestStep = "Check the Opened Date of the last file number in the list within the date range critera.";
                int lastRow = FastDriver.FileSearch.SearchResultTable.GetRowCount();
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(lastRow, 1, TableAction.Click);
                FastDriver.FileSearch.View.FAClick();
                FastDriver.FileSummaryDlg.CheckTheOpenedDateInFileSummaryDialog(fromDate);

                Reports.TestStep = "Enter 'From Date' and 'To Date' values.";
                FastDriver.FileSearch.NewSearch.FAClick();
                FastDriver.FileSearch.WaitForScreenToLoad();
                FastDriver.FileSearch.DateFrom1.FASetText(fromDate);
                FastDriver.FileSearch.DateTo1.FASetText(toDate);
                //FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Check if the search fetches results including the file number just created.";
                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, waitTime);
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTable))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);

                Reports.TestStep = "Search for the files created within the last one month.";
                FastDriver.FileSearch.NewSearch.FAClick();
                FastDriver.FileSearch.Month.FASetText("1");
                //FastDriver.FileSearch.FindNow.FAClick();
                //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, waitTime);
                if (!FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTable))
                {
                    Reports.StatusUpdate("File wasn't located !", false);
                }
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);

                //string actualDate = FastDriver.FileSearch.SearchResultTable.PerformTableAction(2, 6, TableAction.GetText).Message;
                //Reports.StatusUpdate("Check that the Creation Date falls within the From and To Date ranges entered", (Convert.ToDateTime(fromDate) >= Convert.ToDateTime(FastDriver.FileSummaryDlg.OpenedDate.FAGetText()));
                //lastRow = FastDriver.FileSearch.SearchResultTable.GetRowCount();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void FMUC0012_REG0008()
        {
            // bool IsMatchFound = false;
            // int retryCount = 1;
            try
            {
                Reports.TestDescription = "FM2025_FM4999: No Status or Date, File Status.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the first file with default values.";
                var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to TDS screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem());

                Reports.TestStep = "Update the file status to Open In Error.";
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open In Error");
                Reports.TestStep = "Update the current Status Date with server date.";
                FastDriver.TermsDatesStatus.UpdateStatusDateWithServerDate();
                FastDriver.BottomFrame.Done();

                Playback.Wait(20000);

                Reports.TestStep = "Navigate to File Search screen.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Enter the part of the file number just created, with wildcard.";
                SearchForFile(fileNumber: fileNumber, fileStatus: "Opened in Error");


                Reports.TestStep = "Navigate to TDS screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Update the file status to Closed.";
                FastDriver.TermsDatesStatus.Status.FASelectItem("Closed");
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to File Search screen.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);


                Reports.TestStep = "Enter the file number created in this test.";
                //FastDriver.FileSearch.Numbers.FASetText(AddWildcard(fileNumber, 4));
                SearchForFile(fileNumber: fileNumber, fileStatus: "Closed");

                Reports.TestStep = "Navigate to TDS screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Update the file status to Cancelled.";
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to File Search screen.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Enter the file number created in this test.";
                //FastDriver.FileSearch.Numbers.FASetText(AddWildcard(fileNumber, 4));
                SearchForFile(fileNumber: fileNumber, fileStatus: "Cancelled");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void FMUC0012_REG0009()
        {
            bool retrySearchResult = false;
            try
            {
                Reports.TestDescription = "FM4457_FM5006_FM4456: Search files by Employee Name and Type and view the results.";

                var userID = AutoConfig.UserName;
                string reversedUserID = GetParsedUserIDWithSpace(userID: userID, IsToBeReversed: true);


                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with Title/Escrow Officer details.";
                var fileNumber = CreateFileWithEmployeeDetails(); // create a file with employee details.

                Reports.TestStep = "Navigate to File Search screen.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Search by buyer name and user ID(without domain name).";
                FastDriver.FileSearch.Principals.FASetText("BuyerName");
                FastDriver.FileSearch.Buyer.FAClick();
                FastDriver.FileSearch.EmployeeName.FASetText(reversedUserID);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                if (FastDriver.FileSearch.RetryFileSearch("", FastDriver.FileSearch.SearchResultTable))
                {
                    retrySearchResult = true;
                    Reports.TestStep = "Check the resultant files contains the buyer name used for the search.";
                    Reports.StatusUpdate("Is Buyer Name found ?", FastDriver.FileSearch.SearchResultTable.PerformTableAction(2, 2, TableAction.GetText).Message.Contains("BuyerName"));
                }
                if (!retrySearchResult)
                {
                    Reports.StatusUpdate("Could not locate file after multiple retries !", false);
                }
                Reports.TestStep = "Click New Search button.";
                FastDriver.FileSearch.NewSearch.FAClick();

                Reports.TestStep = "Search by employee details.";
                FastDriver.FileSearch.EmployeeName.FASetText(reversedUserID);
                FastDriver.FileSearch.EmployeeType.FASelectItem("Title Officer");
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                if (FastDriver.FileSearch.RetryFileSearch(fileNumber, FastDriver.FileSearch.SearchResultTable))
                {
                    retrySearchResult = true;
                    Reports.TestStep = "Check the result includes the file created in this test.";
                    Reports.StatusUpdate("Is the file number created in this test found ?", true);
                }
                if (!retrySearchResult)
                {
                    Reports.StatusUpdate("Could not locate file after multiple retries !", false);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0010()
        {
            try
            {
                Reports.TestDescription = "[DUPLICATED]";
                //Reports.TestDescription = "[DUPLICATED] FM827_FM2019_FM2020_FM2023  : File Search Results, Tool Tips for Result Section, Search Processing Region, Exact Match.";
                Reports.StatusUpdate("This scenario is already covered in BAT0002 and REG0002", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0011()
        {
            bool retrySearchResult = false;
            try
            {
                bool searchResultVerified = false;
                Reports.TestDescription = "FM10089_FM10086_FM10087_FM10088: File Search options, Search for Pending Files, Search criteria for Pending File Search, Open NFE screen.";
                string pendingFileNumber1 = "";
                string pendingFileNumber2 = "";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to File Search screen.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();

                Reports.TestStep = "Search for pending files by today's date.";
                FastDriver.FileSearch.PendingOrderSearch.FAClick();
                FastDriver.FileSearch.DateFrom1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());
                FastDriver.FileSearch.DateTo1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());
                //FastDriver.FileSearch.DateFrom1.FASetText(DateTime.Now.AddDays(1).ToDateString());
                //FastDriver.FileSearch.DateTo1.FASetText(DateTime.Now.AddDays(1).ToDateString());
                //FastDriver.FileSearch.DateFrom1.FASetText("12-02-2015");
                //FastDriver.FileSearch.DateTo1.FASetText("12-02-2015");
                FastDriver.FileSearch.FindNow.FAClick();

                if (FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: Convert.ToInt32(AutoConfig.WaitTime)) == "No match found.")
                {
                    FastDriver.FileSearch.SwitchToContentFrame();

                    Reports.TestStep = "Create pending files as they do not already exist. Create two files with default values.";
                    pendingFileNumber1 = FastDriver.NewFileEntry.CreateNewFile(AutoConfig.UserName, "CA");
                    pendingFileNumber2 = FastDriver.NewFileEntry.CreateNewFile(AutoConfig.UserName, "CA");

                    Reports.TestStep = "Navigate to File Search screen.";
                    FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();

                    Reports.TestStep = "Search for the pending files.";
                    FastDriver.FileSearch.PendingOrderSearch.FAClick();
                    FastDriver.FileSearch.DateFrom1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());
                    //FastDriver.FileSearch.DateFrom1.FASetText(DateTime.Now.AddDays(1).ToDateString());
                    //FastDriver.FileSearch.FindNow.FAClick();
                    if (FastDriver.FileSearch.RetryFileSearch(pendingFileNumber1, FastDriver.FileSearch.SearchResultTable))
                    {
                        retrySearchResult = true;
                        //FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, Convert.ToInt32(AutoConfig.WaitTime));
                        FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, pendingFileNumber1, 1, TableAction.Click);
                        FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Pending", 5, TableAction.Click);
                    }
                    if (!retrySearchResult)
                    {
                        Reports.StatusUpdate("Could not locate file after multiple retries !", false);
                    }
                    searchResultVerified = true;
                }

                FastDriver.FileSearch.SwitchToContentFrame();
                if (!searchResultVerified)
                {
                    if (FastDriver.FileSearch.SearchResultTable.IsVisible())
                    {
                        Reports.TestStep = "Multiple Pending files exist.";
                        FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Pending", 5, TableAction.Click);
                    }
                }

                if (FastDriver.NewFileEntry.FileStatus.IsVisible() && FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.IsVisible())
                {
                    Reports.TestStep = "Only a single Pending file exists. Verify if the current file status is 'Pending', then create two new Pending files with default values.";
                    Support.AreEqual("Pending", FastDriver.NewFileEntry.FileStatus.FAGetSelectedItem());
                    pendingFileNumber1 = FastDriver.NewFileEntry.CreateNewFile(AutoConfig.UserName, "CA");
                    pendingFileNumber2 = FastDriver.NewFileEntry.CreateNewFile(AutoConfig.UserName, "CA");
                }


                Reports.TestStep = "Navigate to Pending File Search Entry screen through New File Entry screen.";
                FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry");
                FastDriver.NewFileEntry.WaitForEitherElements(FastDriver.PendingFileSearch.SkipSearch, FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo);
                //FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo, Convert.ToInt32(AutoConfig.WaitTime));

                if (FastDriver.NewFileEntry.FileStatus.IsVisible() && FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.IsVisible())
                {
                    Reports.TestStep = "Now, click on New button to open Pending File Search.";
                    FastDriver.BottomFrame.New();
                    FastDriver.PendingFileSearch.WaitForScreenToLoad(null, Convert.ToInt32(AutoConfig.WaitTime));
                }

                Reports.TestStep = "Search for the pending files by Employee Name on  Pending File Search screen.";
                FastDriver.PendingFileSearch.EmployeeName.FASetText(GetParsedUserIDWithSpace(userID: AutoConfig.UserName, IsToBeReversed: true));
                FastDriver.PendingFileSearch.FindNow.FAClick();
                FastDriver.PendingFileSearch.SearchResultTable.IsVisible(Convert.ToInt32(AutoConfig.WaitTime) * 1000);
                Support.AreEqual("Pending", FastDriver.PendingFileSearch.SearchResultTable.PerformTableAction(5, "Pending", 5, TableAction.GetText).Message);
                FastDriver.PendingFileSearch.SearchResultTable.PerformTableAction(5, "Pending", 5, TableAction.Click);
                FastDriver.PendingFileSearch.Select.FAClick();
                FastDriver.NewFileEntry.SwitchToContentFrame();
                Support.AreEqual(GetParsedUserIDWithSpace(userID: AutoConfig.UserName).ToUpper(), FastDriver.NewFileEntry.EnteredBy.FAGetText());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM775: Search on Leading Char String.";


                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile(true, "", false);

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.Numbers.FASetText(AddWildcard(fileNumber, 2));
                FastDriver.FileSearch.FileNo.FAClick();
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Perform a valid file search and verify if the same file is opened.";
                FastDriver.FileNumberSearchSelectionDlg.WaitForScreenToLoad(Convert.ToInt32(AutoConfig.WaitTime));
                FastDriver.FileNumberSearchSelectionDlg.SelectTheSpecifiedFileInTheDialog(fileNumber);
                Support.AreEqual("Open", FastDriver.FileNumberSearchSelectionDlg.SearchResults.PerformTableAction(4, "Open", 4, TableAction.GetText).Message);
                FastDriver.DialogBottomFrame.ClickCancel();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0013_PH()
        {
                Reports.TestDescription = "FM4386_FM4460_FM4458: Search Default Field,MRU File Number,MRU Quick File Search (Cant automate).";
                Assert.Inconclusive("This Flow has NOT been Automated! Please perform this MANUALLY!");
        }

        [TestMethod]
        public void FMUC0012_REG0014()
        {
            try
            {
                Reports.TestDescription = "FM4988: Case Insensitive Search Criteria.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a new file with buyer values in Capital letters.";
                string fileNumber = CreateFileWithBuyerCaps();

                Reports.TestStep = "Navigate to File Search screen.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Enter buyer in small caps except the first letter.";
                FastDriver.FileSearch.Principals.FASetText("BuyerName");
                FastDriver.FileSearch.Buyer.FAClick();
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, Convert.ToInt32(AutoConfig.WaitTime));
                //FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0015()
        {
            try
            {
                Reports.TestDescription = "FM4997: Multiple Values in Text Boxes.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a new file with buyer values in Capital letters.";
                string fileNumber = CreateFile();
                Reports.TestStep = "Navigate to File Search screen.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Enter buyer name and seller name together.";
                FastDriver.FileSearch.Principals.FASetText("BuyerName SellerName");
                FastDriver.FileSearch.AnyPrincipals1.FAClick();
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Check if Search Results table lists the file number just created.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable);
                //FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void FMUC0012_REG0016()
        {
            try
            {
                Reports.TestDescription = "FM5004  Access Rights to Results.";

                Reports.TestStep = "Login to FAST ADM.";
                this.LoginToADM();

                Reports.TestStep = "Select the Region as specified in the AutoConfig";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for the intended user account and open the same.";
                FastDriver.LeftNavigation.Navigate<EmployeeSecurity>(@"Home>System Maintenance>Security Maintenance>Employee Security").WaitForScreenToLoad();
                FastDriver.EmployeeSecurity.LoginNameTextbox.FASetText(AutoConfig.UserName);
                FastDriver.EmployeeSecurity.SearchNowButton.FAClick();

                FastDriver.EmployeeSecurity.ResultsTable.PerformTableAction(1, "[" + AutoConfig.UserName.ToUpper() + "]", 1, TableAction.DoubleClick);

                Reports.TestStep = "Validate that the File Entry Activity role is assigned to the selected office via Business Units to Role view.";
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad(null, Convert.ToInt32(AutoConfig.WaitTime));
                FastDriver.BusinessUnitRoleAssignment.SelectBusinessUnit(AutoConfig.SelectedRegionBUID);
                FastDriver.BusinessUnitRoleAssignment.SelectOfficeUnderBusinessUnits_(AutoConfig.SelectedOfficeBUID);
                if (FastDriver.BusinessUnitRoleAssignment.CheckActivityRightInRole("IT - all", "File Entry Activity"))
                {
                    Reports.StatusUpdate("The Activity Role : File Entry Activity has been located !", true);
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0012_REG0017()
        {
            try
            {
                //AutoConfig.SelectedRegionName
                Reports.TestDescription = "FM5004_2 : Search by different region.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                //Reports.TestStep = "Create the first file with default values.";
                //var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Select the Region that the file has just been created in and perform the search.";
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.Region.FASelectItem(@"02 QA LOAD TEST REGION - DO NOT USE WITHOUT APPROVAL");
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.FindNow.Click();

                Reports.TestStep = "Check if the Search Results table lists open orders.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, Convert.ToInt32(AutoConfig.WaitTime));
                //FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0018()
        {
            try
            {
                Reports.TestDescription = "FV1: Verify the Display format.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                //Reports.TestStep = "Create the first file with default values.";
                //var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers); // WaitForScreenToLoad(FastDriver.FileSearch.Principals);

                Reports.TestStep = "Verify the field type";
                Support.AreEqual("radio", FastDriver.FileSearch._FileSearch.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.PendingOrderSearch.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.Principals.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Buyer.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Seller.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Debtor.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.AnyPrincipals1.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.IndividualHusband.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.TrustEstate.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.BussinessEntity.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.AnyPrincipals2.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.OtherParties.FAGetAttribute("type"));
                Support.AreEqual("select", FastDriver.FileSearch.RoleType.TagName);
                Support.AreEqual("text", FastDriver.FileSearch.PropertyAddress.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertyName.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertyLot.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertyTract.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertyParcel.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.PropertySubDiv.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.APNTaxNo.FAGetAttribute("type"));
                Support.AreEqual("select", FastDriver.FileSearch.State.TagName);
                Support.AreEqual("text", FastDriver.FileSearch.County.FAGetAttribute("type"));
                Support.AreEqual("select", FastDriver.FileSearch.Country.TagName);
                Support.AreEqual("select", FastDriver.FileSearch.Region.TagName);
                Support.AreEqual("radio", FastDriver.FileSearch.FileNo.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.PrincipalsReg.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.ExtNo.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.EntityRef.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.InvoiceNo.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.BussinessSource.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.OutsideRef.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.AnyNumbers.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Open.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Closed.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.OpeninError.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.AnyStatus.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.Cancelled.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.DateFrom1.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.DateTo1.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.Month.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.OpenDate.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.SettlementDate.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.CancelledDate.FAGetAttribute("type"));
                Support.AreEqual("radio", FastDriver.FileSearch.EstSettlementDate.FAGetAttribute("type"));
                Support.AreEqual("text", FastDriver.FileSearch.EmployeeName.FAGetAttribute("type"));
                Support.AreEqual("select", FastDriver.FileSearch.EmployeeType.TagName);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void FMUC0012_REG0019()
        {
            try
            {
                Reports.TestDescription = "FV2: Verify the field validation of File number field.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Check how the page behaves upon entering an invalid character in Numbers field.";
                SetNumberAndSearch("@abc");
                Support.AreEqual(@"Please enter valid file search characters: letters, numbers, *, ?", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers); // this line enables to switch in

                Reports.TestStep = "Click New Search button.";
                FastDriver.FileSearch.NewSearch.FAClick();
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Check how the page behaves upon entering valid characters yet non-existing file.";
                SetNumberAndSearch("abc");
                FastDriver.FileSearch.AnyStatus.FAClick();
                FastDriver.FileSearch.VerifyIfNoMatchFoundMessageAppears();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0020()
        {
            try
            {
                Reports.TestDescription = "FV3: Verify the File Search Result List.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create the first file with default values.";
                var fileNumber = CreateFile();

                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                FastDriver.FileSearch.Principals.FASetText(@"BuyerName BuyerLastName");
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);
                FastDriver.FileSearch.Buyer.FAClick();
                FastDriver.FileSearch.FindNow.FAClick();

                FastDriver.FileSearch.WaitForScreenToLoad();
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                Support.AreEqual("True", FastDriver.FileSearch.View.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.FindNow.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.NewSearch.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.FileSearch.Select.IsEnabled().ToString());
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0021()
        {
            try
            {
                Reports.TestDescription = "FV4: Field definition of File Search screen.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                //Reports.TestStep = "Create the first file with default values.";


                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();

                FastDriver.FileSearch.PropertyLot.FASetText("12432adsfdv");
                Support.AreEqual("12432adsfdv", FastDriver.FileSearch.PropertyLot.FAGetValue());

                Reports.TestStep = "Validate Property Lot field with exact value.";
                FastDriver.FileSearch.PropertyLot.FASetText("");
                FastDriver.FileSearch.PropertyLot.FASetText(@"11111111111111111111111111111111111111111111111111");
                Support.AreEqual(@"11111111111111111111111111111111111111111111111111", FastDriver.FileSearch.PropertyLot.FAGetValue());

                Reports.TestStep = "Enter Property Lot field with upper boundary value+1.";
                FastDriver.FileSearch.PropertyLot.FASetText("");
                FastDriver.FileSearch.PropertyLot.FASetText(@"111111111111111111111111111111111111111111111111111");
                Reports.TestStep = "Validate user is not able to type more than the exact value.";
                Support.AreEqual(@"11111111111111111111111111111111111111111111111111", FastDriver.FileSearch.PropertyLot.FAGetValue());

                Reports.TestStep = "Validate Property Tract with lower boundary.";
                FastDriver.FileSearch.PropertyTract.FASetText(@"1@334354657bghghj");
                Support.AreEqual(@"1@334354657bghghj", FastDriver.FileSearch.PropertyTract.FAGetValue());

                Reports.TestStep = "Validate Property Tract with exact value.";
                FastDriver.FileSearch.PropertyTract.FASetText("");
                FastDriver.FileSearch.PropertyTract.FASetText(@"1@334354657bghghjkuy");
                Support.AreEqual(@"1@334354657bghghjkuy", FastDriver.FileSearch.PropertyTract.FAGetValue());


                Reports.TestStep = "Enter Property Tract field with upper boundary value+1.";
                FastDriver.FileSearch.PropertyTract.FASetText("");
                FastDriver.FileSearch.PropertyTract.FASetText(@"334354657bghghjkuyase");
                Reports.TestStep = "Validate user is not able to type more than the exact value.";
                Support.AreEqual(@"334354657bghghjkuyas", FastDriver.FileSearch.PropertyTract.FAGetValue());

                Reports.TestStep = "Validate Property Parcel with lower boundary.";
                FastDriver.FileSearch.PropertyParcel.FASetText("");
                FastDriver.FileSearch.PropertyParcel.FASetText("ddfref333333333333333333g");
                Support.AreEqual(@"ddfref333333333333333333g", FastDriver.FileSearch.PropertyParcel.FAGetValue());


                Reports.TestStep = "Validate Property Parcel with exact value.";
                FastDriver.FileSearch.PropertyParcel.FASetText("");
                FastDriver.FileSearch.PropertyParcel.FASetText("ddfref333333333333333333gfrgr1");
                Support.AreEqual(@"ddfref333333333333333333gfrgr1", FastDriver.FileSearch.PropertyParcel.FAGetValue());


                Reports.TestStep = "Validate Property Parcel with upper boundary value+1.";
                FastDriver.FileSearch.PropertyParcel.FASetText("");
                FastDriver.FileSearch.PropertyParcel.FASetText("fref333333333333333333gfrgr1123");
                Support.AreEqual(@"fref333333333333333333gfrgr112", FastDriver.FileSearch.PropertyParcel.FAGetValue());


                Reports.TestStep = "Validate APN/Tax No. with lower boundary.";
                FastDriver.FileSearch.APNTaxNo.FASetText("");
                FastDriver.FileSearch.APNTaxNo.FASetText("ddfref333333333333333333g");
                Support.AreEqual(@"ddfref333333333333333333g", FastDriver.FileSearch.APNTaxNo.FAGetValue());

                Reports.TestStep = "Validate APN/Tax No. with exact value.";
                FastDriver.FileSearch.APNTaxNo.FASetText("");
                FastDriver.FileSearch.APNTaxNo.FASetText("ddfref333333333333333333gfrgr1");
                Support.AreEqual(@"ddfref333333333333333333gfrgr1", FastDriver.FileSearch.APNTaxNo.FAGetValue());

                Reports.TestStep = "Validate APN/Tax No. with upper boundary value+1.";
                FastDriver.FileSearch.APNTaxNo.FASetText("");
                FastDriver.FileSearch.APNTaxNo.FASetText("fref333333333333333333gfrgr1123");
                Support.AreEqual(@"fref333333333333333333gfrgr112", FastDriver.FileSearch.APNTaxNo.FAGetValue());


                Reports.TestStep = "Validate Principals, Other Parties, Property Name, Employee Name fields with lower boundary.";
                FastDriver.FileSearch.Principals.FASetText("");
                FastDriver.FileSearch.Principals.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZ", FastDriver.FileSearch.Principals.FAGetValue());

                FastDriver.FileSearch.OtherParties.FASetText("");
                FastDriver.FileSearch.OtherParties.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZ", FastDriver.FileSearch.OtherParties.FAGetValue());

                FastDriver.FileSearch.PropertyName.FASetText("");
                FastDriver.FileSearch.PropertyName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZ", FastDriver.FileSearch.PropertyName.FAGetValue());

                FastDriver.FileSearch.EmployeeName.FASetText("");
                FastDriver.FileSearch.EmployeeName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZ", FastDriver.FileSearch.EmployeeName.FAGetValue());


                Reports.TestStep = "Validate Principals field with upper boundary value+1.";
                FastDriver.FileSearch.Principals.FASetText("");
                FastDriver.FileSearch.Principals.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNeXTRA");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMN", FastDriver.FileSearch.Principals.FAGetValue());

                Reports.TestStep = "Validate Other Parties field with upper boundary value+1.";
                FastDriver.FileSearch.OtherParties.FASetText("");
                FastDriver.FileSearch.OtherParties.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOextra");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNO", FastDriver.FileSearch.OtherParties.FAGetValue());

                Reports.TestStep = "Validate Property Name field with upper boundary value+1.";
                FastDriver.FileSearch.PropertyName.FASetText("");
                FastDriver.FileSearch.PropertyName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOExtra");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNO", FastDriver.FileSearch.PropertyName.FAGetValue());

                Reports.TestStep = "Validate Employee Name field with upper boundary value+1.";
                FastDriver.FileSearch.EmployeeName.FASetText("");
                FastDriver.FileSearch.EmployeeName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOExtra");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNABCDEFGHIJKLMNO", FastDriver.FileSearch.EmployeeName.FAGetValue());



                Reports.TestStep = "Validate Principals field with exact value.";
                FastDriver.FileSearch.Principals.FASetText("");
                FastDriver.FileSearch.Principals.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMN", FastDriver.FileSearch.Principals.FAGetValue());

                Reports.TestStep = "Validate Other Parties field with exact value.";
                FastDriver.FileSearch.OtherParties.FASetText("");
                FastDriver.FileSearch.OtherParties.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.FileSearch.OtherParties.FAGetValue());

                Reports.TestStep = "Validate Property Name field with exact value.";
                FastDriver.FileSearch.PropertyName.FASetText("");
                FastDriver.FileSearch.PropertyName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.FileSearch.PropertyName.FAGetValue());

                Reports.TestStep = "Validate Employee Name field with exact value.";
                FastDriver.FileSearch.EmployeeName.FASetText("");
                FastDriver.FileSearch.EmployeeName.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU", FastDriver.FileSearch.EmployeeName.FAGetValue());



                Reports.TestStep = "Validate Month field with lower boundary.";
                FastDriver.FileSearch.Month.FASetText("");
                //FastDriver.FileSearch.Month.SendKeys(OpenQA.Selenium.Keys.Delete);
                FastDriver.FileSearch.Month.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.FileSearch.Month.FASetText("12");
                Support.AreEqual(@"12", FastDriver.FileSearch.Month.FAGetValue());

                Reports.TestStep = "Validate Month field with exact value.";
                FastDriver.FileSearch.Month.FASetText("");
                FastDriver.FileSearch.Month.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.FileSearch.Month.FASetText("123");
                Support.AreEqual(@"123", FastDriver.FileSearch.Month.FAGetValue());

                Reports.TestStep = "Validate Month field with upper boundary+1.";
                FastDriver.FileSearch.Month.FASetText("");
                FastDriver.FileSearch.Month.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.FileSearch.Month.FASetText("1234");
                Support.AreEqual(@"123", FastDriver.FileSearch.Month.FAGetValue());
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void FMUC0012_REG0022()
        {
            try
            {
                Reports.TestDescription = "FM7895: FASTView (2nd Instance of FAST).";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create Order";
                var fileNumber = this.CreateFile();

                Reports.TestStep = "Click FAST View and open FAST View window.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.FastView.FAClick();
                Playback.Wait(2000);

                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", true, 60);
                FastDriver.FastViewFileSearch.WaitForScreenToLoad();

                FastDriver.FastViewFileSearch.Country.FASelectItem("USA");
                Playback.Wait(4000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
                FastDriver.FastViewFileSearch.WaitForScreenToLoad(FastDriver.FastViewFileSearch.Numbers);
                FastDriver.FastViewFileSearch.Numbers.FASetText(fileNumber);
                FastDriver.FastViewFileSearch.FindNow.FAClick();
                FastDriver.FastViewFileSearch.WaitForScreenToLoad(FastDriver.FastViewFileSearch.FileNumberLabel, Convert.ToInt32(AutoConfig.WaitTime));
                Support.AreEqual(fileNumber, FastDriver.FastViewFileSearch.FileNumberLabel.FAGetText());

                //FastDriver.FASTView.SearchResultTable.PerformTableAction(5, "Open", 5, TableAction.Click);
                //FastDriver.WebDriver.Close();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //FastDriver.FileSearch.WaitForScreenToLoad();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0012_REG0023()
        {
            bool retrySearchResult = false;
            try
            {
                Reports.TestDescription = "Test the New Search functionality. Check if all the fields are reset upon clicking the New Search button.";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                string pendingFileNumber1 = FastDriver.NewFileEntry.CreateNewFile(userID: AutoConfig.UserName, state: "CA", IsBuyerDetailsNeeded: false);


                Reports.TestStep = "Navigate to File Search screen";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Select Pending Order Search option";
                FastDriver.FileSearch.PendingOrderSearch.FAClick();

                Reports.TestStep = "Validate the default value of the fields.";
                Support.AreEqual("", FastDriver.FileSearch.Principals.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.PropertyAddress.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.PropertyName.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.PropertyLot.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.PropertyTract.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.PropertyParcel.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.PropertySubDiv.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.APNTaxNo.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.State.FAGetSelectedItem());
                Support.AreEqual("", FastDriver.FileSearch.County.FAGetValue());
                Support.AreEqual("USA", FastDriver.FileSearch.Country.FAGetSelectedItem());
                Support.AreEqual("", FastDriver.FileSearch.Numbers.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.DateFrom1.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.DateTo1.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.EmployeeName.FAGetValue());
                Support.AreEqual("", FastDriver.FileSearch.EmployeeType.FAGetSelectedItem());

                Reports.TestStep = "AF1: search for a pending file.";
                FastDriver.FileSearch.State.FASelectItem("CA");
                FastDriver.FileSearch.FindNow.FAClick();

                Reports.TestStep = "Verify the number of records.";
                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.SearchResultTable, Convert.ToInt32(AutoConfig.WaitTime));
                // PerformTableAction(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                if (FastDriver.FileSearch.SearchResultTable.GetRowCount() >= 100)
                {
                    Reports.StatusUpdate("More than 100 Records are found !", true);
                    FastDriver.FileSearch.VerifyMoreThan100RecordsFoundNote();
                }
                else
                {
                    Reports.StatusUpdate("Lesser than 100 Records are found !", true);
                }

                FastDriver.FileSearch.SwitchToContentFrame();
                Reports.TestStep = "Validate the newly created pending file is avaialbe in the list.";


                if (FastDriver.FileSearch.RetryFileSearch(pendingFileNumber1, FastDriver.FileSearch.SearchResultTable))
                {
                    retrySearchResult = true;
                }
                if (!retrySearchResult)
                {
                    Reports.StatusUpdate("Could not locate file after multiple retries !", false);
                }

                FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, pendingFileNumber1, 1, TableAction.Click);
                FastDriver.FileSearch.Select.FAClick();

                Reports.TestStep = "Validate the file number on New file Entry screen";
                FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo, Convert.ToInt32(AutoConfig.WaitTime));
                Support.AreEqual(pendingFileNumber1, FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue());

                Reports.TestStep = "create another pending file with specific details";
                string pendingFileNumber2 = FastDriver.NewFileEntry.CreateNewFile(userID: AutoConfig.UserName, state: "AS", IsBuyerDetailsNeeded: true);

                Reports.TestStep = "AF1: Exact Match - move to File Search page and search for pending file with specific details.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Select Pending Order Search option";
                FastDriver.FileSearch.PendingOrderSearch.FAClick();

                Reports.TestStep = "Enter search criteria.";
                EnterSearchCriteriaForPendingSearch("AS");

                if (WaitForEitherElementsAndRetryFileSearch(pendingFileNumber2))
                {
                    FastDriver.NewFileEntry.WaitForScreenToLoad(FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo, Convert.ToInt32(AutoConfig.WaitTime));
                    Support.AreEqual(pendingFileNumber2, FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.FAGetValue());
                }


                Reports.TestStep = "Navigate to File Search page.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Select Pending Order Search option";
                FastDriver.FileSearch.PendingOrderSearch.FAClick();

                Reports.TestStep = "AF2: Test the behavior upon searching for a non-existing pending file.";
                EnterSearchCriteriaForPendingSearch("AR", "___Non-existing__");
                FastDriver.FileSearch.FindNow.FAClick();
                Support.AreEqual("No match found.", FastDriver.WebDriver.HandleDialogMessage(true, true, Convert.ToInt32(AutoConfig.WaitTime)));

                FastDriver.FileSearch.SwitchToContentFrame();
                Reports.TestStep = "AF3: Clear screen for new search.";
                Support.AreEqual("True", FastDriver.FileSearch.NewSearch.IsEnabled().ToString());
                FastDriver.FileSearch.NewSearch.FAClick();

                FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

                Reports.TestStep = "Validate the default values of all search criteria for next search.";
                Support.AreEqual(string.Empty, FastDriver.FileSearch.Principals.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyAddress.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyName.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyLot.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyTract.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyParcel.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertySubDiv.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.APNTaxNo.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.State.FAGetSelectedItem());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.County.FAGetValue());
                Support.AreEqual("USA", FastDriver.FileSearch.Country.FAGetSelectedItem());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.Numbers.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.DateFrom1.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.DateTo1.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.EmployeeName.FAGetValue());
                Support.AreEqual(string.Empty, FastDriver.FileSearch.EmployeeType.FAGetSelectedItem());
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0012_REG0024()
        {
            try
            {
                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();
                Reports.TestStep = "Navigate to QA Automation Region-CD";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.Office.FAClick();
                FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.SearchbyBUID.FASetText("13072" + FAKeys.Tab);
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Create Order";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.CreateStandardFile();
                Playback.Wait(5000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string fileNumber = FastDriver.FileHomepage.FileNum.FAGetValue().ToString();

                Reports.TestStep = "QA Automation Region - DO NOT TOUCH and search file the file which is created in QA Automation Region-CD";

                this.LoginToIIS();
                Reports.TestStep = "Search the file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem("QA Automation Region - CD");
                FastDriver.FileSearch.Numbers.FASetText(fileNumber);
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string fileNumber1 = FastDriver.FileHomepage.FileNum.FAGetValue().ToString();

                Reports.TestStep = "Verify the File which was crated in QA Automation Region - CD";
                Support.AreEqual(fileNumber, fileNumber1);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #region Private Methods

        private void LoginToIIS()
        {
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            catch (Exception ex)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }


        private void LoginToADM()
        {
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            }
            catch (Exception ex)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }

        private void SetNumberAndSearch(string fileNo)
        {
            FastDriver.FileSearch.Numbers.FASetText(@fileNo);
            FastDriver.FileSearch.FindNow.Click();
        }


        private string CreateFileWithBuyerCaps()
        {
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = RequestFactory.GetCreateFileDefaultRequest();


            fileRequest.File.Buyers[0].FirstName = "BUYERNAME";
            fileRequest.File.Buyers[0].LastName = "BUYERLASTNAME";

            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            return fileNumber;
        }

        /*fileRequest.File = new File()
            {
                Buyers = new BuyerSeller[] 
                { 
                        new BuyerSeller() 
                        { 
                            FirstName = "BUYERNAME", 
                            LastName = "BUYERLASTNAME", 
                        }
                },
            };*/
        private string AddWildcard(string fileNumber, int substrLength = 3)
        {
            return fileNumber.Substring(0, substrLength) + "*";
        }

        private string GetParsedUserIDWithSpace(string userID, bool IsToBeReversed = false)
        {
            string parsedUserID = "";
            if (userID.Contains("\\"))
            {
                parsedUserID = userID.Split('\\').LastOrDefault().Substring(0, 4) + " " + userID.Split('\\').LastOrDefault().Substring(4, 4);
            }
            if (IsToBeReversed)
            {
                parsedUserID = parsedUserID.Split(' ').LastOrDefault() + ", " + parsedUserID.Split(' ').FirstOrDefault();
                return parsedUserID.ToUpper();
            }
            return parsedUserID;
        }

        private string CreateFileWithEmployeeDetails()
        {
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = RequestFactory.GetCreateFileDefaultRequest();

            fileRequest.File.Services[0].OfficerObjectCD = "FASTQA07A"; //Employee Name for Title Officer Role
            fileRequest.File.Services[1].OfficerObjectCD = "FASTQA07A"; //Employee Name for Escrow Officer Role

            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            return fileNumber;

        }

        private string CreateFile(bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            string buyerRandomVal = Support.RandomString("AAAAAZ");
            string[] State = { "CR", "AR" };
            Reports.TestStep = "Generate a random buyer name.";
            Support.DataSave("RandomBuyerName", buyerRandomVal);

            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();

                if (OnDemandRequest)
                {

                    fileRequest.File.AutoNumberIndicator = IsAutoNumber;
                    fileRequest.File.FileNumber = "AU" + Support.RandomString("NNNNNN");

                    /*fileRequest.File = new File()
                    {
                        AutoNumberIndicator = IsAutoNumber,
                        FileNumber = "AU" + Support.RandomString("NNNNNN")
                    };*/

                    if (!string.IsNullOrEmpty(GABCode))
                    {
                        fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
                        fileRequest.File.BusinessParties[0].RoleTypeObjectCD = "BUSSOURCE";
                        fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.OtherRealEstateAgent;

                        /* fileRequest.File = new File()
                         {
                             //AutoNumberIndicator = IsAutoNumber,
                             BusinessParties = new FileBusinessParty[] 
                        {
                             new FileBusinessParty()
                             {
                                 AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode),
                                 RoleTypeObjectCD = "BUSSOURCE",
                                 AdditionalRole = new AdditionalRoleList()
                                 {
                                     eAddtionalRole = AdditionalRoleType.OtherRealEstateAgent
                                 }
                             }
                        }
                         };*/
                    }

                    fileRequest.File.Buyers[0].FirstName = buyerRandomVal;

                    /*fileRequest.File.Buyers =
                    new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            //Type = "Individual",
                            //SSN = "123-45-6789",
                            FirstName = buyerRandomVal,
                           // LastName = "Buyer1Lastname",
                        },                        
                    };*/

                    /*fileRequest.File.Properties[0].PropertyAddress[0].State = "AL";
                    fileRequest.File.Properties[0].PropertyAddress[0].County = "AUTAUGA";
                    //fileRequest.File.Properties[0].PropertyAddress[0].City = "PHOENIX";*/

                    fileRequest.File.Properties[0].PropertyAddress[0].State = "AR";
                    fileRequest.File.Properties[0].PropertyAddress[0].County = "LAWRENCE";
                    //fileRequest.File.Properties[0].PropertyAddress[0].City = "PHOENIX";
                    fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                    /*fileRequest.File.Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "AR", 
//                                    City = "ALBANY", 
  //                                  County = "ALAMEDA", 
    //                                Country = "USA" 
                                } 
                            } 
                        } 
                    };*/
                }

                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch //If not able to create file via web service, create file via FAST GUI
            {
                Reports.TestStep = "Create File using FAST GUI.";
                NewFileParameters newFile = null;
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                if (!OnDemandRequest)
                    FastDriver.QuickFileEntry.CreateStandardFile();
                if (OnDemandRequest)
                {
                    newFile = SetNewFileParameters(buyerRandomVal);
                    FastDriver.QuickFileEntry.CreateFile(newFile).SubmitQuickFileEntryForm();
                }

                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
            }
            if (string.IsNullOrEmpty(fileNumber))
            {
                throw new Exception("File creation is unsuccessful ! Aborting the test !");
            }
            return fileNumber;
        }



        private NewFileParameters SetNewFileParameters(string buyerRandomVal)
        {
            return new NewFileParameters()
            {
                BusinessSourceGABcode = "HUDFLINSR1",
                Title = true,
                Escrow = true,
                BusinessSegment = "Residential",
                TransactionType = "Sale w/Mortgage",
                PropertyState = "AR",
                Buyer1Type = "Individual",
                Buyer1FirstName = buyerRandomVal,
                Buyer1LastName = "Buyer1Lastname",
                Seller1Type = "Individual",
                Seller1FirstName = "Seller1Firstname",
                Seller1LastName = "Seller1Lastname",
                PropertyPropTaxAPN1 = "Prop1APN1",
                PropertyBookAddrLin1 = "J305",
                PropertyCity = "ALBANY",
                PropertyZipCode = "12345",
                PropertyCounty = "Lawrence",
            };
        }


        private List<string> LoadTheList()
        {
            return new List<string>
            {
                "Associated Party",
                "Assumption Lender",
                "Broker Disbursement Payee",
                "Business Source",
                "Buyer",
                "Buyer's Attorney",
                "Buyer's Broker",
                "Buyer's RE Broker Transaction Coordinator",
                "Buyer's Real Estate Agent",
                "Construction Company/Builder",
                "Directed By",
                "For Sale by Owner",
                "Hazard Insurance Underwriter",
                "HOA - Management Company",
                "Home Warranty",
                "Homeowner Association",
                "IBA Beneficiary",
                "Inspection and Repair",
                "Insurance Agent",
                "Lender",
                "Lender - 3rd Party Payee",
                "Lender's Attorney",
                "Lessor",
                "Miscellaneous",
                "Mortgage Broker",
                "Mortgage Broker - 3rd Party Payee",
                "New Lender",
                "Other",
                "Other Real Estate Agent",
                "Other Real Estate Broker",
                "Outside Escrow Company",
                "Outside Title Company",
                "Owner Office",
                "Payee",
                "Payoff Lender",
                "Production Office",
                "Real Estate Investment Trust",
                "Seller",
                "Seller's Attorney",
                "Seller's Broker",
                "Seller's Real Estate Agent",
                "Split Entity",
                "Split Office",
                "Survey",
                "Tax Collector",
                "Title Agent",
                "Title Company/Draft",
                "Trustee",
                "Utility Company"
            };
        }
        #endregion

        private string GenerateInvoiceNo()
        {
            string returnValue = string.Empty;
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 4, TableAction.SetText, "2000.00");
            var rowCollection = FastDriver.FileFees.TitleandescrowTable.FindElements(By.TagName("tr"));
            try
            {
                //rowCollection[2].FindElements(By.TagName("td"))[6].FindElement(By.TagName("span")).FindElement(By.TagName("input")).FASetText("1000.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 7, TableAction.SetText, "1000.00");
            }
            catch (Exception e)
            {
                //rowCollection[2].FindElements(By.TagName("td"))[5].FindElement(By.TagName("span")).FindElement(By.TagName("input")).FASetText("1000.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 6, TableAction.SetText, "1000.00");
            }

            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(3, 1, TableAction.On);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(3, 4, TableAction.SetText, "200.00");
            try
            {
                //rowCollection[2].FindElements(By.TagName("td"))[6].FindElement(By.TagName("span")).FindElement(By.TagName("input")).FASetText("100.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(3, 7, TableAction.SetText, "100.00");
            }
            catch (Exception e)
            {
                //rowCollection[2].FindElements(By.TagName("td"))[5].FindElement(By.TagName("span")).FindElement(By.TagName("input")).FASetText("100.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(3, 6, TableAction.SetText, "100.00");
            }
            FastDriver.BottomFrame.Done();
            FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
            FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 8, TableAction.On);

            System.Threading.Thread.Sleep(2000);
            FastDriver.InvoiceFees.Final.FAClick();
            if (FastDriver.InvoiceFees.WaitUntilInvoiceNumberIsGeneratedForTheFirstInvName())
            {
                returnValue = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, 2, TableAction.GetText).Message;
            }
            return returnValue;
        }


        private void EnterSearchCriteriaForPendingSearch(string state, string buyer = "BuyerFirstName")
        {
            FastDriver.FileSearch.Buyer.FAClick();
            FastDriver.FileSearch.Principals.FASetText(buyer);
            FastDriver.FileSearch.State.FASelectItem(state);
            FastDriver.FileSearch.DateFrom1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());
            FastDriver.FileSearch.DateTo1.FASetText(DateTime.UtcNow.AddHours(-8).ToDateString());
            //FastDriver.FileSearch.EmployeeName.FASetText("Jeella, Venkateswara");
            FastDriver.FileSearch.EmployeeName.FASetText(GetParsedUserIDWithSpace(userID: AutoConfig.UserName, IsToBeReversed: true));
            FastDriver.FileSearch.EmployeeType.FASelectItem("Escrow Officer");
        }



        private void WaitForAppropriateElementsState()
        {
            FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers, 60);
            FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Principals);
            FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.TrustEstate);
        }


        private void SearchForFile(string fileNumber, string fileStatus)
        {
            int retryCount = 1;
            //bool IsMatchFound = false;
            bool MultipleRecordsDisplayed = false;
            string alertMessage = "";

            FastDriver.FileSearch.Country.FASelectItem("USA");
            Playback.Wait(4000); // to avoid failures due to screen refresh multiple times upon selecting an option from the Country dropdown.
            FastDriver.FileSearch.WaitForScreenToLoad(FastDriver.FileSearch.Numbers);

            if (fileStatus.Equals("Opened in Error"))
                FastDriver.FileSearch.Numbers.FASetText(AddWildcard(fileNumber: fileNumber, substrLength: 4));

            if (!fileStatus.Equals("Opened in Error"))
                FastDriver.FileSearch.Numbers.FASetText(fileNumber);

            switch (fileStatus)
            {
                case "Opened in Error":
                    FastDriver.FileSearch.OpeninError.FAClick();
                    break;
                case "Closed":
                    FastDriver.FileSearch.Closed.FAClick();
                    break;
                case "Cancelled":
                    FastDriver.FileSearch.Cancelled.FAClick();
                    break;
            }


            while (retryCount <= 5) // sometimes no match found alert appears, though the file exists. Try five times searching for the file with 5 seconds wait between searches.
            {
                FastDriver.FileSearch.FindNow.FAClick();

                if (retryCount == 1)
                {
                    Reports.TestStep = "In case more than one record found, handle the message alert/file number selection dialog appropriately.";
                }

                alertMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, Convert.ToInt32(AutoConfig.WaitTime));
                if (!alertMessage.Contains(fileStatus) && !alertMessage.Equals("No match found."))
                {
                    if (FastDriver.FileSearch.SearchResultTable.IsVisible())
                    {
                        MultipleRecordsDisplayed = true;
                        break;
                    }
                }

                if (!alertMessage.Equals("No match found."))
                {
                    break;
                }

                if (alertMessage.Equals("No match found."))
                {
                    FastDriver.FileSearch.SwitchToContentFrame();
                    Reports.TestStep = "No match found alert is shown up. Retrying... : " + retryCount++;
                    System.Threading.Thread.Sleep(5000);
                    continue;
                }
            }

            if (!MultipleRecordsDisplayed)
            {
                if (alertMessage.Contains("Opened in Error"))
                {
                    Reports.StatusUpdate("Opened in Error alert popped-up !", true);
                }
                VerifyFileIsOpenedOnFileHomePage(fileNumber, fileStatus);
            }

            if (MultipleRecordsDisplayed)
            {
                //Reports.TestStep = "Check if the file created in this test is listed in the dialog";
                //int currentRow = FastDriver.FileNumberSearchSelectionDlg.SelectTheSpecifiedFileInTheDialog(fileNumber);
                //FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Check the file just created is listed.";
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, GetFileStatusLabel(fileStatus), 5, TableAction.Click);
                FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.DoubleClick);

                if (fileStatus.Equals("Opened in Error"))
                {
                    Reports.TestStep = "Handle 'Opened in Error' message alert."; ;
                    FastDriver.WebDriver.HandleDialogMessage();//if more than 100 records found alert appeared, this alert pops-up with the message containing 'Cancelled'.
                }
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //FastDriver.FileSearch.SwitchToContentFrame();
                VerifyFileIsOpenedOnFileHomePage(fileNumber, fileStatus);
            }
        }

        private void VerifyFileIsOpenedOnFileHomePage(string fileNumber, string fileStatus)
        {
            FastDriver.FileHomepage.WaitForScreenToLoad();
            if (fileNumber == FastDriver.FileHomepage.GetFileNumber())
                Reports.StatusUpdate(fileStatus + " file opened on File Homepage!", true);
        }

        private string GetFileStatusLabel(string fileStatus)
        {
            string fileStatusLabel = "";
            switch (fileStatus)
            {
                case "Opened in Error":
                    fileStatusLabel = "Open In Error";
                    break;
                case "Closed":
                    fileStatusLabel = "Closed";
                    break;
                case "Cancelled":
                    fileStatusLabel = "Cancelled";
                    break;
            }
            return fileStatusLabel;
        }



        private bool WaitForEitherElementsAndRetryFileSearch(string fileNumber = "")
        {
            int retryCount = 1;
            string alertMessage = "";
            bool result = false;
            while (retryCount <= 10)
            {
                FastDriver.FileSearch.FindNow.FAClick();

                if (retryCount == 1)
                {
                    Reports.TestStep = "Handle 'No match found' alert, if appears.";
                }
                alertMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, 30);

                if (alertMessage.Equals("No match found."))
                {
                    System.Threading.Thread.Sleep(7000);
                    Reports.StatusUpdate("Retrying for file search after waiting for 5 seconds : " + retryCount++, true);
                    FastDriver.FileSearch.SwitchToContentFrame();
                    continue;
                }

                WaitForEitherElements(FastDriver.FileSearch.SearchResultTable, FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo);

                FastDriver.FileSearch.SwitchToContentFrame();
                if (!alertMessage.Equals("No match found.") && FastDriver.FileSearch.SearchResultTable.IsVisible())
                {
                    if (!string.IsNullOrEmpty(fileNumber) && !FastDriver.FileSearch.SearchResultTable.FAGetText().Contains(fileNumber))
                    {
                        System.Threading.Thread.Sleep(5000);
                        Reports.StatusUpdate("Retrying search from the Search Results Grid after waiting for 5 seconds : " + retryCount++, true);
                        continue;
                    }
                    FastDriver.FileSearch.SearchResultTable.PerformTableAction(1, fileNumber, 1, TableAction.Click);
                    FastDriver.FileSearch.SearchResultTable.PerformTableAction(5, "Pending", 5, TableAction.Click);
                    FastDriver.FileSearch.Select.FAClick();
                    result = true;
                    break;
                }

                if (!alertMessage.Equals("No match found.") && FastDriver.NewFileEntry.DetailsNewFileEntryCustFileNo.IsVisible())
                {
                    result = true;
                    break;
                }
            }
            return result;
        }


        private bool WaitForEitherElements(IWebElement element, IWebElement alternateElement)
        {

            return Report.UpdateLog<bool>(element, "Wait", "Visible", "Element, Alternate Element", () =>
            {

                WebDriverWait Wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(Convert.ToInt32(AutoConfig.WaitTime)));
                try
                {
                    FastDriver.FileSearch.SwitchToContentFrame();
                    Wait.Until(FAExpectedConditions.ElementIsVisible(element));
                }
                catch (WebDriverTimeoutException)
                {
                    FastDriver.NewFileEntry.SwitchToContentFrame();
                    if (alternateElement.IsVisible())
                    {
                        return true;
                    }
                    throw;
                }
                return true;
            });
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
