﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0022_Create_Invoice : MasterTestClass
    {

        #region BAT

        [TestMethod]
        [Description("Create an invoice, Delete an invoice, Deliver Invoice & AF1: Deselect invoice fees/UNINVOICED&ESTIMATED.")]
        public void FMUC0022_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF: Create an invoice, AF2: Delete an invoice, AF4: Deliver Invoice & AF1: Deselect invoice fees/UNINVOICED&ESTIMATED.";
                
                #region MF: Create an invoice

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Verify the Uninvoiced status of the Invoice on first load after adding the fee in fee entry
                Reports.TestStep = "Verify the Uninvoiced status of the Invoice on first load after adding the fee in fee entry";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select second party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("247");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "247", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Create an invoice/Select fees & Estimate option.";
                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.Estimate.FAClick();
                #endregion

                #region Add Fees and Verify the IE message and click on OK button.
                Reports.TestStep = "Add Fee";
                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "20.00");
                FastDriver.BottomFrame.Done();
                #endregion
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "40.00");
                FastDriver.BottomFrame.Done();

                if (FastDriver.WebDriver.WaitForAlertToExist(20))
                {
                    Support.AreEqual("Please add the new fee to the Invoice", FastDriver.WebDriver.HandleDialogMessage());
                }
                #endregion

                #region  Create an invoice/Select Final option
                Reports.TestStep = "Select Final option.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);
                FastDriver.InvoiceFees.Final.FAClick();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 6, TableAction.Click);

                #endregion

                #endregion

                #region AF2: Delete an invoice
                Reports.TestStep = "AF2: Delete an invoice.";
                Reports.StatusUpdate("AF2: Delete an invoice.", true);

                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("HUDASLNDR1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "HUDASLNDR1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Assumption Lender 1 for HUD Test Name 1 Assumption Lender 1 for HUD Test Name 2", 6, TableAction.Click);
                FastDriver.InvoiceFees.Remove.FAClick();
                Reports.TestStep = "Verify IE message and Click on Ok button.";
                Support.AreEqual("Do you wish to delete invoice 0?", FastDriver.WebDriver.HandleDialogMessage());
                #endregion

                #region AF4: Deliver Invoice

                Reports.TestStep = "AF4: Deliver Invoice";
                Reports.StatusUpdate("AF4: Deliver Invoice.", true);
                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 6, TableAction.Click);
                Keyboard.SendKeys("^L");

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForDialogScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                #endregion

                Reports.TestStep = "Uncheck Buyer/Seller format and deliver the invoice";
                FastDriver.InvoiceFees.Format.FASetCheckbox(false);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 6, TableAction.Click);
                Keyboard.SendKeys("^L");

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForDialogScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();
                
                #endregion

                Reports.TestDescription = "Uncheck Payment to Info checkbox and deliver the invoice";
                FastDriver.InvoiceFees.ShowAddress.FASetCheckbox(false);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 6, TableAction.Click);
                Keyboard.SendKeys("^L");

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForDialogScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                //FastDriver.PrintDlg.Cancel.FAClick();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                #endregion

                #endregion

                #region AF1: Deselect invoice fees/UNINVOICED&ESTIMATED.
                Reports.TestStep = "AF1: Deselect invoice fees/UNINVOICED&ESTIMATED.";
                Reports.StatusUpdate("AF1: Deselect invoice fees/UNINVOICED&ESTIMATED.", true);
                Reports.TestStep = "Deselect invoice fees/Uninvoiced.";

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.Off);

                Reports.TestStep = "Deselect invoice fees/Uninvoiced.";
                string FinalDJDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINALADJ", 9, TableAction.GetText).Message;

                Reports.TestStep = "Deselect invoice fees/Estimated.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.Off);

                Reports.TestStep = "Deselect invoice fees/Estimated.";
                string EstmDJDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTMTADJ", 9, TableAction.GetText).Message;

                int diff = EstmDJDate.CompareTo(FinalDJDate);

                if (diff > 0)
                    Reports.StatusUpdate("Export request date updated", true);
                else
                    Reports.StatusUpdate("Export request date NOT updated", true);

                #endregion

                #region AF3: Cancel an Invoice/FINAL & UNINVOICED.
                Reports.TestStep = "AF3: Cancel an Invoice/FINAL & UNINVOICED.";
                Reports.StatusUpdate("AF3: Cancel an Invoice/FINAL & UNINVOICED.", true);
                
                Reports.TestStep = "Cancel an Invoice/Final.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINALADJ", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.TestStep = "Verify the IE message and click on OK button.";
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage().Contains("Do you wish to cancel invoice").ToString());
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Verify the fees are not associated with invoice party after cancelling the invoice";
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).Selected.ToString());

                Reports.TestStep = "Verify the invoice history after cancelling the invoice";
                FastDriver.InvoiceFees.History.FAClick();
                FastDriver.InvoiceHistory.SwitchToContentFrame();
                Support.AreEqual("-50.00", FastDriver.InvoiceHistory.SummaryTable.PerformTableAction(3, "Canceled", 2, TableAction.GetText).Message.Trim());

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 1, TableAction.Click);

                Reports.TestStep = "Cancel an Invoice/Uninvoiced.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Cancel an Invoice/Final.";
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Estimate.Enabled.ToString());

                Reports.TestStep = "Amount should be added to Not Invoiced amount  - after cancellation";
                Support.AreEqual("Invoice Fee List  - Not Invoiced $: 54.98", FastDriver.InvoiceFees.InvoiceFeeList.Text.Trim());

                Reports.TestStep = "Create a GAB with No Address  and verify - Estimate / Final button should not be enabled";

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();
                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem("Lease");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsRadio.FAClick();

                Reports.TestStep = "Click on New GAB button.";
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add a Contact.";
                FastDriver.GABEntryRequestDlg.BuyerSellerType.FASelectItem("Business Entity");
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem("Lease");
                FastDriver.GABEntryRequestDlg.Name1.FASetText("TestLease");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                              
                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "TestLease", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Estimate.Enabled.ToString());


                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry").SwitchToContentFrame();

                Reports.TestStep = "Create File";
                CreateFile();

                Reports.TestStep = "Add a fee";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.New.FAClick();
                
                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Select Business party from Invoice summary.";
                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 6, TableAction.Click);
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).Enabled.ToString());
                
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 6, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).Enabled.ToString());
                
                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "20.00");
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Verify the Total amount updated when each fee is assoicted to the invoice to party";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 1, TableAction.Click);
                Support.AreEqual("4.98", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 2, TableAction.GetText).Message.Trim());
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.Off);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                Support.AreEqual("34.98", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 3, TableAction.GetText).Message.Trim());

                Reports.TestStep = "click on fee transfer in active disbursement summary";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent("Overdraft Confirmation"))
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    
                }
                else
                {
                    Reports.TestStep = "Enter password confimation details dialog info.";
                    FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                    FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                    FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                    if (FastDriver.PasswordConfirmationDlg.LossPassword.IsDisplayed())
                        FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                    Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                
                }

                Reports.TestStep = "Click on Cancel on ChangeFileStatusDlg.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Cancel on Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Verify in invoice screen if it allows the user to Finalise the invoice";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 1, TableAction.Click);

                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.FAClick();
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage().Contains("Issued Fee Transfer").ToString());

                Reports.TestStep = "Create File";
                CreateFile();

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "20.00");
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Add  more payees and associate fee to each of the payee";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem("Lease");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText("Lease 1 for HUD Testing Name 1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(4, "Lease 1 for HUD Testing Name 1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem("Lease");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText("Lease 3 for HUD Testing Name 1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(4, "Lease 3 for HUD Testing Name 1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem("Lease");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText("Lease 2 for HUD Testing Name 1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(4, "Lease 2 for HUD Testing Name 1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad(); 
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "20.00");

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "20.00");

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-2");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-2", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-2", 7, TableAction.SetText, "20.00");

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "20.00");

          
                Reports.TestStep = "Change the status of each payee to UNINVOICED, PRELIM, ESTIMATED, FINAL";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 8, TableAction.On);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 8, TableAction.On);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.Deliver.FAClick();

                #region Deliver the invoice

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForDialogScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow();
                FastDriver.InvoiceFees.WaitForScreenToLoad();

                #endregion

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.Estimate.FAClick();

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Deselect the fees and verify in Invoice history ";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.Off);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 8, TableAction.Off);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 8, TableAction.Off);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.Off);

                Reports.TestStep = "Verify in \"Invoice History\" screen";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTMTADJ", 4, TableAction.Click);
                FastDriver.InvoiceFees.History.FAClick();
                FastDriver.InvoiceHistory.SwitchToContentFrame();

                Support.AreEqual("Adjusted", FastDriver.InvoiceHistory.SummaryTable.PerformTableAction(2, "-30.00", 3, TableAction.GetText).Message.Trim());
                #endregion
                
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Cancel an Invoice/FINAL & UNINVOICED.")]
        public void FMUC0022_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF3: Cancel an Invoice/FINAL & UNINVOICED.";
         

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.New.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("247");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "247", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.Estimate.FAClick();
                #endregion

                #region Add Fees and Verify the IE message and click on OK button.
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner"); 
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "40.00");
                FastDriver.BottomFrame.Done();

                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region  Create an invoice/Select Final option
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);
                FastDriver.InvoiceFees.Final.FAClick();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.Off);

                #endregion
                         
                Reports.TestStep = "Cancel an Invoice/Final.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINALADJ", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.TestStep = "Verify the IE message and click on OK button.";
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage().Contains("Do you wish to cancel invoice").ToString());
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Verify the fees are not associated with invoice party after cancelling the invoice";
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).Selected.ToString());

                Reports.TestStep = "Verify the invoice history after cancelling the invoice";
                FastDriver.InvoiceFees.History.FAClick();
                FastDriver.InvoiceHistory.SwitchToContentFrame();
                Support.AreEqual("-50.00", FastDriver.InvoiceHistory.SummaryTable.PerformTableAction(3, "Canceled", 2, TableAction.GetText).Message.Trim());

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 1, TableAction.Click);

                Reports.TestStep = "Cancel an Invoice/Uninvoiced.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Cancel an Invoice/Final.";
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Estimate.Enabled.ToString());

                Reports.TestStep = "Amount should be added to Not Invoiced amount  - after cancellation";
                Support.AreEqual("Invoice Fee List  - Not Invoiced $: 50.00", FastDriver.InvoiceFees.InvoiceFeeList.Text.Trim());

                Reports.TestStep = "Create a GAB with No Address  and verify - Estimate / Final button should not be enabled";

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();
                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem("Lease");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsRadio.FAClick();

                Reports.TestStep = "Click on New GAB button.";
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();

                Reports.TestStep = "Add a Contact.";
                FastDriver.GABEntryRequestDlg.BuyerSellerType.FASelectItem("Business Entity");
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem("Lease");
                FastDriver.GABEntryRequestDlg.Name1.FASetText("TestLease");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "TestLease", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Estimate.Enabled.ToString());


                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry").SwitchToContentFrame();

                Reports.TestStep = "Create File";
                CreateFile();

                Reports.TestStep = "Add a fee";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Select Business party from Invoice summary.";
                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 6, TableAction.Click);
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).Enabled.ToString());

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 6, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).Enabled.ToString());

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "20.00");
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Verify the Total amount updated when each fee is assoicted to the invoice to party";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 1, TableAction.Click);
                Support.AreEqual("4.98", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 2, TableAction.GetText).Message.Trim());
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.Off);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                Support.AreEqual("34.98", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 3, TableAction.GetText).Message.Trim());

                Reports.TestStep = "click on fee transfer in active disbursement summary";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent("Overdraft Confirmation"))
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                else
                {
                    Reports.TestStep = "Enter password confimation details dialog info.";
                    FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                    FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                    FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");
                    if (FastDriver.PasswordConfirmationDlg.LossPassword.IsDisplayed())
                        FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);
                    Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();

                }

                Reports.TestStep = "Click on Cancel on ChangeFileStatusDlg.";
                Playback.Wait(5000);
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Playback.Wait(5000);
                Reports.TestStep = "Click on Cancel on Print the checks.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Verify in invoice screen if it allows the user to Finalise the invoice";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 1, TableAction.Click);

                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.FAClick();
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage().Contains("Issued Fee Transfer").ToString());

                Reports.TestStep = "Create File";
                CreateFile();

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "20.00");
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Add  more payees and associate fee to each of the payee";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem("Lease");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText("Lease 1 for HUD Testing Name 1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(4, "Lease 1 for HUD Testing Name 1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem("Lease");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText("Lease 3 for HUD Testing Name 1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(4, "Lease 3 for HUD Testing Name 1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem("Lease");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText("Lease 2 for HUD Testing Name 1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(4, "Lease 2 for HUD Testing Name 1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "20.00");
                FastDriver.FileFees.WaitForScreenToLoad();

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "20.00");
                FastDriver.FileFees.WaitForScreenToLoad();

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-2");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-2", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-2", 7, TableAction.SetText, "20.00");
                Playback.Wait(5000);
                FastDriver.FileFees.WaitForScreenToLoad();

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "20.00");


                Reports.TestStep = "Change the status of each payee to UNINVOICED, PRELIM, ESTIMATED, FINAL";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 8, TableAction.On);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 8, TableAction.On);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.Deliver.FAClick();

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForDialogScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow();
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                #endregion

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.Estimate.FAClick();

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Deselect the fees and verify in Invoice history ";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.Off);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 8, TableAction.Off);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-2", 8, TableAction.Off);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.Off);

                Reports.TestStep = "Verify in \"Invoice History\" screen";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTMTADJ", 4, TableAction.Click);
                FastDriver.InvoiceFees.History.FAClick();
                FastDriver.InvoiceHistory.SwitchToContentFrame();

                Support.AreEqual("Adjusted", FastDriver.InvoiceHistory.SummaryTable.PerformTableAction(2, "-30.00", 3, TableAction.GetText).Message.Trim());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REGRESSION
        [TestMethod]
        [Description("Setting up for Estimated Invoice in Office Setup screen & Display Fee Total Recap/Display Invoice Charges/Prevent Split Fees from being Invoiced.")]
        public void FMUC0022_REG0001()
        {
            try
            {
                string RegionInUseCode = "STEST";
                string OfficeInUse_1_OfficeCode = "7878";

                Reports.TestDescription = "Setting up for Estimated Invoice in Office Setup screen & FM2280_FM2294_EWC7_FM9167_EWC4: Display Fee Total Recap/Display Invoice Charges/Prevent Split Fees from being Invoiced.";

                #region  Setting up for Estimated Invoice in Office Setup screen
                Reports.TestStep = "Setting up for Estimated Invoice in Office Setup screen";
                Reports.StatusUpdate("Setting up for Estimated Invoice in Office Setup screen", true);

                #region Login
                Reports.TestStep = "Admin Login";
                _ADMLOGIN();
                #endregion

                Reports.TestStep = "Setup for Estimated Invoice in Office Setup screen.";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>" + RegionInUseCode + ">Offices>" + OfficeInUse_1_OfficeCode).SwitchToContentFrame();
                Support.AreEqual(OfficeInUse_1_OfficeCode, FastDriver.OfficeSetupOffice.OfficeCode.Text.Trim());
                Support.AreEqual("Residential", FastDriver.OfficeSetupOffice.BusinessSegment.FAGetSelectedItem());
                FastDriver.OfficeSetupOffice.DateDown.FASetCheckbox(true);
                FastDriver.OfficeSetupOffice.EstimatedInvoiceActivity.FASetCheckbox(true);
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("7/12/2012");
                //Checkbox removed on 10.1
                // FastDriver.OfficeSetupOffice.AccountServicingProduct.FASetCheckbox(true);
                FastDriver.OfficeSetupOffice.SigningScreen.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region FM2280_FM2294_EWC7_FM9167_EWC4: Display Fee Total Recap/Display Invoice Charges/Prevent Split Fees from being Invoiced.
                Reports.TestStep = "FM2280_FM2294_EWC7_FM9167_EWC4: Display Fee Total Recap/Display Invoice Charges/Prevent Split Fees from being Invoiced.";
                Reports.StatusUpdate("FM2280_FM2294_EWC7_FM9167_EWC4: Display Fee Total Recap/Display Invoice Charges/Prevent Split Fees from being Invoiced.", true);


                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                Reports.TestStep = "Enter First fee in Title and escrow.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter a new payee.";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State").WaitForScreenToBeReady();


                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.OfficeAdressBook.FAClick();

                FastDriver.PayeeSearchDlg.FABFirstCheckBox.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Scissors button for First Fee.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToBeReady(FastDriver.SplitFeeDisbursements.Scissor1);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.Scissor1.FAClick();
                
                Reports.TestStep = "Enter Payee.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToBeReady(FastDriver.SplitFeeDisbursements.SplitPercentage);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.Payee.FASelectItem("BuyerName BuyerLastName");
                FastDriver.SplitFeeDisbursements.SplitPercentage.FASetText("10.00" + FAKeys.Tab);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.Click);

                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen();

                Reports.TestStep = "Validate Split Fees.";
                Support.AreEqual("$0.50", FastDriver.FileFees.SplitFeeAmt.Text.Trim());

                Reports.TestStep = "Validate split fees in Invoice fees screen.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.FeeSummarygrid.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.Click();

                Reports.TestStep = "User attempts to add a fee that is included in an issued Record/Tax check, do not allow that fee to be included in an invoice with status of Estimated/Estimated Adjusted, Final or Final Adjusted.";
                string AlertString = FastDriver.WebDriver.HandleDialogMessage();
                
                string ContainedText = "The selected fee (New Home Rate (Title Only)) cannot be added to the Estimated/Final Invoice; the fee is associated to one of the following:";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));
                
                ContainedText = "Issued Fee Transfer";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));
                
                ContainedText = "Pending/Issued Split Fee";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));
                
                ContainedText = "Pending/Issued Recording Tax Check";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));
                
                ContainedText = "Paid by Lender or Mortgage Broker";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "You must de-select the fee(s) before estimating or finalizing the invoice";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").SwitchToContentFrame();
                FastDriver.ServiceFee.New.FAClick();

                Reports.TestStep = "Select a payee from payee search";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.PayeeName_1.FASetCheckbox(true);

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ServiceFee.SwitchToContentFrame();

                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate split fees in Invoice fees screen.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.FeeSummarygrid.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.Click();

                Reports.TestStep = "User attempts to finalize an Invoice when Pend Service Fees exist.";
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Pending Service Fees exist. Do you wish to finalize the Invoice?");

                AlertString = FastDriver.WebDriver.HandleDialogMessage();

                ContainedText = "The selected fee (New Home Rate (Title Only)) cannot be added to the Estimated/Final Invoice; the fee is associated to one of the following:";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "Issued Fee Transfer";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "Pending/Issued Split Fee";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "Pending/Issued Recording Tax Check";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "Paid by Lender or Mortgage Broker";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "You must de-select the fee(s) before estimating or finalizing the invoice";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("Identify invoiced charge &&  Display Invoice To Summary List /Display Invoice To Detail.")]
        public void FMUC0022_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM2295: Identify invoiced charge && FM2297_FM2299: Display Invoice To Summary List /Display Invoice To Detail.";

                Reports.TestStep = "M2295: Identify invoiced charge";
                Reports.StatusUpdate("M2295: Identify invoiced charge", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);

                #endregion

                #region Navigate to fee entry screen.

                Reports.TestStep = "Add the second fee in Fee Entry.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "40.00");
            
                #endregion

                #region  Create an invoice/Select Final option
                Reports.TestStep = "Select Final option.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 8, TableAction.On);
                FastDriver.InvoiceFees.Final.FAClick();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 6, TableAction.Click);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);

                #endregion

                #region M2295: Identify invoiced charge
                Reports.TestStep = "FM2297_FM2299: Display Invoice To Summary List /Display Invoice To Detail.";
                Reports.StatusUpdate("FM2297_FM2299: Display Invoice To Summary List /Display Invoice To Detail.", true);

                Reports.TestStep = "Display Invoice To Summary List.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);

                Reports.TestStep = "Select Business party from Invoice summary.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("FM2306_FM4780_FM4781: Display Invoice Fee Li./FTD/ST/Group and Sort Invoice Charges/Update Invoice Charge Detail Display.")]
        public void FMUC0022_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM2306_FM4780_FM4781: Display Invoice Fee Li./FTD/ST/Group and Sort Invoice Charges/Update Invoice Charge Detail Display.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);

                #endregion

                Reports.TestStep = "Add the second fee in Fee Entry.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "40.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Add another fee in Fee entry.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner/Eagle Loan");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 4, TableAction.SetText, "20.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 7, TableAction.SetText, "30.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate Invoice Fee List.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
               
                Support.AreEqual("New Home Rate Eagle Owner", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, "50.00", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("New Home Rate Eagle Owner/Eagle Loan", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(4, "30.00", 1, TableAction.GetText).Message.Trim());

               Reports.TestStep = "Edit fee in Fee entry.";
               FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner/Eagle Loan");
               FastDriver.FileFees.WaitForScreenToLoad();
               FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 4, TableAction.SetText, "10.00");
               FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 7, TableAction.SetText, "25.00");

               Reports.TestStep = "Validate changes in Invoice Charge Display.";
               FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

               Support.AreEqual("New Home Rate Eagle Owner/Eagle Loan", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(4, "25.00", 1, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Select Invoice Items/Display Total Amount Not Invoiced.")]
        public void FMUC0022_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM2303_FM2300: Select Invoice Items/Display Total Amount Not Invoiced.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);

                #endregion

                Reports.TestStep = "Add the second fee in Fee Entry.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "40.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Add another fee in Fee entry.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner/Eagle Loan");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 4, TableAction.SetText, "20.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 7, TableAction.SetText, "30.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Edit fee in Fee entry.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 7, TableAction.SetText, "25.00");

                Reports.TestStep = "Select an Invoice.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 2, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummary1Fee.FASetCheckbox(true);
                Support.AreEqual("Invoice Fee List  - Not Invoiced $: 35.00", FastDriver.InvoiceFees.InvoiceFeeList.Text.Trim());
              
                Reports.TestStep = "Validate selected Invoice.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                Support.AreEqual("Midwest Financial Group", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 6, TableAction.GetText).Message.Trim());
              
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Deselect Invoice Items.")]
        public void FMUC0022_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM2304_FM2324_FM2351: Deselect Invoice Items.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);

                #endregion

                Reports.TestStep = "Add the second fee in Fee Entry.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "40.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Add another fee in Fee entry.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner/Eagle Loan");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 4, TableAction.SetText, "20.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 7, TableAction.SetText, "30.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Edit fee in Fee entry.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 7, TableAction.SetText, "25.00");

                Reports.TestStep = "Select an Invoice.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 2, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummary1Fee.FASetCheckbox(true);

                Reports.TestStep = "Deselect an Invoice.";

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.Off);
                Support.AreEqual("Invoice Fee List  - Not Invoiced $: 85.00", FastDriver.InvoiceFees.InvoiceFeeList.Text.Trim());

                Reports.TestStep = "Validate deselected Invoice.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).IsSelected().ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Calculate Invoice Total/Select Invoice Format/Redeliver Invoice.")]
        public void FMUC0022_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM2305_FM2344_FM2348: Calculate Invoice Total/Select Invoice Format/Redeliver Invoice.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                #endregion

                #region Edit and add Fees
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "40.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Add another fee in Fee entry.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner/Eagle Loan");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 4, TableAction.SetText, "20.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 7, TableAction.SetText, "30.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Edit fee in Fee entry.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 7, TableAction.SetText, "25.00");
                #endregion

                #region Cancel and Deliver an Invoice
                Reports.TestStep = "Select an Invoice.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).FASetCheckbox(false);

                Support.AreEqual("Invoice Fee List  - Not Invoiced $: 89.98", FastDriver.InvoiceFees.InvoiceFeeList.Text.Trim());

                Reports.TestStep = "Validate deselected Invoice.";
                Support.AreEqual("0.00", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 3, TableAction.GetText).Message.Trim());

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 2, TableAction.Click);
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.FeeSummary1Fee.Selected.ToString());
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).FASetCheckbox(true);
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Cancel an Invoice/Final.";
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Deliver Invoice.";
                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                Keyboard.SendKeys("^L");

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                
                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Life Cycle of Invoice Status/Cancel a finalized paid invoice/Prevent Finalization of Final or Canceled Invoice & Life Cycle of Invoice Status_1.")]
        public void FMUC0022_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM2358_FM4866_FM13282_FM5256: Life Cycle of Invoice Status/Cancel a finalized paid invoice/Prevent Finalization of Final or Canceled Invoice & FM2358_1_EWC1: Life Cycle of Invoice Status_1.";
                
                #region FM2358_FM4866_FM13282_FM5256: Life Cycle of Invoice Status/Cancel a finalized paid invoice/Prevent Finalization of Final or Canceled Invoice
                
                Reports.TestStep = "FM2358_FM4866_FM13282_FM5256: Life Cycle of Invoice Status/Cancel a finalized paid invoice/Prevent Finalization of Final or Canceled Invoice";
                Reports.StatusUpdate("FM2358_FM4866_FM13282_FM5256: Life Cycle of Invoice Status/Cancel a finalized paid invoice/Prevent Finalization of Final or Canceled Invoice", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Validate UNINVOICED to ESTIMATED if invoice amount is 0.00.
                Reports.TestStep = "Validate UNINVOICED to ESTIMATED if invoice amount is 0.00.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                Support.AreEqual("0.00", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("UNINVOICED", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Estimate.Enabled.ToString());
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                #endregion

                
                Reports.TestStep = "Select the first fee.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);

                Reports.TestStep = "Validate Invoice Total.";
                Support.AreEqual("4.98", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 3, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Deliver Invoice.";
                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                FastDriver.InvoiceFees.Deliver.FAClick();

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion
                
                Reports.TestStep = "Validate status PRELIM.";
                Support.AreEqual("PRELIM", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verification of invoice date with current system date";
                string InvoiceDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 8, TableAction.GetText).Message.Trim();
                string CurrentDate = DateTime.Now.ToUniversalTime().ToString("MM/dd/yyyy");

                if (!InvoiceDate.Contains(CurrentDate))
                {
                   CurrentDate = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/dd/yyyy");

                }
                Support.AreEqual(true.ToString(), InvoiceDate.Contains(CurrentDate).ToString());

                Reports.TestStep = "Set on FINAL after status PRELIM.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "PRELIM", 1, TableAction.Click);
                Keyboard.SendKeys("%F");

                Reports.TestStep = "Validate status FINAL.";
                Support.AreEqual("FINAL", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verification of invoice date with current system date";

                InvoiceDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 8, TableAction.GetText).Message.Trim();
                CurrentDate = DateTime.Now.ToUniversalTime().ToString("MM/dd/yyyy");

                if (!InvoiceDate.Contains(CurrentDate))
                {
                    CurrentDate = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/dd/yyyy");

                }
                Support.AreEqual(true.ToString(), InvoiceDate.Contains(CurrentDate).ToString());

                Reports.TestStep = "CANCEL on FINAL status.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 1, TableAction.Click);
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.StatusUpdate("Validate String", System.Text.RegularExpressions.Regex.IsMatch(FastDriver.WebDriver.HandleDialogMessage(), @"Do you wish to cancel invoice [0-9][0-9][0-9][0-9]?"));
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Validate FINAL to CANCELFINL.";
                Support.AreEqual("CANCELFINL", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 5, TableAction.GetText).Message.Trim());
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Verification of invoice date with current system date";
                InvoiceDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 8, TableAction.GetText).Message.Trim();
                CurrentDate = DateTime.Now.ToUniversalTime().ToString("MM/dd/yyyy");

                if (!InvoiceDate.Contains(CurrentDate))
                {
                    CurrentDate = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("MM/dd/yyyy");

                }
                Support.AreEqual(true.ToString(), InvoiceDate.Contains(CurrentDate).ToString());

                #endregion

                #region FM2358_1_EWC1: Life Cycle of Invoice Status_1
                Reports.TestStep = "FM2358_1_EWC1: Life Cycle of Invoice Status_1";
                Reports.StatusUpdate("FM2358_1_EWC1: Life Cycle of Invoice Status_1", true);

                Reports.TestStep = "Select an Invoice fees.";
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);

                Reports.TestStep = "Prevent Item Selection for Canceled Invoice.";

                if (FastDriver.WebDriver.WaitForAlertToExist(10))
                {

                    Support.AreEqual("Invoice has been cancelled. Please select another invoice.", FastDriver.WebDriver.HandleDialogMessage());
                }

                Reports.TestStep = "Deliver Invoice after traversing to Invoice fees.";
                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                FastDriver.InvoiceFees.Deliver.FAClick();

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Life Cycle of Invoice Status_2/Select Estimated Invoice/Change Status of an Invoice.")]
        public void FMUC0022_REG0010()
        {
            try
            {
                Reports.TestDescription = "FM2358_2_FM5037_FM9162  : Life Cycle of Invoice Status_2/Select Estimated Invoice/Change Status of an Invoice.";
                              
                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "2.99");
                #endregion
                
                Reports.TestStep = "Navigate to Invoice Fees for file event.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                Reports.TestStep = "Select an Invoice fees.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 2, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);

                Reports.TestStep = "Set on Estimate.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.Estimate.FAClick();

                Reports.TestStep = "Validate status ESTIMATED.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 2, TableAction.Click);

                string RequestDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 9, TableAction.GetText).Message.Trim();
                string InvoiceDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 8, TableAction.GetText).Message.Trim();

                Reports.StatusUpdate("Validate String: Export Request Date", System.Text.RegularExpressions.Regex.IsMatch(RequestDate, @"[0-9][0-9][/][0-9][0-9][/][0-9][0-9][0-9][0-9]"));
                Reports.StatusUpdate("Validate String: Inv Status Date", System.Text.RegularExpressions.Regex.IsMatch(InvoiceDate, @"[0-9][0-9][/][0-9][0-9][/][0-9][0-9][0-9][0-9]"));

                Reports.TestStep = "CANCEL on ESTIMATED status.";
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.TestStep = "Cancel Invoice fees.";
                Reports.StatusUpdate("Validate String: Cancel Dialog Message", System.Text.RegularExpressions.Regex.IsMatch(FastDriver.WebDriver.HandleDialogMessage(), @"Do you wish to cancel invoice [0-9][0-9][0-9][0-9]?"));
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Validate FINAL to CANCELESTI.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "CANCELESTI", 2, TableAction.Click);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Life Cycle of Invoice Status_3/Finalize an Estimated Invoice/Prevent Estimate of Estimated or Canceled Invoice.")]
        public void FMUC0022_REG0011()
        {
            try
            {
                Reports.TestDescription = "FM2358_3_FM5038_FM5257: Life Cycle of Invoice Status_3/Finalize an Estimated Invoice/Prevent Estimate of Estimated or Canceled Invoice.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                Reports.TestStep = "to verify if \"Estimate\", \"Final\", \"Cancel\" buttons are disabled when no charge is selected for invoice to party.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Cancel.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Estimate.Enabled.ToString());

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                #endregion

                Reports.TestStep = "Life Cycle of Invoice Status.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.Estimate.FAClick();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 2, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);


                Reports.TestStep = "Deliver Invoice after traversing to Invoice fees.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                FastDriver.InvoiceFees.Deliver.FAClick();

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion

                Reports.TestStep = "Validate status PRELIM.";
                Support.AreEqual("PRELIM", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Set on ESTIMATE after status PRELIM.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "PRELIM", 2, TableAction.Click);
                FastDriver.InvoiceFees.Estimate.FAClick();

                Reports.TestStep = "Validate status ESTIMATED.";
                Support.AreEqual("ESTIMATED", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 5, TableAction.GetText).Message.Trim());

                string RequestDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 9, TableAction.GetText).Message.Trim();
                string InvoiceDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 8, TableAction.GetText).Message.Trim();

                Reports.StatusUpdate("Validate String: Export Request Date", System.Text.RegularExpressions.Regex.IsMatch(RequestDate, @"[0-9][0-9][/][0-9][0-9][/][0-9][0-9][0-9][0-9]"));
                Reports.StatusUpdate("Validate String: Inv Status Date", System.Text.RegularExpressions.Regex.IsMatch(InvoiceDate, @"[0-9][0-9][/][0-9][0-9][/][0-9][0-9][0-9][0-9]"));

                Reports.TestStep = "Set on FINAL after status ESTIMATE.";
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Validate status FINAL.";
                Support.AreEqual("FINAL", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 5, TableAction.GetText).Message.Trim());

                RequestDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 9, TableAction.GetText).Message.Trim();
                InvoiceDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 8, TableAction.GetText).Message.Trim();

                Reports.StatusUpdate("Validate String: Export Request Date", System.Text.RegularExpressions.Regex.IsMatch(RequestDate, @"[0-9][0-9][/][0-9][0-9][/][0-9][0-9][0-9][0-9]"));
                Reports.StatusUpdate("Validate String: Inv Status Date", System.Text.RegularExpressions.Regex.IsMatch(InvoiceDate, @"[0-9][0-9][/][0-9][0-9][/][0-9][0-9][0-9][0-9]"));

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Use Invoiced Party's Address from Address Book.")]
        public void FMUC0022_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM2363: Use Invoiced Party's Address from Address Book.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion
                
                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                #endregion
                                
                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);

                FastDriver.AddressBookSearchDlg.GABDetails.FAClick();
                FastDriver.FileSideBusinessPartyOrganizationSetUpDlg.WaitForDialogToLoad(WinName: "GAB Details");

                Reports.TestStep = "Use Invoiced Party's Address from Address Book.";
                FastDriver.FileSideBusinessPartyOrganizationSetUpDlg.AddressesTable.PerformTableAction(1, "Business", 2, TableAction.Click);

                Reports.TestStep = "Use Invoiced Party's Address from Address Book.";
                FastDriver.FileSideBusinessPartyOrganizationSetUpDlg.AddressesTable.PerformTableAction(1, "Mailing", 2, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Set on Cancel.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                FastDriver.DialogBottomFrame.ClickCancel();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.WaitForScreenToLoad();

                #endregion

                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();
                Reports.TestStep = "Use Invoiced Party's Address from Address Book.";

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.EntityName.FASetText("abc");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                Playback.Wait(1000);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(4, "abc", 1, TableAction.On);

                FastDriver.AddressBookSearchDlg.GABDetails.FAClick();
                FastDriver.FileSideBusinessPartyOrganizationSetUpDlg.WaitForDialogToLoad(WinName: "GAB Details");

                Reports.TestStep = "Click on Done.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Set on Done.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Select new address from the summary.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "abc", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
              
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Add Comments/Print Comments on Invoice/Delete Comments.")]
        public void FMUC0022_REG0013()
        {
            try
            {
                Reports.TestDescription = "FM4622_FM4623_FM4624: Add Comments/Print Comments on Invoice/Delete Comments.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion
                
                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                #endregion

                Reports.TestStep = "Navigate to Invoice Fees for file event.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                Reports.TestStep = "Add Comments.";

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 7, TableAction.Click);

                FastDriver.InvoiceCommentDlg.WaitForDialogToLoad();
                FastDriver.InvoiceCommentDlg.Comment.FASetText("A new Comment!");
                FastDriver.InvoiceCommentDlg.Done.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Verification of comments added in UI side";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 7, TableAction.Click);

                FastDriver.InvoiceCommentDlg.WaitForDialogToLoad();
                Support.AreEqual("A new Comment!", FastDriver.InvoiceCommentDlg.Comment.FAGetValue());
                FastDriver.InvoiceCommentDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                #region Deliver the invoice
                Reports.TestStep = "Deliver Invoice after traversing to Invoice fees.";
                FastDriver.InvoiceFees.Format.FAClick();
                FastDriver.InvoiceFees.Deliver.FAClick();

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion

                Reports.TestStep = "Delete the Comments.";

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 7, TableAction.Click);

                FastDriver.InvoiceCommentDlg.WaitForDialogToLoad();
                FastDriver.InvoiceCommentDlg.Comment.Clear();
                FastDriver.InvoiceCommentDlg.Comment.FAClick();
                FastDriver.InvoiceCommentDlg.Done.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Verification of comments added in UI side";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 7, TableAction.Click);

                FastDriver.InvoiceCommentDlg.WaitForDialogToLoad();
                Support.AreEqual("", FastDriver.InvoiceCommentDlg.Comment.FAGetValue());
                FastDriver.InvoiceCommentDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Modify or Deselect a Fee on an Estimated Invoice/Invoice Statuses for Invoiced Fee Adjustments.")]
        public void FMUC0022_REG0014()
        {
            try
            {
                Reports.TestDescription = "FM5034_FM5036_FM5522: Modify or Deselect a Fee on an Estimated Invoice/Invoice Statuses for Invoiced Fee Adjustments.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                #endregion

                Reports.TestStep = "Set on Estimate.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.Estimate.FAClick();
                
                #region Deselect Finalized Fee
                Reports.TestStep = "Deselect Finalized Fee.";

                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.Off);
                Support.AreEqual("The fee has been invoiced.The change will result in an Invoice Adjustment. Remember to reprint the adjusted invoice and copy the Accounting Department. Continue?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion

                Reports.TestStep = "Validate EstimateADJ Status.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                Support.AreEqual("ESTMTADJ", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Click on History button.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.History.FAClick();

                FastDriver.InvoiceHistory.SwitchToContentFrame();
                Reports.TestStep = "Verify the status as Estimated Adjusted when a fee is removed.";

                Support.AreEqual("Adjusted", FastDriver.InvoiceHistory.SummaryTable.PerformTableAction(2, "-4.98", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual(AutoConfig.UserName.ToUpper(), FastDriver.InvoiceHistory.SummaryTable.PerformTableAction(2, "-4.98", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("ESTMTADJ", FastDriver.InvoiceHistory.CurrentStatus.Text.Trim());
                Support.AreEqual("0.00", FastDriver.InvoiceHistory.Total.Text.Trim());
                
                FastDriver.BottomFrame.Done();
                FastDriver.InvoiceFees.SwitchToContentFrame();
        
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Default File Business Source as First Invoice/Add Invoice To Parties/Add Multiple Instances of Same Party.")]
        public void FMUC0022_REG0015()
        {
            try
            {
                Reports.TestDescription = "FM5229_FM5230_FM5231: Default File Business Source as First Invoice/Add Invoice To Parties/Add Multiple Instances of Same Party.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Get verify the invoice to party is same as business source
                Reports.TestStep = "Get verify the invoice to party is same as business source";

                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").SwitchToContentFrame();
                string BuSourceName = FastDriver.FileHomepage.BusinessPartyNameField.Text.Trim() + " " + FastDriver.FileHomepage.BusinessPartyNameField2.Text.Trim();
                
                Reports.TestStep = "Navigate to Invoice Fees for file event.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                Reports.TestStep = "Validate Business source Invoice party.";
                Support.AreEqual(BuSourceName, FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 1, TableAction.GetText).Message.Trim());
                
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region associate fees to Midwest financial group
                Reports.TestStep = "associate fees to Midwest financial group";
                
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
               
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select same party from File Address Book to add in the Invoice fees";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select Business party from File Address book.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio);

                FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.FASetCheckbox(true);

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                #endregion

                Reports.TestStep = "Validate Business Party Addition.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "BuyerName BuyerLastName", 2, TableAction.Click);
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Estimate.Enabled.ToString());

                Reports.TestStep = "Verify the same fee which is added twice is reflecting in Invoice Fees screen.";

                Support.AreEqual("Midwest Financial Group", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message.ToString());
                Support.AreEqual("Midwest Financial Group", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(3, 1, TableAction.GetText).Message.ToString());

                Reports.TestStep = "Add a fee from  -Recording and TAX-  and verify in Invoice Fees screen";
             
                FastDriver.FileFees.AddFirstMatchingRecordingFee("Record Affidavit");
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Affidavit", 4, TableAction.SetText, "5.00");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Affidavit", 5, TableAction.SetText, "10.00");

                FastDriver.FileFees.AddFirstMatchingRecordingFee("Record Assignment");
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Assignment", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Assignment", 5, TableAction.SetText, "20.00");

                Reports.TestStep = "Validate added recording fees in Invoice Fees screen";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "Record Affidavit", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "Record Assignment", 2, TableAction.Click);
                Support.AreEqual("15.00", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "Record Affidavit", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("30.00", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "Record Assignment", 2, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Deselect Invoiced Fee or Remove Charge Amounts/Change Status Automatically/Deliver Adjusted Invoices/Adjust a finalized paid invoice.")]
        public void FMUC0022_REG0016()
        {
            try
            {
                Reports.TestDescription = "FM5242_FM5244_FM5246_FM13283: Deselect Invoiced Fee or Remove Charge Amounts/Change Status Automatically/Deliver Adjusted Invoices/Adjust a finalized paid invoice.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion
                
                #region Enter First fee in Title and escrow.
                Reports.TestStep = "Enter First fee in Title and escrow.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");

                #endregion
                
                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Add a fee in Fee Entry
                Reports.TestStep = "Add a fee in Fee Entry.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "40.00");

                #endregion
                               
                #region Set Final and Estimate
                Reports.TestStep = "Set on FINAL.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.Final.FAClick();

                DateTime ExportDateBefore = Convert.ToDateTime(FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 9, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Set on ESTIMATE after status UNINVOICED.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.Click);
                FastDriver.InvoiceFees.Estimate.FAClick();
               
                string CurrentDate = DateTime.Now.ToUniversalTime().ToString("MM/dd/yyyy");
                string InvDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 8, TableAction.GetText).Message.Trim();
                Reports.StatusUpdate("Expected value:" + InvDate, true);
                Support.AreEqual(true.ToString(), InvDate.Contains(CurrentDate).ToString());  
      
                #endregion

                Reports.TestStep = "Select Finalized Fee and Remove buyer and seller charges and verify in invoice fees screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).Clear();
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                if (FastDriver.WebDriver.WaitForAlertToExist(10))
                {
                    Support.AreEqual("Fee amount cannot be decreased/increased as it will cause an out of balance Invoice. Cancel the finalized invoice to proceed with the changes.", FastDriver.WebDriver.HandleDialogMessage());
                }
                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).Clear(); 
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                if (FastDriver.WebDriver.WaitForAlertToExist(10))
                {
                    Support.AreEqual("Fee amount cannot be decreased/increased as it will cause an out of balance Invoice. Cancel the finalized invoice to proceed with the changes.", FastDriver.WebDriver.HandleDialogMessage());
                } 
                FastDriver.FileFees.WaitForFeeScreen();

                Reports.TestStep = "Validate that the fee removed should NOT be present in INVOICE FEES screen.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();

                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.InvoicetosummaryTable.Text.Contains("New Home Rate (Title Only)").ToString());

                CurrentDate = DateTime.Now.ToUniversalTime().ToString("MM/dd/yyyy");
                InvDate = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 8, TableAction.GetText).Message.Trim();
                Reports.StatusUpdate("Expected value:" + InvDate, true);
                Support.AreEqual(true.ToString(), InvDate.Contains(CurrentDate).ToString());

                Reports.TestStep = "Deselect Finalized Fee.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.Off);

                Reports.TestStep = "Edit File fees.";
                Support.AreEqual("This fee is associated to an invoice that has been finalized. Cancel the finalized invoice to proceed with the changes.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Deselect Estimated Fee.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 1, TableAction.Off);
                Support.AreEqual("The fee has been invoiced.The change will result in an Invoice Adjustment. Remember to reprint the adjusted invoice and copy the Accounting Department. Continue?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Validate Final Status.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                Support.AreEqual("FINAL", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 5, TableAction.GetText).Message.Trim());


                CurrentDate = DateTime.Now.ToUniversalTime().ToString("MM/dd/yyyy");
                string ExportDateAfter = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 9, TableAction.GetText).Message.Trim();

                DateTime ExportDateAfterTime = Convert.ToDateTime(ExportDateAfter);

                int diff = ExportDateAfterTime.CompareTo(ExportDateBefore);

                if (diff > 0)
                    Reports.StatusUpdate("Export request date updated", true);
                else
                    Reports.StatusUpdate("Export request date NOT updated", true);

                Reports.TestStep = "Validate EstimateADJ Status.";
                Support.AreEqual("ESTMTADJ", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 5, TableAction.GetText).Message);

                Reports.TestStep = "Deliver Invoice after FINAL status.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 1, TableAction.Click);
                FastDriver.InvoiceFees.Format.FAClick();
                FastDriver.InvoiceFees.Deliver.FAClick();
                
                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion

                Reports.TestStep = "Deliver Invoice after ESTMTADJ status.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTMTADJ", 1, TableAction.Click);
                FastDriver.InvoiceFees.Format.FAClick();
                FastDriver.InvoiceFees.Deliver.FAClick();

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion

                Reports.TestStep = "Validate Hot keys for History.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.Click();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 5, TableAction.Click);
                Keyboard.SendKeys("%H");

                Reports.TestStep = "Verify the status as Estimated Adjusted when a fee is removed.";
                FastDriver.InvoiceHistory.SwitchToContentFrame();
                Support.AreEqual(AutoConfig.UserName.ToUpper(), FastDriver.InvoiceHistory.SummaryTable.PerformTableAction(2, "-50.00", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("ESTMTADJ", FastDriver.InvoiceHistory.CurrentStatus.Text.Trim());
                Support.AreEqual(true.ToString(), FastDriver.InvoiceHistory.FirstEstimated.Text.Contains(DateTime.Now.ToDateString()).ToString());
                FastDriver.BottomFrame.Done();
                FastDriver.InvoiceFees.SwitchToContentFrame();


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Remove Fees from Canceled Invoice/Deliver Canceled Invoices/Prevent Item Selection for Canceled Invoice & Prevent Status Change for Zero Invoice/Prevent Deletion of Invoice With Fees.")]
        public void FMUC0022_REG0017()
        {
            try
            {
                Reports.TestDescription = "FM5247_FM5248_FM5255_EWC2_EWC3: Remove Fees from Canceled Invoice/Deliver Canceled Invoices/Prevent Item Selection for Canceled Invoice & FM5258_FM5259: Prevent Status Change for Zero Invoice/Prevent Deletion of Invoice With Fees.";

                #region FM5247_FM5248_FM5255_EWC2_EWC3: Remove Fees from Canceled Invoice/Deliver Canceled Invoices/Prevent Item Selection for Canceled Invoice
                Reports.TestStep = "FM5247_FM5248_FM5255_EWC2_EWC3: Remove Fees from Canceled Invoice/Deliver Canceled Invoices/Prevent Item Selection for Canceled Invoice";
                Reports.StatusUpdate("FM5247_FM5248_FM5255_EWC2_EWC3: Remove Fees from Canceled Invoice/Deliver Canceled Invoices/Prevent Item Selection for Canceled Invoice", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Enter First fee in Title and escrow.
                Reports.TestStep = "Enter First fee in Title and escrow.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");

                #endregion

                #region Click on CANCEL
                Reports.TestStep = "Click on CANCEL.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.Cancel.FAClick();
                
                Support.AreEqual("Do you wish to cancel invoice 0?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Validate Invoice Total.";
                Support.AreEqual("0.00", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 3, TableAction.GetText).Message.Trim());
                                
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                Support.AreEqual("Invoice Fee List  - Not Invoiced $: 0.00", FastDriver.InvoiceFees.InvoiceFeeList.Text.Trim());
                              
                #endregion

                #region Add a fee in Fee Entry
                Reports.TestStep = "Add a fee in Fee Entry.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "40.00");

                #endregion

                #region Create an invoice/Click New.
                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("248");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "248", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                Reports.TestStep = "Set on ESTIMATE after status UNINVOICED.";
                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);
                FastDriver.InvoiceFees.Estimate.FAClick();

                Reports.TestStep = "CANCEL on ESTIMATED status.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 2, TableAction.Click);
                Keyboard.SendKeys("%C");

                Reports.TestStep = "Cancel Invoice fees.";
                Reports.StatusUpdate("Validate String", System.Text.RegularExpressions.Regex.IsMatch(FastDriver.WebDriver.HandleDialogMessage(), @"Do you wish to cancel invoice [0-9][0-9][0-9][0-9]?"));

                FastDriver.InvoiceFees.SwitchToContentFrame();
                Reports.TestStep = "Click on History button.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "CANCELESTI", 2, TableAction.Click);

                FastDriver.InvoiceFees.History.FAClick();
                FastDriver.InvoiceHistory.SwitchToContentFrame();
                Support.AreEqual("-50.00", FastDriver.InvoiceHistory.SummaryTable.PerformTableAction(3, "Canceled", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(AutoConfig.UserName.ToUpper(), FastDriver.InvoiceHistory.SummaryTable.PerformTableAction(3, "Canceled", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("CANCELESTI", FastDriver.InvoiceHistory.CurrentStatus.Text.Trim());
                Support.AreEqual(true.ToString(), FastDriver.InvoiceHistory.FirstEstimated.Text.Contains(DateTime.Now.ToDateString()).ToString());
                Support.AreEqual("0.00", FastDriver.InvoiceHistory.Total.Text.Trim());
                FastDriver.BottomFrame.Done();

                FastDriver.InvoiceFees.SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "CANCELESTI", 2, TableAction.Click);

                FastDriver.InvoiceFees.Format.FAClick();
                FastDriver.InvoiceFees.Deliver.FAClick();

                #region Deliver the invoice
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion

                Reports.TestStep = "CANCEL the CANCELESTMTD.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "CANCELESTI", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);

                Reports.TestStep = "Prevent Item Selection for Canceled Invoice.";
                Support.AreEqual("Invoice has been cancelled. Please select another invoice.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.InvoiceFees.SwitchToContentFrame();

                #endregion

                #region FM5258_FM5259: Prevent Status Change for Zero Invoice/Prevent Deletion of Invoice With Fees.
                Reports.TestStep = "FM5258_FM5259: Prevent Status Change for Zero Invoice/Prevent Deletion of Invoice With Fees.";
                Reports.StatusUpdate("FM5258_FM5259: Prevent Status Change for Zero Invoice/Prevent Deletion of Invoice With Fees.", true);

                Reports.TestStep = "Create an invoice/Click New.";
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.New.FAClick();

                Reports.TestStep = "Select third party from File Address Book to add in the Invoice summary.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable);
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);

                FastDriver.AddressBookSearchDlg.IDCode.FASetText("HUDASLNDR1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "HUDASLNDR1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Prevent Deletion of Invoice With Fees.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Assumption Lender 1 for HUD Test Name 1 Assumption Lender 1 for HUD Test Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.On);
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.Remove.Enabled.ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("FD: Field Definition of Invoice Total.")]
        public void FMUC0022_REG0019()
        {
            try
            {
                Reports.TestDescription = "FD: Field Definition of Invoice Total.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add fee for field definition in Invoice fees
                Reports.TestStep = "Add fee for field definition in Invoice fees.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner/Eagle Loan");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 4, TableAction.SetText, "12345678901.29");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/Eagle Loan", 7, TableAction.SetText, "123456789.00");

                #endregion

                #region Validate Field definition for Invoice Total.
                Reports.TestStep = "Validate Field definition for Invoice Total.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                
                Support.AreEqual("12,469,135,690.29", FastDriver.InvoiceFees.InvoiceTotal.Text.Trim());
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Format.GetParent().Text.Contains("Buyer/Seller/Lender Format").ToString());

                #endregion

             

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Field Definition of Invoice Comment/Retain association to previous owning office.")]
        public void FMUC0022_REG0020()
        {
            try
            {
                Reports.TestDescription = "D1_FM7635: Field Definition of Invoice Comment/Retain association to previous owning office.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                #endregion

                #region Set on FINAL status.
                Reports.TestStep = "Set on FINAL status.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.FAClick();

                #endregion

                Reports.TestStep = "Add Comments.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 7, TableAction.Click);

                Reports.TestStep = "Validate Invoice comments field with lower boundary.";

                FastDriver.InvoiceCommentDlg.WaitForDialogToLoad();
                FastDriver.InvoiceCommentDlg.Comment.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRST");
                FastDriver.InvoiceCommentDlg.Done.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Verification of comments added in UI side";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 7, TableAction.Click);

                Reports.TestStep = "Validate Invoice comments field with exact value and Click on Done Button.";

                FastDriver.InvoiceCommentDlg.WaitForDialogToLoad();
                FastDriver.InvoiceCommentDlg.Comment.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTU");
                FastDriver.InvoiceCommentDlg.Done.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();
                
                Reports.TestStep = "Add Comments.";

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 7, TableAction.Click);

                Reports.TestStep = "Validate Invoice comments field with upper boundary.";

                FastDriver.InvoiceCommentDlg.WaitForDialogToLoad();
                FastDriver.InvoiceCommentDlg.Comment.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUV");
                FastDriver.InvoiceCommentDlg.Comment.FAClick();
                FastDriver.InvoiceCommentDlg.Done.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InvoiceFees.SwitchToContentFrame();
     
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").SwitchToContentFrame();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.SwitchToContentFrame();

                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");

                FastDriver.BottomFrame.Save();
                FastDriver.DialogBottomFrame.ClickYes();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SwitchToContentFrame();

                Reports.TestStep = "Verify error message when invoice is finalized.";
                Support.AreEqual(true.ToString(), FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.Text.Contains("Service File: You cannot Change the Owning Office or Remove a service type when the file contains invoices in statuses Estimated, Estimated Adjusted, Final and Final Adjusted.").ToString());

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Reduce Pending Fee Transfers Amount.")]
        public void FMUC0022_REG0021()
        {
            try
            {
                Reports.TestDescription = "FM9163: Reduce Pending Fee Transfers Amount.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");

                Reports.TestStep = "Enter Second fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Owner");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "30.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "40.00");


                #endregion

                #region Verify pending fee transfer.
                Reports.TestStep = "Verify pending fee transfer.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();

                Support.AreEqual("$74.98", FastDriver.FileFees.TotalFees.Text.Trim());

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Trim().Contains("74.98").ToString());

                #endregion

                Reports.TestStep = "Deselect the second fee and click on FINAL";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 2, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Owner", 8, TableAction.Off);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);

                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "verification of invoice number in Invoice fee list and summary";
      //          Support.AreEqual(true.ToString(),");

                Reports.TestStep = "Verify pending fee transfer in active disbursement summary";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("70.00").ToString());
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Fees with Payment Method of POC for both Buyer and Seller.")]
        public void FMUC0022_REG0022()
        {
            try
            {
                Reports.TestDescription = "FM9166_FD: Fees with Payment Method of POC for both Buyer and Seller.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "12.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "12.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 3, TableAction.Click);


                Reports.TestStep = "Verify the fields in Payment details dialog.";

                FastDriver.PaymentDetails.WaitForScreenToLoad();
                if (FileType == FormType.CD)
                {

                    Support.AreEqual("$12.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                    Support.AreEqual("$12.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                    Support.AreEqual("$12.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                    Support.AreEqual("$12.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                }
                else
                {
                    Support.AreEqual("$12.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                    Support.AreEqual("$12.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                    Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.IsEnabled().ToString());
                    Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaymentMethod.IsEnabled().ToString());

                    Reports.TestStep = "Select POC payment method.";
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("POC");

                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Add fees after select payment method.";

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "5.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.00");

                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("Eagle Owners Policy");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Eagle Owners Policy", 4, TableAction.SetText, "10.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Eagle Owners Policy", 7, TableAction.SetText, "20.00" + FAKeys.Tab);
                var totalCharge = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Eagle Owners Policy", 10, TableAction.GetInputValue).Message;
                #endregion

                Reports.TestStep = "Verify in Invoice Fees screen whether the fee added is displayed.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, totalCharge, 1, TableAction.Click);

                Reports.TestStep = "Navigate to Split Fee disbursements screen and Split the fee";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State").SwitchToContentFrame();

                FastDriver.SplitFeeDisbursements.New.FAClick();
                Reports.TestStep = "Select File address book radio button from Payee Search Dialog.";

                FastDriver.PayeeSearchDlg.WaitForScreenToLoad(element: FastDriver.PayeeSearchDlg.OfficeAdressBook);
                FastDriver.PayeeSearchDlg.OfficeAdressBook.FAClick();

                FastDriver.PayeeSearchDlg.FABFirstCheckBox.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Scissors button for First Fee.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToBeReady(FastDriver.SplitFeeDisbursements.Scissor1);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.Scissor1.FAClick();
              

                Reports.TestStep = "Enter Payee.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToBeReady(FastDriver.SplitFeeDisbursements.Payee);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.Payee.FASelectItemBySendingKeys("BuyerName BuyerLastName");
                FastDriver.SplitFeeDisbursements.SplitPercentage.FASetText("10.00" + FAKeys.Tab);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.Click);


                Reports.TestStep = "Validate Split Fees.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToBeReady(FastDriver.SplitFeeDisbursements.Scissor1);
                Support.AreEqual("3.00", FastDriver.SplitFeeDisbursements.SplitAmount.FAGetValue());

                FastDriver.BottomFrame.Done();
           
                #region Deliver the invoice in UNINVOICED STATUS
                Reports.TestDescription = "deliver the invoice in UNINVOICED STATUS";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 1, TableAction.Click);
                
                Keyboard.SendKeys("^L");

             
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();

                #endregion

                Reports.TestDescription = "deliver the invoice in ESTIMATED STATUS";
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "Eagle Owners Policy", 8, TableAction.Off);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 1, TableAction.Click);

                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Estimate.FAClick();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 1, TableAction.Click);
                Keyboard.SendKeys("^L");

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();

                Reports.TestStep = "Set on FINAL.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, totalCharge, 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.FAClick();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 1, TableAction.Click);
                Keyboard.SendKeys("^L");

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Allow Unlimited Adjustments for Estimated Invoice.")]
        public void FMUC0022_REG0023()
        {
            try
            {
                Reports.TestDescription = "FM5039: Allow Unlimited Adjustments for Estimated Invoice.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");

                #endregion

                Reports.TestStep = "Set on ESTIMATE after status UNINVOICED.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", 1, TableAction.Click);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);
                FastDriver.InvoiceFees.Estimate.FAClick();
                
                Reports.TestStep = "Deselect Finalized Fee.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.Off);

                Reports.TestStep = "Edit File fees.";
                FastDriver.WebDriver.WaitForAlertToExist(15);
                Support.AreEqual("The fee has been invoiced.The change will result in an Invoice Adjustment. Remember to reprint the adjusted invoice and copy the Accounting Department. Continue?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Validate 1st Amount in EstimateADJ.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTMTADJ", 1, TableAction.Click);

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                #endregion

                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);

                Reports.TestStep = "Validate 2nd Amount in EstimateADJ.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                Support.AreEqual("4.98", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Increasing the amount and verify the status.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);

                //This is a work around the perom table action method is throwing an exception if the website shows a pop up after its operation.
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText,"3.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SendKeys, FAKeys.Control + "a");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SendKeys, "3.00" + FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.FileFees.WaitForFeeScreen();
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText,"4.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SendKeys, FAKeys.Control + "a");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SendKeys, "4.00" + FAKeys.Tab);
              
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate  Amount in EstimateADJ.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                Support.AreEqual("7.00", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTMTADJ", 3, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Decrease the amount and verify the status.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).SendKeys(Keys.Control + "a");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).SendKeys("2.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).SendKeys(Keys.Control + "a");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).SendKeys("3.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate  Amount in EstimateADJ.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                Support.AreEqual("5.00", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTMTADJ", 3, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("User attempts to add an issued fee transfer, POC or split fees to an invoice which has one of the following statuses Estimated/ Estimated Adjusted or Final/ Final Adjusted.")]
        public void FMUC0022_REG0024()
        {
            try
            {
                Reports.TestDescription = "EWC5_EW6: User attempts to add an issued fee transfer, POC or split fees to an invoice which has one of the following statuses Estimated/ Estimated Adjusted or Final/ Final Adjusted.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");

                #endregion
                
                #region Add Fees
                Reports.TestStep = "Add the second fee in Fee Entry.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "2.99");
                #endregion

                Reports.TestStep = "Uncheck the fee";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.Off);

                Reports.TestStep = "Set on final button in Invoice screen.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Click on Fee Transfer Button After selection of Payee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent("Overdraft Confirmation"))
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                else
                {
                    Reports.TestStep = "Enter password confimation details dialog info.";
                    FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                    FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                    FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");
                    if (FastDriver.PasswordConfirmationDlg.LossPassword.IsDisplayed())
                        FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);
                    Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();

                }

                Reports.TestStep = "Click on Cancel on ChangeFileStatusDlg.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Click on Cancel on Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Check the Invoice list";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.On);

                Reports.TestStep = "Validate User attempts to add a fee that is included in an issued Recording/Tax check, do not allow that fee to be included in an invoice with status of Estimated/Estimated Adjusted, Final or Final Adjusted";
                string AlertString = FastDriver.WebDriver.HandleDialogMessage();

                string ContainedText = "The selected fee (New Home Rate (Title Only)) cannot be added to the Estimated/Final Invoice; the fee is associated to one of the following:";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "Issued Fee Transfer";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "Pending/Issued Split Fee";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "Pending/Issued Recording Tax Check";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                ContainedText = "Paid by Lender or Mortgage Broker";
                Reports.StatusUpdate("Verify::" + ContainedText, AlertString.Contains(ContainedText));

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Invoice Statuses for Invoiced Fee Adjustments.")]
        public void FMUC0022_REG0025()
        {
            try
            {
                Reports.TestDescription = "FM5522_1: Invoice Statuses for Invoiced Fee Adjustments.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");

                #endregion

                #region Add Fees
                Reports.TestStep = "Add the second fee in Fee Entry.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "2.99");
                #endregion

                Reports.TestStep = "Set on final button in Invoice screen.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Change fee";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).FASetText("12.01" + FAKeys.Tab, false);
               
                Reports.TestStep = "Click on Ok button.";
               Support.AreEqual("Fee amount cannot be decreased/increased as it will cause an out of balance Invoice. Cancel the finalized invoice to proceed with the changes.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).FASetText("24.02" + FAKeys.Tab,false);
                
                Reports.TestStep = "Click on Ok button.";
                Support.AreEqual("Fee amount cannot be decreased/increased as it will cause an out of balance Invoice. Cancel the finalized invoice to proceed with the changes.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Navigate to invoice fees screen and verify the status - FINAL after trying to change the fees associacted with the invoice, - Lock invoice once payment is applied (FACC, New Loan, TDS, Property Tax, FHP) User Story 760998:REQ0860173 ";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 5, TableAction.Click);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Deliver invoices with unselected remaining items")]
        public void FMUC0022_REG0026()
        {
            try
            {
                Reports.TestDescription = "FM2328: Deliver invoices with unselected remaining items.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                #region Add Fees
                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");

                #endregion

                #region Add Fees
                Reports.TestStep = "Add the second fee in Fee Entry.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate Eagle Lender Policy-1");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 7, TableAction.SetText, "2.99");
                #endregion

                Reports.TestStep = "Click on Final.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.Final.Enabled.ToString());
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Deselect File fees and validate Non invoice greater than 0.00.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();

                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate (Title Only)", 8, TableAction.Off);
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "New Home Rate Eagle Lender Policy-1", 8, TableAction.Off);

                Support.AreEqual("Invoice Fee List  - Not Invoiced $: 9.96", FastDriver.InvoiceFees.InvoiceFeeList.Text.Trim());

                Reports.TestStep = "Deliver Invoice in FINALADJ status.";

                Reports.TestStep = "Deliver Invoice.";
                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINALADJ", 3, TableAction.Click);
                FastDriver.InvoiceFees.Deliver.FAClick();

                #region Deliver the invoice
                Reports.TestStep = "Perform the Delivery.";

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.InvoiceFees.SwitchToContentFrame();
                #endregion

           

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        [TestMethod]
        [Description("Invoice - Enable Title Prem Adj check box on Invoice screen")]
        public void FMUC0022_REG0027()
        {
            try
            {

                #region Invoice - Enable Title Prem Adj check box on Invoice screen.

                Reports.TestDescription = "FM2328: Invoice - Enable Title Prem Adj check box on Invoice screen";

                Reports.TestStep = "Login to Fast IIS Application";
                _IISLOGIN();

                Reports.TestStep = "Create file with title Only.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();

                fileRequest.File.Services = RequestFactory.GetServices(isTO: true, isEO: false, isSEO: false);
                var response2 = FileService.CreateFile(fileRequest);
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to the Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees);

                Reports.TestStep = "Add Lender and Owner Policy";
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Addded Fees";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 4, TableAction.SetText, "10");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 7, TableAction.SetText, "20");

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 4, TableAction.SetText, "10");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 7, TableAction.SetText, "20");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Full Loan Premium Amount";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitlePolicyCalculationsforCD);
                FastDriver.FileFees.lenderAdjAmnt.FASetText("50");
                FastDriver.FileFees.LenderLoanEstimateAmount.FAClick();

                // Verify that Title Premium Adjustment Displayed
                FastDriver.FileFees.SPA.IsDisplayed();
                Support.AreEqual(true.ToString(), FastDriver.FileFees.SPA.Enabled.ToString());

                Reports.TestStep = "Navigate to the Invoice Fees";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.InvoiceFees.InvoiceFeeListTable);

                Reports.TestStep = "Verify the Disclose Simultaneous Policy amount Checkbox is Enabled and Unchecked";
                Support.AreEqual(true.ToString(), FastDriver.InvoiceFees.DiscloseSimultaneousPolicyamountCheckBox.Enabled.ToString());

                Reports.TestStep = "Navigate to the Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitlePolicyCalculationsforCD);

                Reports.TestStep = "Remove the amount in Title Premium Adjustment Displayed";
                FastDriver.FileFees.SPA.FASetText("0");
                FastDriver.FileFees.LenderLoanEstimateAmount.FAClick();

                Reports.TestStep = "Navigate to the Invoice Fees";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").SwitchToContentFrame();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.InvoiceFees.InvoiceFeeListTable);

                Reports.TestStep = "Verify the Disclose Simultaneous Policy amount Checkbox is Disabled and Unchecked";
                Support.AreEqual(false.ToString(), FastDriver.InvoiceFees.DiscloseSimultaneousPolicyamountCheckBox.Enabled.ToString());


                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }



        }



        [TestMethod]
        [Description("US 591333: Validate Removal of Account Servicing Setup in Office Setup screen, US 682074: REQ0850873 - Invoice Fees: Disclose Simultaneous Policy Display on screen, US 701730: Verify that the system shall display a CheckBox called Disclose Title Premium Adjustment Amount to the right of the Disclose Simultaneous Policy Amount CheckBox.")]
        public void FMUC0022_REG0028()
        {
            try
            {
                Reports.TestDescription = "US 591333: Validate Removal of Account Servicing Setup in Office Setup screen, US 682074: REQ0850873 - Invoice Fees: Disclose Simultaneous Policy Display on screen, US 701730: Verify that the system shall display a CheckBox called Disclose Title Premium Adjustment Amount to the right of the Disclose Simultaneous Policy Amount CheckBox.";

                #region Data Setup
                string RegionInUseCode = "STEST";
                string OfficeInUse_1_OfficeCode = "7878";
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion


                #region Login
                Reports.TestStep = "Admin Login";
                _ADMLOGIN();
                #endregion

                Reports.TestStep = "Navigate to office set up screen.";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>" + RegionInUseCode + ">Offices>" + OfficeInUse_1_OfficeCode).SwitchToContentFrame();

                Reports.TestStep = "Validate that Account Servicing Setup is removed from Integrate With External Systems section in Office Setuo.";
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                int IWESrows = FastDriver.OfficeSetupOffice.IntegratewithExternalSystems.GetRowCount();
                for (int i = 1; i <= IWESrows; i++)
                {
                    if (FastDriver.OfficeSetupOffice.IntegratewithExternalSystems.PerformTableAction(1, 1, TableAction.GetText).Message.ToString().Trim() == "Account Servicing Product")
                    {
                        Reports.StatusUpdate("Account Servicing Product is not removed from Integrate with External Systems section in Office Setup.", false);
                        break;
                    }
                    else
                    {
                        if (i == IWESrows)
                        {
                            Reports.StatusUpdate("Account Servicing Product is removed from Integrate with External Systems section in Office Setup.", true);
                        }
                    }
                }
                #region Fiel side Login
                Reports.TestStep = "File side Login";
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Validate that Account Servicing dropdown fields should be removed in new loan screen
                Reports.TestStep = "Navigate to New Loan screen.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Validate that Account Servicing dropdown fields should be removed in new loan screen.";
                if (FastDriver.NewLoan.LoanDetailsAccountServicing.IsDisplayed().ToString().Trim().ToLower() == "true")
                {
                    Reports.StatusUpdate("Account Servicing Product is not removed from Integrate with External Systems section in Office Setup.", false);
                }
                else
                {
                    Reports.StatusUpdate("Account Servicing Product is removed from Integrate with External Systems section in Office Setup.", true);
                }
                #endregion

                #region Verify that the system shall display a CheckBox called Disclose Title Premium Adjustment Amount to the right of the Disclose Simultaneous Policy Amount CheckBox.
                
                Reports.TestStep = "Navigate to Invoice Fee Screen.";
                FastDriver.InvoiceFees.Open();

                Reports.TestStep = "Validate REQ0850873 - Invoice Fees: Disclose Simultaneous Policy Display on screen";
                Support.AreEqual("Disclose Simultaneous Policy Amount", FastDriver.InvoiceFees.DiscloseSimultaneousPolicyAmountText.FAGetText().ToString().Trim(), true);

                if (AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Validate Title Premium Adjustment box on Invoice Fees screen and its location.";
                    Support.AreEqual("Disclose Title Premium Adjustment Amount", FastDriver.InvoiceFees.DiscloseTitlePremiumAdjustmentAmountText.FAGetText().ToString().Trim(), true);

                    string CheckBox1 = FastDriver.InvoiceFees.DiscloseSimultaneousPolicyamountCheckBox.FAGetLocation().X.ToString();
                    int CheckBox1Location = Convert.ToInt32(CheckBox1);
                    string CheckBox2 = FastDriver.InvoiceFees.DiscloseTitlePremiumAdjustmentAmountCheckBox.FAGetLocation().X.ToString();
                    int CheckBox2Location = Convert.ToInt32(CheckBox2);
                    if (CheckBox2Location > CheckBox1Location)
                    {
                        Reports.StatusUpdate("Disclose Title Premium Adjustment Amount CheckBox appears to the right of Disclose Simultaneous Policy amount CheckBox.", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Disclose Title Premium Adjustment Amount CheckBox does not appear to the right of Disclose Simultaneous Policy amount CheckBox.", false);
                    }
                }
                else
                {
                    Reports.StatusUpdate("No flow was included for HUD type files.", true);
                }
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("US 703448: REQ0860177 Direct- Select new invoice instead of top invoice.")]
        public void FMUC0022_REG0029()
        {
            try
            {
                Reports.TestDescription = "US 703448: REQ0860177 Direct- Select new invoice instead of top invoice.";

                #region Data Setup
                string NewInvoiceName = string.Empty;
                string FirstInvoiceName = string.Empty;
                string SellerInvoiceName = string.Empty;
                int HighlightedRowNum = 0;
                int FirstInvoiceRowNum = 0;
                int SellerInvoiceRowNum = 0;
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                #endregion

                #region Fiel side Login
                Reports.TestStep = "File side Login";
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Valdiate: Newly added Invoice name should be highlighted in the grid
                Reports.TestStep = "Navigate to Fee Entry Screen.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "50.00");
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "150.00");

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Buyer Charge", TableAction.SetText, "100.00");
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Seller Charge", TableAction.SetText, "200.00");

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItemBySendingKeys("alta");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 8, TableAction.SetText, "55.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add new invoice to file";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Seller", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Add another invoice to file";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Buyer", "Select", TableAction.On);
                string newGAB = FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Buyer", "Name", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dGridFABResults_0_FAFLabel1").Text.ToString();

                if (newGAB.Contains("/").ToString().Trim().ToLower() == "true")
                {
                    string[] InvoiceName = newGAB.Split('/');
                    NewInvoiceName = InvoiceName[0];
                }
                else
                    NewInvoiceName = newGAB;
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Save the highlighted and non highlighted Invoice names.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                int rows = FastDriver.InvoiceFees.InvoicetosummaryTable.GetRowCount();
                for (int i = 1; i <= rows; i++)
                {
                    string InvName = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dgridInvoiceSummary_" + (i - 1) + "_lblInvoiceName").Text.ToString();
                    if (InvName.Contains(NewInvoiceName).ToString().Trim().Trim().ToLower() == "true")
                    {
                        HighlightedRowNum = i;
                        break;
                    }
                    else
                    {
                        if (!(InvName.Contains("Seller").ToString().Trim().Trim().ToLower() == "true"))
                        {
                            FirstInvoiceName = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dgridInvoiceSummary_" + (i - 1) + "_lblInvoiceName").Text.ToString();
                            FirstInvoiceRowNum = i;
                        }
                        if (InvName.Contains("Seller").ToString().Trim().Trim().ToLower() == "true")
                        {
                            SellerInvoiceName = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dgridInvoiceSummary_" + (i - 1) + "_lblInvoiceName").Text.ToString();
                            SellerInvoiceRowNum = i;
                        }
                    }
                }


                Reports.TestStep = "Validate that Newly added Invoice name is highlighted in the grid.";
                FastDriver.InvoiceFees.ValidateHighlightedRows(NewInvoiceName);

                Reports.TestStep = "Navigate away from Invoice Fee screen, navigate back to Invoice Fee and validate First Invoice is highlighted.";
                FastDriver.FileHomepage.Open();
                FastDriver.InvoiceFees.Open();

                Reports.TestStep = "Validate that First Invoice name is highlighted in the grid.";
                FastDriver.InvoiceFees.ValidateHighlightedRows(FirstInvoiceName);

                Reports.TestStep = "Click one of the newly added inovices and validate that it is highlighted.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(SellerInvoiceRowNum, 1, TableAction.Click);
                FastDriver.InvoiceFees.ValidateHighlightedRows(SellerInvoiceName);

                Reports.TestStep = "Remove the newly added inovice and validate that first invoice is highlighted.";
                FastDriver.InvoiceFees.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.ValidateHighlightedRows(FirstInvoiceName);
                #endregion

                #region Verification of Invoice and the associated fees
                Reports.TestStep = "Add a Home Owner Association with a separate gab id.";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: "TestDesc", buyerCharge: 100, sellerCharge: 200);

                Reports.TestStep = "Deselect one of the fees from the invoice . i.e. New Home Rate (Title Only).";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.Off);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New Button on the Invoice Fees Screen, select a new GAB.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.GlobalAddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("HW1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("ID Code", "HW1", "Select", TableAction.On);
                string newGAB2Name = FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("ID Code", "HW1", "Name", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dgGAB_0_lName").Text.ToString();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate that Newly added Invoice name is highlighted in the grid.";
                // FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.ValidateHighlightedRows(newGAB2Name);

                Reports.TestStep = "Add the fee :-New Home Rate (Title Only)-:  to newly added GAB.";
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate away from Invoice Fee screen, return back and validate that first invoice is highlighted.";
                FastDriver.FileHomepage.Open();
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.ValidateHighlightedRows(FirstInvoiceName);

                Reports.TestStep = "Select each of the Invoice name one by one and validate that fees associated to respective invoice will be enabled for selection of the fees.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(FirstInvoiceRowNum, 1, TableAction.Click);
                //FastDriver.InvoiceFees.Invoicetosummary.
                Support.AreEqual("false", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).Enabled.ToString().Trim().ToLower(), true);

                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction("Invoice Name", "HW name 1 HW name 2", "Invoice Name", TableAction.Click);
                Support.AreEqual("true", FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"checkbox\"]")).Enabled.ToString().Trim().ToLower(), true);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("User Story 213023:Invoice - Include B/S Paid at Closing amounts in FAST Invoice.")]
        public void FMUC0022_REG0030()
        {
            try
            {
                Reports.TestDescription = "User Story 213023:Invoice - Include B/S Paid at Closing amounts in FAST Invoice.";

                #region Data Setup
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                #endregion

                #region Fiel side Login
                Reports.TestStep = "File side Login";
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                if (AutoConfig.UseCDFormType)
                {

                    #region
                    Reports.TestStep = "Add a non-facc fee.";
                    FastDriver.FileFees.Open();
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Sel", TableAction.On);
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Buyer Charge", TableAction.SetText, "50.00");
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Seller Charge", TableAction.SetText, "150.00");
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Det", TableAction.Click);

                    Reports.TestStep = "Click on PDD link for the selected fee, Enter Paid by borrower at closing and Paid by seller at closing.";
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("50");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("25");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("25");
                    if (FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled)
                        FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("25");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("25");
                    if (FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled)
                        FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 5);


                    Reports.TestStep = "Save the buyer charge and service tax.";
                    FastDriver.FileFees.Open();
                    string BC = FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Buyer Charge", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tFF_tF1_gT_0_tbc").FAGetValue().ToString().Trim();
                    string ST = FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Sales Tax", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tFF_tF1_gT_0_tbs").FAGetValue().ToString().Trim();
                    double BuyerCharge = Convert.ToDouble(BC);
                    double SalesTax = Convert.ToDouble(ST);

                    Reports.TestStep = "Navigate to Invoice Fee Screen and verify the Total Charge, Buyer Charge and Seller Charge.";
                    FastDriver.InvoiceFees.Open();
                    string InvoiceTotal = FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "Escrow Fee", 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dgridFeeSummary_0_lblTotalCharge").Text.ToString().Trim();
                    double TotalInvoice = Convert.ToDouble(InvoiceTotal);
                    if ((SalesTax + BuyerCharge) == TotalInvoice)
                    {
                        Reports.StatusUpdate("Total invoice charge is sum of charge and tax.", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Total invoice charge is not sum of charge and tax.", false);
                    }

                    string BuyerChargeInv = FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "Escrow Fee", 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dgridFeeSummary_0_lblBuyerWTOLenderCharge").Text.ToString().Trim();
                    double BuyerChargeInv2 = Convert.ToDouble(BuyerChargeInv);
                    if (BuyerChargeInv2 == 50.0)
                    {
                        Reports.StatusUpdate("Buyer charge is as entered in PDD.", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Buyer charge is not as entered in PDD.", false);
                    }

                    string SellerChargeInv = FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "Escrow Fee", 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dgridFeeSummary_0_lblSellerWTOLenderCharge").Text.ToString().Trim();
                    double SellerChargeInv2 = Convert.ToDouble(SellerChargeInv);
                    if (SellerChargeInv2 == 50.0)
                    {
                        Reports.StatusUpdate("Seller charge is as entered in PDD.", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Seller charge is not as entered in PDD.", false);
                    }

                    Reports.TestStep = "Click on PDD link for the selected fee, Enter payment method as Lender for paid by others(buyer and seller).";
                    FastDriver.FileFees.Open();
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Det", TableAction.Click);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("10");
                    if (FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled)
                        FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Lender");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("10");
                    if (FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled)
                        FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Lender");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

                    Reports.TestStep = "Navigate to Invoice Fee Screen and verify the Lender Charge.";
                    FastDriver.InvoiceFees.Open();
                    string LenderCharge = FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(1, "Escrow Fee", 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dgridFeeSummary_0_lblLenderCharge").Text.ToString().Trim();
                    double LenderCharge2 = Convert.ToDouble(LenderCharge);
                    if (LenderCharge2 == 20.0)
                    {
                        Reports.StatusUpdate("Lender charge is as entered in PDD.", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Lender charge is not as entered in PDD.", false);
                    }

                    #endregion
                }
                else
                {
                    Reports.StatusUpdate("No flow was included for HUD type files.", true);
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        

        
        #endregion
            
        #region PRIVATE METHODS

        private FormType CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                       
            return customizableFileRequest.formType;
        }

        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }
              
            
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}