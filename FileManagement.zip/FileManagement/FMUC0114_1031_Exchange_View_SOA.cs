﻿using FASTSelenium.Common;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace FileManagement
{
    [CodedUITest]
    public class FMUC0114_1031_Exchange_View_SOA : FASTHelpers
    {
        [TestMethod]
        [Description("Validate View Statement of the Account (SOA) for an authorized exchange user")]
        public void FMUC0114_REG0001()
        {
            try
            {
                Reports.TestDescription = "Validate View Statement of the Account (SOA) for an authorized exchange user";

                FAST_Login_IIS();
                FAST_OpenRegionOrOffice(12386);

                #region Create Exchange File
                Reports.TestStep = "Create Exchange File";
                OpenExchangeFileEntry();
                NewExchangeFileEntry();
                EnterExchangeFileEntryDetails();
                EnterExchangeFileEntryParties();
                EnterExchangeFileEntryRelinquished();
                CloseExchangeFileEntry();
                #endregion

                #region Add some deposits
                Reports.TestStep = "Add some deposits";
                ExchangeDeposit(amount: "2,000,000.00", typeFund: "Cash", representing: "Early Release");
                ExchangeDeposit(amount: "1,000,000.00", typeFund: "Credit Card", representing: "Earnest Money Deposit");
                ExchangeDeposit(amount: "500,000.00", typeFund: "Direct Deposit", representing: "Exchange Fees");
                ExchangeDeposit(amount: "250,000.00", typeFund: "Other", representing: "Loan Proceeds");
                ExchangeDeposit(amount: "125,000.00", typeFund: "Other", representing: "Miscellaneous Funds");
                #endregion

                #region Validate SOA data
                Reports.TestStep = "Validate SOA data";
                FastDriver.ViewStatementOfTheAccount.Open();
                //  View Statement of the Account
                Support.AreEqual("(1) John Doe", FastDriver.ViewStatementOfTheAccount.ExchangeTaxPayers.Text);
                Support.AreEqual("(1)1 Main St. , Santa Ana, CA 92707, USA", FastDriver.ViewStatementOfTheAccount.RelinquishedProperties.Text);
                Support.AreEqual("", FastDriver.ViewStatementOfTheAccount.Replacementsroperties.Text);
                //  Dates
                Support.AreEqual("", FastDriver.ViewStatementOfTheAccount.lbl45thDayDeadline.Text);
                Support.AreEqual("", FastDriver.ViewStatementOfTheAccount.lbl180thDayDeadline.Text);
                Support.AreEqual(DateTime.Now.ToPST().ToDateString(slash: true), FastDriver.ViewStatementOfTheAccount.lblActualIDDate.Text);
                Support.AreEqual("", FastDriver.ViewStatementOfTheAccount.lblClosedDate.Text);
                //  Detail Transactions
                var detailTransactions = FastDriver.ViewStatementOfTheAccount.DetailTransactions.Text;
                Support.Match(DateTime.Now.ToPST().ToDateString() + "\\s+\\$2,000,000\\.00\\s+\\$0\\.00", detailTransactions);
                Support.Match(DateTime.Now.ToPST().ToDateString() + "\\s+\\$1,000,000\\.00\\s+\\$0\\.00", detailTransactions);
                Support.Match(DateTime.Now.ToPST().ToDateString() + "\\s+\\$500,000\\.00\\s+\\$0\\.00", detailTransactions);
                Support.Match(DateTime.Now.ToPST().ToDateString() + "\\s+\\$250,000\\.00\\s+\\$0\\.00", detailTransactions);
                Support.Match(DateTime.Now.ToPST().ToDateString() + "\\s+\\$125,000\\.00\\s+\\$0\\.00", detailTransactions);
                Support.Match("Total of Receipts/Credits\\s+\\$3,875,000\\.00", detailTransactions);
                Support.Match("Total of Disbursements/Debits\\s+\\$0.00", detailTransactions);
                //
                Support.AreEqual("BALANCE AS OF June 08, 2016", FastDriver.ViewStatementOfTheAccount.lblCurrentBalance.Text);
                Support.AreEqual("$3,875,000.00", FastDriver.ViewStatementOfTheAccount.lblCurrentBalanceAmount.Text);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Deliver View Statement of the Account (SOA) for an authorized exchange user")]
        public void FMUC0114_REG0002()
        {
            try
            {
                Reports.TestDescription = "Deliver View Statement of the Account (SOA) for an authorized exchange user";

                FAST_Login_IIS();
                FAST_OpenRegionOrOffice(12386);

                #region Create Exchange File
                Reports.TestStep = "Create Exchange File";
                OpenExchangeFileEntry();
                NewExchangeFileEntry();
                EnterExchangeFileEntryDetails();
                EnterExchangeFileEntryParties();
                EnterExchangeFileEntryRelinquished();
                CloseExchangeFileEntry();
                #endregion

                #region Add some deposits
                Reports.TestStep = "Add some deposits";
                ExchangeDeposit(amount: "2,000,000.00", typeFund: "Cash", representing: "Early Release");
                #endregion

                #region Deliver SOA document
                Reports.TestStep = "Deliver SOA document";
                PerformDelivery(FADeliveryMethod.Print);
                PerformDelivery(FADeliveryMethod.Email);
                PerformDelivery(FADeliveryMethod.Fax);
                PerformDelivery(FADeliveryMethod.ImageDoc);
                PerformDelivery(FADeliveryMethod.Preview);
                //
                var pdfContent = Support.ReadPdfFile(Reports.DEPLOYDIR + "\\temp.pdf");
                var todaysDate = DateTime.UtcNow.ToPST().ToDateString(slash: true);
                Support.Match("2 First American Way", pdfContent);
                Support.Match("Santa Ana, CA 92707", pdfContent);
                Support.Match("\\(444\\)444-4444", pdfContent);
                Support.Match("STATEMENT OF ACCOUNT AS OF", pdfContent);
                Support.Match(todaysDate, pdfContent);
                Support.Match("EXCHANGE NO.: [0-9]+", pdfContent);
                Support.Match("EXCHANGOR: John Doe", pdfContent);
                Support.Match("RELINQUISHED PROPERTY: REPLACEMENT PROPERTY:", pdfContent);
                Support.Match("\\(1\\) 1 Main St\\. Santa Ana, CA 92707", pdfContent);
                Support.Match("45-Day Deadline: 180-Day Deadline:", pdfContent);
                Support.Match("Actual ID Date: " + todaysDate + " Close Date:", pdfContent);
                Support.Match("Date Description Credit Debit", pdfContent);
                Support.Match(todaysDate + " 2,000,000\\.00 0\\.00", pdfContent);
                Support.Match("Totals of Receipts/Credits 2,000,000\\.00", pdfContent);
                Support.Match("Totals of Disbursements/Debits 0\\.00", pdfContent);
                Support.Match("BALANCE AS OF " + todaysDate + " 2,000,000\\.00", pdfContent);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #region Create Exchange File
        private void OpenExchangeFileEntry()
        {
            FastDriver.ExchangeFileEntry.Open();
        }

        private void NewExchangeFileEntry()
        {
            FastDriver.BottomFrame.New();
            FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
        }

        private void CloseExchangeFileEntry()
        {
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        private void EnterExchangeFileEntryDetails(string TransactionType=null, string Office=null)
        {
            FastDriver.ExchangeFileEntry.DetailsTab.FAClick();
            FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
            //FastDriver.ExchangeFileEntry.Service.FASetCheckbox(true);
            //FastDriver.ExchangeFileEntry.BusinessSegment.FASelectItem("Exchange");
            FastDriver.ExchangeFileEntry.TransactionType.FASelectItem(TransactionType ?? "Delayed");
            FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItem(Office ?? "QA Automation Office Expresso PR: eSTEST off: 7880(12386)");
            FastDriver.ExchangeFileEntry.ActualIDDate.FASetText(DateTime.UtcNow.ToPST().ToDateString());
            FastDriver.ExchangeFileEntry.TaxPayerAddNew.FAClick();
            FastDriver.ExchangeFileEntry.TaxPayerType.FASelectItem("Individual");
            FastDriver.ExchangeFileEntry.TaxpyrIndividualName.FASetText("John");
            FastDriver.ExchangeFileEntry.TaxpyrIndividualLast.FASetText("Doe");
            FastDriver.ExchangeFileEntry.TaxpyrIndividualSSNTIN.FASetText("123456789");
            FastDriver.ExchangeFileEntry.TaxPayerAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.TaxPayerCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.TaxPayerState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.TaxPayerZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.TaxPayerCounty.FASetText("Orange");
            FastDriver.ExchangeFileEntry.TaxPayerBusPh.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.TaxPayerHomePh.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.TaxPayerCellFax.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.TaxPayerPager.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.TaxPayerEmail.FASetText("test@test.net");
        }

        private void EnterExchangeFileEntryParties(string ReferredByGABCode = "DIRECTEDBY", string CreditToGABCode = "CTESTDKEXU", string TaxPayerRepGABCode = "CTESTYMJCA", string CPAGABCode = "EXCHCPA", string AdvisorAttorneyGABCode = "ATNYTITCMP")
        {
            FastDriver.ExchangeFileEntry.PartiesTab.FAClick();
            FastDriver.ExchangeFileEntry.WaitForTabToLoad();
            FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode(ReferredByGABCode, CreditToGABCode, TaxPayerRepGABCode, CPAGABCode, AdvisorAttorneyGABCode);
        }

        private void EnterExchangeFileEntryRelinquished()
        {
            FastDriver.ExchangeFileEntry.RelinquishedTab.FAClick();
            FastDriver.ExchangeFileEntry.WaitForTabToLoad();
            FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Single Family Residence");
            FastDriver.ExchangeFileEntry.RelPropertyAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.RelPropertyCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.RelPropertyZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.RelPropertyCounty.FASelectItem("Orange");
            FastDriver.ExchangeFileEntry.EnterRelinquishedTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
            FastDriver.ExchangeFileEntry.RelBuyersAddNew.FAClick();
            FastDriver.ExchangeFileEntry.RelBuyersType.FASelectItem("Individual");
            FastDriver.ExchangeFileEntry.RelBuyersIndividualFirstName.FASetText("Jane");
            FastDriver.ExchangeFileEntry.RelBuyersIndividualLastName.FASetText("Doe");
            FastDriver.ExchangeFileEntry.RelBuyersIndividualSSNTIN.FASetText("123456789");
            FastDriver.ExchangeFileEntry.RelAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.RelBuyersCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.RelBuyersState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.RelBuyersZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.RelBuyersCounty.FASetText("Orange");
            FastDriver.ExchangeFileEntry.RelBuyersBusPhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.RelBuyersHomePhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.RelBuyersCellPhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.RelBuyersPager.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.RelBuyersEmail.FASetText("test@test.net");
        }

        private void EnterExchangeFileEntryReplacement()
        {
            FastDriver.ExchangeFileEntry.ReplacementTab.FAClick();
            FastDriver.ExchangeFileEntry.WaitForTabToLoad();
            FastDriver.ExchangeFileEntry.REPPropertyType.FASelectItem("Single Family Residence");
            FastDriver.ExchangeFileEntry.REPPropertyAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.REPPropertyCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.REPPropertyState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.REPPropertyZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.REPPropertyCounty.FASelectItem("Orange");
            FastDriver.ExchangeFileEntry.EnterReplacementTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
            FastDriver.ExchangeFileEntry.REPAddNew.FAClick();
            FastDriver.ExchangeFileEntry.REPSellersType.FASelectItem("Individual");
            FastDriver.ExchangeFileEntry.REPSellersIndividualFirstName.FASetText("Jane");
            FastDriver.ExchangeFileEntry.REPSellersIndividualLastName.FASetText("Doe");
            FastDriver.ExchangeFileEntry.REPSellerIndividualSSNTIN.FASetText("123456789");
            FastDriver.ExchangeFileEntry.REPAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.REPSellersCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.REPSellersState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.REPSellersZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.REPSellersCounty.FASetText("Orange");
            FastDriver.ExchangeFileEntry.REPSellersBusPhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.REPSellersHomePhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.REPSellersCellPhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.REPSellersPager.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.REPSellersEmail.FASetText("test@test.net");
        }

        private void EnterExchangeFileEntryEATAcquisition()
        {
            FastDriver.ExchangeFileEntry.EATAcquisitionTab.FAClick();
            FastDriver.ExchangeFileEntry.WaitForTabToLoad();
            FastDriver.ExchangeFileEntry.EATAcqPropertyType.FASelectItem("Single Family Residence");
            FastDriver.ExchangeFileEntry.EATAcqPropertyAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.EATAcqPropertyCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.EATAcqPropertyState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.EATAcqPropertyZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.EATAcqPropertyCounty.FASelectItem("Orange");
            FastDriver.ExchangeFileEntry.EnterEATAcquisitionTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
            FastDriver.ExchangeFileEntry.EATAcqSellersAddNew.FAClick();
            FastDriver.ExchangeFileEntry.EATAcqSellersType.FASelectItem("Individual");
            FastDriver.ExchangeFileEntry.EATAcqSellersIndividualFirstName.FASetText("Jane");
            FastDriver.ExchangeFileEntry.EATAcqSellersIndividualLastName.FASetText("Doe");
            FastDriver.ExchangeFileEntry.EATAcqSellersIndividualSSNTIN.FASetText("123456789");
            FastDriver.ExchangeFileEntry.EATAcqAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.EATAcqSellersCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.EATAcqSellersState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.EATAcqSellersZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.EATAcqSellersCounty.FASetText("Orange");
            FastDriver.ExchangeFileEntry.EATAcqSellersBusPhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.EATAcqSellersHomePhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.EATAcqSellersCellPhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.EATAcqSellersPager.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.EATAcqSellersEmail.FASetText("test@test.net");
        }

        private void EnterExchangeFileEntryEATDisposition()
        {
            FastDriver.ExchangeFileEntry.EATDispositionTab.FAClick();
            FastDriver.ExchangeFileEntry.WaitForTabToLoad();
            FastDriver.ExchangeFileEntry.EATDispPropertyType.FASelectItem("Single Family Residence");
            FastDriver.ExchangeFileEntry.EATDispPropertyAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.EATDispPropertyCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.EATDispPropertyState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.EATDispPropertyZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.EATDispPropertyCounty.FASelectItem("Orange");
            FastDriver.ExchangeFileEntry.EnterEATDispositionGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
            FastDriver.ExchangeFileEntry.EATDispSellersAddNew.FAClick();
            FastDriver.ExchangeFileEntry.EATDispSellersType.FASelectItem("Individual");
            FastDriver.ExchangeFileEntry.EATDispSellersIndividualFirstName.FASetText("Jane");
            FastDriver.ExchangeFileEntry.EATDispSellersIndividualLastName.FASetText("Doe");
            FastDriver.ExchangeFileEntry.EATDispSellersIndividualSSNTIN.FASetText("123456789");
            FastDriver.ExchangeFileEntry.EATDispAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.EATDispSellersCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.EATDispSellersState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.EATDispSellersZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.EATDispSellersCounty.FASetText("Orange");
            FastDriver.ExchangeFileEntry.EATDispSellersBusPhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.EATDispSellersHomePhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.EATDispSellersCellPhone.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.EATDispSellersPager.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.EATDispSellersEmail.FASetText("test@test.net");
        }

        private string ExchangeDeposit(string amount, string receivedFrom = "Buyer", string typeFund = "Cash", string representing = "Additional Closing Costs", string payorName = "", string descr = "")
        {
            #region Add Deposit in Escrow
            FastDriver.ExchangeDeposit.Open();
            FastDriver.ExchangeDeposit.Amount.FASetText(amount);
            FastDriver.ExchangeDeposit.IssueDte.FASetText(DateTime.Now.ToPST().ToDateString());
            FastDriver.ExchangeDeposit.ReceivedFrom.FASelectItemBySendingKeys(receivedFrom);
            FastDriver.ExchangeDeposit.TypeofFunds.FASelectItemBySendingKeys(typeFund);
            FastDriver.ExchangeDeposit.Representing.FASelectItemBySendingKeys(representing);
            FastDriver.ExchangeDeposit.Description.FASetText(descr);
            if (string.IsNullOrEmpty(payorName) == false)
                FastDriver.ExchangeDeposit.Payor.FASetText(payorName);
            FastDriver.BottomFrame.Save();
            FastDriver.WebDriver.WaitForAlertToExist(10);
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: false);
            FastDriver.ExchangeDeposit.SwitchToContentFrame();
            var receiptNo = FastDriver.ExchangeDeposit.ReceiptNo.FAGetAttribute("value");
            #endregion

            return receiptNo;
        }

        private void PerformDelivery(FADeliveryMethod deliveryMethod)
        {
            FastDriver.ViewStatementOfTheAccount.Open();
            FastDriver.Delivery.Perform(deliveryMethod);

            switch (deliveryMethod)
            {
                case FADeliveryMethod.Print:
                    FastDriver.PrintDlg.WaitForScreenToLoad();
                    FastDriver.PrintDlg.SendPrint();
                    break;
                case FADeliveryMethod.ImageDoc:
                    FastDriver.ImageDocDlg.WaitForScreenToLoad();
                    FastDriver.ImageDocDlg.Deliver();
                    break;
                case FADeliveryMethod.Fax:
                    FastDriver.FaxDlg.WaitForScreenToLoad();
                    FastDriver.FaxDlg.SendFax();
                    break;
                case FADeliveryMethod.Email:
                    FastDriver.EmailDlg.WaitForDialogToLoad();
                    FastDriver.EmailDlg.SendEmail();
                    break;
                case FADeliveryMethod.Preview:
                    Support.SavePDF(Reports.DEPLOYDIR + "\\temp.pdf");
                    break;
                default:
                    throw new Exception("Delivery method not supported: " + deliveryMethod);
            }

            Playback.Wait(10000);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup()
        {
            CloseRelatedProcesses();
            MasterTestClass.CleanupClass();
        }
    }
}
