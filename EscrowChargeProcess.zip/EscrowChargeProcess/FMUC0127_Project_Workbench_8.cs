﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using AutoIt;

namespace EscrowChargeProcess
{

    public partial class FMUC0127_Project_Workbench : MasterTestClass
    {
        #region US_603430
        [Microsoft.VisualStudio.TestTools.UnitTesting.TestMethod]
        public void US_603430_617911_and_617994()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify that the last row highlighted by default gets deleted upon clicking on subtract button (-)";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                //
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                this.EnterSiteFileData();
             
                #endregion UI Interaction
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                    Playback.Wait(500);
                }
                Support.AreEqual("5", FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount().ToString());
                FastDriver.ProjectWorkBench.RemoveButton.FAClick();
                Playback.Wait(500);
                //Test User Story 617994
                Support.AreEqual("4", FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount().ToString());


            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_603430_618010()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify that row selection can be moved up and down with keyboard arrow keys";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                this.EnterSiteFileData();
               
                #endregion UI Interaction
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                    Playback.Wait(500);
                }
                Support.AreEqual("5", FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount().ToString());
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(5, 4, TableAction.SetText, "Test Address");
                Playback.Wait(1000);
                Support.AreEqual("Test Address", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(5, 4, TableAction.GetInputValue).Message.ToString());

                Playback.Wait(500);
                FastDriver.ProjectWorkBench.RemoveButton.FAClick();
                Playback.Wait(500);

                Support.AreEqual("4", FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount().ToString());
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.SendKeys(FAKeys.ArrowUp);
                FastDriver.ProjectWorkBench.RemoveButton.FAClick();
                Playback.Wait(500);
                Support.AreEqual("3", FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount().ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_603430_665547()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify the keyboard arrow selection when Copy All checkbox is selected";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                this.EnterSiteFileData();

                #endregion UI Interaction
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                    Playback.Wait(500);
                }
                FastDriver.ProjectWorkBench.CopyAllAddresses.FAClick();

                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 4, TableAction.Click);

                for (int i = 0; i < FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount() - 2; i++)
                {
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.SendKeys(FAKeys.ArrowDown);
                }

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        #endregion US_603430

        #region US_584267

        [TestMethod]
        public void US_584267_624049_AND_624052()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                this.EnterSiteFileData();
               
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                #endregion UI Interaction

                //
                Reports.TestStep = "Navigate to File Home Page and CHange product & transaction type";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Sale/Cash");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.AddRemoveProducts.FAClick();
                FastDriver.ProductListDlg.WaitScreenToLoad();
                for (int i = 1; i <= FastDriver.ProductListDlg.Table.GetRowCount(); i++)
                {
                    FastDriver.ProductListDlg.Table.PerformTableAction(i, 1, TableAction.Off);

                }

                FastDriver.ProductListDlg.Table.PerformTableAction(5, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateTransactionTypeChk);
                FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.SlidingTitle.FAClick();
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateTransactionTypeChk);
                Support.AreEqual("SlidingTitle", FastDriver.ProjectWorkBench.SlidingTitle.GetAttribute("class"));

                //*********This steps covers test case 624052******
                var element = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//*[contains(., 'Site File(s) updated Successfully.')]");
                Support.AreEqual("True", (element != null).ToString());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_584267_624056()
        {
            try
            {
                Reports.TestDescription = "To verify that update section is disabled in system 2 when update is in progress in system 1 for the same file";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_584267_624050_AND_624051()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);

                for (int i = 1; i < 6; i++)
                {

                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 4, TableAction.SetText, "1807 Glenwood St. NE");
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 5, TableAction.SetText, "Brevard");
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 6, TableAction.SelectItem, "FL");
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 7, TableAction.SetText, "32907");
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 8, TableAction.SetText, "Palm Beach");
                    FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                    Playback.Wait(300);
                }

                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                #endregion UI Interaction

                //
                Reports.TestStep = "Navigate to File Home Page and CHange product & transaction type";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Sale/Cash");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.AddRemoveProducts.FAClick();
                FastDriver.ProductListDlg.WaitScreenToLoad();
                for (int i = 1; i <= FastDriver.ProductListDlg.Table.GetRowCount(); i++)
                {
                    FastDriver.ProductListDlg.Table.PerformTableAction(i, 1, TableAction.Off);

                }

                FastDriver.ProductListDlg.Table.PerformTableAction(5, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateTransactionTypeChk);
                FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.SlidingTitle.FAClick();
                for (int i = 1; i <= 5; i++)
                {
                    FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(i, 1, TableAction.On);

                }
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();

                var element = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//*[contains(., 'An Update is in Process. Please wait.')]");
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateTransactionTypeChk);
                Support.AreEqual("True", (element != null).ToString());
                Playback.Wait(2000);
                //*********This steps covers test case 624051******
                var element2 = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//*[contains(., 'Site File(s) updated Successfully.')]");
                Support.AreEqual("True", (element2 != null).ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion US_584267

       #region US_659238
        
        [TestMethod]
        public void US_659238_Scenario1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create  Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Residential");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Validate ProjectWorkBench Link is not available";
                try
                {
                    FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench");
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("As expected ProjectWorkbench link not available", true);
                }
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.FormType_CD.Enabled.ToString());

                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileFees.CD.Enabled.ToString());
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.TermsDatesStatus.OverwriteStatus.Displayed.ToString(), "validates Overwritestatus chechkbox is unavailable");


                #endregion UI Interaction


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_659238_Scenario2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create  Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Validate ProjectWorkBench Link is not available";
                try
                {
                    FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench");
                    Reports.StatusUpdate("As expected, ProjectWorkbench link available", true);
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Unexpected, ProjectWorkbench link not available", false);
                
                }

                //
                Reports.TestStep = "Validate FormType CD disabled in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.NewLoan.FormType_CD.Enabled.ToString(), "Validates FormType CD disabled in New Loan Screen");

                //
                Reports.TestStep = "Validate FormType CD disabled in File Fees Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.FileFees.CD.Enabled.ToString());


                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("True",FastDriver.TermsDatesStatus.OverwriteStatus.Displayed.ToString(),"validates Overwritestatus chechkbox is available");


                #endregion UI Interaction


            }

            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion US_659238

        #region US_556927

        [TestMethod]
        public void US_556927_640029()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify that the last row highlighted by default gets deleted upon clicking on subtract button (-)";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                //
                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                string sitefileNum = Support.RandomString("NNNAA").ToString();
                FastDriver.ProjectWorkBench.SiteFileNum.FASetText(sitefileNum);
                FastDriver.ProjectWorkBench.State.FASelectItem("FL");
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.FileNumberEditBox.FASetText(FastDriver.TopFrame.GetFileNumber() + "FL1");
                FastDriver.TopFrame.FileNumberEditBox.FASendKeys(FAKeys.Enter);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("250000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                Support.AreEqual("Individual", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                Support.AreEqual(@"N/A", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem());

                //
                Reports.TestStep = "Create a seller";
                this.CreateASeller();
               

                //
                Reports.TestStep = "Navigate to 1099-s";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                Validate1099SFieldsAvailability(false,false,false, false, false, false, false, false, false, false);
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum2);

                //
                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteMenuOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);
                FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis.FAClick();
                FastDriver.SellerSelectionDlg.WaitForScreenToLoad();
                FastDriver.SellerSelectionDlg.SellerSelectionTable.PerformTableAction(2, 4, TableAction.On);
                FastDriver.SellerSelectionDlg.Done.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);
                FastDriver.ProjectWorkBench.SlidingTitle.FAClick();
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateTransactionTypeChk);
                #endregion UI Interaction
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_556927_640049()
        {
            try
            {
                Reports.TestDescription = "System Should throw an Warning message if the Site File has the 1099-S Records('Not Ready for Extract' and has a Last Export Date- PlaceHolder";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
          

        }
        
        [TestMethod]
        public void US_556927_640050()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);

                for (int i = 1; i < 6; i++)
                {
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 4, TableAction.SetText, "1807 Glenwood St. NE");
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 5, TableAction.SetText, "Brevard");
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 6, TableAction.SelectItem, "FL");
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 7, TableAction.SetText, "32907");
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(i, 8, TableAction.SetText, "Palm Beach");
                    FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                    Playback.Wait(300);
                }

                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Modifying First site file";
                FastDriver.TopFrame.WaitForScreenToLoad();
                string projectFileNumber = FastDriver.TopFrame.GetFileNumber(); 
                FastDriver.TopFrame.FileNumberEditBox.FASetText(projectFileNumber + "FL1");
                FastDriver.TopFrame.FileNumberEditBox.FASendKeys(FAKeys.Enter);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("250000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.GiveFocus();
                FastDriver._1099S.GrossProceedDollor.FASendKeys(FAKeys.Backspace);
                FastDriver._1099S.CreateAdHoc("250000");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Modifying second site file";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.FileNumberEditBox.FASetText(projectFileNumber + "FL2");
                FastDriver.TopFrame.FileNumberEditBox.FASendKeys(FAKeys.Enter);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("350000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow:false);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.ToDateString());
               
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                FastDriver._1099S.AdHoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.GiveFocus();
                FastDriver._1099S.GrossProceedDollor.FASendKeys(FAKeys.Backspace);
                FastDriver._1099S.CreateAdHoc("350000");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                
                //
                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.TopFrame.SearchFileByFileNumber(projectFileNumber);
                FastDriver.ProjectWorkBench.Open();
                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateTransactionTypeChk);

                FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis.FAClick();
                FastDriver.SellerSelectionDlg.WaitForScreenToLoad();
                FastDriver.SellerSelectionDlg.SellerSelectionTable.PerformTableAction(2, 4, TableAction.On);
                FastDriver.SellerSelectionDlg.Done.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);
                FastDriver.ProjectWorkBench.SlidingTitle.FAClick();
                
                for (int i = 1; i < 6; i++)
                {
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(i, 1, TableAction.On);
                }
                
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();
                string message= @"Selected Site file(s) cannot be updated from Project workbench as one or more Site file(s) has at least one of the following scenarios";

                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage().Contains(message).ToString());
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderCancel.FAClick();
                #endregion UI Interaction
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_556927_640035()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                this.EnterSiteFileData();

                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Modifying First site file";
                FastDriver.TopFrame.WaitForScreenToLoad();
                string projectFileNumber = FastDriver.TopFrame.GetFileNumber();
                FastDriver.TopFrame.FileNumberEditBox.FASetText(projectFileNumber + "FL1");
                FastDriver.TopFrame.FileNumberEditBox.FASendKeys(FAKeys.Enter);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("251000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                Support.AreEqual("Individual",FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
                
                //
                Reports.TestStep = "Create a seller";
                this.CreateASeller();

                //
                Reports.TestStep = "Navigate to 1099-s";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                this.Validate1099SFieldsAvailability(false,false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.GiveFocus();
                FastDriver._1099S.GrossProceedDollor.FASendKeys(FAKeys.Backspace);
                FastDriver._1099S.CreateAdHoc("251000");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.TopFrame.SearchFileByFileNumber(projectFileNumber);

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteMenuOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);
                FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis.FAClick();
                FastDriver.SellerSelectionDlg.WaitForScreenToLoad();
                FastDriver.SellerSelectionDlg.SellerSelectionTable.PerformTableAction(2, 4, TableAction.On);
                FastDriver.SellerSelectionDlg.Done.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);
                FastDriver.ProjectWorkBench.SlidingTitle.FAClick();
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 1, TableAction.On);
             

                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();
                string message = @"Selected Site file(s) cannot be updated from Project workbench as one or more Site file(s) has at least one of the following scenarios";

                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage().Contains(message).ToString());
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderCancel.FAClick();
                #endregion UI Interaction
            }
            catch (Exception e)
            {
                
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_556927_640826()
        {
            try
            {
                Reports.TestDescription = "System Should throw an Warning message if the Site File has the 1099-S Records('Not Ready for Extract' and has a Last Export Date- PlaceHolder";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void US_556927_640043()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                this.EnterSiteFileData();

                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Modifying First site file by navigating to tems-dates-status";
                FastDriver.TopFrame.WaitForScreenToLoad();
                string projectFileNumber = FastDriver.TopFrame.GetFileNumber();
                FastDriver.TopFrame.FileNumberEditBox.FASetText(projectFileNumber + "FL1");
                FastDriver.TopFrame.FileNumberEditBox.FASendKeys(FAKeys.Enter);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("251000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Create a seller";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                this.CreateASeller();

                //
                Reports.TestStep = "Navigate to 1099-s";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                this.Validate1099SFieldsAvailability(false,false);
                Support.AreEqual("251,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue());
                FastDriver._1099S.GrossProceedDollor.GiveFocus();
                FastDriver._1099S.GrossProceedDollor.FASendKeys(FAKeys.Backspace);
                FastDriver._1099S.CreateAdHoc("251000");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver._1099S.WaitForScreenToLoad();

                //
                Reports.TestStep = "Modify a 1099 field";
                FastDriver._1099S.ActiveFirstName.FASetText("Ad-HOC First Name-Modified");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.TopFrame.SearchFileByFileNumber(projectFileNumber);

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteMenuOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);
                FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis.FAClick();
                FastDriver.SellerSelectionDlg.WaitForScreenToLoad();
                FastDriver.SellerSelectionDlg.SellerSelectionTable.PerformTableAction(2, 4, TableAction.On);
                FastDriver.SellerSelectionDlg.Done.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);
                FastDriver.ProjectWorkBench.SlidingTitle.FAClick();
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 1, TableAction.On);

                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();
                string message = @"Selected Site file(s) cannot be updated from Project workbench as one or more Site file(s) has at least one of the following scenarios";
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage().Contains(message).ToString());
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderCancel.FAClick();
                #endregion UI Interaction
            }
            catch (Exception e)
            {
                
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_556927_641621()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                this.EnterSiteFileData();

                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Modifying First site file by navigating to tems-dates-status";
                FastDriver.TopFrame.WaitForScreenToLoad();
                string projectFileNumber = FastDriver.TopFrame.GetFileNumber();
                FastDriver.TopFrame.FileNumberEditBox.FASetText(projectFileNumber + "FL1");
                FastDriver.TopFrame.FileNumberEditBox.FASendKeys(FAKeys.Enter);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("251000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Create a seller";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                this.CreateASeller();

                //
                Reports.TestStep = "Navigate to 1099-s";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                this.Validate1099SFieldsAvailability(false,false);
                Support.AreEqual("251,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue());
                FastDriver._1099S.GrossProceedDollor.GiveFocus();
                FastDriver._1099S.GrossProceedDollor.FASendKeys(FAKeys.Backspace);
                FastDriver._1099S.CreateAdHoc("251000");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver._1099S.WaitForScreenToLoad();
                string originalDate= FastDriver._1099S.DateCreated.FAGetText();

                //
                Reports.TestStep = "Modify a 1099 field";
                FastDriver._1099S.ActiveFirstName.FASetText("Ad-HOC First Name-Modified");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("False",FastDriver._1099S.DateCorrected.FAGetText().Equals(originalDate).ToString());
                FastDriver._1099S.ActiveReadyForExtract.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.Method.FASelectItem("Print");
                FastDriver._1099S.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);
                //******continue on step 16, the void button is not getting enabled after the delivery QA crew is verifying the order of the steps.
                #endregion UI Interaction
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }             
        }


        [TestMethod]
        public void US_556927_640833()
        {
            try
            {
                Reports.TestDescription = "System Should throw an Warning message if the Site File has the 1099-S Records('Not Ready for Extract' and has a Last Export Date- PlaceHolder";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception)
            {
                
                throw;
            }  
        }

        [TestMethod]
        public void US_556927_640030()
        {
            try
            {
                 #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                this.EnterSiteFileData();
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Modifying First site file by navigating to tems-dates-status";
                FastDriver.TopFrame.WaitForScreenToLoad();
                string projectFileNumber = FastDriver.TopFrame.GetFileNumber();
                FastDriver.TopFrame.FileNumberEditBox.FASetText(projectFileNumber + "FL1");
                FastDriver.TopFrame.FileNumberEditBox.FASendKeys(FAKeys.Enter);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("251000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Create a seller";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                this.CreateASeller();
               

                //
                Reports.TestStep = "Navigate to 1099-s";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad();
                this.Validate1099SFieldsAvailability(false,false);
                Support.AreEqual("251,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue());
                #endregion UI Interaction

            }
            catch (Exception e)
            {
                
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_556927_640045()
        {
            try
            {
                Reports.TestDescription = "System Should throw an Warning message if the Site File has the 1099-S Records('Not Ready for Extract' and has a Last Export Date- PlaceHolder";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception)
            {

                throw;
            }
        }

        [TestMethod]
        public void US_556927_640917()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if the update section is disabled when another update is in progress- (624052) To verify if update section is enabled after update is successful";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.FileHomepage.TransactionType.FASelectItem("Refinance");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();
                
                //
                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Support.AreEqual("False",FastDriver.ProjectWorkBench.Seller.IsVisible().ToString());

                //
                Reports.TestStep = "Navigate to File Homepage and change transaction Type";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem(@"Sale/Cash");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                //
                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();
                
                //
                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Support.AreEqual("True", FastDriver.ProjectWorkBench.Seller.IsVisible().ToString());
                this.EnterSiteFileData();

                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.TopFrame.WaitForScreenToLoad();
                string projectFileNumber = FastDriver.TopFrame.GetFileNumber();
                FastDriver.TopFrame.FileNumberEditBox.FASetText(projectFileNumber + "FL1");
                FastDriver.TopFrame.FileNumberEditBox.FASendKeys(FAKeys.Enter);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("251000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Navigate to 1099-s";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S").WaitForScreenToLoad(FastDriver._1099S.AdHoc);
                FastDriver._1099S.AdHoc.FAClick();
                FastDriver._1099S.GrossProceedDollor.GiveFocus();
                FastDriver._1099S.GrossProceedDollor.FASendKeys(FAKeys.Backspace);
                FastDriver._1099S.CreateAdHoc("251000");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("251,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue());

                //
                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.TopFrame.SearchFileByFileNumber(projectFileNumber);
                FastDriver.ProjectWorkBench.Open();
                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
               
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteMenuOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);
                FastDriver.ProjectWorkBench.UpdateSellerChk.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis.FAClick();
                FastDriver.SellerSelectionDlg.WaitForScreenToLoad();
                FastDriver.SellerSelectionDlg.SellerSelectionTable.PerformTableAction(2, 4, TableAction.On);
                FastDriver.SellerSelectionDlg.Done.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);
                FastDriver.ProjectWorkBench.SlidingTitle.FAClick();
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();
                string message = @"Selected Site file(s) cannot be updated from Project workbench as one or more Site file(s) has at least one of the following scenarios";
                Support.AreEqual("True", FastDriver.WebDriver.HandleDialogMessage().Contains(message).ToString());
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderCancel.FAClick();

               
                #endregion UI Interaction

            }
            catch (Exception e)
            {
                
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_556927_640821()
        {
            try
            {
                Reports.TestDescription = "System Should throw an Warning message if the Site File has the 1099-S Records('Not Ready for Extract' and has a Last Export Date- PlaceHolder";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception)
            {

                throw;
            }
        }

        #endregion US_556927

        //#region US_659238



        #region custom class method
        private void EnterSiteFileData()
        {
            Reports.TestStep = "Enter the data in the site file row";
            FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
            FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 4, TableAction.SetText, "1807 Glenwood St. NE");
            FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 5, TableAction.SetText, "Brevard");
            FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 6, TableAction.SelectItem, "FL");
            FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 7, TableAction.SetText, "32907");
            FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 8, TableAction.SetText, "Palm Beach");
        }

        private void Validate1099SFieldsAvailability(bool PayeeIndicator=true, bool SSNTINType= true, bool SSNTIN=true, bool ForeignCountrySeller = true, bool ActiveReadyForExtract = true, bool ActiveFirstName = true, bool ActiveAddress = true, bool ActiveCity = true, bool ActivecboState = true, bool ActiveZip = true)
        {
            Support.AreEqual(PayeeIndicator.ToString(), FastDriver._1099S.PayeeIndicator.IsEnabled().ToString());
            Support.AreEqual(SSNTINType.ToString(), FastDriver._1099S.SSNTINType.IsEnabled().ToString());
            Support.AreEqual(SSNTIN.ToString(), FastDriver._1099S.SSNTIN.IsEnabled().ToString());
            Support.AreEqual(ForeignCountrySeller.ToString(), FastDriver._1099S.ForeignCountrySeller.IsEnabled().ToString());
            Support.AreEqual(ActiveReadyForExtract.ToString(), FastDriver._1099S.ActiveReadyForExtract.IsEnabled().ToString());
            Support.AreEqual(ActiveFirstName.ToString(), FastDriver._1099S.ActiveFirstName.IsEnabled().ToString());
            Support.AreEqual(ActiveAddress.ToString(), FastDriver._1099S.ActiveAddress.IsEnabled().ToString());
            Support.AreEqual(ActiveCity.ToString(), FastDriver._1099S.ActiveCity.IsEnabled().ToString());
            Support.AreEqual(ActivecboState.ToString(), FastDriver._1099S.ActivecboState.IsEnabled().ToString());
            Support.AreEqual(ActiveZip.ToString(), FastDriver._1099S.ActiveZip.IsEnabled().ToString());

        }
        private void CreateASeller()
        {
            Support.AreEqual("Individual", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem());
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys(@"H");
            FastDriver.BuyerSellerSetup.WaitForHusbandSpouseFirstNameToLoad();
            FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText(@"Seller Husband First");
            FastDriver.BuyerSellerSetup.Husband2LastName.FASetText(@"Seller Husband Last");
            FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText(@"Wife First");
            FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FASetText(@"Seller Husband Last");
            FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
            FastDriver.ExchangeCompany.WaitForScrenToLoad();
            FastDriver.ExchangeCompany.GABcode.FASetText(@"EXCH01");
            FastDriver.ExchangeCompany.Find.FAClick();
            FastDriver.BottomFrame.Done();
        }
        #endregion custom class method




    }
}
