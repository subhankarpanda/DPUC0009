﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpers;


namespace EscrowChargeProcess
{
    /// <summary>
    /// Summary description for FMUC0043_InspectionRepair
    /// </summary>
    [CodedUITest]
    public class FMUC0043_InspectionRepair : MasterTestClass
    {
        #region BAT

        [TestMethod]
        [Description("Create first three instance of inspection Repair Pest.")]
        public void FMUC0043_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Create first three instance of inspection Repair Pest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Verify Change OO Button.

                Reports.TestStep = "Verify for FileHomePage.";

                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.FileHomepage.ChangeOO.IsDisplayed().ToString());

                #endregion

                #region Create an instance of inspection Repair Pest.

                Reports.TestStep = "Create an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                #endregion

                #region Create second instance of inspection Repair Pest
                Reports.TestStep = "Create second instance of inspection Repair Pest.";
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 2 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 2 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference2");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION2");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("100.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("125.00");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 225.55", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
          
                #endregion

                #region Create third instance of inspection Repair Pest.
                Reports.TestStep = "Create third instance of inspection Repair Pest.";
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 3 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 3 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference3");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION3");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("200.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("150.00");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 350.00", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());

                FastDriver.BottomFrame.Done();
                FastDriver.InspectionRepairSummary.SwitchToContentFrame();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Edit Inspection/Repair.")]
        public void FMUC0043_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_00: Edit Inspection/Repair.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion
                              
                #region Create an instance of inspection Repair Pest.

                Reports.TestStep = "Create an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");

                #endregion

                #region Create second instance of inspection Repair Pest
                Reports.TestStep = "Create second instance of inspection Repair Pest.";
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 2 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 2 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference2");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION2");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("100.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("125.00");
                
                #endregion

                #region Create third instance of inspection Repair Pest.
                Reports.TestStep = "Create third instance of inspection Repair Pest.";
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 3 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 3 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference3");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION3");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("200.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("150.00");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Alternate Course 1: Edit Inspection/Repair.
                Reports.TestStep = "Alternate Course 1: Edit Inspection/Repair.";
                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();

                FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.InspectionRepairSummary.Edit.FAClick();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Alternate Course 1: Edit Inspection/Repair1.";
                FastDriver.InspectionRepairPest.Name.FASetText("pest2 name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Reference.FASetText("ReferenceEdited");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTIONEDITED");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("111.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("222.00");
                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);

                Support.AreEqual("Check Amount: $ 333.00", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());

                FastDriver.BottomFrame.Done();

                #endregion

                #region Alternate Course 1: Edit Inspection/Repair02(validation).
                Reports.TestStep = "Alternate Course 1: Edit Inspection/Repair.";
                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();
                FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.InspectionRepairSummary.Edit.FAClick();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Alternate Course 1: Edit Inspection/Repair02(validation).";
           
                Support.AreEqual("ReferenceEdited", FastDriver.InspectionRepairPest.Reference.FAGetValue().Trim());
                Support.AreEqual("PESTDESCRIPTIONEDITED", FastDriver.InspectionRepairPest.description.FAGetValue().Trim());
                Support.AreEqual("111.00", FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("222.00", FastDriver.InspectionRepairPest.SellerCharge.FAGetValue().Trim());

                Support.AreEqual("Check Amount: $ 333.00", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());

                FastDriver.BottomFrame.Done();

                #endregion

                #region Valiadate change in buyer and seller amount
                Reports.TestStep = "Valiadate change in buyer and seller amount";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();

                Support.AreEqual("4,503.00", FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText().Trim());
                Support.AreEqual("5,411.55", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText().Trim());

                #endregion

                #region Navigate to Inspection pest summary screen
                Reports.TestStep = "Navigate to Inspection pest summary screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSummary>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Delete Inspection/Repair.")]
        public void FMUC0043_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF2_00: Delete Inspection/Repair.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Create an instance of inspection Repair Pest.

                Reports.TestStep = "Create an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("111.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("222.00");

                #endregion

                #region Create second instance of inspection Repair Pest
                Reports.TestStep = "Create second instance of inspection Repair Pest.";
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 2 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 2 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference2");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION2");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("100.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("125.00");

                #endregion

                #region Create third instance of inspection Repair Pest.
                Reports.TestStep = "Create third instance of inspection Repair Pest.";
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 3 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 3 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference3");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION3");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("200.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("150.00");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Alternate Course 2: Delete Inspection/Repair
                Reports.TestStep = "Alternate Course 2: Delete Inspection/Repair.";
                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();

                FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.Click);
                FastDriver.InspectionRepairSummary.Remove.FAClick();

                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();

                Reports.TestStep = "Alternate Course 2: Delete Inspection/Repair1.";

                Support.AreEqual("Available",  FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.GetText).Message.Trim());
                #endregion

                #region Valiadate change in buyer and seller amount
                Reports.TestStep = "Valiadate change in buyer and seller amount";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();

                Support.AreEqual("4,653.00", FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText().Trim());
                Support.AreEqual("5,211.55", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText().Trim());

               #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Cancel 1st New Inspection/Repair Instance Creation.")]
        public void FMUC0043_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF3_00: Cancel 1st New Inspection/Repair Instance Creation.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Alternate Course 3: Cancel 1st New Inspection/Repair Instance Creation.

                Reports.TestStep = "Alternate Course 3: Cancel 1st New Inspection/Repair Instance Creation.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify new instance.
                Reports.TestStep = "verify new instance.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.SwitchToTopFrame();
                //SwitchToTitleFrame();
                Support.AreEqual("Inspection/Repair - Pest: New", FastDriver.InspectionRepairPest.InspectionTitle.FAGetText().Trim());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Cancel 2nd New Inspection/Repair Instance Creation.")]
        public void FMUC0043_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Cancel 2nd New Inspection/Repair Instance Creation.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Create an instance of inspection Repair Pest.

                Reports.TestStep = "Create an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                #endregion

                #region Alternate Course 4: Cancel 2nd New Inspection/Repair Instance Creation.

                Reports.TestStep = "Alternate Course 4: Cancel 2nd New Inspection/Repair Instance Creation.";

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 3 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 3 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference3");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION3");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("200.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("150.00");

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify new instance.
                Reports.TestStep = "verify new instance.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.SwitchToTopFrame();
                //SwitchToTitleFrame();
                Support.AreEqual("Inspection/Repair - Pest: 1", FastDriver.InspectionRepairPest.InspectionTitle.FAGetText().Trim());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Cancel 3rd / Subsequent New Inspection/Repair Instance Creation.")]
        public void FMUC0043_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF5_00: Cancel 3rd / Subsequent New Inspection/Repair Instance Creation.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Create an instance of inspection Repair Pest.

                Reports.TestStep = "Create an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
               
                #endregion

                #region Create second instance of inspection Repair Pest
                Reports.TestStep = "Create second instance of inspection Repair Pest.";
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 2 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 2 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference2");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION2");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("100.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("125.00");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 225.55", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());

                #endregion

                #region Alternate Course 5: Cancel 3rd / Subsequent New Inspection/Repair Instance Creation.

                Reports.TestStep = "Alternate Course 5: Cancel 3rd / Subsequent New Inspection/Repair Instance Creation.";
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 3 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 3 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference3");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION3");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("200.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("150.00");

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify new instance.
                Reports.TestStep = "verify new instance.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSummary>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.InspectionRepairSummary.Edit.IsDisplayed().ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Cancel Changes to Existing Inspection/Repair Instance.")]
        public void FMUC0043_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF6_00: Cancel Changes to Existing Inspection/Repair Instance.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Create an instance of inspection Repair Pest.

                Reports.TestStep = "Create an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());

                #endregion

                #region Create second instance of inspection Repair Pest
                Reports.TestStep = "Create second instance of inspection Repair Pest.";
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 2 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 2 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference2");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION2");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("100.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("125.00");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 225.55", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Alternate Course 6: Cancel Changes to Existing Inspection/Repair Instance.
                Reports.TestStep = "Alternate Course 1: Edit Inspection/Repair.";
                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();
                FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(1, "1", 2, TableAction.Click);
                FastDriver.InspectionRepairSummary.Edit.FAClick();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Alternate Course 6: Cancel Changes to Existing Inspection/Repair Instance.";

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 3 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 3 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference3");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("08-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("09-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("11-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("05-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION6");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("22.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("22.00");

                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                Reports.TestStep = "Alternate Course 6: Cancel Changes to Existing Inspection/Repair Instance02.";

                
                Support.AreEqual("Contact, Pest 1 for HUD", FastDriver.InspectionRepairPest.Attention.FAGetSelectedItem().Trim());
                Support.AreEqual("Reference1", FastDriver.InspectionRepairPest.Reference.FAGetValue().Trim());
                Support.AreEqual("5", FastDriver.InspectionRepairPest.WithinDays.FAGetValue().Trim());
                Support.AreEqual("07-10-2012", FastDriver.InspectionRepairPest.OrderDate.FAGetValue().Trim());
                Support.AreEqual("12-10-2012", FastDriver.InspectionRepairPest.DueDate.FAGetValue().Trim());
                Support.AreEqual("10-10-2012", FastDriver.InspectionRepairPest.FollowUpDate.FAGetValue().Trim());
                Support.AreEqual("04-10-2013", FastDriver.InspectionRepairPest.CompleteDate.FAGetValue().Trim());
                Support.AreEqual("03-10-2013", FastDriver.InspectionRepairPest.ReportDate.FAGetValue().Trim());
                Support.AreEqual("PESTDESCRIPTION1", FastDriver.InspectionRepairPest.description.FAGetValue().Trim());
                Support.AreEqual("55.55", FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("66.66", FastDriver.InspectionRepairPest.SellerCharge.FAGetValue().Trim());
               
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Create instance of Septic and Other-Inspection/Repair.")]
        public void FMUC0043_BAT0008()
        {
            try
            {
                Reports.TestDescription = "MF1_01: Create instance of Septic and Other-Inspection/Repair.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Create an instance of inspection Repair Septic

                Reports.TestStep = "Create an instance of inspection Repair Septic.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();

                FastDriver.InspectionRepairSeptic.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairSeptic.Find.FAClick();

                FastDriver.InspectionRepairSeptic.WaitForScreenToLoad();

                FastDriver.InspectionRepairSeptic.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairSeptic.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairSeptic.WithinDays.FASetText("5");
                FastDriver.InspectionRepairSeptic.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairSeptic.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairSeptic.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairSeptic.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairSeptic.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairSeptic.description.FASetText("SEPTICInspectionDESCRIPTION1");
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairSeptic.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairSeptic.CheckAmount.FAGetText().Trim());

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create an instance of inspection Repair Other.
                Reports.TestStep = "Create second instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.WaitForScreenToLoad();

                FastDriver.InspectionRepairOther.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.WaitForScreenToLoad();

                FastDriver.InspectionRepairOther.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairOther.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairOther.WithinDays.FASetText("5");
                FastDriver.InspectionRepairOther.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairOther.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairOther.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairOther.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairOther.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairOther.description.FASetText("OTHERInspectionDESCRIPTION1");
                FastDriver.InspectionRepairOther.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairOther.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairOther.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairOther.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Edit the Check details/Change the Payment Details.")]
        public void FMUC0043_BAT0009()
        {
            try
            {
                Reports.TestDescription = "MF1_02: Edit the Check details/Change the Payment Details.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType FileFormType = _CreateFile();
                #endregion

                #region Create an instance of inspection Repair Septic

                Reports.TestStep = "Create an instance of inspection Repair Septic.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();

                FastDriver.InspectionRepairSeptic.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairSeptic.Find.FAClick();

                FastDriver.InspectionRepairSeptic.WaitForScreenToLoad();

                FastDriver.InspectionRepairSeptic.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairSeptic.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairSeptic.WithinDays.FASetText("5");
                FastDriver.InspectionRepairSeptic.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairSeptic.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairSeptic.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairSeptic.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairSeptic.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairSeptic.description.FASetText("SEPTICInspectionDESCRIPTION1");
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairSeptic.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairSeptic.CheckAmount.FAGetText().Trim());

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create an instance of inspection Repair Other.
                Reports.TestStep = "Create second instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.WaitForScreenToLoad();

                FastDriver.InspectionRepairOther.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.WaitForScreenToLoad();

                FastDriver.InspectionRepairOther.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairOther.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairOther.WithinDays.FASetText("5");
                FastDriver.InspectionRepairOther.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairOther.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairOther.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairOther.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairOther.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairOther.description.FASetText("OTHERInspectionDESCRIPTION1");
                FastDriver.InspectionRepairOther.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairOther.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairOther.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairOther.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.Done();
                #endregion

                #region To Edit the check Details and ADD.

                Reports.TestStep = "To Edit the check Details and ADD.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.CheckDetails.FAClick();
                Reports.TestStep = "Edit description in Inspection/Repair Pest.";

                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.CheckDetailsDlg.Description.FASetText("Check Description Edited");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Voucher info edited for Inpection/Repair Pest");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Enter payment details for Inspection Pest.
                Reports.TestStep = "Enter payment details for Inspection Pest.";
                FastDriver.InspectionRepairOther.WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-Inspection Repair/Pest");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("1.99");

                if (FileFormType == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("1.99");
                }

                FastDriver.DialogBottomFrame.ClickDone();

                #endregion

                #region To verify the check amount after editing in PaymentDlg.
                Reports.TestStep = "To verify the check amount after editing in PaymentDlg.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairOther.WaitForScreenToLoad();
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.InspectionRepairOther.CheckAmount.FAGetText().ToString());
                FastDriver.BottomFrame.Done();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Create first three instance of inspection Repair Pest.")]
        public void FMUC0043_BAT0010()
        {
            try
            {
                Reports.TestDescription = "MF1_06_07_10: Create first three instance of inspection Repair Pest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType FileFormType = _CreateFile();
                #endregion

                #region Create an instance of inspection Repair Septic

                Reports.TestStep = "Create an instance of inspection Repair Septic.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();

                FastDriver.InspectionRepairSeptic.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairSeptic.Find.FAClick();

                FastDriver.InspectionRepairSeptic.WaitForScreenToLoad();

                FastDriver.InspectionRepairSeptic.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairSeptic.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairSeptic.WithinDays.FASetText("5");
                FastDriver.InspectionRepairSeptic.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairSeptic.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairSeptic.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairSeptic.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairSeptic.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairSeptic.description.FASetText("SEPTICInspectionDESCRIPTION1");
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairSeptic.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairSeptic.CheckAmount.FAGetText().Trim());

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create an instance of inspection Repair Other.
                Reports.TestStep = "Create second instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.WaitForScreenToLoad();

                FastDriver.InspectionRepairOther.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.WaitForScreenToLoad();

                FastDriver.InspectionRepairOther.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairOther.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairOther.WithinDays.FASetText("5");
                FastDriver.InspectionRepairOther.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairOther.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairOther.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairOther.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairOther.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairOther.description.FASetText("OTHERInspectionDESCRIPTION1");
                FastDriver.InspectionRepairOther.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairOther.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairOther.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairOther.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create third instance of inspection Repair Pest.
                Reports.TestStep = "Create third instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 3 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 3 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference3");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION3");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("200.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("150.00");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 350.00", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.Done();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                #endregion

                #region Validate the default for Check Details Dialog.
                Reports.TestStep = "Validate the default for Check Details Dialog.";
                FastDriver.InspectionRepairPest.CheckDetails.FAClick();
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Inspection and/or Repairs",  FastDriver.CheckDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Edit description in Inspection/Repair Pest.";

                FastDriver.CheckDetailsDlg.Description.FASetText("Check Description Edited");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Voucher info edited for Insurance");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.BottomFrame.Done();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                #endregion
                
                #region Clicking on payment details and Change the seller and buyer payment to RBL.
                Reports.TestStep = "Clicking on payment details and Change the seller and buyer payment to RBL.";

                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Change the seller and buyer payment to RBL";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$3.99");

                if (FileFormType == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$3.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$3.99");
                    FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("NameEdit");
                }
                else {
                     FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("RBL");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("RBL");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                
                #endregion

                #region verify for pencil icon.
                Reports.TestStep = "verify for pencil icon.";
                Support.AreEqual(true.ToString(),FastDriver.InspectionRepairPest.PencilIcon.IsDisplayed().ToString());

                Reports.TestStep = "Verify the change in amount in buyer and seller charge";

                Support.AreEqual("3.99", FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("3.99", FastDriver.InspectionRepairPest.SellerCharge.FAGetValue().Trim());

                #endregion

                #region Clicking on payment details and make payment method as CHK..
                Reports.TestStep = "Clicking on payment details and  make payment method as CHK.";

                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Change the seller and buyer payment to RBL";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$2.60");

                if (FileFormType == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$2.60");
                    FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("CHK");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                #endregion

                #region verify for pencil icon.

                if (FileFormType == FormType.CD) {
                    Reports.TestStep = "verify for pencil icon does appear when changing amounts in PDD.";
                    Support.AreEqual(true.ToString(), FastDriver.InspectionRepairPest.PencilIcon.IsDisplayed().ToString());

                } else {
                    Reports.TestStep = "verify for pencil icon doesnot appear for check amount.";
                    Support.AreEqual(false.ToString(), FastDriver.InspectionRepairPest.PencilIcon.IsDisplayed().ToString());

                }

                Support.AreEqual("Check Amount: $ 5.10", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
               
                FastDriver.BottomFrame.Done();
                #endregion

                #region "Validate the buyer and seller net amount
                Reports.TestStep = "Validate the buyer and seller net amount";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();

                Support.AreEqual("5,113.60", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText().Trim());
                Support.AreEqual("4,864.08", FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText().Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region REGRESSION

        [TestMethod]
        [Description("1:Inspection/Repair 2:Required Data 3:Inspection/Repair Report Info. 4:Display Payment Details 5:Display Check Details 6:Enter Charges 7:Delete Inspection/Repair Ins")]
        public void FMUC0043_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM1155_FM2498_FM1802_FM2500_FM2501_FM2502_FM4201_EW13: 1:Inspection/Repair 2:Required Data 3:Inspection/Repair Report Info. 4:Display Payment Details 5:Display Check Details 6:Enter Charges 7:Delete Inspection/Repair Ins.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType FileFormType = _CreateFile();
                #endregion
                              
                #region Set an instance of inspection Repair Pest.
                Reports.TestStep = "Set an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.GABcode.FASetText("PEST2");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for Inspection Pest.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$1.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$1.99");

                if (FileFormType == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$1.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$1.99");
                    FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Sanity-Inspection Repair/Pest");

                }
                else {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-Inspection Repair/Pest");
                }
                
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Clicking on payment details.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for Inspection Pest.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                if (FileFormType == FormType.CD)
                {
                    Support.AreEqual("$1.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                    Support.AreEqual("$1.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                    Support.AreEqual("Sanity-Inspection Repair/Pest", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue());
                    Support.AreEqual("$1.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                    Support.AreEqual("$1.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue());
                }
                else {
                    Support.AreEqual("1.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                    Support.AreEqual("1.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                    Support.AreEqual("Sanity-Inspection Repair/Pest", FastDriver.PaymentDetailsDlg.DESCRPTION.FAGetValue());
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                #endregion

                #region  Create an instance of inspection Repair Pest.

                Reports.TestStep = "Create an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                                
                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("OTHERInspectionDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click on Find button to enter GAB code from Address Book Search.
                Reports.TestStep = "Click on Find button to enter GAB code from Address Book Search.";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("Test");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);

                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(4, "Test", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number. Do you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                #endregion

                #region Inspection Repair Report Information.
                Reports.TestStep = "Inspection Repair Report Information.";

                FastDriver.InspectionRepairPest.FurnishedBy.FASelectItem("Seller");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("10");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("09-03-2010");
                FastDriver.InspectionRepairPest.DueDate.FASetText("09-03-2011");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-03-2011");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("11-03-2011");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("11-03-2011");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Edit Check Details
                Reports.TestStep = "Edit Check Details.";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.CheckDetails.FAClick();

                Reports.TestStep = "Edit description in Inspection/Repair Pest.";
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.CheckDetailsDlg.Description.FASetText("Check Description Edited");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Voucher info edited for Inpection/Repair Pest");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion

                #region Alternate Course 1: Edit Inspection/Repair1
                Reports.TestStep = "Alternate Course 1: Edit Inspection/Repair1.";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Reference.FASetText("ReferenceEdited");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTIONEDITED");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("111.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("222.00");
                FastDriver.InspectionRepairPest.SellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 333.00", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.Done();

                #endregion

                #region hange the payment details methods to POC-B and POC-s
                Reports.TestStep = "Clicking on payment details.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Change the payment details methods to POC-B and POC-s.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (FileFormType == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("NameEdit");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("POC-S");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "verify for pencil icon.";
                Support.AreEqual(true.ToString(), FastDriver.InspectionRepairPest.PencilIcon.IsDisplayed().ToString());
                #endregion

                #region Create 2nd instance of inspection Repair Pest.

                Reports.TestStep = "Create 2nd instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.GABcode.FASetText("PEST2");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();
                FastDriver.InspectionRepairSummary.New.FAClick();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.GABcode.FASetText("HUDPEST003");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Instance and Press shortcut key to delete.";
                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();
                FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.Click);
                FastDriver.InspectionRepairSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();

                Support.AreEqual("Available", FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.GetText).Message.Trim());
                                
                #endregion

                #region Navigate to Inspection Repair/Pest Screen and Delete the Inspection-Pest instance
                Reports.TestStep = "Navigate to Inspection Repair/Pest Screen and Delete the Inspection-Pest instance";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSummary>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(1, "2", 2, TableAction.Click);
                FastDriver.InspectionRepairSummary.Edit.FAClick();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();

                Support.AreEqual("All information will be removed for this Inspection Repair.  Continue?", FastDriver.WebDriver.HandleDialogMessage());                                
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("1:User deletes a charge process instance that has issued checks. 2:The business party is a payee on an issued check and user tries to edit or replace it with another business party. 3:User tries to delete a")]
        public void FMUC0043_REG0002()
        {
            try
            {
                Reports.TestDescription = "EW1_8_3_5_6: 1:User deletes a charge process instance that has issued checks. 2:The business party is a payee on an issued check and user tries to edit or replace it with another business party. 3:User tries to delete a";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType FileFormType = _CreateFile();
                #endregion

                #region Create an instance of inspection Repair Pest.

                Reports.TestStep = "Create an instance of inspection Repair Pest.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");

                FastDriver.InspectionRepairPest.Attention.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                #endregion

                #region New us Shortcut Keys."
                Reports.TestStep = "New us Shortcut Keys.";
                Keyboard.SendKeys("^N");
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                #endregion

                #region Print All Checks.

                Reports.TestStep = "Print All Checks.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();


                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);


                Reports.TestStep = "Click on Done in ADS screen.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Inspection Repair Pest and Delete The Payee have Issued Instance.
                Reports.TestStep = "Navigate to Inspection Repair Pest and Delete The Payee have Issued Instance.";
               
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());
                #endregion

                #region Click on Find button to enter GAB code from Address Book Search
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                Reports.TestStep = "Click on Find button to enter GAB code from Address Book Search.";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Find.FAClick();
                Support.AreEqual(@"A check has been issued for this Payee.  The Payee name cannot be changed.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                #endregion

                #region Delete Charge Description
                Reports.TestStep = "Delete Charge Description.";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.description.FASetText("");
                FastDriver.InspectionRepairPest.description.SendKeys(FAKeys.Tab);
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                #endregion

                #region Decrease and Increase the Issued Amount.
                Reports.TestStep = "Decrease the Issued Amount.";
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("1.00");
                FastDriver.InspectionRepairPest.BuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false));
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Increase the Issued Amount.";
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("100.00");
                FastDriver.InspectionRepairPest.SellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("1:Display Check Amounts 2:Delete Inspection/Repair Instance 3:Enter GFE Amounts for a GFE Charge 4:User deletes a charge process instance that does not have issued checks. 5:User searc")]
        public void FMUC0043_REG0003()
        {
            try
            {
                Reports.TestDescription = "2503_4201_ES10845_EW2_7_9_10_11_12: 1:Display Check Amounts 2:Delete Inspection/Repair Instance 3:Enter GFE Amounts for a GFE Charge 4:User deletes a charge process instance that does not have issued checks. 5:User searc";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType FileFormType = _CreateFile();
                #endregion

                #region Alternate Course 3: Cancel 1st New Inspection/Repair Instance Creation.

                Reports.TestStep = "Enter Invalid Gab Code.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.GABcode.FASetText("XCHZ");
                FastDriver.InspectionRepairPest.Find.Click();
                Support.AreEqual("ID Code not found.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Enter GFE Amount.";
                FastDriver.InspectionRepairPest.GFEAmount.FASetText("10.00");
                FastDriver.InspectionRepairPest.GFEAmount.SendKeys(FAKeys.Tab);

                Reports.TestStep = "save Changes without Bus Party.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Alternate Course 3: Cancel 1st New Inspection/Repair Instance Creation.";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.Click();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");

                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Create an instance of inspection Repair Pest.
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Name.FASetText("Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.Click();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION1");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("55.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("66.66");
                FastDriver.InspectionRepairPest.SellerCharge.SendKeys(FAKeys.Tab);

                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete us Shortcut Keys.";
                FastDriver.BottomFrame.Delete();
                Support.AreEqual("All information will be removed for this Inspection Repair.  Continue?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false));
                
                Reports.TestStep = "New us Shortcut Keys.";
                Playback.Wait(5000);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                Keyboard.SendKeys("^N");

                //FastDriver.InspectionRepairPest.PaymentDetails.SendKeys(Keys.LeftControl + "N");
                Playback.Wait(5000);

                Reports.TestStep = "Cancel us Shortcut Keys.";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                //FastDriver.InspectionRepairPest.PaymentDetails.SendKeys(Keys.LeftControl + "Q");
                Keyboard.SendKeys("^Q");

                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());
                Playback.Wait(5000);

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();


                #endregion

                #region Create second instance of inspection Repair Pest.
                Reports.TestStep = "New us Shortcut Keys.";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                Keyboard.SendKeys("^N");
                Playback.Wait(5000);

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Create second instance of inspection Repair Pest.";
                FastDriver.InspectionRepairPest.Name.FASetText("Pest 2 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.Click();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 2 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference2");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION2");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("100.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("125.00");
                FastDriver.InspectionRepairPest.SellerCharge.SendKeys(FAKeys.Tab);

                Support.AreEqual("Check Amount: $ 225.55", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create second instance.
                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();
                FastDriver.InspectionRepairSummary.New.FAClick();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Create second instance.";
                FastDriver.InspectionRepairPest.Name.FASetText("Pest 2 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.Click();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 2 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference2");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION2");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("100.55");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("125.00");
                FastDriver.InspectionRepairPest.SellerCharge.SendKeys(FAKeys.Tab);

                Support.AreEqual("Check Amount: $ 225.55", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                Reports.TestStep = "Done us Shortcut Keys.";
                Keyboard.SendKeys("^D");
                Playback.Wait(5000);

                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click New Using Shortcut Key.";

                Keyboard.SendKeys("%N");
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Cancel without save changes.";
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Create third instance of inspection Repair Pest.
                Reports.TestStep = "Create third instance of inspection Repair Pest.";
                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();
                Keyboard.SendKeys("%N");
                Playback.Wait(5000);

                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.Name.FASetText("Pest 3 for HUD Testing Name 1");
                FastDriver.InspectionRepairPest.Find.Click();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.Attention.FASelectItem("Contact, Pest 3 for HUD");
                FastDriver.InspectionRepairPest.Reference.FASetText("Reference3");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("5");
                FastDriver.InspectionRepairPest.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairPest.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairPest.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairPest.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairPest.description.FASetText("PESTDESCRIPTION3");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("200.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("150.00");
                FastDriver.InspectionRepairPest.SellerCharge.SendKeys(FAKeys.Tab);

                Support.AreEqual("Check Amount: $ 350.00", FastDriver.InspectionRepairPest.CheckAmount.FAGetText().Trim());
                Reports.TestStep = "Done us Shortcut Keys.";
                FastDriver.BottomFrame.Done();
                FastDriver.InspectionRepairSummary.WaitForScreenToLoad();
                
                #endregion

                #region Navigate to Active Disbursement Summary screen.
                Reports.TestStep = "Navigate to Active Disbursement Summary screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "122.21", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "225.55", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "350.00", 7, TableAction.Click);
                #endregion

                #region Navigate to Inspection Repair/Pest screen and Select Instance and Press shortcut key to delete.
                Reports.TestStep = "Navigate to Inspection Repair/Pest screen.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSummary>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                
                Reports.TestStep = "Select Instance and Press shortcut key to delete.";
                FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.Click);
                Keyboard.SendKeys("^R");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Field Definitions")]
        public void FMUC0043_REG0004()
        {
            try
            {
                Reports.TestDescription = "FD: Field Definitions";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType FileFormType = _CreateFile();
                #endregion

                #region Verify the Field with lower Boundary Value.

                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.GABcode.FASetText("HUDFLINSR");
                FastDriver.InspectionRepairPest.GABcode.SendKeys(FAKeys.Tab);
                Support.AreEqual("HUDFLINSR", FastDriver.InspectionRepairPest.GABcode.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Name.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789");
                FastDriver.InspectionRepairPest.Name.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789", FastDriver.InspectionRepairPest.Name.FAGetValue().Trim());


                FastDriver.InspectionRepairPest.Edit.FASetCheckbox(true);

                FastDriver.InspectionRepairPest.BusPhone.FASetText("123456789");
                FastDriver.InspectionRepairPest.BusPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.InspectionRepairPest.BusPhone.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.BusFax.FASetText("123456789");
                FastDriver.InspectionRepairPest.BusFax.SendKeys(FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.InspectionRepairPest.BusFax.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.CellPhone.FASetText("123456789");
                FastDriver.InspectionRepairPest.CellPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.InspectionRepairPest.CellPhone.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Pager.FASetText("123456789");
                FastDriver.InspectionRepairPest.Pager.SendKeys(FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.InspectionRepairPest.Pager.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.EmailAddress.FASetText("test.test");
                FastDriver.InspectionRepairPest.EmailAddress.SendKeys(FAKeys.Tab);
                Support.AreEqual("?", FastDriver.InspectionRepairPest.EmailAddress.FAGetValue().Trim());

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                #endregion

                #region Verify the Field with lower Boundary Value.
                Reports.TestStep = "Verify the Field with lower Boundary Value.";

                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
     
                FastDriver.InspectionRepairPest.EditName.FASetCheckbox(true);

                FastDriver.InspectionRepairPest.NameEdit.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456");
                FastDriver.InspectionRepairPest.NameEdit.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456", FastDriver.InspectionRepairPest.NameEdit.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Reference.FASetText("0123456789012345678901234567890123456789012345678");
                FastDriver.InspectionRepairPest.Reference.SendKeys(FAKeys.Tab);
                Support.AreEqual("0123456789012345678901234567890123456789012345678", FastDriver.InspectionRepairPest.Reference.FAGetValue().Trim());

                Support.AreEqual("Buyer Seller Other", FastDriver.InspectionRepairPest.FurnishedBy.FAGetText().Trim());

                FastDriver.InspectionRepairPest.WithinDays.FASetText("1000");
                FastDriver.InspectionRepairPest.WithinDays.SendKeys(FAKeys.Tab);
                Support.AreEqual("100", FastDriver.InspectionRepairPest.WithinDays.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.description.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH");
                FastDriver.InspectionRepairPest.description.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.InspectionRepairPest.description.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.BuyerCharge.SendKeys("99999999999.99");
                FastDriver.InspectionRepairPest.SellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue());

                FastDriver.InspectionRepairPest.GFEAmount.SendKeys("99999999999.99");
                FastDriver.InspectionRepairPest.BuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.InspectionRepairPest.GFEAmount.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.SellerCharge.SendKeys("99999999999.99");
                FastDriver.InspectionRepairPest.GFEAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.InspectionRepairPest.SellerCharge.FAGetValue().Trim());

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                #endregion

                #region Verify the Field with Exact Value.
                Reports.TestStep = "Verify the Field with Exact Value.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.GABcode.FASetText("HUDFLINSR1");
                FastDriver.InspectionRepairPest.GABcode.SendKeys(FAKeys.Tab);
                Support.AreEqual("HUDFLINSR1", FastDriver.InspectionRepairPest.GABcode.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Name.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890");
                FastDriver.InspectionRepairPest.Name.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.InspectionRepairPest.Name.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Edit.FASetCheckbox(true);

                FastDriver.InspectionRepairPest.BusPhone.FASetText("1234567899");
                FastDriver.InspectionRepairPest.BusPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.InspectionRepairPest.BusPhone.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.BusFax.FASetText("1234567899");
                FastDriver.InspectionRepairPest.BusFax.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.InspectionRepairPest.BusFax.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.CellPhone.FASetText("1234567899");
                FastDriver.InspectionRepairPest.CellPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.InspectionRepairPest.CellPhone.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Pager.FASetText("1234567899");
                FastDriver.InspectionRepairPest.Pager.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.InspectionRepairPest.Pager.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.EmailAddress.FASetText("test@test.com");
                FastDriver.InspectionRepairPest.EmailAddress.SendKeys(FAKeys.Tab);
                Support.AreEqual("test@test.com", FastDriver.InspectionRepairPest.EmailAddress.FAGetValue().Trim());
                
                FastDriver.InspectionRepairPest.EditName.FASetCheckbox(true);

                FastDriver.InspectionRepairPest.NameEdit.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567");
                FastDriver.InspectionRepairPest.NameEdit.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.InspectionRepairPest.NameEdit.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Reference.FASetText("01234567890123456789012345678901234567890123456789");
                FastDriver.InspectionRepairPest.Reference.SendKeys(FAKeys.Tab);
                Support.AreEqual("01234567890123456789012345678901234567890123456789", FastDriver.InspectionRepairPest.Reference.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.description.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI");
                FastDriver.InspectionRepairPest.description.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.InspectionRepairPest.description.FAGetValue().Trim());
                                
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                #endregion

                #region Verify the Field with Upper Boundary Value
                Reports.TestStep = "Verify the Field with Upper Boundary Value.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.GABcode.FASetText("HUDFLINSR12");
                FastDriver.InspectionRepairPest.GABcode.SendKeys(FAKeys.Tab);
                Support.AreEqual("HUDFLINSR1", FastDriver.InspectionRepairPest.GABcode.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Name.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ12345678901");
                FastDriver.InspectionRepairPest.Name.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.InspectionRepairPest.Name.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Edit.FASetCheckbox(true);

                FastDriver.InspectionRepairPest.BusPhone.FASetText("12345678999");
                FastDriver.InspectionRepairPest.BusPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.InspectionRepairPest.BusPhone.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.BusFax.FASetText("12345678999");
                FastDriver.InspectionRepairPest.BusFax.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.InspectionRepairPest.BusFax.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.CellPhone.FASetText("12345678999");
                FastDriver.InspectionRepairPest.CellPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.InspectionRepairPest.CellPhone.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Pager.FASetText("12345678999");
                FastDriver.InspectionRepairPest.Pager.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.InspectionRepairPest.Pager.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.EmailAddress.FASetText("test@test.com");
                FastDriver.InspectionRepairPest.EmailAddress.SendKeys(FAKeys.Tab);
                Support.AreEqual("test@test.com", FastDriver.InspectionRepairPest.EmailAddress.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.EditName.FASetCheckbox(true);

                FastDriver.InspectionRepairPest.NameEdit.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678");
                FastDriver.InspectionRepairPest.NameEdit.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.InspectionRepairPest.NameEdit.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.Reference.FASetText("012345678901234567890123456789012345678901234567890");
                FastDriver.InspectionRepairPest.Reference.SendKeys(FAKeys.Tab);
                Support.AreEqual("01234567890123456789012345678901234567890123456789", FastDriver.InspectionRepairPest.Reference.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.description.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ");
                FastDriver.InspectionRepairPest.description.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.InspectionRepairPest.description.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("10000000000000000");
                FastDriver.InspectionRepairPest.BuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("?", FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue());

                FastDriver.InspectionRepairPest.GFEAmount.FASetText("10000000000000000");
                FastDriver.InspectionRepairPest.GFEAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("?", FastDriver.InspectionRepairPest.GFEAmount.FAGetValue().Trim());

                FastDriver.InspectionRepairPest.SellerCharge.FASetText("10000000000000000");
                FastDriver.InspectionRepairPest.SellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("?", FastDriver.InspectionRepairPest.SellerCharge.FAGetValue().Trim());

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region PRIVATE METHODS

        private void SwitchToTitleFrame() {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            FastDriver.WebDriver.SwitchTo().Frame("fraTitle");
        }

        private FormType _CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = _GetCurrentFileFormType();
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.LiabilityAmount = 5000;

            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            #region CreateNewLoan
            var newLoan = new NewLoanParameters()
            {
                Type = "",
                Amount = "",
                GABCode = "247"
            };
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.FillNewLoanForm(newLoan);
            FastDriver.NewLoan.ClickRecapTab();
            FastDriver.NewLoan.WaitForRecapToLoad();
            #endregion

            return customizableFileRequest.formType;
        }

        public void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        public void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }

        public bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private FormType _GetCurrentFileFormType()
        {
            return AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }
}
