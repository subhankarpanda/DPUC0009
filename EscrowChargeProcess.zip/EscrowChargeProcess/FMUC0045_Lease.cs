﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using OpenQA.Selenium;
using System.Linq;
using SeleniumInternalHelpers;
using FASTWCFHelpers.FastFileService;
namespace EscrowChargeProcess
{

    [CodedUITest]
    public class FMUC0045_Lease : MasterTestClass
    {
        // CreateFileRequest fileRequest = RequestFactory.GetCreateFileDefaultRequest();
        #region BAT

        [TestMethod]
        public void FMUC0045_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Open Fast application and create an order.";
                this.Login();
                //Merged with the next Test Case as this only creates a Order;
                Reports.TestStep = "Test Case Merged";
                Reports.StatusUpdate("This test was merged with the next one as this only creates an order", true);

            }

            catch (Exception e)
            {
                Reports.StatusUpdate("This test was merged with the next one as this only creates an order", true);

            }
        }
        [TestMethod]
        public void FMUC0045_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF3_01: Navigate to Lease screen and Cancel 1st New Lease Instance Creation.";

                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Navigate to Lease detail screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");

                //
                //
                Reports.TestStep = "Create another instance and click on cancel button.";
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                FastDriver.BottomFrame.Cancel();
                Playback.Wait(3000);
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }

        }

        [TestMethod]
        public void FMUC0045_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF1_01: Navigate to Lease screen and create first instance.";
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Navigate to Lease detail screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");

                //
                //
                Reports.TestStep = "Set an instance of the Lease Details.";
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                // 
                // 
                Reports.TestStep = "Enter payment details for Lease.";
                this.FillPaymentDetailsDialog(description: "Sanity-LEASE", BuyerCharge: "5.99", SellerCharge: "5.99", PaidbyBuyerAtClosing: "5.99", PaidbySellerAtClosing: "5.99");

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_BAT0004()
        {
            try
            {
                Reports.TestDescription = "MF1_02: Validate the data in Lease screen.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Click on Payment details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                //
                //
                Reports.TestStep = "Enter payment details for Lease.";
                this.FillPaymentDetailsDialog(BuyerCharge: "$5.99", SellerCharge: "$5.99", PaidbyBuyerAtClosing: "$5.99", PaidbySellerAtClosing: "$5.99");

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_BAT0005()
        {
            try
            {
                Reports.TestDescription = "MF1_03: Change the Description and charge, saves the changes. Validate the changed description and charge.";
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Fill in description and charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen and change the description and charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc2");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("12.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("13.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");

                //
                //
                Reports.TestStep = "Validate the description and charge in lease screen after Change .";

                Support.AreEqual("Changed desc2", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("12.00", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("13.00", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF4_01: Cancel 2nd New Lease Instance Creation.";

                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Create another instance and click on cancel button.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc2");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                FastDriver.BottomFrame.Cancel();
                Playback.Wait(3000);
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0045_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF4_02: Validate that first instance screen is loaded.";
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Create another instance and click on cancel button.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc2");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                FastDriver.BottomFrame.Cancel();
                Playback.Wait(3000);
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "Validate the description and charge in lease screen after Change .";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                Support.AreEqual("Changed desc1", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("10.00", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("11.00", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF1_01: Creates another instance and navigate to lease summary screen.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Create another instance and click on cancel button.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc2");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                FastDriver.BottomFrame.Cancel();
                Playback.Wait(3000);
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                Playback.Wait(5000);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 2 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                Playback.Wait(2000);

                //
                //
                Reports.TestStep = "validate the 2nd instance.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                Support.AreEqual("2nd Instance", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("11.00", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("12.00", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                //
                //
                Reports.TestStep = "Validate that summary screen is loaded after Create another instance.";
                FastDriver.LeaseSummary.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.LeaseSummary.New.Displayed.ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF1_01: Creates another instance and navigate to lease summary screen.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Create another instance and click on cancel button.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc2");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                FastDriver.BottomFrame.Cancel();
                Playback.Wait(3000);
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                Playback.Wait(5000);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 2 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                Playback.Wait(2000);

                //
                //
                Reports.TestStep = "validate the 2nd instance.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                Support.AreEqual("2nd Instance", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("11.00", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("12.00", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());
                FastDriver.BottomFrame.Done();
                Playback.Wait(200);
                //
                //BAT0009
                Reports.TestStep = "Select any instance.";
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.New, 10);
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 3 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();

                //
                //
                Reports.TestStep = "Validate the description and charge in lease screen after Change .";
                Support.AreEqual("Changed desc1", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("10.00", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("11.00", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());

                //
                //
                Reports.TestStep = "Edit the instance.";
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Validate File balance summary after changing the amount.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                Support.AreEqual("5,022.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.Text.Trim());
                Support.AreEqual("5,022.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Trim());



            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_BAT0010()
        {
            try
            {
                Reports.TestDescription = "AF1_01: Creates another instance and navigate to lease summary screen.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Create another instance and click on cancel button.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc2");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                FastDriver.BottomFrame.Cancel();
                Playback.Wait(3000);
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                Playback.Wait(5000);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 2 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                Playback.Wait(2000);

                //
                //
                Reports.TestStep = "validate the 2nd instance.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                Support.AreEqual("2nd Instance", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("11.00", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("12.00", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());
                FastDriver.BottomFrame.Done();
                Playback.Wait(200);
                //
                //BAT0009
                Reports.TestStep = "Select any instance.";
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.New, 10);
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 3 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();

                //
                //
                Reports.TestStep = "Validate the description and charge in lease screen after Change .";
                Support.AreEqual("Changed desc1", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("10.00", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("11.00", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());

                //
                //
                Reports.TestStep = "Edit the instance.";
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Validate File balance summary after changing the amount.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                Support.AreEqual("5,022.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.Text.Trim());
                Support.AreEqual("5,022.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Trim());

                //
                //
                Reports.TestStep = "Select any instance.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.New, 10);
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 3 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                //
                //
                Reports.TestStep = "validate the 2nd instance.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                Support.AreEqual("2nd Instance", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("11.00", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("12.00", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0045_BAT0011()
        {
            try
            {

                Reports.TestDescription = "AF2_01: Select one instance and click on Delete.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                Playback.Wait(500);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);
                ;


                // 
                // 
                Reports.TestStep = "Select an instance and click on Delete.";
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 2 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Remove.FAClick();
                Playback.Wait(2000);

                //
                //
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0045_BAT0012()
        {
            try
            {
                //
                //
                Reports.TestDescription = "AF2_02: Validate that Available is displayed in summary screen and no value is present in detail screen.";

                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                Playback.Wait(500);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);

                // 
                // 
                Reports.TestStep = "Select an instance and click on Delete.";
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 2 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Remove.FAClick();
                Playback.Wait(2000);

                //
                //
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "Validate in the summary screen that available is shown after Delete an instance.";
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.New, 10);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                Support.AreEqual("Rent/Lease Payment Due", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0045_BAT0013()
        {
            try
            {
                Reports.TestDescription = "AF5_01: Cancel 3rd New Lease Instance Creation.";
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                Playback.Wait(500);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);

                //
                //
                Reports.TestStep = "Create 3rd instance and click on cancel button.";
                FastDriver.LeaseSummary.New.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Cancel 2nd");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                FastDriver.BottomFrame.Cancel();

                //
                //
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0045_BAT0014()
        {
            try
            {
                Reports.TestDescription = "AF5_02: Validate that summary screen is loaded.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                Playback.Wait(500);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);

                //
                //
                Reports.TestStep = "Create 3rd instance and click on cancel button.";
                FastDriver.LeaseSummary.New.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Cancel 2nd");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                FastDriver.BottomFrame.Cancel();

                //
                //
                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "Validate that cancelled instance does not appear in summary screen.";
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.New, 10);
                int rowCount = FastDriver.LeaseSummary.SummaryTable.GetRowCount();
                Support.AreEqual("3", rowCount.ToString());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_BAT0015()
        {
            try
            {
                Reports.TestDescription = "AF6_01: Change the Description and charge, cancel the changes. Validate the changed description and charge.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                Playback.Wait(500);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);

                //
                //
                Reports.TestStep = "Select any instance.";
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 3 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();

                //
                //
                Reports.TestStep = "Cancel the edition of an instance.";
                FastDriver.LeaseDetail.ChargeDescription.FASetText("change desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.01");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.01");
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0045_BAT0016()
        {
            try
            {
                Reports.TestDescription = "AF6_02: Validate the changes does not reflect in cancellation in edited instance.";
                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "Fill data";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                Playback.Wait(500);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(1500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                //
                //
                Reports.TestStep = "Auto Save details entered by navigating again to the screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);

                //
                //
                Reports.TestStep = "Select any instance.";
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 2 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();

                //
                //
                Reports.TestStep = "Cancel the edition of an instance.";
                FastDriver.LeaseDetail.ChargeDescription.FASetText("change desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.01");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.01");
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "validate the 2nd instance.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                Support.AreEqual("2nd Instance", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Trim());
                Support.AreEqual("11.00", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("12.00", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Trim());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        #endregion


        #region REGRESSION

        [TestMethod]
        public void FMUC0045_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM1837_FM2529_FM2530_FM2531_FM2532: 1:Lease 2:Required Data 3:Display Payment Details 4:Display Check Details 5:Enter Charges";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Set an instance of the Lease Details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(500);
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                //
                //
                Reports.TestStep = "Enter payment details for Lease.";
                this.FillPaymentDetailsDialog(description: "Sanity-LEASE", BuyerCharge: "5.99", SellerCharge: "5.99", PaidbyBuyerAtClosing: "5.99", PaidbySellerAtClosing: "5.99");

                //
                //
                Reports.TestStep = "Click on Payment details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                //
                //
                Reports.TestStep = "Validate payment details for Lease.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                Support.AreEqual("Sanity-LEASE", FastDriver.PaymentDetailsDlg.Description.GetAttribute("value").Trim());
                Support.AreEqual("$5.99", FastDriver.PaymentDetailsDlg.BuyerCharge.GetAttribute("value").Trim());
                Support.AreEqual("$5.99", FastDriver.PaymentDetailsDlg.SellerCharge.GetAttribute("value").Trim());
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PaymentDetailsDlg.SwitchToContentFrame();

                //
                //
                Reports.TestStep = "Change the description and charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(500);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("change desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                //
                //
                Reports.TestStep = "Click on Check details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.CheckDetails.FAClick();
                Playback.Wait(300);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail", timeoutSeconds: 10);
                //Playback.Wait(1000000000);
                //
                //
                Reports.TestStep = "Edit Description for Lease.";
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.Description.FASetText("Description for Lease");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Check Voucher info for Lease Regression");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                //
                //
                Reports.TestStep = "Click on Find To Enter Gab Through Address Book Search.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.Find.FAClick();

                //
                //
                Reports.TestStep = "Set an Homeowner Association id from Global address book.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address");
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("HOA1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                Playback.Wait(3000);
                if (!FastDriver.AddressBookSearchDlg.SearchResultsRadio.Selected)
                    FastDriver.AddressBookSearchDlg.SearchResultsRadio.FAClick();
                //
                //
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                //
                //
                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM2040_FM2533_EWC1_EWC3_EWC4_EWC5_EWC7: 1:Lease Details 2:Display Check Amounts 3:User deletes a charge process instance that has issued checks. 4:User tries to delete a charge description that has a charge amount. 5:Use";
                Reports.TestStep = "Login to Fast";
                this.Login();

                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                Reports.TestStep = "Set an instance of the Lease Details with charge and Lease Amount and Reference No.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(1000);
                FastDriver.LeaseDetail.Reference.FASetText("9585655");
                FastDriver.LeaseDetail.LeaseAmount.FASetText("500.00");
                FastDriver.LeaseDetail.Per.FASelectItem("Month");
                FastDriver.LeaseDetail.For.FASetText("10");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("#");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("20.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("20.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("Check Amount: $ 40.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim());

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                if (FastDriver.PasswordConfirmationDlg.Password.Exists())
                {
                    try
                    {
                        FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad(FastDriver.PasswordConfirmationDlg.Password);
                        FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    }
                    catch (Exception)
                    {
                        Reports.StatusUpdate("Passwordconfirmationdlg failed", false);
                    }
                }
                //bool overdraftConfirmationDlgExist = false;
                else
                {
                    try
                    {
                        FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                        //overdraftConfirmationDlgExist = true;
                    }
                    catch (Exception) { }
                   // if (overdraftConfirmationDlgExist)
                        FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();

                    FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 200);
                }
                Reports.TestStep = "Navigate to Lease detail screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Delete us Shortcut Keys.";
                FastDriver.BottomFrame.Delete();

                Reports.TestStep = "Delete The Payee have Issued Instance.";
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", message);

                Reports.TestStep = "Delete Charge Description Having Charges.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.ChargeDescription.FASetText("");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Delete Charge Description.";
                string message2 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", message2);

                Reports.TestStep = "Decrease Issued amount.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Enter Less Than the issued Amount.";
                string message3 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?", message3);

                Reports.TestStep = "Increase Issued amount.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.BuyerCharge.FASetText("50.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Enter Greater Than the Issued Amount.";
                string message4 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", message4);

                Reports.TestStep = "Click on Find To Enter Gab Through Address Book Search.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.Find.FAClick();

                Reports.TestStep = "Change Payee To whom check issued.";
                string message5 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("A check has been issued for this Payee.  The Payee name cannot be changed.", message5);

            }
            catch (Exception e)
            {
                FailTest(e.Message);

            }
        }
        [TestMethod]
        public void FMUC0045_REG0003()
        {
            try
            {
                Reports.TestDescription = "EWC6_8_9_10_11_12_13: 1:User cancels entry of the FIRST new instance using Cancel button on framework before saving a new process instance. 2:User cancels entry of the SECOND new instance using Cancel button on framework be";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Verify Invalid GAB ID.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("XCHZ");
                //Playback.Wait(400);
                // 
                // 
                Reports.TestStep = "ID Code Not Found.";
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("ID Code not found.", message.Clean());

                // 
                // 
                Reports.TestStep = "Edit the instance.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                Keyboard.SendKeys(FAKeys.TabAway);

                // 
                // 
                Reports.TestStep = "save Changes without Bus Party.";
                // Playback.Wait(200000);
                FastDriver.LeftFrame.SwitchToLeftNavigationPane();
                FastDriver.WebDriver.FindElement(By.LinkText("Home")).FAClick();
                //FastDriver.LeftNavigation.Navigate<LeftFrame>("Home");
                Playback.Wait(3000);
                string message2 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual("Error(s) occured. See Message pane.", message2.Trim());
                if (FastDriver.WebDriver.WaitForAlertToExist(120))
                    Reports.StatusUpdate(FastDriver.WebDriver.HandleDialogMessage().Clean(), true);
                else
                    Reports.StatusUpdate("Alert not Found!", false);

                // 
                // 
                Reports.TestStep = "Change the description and charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(300);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                // 
                // 
                Reports.TestStep = "Cancel us Shortcut Keys.";
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Cancel without save changes.";
                string message3 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Cancel without saving changes?", message3.Trim());

                //
                //
                Reports.TestStep = "Set an instance of the Lease Details with charge and Lease Amount and Reference No.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                Playback.Wait(300);
                FastDriver.LeaseDetail.Reference.FASetText("9585655");
                FastDriver.LeaseDetail.LeaseAmount.FASetText("500.00");
                FastDriver.LeaseDetail.Per.FASelectItem("Month");
                FastDriver.LeaseDetail.For.FASetText("10");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("#");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("20.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("20.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("Check Amount: $ 40.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim());

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Change Business Party Having Reference No.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDFLINSR1");

                //
                //
                Reports.TestStep = "Replace Gab code which has refrence number and verify message displayed.";
                string message4 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number. Do you want to retain the \"Reference\"/\"Loan\" Number?", message4.Clean());

                //
                //
                Reports.TestStep = "Reset us Shortcut Keys.";
                FastDriver.BottomFrame.Reset();
                Playback.Wait(3000);

                //
                //
                Reports.TestStep = "Cancel without save changes.";
                string message5 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Cancel without saving changes?", message5.Trim());

                // 
                // 
                Reports.TestStep = "Check Edit Name Check Box.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                if (!FastDriver.LeaseDetail.EditName.Selected)
                    FastDriver.LeaseDetail.EditName.FAClick();

                // 
                // 
                Reports.TestStep = "Enter Contact when Edit Name is checked.";
                //                FastDriver.LeftNavigation.Navigate<HomePage>("Home");
                FastDriver.LeftFrame.SwitchToLeftNavigationPane();
                FastDriver.WebDriver.FindElement(By.LinkText("Home")).FAClick();

                string message6 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual("Name field is required when Edit Name checkbox is selected.", message6.Trim());
                if (FastDriver.WebDriver.WaitForAlertToExist(120))
                    Reports.StatusUpdate(FastDriver.WebDriver.HandleDialogMessage().Clean(), true);
                else
                    Reports.StatusUpdate("Alert not Found!", false);

                // 
                // 
                Reports.TestStep = "Check Edit Name Check Box and Enter Edit Name.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                if (!FastDriver.LeaseDetail.EditName.Selected)
                    FastDriver.LeaseDetail.EditName.FAClick();
                FastDriver.LeaseDetail.NameEdit.FASetText("Edit Name");
                Playback.Wait(350);
                FastDriver.BottomFrame.Reset();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Cancel without save changes.";
                FastDriver.WebDriver.HandleDialogMessage();

                // 
                // 
                Reports.TestStep = "Delete us Shortcut Keys.";
                FastDriver.BottomFrame.Delete();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Delete us Shortcut Keys.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "EWC2: 1:User deletes a charge process instance that does not have issued checks.";

                //
                //
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create Basic Order";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(300);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                // 
                // 
                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                // 
                Reports.TestStep = "Navigate to Lease detail screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                FastDriver.LeaseDetail.WaitForScreenToLoad();

                //
                //
                Reports.TestStep = "Create 2nd instance.";
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(300);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("2nd Instance");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(300);

                // 
                // 
                Reports.TestStep = "Select an instance and use short cut key to Edit.";
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 2 for HUD Testing Name 1", "Name", TableAction.Click);
                Playback.Wait(200);
                Keyboard.SendKeys("%E");
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("247");
                Playback.Wait(300);
                Keyboard.SendKeys("^R");

                //
                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Select an instance and click on Delete.";
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Lease 2 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Remove.FAClick();

                // 
                // 
                Reports.TestStep = "Delete the Lease Payee not have Issued Checks.";
                string message1 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(" All information will be removed for this Lease. Continue? ".Clean(), message1.Clean());

                // 
                // 
                Reports.TestStep = "Verify for available.";
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Create 3rd instance and click on cancel button.";
                Playback.Wait(300);
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable);
                FastDriver.LeaseSummary.New.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(300);
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Cancel 2nd");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("11.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("12.00");
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Cancel without save changes.";
                string message2 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Cancel without saving changes?", message2.Clean());

                // 
                // 
                Reports.TestStep = "Verify Cancellation of third instance.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable);
                Support.AreEqual("3", FastDriver.LeaseSummary.SummaryTable.GetRowCount().ToString());

                // 
                // 
                Reports.TestStep = "Edit deleted instance.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("Lease");
                Playback.Wait(300);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Edit second instance.";
                FastDriver.LeaseSummary.SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "lease name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                Keyboard.SendKeys("^{DEL}");

                // 
                // 
                Reports.TestStep = "Delete the Lease Payee not have Issued Checks.";
                string message3 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("All information will be removed for this Lease. Continue?", message3.Clean());

                // 
                // 
                Reports.TestStep = "Verify for available.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Edit deleted instance.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("Lease");
                Playback.Wait(300);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Delete instance using shortkeys.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "lease name 1", "Name", TableAction.Click);
                FastDriver.LeaseSummary.Edit.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDFLINSR1");
                Playback.Wait(300);
                Keyboard.SendKeys("^{DEL}");


                // 
                // 
                Reports.TestStep = "Delete the Lease Payee not have Issued Checks.";
                string message4 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("All information will be removed for this Lease. Continue?".Clean(), message4.Clean());

                // 
                // 
                Reports.TestStep = "Verify for available.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                FastDriver.LeaseSummary.WaitCreation(FastDriver.LeaseSummary.SummaryTable, 10);
                FastDriver.LeaseSummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0045_REG0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FD: Field Definitions";

                //
                //
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Log into FAST application.";
                this.CreateFileWithWCF();

                //
                // 
                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.GABcode.FASetText("HUDFLINSR");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("HUDFLINSR", FastDriver.LeaseDetail.GABcode.GetAttribute("value").Clean());
                FastDriver.LeaseDetail.Name.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789");
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789", FastDriver.LeaseDetail.Name.GetAttribute("value").Clean());

                if (!FastDriver.LeaseDetail.Edit.Selected)
                    FastDriver.LeaseDetail.Edit.FAClick();

                FastDriver.LeaseDetail.BusPhone.FASetText("123456789");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(300);
                Support.AreEqual("(???)???-????", FastDriver.LeaseDetail.BusPhone.GetAttribute("value").Clean());

                Keyboard.SendKeys(FAKeys.TabAway);

                FastDriver.LeaseDetail.BusFax.FASetText("123456789");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(???)???-????", FastDriver.LeaseDetail.BusFax.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.CellPhone.FASetText("123456789");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(???)???-????", FastDriver.LeaseDetail.CellPhone.GetAttribute("value").Clean());


                FastDriver.LeaseDetail.Pager.FASetText("123456789");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(???)???-????", FastDriver.LeaseDetail.Pager.GetAttribute("value").Clean());


                FastDriver.LeaseDetail.EmailAddress.FASetText("test.test");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("?", FastDriver.LeaseDetail.EmailAddress.GetAttribute("value").Clean());

                FastDriver.BottomFrame.Cancel();
                Playback.Wait(1500);
                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(1500);

                // 
                // 
                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                //FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.SwitchToContentFrame();
                if (!FastDriver.LeaseDetail.Edit.Selected)
                    FastDriver.LeaseDetail.Edit.FAClick();

                if (!FastDriver.LeaseDetail.EditName.Selected)
                    FastDriver.LeaseDetail.EditName.FAClick();

                FastDriver.LeaseDetail.NameEdit.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456", FastDriver.LeaseDetail.NameEdit.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.Reference.FASetText("0123456789012345678901234567890123456789012345678");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("0123456789012345678901234567890123456789012345678", FastDriver.LeaseDetail.Reference.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.Reference.FASetText("0123456789012345678901234567890123456789012345678");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("0123456789012345678901234567890123456789012345678", FastDriver.LeaseDetail.Reference.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.LeaseAmount.FASetText("99999999999.99" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("99,999,999,999.99", FastDriver.LeaseDetail.LeaseAmount.GetAttribute("value").Clean());


                Support.AreEqual("Month Year", FastDriver.LeaseDetail.Per.Text.Clean());

                Keyboard.SendKeys(FAKeys.TabAway);

                //FastDriver.LeaseDetail.For.FASetText("999"+Keys.Delete + Keys.Delete);
                FastDriver.LeaseDetail.For.FAClick();
                while (!FastDriver.LeaseDetail.For.GetAttribute("value").Clean().Equals("999"))
                {
                    FastDriver.LeaseDetail.For.FAClick();
                    this.SlowSetText("999");
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("999".Clean(), FastDriver.LeaseDetail.For.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.ChargeDescription.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Clean());

                //FastDriver.LeaseDetail.BuyerCharge.FASetText("99999999999.99" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete+Keys.Delete);
                while (!FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Clean().Equals("99,999,999,999.99"))
                {
                    FastDriver.LeaseDetail.BuyerCharge.FAClick();
                    this.SlowSetText("99999999999.99");
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                Support.AreEqual("99,999,999,999.99", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Clean());

                //FastDriver.LeaseDetail.SellerCharge.FASetText("99999999999.99" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete+Keys.Delete);
                while (!FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Clean().Equals("99,999,999,999.99"))
                {
                    FastDriver.LeaseDetail.SellerCharge.FAClick();
                    this.SlowSetText("99999999999.99");
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("99,999,999,999.99", FastDriver.LeaseDetail.SellerCharge.GetAttribute("value").Clean());

                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "Verify the Field with Exact Value.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                FastDriver.LeaseDetail.GABcode.FASetText("HUDFLINSR1");
                Support.AreEqual("HUDFLINSR1", FastDriver.LeaseDetail.GABcode.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.Name.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890");
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.LeaseDetail.Name.GetAttribute("value").Clean());

                if (!FastDriver.LeaseDetail.Edit.Selected)
                    FastDriver.LeaseDetail.Edit.FAClick();

                FastDriver.LeaseDetail.BusPhone.FASetText("1234567899");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(123)456-7899", FastDriver.LeaseDetail.BusPhone.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.BusFax.FASetText("1234567899");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(123)456-7899", FastDriver.LeaseDetail.BusFax.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.CellPhone.FASetText("1234567899");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(123)456-7899", FastDriver.LeaseDetail.CellPhone.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.Pager.FASetText("1234567899");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(123)456-7899", FastDriver.LeaseDetail.Pager.GetAttribute("value").Clean());


                FastDriver.LeaseDetail.EmailAddress.FASetText("test@test.com");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("test@test.com", FastDriver.LeaseDetail.EmailAddress.GetAttribute("value").Clean());

                if (!FastDriver.LeaseDetail.EditName.Selected)
                    FastDriver.LeaseDetail.EditName.FAClick();

                FastDriver.LeaseDetail.NameEdit.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.LeaseDetail.NameEdit.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.Reference.FASetText("01234567890123456789012345678901234567890123456789");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("01234567890123456789012345678901234567890123456789", FastDriver.LeaseDetail.Reference.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.ChargeDescription.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Clean());

                FastDriver.BottomFrame.Cancel();
                Playback.Wait(3000);
                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                try
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                catch (Exception)
                {

                };

                // 
                // 
                Reports.TestStep = "Verify the Field with Upper Boundary Value.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                FastDriver.LeaseDetail.GABcode.FASetText("HUDFLINSR12");
                Support.AreEqual("HUDFLINSR1", FastDriver.LeaseDetail.GABcode.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.Name.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ12345678901");
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.LeaseDetail.Name.GetAttribute("value").Clean());

                if (!FastDriver.LeaseDetail.Edit.Selected)
                    FastDriver.LeaseDetail.Edit.FAClick();

                FastDriver.LeaseDetail.BusPhone.FASetText("12345678999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(123)456-7899", FastDriver.LeaseDetail.BusPhone.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.BusFax.FASetText("12345678999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(123)456-7899", FastDriver.LeaseDetail.BusFax.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.CellPhone.FASetText("12345678999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(123)456-7899", FastDriver.LeaseDetail.CellPhone.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.Pager.FASetText("12345678999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("(123)456-7899", FastDriver.LeaseDetail.Pager.GetAttribute("value").Clean());


                FastDriver.LeaseDetail.EmailAddress.FASetText("test@test.com");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("test@test.com", FastDriver.LeaseDetail.EmailAddress.GetAttribute("value").Clean());

                if (!FastDriver.LeaseDetail.EditName.Selected)
                    FastDriver.LeaseDetail.EditName.FAClick();

                FastDriver.LeaseDetail.NameEdit.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.LeaseDetail.NameEdit.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.Reference.FASetText("012345678901234567890123456789012345678901234567890");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("01234567890123456789012345678901234567890123456789", FastDriver.LeaseDetail.Reference.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.LeaseAmount.FASetText("10000000000000000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("?", FastDriver.LeaseDetail.LeaseAmount.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.For.FASetText("1000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("100", FastDriver.LeaseDetail.For.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.ChargeDescription.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.BuyerCharge.FASetText("10000000000000000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("?", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Clean());

                FastDriver.LeaseDetail.SellerCharge.FASetText("10000000000000000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("?", FastDriver.LeaseDetail.BuyerCharge.GetAttribute("value").Clean());

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion


        #region Custom Methods
        private void Login()
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            //
            //

            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
        }
        private void CreateFileWithWCF()
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }

        private void CreateFileWithWCF(CreateFileRequest fileRequest)
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }


        private void FillPaymentDetailsDialog(string BuyerCharge = "", string PaidbyBuyerAtClosing = "", string SellerCharge = "", string PaidbySellerAtClosing = "", string PaidbySellerBeforeClosing = "", string PaidbySellerOthers = "", string sellerCredit = "", string SellerPaidbyOthersPaymentMethod = "", string description = "", string useDefault = "", string payeeName = "", string SellerCreditPaymentMethod = "")
        {

            Playback.Wait(250);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
            FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

            if (!BuyerCharge.Equals(""))
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(BuyerCharge);

            if (!SellerCharge.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(SellerCharge);

            if (!PaidbyBuyerAtClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(PaidbyBuyerAtClosing);

            if (!PaidbySellerAtClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(PaidbySellerAtClosing);

            if (!PaidbySellerBeforeClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(PaidbySellerBeforeClosing);

            if (!PaidbySellerOthers.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(PaidbySellerOthers);

            if (!sellerCredit.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText(sellerCredit);

            if (!SellerPaidbyOthersPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(SellerPaidbyOthersPaymentMethod);

            if (!SellerCreditPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem(SellerCreditPaymentMethod);


            if (!description.Equals(""))
                FastDriver.PaymentDetailsDlg.Description.FASetText(description);

            if (!useDefault.Equals("") && useDefault == true.ToString())
            {
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(true);
            }

            else if (!useDefault.Equals("") && useDefault == false.ToString())
            {
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
            }

            if (payeeName.Equals("EMPTY"))
            { FastDriver.PaymentDetailsDlg.PayeeName.FASetText(""); }

            else if (!payeeName.Equals(""))
            { FastDriver.PaymentDetailsDlg.PayeeName.FASetText(payeeName); }

            //closes the dialog window and switches back to the Fast window;
            FastDriver.PaymentDetailsNewLoanDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.btnDone.FAClick();
            Playback.Wait(500);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.PaymentDetailsDlg.SwitchToContentFrame();

        }

        private void SlowSetText(string textToSet, int miliSeconds = 250)
        {
            char[] arrayOfChar = textToSet.ToCharArray();
            foreach (char c in arrayOfChar)
            {
                Keyboard.SendKeys(c.ToString());
                Playback.Wait(miliSeconds);
            }

        }

        # endregion custom methods

        #region Class CleanUp
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
        #endregion Class Cleanup

}



