﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using System.Collections.Generic;


namespace EscrowChargeProcess
{
    [CodedUITest]
    public class FMUC0055_HoldFunds : MasterTestClass
    {
        #region BAT

        #region FMUC0055_BAT0001
        [TestMethod]
        public void FMUC0055_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF_001_AF_002: Add a Hold Funds Instance, Enter Hold Funds Disbursements details.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify the loading of Hold Fund Screen.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.HoldFunds.ReleaseinDays.FAGetValue().Clean(), true);
                Support.AreEqual("", FastDriver.HoldFunds.DateDaysOn.FAGetValue().Clean(), true);
                Support.AreEqual("True", FastDriver.HoldFunds.New.Exists().ToString(), true);
                Support.AreEqual("True", FastDriver.HoldFunds.Remove.Exists().ToString(), true);

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Fund Instance.");
                //FastDriver.HoldFunds.ReleaseinDays.FASetText("7" + FAKeys.Tab);
                
                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Desc" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("4.00" + FAKeys.Tab);

                Reports.TestStep = "Verify for the Recap Section and Payee Information.";
                Support.AreEqual("4.00", FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 6, TableAction.GetText).Message.Clean(), true);

                Reports.TestStep = "Validate held amount in FBS.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("6.00", FastDriver.EscrowFileBalanceSummary.FundsHeldAfterCloseSeller.FAGetText(), true);
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_BAT0001

        #region FMUC0055_BAT0002
        [TestMethod]
        public void FMUC0055_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF_001: Edit Hold Funds Instance.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Edit Hold Fund data.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Edited - Reason For Hold Fund.");
                FastDriver.HoldFunds.SellerCharge.FASetText("4.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Desc" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("4.00" + FAKeys.Tab);

                Reports.TestStep = "Verify for the Data Edited in Recap Section and Payee Information.";
                Support.AreEqual("4.00", FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 6, TableAction.GetText).Message.Clean(), true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate File balance summary after enter Held Fund.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("4.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText(), true);
                Support.AreEqual("4.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_BAT0002

        #region FMUC0055_BAT0003
        [TestMethod]
        public void FMUC0055_BAT0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF_003: Complete Hold Funds Release.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Edited - Reason For Hold Fund.");
                FastDriver.HoldFunds.SellerCharge.FASetText("4.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Desc" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("4.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Making a cash deposit to avoid overdraft confirmation message.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                var deposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                try
                {
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                catch
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.PrintChecks.SwitchToContentFrame();
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Verify for the Released date After Issuing the Hold Fund.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToString("M-d-yyyy"), FastDriver.HoldFunds.ReleaseDate.FAGetText(), true);

                Reports.TestStep = "Click on Delete.";
                FastDriver.BottomFrame.Delete();

                Reports.TestStep = "Validate warning message.";
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_BAT0003

        #region FMUC0055_BAT0004
        [TestMethod]
        public void FMUC0055_BAT0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF_005: Cancel 1st New Hold Funds Instance Creation.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Fund Instance.");
                //FastDriver.HoldFunds.ReleaseinDays.FASetText("7" + FAKeys.Tab);

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Description" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);

                Reports.TestStep = "Cancel First Hold Fund Instance.";
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Validate Cancel without save changes.";
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);

                Reports.TestStep = "Validate seller charge is removed.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                Support.AreEqual("0.00", FastDriver.HoldFunds.SellerCharge.FAGetValue(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_BAT0004

        #region FMUC0055_BAT0005
        [TestMethod]
        public void FMUC0055_BAT0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF_006_004: Cancel 2nd New Hold Funds Instance Creation.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create first Hold Funds instance";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Fund Instance.");
                //FastDriver.HoldFunds.ReleaseinDays.FASetText("7" + FAKeys.Tab);

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Description" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);

                Reports.TestStep = "Create second Hold Funds instance.";
                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Description" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);

                Reports.TestStep = "Cancel Second Hold Fund Instance.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                Reports.TestStep = "Validate first Hold Fund instance display.";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual("10.00", FastDriver.HoldFunds.SellerCharge.FAGetValue(), true);


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_BAT0005

        #region FMUC0055_BAT0006
        // Remove this test case, same was done in FMUC0055_BAT0005
        #endregion FMUC0055_BAT0006

        #region FMUC0055_BAT0007
        [TestMethod]
        public void FMUC0055_BAT0007()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF_008: Cancel Changes to Existing Hold Funds Instance.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create first Hold Funds instance";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Fund Instance.");
                //FastDriver.HoldFunds.ReleaseinDays.FASetText("7" + FAKeys.Tab);

                Reports.TestStep = "Enter Data on Hold Fund Screen.";
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Description" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);

                Reports.TestStep = "Create second Hold Funds instance.";
                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Description" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit the second Hold Funds instance.";
                FastDriver.HoldFundsSummary.WaitForScreenToLoad();
                FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.HoldFundsSummary.Edit.FAClick();
                FastDriver.HoldFunds.WaitForScreenToLoad();

                Reports.TestStep = "Edit seller charge amount"; 
                FastDriver.HoldFunds.SellerCharge.FASetText("20.00" + FAKeys.Tab);

                Reports.TestStep = "Click Reset button and verify seller charge reverted to original value.";
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual("10.00", FastDriver.HoldFunds.SellerCharge.FAGetValue(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_BAT0007

        #endregion BAT

        #region Regression

        #region FMUC0055_REG0001
        [TestMethod]
        public void FMUC0055_REG0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM2117_FM1550_FM2479_FM2630_FM3769_FM2480_FM1553_FM1560_FM1559_EWC13_EWC01_EWC02: Required Data for Hold Funds, Enter Hold Fund Reason, Select Buyer/Seller Charge, Disable Other Party Chg Fields, clear Held Amount if Use";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create first Hold Funds instance";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Fund Instance.");
                FastDriver.HoldFunds.ReleaseinDays.FASetText("1" + FAKeys.Tab);

                Reports.TestStep = "Verify For the error Held Amount is Required.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual("HeldAmount: Held Amount is Required", FastDriver.HoldFunds.MessagePanel.FAGetText().Clean(), true);

                Reports.TestStep = "Validating if Seller Radio Button in on Buyer Held Amount should be disabled.";
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Description" + FAKeys.Tab);
                Support.AreEqual("True", FastDriver.HoldFunds.HoldFundBuyerCharge1.IsReadOnly().ToString(), true);

                Reports.TestStep = "Complete the first Hold Funds instance";
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change the Enter Date.";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.Date.FASetText(DateTime.Now.AddDays(1).ToDateString() + FAKeys.Tab);
                Support.AreEqual("Do you wish to recalculate Estimated Release Date ?", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

                Reports.TestStep = "Validate Days on equal Date + Release In day.";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.AddDays(2).ToDateString(), FastDriver.HoldFunds.DateDaysOn.FAGetValue(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0001

        #region FMUC0055_REG0002
        [TestMethod]
        public void FMUC0055_REG0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM1551_FM1552_FM2402_FM2401_FM2400_EWC1_EWC2: Enter Number of Days, Calculate Days On Date, Edit Number of Days, Recalculate Days On Date, User changes the Hold Funds entry date after calculating the Estimated Release date";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create first Hold Funds instance";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Fund Instance.");
                FastDriver.HoldFunds.ReleaseinDays.FASetText("1" + FAKeys.Tab);

                Reports.TestStep = "Increase the release in day then validate the days on date";
                FastDriver.HoldFunds.ReleaseinDays.FASetText("2" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.AddDays(2).ToDateString(), FastDriver.HoldFunds.DateDaysOn.FAGetValue(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0002

        #region FMUC0055_REG0003
        [TestMethod]
        public void FMUC0055_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM1549_FM2398_FM2397: Add a New Hold Funds Instance, Display Entry Recap, Display Hold Funds Summary.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Enter Charges to check Total release for seller amount.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Seller to Check Total release for seller.");
                //FastDriver.HoldFunds.ReleaseinDays.FASetText("1" + FAKeys.Tab);
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Desc" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("4.00" + FAKeys.Tab);

                Reports.TestStep = "Verify for the Total release for seller amount.";
                Support.AreEqual("4.00", FastDriver.HoldFunds.TotalReleasedForSeller.FAGetText().Clean(), true);

                Reports.TestStep = "Create second Hold Funds instance.";
                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.Agreement.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Fund Description" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Hold Funds Summary table header.";
                FastDriver.HoldFundsSummary.WaitForScreenToLoad();
                Support.AreEqual("#", FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Reason", FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Held From", FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Amount Remaining", FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(1, 4, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Est.Release", FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Actual Release", FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean(), true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0003

        #region FMUC0055_REG0004
        [TestMethod]
        public void FMUC0055_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM3769_FM1556_FM2496_FM1566_FM2409_FM1567: Disbursement Payee Name is Required Release Funds No Payment Details Update Ent RecapAmt Remaining_CHK Payment Method_Update Entry Recap Funds Held.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Enter Charges to check Total release for seller amount.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Seller to Check Total release for seller.");
                //FastDriver.HoldFunds.ReleaseinDays.FASetText("1" + FAKeys.Tab);
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller." + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("6.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verified for the Business party required Error.";
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual("BusOrgID: Business Party required", FastDriver.HoldFunds.BusOrgIDBussPartyrequired.FAGetText().Clean(), true);
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                string GABName = FastDriver.HoldFunds.GABName.FAGetText() + " " + FastDriver.HoldFunds.GABNameLine2.FAGetText();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for the Pending Check and Payee Name For the Hold Fund.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "6.00", 1, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual("Check", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "6.00", 3, TableAction.GetText).Message.Clean(), true);
                Support.AreEqual(GABName, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "6.00", 8, TableAction.GetText).Message.Clean(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0004

        #region FMUC0055_REG0005
        [TestMethod]
        public void FMUC0055_REG0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM2407_FM2405_FM1557_EWC12: Update Check Amount_Total Released Not to Exceed_Multiple Charges Per Payee_User enters an Amount Released payee charge that causes total Amount Released to exceed Held Amount.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Enter seller amount so that Release amount exceeds the total Seller amount.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Seller to Check Total release for seller.");
                //FastDriver.HoldFunds.ReleaseinDays.FASetText("1" + FAKeys.Tab);
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller." + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("11.00" + FAKeys.Tab);

                Reports.TestStep = "Validate message: Total Seller Amount Released cannot exceed Total Seller Amount Held.";
                Support.AreEqual("Total Seller Amount Released cannot exceed Total Seller Amount Held.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                
                Reports.TestStep = "Complete the transaction.";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0005

        #region FMUC0055_REG0006
        [TestMethod]
        public void FMUC0055_REG0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM2408: Create Pending Disbursement.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a new instance of Hold Funds.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Seller to Check Total release for seller.");
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller." + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Hold Fund Payee and Click on Edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "10.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Validate that Wire instructions are same as in business party org setup.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys("Wire");
                Support.AreEqual("", FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue(), true);
                Support.AreEqual("", FastDriver.EditDisbursement.ReceivingBankName.FAGetValue(), true);
                Support.AreEqual("", FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue(), true);
                Support.AreEqual("", FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue(), true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Select the Seller Charge and Click on Edit.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.HoldFunds.CheckDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail", true, 20);
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.CheckDetailsDlg.Description.FASetText("Edited Check Details Description.");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Edited Check Details Voucher Information.");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Hold Fund Payee and Click on Edit and validate voucher description";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "10.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Edited Check Details Description.", FastDriver.EditDisbursement.VoucherDescription.FAGetValue().Clean(), true);
                Support.AreEqual("Edited Check Details Voucher Information.", FastDriver.EditDisbursement.VoucherMemo.FAGetValue().Clean(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0006

        #region FMUC0055_REG0007
        [TestMethod]
        public void FMUC0055_REG0007()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM1562_FM2416_FM2634_FM4383_FM2417_EWC4_EWC14_EWC15";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Create a new instance of Hold Funds.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Seller to Check Total release for seller.");
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller - first instance" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);

                Reports.TestStep = "FM1562: Create multiple payee per Hold Funds instance.";
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller - second instance" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("11.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM2416: Remove a payee from a Hold Funds instance";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.HoldFunds.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                Reports.TestStep = "FM2634	Prevent Payee Removal if check already issued.";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller - second instance" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("11.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Making a cash deposit to avoid overdraft confirmation message.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                var deposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "11.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                try
                {
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                catch
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.PrintChecks.SwitchToContentFrame();
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.HoldFunds.Remove.FAClick();
                Support.AreEqual("Unable to Remove Disbursement. Check has been issued. You must cancel check before removing payee.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                FastDriver.HoldFunds.WaitForScreenToLoad();

                Reports.TestStep = "FM4383: Prevent Amount Released Deletion";
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("0.00" + FAKeys.Tab);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                FastDriver.HoldFunds.WaitForScreenToLoad();

                Reports.TestStep = "FM2417: Delete a Released Amount";
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("0.00" + FAKeys.Tab);
                Support.AreEqual("100.00", FastDriver.HoldFunds.SellerCurrentHeldTotal.FAGetText(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0007

        #region FMUC0055_REG0008
        [TestMethod]
        public void FMUC0055_REG0008()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM1558_FM2411_FM2412_FM4207_FM4379_FM2608_FM1571_FM2481: Insert Actual Release Date Prevent Further Charge Entry Prevent Further Payee Entry Prevent Disbursement Editing When Release Date Present Remove Release Date if C";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "FM1558: When all Hold Funds Disbursement checks totaling the Held Amount are in Issued status in Active Disbursement Summary, the system will insert the current system date in the Release Date field.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Seller to Check Total release for seller.");
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller - first instance" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("20.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Making a cash deposit to avoid overdraft confirmation message.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                var deposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Print the check";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "20.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                try
                {
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                catch
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.PrintChecks.SwitchToContentFrame();
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Validate Release Date is populated with today's date.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToString("M-d-yyyy"), FastDriver.HoldFunds.ReleaseDate.FAGetText(), true);

                Reports.TestStep = "FM2411: The system will prevent further entry of new Amount Released charges when all payee checks have Issued status in Active Disbursement Summary and the Release Date is assigned.";
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                Support.AreEqual("True", FastDriver.HoldFunds.HoldFundSellerCharge1.IsReadOnly().ToString(), true);

                Reports.TestStep = "FM2412: The system will prevent further entry of new Disbursed To payees in the instance have Issued status in Active Disbursement Summary and the Release Date is assigned.";
                Support.AreEqual("False", FastDriver.HoldFunds.SellerCharge.Enabled.ToString(), true);

                Reports.TestStep = "FM4207: The system will disable editing of all disbursement entries in a Hold Funds instance, including business party, charge descriptions and amounts, when a Release Date is present.";
                Support.AreEqual("False", FastDriver.HoldFunds.Find.Enabled.ToString(), true);
                Support.AreEqual("True", FastDriver.HoldFunds.HoldFundChargesDescription1.IsReadOnly().ToString(), true);

                Reports.TestStep = "FM4379	Remove Release Date if Check is Voided or Canceled";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "20.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Void", true, 20);
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Test FM437 Remove Release Date if Check is Voided or Canceled");
                FastDriver.VoidDlg.OK.FAClick();

                Reports.TestStep = "Validate Release Date is removed.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                Support.AreEqual(" ", FastDriver.HoldFunds.ReleaseDate.FAGetText(), true);

                Reports.TestStep = "FM2608: If the user enters a Held Amount that is less than or equal to the Buyer's or Seller's Amount in the escrow file balance, the system subtracts this amount from the Buyer Amount or Seller Amount in the escrow file balance. If the Buyer Amount or Seller Amount is zero, the system will show the amount of the Held Funds as a negative Funds Due amount for the Buyer or Seller.";
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("0.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("20.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText(), true);

                Reports.TestStep = "FM1571: The user may edit the Hold Funds reason before all Hold Funds disbursements have been issued. The user may not edit the Hold Funds reason if all disbursements have been issued.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("20.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Print the check";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "20.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                try
                {
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                catch
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.PrintChecks.SwitchToContentFrame();
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Verify the Reason text box is disabled.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.HoldFunds.Reason.Enabled.ToString(), true);

                Reports.TestStep = "FM2481: The system will allow the user to edit the Held Amount if any Hold Funds Disbursement checks have a Pending status in Active Disbursement Summary (including checks that have been previously issued, then voided or canceled), even if other Hold Funds Disbursement checks for the same Hold Funds instance are issued. If the user edits the Held Amount, Amount Remaining must be greater than or equal to the issued Hold Funds Disbursement checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "20.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Void", true, 20);
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Test FM2481");
                FastDriver.VoidDlg.OK.FAClick();

                Reports.TestStep = "Validate users are abled to edit held amount after check is voided.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.SellerCharge.FASetText("30.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0008

        #region FMUC0055_REG0009
        [TestMethod]
        public void FMUC0055_REG0009()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM5045_FM5048_FM1547_FM5047_EWC3: Prevent Delete of Buyers and sellers Hold Funds Entry _Delete a Buyers and sellers Hold Funds Entry User tries to delete a Hold Funds instance that has issued checks.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Create a new Hold Funds instance";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Seller to Check Total release for seller.");
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller - first instance" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Making a cash deposit to avoid overdraft confirmation message.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                var deposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Print the check";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "10.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                try
                {
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                catch
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.PrintChecks.SwitchToContentFrame();
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Validate users cannot delete an Hold Funds instance if checked already issue.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.HoldFunds.Remove.FAClick();
                Support.AreEqual("Unable to Remove Disbursement. Check has been issued. You must cancel check before removing payee.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0009

        #region FMUC0055_REG0010
        [TestMethod]
        public void FMUC0055_REG0010()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "EWC5_EWC6_EWC16_EWC17_ECW_18_ECW19_EWC10: Verify Warning Conditions for Hold Fund Screen.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Create a new Hold Funds instance";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Seller to Check Total release for seller.");
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();

                Reports.TestStep = "EWC5: User searches for a business party on ID Code and system does not find an exact match.";
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("Invalid");
                FastDriver.HoldFunds.Find.FAClick();
                Support.AreEqual("ID Code not found.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller - first instance" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Making a cash deposit to avoid overdraft confirmation message.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                var deposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Print the check";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "10.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                try
                {
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                catch
                {
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                    FastDriver.PrintChecks.SwitchToContentFrame();
                    FastDriver.PrintChecks.Deliver.FAClick();
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "EWC6: User tries to edit or replace a payee name that has an issued check.";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("251");
                FastDriver.HoldFunds.Find.FAClick();
                Support.AreEqual("A check has been issued for this Payee. The Payee name cannot be changed.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                FastDriver.HoldFunds.WaitForScreenToLoad();

                Reports.TestStep = "EWC16: User tries to add or increase a Hold Funds Disbursement charge amount after the payee check is issued.";
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("19.00" + FAKeys.Tab);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(true, false, 20).Clean(), true);
                FastDriver.HoldFunds.WaitForScreenToLoad();

                Reports.TestStep = "EWC17: When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name.";
                FastDriver.HoldFunds.HoldFundEditName.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Name field is required when Edit Name checkbox is selected.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                FastDriver.HoldFunds.WaitForScreenToLoad();

                Reports.TestStep = "EWC18: When the user enters an invalid e-Mail address";
                FastDriver.HoldFunds.Edit.FASetCheckbox(true);
                FastDriver.HoldFunds.HoldFundBusPartyextEmailAddress.FASetText("invalidemail@@firstam.com");
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Please correct invalid data entered.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.HoldFundBusPartyextEmailAddress.FASetText("invalidemail@firstam.com");

                Reports.TestStep = "EWC19: User tries to change a Business Party which has a Reference number specified against it.";
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartytextReference.FASetText("12345");
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("1256" + FAKeys.Tab);
                FastDriver.HoldFunds.Find.FAClick();
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number. Do you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                FastDriver.HoldFunds.WaitForScreenToLoad();

                Reports.TestStep = "EWC10: User cancels entry using Reset button on framework before saving changes to an EXISTING process instance.";
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.BottomFrame.Reset();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0010

        #region FMUC0055_REG0011
        //Cancel of first an second Hold Funds instances already covered by BAT03 and BAT04 test cases
        #endregion FMUC0055_REG0011

        #region FMUC0055_REG0012
        [TestMethod]
        public void FMUC0055_REG0012()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FieldValidations: Verify Field Definition for Hold Fund Screen.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a new Hold Funds instance";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891123445");
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Reason cannot exceed 255 characters", FastDriver.WebDriver.HandleDialogMessage(true, true, 20).Clean(), true);
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij123456789112344");
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.Edit.FASetCheckbox(true);
                FastDriver.HoldFunds.HoldFundBusPartytextBusPhone.FASetText("12345678921234567896123456789'123456789");
                FastDriver.HoldFunds.HoldFundBusPartyExtnPhone.FASetText("123456789696");
                FastDriver.HoldFunds.HoldFundBusPartytextBusFax.FASetText("12345678921234567896123456789123");
                FastDriver.HoldFunds.HoldFundBusPartytextCellPhone.FASetText("12345678921234567896123456789123");
                FastDriver.HoldFunds.HoldFundBusPartytextPager.FASetText("12345678921234567896123456789123");
                FastDriver.HoldFunds.HoldFundBusPartyextEmailAddress.FASetText("busparty@regression.com");
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("abcdefghijabcdefghijabcdefghijabcdefghijabcdefghij");
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying entered Data.";
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual("1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij1234567891abcdefghij123456789112344", FastDriver.HoldFunds.Reason.FAGetValue().Clean(), true);
                Support.AreEqual("20.00", FastDriver.HoldFunds.SellerCharge.FAGetValue().Clean(), true);
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                Support.AreEqual("(123)456-7892", FastDriver.HoldFunds.HoldFundBusPartytextBusPhone.FAGetValue().Clean(), true);
                Support.AreEqual("1234567896", FastDriver.HoldFunds.HoldFundBusPartyExtnPhone.FAGetValue().Clean(), true);
                Support.AreEqual("(123)456-7892", FastDriver.HoldFunds.HoldFundBusPartytextBusFax.FAGetValue().Clean(), true);
                Support.AreEqual("(123)456-7892", FastDriver.HoldFunds.HoldFundBusPartytextCellPhone.FAGetValue().Clean(), true);
                Support.AreEqual("(123)456-7892", FastDriver.HoldFunds.HoldFundBusPartytextPager.FAGetValue().Clean(), true);
                Support.AreEqual("busparty@regression.com", FastDriver.HoldFunds.HoldFundBusPartyextEmailAddress.FAGetValue().Clean(), true);
                Support.AreEqual("abcdefghijabcdefghijabcdefghijabcdefghijabcde", FastDriver.HoldFunds.HoldFundChargesDescription1.FAGetValue().Clean(), true);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0012

        #region FMUC0055_REG0013
        [TestMethod]
        public void FMUC0055_REG0013()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM2398: Display Entry Recap";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a new Hold Funds instance";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Test Seller Fund");
                FastDriver.HoldFunds.RadbtnSeller.FASetCheckbox(true);
                FastDriver.HoldFunds.SellerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Desc For seller - first instance" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Test Buyer Fund");
                FastDriver.HoldFunds.RadbtnBuyer.FASetCheckbox(true);
                FastDriver.HoldFunds.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("HOLDFUNDS");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Hold Funds buyer charge");
                Playback.Wait(1000);
                FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText("10.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate FM2398: Display Entry Recap";
                FastDriver.HoldFundsSummary.WaitForScreenToLoad();
                FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.HoldFundsSummary.Edit.FAClick();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual("10.00", FastDriver.HoldFunds.BuyerCurrentHeldTotal.FAGetText().Clean(), true);
                Support.AreEqual("10.00", FastDriver.HoldFunds.TotalReleasedForBuyer.FAGetText().Clean(), true);
                Support.AreEqual("10.00", FastDriver.HoldFunds.SellerCurrentHeldTotal.FAGetText().Clean(), true);
                Support.AreEqual("10.00", FastDriver.HoldFunds.TotalReleasedForSeller.FAGetText().Clean(), true);
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FMUC0055_REG0013

        #endregion Regression

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}